<?php

namespace App\Traits;

use Illuminate\Support\Str;

/**
 * Oddiy API token tizimi — Sanctum o'rnatilmaguncha ishlaydi.
 * Sanctum o'rnatilgandan keyin bu faylni o'chirish va User modelida
 * use Laravel\Sanctum\HasApiTokens; ga qaytarish kerak.
 */
trait HasApiTokens
{
    /**
     * Yangi API token yaratish
     */
    public function createToken(string $name, array $abilities = ['*'])
    {
        $token = Str::random(64);

        // personal_access_tokens jadvaliga yozish
        $tokenModel = $this->tokens()->create([
            'name'       => $name,
            'token'      => hash('sha256', $token),
            'abilities'  => $abilities,
            'expires_at' => null,
        ]);

        return new class($tokenModel, $token) {
            public $accessToken;
            public string $plainTextToken;

            public function __construct($accessToken, string $plainTextToken)
            {
                $this->accessToken = $accessToken;
                $this->plainTextToken = $accessToken->getKey() . '|' . $plainTextToken;
            }
        };
    }

    /**
     * Tokenlar munosabati
     */
    public function tokens()
    {
        return $this->morphMany(\App\Models\PersonalAccessToken::class, 'tokenable');
    }

    /**
     * Joriy token
     */
    public function currentAccessToken()
    {
        return $this->accessToken ?? null;
    }

    /**
     * Token ni o'rnatish
     */
    public function withAccessToken($accessToken)
    {
        $this->accessToken = $accessToken;
        return $this;
    }
}
