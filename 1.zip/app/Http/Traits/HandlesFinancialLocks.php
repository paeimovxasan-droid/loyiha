<?php

namespace App\Http\Traits;

use App\Models\User;
use App\Models\AIS\Wallet;
use Illuminate\Database\Eloquent\Model;

trait HandlesFinancialLocks
{
    /**
     * Ikki foydalanuvchi yoki obyektni ID bo'yicha tartiblab qulflash
     * Bu Deadlock (o'lik tugun) muammosini 100% bartaraf etadi.
     */
    protected function lockInOrder(Model $modelA, Model $modelB): array
    {
        // ID bo'yicha tartiblash: kichik ID birinchi qulflanadi
        if ($modelA->id < $modelB->id) {
            $first  = $modelA::lockForUpdate()->find($modelA->id);
            $second = $modelB::lockForUpdate()->find($modelB->id);
            return [$first, $second];
        }

        $first  = $modelB::lockForUpdate()->find($modelB->id);
        $second = $modelA::lockForUpdate()->find($modelA->id);
        return [$second, $first]; // Asl tartibda qaytarish [A, B]
    }

    /**
     * Wallet lar uchun ID bo'yicha tartiblab qulflash
     */
    protected function lockWalletsInOrder(int $userIdA, int $userIdB): array
    {
        // IDs ni tartiblash
        $ids = [$userIdA, $userIdB];
        sort($ids);

        // Kichik ID li walletni birinchi qulflash
        $wallet1 = Wallet::lockForUpdate()->where('user_id', $ids[0])->first();
        $wallet2 = Wallet::lockForUpdate()->where('user_id', $ids[1])->first();

        // Asl userIdA va userIdB tartibida qaytarish
        if ($userIdA === $ids[0]) {
            return [$wallet1, $wallet2];
        }
        return [$wallet2, $wallet1];
    }
}
