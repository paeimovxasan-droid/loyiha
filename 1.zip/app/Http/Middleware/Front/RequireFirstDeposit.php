<?php

namespace App\Http\Middleware\Front;

use App\Models\Payment\Deposit;
use App\Models\Setting;
use Closure;
use Illuminate\Http\Request;

/**
 * Birinchi depozit majburligi middleware
 * Agar setting'da require_first_deposit = true bo'lsa,
 * foydalanuvchi depozit qilmagan bo'lsa — deposit sahifasiga yo'naltiriladi.
 */
class RequireFirstDeposit
{
    // Bu sahifalarga depozitsiz kirish mumkin
    private array $allowedRoutes = [
        'app.deposit',
        'app.deposit.store',
        'app.profile',
        'app.profile.update',
        'app.profile.password',
        'app.kyc',
        'app.kyc.passport',
        'app.kyc.face.start',
        'app.kyc.face.submit',
        'app.transactions',
        'logout',
    ];

    public function handle(Request $request, Closure $next)
    {
        $setting = Setting::get();

        // Majburiy depozit o'chirilgan bo'lsa — o'tkazib yuborish
        if (!$setting->require_first_deposit) {
            return $next($request);
        }

        // Ruxsat etilgan sahifalar
        if ($request->routeIs(...$this->allowedRoutes)) {
            return $next($request);
        }

        $user = auth()->user();
        if (!$user) {
            return $next($request);
        }

        // Tasdiqlangan depozit bormi?
        $hasDeposit = Deposit::where('user_id', $user->id)
            ->where('status', 'approved')
            ->where('amount', '>=', $setting->first_deposit_min_amount)
            ->exists();

        if (!$hasDeposit) {
            return redirect()->route('app.deposit')
                ->with('warning',
                    'Platformadan foydalanish uchun kamida ' .
                    number_format($setting->first_deposit_min_amount) .
                    ' UZS depozit qilishingiz kerak.'
                );
        }

        return $next($request);
    }
}
