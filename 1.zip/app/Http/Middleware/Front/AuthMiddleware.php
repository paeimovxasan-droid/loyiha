<?php

namespace App\Http\Middleware\Front;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AuthMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth()->check()) {
            return redirect()->route('login');
        }

        if (auth()->user()->status === 'banned') {
            auth()->logout();
            return redirect()->route('login')->withErrors(['account' => 'Hisobingiz bloklangan.']);
        }

        return $next($request);
    }
}
