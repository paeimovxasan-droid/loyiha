<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CheckInstalled
{
    public function handle(Request $request, Closure $next)
    {
        // Bu yo'llar har doim ruxsat
        if ($request->is('up')) {
            return $next($request);
        }

        // Install sahifalari
        if ($request->is('install') || $request->is('install/*')) {
            // /install/complete har doim ruxsat (o'rnatish tugagandan keyin)
            if ($request->is('install/complete')) {
                return $next($request);
            }

            // O'rnatilgan bo'lsa va database ishlayotgan bo'lsa installerni bloklash
            if (file_exists(storage_path('installed'))) {
                try {
                    \Illuminate\Support\Facades\DB::connection()->getPdo();
                    return redirect('/');
                } catch (\Exception $e) {
                    @unlink(storage_path('installed'));
                }
            }
            return $next($request);
        }

        // O'rnatilmagan bo'lsa /install ga yo'naltirish
        if (!file_exists(storage_path('installed'))) {
            return redirect('/install');
        }

        // O'rnatishdan keyin config cache tozalash (bir marta)
        if (!file_exists(storage_path('cache_cleared'))) {
            try {
                // Config cache faylini o'chirish
                $configCache = base_path('bootstrap/cache/config.php');
                if (file_exists($configCache)) {
                    @unlink($configCache);
                }
                file_put_contents(storage_path('cache_cleared'), now()->toISOString());
            } catch (\Exception $e) {
                // Ignore
            }
        }

        return $next($request);
    }
}
