<?php

namespace App\Http\Middleware\Api;

use App\Models\PersonalAccessToken;
use Closure;
use Illuminate\Http\Request;

/**
 * Oddiy token autentifikatsiya middleware — Sanctum o'rniga.
 */
class SimpleTokenAuth
{
    public function handle(Request $request, Closure $next)
    {
        $token = $request->bearerToken();

        if (!$token) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated.',
                'data'    => null,
                'errors'  => null,
            ], 401);
        }

        $accessToken = PersonalAccessToken::findToken($token);

        if (!$accessToken) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated.',
                'data'    => null,
                'errors'  => null,
            ], 401);
        }

        // Token ishlatilgan vaqtni yangilash
        $accessToken->update(['last_used_at' => now()]);

        // Foydalanuvchini olish
        $user = $accessToken->tokenable;

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Unauthenticated.',
                'data'    => null,
                'errors'  => null,
            ], 401);
        }

        // Auth ga foydalanuvchini o'rnatish
        auth()->setUser($user);
        $request->setUserResolver(fn () => $user);

        return $next($request);
    }
}
