<?php

namespace App\Http\Middleware\Api;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SetLocaleApi
{
    protected array $supported = ['uz', 'ru', 'en'];

    public function handle(Request $request, Closure $next): Response
    {
        $locale = $request->header('Accept-Language', $request->user()?->locale ?? 'uz');
        $locale = in_array($locale, $this->supported) ? $locale : 'uz';

        app()->setLocale($locale);

        return $next($request);
    }
}
