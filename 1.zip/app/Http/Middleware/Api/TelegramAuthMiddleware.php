<?php

namespace App\Http\Middleware\Api;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class TelegramAuthMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!auth('sanctum')->check()) {
            return response()->json([
                'success' => false,
                'data'    => null,
                'message' => 'Autentifikatsiya talab qilinadi',
                'errors'  => null,
            ], 401);
        }

        if (auth('sanctum')->user()->isBanned()) {
            return response()->json([
                'success' => false,
                'data'    => null,
                'message' => 'Hisobingiz bloklangan',
                'errors'  => null,
            ], 403);
        }

        return $next($request);
    }
}
