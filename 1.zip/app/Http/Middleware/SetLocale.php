<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Session;

class SetLocale
{
    protected array $supported = ['uz', 'ru', 'en'];

    public function handle(Request $request, Closure $next)
    {
        // Installer sahifasida locale o'rnatish shart emas
        if ($request->is('install') || $request->is('install/*')) {
            App::setLocale('uz');
            return $next($request);
        }

        if ($request->has('lang') && in_array($request->get('lang'), $this->supported)) {
            Session::put('locale', $request->get('lang'));

            // Kirgan foydalanuvchining locale ni yangilash
            if (auth()->check()) {
                auth()->user()->update(['locale' => $request->get('lang')]);
            }
        }

        // Avval session, keyin foydalanuvchi locale, keyin default
        $locale = Session::get('locale')
            ?? (auth()->check() ? auth()->user()->locale : null)
            ?? 'uz';

        if (!in_array($locale, $this->supported)) {
            $locale = 'uz';
        }

        App::setLocale($locale);

        return $next($request);
    }
}
