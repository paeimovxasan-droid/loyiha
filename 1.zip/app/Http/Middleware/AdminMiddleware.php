<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        if (!Auth::check()) {
            return redirect()->route('admin.login');
        }

        /** @var \App\Models\User $user */
        $user = Auth::user();

        $roles = $user->getRoleNames();

        // Agar foydalanuvchida umuman rol bo'lmasa yoki faqatgina 'user' bo'lsa kirish taqiqlanadi
        if ($roles->isEmpty() || ($roles->count() === 1 && $roles->contains('user'))) {
            Auth::logout();
            return redirect()->route('admin.login')->withErrors([
                'email' => 'Sizda admin panelga kirish ruxsati yo\'q.',
            ]);
        }

        // Bloklangan foydalanuvchi
        if ($user->isBanned()) {
            Auth::logout();
            return redirect()->route('admin.login')->withErrors([
                'email' => 'Hisobingiz bloklangan.',
            ]);
        }

        return $next($request);
    }
}
