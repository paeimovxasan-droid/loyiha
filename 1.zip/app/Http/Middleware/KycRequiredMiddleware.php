<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class KycRequiredMiddleware
{
    public function handle(Request $request, Closure $next): Response
    {
        $user = auth()->user();

        if (!$user) {
            return redirect()->route('login');
        }

        // Admin foydalanuvchilar uchun KYC tekshiruvi o'tkazib yuboriladi
        if ($user->isAdmin()) {
            return $next($request);
        }

        $status = $user->kyc_status;

        if ($status === 'verified') {
            return $next($request);
        }

        $message = match($status) {
            'none', null         => 'Moliyaviy amallar uchun KYC tasdiqlanishi kerak. Hujjat yuboring.',
            'passport_pending'   => 'Pasportingiz ko\'rib chiqilmoqda. Iltimos, kuting.',
            'passport_verified'  => 'Face ID bosqichini o\'ting.',
            'face_pending'       => 'Face ID so\'rovingiz ko\'rib chiqilmoqda. Iltimos, kuting.',
            'rejected'           => 'KYC rad etildi: ' . ($user->kyc_rejection_reason ?? 'Sabab ko\'rsatilmagan') . '. Qaytadan yuboring.',
            default              => 'Moliyaviy amallar uchun KYC tasdiqlanishi kerak.',
        };

        if ($request->expectsJson()) {
            return response()->json([
                'error'        => $message,
                'kyc_required' => true,
                'kyc_status'   => $status,
            ], 403);
        }

        return redirect()->route('app.kyc')->with('error', $message);
    }
}
