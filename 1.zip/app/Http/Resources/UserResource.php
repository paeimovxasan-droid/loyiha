<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
            'username' => $this->username,
            'email' => $this->email,
            'phone' => $this->phone,
            'avatar' => $this->avatar_url, // Getter from Model
            'status' => $this->status,
            'kyc_status' => $this->kyc_status,
            'level' => $this->level,       // Getter from Level trait
            'level_title' => $this->level_title, // Getter from Level trait
            'is_leader' => (bool) $this->is_leader,
        ];
    }
}
