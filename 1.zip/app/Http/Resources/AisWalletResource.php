<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AisWalletResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'wallet_number' => $this->wallet_number,
            'formatted_number' => substr($this->wallet_number, 0, 4) . ' ' . substr($this->wallet_number, 4, 4) . ' ' . substr($this->wallet_number, 8, 4) . ' ' . substr($this->wallet_number, 12, 4),
            'balance' => (float) $this->balance,
            'is_frozen' => (bool) $this->is_frozen,
            'frozen_balance' => (float) $this->frozen_balance,
        ];
    }
}
