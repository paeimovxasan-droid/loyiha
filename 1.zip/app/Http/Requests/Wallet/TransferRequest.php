<?php

namespace App\Http\Requests\Wallet;

use Illuminate\Foundation\Http\FormRequest;

class TransferRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'receiver' => 'required|string',
            'amount'   => 'required|numeric|min:0.0001',
            'note'     => 'nullable|string|max:255',
        ];
    }
}
