<?php

namespace App\Http\Requests\Wallet;

use Illuminate\Foundation\Http\FormRequest;

class ConvertRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        // Buy: UZS miqdori (min 1,000 UZS)
        // Sell: AIS miqdori (min 0.001 AIS)
        $minAmount = $this->direction === 'sell' ? 0.001 : 1000;

        return [
            'direction' => 'required|in:buy,sell',
            'amount'    => "required|numeric|min:{$minAmount}",
        ];
    }

    public function messages(): array
    {
        return [
            'amount.min' => $this->direction === 'sell'
                ? 'Minimal miqdor: 0.001 AIS'
                : 'Minimal miqdor: 1,000 UZS',
        ];
    }
}
