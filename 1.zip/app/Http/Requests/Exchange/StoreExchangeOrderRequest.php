<?php

namespace App\Http\Requests\Exchange;

use Illuminate\Foundation\Http\FormRequest;

class StoreExchangeOrderRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'type'   => 'required|in:limit,market',
            'side'   => 'required|in:buy,sell',
            'price'  => 'required_if:type,limit|nullable|numeric|min:0.01',
            'amount' => 'required|numeric|min:0.0001',
        ];
    }
}
