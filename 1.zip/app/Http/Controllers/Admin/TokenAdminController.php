<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Tokenization\Asset;
use App\Services\TokenizationService;
use Illuminate\Http\Request;

class TokenAdminController extends Controller
{
    public function index()
    {
        $assets = Asset::latest()->paginate(20);
        return view('admin.tokens.index', compact('assets'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'         => 'required|string|max:255',
            'description'  => 'required|string',
            'total_value'  => 'required|numeric|min:1',
            'total_tokens' => 'required|integer|min:1',
        ]);

        TokenizationService::createAsset($data);

        return back()->with('success', 'Aktiv yaratildi');
    }

    public function update(Request $request, Asset $asset)
    {
        $data = $request->validate([
            'name'        => 'string|max:255',
            'description' => 'string',
            'status'      => 'in:active,sold_out,closed',
        ]);

        $asset->update($data);
        return back()->with('success', 'Aktiv yangilandi');
    }
}
