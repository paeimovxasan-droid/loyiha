<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Translation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

class TranslationController extends Controller
{
    public function index(Request $request)
    {
        $query = Translation::query();

        if ($request->filled('group')) {
            $query->where('group', $request->group);
        }
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('key', 'like', "%$search%")
                  ->orWhere('text->uz', 'like', "%$search%")
                  ->orWhere('text->ru', 'like', "%$search%")
                  ->orWhere('text->en', 'like', "%$search%");
            });
        }

        $translations = $query->orderBy('group')->orderBy('key')->paginate(30)->withQueryString();
        $groups = Translation::query()->distinct()->orderBy('group')->pluck('group')->filter()->values();

        return view('admin.translations.index', compact('translations', 'groups'));
    }

    public function create()
    {
        $groups = Translation::query()->distinct()->orderBy('group')->pluck('group')->filter()->values();
        return view('admin.translations.create', compact('groups'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'group'   => 'nullable|string|max:100',
            'key'     => 'required|string|max:255',
            'text.uz' => 'required|string',
            'text.ru' => 'nullable|string',
            'text.en' => 'nullable|string',
        ]);

        // Unique tekshiruvi
        $exists = Translation::where('group', $data['group'] ?? null)
            ->where('key', $data['key'])->exists();

        if ($exists) {
            return back()->withErrors(['key' => 'Bu group+key allready mavjud'])->withInput();
        }

        Translation::create([
            'group' => $data['group'] ?? null,
            'key'   => $data['key'],
            'text'  => [
                'uz' => $data['text']['uz'],
                'ru' => $data['text']['ru'] ?? $data['text']['uz'],
                'en' => $data['text']['en'] ?? $data['text']['uz'],
            ],
        ]);

        Cache::forget('db_translations');

        return redirect()->route('admin.translations.index')
            ->with('success', "Tarjima qo'shildi");
    }

    public function edit(Translation $translation)
    {
        $groups = Translation::query()->distinct()->orderBy('group')->pluck('group')->filter()->values();
        return view('admin.translations.edit', compact('translation', 'groups'));
    }

    public function update(Request $request, Translation $translation)
    {
        $data = $request->validate([
            'group'   => 'nullable|string|max:100',
            'key'     => 'required|string|max:255',
            'text.uz' => 'required|string',
            'text.ru' => 'nullable|string',
            'text.en' => 'nullable|string',
        ]);

        $translation->update([
            'group' => $data['group'] ?? null,
            'key'   => $data['key'],
            'text'  => [
                'uz' => $data['text']['uz'],
                'ru' => $data['text']['ru'] ?? $data['text']['uz'],
                'en' => $data['text']['en'] ?? $data['text']['uz'],
            ],
        ]);

        Cache::forget('db_translations');

        return redirect()->route('admin.translations.index')
            ->with('success', 'Tarjima yangilandi');
    }

    public function destroy(Translation $translation)
    {
        $translation->delete();
        Cache::forget('db_translations');

        return redirect()->route('admin.translations.index')
            ->with('success', "Tarjima o'chirildi");
    }

    /**
     * Cache ni tozalash (admin paneldan)
     */
    public function clearCache()
    {
        Cache::forget('db_translations');
        return back()->with('success', 'Tarjima cache tozalandi');
    }
}
