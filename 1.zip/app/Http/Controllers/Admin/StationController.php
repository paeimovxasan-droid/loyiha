<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Station;
use Illuminate\Http\Request;

class StationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $stations = Station::latest()->paginate(15);
        return view('admin.stations.index', compact('stations'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.stations.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name'             => 'required|array',
            'name.uz'          => 'required|string',
            'name.ru'          => 'nullable|string',
            'name.en'          => 'nullable|string',
            'address'          => 'nullable|array',
            'district'         => 'nullable|array',
            'capacity_kw'      => 'required|numeric',
            'price_per_kw'     => 'required|numeric',
            'old_price_per_kw' => 'nullable|numeric',
            'status'           => 'required|in:active,inactive,maintenance',
            'has_discount'     => 'nullable|in:0,1',
            'latitude'         => 'nullable|numeric',
            'longitude'        => 'nullable|numeric'
        ]);

        $data['has_discount'] = $request->has('has_discount');

        Station::create($data);

        return redirect()->route('admin.stations.index')->with('success', __('messages.saved'));
    }

    /**
     * Display the specified resource.
     */
    public function show(Station $station)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Station $station)
    {
        return view('admin.stations.edit', compact('station'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Station $station)
    {
        $data = $request->validate([
            'name'             => 'required|array',
            'name.uz'          => 'required|string',
            'name.ru'          => 'nullable|string',
            'name.en'          => 'nullable|string',
            'address'          => 'nullable|array',
            'district'         => 'nullable|array',
            'capacity_kw'      => 'required|numeric',
            'price_per_kw'     => 'required|numeric',
            'old_price_per_kw' => 'nullable|numeric',
            'status'           => 'required|in:active,inactive,maintenance',
            'has_discount'     => 'nullable|in:0,1',
            'latitude'         => 'nullable|numeric',
            'longitude'        => 'nullable|numeric'
        ]);

        $data['has_discount'] = $request->has('has_discount');

        $station->update($data);

        return redirect()->route('admin.stations.index')->with('success', __('messages.saved'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Station $station)
    {
        $station->delete();
        return redirect()->route('admin.stations.index')->with('success', __('messages.deleted'));
    }
}
