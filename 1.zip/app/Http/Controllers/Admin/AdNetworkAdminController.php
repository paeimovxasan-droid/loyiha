<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AdNetwork\AdCampaign;
use App\Models\AdNetwork\Ad;
use Illuminate\Http\Request;

class AdNetworkAdminController extends Controller
{
    public function campaigns(Request $request)
    {
        $query = AdCampaign::with('user:id,name,username')->latest();
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        $campaigns = $query->paginate(20);
        return view('admin.ad-network.campaigns', compact('campaigns'));
    }

    public function ads(Request $request)
    {
        $query = Ad::with('campaign')->latest();
        $ads = $query->paginate(20);
        return view('admin.ad-network.ads', compact('ads'));
    }

    public function editCampaign(AdCampaign $campaign)
    {
        $campaign->load('user:id,name,username');
        return view('admin.ad-network.edit_campaign', compact('campaign'));
    }

    public function updateCampaign(Request $request, AdCampaign $campaign)
    {
        $request->validate([
            'name'   => 'required|string|max:255',
            'budget' => 'required|numeric|min:0',
            'status' => 'required|in:active,paused,completed',
        ]);

        $campaign->update($request->only('name', 'budget', 'status'));

        return redirect()->route('admin.ad-network.campaigns')->with('success', 'Kampaniya muvaffaqiyatli yangilandi.');
    }
}
