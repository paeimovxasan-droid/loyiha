<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment\PaymentMethod;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Services\FileUploadService;

class PaymentMethodController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $methods = PaymentMethod::orderBy('sort_order')->get();
        return view('admin.payment_methods.index', compact('methods'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('admin.payment_methods.create');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'                   => 'required|array',
            'name.uz'                => 'required|string',
            'name.ru'                => 'nullable|string',
            'name.en'                => 'nullable|string',
            'number'                 => 'nullable|string|max:32',
            'minimum_deposit'        => 'required|numeric|min:0',
            'maximum_deposit'        => 'required|numeric|min:0',
            'deposit_charge_percent' => 'required|numeric|min:0',
            'minimum_withdraw'       => 'required|numeric|min:0',
            'maximum_withdraw'       => 'required|numeric|min:0',
            'withdraw_charge_percent'=> 'required|numeric|min:0',
            'photo_id'               => 'nullable|integer|exists:files,id',
            'status'                 => 'required|string|in:active,inactive',
            'sort_order'             => 'required|integer|min:0',
        ]);

        $validated['slug'] = Str::slug($validated['name']['uz']) . '-' . rand(100, 999);

        // photo_id bo'sh kelsa — olib tashlaymiz
        if (empty($validated['photo_id'])) {
            unset($validated['photo_id']);
        }

        PaymentMethod::create($validated);

        return redirect()->route('admin.payment_methods.index')->with('success', 'To\'lov usuli muvaffaqiyatli qo\'shildi');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(PaymentMethod $paymentMethod)
    {
        return view('admin.payment_methods.edit', compact('paymentMethod'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, PaymentMethod $paymentMethod)
    {
        $validated = $request->validate([
            'name'                   => 'required|array',
            'name.uz'                => 'required|string',
            'name.ru'                => 'nullable|string',
            'name.en'                => 'nullable|string',
            'number'                 => 'nullable|string|max:32',
            'minimum_deposit'        => 'required|numeric|min:0',
            'maximum_deposit'        => 'required|numeric|min:0',
            'deposit_charge_percent' => 'required|numeric|min:0',
            'minimum_withdraw'       => 'required|numeric|min:0',
            'maximum_withdraw'       => 'required|numeric|min:0',
            'withdraw_charge_percent'=> 'required|numeric|min:0',
            'photo_id'               => 'nullable|integer|exists:files,id',
            'status'                 => 'required|string|in:active,inactive',
            'sort_order'             => 'required|integer|min:0',
        ]);

        // photo_id bo'sh string yoki null kelsa — mavjud rasmni saqlaymiz
        if (empty($validated['photo_id'])) {
            unset($validated['photo_id']);
        }

        $paymentMethod->update($validated);

        return redirect()->route('admin.payment_methods.index')->with('success', 'To\'lov usuli muvaffaqiyatli yangilandi');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(PaymentMethod $paymentMethod)
    {
        $paymentMethod->delete();
        return redirect()->route('admin.payment_methods.index')->with('success', 'To\'lov usuli o\'chirildi');
    }
}
