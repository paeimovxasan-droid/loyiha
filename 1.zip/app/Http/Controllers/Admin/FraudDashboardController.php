<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment\Deposit;
use App\Models\Security\AuditLog;
use App\Models\Security\FraudFlag;
use App\Models\Security\UserDevice;
use App\Models\User;
use App\Services\Security\FraudDetectionService;
use Illuminate\Http\Request;

class FraudDashboardController extends Controller
{
    public function index(): \Illuminate\View\View
    {
        $stats = [
            'today_flags'    => FraudFlag::whereDate('created_at', today())->count(),
            'high_risk'      => User::where('is_high_risk', true)->count(),
            'blocked_ips'    => \App\Models\Security\IpCheck::where('is_vpn', true)
                                    ->orWhere('is_proxy', true)->count(),
            'pending_kyc'    => User::whereIn('kyc_status', ['passport_pending', 'face_pending'])->count(),
            'total_flags'    => FraudFlag::whereNull('resolved_at')->count(),
            'banned_users'   => User::where('status', 'banned')->count(),
        ];

        $recentFlags = FraudFlag::with('user')
            ->whereNull('resolved_at')
            ->latest()
            ->limit(10)
            ->get();

        $recentSuspicious = Deposit::with('user')
            ->where('is_suspicious', true)
            ->latest()
            ->limit(5)
            ->get();

        return view('admin.fraud.index', compact('stats', 'recentFlags', 'recentSuspicious'));
    }

    public function users(Request $request): \Illuminate\View\View
    {
        $query = User::with(['fraudFlags', 'devices'])
            ->whereHas('fraudFlags', fn($q) => $q->whereNull('resolved_at'));

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(fn($q) => $q
                ->where('name', 'like', "%{$s}%")
                ->orWhere('email', 'like', "%{$s}%")
                ->orWhere('username', 'like', "%{$s}%")
            );
        }

        if ($request->filled('risk')) {
            $query->where('is_high_risk', $request->risk === 'high');
        }

        $users = $query->latest()->paginate(20)->withQueryString();

        return view('admin.fraud.users', compact('users'));
    }

    public function transactions(Request $request): \Illuminate\View\View
    {
        $deposits = Deposit::with('user')
            ->where('is_suspicious', true)
            ->latest()
            ->paginate(20);

        return view('admin.fraud.transactions', compact('deposits'));
    }

    public function userDetail(User $user): \Illuminate\View\View
    {
        $user->load(['fraudFlags', 'devices', 'behavioralScoreLogs']);

        $fraudFlags    = $user->fraudFlags()->latest()->get();
        $devices       = $user->devices()->latest()->get();
        $scoreLogs     = $user->behavioralScoreLogs()->latest()->limit(20)->get();
        $auditLogs     = AuditLog::where('user_id', $user->id)->latest()->limit(30)->get();

        // Bir xil IP dan ro'yxatdan o'tgan boshqa akkauntlar
        $registrationIps = $user->devices()
            ->where('event_type', 'register')
            ->pluck('ip_address')
            ->unique();

        $relatedAccounts = collect();
        foreach ($registrationIps as $ip) {
            $accounts = UserDevice::where('ip_address', $ip)
                ->where('event_type', 'register')
                ->where('user_id', '!=', $user->id)
                ->with('user')
                ->get()
                ->pluck('user')
                ->filter();
            $relatedAccounts = $relatedAccounts->merge($accounts);
        }
        $relatedAccounts = $relatedAccounts->unique('id');

        return view('admin.fraud.user-detail', compact(
            'user', 'fraudFlags', 'devices', 'scoreLogs', 'auditLogs', 'relatedAccounts'
        ));
    }

    public function banUser(User $user): \Illuminate\Http\RedirectResponse
    {
        if ($user->isAdmin()) {
            return back()->with('error', 'Admin foydalanuvchini ban qilib bo\'lmaydi.');
        }

        FraudDetectionService::banUser($user);

        return back()->with('success', "{$user->name} ban qilindi.");
    }

    public function unbanUser(User $user): \Illuminate\Http\RedirectResponse
    {
        $user->update(['status' => 'active']);

        try {
            AuditLog::log('user_unbanned', $user, ['unbanned_by' => auth()->id()]);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('AuditLog unbanUser failed', ['error' => $e->getMessage()]);
        }

        return back()->with('success', "{$user->name} ban olib tashlandi.");
    }

    public function removeFraudFlag(User $user, FraudFlag $flag): \Illuminate\Http\RedirectResponse
    {
        if ($flag->user_id !== $user->id) {
            return back()->with('error', 'Flag topilmadi.');
        }

        FraudDetectionService::unflagUser($user, $flag->id);

        return back()->with('success', 'Fraud flag olib tashlandi.');
    }

    public function auditLogs(Request $request): \Illuminate\View\View
    {
        $query = AuditLog::with('user')->latest();

        if ($request->filled('action')) {
            $query->where('action', 'like', '%' . $request->action . '%');
        }

        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }

        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $logs = $query->paginate(30)->withQueryString();

        return view('admin.fraud.audit-logs', compact('logs'));
    }
}
