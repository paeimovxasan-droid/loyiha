<?php

namespace App\Http\Controllers\Admin\Marketing;

use App\Http\Controllers\Controller;
use App\Models\Marketing\InviteChallengeSettings;
use Illuminate\Http\Request;

class InviteChallengeController extends Controller
{
    public function settings()
    {
        $settings = InviteChallengeSettings::instance();
        return view('admin.marketing.invite-challenge.settings', compact('settings'));
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'duration_days'        => 'nullable|integer|min:1',
            'target_referrals'     => 'nullable|integer|min:1',
            'reward_ais'           => 'nullable|numeric|min:0',
            'min_deposit_required' => 'nullable|boolean',
        ]);

        $settings = InviteChallengeSettings::instance();
        $settings->update(array_filter($data, fn ($v) => $v !== null));
        return back()->with('success', 'Sozlamalar yangilandi.');
    }
}
