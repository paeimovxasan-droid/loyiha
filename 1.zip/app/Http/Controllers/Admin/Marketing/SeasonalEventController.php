<?php

namespace App\Http\Controllers\Admin\Marketing;

use App\Http\Controllers\Controller;
use App\Models\Marketing\SeasonalEvent;
use App\Services\Marketing\EventService;
use Illuminate\Http\Request;

class SeasonalEventController extends Controller
{
    public function index(Request $request)
    {
        $query = SeasonalEvent::with('quests')->orderByDesc('created_at');
        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }
        $events = $query->paginate(15);
        return view('admin.marketing.events.index', compact('events'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'        => 'required|string|max:255',
            'description' => 'nullable|string',
            'starts_at'   => 'required|date',
            'ends_at'     => 'required|date|after:starts_at',
        ]);
        SeasonalEvent::create($data);
        return back()->with('success', 'Tadbir yaratildi.');
    }

    public function update(Request $request, int $id)
    {
        $event = SeasonalEvent::findOrFail($id);
        $data = $request->validate([
            'name'        => 'nullable|string|max:255',
            'description' => 'nullable|string',
            'ends_at'     => 'nullable|date',
            'status'      => 'nullable|in:active,finalized',
        ]);
        $event->update(array_filter($data, fn ($v) => $v !== null));
        return back()->with('success', 'Tadbir yangilandi.');
    }

    public function destroy(int $id)
    {
        $event = SeasonalEvent::findOrFail($id);
        $event->quests()->detach();
        $event->delete();
        return back()->with('success', 'Tadbir o\'chirildi.');
    }
}
