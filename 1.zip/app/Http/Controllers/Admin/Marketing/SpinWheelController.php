<?php

namespace App\Http\Controllers\Admin\Marketing;

use App\Http\Controllers\Controller;
use App\Models\Marketing\SpinWheelPrize;
use Illuminate\Http\Request;

class SpinWheelController extends Controller
{
    public function index()
    {
        $prizes = SpinWheelPrize::orderBy('id')->get();

        // Statistika
        $totalSpins   = \App\Models\Marketing\SpinWheelLog::count();
        $todaySpins   = \App\Models\Marketing\SpinWheelLog::where('spun_at', today())->count();
        $totalAisGiven = \App\Models\Marketing\SpinWheelLog::where('prize_type', 'ais')->sum('prize_value');

        return view('admin.marketing.spin-wheel.index', compact('prizes', 'totalSpins', 'todaySpins', 'totalAisGiven'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'type'    => 'required|in:ais,xp,lucky_ticket,nothing',
            'value'   => 'required|numeric|min:0',
            'label_uz'=> 'required|string|max:50',
            'label_ru'=> 'nullable|string|max:50',
            'label_en'=> 'nullable|string|max:50',
            'weight'  => 'required|integer|min:1|max:1000',
            'color'   => 'nullable|string|max:7',
            'status'  => 'required|in:active,inactive',
        ]);

        SpinWheelPrize::create([
            'type'   => $data['type'],
            'value'  => $data['value'],
            'label'  => [
                'uz' => $data['label_uz'],
                'ru' => $data['label_ru'] ?? $data['label_uz'],
                'en' => $data['label_en'] ?? $data['label_uz'],
            ],
            'weight' => $data['weight'],
            'color'  => $data['color'] ?? '#6366f1',
            'status' => $data['status'],
        ]);

        return back()->with('success', 'Yangi mukofot qo\'shildi.');
    }

    public function updatePrize(Request $request, SpinWheelPrize $prize)
    {
        $data = $request->validate([
            'type'    => 'required|in:ais,xp,lucky_ticket,nothing',
            'value'   => 'required|numeric|min:0',
            'label_uz'=> 'required|string|max:50',
            'label_ru'=> 'nullable|string|max:50',
            'label_en'=> 'nullable|string|max:50',
            'weight'  => 'required|integer|min:1|max:1000',
            'color'   => 'nullable|string|max:7',
            'status'  => 'required|in:active,inactive',
        ]);

        $prize->update([
            'type'   => $data['type'],
            'value'  => $data['value'],
            'label'  => [
                'uz' => $data['label_uz'],
                'ru' => $data['label_ru'] ?? $data['label_uz'],
                'en' => $data['label_en'] ?? $data['label_uz'],
            ],
            'weight' => $data['weight'],
            'color'  => $data['color'] ?? '#6366f1',
            'status' => $data['status'],
        ]);

        return back()->with('success', 'Mukofot yangilandi.');
    }

    public function destroy(SpinWheelPrize $prize)
    {
        $prize->delete();
        return back()->with('success', 'Mukofot o\'chirildi.');
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'prizes'          => 'required|array|min:1',
            'prizes.*.id'     => 'nullable|integer|exists:spin_wheel_prizes,id',
            'prizes.*.type'   => 'required|in:ais,xp,lucky_ticket,nothing',
            'prizes.*.value'  => 'required|numeric|min:0',
            'prizes.*.label'  => 'required|array',
            'prizes.*.weight' => 'required|integer|min:1',
            'prizes.*.color'  => 'nullable|string|max:7',
            'prizes.*.status' => 'nullable|in:active,inactive',
        ]);

        foreach ($data['prizes'] as $prizeData) {
            if (!empty($prizeData['id'])) {
                $prize = SpinWheelPrize::find($prizeData['id']);
                if ($prize) $prize->update($prizeData);
            } else {
                SpinWheelPrize::create($prizeData);
            }
        }
        return back()->with('success', 'Mukofotlar yangilandi.');
    }
}
