<?php

namespace App\Http\Controllers\Admin\Marketing;

use App\Http\Controllers\Controller;
use App\Models\Marketing\LeaderboardCompetition;
use Illuminate\Http\Request;

class LeaderboardController extends Controller
{
    public function index()
    {
        $active = LeaderboardCompetition::active()->orderByDesc('created_at')->get();
        $history = LeaderboardCompetition::where('status', 'finalized')->orderByDesc('ends_at')->limit(20)->get();
        return view('admin.marketing.competitions.index', compact('active', 'history'));
    }

    public function settings(Request $request)
    {
        $data = $request->validate([
            'weekly_prizes'  => 'nullable|array',
            'monthly_prizes' => 'nullable|array',
        ]);

        if (!empty($data['weekly_prizes'])) {
            LeaderboardCompetition::active()->weekly()->update(['prizes' => $data['weekly_prizes']]);
        }
        if (!empty($data['monthly_prizes'])) {
            LeaderboardCompetition::active()->monthly()->update(['prizes' => $data['monthly_prizes']]);
        }
        return back()->with('success', 'Musobaqa sozlamalari yangilandi.');
    }
}
