<?php

namespace App\Http\Controllers\Admin\Marketing;

use App\Http\Controllers\Controller;
use App\Models\Marketing\PromoCode;
use App\Services\Marketing\PromoService;
use Illuminate\Http\Request;

class PromoCodeController extends Controller
{
    public function index(Request $request)
    {
        $query = PromoCode::orderByDesc('created_at');
        if ($request->filled('status')) {
            $query->where('status', $request->input('status'));
        }
        $promoCodes = $query->paginate(15);
        return view('admin.marketing.promo-codes.index', compact('promoCodes'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'code'           => 'required|string|max:50|unique:promo_codes,code',
            'reward_ais'     => 'required|numeric|min:0',
            'reward_xp'      => 'required|integer|min:0',
            'max_uses'       => 'nullable|integer|min:1',
            'starts_at'      => 'nullable|date',
            'expires_at'     => 'nullable|date|after_or_equal:starts_at',
            'new_users_only' => 'nullable|boolean',
            'new_user_hours' => 'nullable|integer|min:1',
        ]);
        PromoService::create($data);
        return back()->with('success', 'Promo-kod yaratildi.');
    }

    public function update(Request $request, int $id)
    {
        $promo = PromoCode::findOrFail($id);
        $data = $request->validate([
            'reward_ais'     => 'nullable|numeric|min:0',
            'reward_xp'      => 'nullable|integer|min:0',
            'max_uses'       => 'nullable|integer|min:1',
            'expires_at'     => 'nullable|date',
            'status'         => 'nullable|in:active,inactive',
            'new_users_only' => 'nullable|boolean',
        ]);
        $promo->update(array_filter($data, fn ($v) => $v !== null));
        return back()->with('success', 'Promo-kod yangilandi.');
    }

    public function destroy(int $id)
    {
        PromoCode::findOrFail($id)->delete();
        return back()->with('success', 'Promo-kod o\'chirildi.');
    }

    public function stats(int $id)
    {
        $promo = PromoCode::findOrFail($id);
        $stats = PromoService::stats($promo);
        return view('admin.marketing.promo-codes.stats', compact('promo', 'stats'));
    }
}
