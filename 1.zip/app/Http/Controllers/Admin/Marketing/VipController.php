<?php

namespace App\Http\Controllers\Admin\Marketing;

use App\Http\Controllers\Controller;
use App\Models\Marketing\MembershipTier;
use Illuminate\Http\Request;

class VipController extends Controller
{
    public function index()
    {
        $tiers = MembershipTier::orderBy('min_ais_earned')->get();
        return view('admin.marketing.vip.index', compact('tiers'));
    }

    public function settings(Request $request)
    {
        $data = $request->validate([
            'tiers'                        => 'required|array|min:1',
            'tiers.*.tier'                 => 'required|string',
            'tiers.*.min_ais_earned'       => 'required|numeric|min:0',
            'tiers.*.min_referrals'        => 'required|integer|min:0',
            'tiers.*.cashback_percent'     => 'required|numeric|min:0|max:100',
            'tiers.*.fee_discount_percent' => 'required|numeric|min:0|max:100',
        ]);

        foreach ($data['tiers'] as $tierData) {
            MembershipTier::updateOrCreate(['tier' => $tierData['tier']], $tierData);
        }
        return back()->with('success', 'VIP sozlamalari yangilandi.');
    }
}
