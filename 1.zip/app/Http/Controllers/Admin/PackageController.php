<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Package\Package;
use Illuminate\Support\Facades\Storage;
use App\Services\FileUploadService;

class PackageController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $packages = Package::orderBy('sort_order')->get();
        return view('admin.packages.index', compact('packages'));
    }

    public function create()
    {
        return view('admin.packages.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name_uz'              => 'required|string|max:255',
            'name_ru'              => 'nullable|string|max:255',
            'name_en'              => 'nullable|string|max:255',
            'photo_id'             => 'nullable|integer|exists:files,id',
            'price'                => 'required|numeric|min:0',
            'validity_days'        => 'required|integer|min:1',
            'daily_profit_percent' => 'required|numeric|min:0',
            'total_profit_percent' => 'required|numeric|min:0',
            'sponsor_income'       => 'required|numeric|min:0',
            'ref_level1'           => 'required|numeric|min:0',
            'ref_level2'           => 'required|numeric|min:0',
            'ref_level3'           => 'required|numeric|min:0',
            'is_default'           => 'nullable|boolean',
            'status'               => 'required|in:active,inactive',
            'sort_order'           => 'required|integer|min:0',
        ]);

        $name = [
            'uz' => $data['name_uz'],
            'ru' => $data['name_ru'] ?? $data['name_uz'],
            'en' => $data['name_en'] ?? $data['name_uz'],
        ];

        unset($data['name_uz'], $data['name_ru'], $data['name_en']);
        $data['name'] = $name;

        // photo_id AJAX orqali yuklangan — $data ichida allaqachon bor
        // bo'sh bo'lsa null ga o'tkazamiz
        if (empty($data['photo_id'])) {
            unset($data['photo_id']);
        }

        $data['is_default'] = $request->has('is_default');

        if ($data['is_default']) {
            Package::where('is_default', true)->update(['is_default' => false]);
        }

        Package::create($data);

        return redirect()->route('admin.packages.index')->with('success', 'Paket muvaffaqiyatli qo\'shildi.');
    }

    public function edit(string $id)
    {
        $package = Package::findOrFail($id);
        return view('admin.packages.edit', compact('package'));
    }

    public function update(Request $request, string $id)
    {
        $package = Package::findOrFail($id);
        
        $data = $request->validate([
            'name_uz'              => 'required|string|max:255',
            'name_ru'              => 'nullable|string|max:255',
            'name_en'              => 'nullable|string|max:255',
            'photo_id'             => 'nullable|integer|exists:files,id',
            'price'                => 'required|numeric|min:0',
            'validity_days'        => 'required|integer|min:1',
            'daily_profit_percent' => 'required|numeric|min:0',
            'total_profit_percent' => 'required|numeric|min:0',
            'sponsor_income'       => 'required|numeric|min:0',
            'ref_level1'           => 'required|numeric|min:0',
            'ref_level2'           => 'required|numeric|min:0',
            'ref_level3'           => 'required|numeric|min:0',
            'is_default'           => 'nullable|boolean',
            'status'               => 'required|in:active,inactive',
            'sort_order'           => 'required|integer|min:0',
        ]);

        $name = [
            'uz' => $data['name_uz'],
            'ru' => $data['name_ru'] ?? $data['name_uz'],
            'en' => $data['name_en'] ?? $data['name_uz'],
        ];

        unset($data['name_uz'], $data['name_ru'], $data['name_en']);
        $data['name'] = $name;

        // photo_id AJAX orqali yuklangan — $data ichida allaqachon bor
        // bo'sh string kelsa — o'zgartirmaymiz (mavjud rasmni saqlaymiz)
        if (isset($data['photo_id']) && $data['photo_id'] === '') {
            unset($data['photo_id']);
        } elseif (empty($data['photo_id'])) {
            unset($data['photo_id']);
        }

        $data['is_default'] = $request->has('is_default');

        if ($data['is_default']) {
            Package::where('id', '!=', $package->id)->update(['is_default' => false]);
        }

        $package->update($data);

        return redirect()->route('admin.packages.index')->with('success', 'Paket muvaffaqiyatli yangilandi.');
    }

    public function destroy(string $id)
    {
        $package = Package::findOrFail($id);
        // optional: define delete behavior for the file if necessary, but since it's nullable with nullOnDelete, just deleting the package is fine
        $package->delete();

        return redirect()->route('admin.packages.index')->with('success', 'Paket o\'chirildi.');
    }
}
