<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Credit\Credit;
use Illuminate\Http\Request;

class CreditAdminController extends Controller
{
    public function index(Request $request)
    {
        try {
            $query = Credit::with('user:id,name,username')->latest();
            if ($request->filled('status')) {
                $query->where('status', $request->status);
            }
            $credits = $query->paginate(20);
            return view('admin.credit.index', compact('credits'));
        } catch (\Throwable $e) {
            return back()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }

    public function edit(Credit $credit)
    {
        $credit->load('user:id,name,username');
        return view('admin.credit.edit', compact('credit'));
    }

    public function update(Request $request, Credit $credit)
    {
        $request->validate([
            'amount'        => 'required|numeric|min:0',
            'interest_rate' => 'required|numeric|min:0',
            'term_days'     => 'required|integer|min:1',
            'status'        => 'required|in:pending,active,repaid,overdue,defaulted',
            'due_date'      => 'nullable|date',
        ]);

        $credit->update($request->only('amount', 'interest_rate', 'term_days', 'status', 'due_date'));

        return redirect()->route('admin.credits.index')->with('success', 'Kredit muvaffaqiyatli yangilandi.');
    }
}
