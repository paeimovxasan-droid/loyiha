<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Game\Quest;
use App\Models\Game\UserQuest;
use Illuminate\Http\Request;

class QuestAdminController extends Controller
{
    public function index()
    {
        $quests = Quest::withCount(['userQuests', 'userQuests as claimed_count' => fn($q) => $q->where('status', 'claimed')])
            ->orderBy('sort_order')->get();

        $stats = [
            'total'         => $quests->count(),
            'active'        => $quests->where('status', 'active')->count(),
            'total_claimed' => UserQuest::where('status', 'claimed')->count(),
        ];

        return view('admin.quests.index', compact('quests', 'stats'));
    }

    public function create()
    {
        return view('admin.quests.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title_uz'          => 'required|string|max:255',
            'title_ru'          => 'nullable|string|max:255',
            'title_en'          => 'nullable|string|max:255',
            'description_uz'    => 'nullable|string',
            'description_ru'    => 'nullable|string',
            'description_en'    => 'nullable|string',
            'icon'              => 'required|string|max:10',
            'category'          => 'required|string',
            'type'              => 'required|in:one_time,daily,weekly,repeatable',
            'requirement_type'  => 'required|string',
            'requirement_value' => 'required|integer|min:1',
            'reward_ais'        => 'required|numeric|min:0',
            'reward_uzs'        => 'required|numeric|min:0',
            'reward_xp'         => 'required|integer|min:0',
            'reward_badge'      => 'nullable|string|max:50',
            'min_level'         => 'required|integer|min:0',
            'sort_order'        => 'required|integer|min:0',
            'status'            => 'required|in:active,inactive',
            'expires_at'        => 'nullable|date',
        ]);

        Quest::create(array_merge($data, [
            'title'       => ['uz' => $data['title_uz'], 'ru' => $data['title_ru'] ?? $data['title_uz'], 'en' => $data['title_en'] ?? $data['title_uz']],
            'description' => ['uz' => $data['description_uz'] ?? '', 'ru' => $data['description_ru'] ?? '', 'en' => $data['description_en'] ?? ''],
        ]));

        return redirect()->route('admin.quests.index')->with('success', 'Kvest yaratildi.');
    }

    public function edit(Quest $quest)
    {
        return view('admin.quests.edit', compact('quest'));
    }

    public function update(Request $request, Quest $quest)
    {
        $data = $request->validate([
            'title_uz'          => 'required|string|max:255',
            'title_ru'          => 'nullable|string|max:255',
            'title_en'          => 'nullable|string|max:255',
            'description_uz'    => 'nullable|string',
            'description_ru'    => 'nullable|string',
            'description_en'    => 'nullable|string',
            'icon'              => 'required|string|max:10',
            'category'          => 'required|string',
            'type'              => 'required|in:one_time,daily,weekly,repeatable',
            'requirement_type'  => 'required|string',
            'requirement_value' => 'required|integer|min:1',
            'reward_ais'        => 'required|numeric|min:0',
            'reward_uzs'        => 'required|numeric|min:0',
            'reward_xp'         => 'required|integer|min:0',
            'reward_badge'      => 'nullable|string|max:50',
            'min_level'         => 'required|integer|min:0',
            'sort_order'        => 'required|integer|min:0',
            'status'            => 'required|in:active,inactive',
            'expires_at'        => 'nullable|date',
        ]);

        $quest->update(array_merge($data, [
            'title'       => ['uz' => $data['title_uz'], 'ru' => $data['title_ru'] ?? $data['title_uz'], 'en' => $data['title_en'] ?? $data['title_uz']],
            'description' => ['uz' => $data['description_uz'] ?? '', 'ru' => $data['description_ru'] ?? '', 'en' => $data['description_en'] ?? ''],
        ]));

        return redirect()->route('admin.quests.index')->with('success', 'Kvest yangilandi.');
    }

    public function destroy(Quest $quest)
    {
        $quest->delete();
        return back()->with('success', 'Kvest o\'chirildi.');
    }
}
