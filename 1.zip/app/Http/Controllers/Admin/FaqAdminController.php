<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AiAssistant\FaqEntry;
use Illuminate\Http\Request;

class FaqAdminController extends Controller
{
    public function index()
    {
        $faqs = FaqEntry::latest()->paginate(30);
        return view('admin.faq.index', compact('faqs'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'question' => 'required|string|max:255',
            'answer'   => 'required|string',
            'category' => 'nullable|string|max:100',
            'keywords' => 'nullable|string|max:255',
        ]);

        FaqEntry::create($data);
        return back()->with('success', 'FAQ yaratildi');
    }

    public function update(Request $request, FaqEntry $faq)
    {
        $data = $request->validate([
            'question'  => 'string|max:255',
            'answer'    => 'string',
            'category'  => 'nullable|string|max:100',
            'keywords'  => 'nullable|string|max:255',
            'is_active' => 'boolean',
        ]);

        $faq->update($data);
        return back()->with('success', 'FAQ yangilandi');
    }

    public function destroy(FaqEntry $faq)
    {
        $faq->delete();
        return back()->with('success', 'FAQ o\'chirildi');
    }
}
