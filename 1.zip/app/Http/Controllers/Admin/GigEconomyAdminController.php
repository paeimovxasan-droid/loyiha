<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\GigEconomy\GigListing;
use App\Models\GigEconomy\GigApplication;
use Illuminate\Http\Request;

class GigEconomyAdminController extends Controller
{
    public function listings(Request $request)
    {
        $query = GigListing::with('user:id,name,username')->latest();
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        $listings = $query->paginate(20);
        return view('admin.gig-economy.listings', compact('listings'));
    }

    public function applications(Request $request)
    {
        $query = GigApplication::with(['gig', 'user:id,name,username'])->latest();
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        $applications = $query->paginate(20);
        return view('admin.gig-economy.applications', compact('applications'));
    }

    public function editListing(GigListing $listing)
    {
        $listing->load('user:id,name,username');
        return view('admin.gig-economy.edit_listing', compact('listing'));
    }

    public function updateListing(Request $request, GigListing $listing)
    {
        $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string',
            'budget'      => 'required|numeric|min:0',
            'status'      => 'required|in:open,in_progress,completed,cancelled',
        ]);

        $listing->update($request->only('title', 'description', 'budget', 'status'));

        return redirect()->route('admin.gig-economy.listings')->with('success', 'E\'lon muvaffaqiyatli yangilandi.');
    }

    public function destroyListing(GigListing $listing)
    {
        $listing->delete();
        return back()->with('success', 'E\'lon o\'chirildi.');
    }
}
