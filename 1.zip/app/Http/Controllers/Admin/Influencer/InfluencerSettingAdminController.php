<?php

namespace App\Http\Controllers\Admin\Influencer;

use App\Http\Controllers\Controller;
use App\Models\Influencer\InfluencerSetting;
use Illuminate\Http\Request;

class InfluencerSettingAdminController extends Controller
{
    public function index()
    {
        $setting = InfluencerSetting::current();
        return view('admin.influencer.settings.index', compact('setting'));
    }

    public function update(Request $request)
    {
        $data = $request->validate([
            'is_enabled'               => 'boolean',
            'coeff_youtube_channel'    => 'required|numeric|min:0.01|max:10',
            'coeff_telegram_channel'   => 'required|numeric|min:0.01|max:10',
            'coeff_telegram_group'     => 'required|numeric|min:0.01|max:10',
            'coeff_telegram_bot'       => 'required|numeric|min:0.01|max:10',
            'min_subscribers_youtube'  => 'required|integer|min:0',
            'min_subscribers_telegram' => 'required|integer|min:0',
            'screenshot_required'      => 'boolean',
            'max_daily_submissions'    => 'required|integer|min:1|max:100',
            'max_channels_per_user'    => 'required|integer|min:1|max:50',
        ]);

        $setting = InfluencerSetting::current();
        $setting->update(array_merge($data, [
            'is_enabled'        => $request->boolean('is_enabled'),
            'screenshot_required'=> $request->boolean('screenshot_required'),
            'updated_at'        => now(),
            'updated_by'        => auth()->id(),
        ]));

        InfluencerSetting::clearCache();

        return back()->with('success', 'Sozlamalar saqlandi.');
    }
}
