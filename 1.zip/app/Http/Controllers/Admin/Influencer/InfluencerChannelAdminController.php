<?php

namespace App\Http\Controllers\Admin\Influencer;

use App\Http\Controllers\Controller;
use App\Models\Influencer\InfluencerChannel;
use App\Services\Influencer\InfluencerChannelService;
use Illuminate\Http\Request;

class InfluencerChannelAdminController extends Controller
{
    public function index(Request $request)
    {
        $query = InfluencerChannel::with('user')->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }
        if ($request->filled('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('name', 'like', "%{$request->search}%")
                  ->orWhere('url', 'like', "%{$request->search}%");
            });
        }

        $channels = $query->paginate(20)->withQueryString();
        $types    = InfluencerChannel::TYPES;

        return view('admin.influencer.channels.index', compact('channels', 'types'));
    }

    public function approve(InfluencerChannel $channel)
    {
        InfluencerChannelService::approve($channel, auth()->user());
        return back()->with('success', "Kanal \"{$channel->name}\" tasdiqlandi.");
    }

    public function reject(Request $request, InfluencerChannel $channel)
    {
        $request->validate(['reason' => 'required|string|max:500']);
        InfluencerChannelService::reject($channel, auth()->user(), $request->reason);
        return back()->with('success', "Kanal \"{$channel->name}\" rad etildi.");
    }

    public function suspend(InfluencerChannel $channel)
    {
        InfluencerChannelService::suspend($channel, auth()->user());
        return back()->with('success', "Kanal \"{$channel->name}\" bloklandi.");
    }
}
