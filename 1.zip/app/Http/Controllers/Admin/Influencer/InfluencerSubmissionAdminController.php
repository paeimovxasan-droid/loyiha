<?php

namespace App\Http\Controllers\Admin\Influencer;

use App\Http\Controllers\Controller;
use App\Models\Influencer\InfluencerCampaign;
use App\Models\Influencer\InfluencerChannel;
use App\Models\Influencer\InfluencerReward;
use App\Models\Influencer\InfluencerSubmission;
use App\Services\Influencer\InfluencerSubmissionService;
use Illuminate\Http\Request;

class InfluencerSubmissionAdminController extends Controller
{
    public function index(Request $request)
    {
        $query = InfluencerSubmission::with(['user', 'channel', 'campaign', 'screenshot'])->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('campaign_id')) {
            $query->where('campaign_id', $request->campaign_id);
        }
        if ($request->filled('channel_type')) {
            $query->whereHas('channel', fn($q) => $q->where('type', $request->channel_type));
        }

        $submissions  = $query->paginate(20)->withQueryString();
        $campaigns    = InfluencerCampaign::orderBy('name')->get(['id', 'name']);
        $channelTypes = InfluencerChannel::TYPES;

        return view('admin.influencer.submissions.index', compact('submissions', 'campaigns', 'channelTypes'));
    }

    public function approve(InfluencerSubmission $submission)
    {
        try {
            InfluencerSubmissionService::approve($submission, auth()->user());
            return back()->with('success', 'Submission tasdiqlandi va mukofot berildi.');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function reject(Request $request, InfluencerSubmission $submission)
    {
        $request->validate(['reason' => 'required|string|max:500']);
        InfluencerSubmissionService::reject($submission, auth()->user(), $request->reason);
        return back()->with('success', 'Submission rad etildi.');
    }

    public function bulkApprove(Request $request)
    {
        $request->validate(['ids' => 'required|array', 'ids.*' => 'integer']);
        InfluencerSubmissionService::bulkApprove($request->ids, auth()->user());
        return back()->with('success', count($request->ids) . ' ta submission tasdiqlash jarayoni boshlandi.');
    }

    public function stats(Request $request)
    {
        // Publisher reytingi
        $topPublishers = InfluencerReward::with('user')
            ->selectRaw('user_id, SUM(amount) as total_reward, COUNT(*) as total_count')
            ->groupBy('user_id')
            ->orderByDesc('total_reward')
            ->limit(20)
            ->get();

        // Kampaniya samaradorligi
        $campaignStats = InfluencerCampaign::withCount([
            'submissions',
            'submissions as approved_count' => fn($q) => $q->where('status', 'approved'),
            'submissions as rejected_count' => fn($q) => $q->where('status', 'rejected'),
        ])->get();

        // Umumiy statistika
        $totalStats = [
            'total_channels'     => \App\Models\Influencer\InfluencerChannel::count(),
            'approved_channels'  => \App\Models\Influencer\InfluencerChannel::where('status', 'approved')->count(),
            'total_submissions'  => InfluencerSubmission::count(),
            'pending_submissions'=> InfluencerSubmission::where('status', 'pending')->count(),
            'total_spent_ais'    => InfluencerReward::sum('amount'),
            'active_campaigns'   => InfluencerCampaign::where('status', 'active')->count(),
        ];

        return view('admin.influencer.submissions.stats', compact('topPublishers', 'campaignStats', 'totalStats'));
    }
}
