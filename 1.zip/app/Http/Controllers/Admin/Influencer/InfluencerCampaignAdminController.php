<?php

namespace App\Http\Controllers\Admin\Influencer;

use App\Http\Controllers\Controller;
use App\Models\Influencer\InfluencerCampaign;
use App\Models\Influencer\InfluencerChannel;
use App\Services\FileUploadService;
use Illuminate\Http\Request;

class InfluencerCampaignAdminController extends Controller
{
    public function index(Request $request)
    {
        $query = InfluencerCampaign::with('createdBy')->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $campaigns   = $query->paginate(15)->withQueryString();
        $channelTypes = InfluencerChannel::TYPES;

        return view('admin.influencer.campaigns.index', compact('campaigns', 'channelTypes'));
    }

    public function create()
    {
        $channelTypes = InfluencerChannel::TYPES;
        return view('admin.influencer.campaigns.create', compact('channelTypes'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'                        => 'required|string|max:255',
            'description'                 => 'nullable|string',
            'ad_text_uz'                  => 'required|string',
            'ad_text_ru'                  => 'nullable|string',
            'ad_text_en'                  => 'nullable|string',
            'target_url'                  => 'required|url|max:500',
            'reward_amount'               => 'required|numeric|min:0.0001',
            'total_budget'                => 'required|numeric|min:0.0001',
            'target_channel_types'        => 'required|array|min:1',
            'target_channel_types.*'      => 'in:youtube_channel,telegram_channel,telegram_group,telegram_bot',
            'min_subscribers'             => 'nullable|integer|min:0',
            'max_submissions_per_channel' => 'nullable|integer|min:1',
            'starts_at'                   => 'required|date',
            'ends_at'                     => 'required|date|after:starts_at',
            'image'                       => 'nullable|image|max:2048',
        ]);

        $imageId = null;
        if ($request->hasFile('image')) {
            $file    = FileUploadService::upload($request->file('image'), 'influencer/campaigns');
            $imageId = $file->id;
        }

        InfluencerCampaign::create([
            'name'                        => $data['name'],
            'description'                 => $data['description'] ?? null,
            'ad_text'                     => [
                'uz' => $data['ad_text_uz'],
                'ru' => $data['ad_text_ru'] ?? $data['ad_text_uz'],
                'en' => $data['ad_text_en'] ?? $data['ad_text_uz'],
            ],
            'image_id'                    => $imageId,
            'target_url'                  => $data['target_url'],
            'reward_amount'               => $data['reward_amount'],
            'total_budget'                => $data['total_budget'],
            'spent_budget'                => 0,
            'status'                      => InfluencerCampaign::STATUS_ACTIVE,
            'target_channel_types'        => $data['target_channel_types'],
            'min_subscribers'             => $data['min_subscribers'] ?? 0,
            'max_submissions_per_channel' => $data['max_submissions_per_channel'] ?? 1,
            'starts_at'                   => $data['starts_at'],
            'ends_at'                     => $data['ends_at'],
            'created_by'                  => auth()->id(),
        ]);

        return redirect()->route('admin.influencer.campaigns.index')
            ->with('success', 'Kampaniya muvaffaqiyatli yaratildi.');
    }

    public function edit(InfluencerCampaign $campaign)
    {
        $channelTypes = InfluencerChannel::TYPES;
        return view('admin.influencer.campaigns.edit', compact('campaign', 'channelTypes'));
    }

    public function update(Request $request, InfluencerCampaign $campaign)
    {
        $data = $request->validate([
            'name'                        => 'required|string|max:255',
            'description'                 => 'nullable|string',
            'ad_text_uz'                  => 'required|string',
            'ad_text_ru'                  => 'nullable|string',
            'ad_text_en'                  => 'nullable|string',
            'target_url'                  => 'required|url|max:500',
            'reward_amount'               => 'required|numeric|min:0.0001',
            'total_budget'                => 'required|numeric|min:' . $campaign->spent_budget,
            'status'                      => 'required|in:active,paused,completed,cancelled',
            'target_channel_types'        => 'required|array|min:1',
            'min_subscribers'             => 'nullable|integer|min:0',
            'max_submissions_per_channel' => 'nullable|integer|min:1',
            'starts_at'                   => 'required|date',
            'ends_at'                     => 'required|date|after:starts_at',
        ]);

        $campaign->update([
            'name'                        => $data['name'],
            'description'                 => $data['description'] ?? null,
            'ad_text'                     => [
                'uz' => $data['ad_text_uz'],
                'ru' => $data['ad_text_ru'] ?? $data['ad_text_uz'],
                'en' => $data['ad_text_en'] ?? $data['ad_text_uz'],
            ],
            'target_url'                  => $data['target_url'],
            'reward_amount'               => $data['reward_amount'],
            'total_budget'                => $data['total_budget'],
            'status'                      => $data['status'],
            'target_channel_types'        => $data['target_channel_types'],
            'min_subscribers'             => $data['min_subscribers'] ?? 0,
            'max_submissions_per_channel' => $data['max_submissions_per_channel'] ?? 1,
            'starts_at'                   => $data['starts_at'],
            'ends_at'                     => $data['ends_at'],
        ]);

        return redirect()->route('admin.influencer.campaigns.index')
            ->with('success', 'Kampaniya yangilandi.');
    }

    public function destroy(InfluencerCampaign $campaign)
    {
        if ($campaign->submissions()->exists()) {
            return back()->with('error', 'Submissionlari mavjud kampaniyani o\'chirib bo\'lmaydi.');
        }
        $campaign->delete();
        return redirect()->route('admin.influencer.campaigns.index')
            ->with('success', 'Kampaniya o\'chirildi.');
    }
}
