<?php

namespace App\Http\Controllers\Admin\Influencer;

use App\Http\Controllers\Controller;
use App\Models\Influencer\InfluencerReward;
use Illuminate\Http\Request;

class InfluencerRewardAdminController extends Controller
{
    public function index(Request $request)
    {
        $query = InfluencerReward::with(['user', 'campaign', 'channel'])->latest('created_at');

        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }
        if ($request->filled('campaign_id')) {
            $query->where('campaign_id', $request->campaign_id);
        }
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $rewards   = $query->paginate(20)->withQueryString();
        $totalAis  = $query->sum('amount');
        $campaigns = \App\Models\Influencer\InfluencerCampaign::orderBy('name')->get(['id', 'name']);

        return view('admin.influencer.rewards.index', compact('rewards', 'totalAis', 'campaigns'));
    }
}
