<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment\Deposit;
use Illuminate\Http\Request;

class DepositController extends Controller
{
    public function index(Request $request)
    {
        $query = Deposit::query()->with('user', 'paymentMethod')->latest();
        
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        
        $deposits = $query->paginate(15);
        return view('admin.deposits.index', compact('deposits'));
    }

    public function show(Deposit $deposit)
    {
        return view('admin.deposits.show', compact('deposit'));
    }

    public function approve(Request $request, Deposit $deposit)
    {
        if (!$deposit->isPending()) {
            return back()->with('error', 'Siz faqat kutilayotgan to\'lovlarni tasdiqlay olasiz');
        }

        \Illuminate\Support\Facades\DB::transaction(function () use ($deposit, $request) {
            // Lock bilan qayta tekshirish — race condition oldini olish
            $deposit = Deposit::lockForUpdate()->find($deposit->id);

            if (!$deposit->isPending()) {
                throw new \Exception('Bu depozit allaqachon qayta ishlangan.');
            }

            $user = \App\Models\User::lockForUpdate()->find($deposit->user_id);

            if (!$user) {
                $deposit->update(['status' => 'approved', 'approved_at' => now(), 'feedback' => 'User deleted']);
                return;
            }

            $deposit->update([
                'status'       => 'approved',
                'approved_at'  => now(),
                'deposited_at' => now(),
                'feedback'     => $request->feedback ?? null,
            ]);

            $balanceBefore = $user->balance;
            $user->increment('balance', $deposit->final_amount);
            $user->refresh();

            $user->transactions()->create([
                'type'                 => 'deposit',
                'transactionable_type' => Deposit::class,
                'transactionable_id'   => $deposit->id,
                'amount'               => $deposit->final_amount,
                'balance_before'       => $balanceBefore,
                'balance_after'        => $user->balance,
                'direction'            => 'credit',
                'status'               => 'completed',
                'description'          => 'Depozit to\'ldirildi',
            ]);

            $xp = min(20, max(5, (int) ($deposit->final_amount / 50000)));
            \App\Services\XpService::award(
                $user,
                \App\Models\Level\XpLog::ACTION_DEPOSIT,
                $xp,
                'Depozit: ' . number_format($deposit->final_amount) . ' UZS'
            );

            \App\Services\QuestService::updateProgress($user, \App\Models\Game\Quest::REQ_DEPOSIT_COUNT);
            \App\Services\QuestService::updateProgress($user, \App\Models\Game\Quest::REQ_TOTAL_DEPOSIT, (int) $deposit->final_amount);

            try {
                \App\Services\TelegramBotService::notify(
                    $user,
                    "✅ Depozitingiz tasdiqlandi!\n\n💵 Summa: " . number_format($deposit->final_amount) . " UZS\n📊 Yangi balans: " . number_format($user->balance) . " UZS",
                    [[['text' => '💰 Balansni ko\'rish', 'url' => config('app.url') . '/app/deposit']]]
                );
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('Deposit approve notify failed', ['error' => $e->getMessage()]);
            }
        });

        return back()->with('success', 'To\'lov tasdiqlandi, balans to\'ldirildi.');
    }

    public function reject(Request $request, Deposit $deposit)
    {
        if (!$deposit->isPending()) {
            return back()->with('error', 'Faqat kutilayotganlarni bekor qilish mumkin');
        }

        $deposit->update([
            'status' => 'rejected',
            'feedback' => $request->feedback ?? 'Admin tomonidan bekor qilindi'
        ]);

        // Foydalanuvchiga Telegram bildirishnoma
        try {
            \App\Services\TelegramBotService::notify(
                $deposit->user,
                "❌ Depozit so'rovingiz rad etildi.\n\n" .
                "💵 Summa: " . number_format($deposit->amount, 2) . " UZS\n" .
                "📝 Sabab: " . ($request->feedback ?? 'Admin tomonidan bekor qilindi'),
                [[['text' => '💰 Qayta depozit qilish', 'url' => config('app.url') . '/app/deposit']]]
            );
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Deposit reject notify failed', ['error' => $e->getMessage()]);
        }

        return back()->with('success', 'To\'lov rad etildi');
    }
}
