<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\FileUploadService;
use Illuminate\Http\Request;

class FileUploadController extends Controller
{
    /**
     * AJAX orqali rasm yuklash va file ID qaytarish.
     * 
     * POST /admin/upload
     * Field: file (image)
     * Response: { id, url }
     */
    public function upload(Request $request)
    {
        $request->validate([
            'file'   => 'required|image|max:10240',
            'folder' => 'nullable|string|max:50',
        ]);

        $folder = $request->input('folder', 'uploads');

        // Faqat ruxsat etilgan papkalar
        $allowedFolders = ['settings', 'packages', 'payment-methods', 'uploads'];
        if (!in_array($folder, $allowedFolders)) {
            $folder = 'uploads';
        }

        try {
            $file = FileUploadService::upload($request->file('file'), $folder);

            return response()->json([
                'success' => true,
                'id'      => $file->id,
                'url'     => $file->url,
                'name'    => $file->name,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Fayl yuklanmadi: ' . $e->getMessage(),
            ], 422);
        }
    }
}
