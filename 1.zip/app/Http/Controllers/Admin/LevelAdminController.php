<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Level\LevelConfig;
use App\Models\Level\UserLevel;
use App\Models\Level\XpLog;

class LevelAdminController extends Controller
{
    public function index()
    {
        $configs = LevelConfig::orderBy('level')->get();

        $stats = [
            'total_xp_awarded' => XpLog::sum('xp'),
            'avg_level'        => round(UserLevel::avg('level') ?? 0, 1),
            'max_level'        => UserLevel::max('level') ?? 0,
            'level_dist'       => UserLevel::selectRaw('level, count(*) as cnt')
                ->groupBy('level')->orderBy('level')->get(),
        ];

        return view('admin.levels.index', compact('configs', 'stats'));
    }

    public function leaderboard()
    {
        $users = UserLevel::with('user')
            ->orderByDesc('total_xp')
            ->paginate(50);

        return view('admin.levels.leaderboard', compact('users'));
    }
}
