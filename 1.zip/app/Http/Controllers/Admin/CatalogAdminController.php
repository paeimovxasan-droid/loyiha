<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Catalog\Shop;
use App\Models\Catalog\Product;
use Illuminate\Http\Request;

class CatalogAdminController extends Controller
{
    public function shops(Request $request)
    {
        try {
            $query = Shop::with('user:id,name,username')->latest();
            if ($request->filled('status')) {
                $query->where('status', $request->status);
            }
            $shops = $query->paginate(20);
            return view('admin.catalog.shops', compact('shops'));
        } catch (\Throwable $e) {
            return back()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }

    public function products(Request $request)
    {
        try {
            $query = Product::with('shop')->latest();
            if ($request->filled('status')) {
                $query->where('status', $request->status);
            }
            $products = $query->paginate(20);
            return view('admin.catalog.products', compact('products'));
        } catch (\Throwable $e) {
            return back()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }

    public function editShop(Shop $shop)
    {
        $shop->load('user:id,name,username');
        return view('admin.catalog.edit_shop', compact('shop'));
    }

    public function updateShop(Request $request, Shop $shop)
    {
        $request->validate([
            'name'        => 'required|string|max:255',
            'description' => 'nullable|string',
            'status'      => 'required|in:active,pending,suspended',
        ]);

        $shop->update($request->only('name', 'description', 'status'));

        return redirect()->route('admin.catalog.shops')->with('success', 'Do\'kon muvaffaqiyatli yangilandi.');
    }

    public function editProduct(Product $product)
    {
        $product->load('shop');
        $shops = Shop::orderBy('name')->get(['id', 'name']);
        return view('admin.catalog.edit_product', compact('product', 'shops'));
    }

    public function updateProduct(Request $request, Product $product)
    {
        $request->validate([
            'name'        => 'required|string|max:255',
            'description' => 'nullable|string',
            'price'       => 'required|numeric|min:0',
            'status'      => 'required|in:active,out_of_stock,pending',
            'shop_id'     => 'required|exists:shops,id',
        ]);

        $product->update($request->only('name', 'description', 'price', 'status', 'shop_id'));

        return redirect()->route('admin.catalog.products')->with('success', 'Mahsulot muvaffaqiyatli yangilandi.');
    }

    public function destroyProduct(Product $product)
    {
        $product->delete();
        return redirect()->route('admin.catalog.products')->with('success', 'Mahsulot o\'chirildi.');
    }
}
