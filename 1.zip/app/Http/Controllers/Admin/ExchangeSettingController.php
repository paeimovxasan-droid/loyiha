<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Exchange\ExchangeOrder;
use App\Models\Exchange\ExchangeSetting;
use App\Models\Exchange\ExchangeTrade;
use Illuminate\Http\Request;

class ExchangeSettingController extends Controller
{

    /**
     * GET admin/exchange/settings — Sozlamalarni ko'rish
     */
    public function index()
    {
        $settings = ExchangeSetting::all()->pluck('value', 'key');

        return view('admin.exchange.settings', compact('settings'));
    }

    /**
     * PUT admin/exchange/settings — Sozlamalarni yangilash
     */
    public function update(Request $request)
    {
        $data = $request->validate([
            'maker_fee_percent' => 'nullable|numeric|min:0|max:5',
            'taker_fee_percent' => 'nullable|numeric|min:0|max:5',
            'min_order_amount'  => 'nullable|numeric|min:0.0001',
            'max_order_amount'  => 'nullable|numeric|min:1',
            'min_order_price'   => 'nullable|numeric|min:0.01',
            'max_order_price'   => 'nullable|numeric|min:1',
            'is_maintenance'    => 'nullable|in:true,false',
        ]);

        foreach ($data as $key => $value) {
            if ($value !== null) {
                ExchangeSetting::set($key, (string) $value);
            }
        }

        return back()->with('success', 'Birja sozlamalari yangilandi.');
    }

    /**
     * GET admin/exchange/stats — Birja statistikasi
     */
    public function stats()
    {
        $since24h = now()->subDay();

        $volume24h = ExchangeTrade::where('created_at', '>=', $since24h)->sum('total');
        $totalFees = ExchangeTrade::where('created_at', '>=', $since24h)
            ->selectRaw('SUM(buyer_fee + seller_fee) as total_fees')
            ->value('total_fees') ?? 0;
        $activeUsers = ExchangeOrder::where('created_at', '>=', $since24h)
            ->distinct('user_id')
            ->count('user_id');
        $totalOrders = ExchangeOrder::where('created_at', '>=', $since24h)->count();
        $totalTrades = ExchangeTrade::where('created_at', '>=', $since24h)->count();

        return view('admin.exchange.stats', compact('volume24h', 'totalFees', 'activeUsers', 'totalOrders', 'totalTrades'));
    }

    /**
     * GET admin/exchange/orders — Buyurtmalar ro'yxati
     */
    public function orders(Request $request)
    {
        $query = ExchangeOrder::with('user:id,name,username')
            ->orderByDesc('created_at');

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }
        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }

        $orders = $query->paginate(20);

        return view('admin.exchange.orders', compact('orders'));
    }

    /**
     * GET admin/exchange/trades — Savdolar ro'yxati
     */
    public function trades(Request $request)
    {
        $query = ExchangeTrade::with(['buyer:id,name,username', 'seller:id,name,username'])
            ->orderByDesc('created_at');

        if ($request->filled('user_id')) {
            $query->where(function ($q) use ($request) {
                $q->where('buyer_id', $request->user_id)
                  ->orWhere('seller_id', $request->user_id);
            });
        }
        if ($request->filled('from')) {
            $query->where('created_at', '>=', $request->from);
        }
        if ($request->filled('to')) {
            $query->where('created_at', '<=', $request->to);
        }

        $trades = $query->paginate(20);

        return view('admin.exchange.trades', compact('trades'));
    }
}
