<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Game\Task;
use App\Models\Game\UserTask;
use App\Services\XpService;
use App\Models\Level\XpLog;
use Illuminate\Http\Request;

class TaskAdminController extends Controller
{
    public function index(Request $request)
    {
        // Topshiriqlar ro'yxati (Task modeli)
        $tasks = Task::orderBy('sort_order')->get();

        // Foydalanuvchi yuborishlari (UserTask)
        $query = UserTask::with('user', 'task')->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        } else {
            $query->orderByRaw("CASE status WHEN 'pending' THEN 1 WHEN 'rejected' THEN 2 WHEN 'approved' THEN 3 ELSE 4 END");
        }

        $submissions = $query->paginate(20)->withQueryString();

        $stats = [
            'pending'  => UserTask::where('status', 'pending')->count(),
            'approved' => UserTask::where('status', 'approved')->count(),
            'rejected' => UserTask::where('status', 'rejected')->count(),
            'total_tasks' => Task::count(),
        ];

        return view('admin.tasks.index', compact('tasks', 'submissions', 'stats'));
    }

    public function create()
    {
        return view('admin.tasks.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title'                  => 'required|array',
            'title.uz'               => 'required|string|max:255',
            'title.ru'               => 'nullable|string|max:255',
            'title.en'               => 'nullable|string|max:255',
            'description'            => 'nullable|array',
            'description.uz'         => 'nullable|string',
            'description.ru'         => 'nullable|string',
            'description.en'         => 'nullable|string',
            'link'                   => 'nullable|url|max:500',
            'platform'               => 'nullable|string|max:50',
            'reward'                 => 'required|numeric|min:0',
            'required_package_level' => 'required|integer|min:0',
            'sort_order'             => 'required|integer|min:0',
            'status'                 => 'required|in:active,inactive',
        ]);

        Task::create($data);

        return redirect()->route('admin.tasks.index')->with('success', 'Topshiriq yaratildi.');
    }

    public function edit(Task $task)
    {
        return view('admin.tasks.edit', compact('task'));
    }

    public function update(Request $request, Task $task)
    {
        $data = $request->validate([
            'title'                  => 'required|array',
            'title.uz'               => 'required|string|max:255',
            'title.ru'               => 'nullable|string|max:255',
            'title.en'               => 'nullable|string|max:255',
            'description'            => 'nullable|array',
            'description.uz'         => 'nullable|string',
            'description.ru'         => 'nullable|string',
            'description.en'         => 'nullable|string',
            'link'                   => 'nullable|url|max:500',
            'platform'               => 'nullable|string|max:50',
            'reward'                 => 'required|numeric|min:0',
            'required_package_level' => 'required|integer|min:0',
            'sort_order'             => 'required|integer|min:0',
            'status'                 => 'required|in:active,inactive',
        ]);

        $task->update($data);

        return redirect()->route('admin.tasks.index')->with('success', 'Topshiriq yangilandi.');
    }

    public function destroy(Task $task)
    {
        $task->delete();
        return back()->with('success', 'Topshiriq o\'chirildi.');
    }

    public function approve(UserTask $userTask)
    {
        if ($userTask->status !== 'pending') {
            return back()->with('error', 'Faqat kutilayotganlarni tasdiqlash mumkin.');
        }

        $userTask->update(['status' => 'approved']);

        $user   = $userTask->user;
        if (!$user) {
            return back()->with('warning', 'Topshiriq tasdiqlandi, lekin foydalanuvchi topilmadi.');
        }

        $reward = $userTask->task?->reward ?? 0;

        if ($reward > 0) {
            $user->increment('balance', $reward);
        }

        XpService::award($user, XpLog::ACTION_TASK, 15,
            'Topshiriq tasdiqlandi: ' . $userTask->task?->getTranslation('title', 'uz'), $userTask);

        \App\Services\QuestService::updateProgress($user, \App\Models\Game\Quest::REQ_TASK_COMPLETE);

        return back()->with('success', "Topshiriq tasdiqlandi. +{$reward} UZS va +50 XP berildi.");
    }

    public function reject(UserTask $userTask)
    {
        if ($userTask->status !== 'pending') {
            return back()->with('error', 'Faqat kutilayotganlarni rad etish mumkin.');
        }

        $userTask->update(['status' => 'rejected']);

        return back()->with('success', 'Topshiriq rad etildi.');
    }
}
