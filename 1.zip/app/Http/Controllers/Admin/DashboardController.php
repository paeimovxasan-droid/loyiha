<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment\Deposit;
use App\Models\Payment\Withdrawal;
use App\Models\Package\Purchase;
use App\Models\Finance\Transaction;
use App\Models\Exchange\ExchangeTrade;
use App\Models\Security\AuditLog;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index()
    {
        try {
        $stats = [
            'total_users'              => User::count(),
            'active_users'             => User::active()->count(),
            'new_users_today'          => User::whereDate('created_at', today())->count(),
            'new_users_week'           => User::where('created_at', '>=', now()->subWeek())->count(),

            'pending_deposits'         => Deposit::pending()->count(),
            'pending_withdrawals'      => Withdrawal::pending()->count(),
            'total_deposits_amount'    => Deposit::where('status', 'approved')->sum('final_amount'),
            'total_withdrawals_amount' => Withdrawal::where('status', 'approved')->sum('final_amount'),
            'today_deposits'           => Deposit::where('status', 'approved')->whereDate('created_at', today())->sum('final_amount'),

            'active_purchases'         => Purchase::active()->count(),

            // AIS statistika
            'total_ais_supply'         => \App\Models\AIS\Wallet::sum('balance'),
            'total_transfers_today'    => \App\Models\AIS\AisTransfer::whereDate('created_at', today())->where('status', 'completed')->count(),
            'total_transfers_volume'   => \App\Models\AIS\AisTransfer::where('status', 'completed')->sum('amount'),
            'ais_rate'                 => \App\Models\AIS\AisRate::current()?->rate_uzs ?? 0,

            // Level statistika
            'avg_level'                => round(\App\Models\Level\UserLevel::avg('level') ?? 0, 1),
            'total_xp_awarded'         => \App\Models\Level\XpLog::sum('xp'),
            'top_level_user'           => \App\Models\Level\UserLevel::with('user')->orderByDesc('level')->first(),

            // KYC va Tasks
            'pending_kyc'              => \App\Models\User::whereIn('kyc_status', ['passport_pending', 'face_pending'])->count(),
            'pending_tasks'            => \App\Models\Game\UserTask::where('status', 'pending')->count(),

            // Yangi modullar
            'pending_crowdfunding'     => \App\Models\Crowdfunding\CfProject::where('status', 'pending')->count(),
            'active_crowdfunding'      => \App\Models\Crowdfunding\CfProject::where('status', 'active')->count(),
            'total_courses'            => \App\Models\Education\Course::count(),
            'total_shops'              => \App\Models\Catalog\Shop::where('status', 'active')->count(),
            'active_credits'           => \App\Models\Credit\Credit::whereIn('status', ['active', 'pending'])->count(),
            'active_gigs'              => \App\Models\GigEconomy\GigListing::where('status', 'open')->count(),
            'active_loans'             => \App\Models\Lending\Loan::where('status', 'active')->count(),

            // ─── Professional Financial Intelligence (Phase 11) ───
            'revenue_withdrawals'      => (float) Withdrawal::where('status', 'approved')->sum('charge'),
            'revenue_packages'         => (float) Purchase::where('status', 'active')->sum('amount'),
            'exchange_volume_24h'      => (float) ExchangeTrade::where('created_at', '>=', now()->subDay())->sum('total'),
            'exchange_fees_total'      => (float) ExchangeTrade::sum(DB::raw('buyer_fee + seller_fee')),
            
            // Xavfsizlik stats
            'critical_audit_logs'      => AuditLog::whereIn('action', ['withdrawal_requested', '2fa_disabled', 'kyc_rejected'])->count(),
            'total_2fa_users'          => User::where('two_fa_enabled', true)->count(),
            
            // Retention
            'active_last_24h'          => User::where('updated_at', '>=', now()->subDay())->count(),
        ];

        $userChart = collect(range(6, 0))->map(fn($i) => [
            'date'  => now()->subDays($i)->format('d M'),
            'count' => User::whereDate('created_at', now()->subDays($i))->count(),
        ]);

        $recentTransactions = Transaction::with('user')->latest()->take(10)->get();
        $recentUsers        = User::with('roles')->latest()->take(8)->get();

        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('Dashboard error: ' . $e->getMessage());
            $stats = array_fill_keys([
                'total_users','active_users','new_users_today','new_users_week',
                'pending_deposits','pending_withdrawals','total_deposits_amount',
                'total_withdrawals_amount','today_deposits','active_purchases',
                'total_ais_supply','total_transfers_today','total_transfers_volume',
                'ais_rate','avg_level','total_xp_awarded','pending_kyc','pending_tasks',
                'pending_crowdfunding','active_crowdfunding','total_courses','total_shops',
                'active_credits','active_gigs','active_loans','revenue_withdrawals',
                'revenue_packages','exchange_volume_24h','exchange_fees_total',
                'critical_audit_logs','total_2fa_users','active_last_24h',
            ], 0);
            $stats['top_level_user'] = null;
            $userChart = collect();
            $recentTransactions = collect();
            $recentUsers = collect();
        }

        return view('admin.dashboard.index', compact(
            'stats', 'userChart', 'recentTransactions', 'recentUsers'
        ));
    }
}
