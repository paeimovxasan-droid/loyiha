<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AIS\AisRate;
use App\Models\AIS\AisTransfer;
use App\Models\AIS\Wallet;
use App\Models\Setting;
use Illuminate\Http\Request;

class AisController extends Controller
{
    public function rate()
    {
        $current  = AisRate::current();
        $history  = AisRate::latest()->limit(10)->get();
        $setting  = Setting::get();
        return view('admin.ais.rate', compact('current', 'history', 'setting'));
    }

    public function updateRate(Request $request)
    {
        $data = $request->validate([
            'rate_uzs'  => 'required|numeric|min:1',
            'buy_rate'  => 'required|numeric|min:1',
            'sell_rate' => 'required|numeric|min:1|lte:buy_rate',
        ]);

        // Eski kursni o'chirish
        AisRate::where('is_active', true)->update(['is_active' => false]);

        AisRate::create(array_merge($data, [
            'set_by'    => auth()->id(),
            'is_active' => true,
        ]));

        // Settings ni ham yangilash
        Setting::get()->update(['ais_to_uzs_rate' => $data['rate_uzs']]);
        \Illuminate\Support\Facades\Cache::forget('app_settings');

        return back()->with('success', 'AIS kursi yangilandi: 1 AIS = ' . number_format($data['rate_uzs']) . ' UZS');
    }

    public function wallets(Request $request)
    {
        $query = Wallet::with('user')->latest();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('wallet_number', 'like', "%{$s}%")
                  ->orWhereHas('user', fn($u) => $u->where('name', 'like', "%{$s}%")
                      ->orWhere('username', 'like', "%{$s}%"));
            });
        }

        $wallets = $query->paginate(20)->withQueryString();
        $totalAis = Wallet::sum('balance');

        return view('admin.ais.wallets', compact('wallets', 'totalAis'));
    }

    public function transfers(Request $request)
    {
        $query = AisTransfer::with('sender', 'receiver')->latest();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('reference', 'like', "%{$s}%")
                  ->orWhereHas('sender', fn($u) => $u->where('username', 'like', "%{$s}%"))
                  ->orWhereHas('receiver', fn($u) => $u->where('username', 'like', "%{$s}%"));
            });
        }

        $transfers  = $query->paginate(20)->withQueryString();
        $totalVolume = AisTransfer::where('status', 'completed')->sum('amount');

        return view('admin.ais.transfers', compact('transfers', 'totalVolume'));
    }
}
