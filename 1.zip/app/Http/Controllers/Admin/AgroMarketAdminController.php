<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AgroMarket\AgroListing;
use App\Models\AgroMarket\AgroOrder;
use Illuminate\Http\Request;

class AgroMarketAdminController extends Controller
{
    public function listings(Request $request)
    {
        $query = AgroListing::with('user:id,name,username')->latest();
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        $listings = $query->paginate(20);
        return view('admin.agromarket.listings', compact('listings'));
    }

    public function orders(Request $request)
    {
        $query = AgroOrder::with(['listing', 'buyer:id,name,username'])->latest();
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        $orders = $query->paginate(20);
        return view('admin.agromarket.orders', compact('orders'));
    }

    public function editListing(AgroListing $listing)
    {
        $listing->load('user:id,name,username');
        return view('admin.agromarket.edit_listing', compact('listing'));
    }

    public function updateListing(Request $request, AgroListing $listing)
    {
        $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string',
            'price'       => 'required|numeric|min:0',
            'status'      => 'required|in:active,sold,expired',
        ]);

        $listing->update($request->only('title', 'description', 'price', 'status'));

        return redirect()->route('admin.agromarket.listings')->with('success', 'E\'lon muvaffaqiyatli yangilandi.');
    }

    public function destroyListing(AgroListing $listing)
    {
        $listing->delete();
        return back()->with('success', 'E\'lon o\'chirildi.');
    }
}
