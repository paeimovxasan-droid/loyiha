<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Level\UserLevel;
use App\Models\User;
use Illuminate\Http\Request;

class LeaderController extends Controller
{
    public function index(Request $request)
    {
        $query = User::with(['userLevel', 'roles'])
            ->whereHas('roles', fn($r) => $r->where('name', 'user'))
            ->withCount(['referrals', 'purchases'])
            ->latest();

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(fn($q) => $q
                ->where('name', 'like', "%{$s}%")
                ->orWhere('username', 'like', "%{$s}%")
                ->orWhere('email', 'like', "%{$s}%")
            );
        }

        if ($request->filled('filter')) {
            match ($request->filter) {
                'leaders'  => $query->where('is_leader', true),
                'top_xp'   => $query->orderByDesc(
                    UserLevel::select('total_xp')
                        ->whereColumn('user_id', 'users.id')
                        ->limit(1)
                ),
                default => null,
            };
        }

        $users = $query->paginate(20)->withQueryString();

        // Statistika
        $stats = [
            'total_leaders'  => User::where('is_leader', true)->count(),
            'total_users'    => User::whereHas('roles', fn($r) => $r->where('name', 'user'))->count(),
            'top_level'      => UserLevel::max('level') ?? 0,
            'total_xp'       => UserLevel::sum('total_xp'),
        ];

        return view('admin.leaders.index', compact('users', 'stats'));
    }

    public function toggle(User $user)
    {
        $user->update(['is_leader' => !$user->is_leader]);
        $msg = $user->is_leader ? "{$user->name} lider sifatida belgilandi." : "{$user->name} liderlikdan olib tashlandi.";
        return back()->with('success', $msg);
    }

    public function tree(User $user)
    {
        // 3 darajali referral daraxti
        $tree = $this->buildTree($user, 3);

        $stats = [
            'level1_count' => $user->referrals()->count(),
            'level2_count' => $user->referrals()->withCount('referrals')->get()->sum('referrals_count'),
            'total_team'   => $this->countTeam($user, 3),
            'user_level'   => $user->userLevel?->level ?? 0,
            'total_xp'     => $user->userLevel?->total_xp ?? 0,
        ];

        return view('admin.leaders.tree', compact('user', 'tree', 'stats'));
    }

    private function buildTree(User $user, int $depth): array
    {
        if ($depth === 0) return [];

        $referrals = $user->referrals()->with('userLevel')->get();

        return $referrals->map(function ($ref) use ($depth) {
            return [
                'user'     => $ref,
                'children' => $this->buildTree($ref, $depth - 1),
            ];
        })->toArray();
    }

    private function countTeam(User $user, int $depth): int
    {
        if ($depth === 0) return 0;

        // Bir query da barcha referrallarni olish
        $referrals = $user->referrals()->select('id', 'username')->get();
        $count = $referrals->count();

        if ($depth > 1) {
            foreach ($referrals as $ref) {
                $count += $this->countTeam($ref, $depth - 1);
            }
        }

        return $count;
    }
}
