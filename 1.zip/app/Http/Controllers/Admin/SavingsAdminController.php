<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Savings\SavingsPlan;
use Illuminate\Http\Request;

class SavingsAdminController extends Controller
{
    public function index(Request $request)
    {
        try {
            $query = SavingsPlan::with('user:id,name,username')->latest();
            if ($request->filled('status')) {
                $query->where('status', $request->status);
            }
            $plans = $query->paginate(20);
            return view('admin.savings.index', compact('plans'));
        } catch (\Throwable $e) {
            return back()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }

    public function edit(SavingsPlan $saving)
    {
        $saving->load('user:id,name,username');
        return view('admin.savings.edit', ['plan' => $saving]);
    }

    public function update(Request $request, SavingsPlan $saving)
    {
        $request->validate([
            'term_months'    => 'required|integer|min:1',
            'monthly_amount' => 'required|numeric|min:0',
            'status'         => 'required|in:active,completed,cancelled',
        ]);

        $saving->update($request->only('term_months', 'monthly_amount', 'status'));

        return redirect()->route('admin.savings.index')->with('success', 'Jamg\'arma reja muvaffaqiyatli yangilandi.');
    }
}
