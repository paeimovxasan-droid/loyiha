<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Marketplace\Gig;
use Illuminate\Http\Request;

class MarketplaceAdminController extends Controller
{
    public function index(Request $request)
    {
        try {
            $query = Gig::with('user')->latest();
            if ($request->filled('status')) {
                $query->where('status', $request->status);
            }
            $gigs = $query->paginate(20);
            return view('admin.marketplace.index', compact('gigs'));
        } catch (\Throwable $e) {
            return back()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }

    public function create()
    {
        return view('admin.marketplace.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string',
            'price'       => 'required|numeric|min:0',
            'status'      => 'required|in:active,pending,paused,rejected',
            'user_id'     => 'required|exists:users,id',
        ]);

        Gig::create($request->only('title', 'description', 'price', 'status', 'user_id'));

        return redirect()->route('admin.marketplace.index')->with('success', 'Gig muvaffaqiyatli yaratildi.');
    }

    public function edit(Gig $marketplace)
    {
        $marketplace->load('user');
        return view('admin.marketplace.edit', ['gig' => $marketplace]);
    }

    public function update(Request $request, Gig $marketplace)
    {
        $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string',
            'price'       => 'required|numeric|min:0',
            'status'      => 'required|in:active,pending,paused,rejected',
        ]);

        $marketplace->update($request->only('title', 'description', 'price', 'status'));

        return redirect()->route('admin.marketplace.index')->with('success', 'Gig muvaffaqiyatli yangilandi.');
    }

    public function destroy(Gig $marketplace)
    {
        $marketplace->delete();
        return redirect()->route('admin.marketplace.index')->with('success', 'Gig o\'chirildi.');
    }
}
