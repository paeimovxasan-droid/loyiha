<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\RoadmapModule;
use App\Services\RoadmapService;
use Illuminate\Http\Request;

class RoadmapController extends Controller
{
    public function index()
    {
        $modules = RoadmapModule::active()->get();

        return view('admin.roadmap.index', compact('modules'));
    }

    public function create()
    {
        return view('admin.roadmap.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'title'            => 'required|string|max:255',
            'description'      => 'required|string',
            'icon'             => 'nullable|string|max:255',
            'status'           => 'required|in:coming_soon,in_progress,beta,released',
            'sort_order'       => 'required|integer|min:0',
            'estimated_date'   => 'nullable|date',
            'banner_image'     => 'nullable|string|max:255',
            'progress_percent' => 'nullable|integer|min:0|max:100',
        ]);

        RoadmapModule::create($data);

        return redirect()->route('admin.roadmap.index')->with('success', 'Modul yaratildi.');
    }

    public function edit(RoadmapModule $roadmap)
    {
        return view('admin.roadmap.edit', ['module' => $roadmap]);
    }

    public function update(Request $request, RoadmapModule $roadmap)
    {
        $data = $request->validate([
            'title'            => 'required|string|max:255',
            'description'      => 'required|string',
            'icon'             => 'nullable|string|max:255',
            'status'           => 'required|in:coming_soon,in_progress,beta,released',
            'sort_order'       => 'required|integer|min:0',
            'estimated_date'   => 'nullable|date',
            'banner_image'     => 'nullable|string|max:255',
            'progress_percent' => 'nullable|integer|min:0|max:100',
        ]);

        $oldStatus = $roadmap->status;
        $roadmap->update($data);

        // Holat o'zgarishini aniqlash
        if ($oldStatus !== $data['status']) {
            RoadmapService::onStatusChange($roadmap, $oldStatus, $data['status']);
        }

        return redirect()->route('admin.roadmap.index')->with('success', 'Modul yangilandi.');
    }

    public function destroy(RoadmapModule $roadmap)
    {
        $roadmap->delete();

        return back()->with('success', "Modul o'chirildi.");
    }
}
