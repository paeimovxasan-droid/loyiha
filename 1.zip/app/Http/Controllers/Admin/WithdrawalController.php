<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment\Withdrawal;
use Illuminate\Http\Request;

class WithdrawalController extends Controller
{
    public function index(Request $request)
    {
        $query = Withdrawal::query()->with('user', 'paymentMethod')->latest();
        
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        
        $withdrawals = $query->paginate(15);
        return view('admin.withdrawals.index', compact('withdrawals'));
    }

    public function show(Withdrawal $withdrawal)
    {
        return view('admin.withdrawals.show', compact('withdrawal'));
    }

    public function approve(Request $request, Withdrawal $withdrawal)
    {
        if (!$withdrawal->isPending()) {
            return back()->with('error', 'Siz faqat kutilayotgan so\'rovlarni tasdiqlay olasiz');
        }

        $withdrawal->update([
            'status' => 'approved',
            'approved_at' => now(),
            'feedback' => $request->feedback ?? null
        ]);

        // Front da allaqachon balansdan yechilgan va transaction yozilgan
        if ($withdrawal->user) {
            $withdrawal->user->transactions()
                ->where('transactionable_type', Withdrawal::class)
                ->where('transactionable_id', $withdrawal->id)
                ->where('status', 'pending')
                ->update(['status' => 'completed']);

            // Foydalanuvchiga Telegram bildirishnoma
            try {
                \App\Services\TelegramBotService::notify(
                    $withdrawal->user,
                    "✅ Yechim so'rovingiz tasdiqlandi!\n\n" .
                    "💵 Summa: " . number_format($withdrawal->final_amount, 2) . " UZS\n" .
                    "📲 " . ($withdrawal->method_name ?? '') . " ga o'tkazildi.",
                    [[['text' => '📊 Tranzaksiyalarni ko\'rish', 'url' => config('app.url') . '/app/transactions']]]
                );
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('Withdrawal approve notify failed', ['error' => $e->getMessage()]);
            }

            // Kanalga to'lov cheki yuborish
            try {
                \App\Services\TelegramBotService::sendWithdrawalReceiptToChannel($withdrawal);
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('Withdrawal channel receipt failed', ['error' => $e->getMessage()]);
            }
        }

        return back()->with('success', 'Yechib olish tasdiqlandi');
    }

    public function reject(Request $request, Withdrawal $withdrawal)
    {
        if (!$withdrawal->isPending()) {
            return back()->with('error', 'Faqat kutilayotganlarni bekor qilish mumkin');
        }

        $user = $withdrawal->user;

        if (!$user) {
            $withdrawal->update([
                'status'   => 'rejected',
                'feedback' => $request->feedback ?? 'Admin tomonidan bekor qilindi (foydalanuvchi topilmadi)',
            ]);
            return back()->with('success', 'Yechib olish rad etildi (foydalanuvchi topilmadi, pul qaytarilmadi)');
        }

        \Illuminate\Support\Facades\DB::transaction(function () use ($withdrawal, $user, $request) {
            // Lock bilan qayta tekshirish
            $withdrawal = Withdrawal::lockForUpdate()->find($withdrawal->id);

            if (!$withdrawal->isPending()) {
                throw new \Exception('Bu yechim allaqachon qayta ishlangan.');
            }

            $user = \App\Models\User::lockForUpdate()->find($user->id);

            $withdrawal->update([
                'status'   => 'rejected',
                'feedback' => $request->feedback ?? 'Admin tomonidan bekor qilindi',
            ]);

            if (!$user) {
                return; // User o'chirilgan, pul qaytarib bo'lmaydi
            }

            $balanceBefore = $user->balance;

            // Pulni qaytarish
            $user->increment('balance', $withdrawal->amount);
            $user->refresh();

            // Oldingi pending transaction ni reversed ga o'zgartirish
            $user->transactions()
                ->where('transactionable_type', Withdrawal::class)
                ->where('transactionable_id', $withdrawal->id)
                ->where('status', 'pending')
                ->update(['status' => 'reversed']);

            // Qaytarish transaction yozish
            $user->transactions()->create([
                'type'                  => 'withdraw',
                'transactionable_type'  => Withdrawal::class,
                'transactionable_id'    => $withdrawal->id,
                'amount'                => $withdrawal->amount,
                'balance_before'        => $balanceBefore,
                'balance_after'         => $user->balance,
                'direction'             => 'credit',
                'status'                => 'reversed',
                'description'           => 'Yechib olish bekor qilindi (Pul qaytarildi)',
            ]);
        });

        // Foydalanuvchiga Telegram bildirishnoma
        try {
            \App\Services\TelegramBotService::notify(
                $user,
                "❌ Yechim so'rovingiz rad etildi.\n\n" .
                "💵 Summa: " . number_format($withdrawal->amount, 2) . " UZS\n" .
                "📝 Sabab: " . ($request->feedback ?? 'Admin tomonidan bekor qilindi') . "\n\n" .
                "Pul balansingizga qaytarildi.",
                [[['text' => '💰 Balansni ko\'rish', 'url' => config('app.url') . '/app/deposit']]]
            );
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Withdrawal reject notify failed', ['error' => $e->getMessage()]);
        }

        return back()->with('success', 'Yechib olish so\'rovi rad etildi va pul balansga qaytarildi');
    }
}
