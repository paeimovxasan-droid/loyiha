<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Investment\Fund;
use Illuminate\Http\Request;

class FundAdminController extends Controller
{
    public function index()
    {
        $funds = Fund::orderBy('sort_order')->paginate(15);
        return view('admin.funds.index', compact('funds'));
    }

    public function create()
    {
        return view('admin.funds.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name'               => 'required|array',
            'name.uz'            => 'required|string|max:255',
            'name.ru'            => 'nullable|string|max:255',
            'name.en'            => 'nullable|string|max:255',
            'description'        => 'nullable|array',
            'commission_percent' => 'required|numeric|min:0|max:100',
            'validity_days'      => 'required|integer|min:1',
            'min_invest'         => 'required|numeric|min:0',
            'sort_order'         => 'required|integer|min:0',
            'status'             => 'required|in:active,inactive',
        ]);

        Fund::create($data);
        return redirect()->route('admin.funds.index')->with('success', 'Fond yaratildi.');
    }

    public function edit(Fund $fund)
    {
        return view('admin.funds.edit', compact('fund'));
    }

    public function update(Request $request, Fund $fund)
    {
        $data = $request->validate([
            'name'               => 'required|array',
            'name.uz'            => 'required|string|max:255',
            'name.ru'            => 'nullable|string|max:255',
            'name.en'            => 'nullable|string|max:255',
            'description'        => 'nullable|array',
            'commission_percent' => 'required|numeric|min:0|max:100',
            'validity_days'      => 'required|integer|min:1',
            'min_invest'         => 'required|numeric|min:0',
            'sort_order'         => 'required|integer|min:0',
            'status'             => 'required|in:active,inactive',
        ]);

        $fund->update($data);
        return redirect()->route('admin.funds.index')->with('success', 'Fond yangilandi.');
    }

    public function destroy(Fund $fund)
    {
        $fund->delete();
        return back()->with('success', 'Fond o\'chirildi.');
    }
}
