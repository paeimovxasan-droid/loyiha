<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Education\Course;
use Illuminate\Http\Request;

class EducationAdminController extends Controller
{
    public function index(Request $request)
    {
        try {
            $query = Course::with('user:id,name,username')->latest();
            if ($request->filled('status')) {
                $query->where('status', $request->status);
            }
            $courses = $query->paginate(20);
            return view('admin.education.index', compact('courses'));
        } catch (\Throwable $e) {
            return back()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }

    public function edit(Course $education)
    {
        $education->load('user:id,name,username');
        return view('admin.education.edit', ['course' => $education]);
    }

    public function update(Request $request, Course $education)
    {
        $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string',
            'price'       => 'required|numeric|min:0',
            'status'      => 'required|in:draft,published,archived',
        ]);

        $education->update($request->only('title', 'description', 'price', 'status'));

        return redirect()->route('admin.education.index')->with('success', 'Kurs muvaffaqiyatli yangilandi.');
    }

    public function destroy(Course $education)
    {
        $education->delete();
        return redirect()->route('admin.education.index')->with('success', 'Kurs o\'chirildi.');
    }
}
