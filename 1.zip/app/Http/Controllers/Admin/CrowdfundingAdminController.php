<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Crowdfunding\CfProject;
use App\Services\CrowdfundingService;
use Illuminate\Http\Request;

class CrowdfundingAdminController extends Controller
{
    /**
     * Barcha loyihalar ro'yxati (status filter)
     */
    public function index(Request $request)
    {
        $query = CfProject::with('user:id,name,username')->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $projects = $query->paginate(15);

        return view('admin.crowdfunding.index', compact('projects'));
    }

    /**
     * Loyihani tasdiqlash
     */
    public function approve(CfProject $project)
    {
        CrowdfundingService::approveProject($project);

        return back()->with('success', 'Loyiha tasdiqlandi.');
    }

    /**
     * Loyihani rad etish
     */
    public function reject(Request $request, CfProject $project)
    {
        $request->validate([
            'reason' => 'required|string|max:1000',
        ]);

        CrowdfundingService::rejectProject($project, $request->reason);

        return back()->with('success', 'Loyiha rad etildi.');
    }

    /**
     * Xarajat kiritish
     */
    public function addExpense(Request $request, CfProject $project)
    {
        $data = $request->validate([
            'amount'      => 'required|numeric|min:0.0001',
            'description' => 'required|string|max:500',
            'spent_at'    => 'required|date',
        ]);

        try {
            CrowdfundingService::addExpense($project, $data);
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }

        return back()->with('success', 'Xarajat kiritildi.');
    }

    /**
     * Loyiha xarajatlari ro'yxati
     */
    public function expenses(CfProject $project)
    {
        $expenses = $project->expenses()->latest('spent_at')->paginate(15);

        return view('admin.crowdfunding.expenses', compact('project', 'expenses'));
    }
}
