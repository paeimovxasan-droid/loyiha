<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ubi\UbiClaim;
use App\Models\Ubi\UbiSetting;
use App\Services\UbiService;
use Illuminate\Http\Request;

class UbiAdminController extends Controller
{
    public function settings()
    {
        $setting = UbiSetting::current();
        $totalClaims = UbiClaim::count();
        $totalPaid = UbiClaim::sum('amount');

        return view('admin.ubi.settings', compact('setting', 'totalClaims', 'totalPaid'));
    }

    public function updateSettings(Request $request)
    {
        $data = $request->validate([
            'daily_amount' => 'required|numeric|min:0.0001',
            'is_active'    => 'boolean',
            'min_level'    => 'integer|min:0',
        ]);

        $data['is_active'] = $request->boolean('is_active');
        UbiService::updateSettings($data);

        return back()->with('success', 'UBI sozlamalari yangilandi');
    }

    public function claims()
    {
        $claims = UbiClaim::with('user:id,name,username')
            ->latest('claimed_at')->paginate(50);

        return view('admin.ubi.claims', compact('claims'));
    }
}
