<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Support\SupportTicket;
use App\Models\Support\SupportTicketMessage;
use App\Services\TelegramBotService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class SupportTicketAdminController extends Controller
{
    /**
     * Barcha ticketlar ro'yxati
     */
    public function index(Request $request)
    {
        $query = SupportTicket::with(['user', 'lastMessage', 'assignedTo'])->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }
        if ($request->filled('priority')) {
            $query->where('priority', $request->priority);
        }
        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($q) use ($s) {
                $q->where('ticket_number', 'like', "%{$s}%")
                  ->orWhere('subject', 'like', "%{$s}%")
                  ->orWhereHas('user', fn($u) => $u->where('name', 'like', "%{$s}%")
                      ->orWhere('username', 'like', "%{$s}%"));
            });
        }

        $tickets    = $query->paginate(20)->withQueryString();
        $categories = SupportTicket::CATEGORIES;
        $priorities = SupportTicket::PRIORITIES;
        $statuses   = SupportTicket::STATUSES;

        // Statistika
        $stats = [
            'open'        => SupportTicket::whereIn('status', ['open', 'reopened'])->count(),
            'in_progress' => SupportTicket::where('status', 'in_progress')->count(),
            'answered'    => SupportTicket::where('status', 'answered')->count(),
            'closed_today'=> SupportTicket::where('status', 'closed')->whereDate('closed_at', today())->count(),
        ];

        return view('admin.support.index', compact('tickets', 'categories', 'priorities', 'statuses', 'stats'));
    }

    /**
     * Ticket ko'rish va javob berish
     */
    public function show(SupportTicket $ticket)
    {
        // Foydalanuvchi xabarlarini o'qilgan deb belgilash
        $ticket->messages()
            ->where('is_admin_reply', false)
            ->where('is_read', false)
            ->update(['is_read' => true]);

        // Statusni in_progress ga o'tkazish (agar open bo'lsa)
        if ($ticket->status === 'open') {
            $ticket->update(['status' => 'in_progress']);
        }

        $messages   = $ticket->messages()->with('user')->get();
        $priorities = SupportTicket::PRIORITIES;
        $admins     = \App\Models\User::role(['admin', 'super-admin', 'moderator'])->get(['id', 'name']);

        return view('admin.support.show', compact('ticket', 'messages', 'priorities', 'admins'));
    }

    /**
     * Admin javob berish
     */
    public function reply(Request $request, SupportTicket $ticket)
    {
        $request->validate([
            'message'    => 'required|string|min:2|max:5000',
            'attachment' => 'nullable|file|max:5120|mimes:jpg,jpeg,png,pdf,doc,docx',
            'status'     => 'nullable|in:in_progress,answered,closed',
        ]);

        $attachmentPath = null;
        if ($request->hasFile('attachment')) {
            $attachmentPath = $request->file('attachment')
                ->store('support/attachments', 'public');
        }

        SupportTicketMessage::create([
            'ticket_id'      => $ticket->id,
            'user_id'        => auth()->id(),
            'message'        => $request->message,
            'attachment'     => $attachmentPath,
            'is_admin_reply' => true,
            'is_read'        => false,
        ]);

        $newStatus = $request->status ?? 'answered';
        $ticket->update([
            'status'        => $newStatus,
            'last_reply_at' => now(),
            'closed_at'     => $newStatus === 'closed' ? now() : $ticket->closed_at,
        ]);

        // Foydalanuvchiga Telegram bildirishnoma
        try {
            if ($ticket->user) {
                TelegramBotService::notifyUserTicketReply(
                    $ticket->user,
                    $ticket->ticket_number,
                    $ticket->subject,
                    $request->message,
                    $ticket->id
                );
            }
        } catch (\Throwable $e) {
            Log::warning('Admin reply notify failed', ['error' => $e->getMessage()]);
        }

        return back()->with('success', 'Javob yuborildi.');
    }

    /**
     * Prioritet va assigned_to yangilash
     */
    public function update(Request $request, SupportTicket $ticket)
    {
        $request->validate([
            'priority'    => 'nullable|in:low,medium,high,urgent',
            'assigned_to' => 'nullable|exists:users,id',
            'status'      => 'nullable|in:open,in_progress,answered,closed,reopened',
        ]);

        $ticket->update(array_filter([
            'priority'    => $request->priority,
            'assigned_to' => $request->assigned_to,
            'status'      => $request->status,
            'closed_at'   => $request->status === 'closed' ? now() : null,
        ], fn($v) => $v !== null));

        return back()->with('success', 'Ticket yangilandi.');
    }
}
