<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    public function index()
    {
        try {
            $setting = Setting::get();
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('Settings index error: ' . $e->getMessage());
            \Illuminate\Support\Facades\Cache::forget('app_settings');
            $setting = Setting::firstOrCreate([], [
                'site_name'    => ['uz' => 'AISOQQA', 'ru' => 'AISOQQA', 'en' => 'AISOQQA'],
                'currency'     => 'UZS',
                'min_deposit'  => 10000,
                'max_deposit'  => 50000000,
                'min_withdraw' => 20000,
                'max_withdraw' => 10000000,
            ]);
        }
        
        return view('admin.settings.index', compact('setting'));
    }

    public function update(Request $request)
    {
        $setting = Setting::get();
        
        $data = $request->validate([
            'site_name'       => 'required|array',
            'site_name.uz'    => 'required|string',
            'site_name.ru'    => 'nullable|string',
            'site_name.en'    => 'nullable|string',
            'site_title'      => 'nullable|array',
            'site_description'=> 'nullable|array',

            'contact_phone'   => 'nullable|string',
            'contact_email'   => 'nullable|email',

            'telegram'        => 'nullable|string',
            'instagram'       => 'nullable|string',
            'facebook'        => 'nullable|string',
            'youtube'         => 'nullable|string',

            'min_deposit'     => 'required|numeric',
            'max_deposit'     => 'required|numeric',
            'min_withdraw'    => 'required|numeric',
            'max_withdraw'    => 'required|numeric',

            'currency'        => 'required|string',

            // AJAX upload orqali kelgan ID lar
            'logo_id'         => 'nullable|integer|exists:files,id',
            'favicon_id'      => 'nullable|integer|exists:files,id',

            // Telegram sozlamalari
            'telegram_bot_token'          => 'nullable|string',
            'telegram_bot_username'       => 'nullable|string',
            'telegram_channel_id'         => 'nullable|string',
            'telegram_miniapp_url'        => 'nullable|url',
            'telegram_webhook_secret'     => 'nullable|string',
            'telegram_auto_posts_enabled' => 'nullable|boolean',

            // Daromad sozlamalari
            'withdrawal_fee_percent'   => 'nullable|numeric|min:0|max:20',
            'lucky_draw_rake_percent'  => 'nullable|numeric|min:0|max:90',
            'require_first_deposit'    => 'nullable|boolean',
            'first_deposit_min_amount' => 'nullable|numeric|min:0',
            'vip_silver_price'         => 'nullable|numeric|min:0',
            'vip_gold_price'           => 'nullable|numeric|min:0',
            'vip_platinum_price'       => 'nullable|numeric|min:0',
        ]);

        // Bo'sh ID kelsa — o'zgartirmaymiz (mavjud faylni saqlaymiz)
        if (empty($data['logo_id'])) {
            unset($data['logo_id']);
        }
        if (empty($data['favicon_id'])) {
            unset($data['favicon_id']);
        }

        $setting->update($data);

        // Boolean maydonlarni alohida saqlash (checkbox)
        $setting->update([
            'require_first_deposit'       => $request->boolean('require_first_deposit'),
            'telegram_auto_posts_enabled' => $request->boolean('telegram_auto_posts_enabled'),
        ]);

        \Illuminate\Support\Facades\Cache::forget('app_settings');

        return back()->with('success', 'Sozlamalar saqlandi');
    }
}
