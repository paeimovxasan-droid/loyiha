<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function showLogin()
    {
        if (Auth::check() && Auth::user()->hasAnyRole(['super-admin', 'admin', 'moderator'])) {
            return redirect()->route('admin.dashboard');
        }
        return view('admin.auth.login');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email'    => ['required', 'email'],
            'password' => ['required'],
        ]);

        if (!Auth::attempt($credentials, $request->boolean('remember'))) {
            return back()->withErrors([
                'email' => 'Email yoki parol noto\'g\'ri.',
            ])->onlyInput('email');
        }

        $user = Auth::user();

        // Faqat admin rollari kirishi mumkin
        if (!$user->hasAnyRole(['super-admin', 'admin', 'moderator'])) {
            Auth::logout();
            return back()->withErrors([
                'email' => 'Sizda admin panelga kirish ruxsati yo\'q.',
            ])->onlyInput('email');
        }

        // Bloklangan foydalanuvchi
        if ($user->isBanned()) {
            Auth::logout();
            return back()->withErrors([
                'email' => 'Hisobingiz bloklangan. Administratorga murojaat qiling.',
            ])->onlyInput('email');
        }

        $request->session()->regenerate();

        return redirect()->intended(route('admin.dashboard'));
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect()->route('admin.login');
    }
}
