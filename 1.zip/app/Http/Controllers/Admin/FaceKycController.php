<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Security\AuditLog;
use App\Models\Security\FaceKycAttempt;
use App\Models\User;
use App\Services\Security\FaceKycService;
use Illuminate\Http\Request;

class FaceKycController extends Controller
{
    /**
     * Barcha Face KYC so'rovlari ro'yxati
     */
    public function index(Request $request)
    {
        $query = FaceKycAttempt::with('user')
            ->whereIn('status', ['submitted', 'approved', 'rejected']);

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        } else {
            // Default: submitted birinchi
            $query->orderByRaw("CASE status WHEN 'submitted' THEN 1 WHEN 'rejected' THEN 2 WHEN 'approved' THEN 3 ELSE 4 END");
        }

        if ($request->filled('search')) {
            $s = $request->search;
            $query->whereHas('user', fn($q) => $q
                ->where('name', 'like', "%{$s}%")
                ->orWhere('username', 'like', "%{$s}%")
                ->orWhere('email', 'like', "%{$s}%")
            );
        }

        $attempts = $query->latest('submitted_at')->paginate(20)->withQueryString();

        $stats = [
            'submitted' => FaceKycAttempt::where('status', 'submitted')->count(),
            'approved'  => FaceKycAttempt::where('status', 'approved')->count(),
            'rejected'  => FaceKycAttempt::where('status', 'rejected')->count(),
        ];

        return view('admin.kyc.face-index', compact('attempts', 'stats'));
    }

    /**
     * Bitta so'rovni ko'rish (rasmlar bilan)
     */
    public function show(FaceKycAttempt $attempt)
    {
        $attempt->load('user');

        // Rasmlarni base64 sifatida yuklash (private storage)
        $selfieUrl   = $attempt->selfie_path
            ? FaceKycService::getTemporaryImageUrl($attempt->selfie_path)
            : null;

        $docFrontUrl = $attempt->doc_front_path
            ? FaceKycService::getTemporaryImageUrl($attempt->doc_front_path)
            : null;

        $docBackUrl  = $attempt->doc_back_path
            ? FaceKycService::getTemporaryImageUrl($attempt->doc_back_path)
            : null;

        return view('admin.kyc.face-show', compact(
            'attempt', 'selfieUrl', 'docFrontUrl', 'docBackUrl'
        ));
    }

    /**
     * Tasdiqlash
     */
    public function approve(FaceKycAttempt $attempt)
    {
        if ($attempt->status !== 'submitted') {
            return back()->with('error', 'Faqat yuborilgan so\'rovlarni tasdiqlash mumkin.');
        }

        $user = $attempt->user;
        if (!$user) {
            return back()->with('error', 'Foydalanuvchi topilmadi.');
        }

        $attempt->update([
            'reviewed_by' => auth()->id(),
            'reviewed_at' => now(),
        ]);

        FaceKycService::approveUser($user, $attempt);

        AuditLog::log('face_kyc_approved_by_admin', $user, [
            'attempt_id' => $attempt->id,
            'admin_id'   => auth()->id(),
        ]);

        return back()->with('success', "{$user->name} Face KYC tasdiqlandi.");
    }

    /**
     * Rad etish
     */
    public function reject(Request $request, FaceKycAttempt $attempt)
    {
        if ($attempt->status !== 'submitted') {
            return back()->with('error', 'Faqat yuborilgan so\'rovlarni rad etish mumkin.');
        }

        $request->validate([
            'reason' => 'required|string|max:500',
        ]);

        $user = $attempt->user;
        if (!$user) {
            return back()->with('error', 'Foydalanuvchi topilmadi.');
        }

        $attempt->update([
            'reviewed_by' => auth()->id(),
            'reviewed_at' => now(),
        ]);

        FaceKycService::rejectUser($user, $request->reason, $attempt);

        AuditLog::log('face_kyc_rejected_by_admin', $user, [
            'attempt_id' => $attempt->id,
            'reason'     => $request->reason,
            'admin_id'   => auth()->id(),
        ]);

        return back()->with('success', "{$user->name} Face KYC rad etildi.");
    }
}
