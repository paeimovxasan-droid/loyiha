<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Medical\MedicalSetting;
use Illuminate\Http\Request;

class MedicalSettingController extends Controller
{
    public function index()
    {
        $settings = MedicalSetting::getAll();
        return view('admin.medical.settings', compact('settings'));
    }

    public function update(Request $request)
    {
        $validated = $request->validate([
            'commission_percent'      => 'required|numeric|min:0|max:50',
            'escrow_timeout_hours'    => 'required|integer|min:1|max:72',
            'home_visit_timeout_hours' => 'required|integer|min:1|max:12',
            'delivery_fee'            => 'required|numeric|min:0',
            'platform_fee'            => 'required|numeric|min:0',
            'min_consultation_price'  => 'required|numeric|min:1',
            'max_consultation_price'  => 'required|numeric|min:10',
            'auto_suspend_complaints' => 'required|integer|min:1|max:10',
            'auto_suspend_rating'     => 'required|numeric|min:1|max:3',
            'auto_suspend_expired'    => 'required|integer|min:2|max:20',
            'inactivity_days'         => 'required|integer|min:7|max:90',
            'warning_rating'          => 'required|numeric|min:2|max:4',
            'xp_consultation_patient' => 'required|integer|min:0|max:200',
            'xp_consultation_doctor'  => 'required|integer|min:0|max:200',
            'xp_review'              => 'required|integer|min:0|max:100',
        ]);

        foreach ($validated as $key => $value) {
            MedicalSetting::setValue($key, $value);
        }

        MedicalSetting::clearCache();

        return back()->with('success', 'Sozlamalar saqlandi.');
    }
}
