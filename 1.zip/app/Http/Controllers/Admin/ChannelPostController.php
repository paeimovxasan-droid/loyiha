<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ChannelPost;
use App\Services\TelegramChannelService;
use Illuminate\Http\Request;

class ChannelPostController extends Controller
{
    /**
     * Kanal post tarixini ko'rsatish
     */
    public function index(Request $request)
    {
        $query = ChannelPost::with('creator')->latest();

        if ($request->filled('type')) {
            $query->where('type', $request->type);
        }

        $posts = $query->paginate(20)->withQueryString();

        return view('admin.channel-posts.index', compact('posts'));
    }

    /**
     * Maxsus e'lon yaratish formasi
     */
    public function create()
    {
        return view('admin.channel-posts.create');
    }

    /**
     * Maxsus e'lonni kanalga yuborish
     */
    public function store(Request $request)
    {
        $request->validate([
            'content' => 'required|string|max:4096',
            'photo'   => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
        ]);

        $photoPath = null;
        if ($request->hasFile('photo')) {
            $file = \App\Services\FileUploadService::upload($request->file('photo'), 'channel-posts');
            $photoPath = $file->path;
        }

        $post = ChannelPost::create([
            'type'       => 'custom',
            'content'    => $request->content,
            'photo'      => $photoPath,
            'status'     => 'pending',
            'created_by' => auth()->id(),
        ]);

        TelegramChannelService::sendPost($request->content, $photoPath);

        $post->update(['status' => 'sent', 'sent_at' => now()]);

        return redirect()->route('admin.channel-posts.index')
            ->with('success', 'E\'lon kanalga yuborildi.');
    }
}
