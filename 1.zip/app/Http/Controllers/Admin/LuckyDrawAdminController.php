<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Game\LuckyDraw;
use Illuminate\Http\Request;

class LuckyDrawAdminController extends Controller
{
    public function index()
    {
        $draws = LuckyDraw::latest()->paginate(15);
        return view('admin.lucky-draw.index', compact('draws'));
    }

    public function create()
    {
        return view('admin.lucky-draw.create');
    }

    public function store(Request $request)
    {
        $setting = \App\Models\Setting::get();

        $data = $request->validate([
            'name'                  => 'required|array',
            'name.uz'               => 'required|string|max:255',
            'name.ru'               => 'nullable|string|max:255',
            'name.en'               => 'nullable|string|max:255',
            'entry_fee'             => 'required|numeric|min:0',
            'prize_amount'          => 'required|numeric|min:0',
            'platform_rake_percent' => 'nullable|numeric|min:0|max:90',
            'max_tickets'           => 'nullable|integer|min:0',
            'draw_at'               => 'required|date|after:now',
            'status'                => 'required|in:active,inactive,completed',
        ]);

        // G'olibga beriladigan summa = prize_amount * (1 - rake/100)
        $data['platform_rake_percent'] = $data['platform_rake_percent'] ?? 25; $data['winner_prize'] = round($data['prize_amount'] * (1 - $data['platform_rake_percent'] / 100), 2);

        LuckyDraw::create($data);
        return redirect()->route('admin.lucky-draw.index')->with('success', 'Lucky Draw yaratildi.');
    }

    public function edit(LuckyDraw $luckyDraw)
    {
        return view('admin.lucky-draw.edit', ['draw' => $luckyDraw]);
    }

    public function update(Request $request, LuckyDraw $luckyDraw)
    {
        $data = $request->validate([
            'name'                  => 'required|array',
            'name.uz'               => 'required|string|max:255',
            'name.ru'               => 'nullable|string|max:255',
            'name.en'               => 'nullable|string|max:255',
            'entry_fee'             => 'required|numeric|min:0',
            'prize_amount'          => 'required|numeric|min:0',
            'platform_rake_percent' => 'nullable|numeric|min:0|max:90',
            'max_tickets'           => 'nullable|integer|min:0',
            'draw_at'               => 'required|date',
            'status'                => 'required|in:active,inactive,completed',
        ]);

        $data['platform_rake_percent'] = $data['platform_rake_percent'] ?? 25; $data['winner_prize'] = round($data['prize_amount'] * (1 - $data['platform_rake_percent'] / 100), 2);

        $luckyDraw->update($data);
        return redirect()->route('admin.lucky-draw.index')->with('success', 'Lucky Draw yangilandi.');
    }

    public function destroy(LuckyDraw $luckyDraw)
    {
        $luckyDraw->delete();
        return back()->with('success', 'Lucky Draw o\'chirildi.');
    }

    /**
     * Qur'a tashlash — tasodifiy g'olib tanlash va mukofot berish
     */
    public function draw(LuckyDraw $luckyDraw)
    {
        if ($luckyDraw->status !== 'active') {
            return back()->with('error', 'Faqat faol Lucky Draw uchun qur\'a tashlash mumkin.');
        }

        $tickets = \App\Models\Game\LuckyDrawTicket::where('lucky_draw_id', $luckyDraw->id)->get();

        if ($tickets->isEmpty()) {
            return back()->with('error', 'Hali birorta chipta sotilmagan.');
        }

        try {
            \Illuminate\Support\Facades\DB::transaction(function () use ($luckyDraw, $tickets) {
                // Har bir chipta alohida "slot" — ko'p chipta = ko'p imkoniyat
                $slots = [];
                foreach ($tickets as $ticket) {
                    for ($i = 0; $i < $ticket->quantity; $i++) {
                        $slots[] = $ticket->user_id;
                    }
                }

                // Tasodifiy g'olib tanlash
                $winnerId = $slots[array_rand($slots)];

                // G'olibga beriladigan summa
                $winnerPrize = $luckyDraw->calcWinnerPrize();

                // G'olibning balansini oshirish
                $winner = \App\Models\User::lockForUpdate()->find($winnerId);
                $winner->increment('balance', $winnerPrize);

                // Tiket g'olib deb belgilash
                \App\Models\Game\LuckyDrawTicket::where('lucky_draw_id', $luckyDraw->id)
                    ->where('user_id', $winnerId)
                    ->first()
                    ?->update(['is_winner' => true, 'prize_won' => $winnerPrize]);

                // Draw natijasini saqlash
                $luckyDraw->update([
                    'status'      => 'completed',
                    'winner_id'   => $winnerId,
                    'winner_prize'=> $winnerPrize,
                    'drawn_at'    => now(),
                ]);

                // Tranzaksiya yozuvi
                $winner->transactions()->create([
                    'amount'      => $winnerPrize,
                    'type'        => 'lucky_draw',
                    'direction'   => 'credit',
                    'status'      => 'completed',
                    'description' => "Lucky Draw g'olibi: {$luckyDraw->getTranslation('name', 'uz')}",
                ]);

                // Telegram bildirishnoma
                try {
                    \App\Services\TelegramBotService::notify(
                        $winner,
                        "🎉 Tabriklaymiz! Siz Lucky Draw'da g'olib bo'ldingiz!\n\n" .
                        "🎰 O'yin: {$luckyDraw->getTranslation('name', 'uz')}\n" .
                        "💰 Mukofot: " . number_format($winnerPrize, 2) . " UZS\n\n" .
                        "Mukofot balansingizga o'tkazildi! 🚀",
                        [[['text' => '💰 Balansni ko\'rish', 'url' => config('app.url') . '/app/deposit']]]
                    );
                } catch (\Throwable $e) {
                    \Illuminate\Support\Facades\Log::warning('LuckyDraw winner notify failed', ['error' => $e->getMessage()]);
                }
            });
        } catch (\Exception $e) {
            return back()->with('error', 'Xatolik: ' . $e->getMessage());
        }

        $draw = LuckyDraw::find($luckyDraw->id);
        return back()->with('success',
            "Qur'a tashlandi! G'olib: {$draw->winner?->name} — " .
            number_format($draw->winner_prize, 2) . " UZS mukofot berildi."
        );
    }

    /**
     * Draw natijalari
     */
    public function results()
    {
        $completed = LuckyDraw::with('winner')
            ->where('status', 'completed')
            ->whereNotNull('winner_id')
            ->latest('drawn_at')
            ->paginate(15);

        return view('admin.lucky-draw.results', compact('completed'));
    }
}
