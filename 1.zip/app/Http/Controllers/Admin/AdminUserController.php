<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class AdminUserController extends Controller
{
    public function index(Request $request)
    {
        // Faqat admin, super-admin kabi rollarni oladigan xodimlar
        $query = User::with('roles')->whereHas('roles', function($q) {
            $q->where('name', '!=', 'user');
        })->latest();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('username', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $admins = $query->paginate(15)->withQueryString();
        $roles = Role::where('name', '!=', 'user')->get();

        return view('admin.admins.index', compact('admins', 'roles'));
    }

    public function create()
    {
        $roles = Role::where('name', '!=', 'user')->get();
        return view('admin.admins.create', compact('roles'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'     => ['required', 'string', 'max:255'],
            'username' => ['required', 'string', 'max:50', 'unique:users'],
            'email'    => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'phone'    => ['nullable', 'string', 'max:20'],
            'password' => ['required', 'string', 'min:8'],
            'role'     => ['required', 'exists:roles,name'],
            'status'   => ['required', Rule::in(['active', 'banned'])],
        ]);

        $admin = User::create([
            'name'     => $validated['name'],
            'username' => $validated['username'],
            'email'    => $validated['email'],
            'phone'    => $validated['phone'],
            'password' => Hash::make($validated['password']),
            'status'   => $validated['status'],
            'balance'  => 0,
            'email_verified_at' => now(),
            'locale'   => 'uz',
        ]);

        $admin->assignRole($validated['role']);

        return redirect()->route('admin.admins.index')->with('success', 'Boshqaruvchi muvaffaqiyatli yaratildi.');
    }

    public function edit(User $admin)
    {
        $roles = Role::where('name', '!=', 'user')->get();
        return view('admin.admins.edit', compact('admin', 'roles'));
    }

    public function update(Request $request, User $admin)
    {
        $validated = $request->validate([
            'name'     => ['required', 'string', 'max:255'],
            'username' => ['required', 'string', 'max:50', Rule::unique('users')->ignore($admin->id)],
            'email'    => ['required', 'string', 'email', 'max:255', Rule::unique('users')->ignore($admin->id)],
            'phone'    => ['nullable', 'string', 'max:20'],
            'status'   => ['required', Rule::in(['active', 'banned'])],
        ]);

        if ($request->filled('password')) {
            $request->validate(['password' => ['min:8']]);
            $validated['password'] = Hash::make($request->password);
        }

        $admin->update($validated);

        return redirect()->route('admin.admins.index')->with('success', 'Boshqaruvchi ma\'lumotlari yangilandi.');
    }

    public function destroy(User $admin)
    {
        if ($admin->hasRole('super-admin')) {
            return back()->with('error', 'Super adminni o\'chirib bo\'lmaydi.');
        }

        if ($admin->id === auth()->id()) {
            return back()->with('error', 'O\'zingizni o\'chira olmaysiz.');
        }

        $admin->delete();
        return back()->with('success', 'Boshqaruvchi o\'chirildi.');
    }

    public function assignRole(Request $request, User $admin)
    {
        if ($admin->hasRole('super-admin') && !auth()->user()->hasRole('super-admin')) {
            return back()->with('error', 'Super admin rolini o\'zgartirish mumkin emas.');
        }

        $request->validate(['role' => 'required|exists:roles,name']);
        
        $admin->syncRoles($request->role);

        return back()->with('success', 'Boshqaruvchi roli yangilandi.');
    }

    public function ban(User $admin)
    {
        if ($admin->hasRole('super-admin')) {
            return back()->with('error', 'Super adminni blokirovka qilib bo\'lmaydi.');
        }

        if ($admin->id === auth()->id()) {
            return back()->with('error', 'O\'zingizni blokirovka qila olmaysiz.');
        }

        $admin->status = $admin->status === 'active' ? 'banned' : 'active';
        $admin->save();

        $msg = $admin->status === 'banned' ? 'Boshqaruvchi bloklandi.' : 'Boshqaruvchi blokdan chiqarildi.';
        return back()->with('success', $msg);
    }
}
