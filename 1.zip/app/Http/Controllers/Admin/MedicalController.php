<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Medical\Consultation;
use App\Models\Medical\DoctorProfile;
use App\Models\Medical\HomeVisit;
use App\Models\Medical\Medicine;
use App\Models\Medical\MedicalComplaint;
use App\Models\Medical\MedicineOrder;
use App\Services\Medical\MedicalService;
use App\Services\TelegramBotService;
use Illuminate\Http\Request;

class MedicalController extends Controller
{
    // ══════════════════════════════════════════════════════════════════════
    // DASHBOARD
    // ══════════════════════════════════════════════════════════════════════

    public function dashboard()
    {
        $stats = [
            'total_doctors'         => DoctorProfile::count(),
            'approved_doctors'      => DoctorProfile::approved()->count(),
            'pending_doctors'       => DoctorProfile::where('status', 'pending')->count(),
            'active_consultations'  => Consultation::active()->count(),
            'completed_today'       => Consultation::completed()->whereDate('completed_at', today())->count(),
            'monthly_revenue'       => Consultation::completed()
                ->where('completed_at', '>=', now()->startOfMonth())
                ->sum('commission_amount'),
            'pending_orders'        => MedicineOrder::where('status', 'new')->count(),
            'pending_complaints'    => MedicalComplaint::pending()->count(),
            'escrow_frozen'         => Consultation::where('status', 'pending')->sum('escrow_amount')
                + HomeVisit::where('status', 'pending')->sum('escrow_amount'),
        ];

        return view('admin.medical.dashboard', compact('stats'));
    }

    // ══════════════════════════════════════════════════════════════════════
    // SHIFOKOR TASDIQLASH
    // ══════════════════════════════════════════════════════════════════════

    public function doctors(Request $request)
    {
        $query = DoctorProfile::with('user:id,name,email,phone')->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $doctors = $query->paginate(15);
        return view('admin.medical.doctors', compact('doctors'));
    }

    public function doctorShow(DoctorProfile $doctorProfile)
    {
        $doctorProfile->load(['user', 'reviews.patient:id,name']);

        // Faoliyat statistikasi
        $stats = [
            'total_consultations'  => Consultation::where('doctor_id', $doctorProfile->user_id)->count(),
            'completed'            => Consultation::where('doctor_id', $doctorProfile->user_id)->completed()->count(),
            'expired'              => Consultation::where('doctor_id', $doctorProfile->user_id)->where('status', 'expired')->count(),
            'cancelled'            => Consultation::where('doctor_id', $doctorProfile->user_id)->where('status', 'cancelled')->count(),
            'total_earnings'       => Consultation::where('doctor_id', $doctorProfile->user_id)->completed()->sum('doctor_earning'),
            'avg_response_hours'   => $this->calculateAvgResponseTime($doctorProfile->user_id),
            'justified_complaints' => MedicalComplaint::where('doctor_id', $doctorProfile->user_id)->where('is_justified', true)->count(),
        ];

        return view('admin.medical.doctor-show', compact('doctorProfile', 'stats'));
    }

    public function doctorApprove(Request $request, DoctorProfile $doctorProfile)
    {
        if (!$doctorProfile->isPending()) {
            return back()->with('error', 'Bu profil kutilmoqda holatida emas.');
        }

        $doctorProfile->update([
            'status'      => DoctorProfile::STATUS_APPROVED,
            'approved_at' => now(),
        ]);

        if ($doctorProfile->user) {
            TelegramBotService::notify(
                $doctorProfile->user,
                "✅ Shifokor profilingiz tasdiqlandi!\n"
                . "Endi bemorlar sizdan maslahat olishi mumkin.",
                [[['text' => '📱 Platformaga kirish', 'url' => config('app.url') . '/app/doctor/dashboard']]]
            );
        }

        return back()->with('success', 'Shifokor profili tasdiqlandi.');
    }

    public function doctorReject(Request $request, DoctorProfile $doctorProfile)
    {
        $request->validate(['reason' => 'required|string|max:500']);

        $doctorProfile->update([
            'status'           => DoctorProfile::STATUS_REJECTED,
            'rejection_reason' => $request->reason,
        ]);

        if ($doctorProfile->user) {
            TelegramBotService::notify(
                $doctorProfile->user,
                "❌ Shifokor profilingiz rad etildi.\n"
                . "📋 Sabab: {$request->reason}\n\n"
                . "Iltimos, ma'lumotlarni to'g'irlab qayta yuboring."
            );
        }

        return back()->with('success', 'Shifokor profili rad etildi.');
    }

    public function doctorSuspend(DoctorProfile $doctorProfile)
    {
        $doctorProfile->update(['status' => DoctorProfile::STATUS_SUSPENDED]);

        if ($doctorProfile->user) {
            TelegramBotService::notify(
                $doctorProfile->user,
                "🚫 Shifokor profilingiz to'xtatildi.\nAdmin bilan bog'laning."
            );
        }

        return back()->with('success', 'Shifokor profili to\'xtatildi.');
    }

    public function doctorReactivate(DoctorProfile $doctorProfile)
    {
        $newRating = $doctorProfile->rating < 2.0 ? 3.0 : $doctorProfile->rating;

        $doctorProfile->update([
            'status' => DoctorProfile::STATUS_APPROVED,
            'rating' => $newRating,
        ]);

        if ($doctorProfile->user) {
            TelegramBotService::notify(
                $doctorProfile->user,
                "✅ Shifokor profilingiz qayta faollashtirildi!\nReytingingiz: {$newRating}"
            );
        }

        return back()->with('success', 'Shifokor qayta faollashtirildi.');
    }

    // ══════════════════════════════════════════════════════════════════════
    // MASLAHATLAR
    // ══════════════════════════════════════════════════════════════════════

    public function consultations(Request $request)
    {
        $query = Consultation::with(['patient:id,name', 'doctor:id,name', 'doctorProfile:id,specialty'])->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $consultations = $query->paginate(15);
        return view('admin.medical.consultations', compact('consultations'));
    }

    public function consultationShow(Consultation $consultation)
    {
        $consultation->load(['patient', 'doctor', 'doctorProfile', 'messages.sender:id,name', 'prescriptions.items', 'referrals', 'review', 'complaint']);
        return view('admin.medical.consultation-show', compact('consultation'));
    }

    // ══════════════════════════════════════════════════════════════════════
    // DORI BUYURTMALAR
    // ══════════════════════════════════════════════════════════════════════

    public function medicineOrders(Request $request)
    {
        $query = MedicineOrder::with(['patient:id,name', 'items'])->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $orders = $query->paginate(15);
        return view('admin.medical.medicine-orders', compact('orders'));
    }

    public function medicineOrderUpdateStatus(Request $request, MedicineOrder $medicineOrder)
    {
        $request->validate([
            'status' => 'required|in:processing,delivering,delivered,cancelled',
        ]);

        $medicineOrder->update(['status' => $request->status]);

        if ($request->status === 'delivered') {
            $medicineOrder->update(['delivered_at' => now()]);
        }

        // Bemorga bildirishnoma
        $statusMessages = [
            'processing' => '⚙️ Dori buyurtmangiz jarayonda.',
            'delivering' => '🚗 Dorilaringiz yetkazilmoqda!',
            'delivered'  => '✅ Dorilaringiz yetkazildi!',
            'cancelled'  => '❌ Dori buyurtmangiz bekor qilindi.',
        ];

        TelegramBotService::notify(
            $medicineOrder->patient,
            $statusMessages[$request->status] ?? 'Buyurtma holati yangilandi.'
        );

        return back()->with('success', 'Buyurtma holati yangilandi.');
    }

    // ══════════════════════════════════════════════════════════════════════
    // UYGA CHAQIRISHLAR
    // ══════════════════════════════════════════════════════════════════════

    public function homeVisits(Request $request)
    {
        $query = HomeVisit::with(['patient:id,name', 'doctor:id,name', 'doctorProfile:id,specialty'])->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $visits = $query->paginate(15);
        return view('admin.medical.home-visits', compact('visits'));
    }

    // ══════════════════════════════════════════════════════════════════════
    // SHIKOYATLAR
    // ══════════════════════════════════════════════════════════════════════

    public function complaints(Request $request)
    {
        $query = MedicalComplaint::with(['patient:id,name', 'doctor:id,name', 'consultation'])->latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $complaints = $query->paginate(15);
        return view('admin.medical.complaints', compact('complaints'));
    }

    public function complaintReview(Request $request, MedicalComplaint $complaint)
    {
        $request->validate([
            'is_justified'   => 'required|boolean',
            'admin_response' => 'nullable|string|max:1000',
        ]);

        $complaint->update([
            'status'         => MedicalComplaint::STATUS_REVIEWED,
            'is_justified'   => $request->is_justified,
            'admin_response' => $request->admin_response,
            'reviewed_at'    => now(),
        ]);

        // Agar asosli bo'lsa — shifokor reytingini pasaytirish
        if ($request->is_justified) {
            $profile = DoctorProfile::where('user_id', $complaint->doctor_id)->first();
            if ($profile) {
                $newRating = max(0, $profile->rating - 0.5);
                $profile->update(['rating' => $newRating]);

                if ($profile->user) {
                    TelegramBotService::notify(
                        $profile->user,
                        "⚠️ Sizga asosli shikoyat keldi. Reytingingiz 0.5 ga pasaytirildi.\n"
                        . "Hozirgi reyting: {$newRating}"
                    );
                }

                // 3 ta asosli shikoyat — avtomatik suspend
                $justifiedCount = MedicalComplaint::where('doctor_id', $complaint->doctor_id)
                    ->where('is_justified', true)
                    ->count();

                if ($justifiedCount >= 3 && $profile->isApproved()) {
                    $profile->update(['status' => DoctorProfile::STATUS_SUSPENDED]);
                    if ($profile->user) {
                        TelegramBotService::notify(
                            $profile->user,
                            "🚫 3 ta asosli shikoyat tufayli profilingiz to'xtatildi."
                        );
                    }
                    TelegramBotService::notifyAdmin(
                        "🚫 Shifokor avtomatik to'xtatildi (3 asosli shikoyat)\n"
                        . "👨‍⚕️ " . ($profile->user?->name ?? 'Noma\'lum')
                    );
                }

                MedicalService::checkDoctorQuality($profile);
            }
        }

        return back()->with('success', 'Shikoyat ko\'rib chiqildi.');
    }

    // ══════════════════════════════════════════════════════════════════════
    // DORI KATALOGI
    // ══════════════════════════════════════════════════════════════════════

    public function medicines(Request $request)
    {
        $query = Medicine::query()->latest();

        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $medicines = $query->paginate(15);
        return view('admin.medical.medicines', compact('medicines'));
    }

    public function medicineStore(Request $request)
    {
        $validated = $request->validate([
            'name'        => 'required|string|max:255',
            'type'        => 'required|in:' . implode(',', Medicine::TYPES),
            'price'       => 'required|numeric|min:0',
            'description' => 'nullable|string|max:1000',
            'is_active'   => 'boolean',
            'in_stock'    => 'boolean',
        ]);

        Medicine::create($validated);
        return back()->with('success', 'Dori qo\'shildi.');
    }

    public function medicineUpdate(Request $request, Medicine $medicine)
    {
        $validated = $request->validate([
            'name'        => 'sometimes|string|max:255',
            'type'        => 'sometimes|in:' . implode(',', Medicine::TYPES),
            'price'       => 'sometimes|numeric|min:0',
            'description' => 'nullable|string|max:1000',
            'is_active'   => 'sometimes|boolean',
            'in_stock'    => 'sometimes|boolean',
        ]);

        $medicine->update($validated);
        return back()->with('success', 'Dori yangilandi.');
    }

    public function medicineDelete(Medicine $medicine)
    {
        $medicine->delete(); // soft delete
        return back()->with('success', 'Dori o\'chirildi.');
    }

    // ══════════════════════════════════════════════════════════════════════
    // MOLIYAVIY HISOBOT
    // ══════════════════════════════════════════════════════════════════════

    public function financialReport(Request $request)
    {
        $from = $request->filled('from') ? $request->from : now()->startOfMonth()->toDateString();
        $to = $request->filled('to') ? $request->to : now()->toDateString();

        $stats = [
            'total_revenue'     => Consultation::completed()
                ->whereBetween('completed_at', [$from, $to . ' 23:59:59'])
                ->sum('commission_amount'),
            'total_paid_doctors' => Consultation::completed()
                ->whereBetween('completed_at', [$from, $to . ' 23:59:59'])
                ->sum('doctor_earning'),
            'refunded'          => Consultation::whereIn('status', ['cancelled', 'expired'])
                ->whereBetween('updated_at', [$from, $to . ' 23:59:59'])
                ->sum('escrow_amount'),
            'medicine_revenue'  => MedicineOrder::where('status', 'delivered')
                ->whereBetween('delivered_at', [$from, $to . ' 23:59:59'])
                ->sum('platform_fee'),
            'escrow_frozen'     => Consultation::pending()->sum('escrow_amount'),
        ];

        // Top shifokorlar
        $topDoctors = DoctorProfile::with('user:id,name')
            ->approved()
            ->orderByDesc('rating')
            ->limit(10)
            ->get();

        return view('admin.medical.financial-report', compact('stats', 'topDoctors', 'from', 'to'));
    }

    // ══════════════════════════════════════════════════════════════════════
    // HELPERS
    // ══════════════════════════════════════════════════════════════════════

    private function calculateAvgResponseTime(int $doctorId): float
    {
        $consultations = Consultation::where('doctor_id', $doctorId)
            ->whereNotNull('accepted_at')
            ->latest()
            ->limit(20)
            ->get();

        if ($consultations->isEmpty()) return 0;

        $totalHours = $consultations->sum(function ($c) {
            return $c->created_at->diffInMinutes($c->accepted_at) / 60;
        });

        return round($totalHours / $consultations->count(), 1);
    }
}
