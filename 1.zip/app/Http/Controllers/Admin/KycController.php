<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Security\AuditLog;
use App\Models\User;
use App\Services\Security\FaceKycService;
use Illuminate\Http\Request;

class KycController extends Controller
{
    /**
     * Pasport KYC so'rovlari ro'yxati (1-bosqich)
     */
    public function index(Request $request)
    {
        $query = User::whereIn('kyc_status', [
            'passport_pending',
            'passport_verified',
            'face_pending',
            'verified',
            'rejected',
        ]);

        if ($request->filled('status')) {
            $query->where('kyc_status', $request->status);
        } else {
            // Default: passport_pending birinchi
            $query->orderByRaw("CASE kyc_status
                WHEN 'passport_pending'  THEN 1
                WHEN 'face_pending'      THEN 2
                WHEN 'passport_verified' THEN 3
                WHEN 'rejected'          THEN 4
                WHEN 'verified'          THEN 5
                ELSE 6 END");
        }

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(fn($q) => $q
                ->where('name', 'like', "%{$s}%")
                ->orWhere('email', 'like', "%{$s}%")
                ->orWhere('username', 'like', "%{$s}%")
            );
        }

        $users = $query->latest()->paginate(20)->withQueryString();

        $stats = [
            'passport_pending'  => User::where('kyc_status', 'passport_pending')->count(),
            'passport_verified' => User::where('kyc_status', 'passport_verified')->count(),
            'face_pending'      => User::where('kyc_status', 'face_pending')->count(),
            'verified'          => User::where('kyc_status', 'verified')->count(),
            'rejected'          => User::where('kyc_status', 'rejected')->count(),
        ];

        return view('admin.kyc.index', compact('users', 'stats'));
    }

    /**
     * Foydalanuvchining pasport rasmini ko'rish
     */
    public function show(User $user)
    {
        $docUrl = $user->kyc_document
            ? FaceKycService::getTemporaryImageUrl($user->kyc_document)
            : null;

        // Face ID urinishlari tarixi
        $attempts = $user->faceKycAttempts()->latest()->get();

        return view('admin.kyc.show', compact('user', 'docUrl', 'attempts'));
    }

    /**
     * Pasportni tasdiqlash → passport_verified
     */
    public function approve(User $user)
    {
        if ($user->kyc_status !== 'passport_pending') {
            return back()->with('error', 'Faqat passport_pending holatidagi so\'rovlarni tasdiqlash mumkin.');
        }

        FaceKycService::approvePassport($user);

        AuditLog::log('kyc_passport_approved', $user, [
            'admin_id' => auth()->id(),
        ]);

        return back()->with('success', "{$user->name} pasporti tasdiqlandi. Endi Face ID bosqichini o'tishi kerak.");
    }

    /**
     * Pasportni rad etish → rejected
     */
    public function reject(Request $request, User $user)
    {
        if ($user->kyc_status !== 'passport_pending') {
            return back()->with('error', 'Faqat passport_pending holatidagi so\'rovlarni rad etish mumkin.');
        }

        $request->validate([
            'reason' => 'required|string|max:500',
        ]);

        $reason = $request->input('reason');

        FaceKycService::rejectPassport($user, $reason);

        AuditLog::log('kyc_passport_rejected', $user, [
            'reason'   => $reason,
            'admin_id' => auth()->id(),
        ]);

        return back()->with('success', "{$user->name} pasporti rad etildi.");
    }
}
