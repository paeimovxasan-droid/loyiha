<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Lending\Loan;
use App\Models\Lending\LoanOffer;
use Illuminate\Http\Request;

class LendingAdminController extends Controller
{
    public function loans(Request $request)
    {
        $query = Loan::with(['borrower:id,name,username', 'lender:id,name,username'])->latest();
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        $loans = $query->paginate(20);
        return view('admin.lending.loans', compact('loans'));
    }

    public function offers(Request $request)
    {
        $query = LoanOffer::with('lender:id,name,username')->latest();
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        $offers = $query->paginate(20);
        return view('admin.lending.offers', compact('offers'));
    }

    public function editLoan(Loan $loan)
    {
        $loan->load(['borrower:id,name,username', 'lender:id,name,username']);
        return view('admin.lending.edit_loan', compact('loan'));
    }

    public function updateLoan(Request $request, Loan $loan)
    {
        $request->validate([
            'status' => 'required|in:pending,active,repaid,defaulted',
        ]);

        $loan->update($request->only('status'));

        return redirect()->route('admin.lending.loans')->with('success', 'Qarz holati muvaffaqiyatli yangilandi.');
    }
}
