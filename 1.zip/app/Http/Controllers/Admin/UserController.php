<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;

class UserController extends Controller
{
    public function index(Request $request)
    {
        $query = User::with('roles')
            ->where(function($q) {
                $q->whereHas('roles', fn($r) => $r->where('name', 'user'))
                  ->orDoesntHave('roles');
            })->latest();

        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%")
                  ->orWhere('username', 'like', "%{$search}%")
                  ->orWhere('phone', 'like', "%{$search}%");
            });
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        try {
            $users = $query->paginate(15)->withQueryString();
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('Admin users index error: ' . $e->getMessage());
            $users = new \Illuminate\Pagination\LengthAwarePaginator([], 0, 15);
        }

        return view('admin.users.index', compact('users'));
    }

    public function create()
    {
        return view('admin.users.create');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'     => ['required', 'string', 'max:255'],
            'username' => ['required', 'string', 'max:50', 'unique:users'],
            'email'    => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'phone'    => ['nullable', 'string', 'max:20'],
            'password' => ['required', 'string', 'min:8'],
            'status'   => ['required', Rule::in(['active', 'banned'])],
            'balance'  => ['nullable', 'numeric', 'min:0'],
        ]);

        $user = User::create([
            'name'     => $validated['name'],
            'username' => $validated['username'],
            'email'    => $validated['email'],
            'phone'    => $validated['phone'],
            'password' => Hash::make($validated['password']),
            'status'   => $validated['status'],
            'balance'  => $validated['balance'] ?? 0,
            'email_verified_at' => now(),
            'locale'   => 'uz',
        ]);

        $user->assignRole('user');

        // Hamyon yaratish
        \App\Services\WalletService::createForUser($user);

        return redirect()->route('admin.users.index')->with('success', 'Mijoz muvaffaqiyatli yaratildi.');
    }

    public function edit(User $user)
    {
        return view('admin.users.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'name'     => ['required', 'string', 'max:255'],
            'username' => ['required', 'string', 'max:50', Rule::unique('users')->ignore($user->id)],
            'email'    => ['required', 'string', 'email', 'max:255', Rule::unique('users')->ignore($user->id)],
            'phone'    => ['nullable', 'string', 'max:20'],
            'status'   => ['required', Rule::in(['active', 'banned'])],
        ]);

        if ($request->filled('password')) {
            $request->validate(['password' => ['min:8']]);
            $validated['password'] = Hash::make($request->password);
        }

        $user->update($validated);

        return redirect()->route('admin.users.index')->with('success', 'Mijoz ma\'lumotlari yangilandi.');
    }

    public function destroy(User $user)
    {
        if ($user->id === auth()->id()) {
            return back()->with('error', 'O\'zingizni o\'chira olmaysiz.');
        }

        $user->delete();
        return back()->with('success', 'Mijoz o\'chirildi.');
    }

    public function adjustBalance(Request $request, User $user)
    {
        $request->validate([
            'action' => 'required|in:add,subtract',
            'amount' => 'required|numeric|min:0.01|max:50000000',
            'reason' => 'nullable|string|max:255',
        ]);

        $amount = $request->amount;

        \Illuminate\Support\Facades\DB::transaction(function () use ($user, $amount, $request) {
            // Pessimistic lock — race condition oldini olish
            $user = User::lockForUpdate()->find($user->id);
            $balanceBefore = $user->balance;

            if ($request->action === 'add') {
                $user->increment('balance', $amount);
                $direction = 'credit';
                $msg = "+{$amount} qo'shildi.";
            } else {
                if ($user->balance < $amount) {
                    throw new \Exception('Balans yetarli emas.');
                }
                $user->decrement('balance', $amount);
                $direction = 'debit';
                $msg = "-{$amount} ayirildi.";
            }

            $user->refresh();

            $description = 'Admin tomonidan balans o\'zgartirildi';
            if ($request->filled('reason')) {
                $description .= ': ' . $request->reason;
            }

            $user->transactions()->create([
                'amount'         => $amount,
                'type'           => 'bonus',
                'direction'      => $direction,
                'balance_before' => $balanceBefore,
                'balance_after'  => $user->balance,
                'status'         => 'completed',
                'description'    => $description,
            ]);

            // Audit log
            try {
                \App\Models\Security\AuditLog::log(
                    'admin_balance_adjust',
                    $user,
                    [
                        'admin_id'      => auth()->id(),
                        'admin_name'    => auth()->user()->name,
                        'action'        => $request->action,
                        'amount'        => $amount,
                        'balance_before'=> $balanceBefore,
                        'balance_after' => $user->balance,
                        'reason'        => $request->reason,
                        'ip'            => request()->ip(),
                    ]
                );
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('AuditLog failed', ['error' => $e->getMessage()]);
            }
        });

        return back()->with('success', 'Mijoz balansi muvaffaqiyatli ozgartirildi.');
    }

    public function ban(User $user)
    {
        if ($user->hasRole('super-admin')) {
            return back()->with('error', 'Super adminni blokirovka qilib bo\'lmaydi.');
        }

        if ($user->id === auth()->id()) {
            return back()->with('error', 'O\'zingizni blokirovka qila olmaysiz.');
        }

        $user->status = $user->status === 'active' ? 'banned' : 'active';
        $user->save();

        $msg = $user->status === 'banned' ? 'Mijoz bloklandi.' : 'Mijoz blokdan chiqarildi.';
        return back()->with('success', $msg);
    }
}
