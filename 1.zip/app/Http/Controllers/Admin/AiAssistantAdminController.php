<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AiAssistant\FaqEntry;
use App\Models\AiAssistant\AiConversation;
use Illuminate\Http\Request;

class AiAssistantAdminController extends Controller
{
    public function faq()
    {
        $faqs = FaqEntry::latest()->paginate(30);
        return view('admin.ai-assistant.faq', compact('faqs'));
    }

    public function storeFaq(Request $request)
    {
        $data = $request->validate([
            'question' => 'required|string|max:500',
            'answer'   => 'required|string',
            'category' => 'nullable|string|max:100',
            'keywords' => 'nullable|string|max:255',
        ]);
        $data['is_active'] = true;
        FaqEntry::create($data);
        return back()->with('success', 'FAQ qoshildi');
    }

    public function updateFaq(Request $request, FaqEntry $faq)
    {
        $data = $request->validate([
            'question' => 'required|string|max:500',
            'answer'   => 'required|string',
            'category' => 'nullable|string|max:100',
            'keywords' => 'nullable|string|max:255',
            'is_active'=> 'boolean',
        ]);
        $data['is_active'] = $request->boolean('is_active');
        $faq->update($data);
        return back()->with('success', 'FAQ yangilandi');
    }

    public function destroyFaq(FaqEntry $faq)
    {
        $faq->delete();
        return back()->with('success', 'FAQ ochirildi');
    }

    public function conversations()
    {
        $conversations = AiConversation::with('user:id,name,username')
            ->withCount('messages')
            ->latest()->paginate(30);
        return view('admin.ai-assistant.conversations', compact('conversations'));
    }
}
