<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class InstallerController extends Controller
{
    // ── Qadam 1: Xush kelibsiz ───────────────────────────────────────────────
    public function welcome()
    {
        $checks = $this->systemChecks();
        return view('installer.welcome', compact('checks'));
    }

    // ── Qadam 2: Ma'lumotlar bazasi ──────────────────────────────────────────
    public function database()
    {
        return view('installer.database');
    }

    public function databaseSave(Request $request)
    {
        $data = $request->validate([
            'db_host'     => 'required|string',
            'db_port'     => 'required|numeric',
            'db_name'     => 'required|string',
            'db_user'     => 'required|string',
            'db_password' => 'nullable|string',
        ]);

        // DB ulanishni test qilish
        try {
            $pdo = new \PDO(
                "mysql:host={$data['db_host']};port={$data['db_port']};dbname={$data['db_name']}",
                $data['db_user'],
                $data['db_password'] ?? '',
                [\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION, \PDO::ATTR_TIMEOUT => 5]
            );
        } catch (\PDOException $e) {
            return back()->withErrors(['db' => 'DB ulanish xatosi: ' . $e->getMessage()])->withInput();
        }

        session([
            'install_db' => [
                'db_host'     => $data['db_host'],
                'db_port'     => $data['db_port'],
                'db_name'     => $data['db_name'],
                'db_user'     => $data['db_user'],
                'db_password' => encrypt($data['db_password'] ?? ''),
            ],
        ]);

        return redirect()->route('install.site');
    }

    // ── Qadam 3: Sayt sozlamalari ────────────────────────────────────────────
    public function site()
    {
        if (!session('install_db')) return redirect()->route('install.database');
        return view('installer.site');
    }

    public function siteSave(Request $request)
    {
        $data = $request->validate([
            'site_name'    => 'required|string|max:100',
            'site_domain'  => 'required|string|max:100',
            'contact_email'=> 'required|email',
            'ais_rate'     => 'required|numeric|min:1',
            'currency'     => 'required|string|max:10',
        ]);

        session(['install_site' => $data]);
        return redirect()->route('install.admin');
    }

    // ── Qadam 4: Admin hisob ─────────────────────────────────────────────────
    public function admin()
    {
        if (!session('install_site')) return redirect()->route('install.site');
        return view('installer.admin');
    }

    public function adminSave(Request $request)
    {
        $data = $request->validate([
            'name'     => 'required|string|max:100',
            'email'    => 'required|email',
            'password' => 'required|string|min:8|confirmed',
        ]);

        session(['install_admin' => $data]);
        return redirect()->route('install.process');
    }

    // ── Qadam 5: O'rnatish jarayoni ──────────────────────────────────────────
    public function process()
    {
        if (!session('install_admin')) return redirect()->route('install.admin');
        return view('installer.process');
    }

    public function run(Request $request)
    {
        $db    = session('install_db');
        $site  = session('install_site');
        $admin = session('install_admin');

        if (!$db || !$site || !$admin) {
            return response()->json(['success' => false, 'message' => 'Session ma\'lumotlari yo\'q. Qaytadan boshlang.']);
        }

        // DB parolni decrypt qilish
        try {
            $db['db_password'] = decrypt($db['db_password']);
        } catch (\Exception $e) {
            $db['db_password'] = '';
        }

        $steps = [];

        try {
            // ── 1. .env yozish ───────────────────────────────────────────────
            $this->writeEnv($db, $site);
            $steps[] = ['step' => '.env fayli yaratildi', 'ok' => true];

            // ── 2. APP_KEY ───────────────────────────────────────────────────
            Artisan::call('key:generate', ['--force' => true]);
            $steps[] = ['step' => 'APP_KEY yaratildi', 'ok' => true];

            // ── 3. Config cache tozalash + DB ulanishni yangilash ────────────
            Artisan::call('config:clear');
            // DB konfiguratsiyasini runtime da yangilash
            config([
                'database.connections.mysql.host'     => $db['db_host'],
                'database.connections.mysql.port'     => $db['db_port'],
                'database.connections.mysql.database' => $db['db_name'],
                'database.connections.mysql.username' => $db['db_user'],
                'database.connections.mysql.password' => $db['db_password'] ?? '',
            ]);
            \Illuminate\Support\Facades\DB::purge('mysql');
            \Illuminate\Support\Facades\DB::reconnect('mysql');
            $steps[] = ['step' => 'Config yangilandi', 'ok' => true];

            // ── 4. Migration ─────────────────────────────────────────────────
            Artisan::call('migrate', ['--force' => true]);
            $steps[] = ['step' => 'Jadvallar yaratildi', 'ok' => true];

            // ── 5. Seed ──────────────────────────────────────────────────────
            Artisan::call('db:seed', ['--force' => true]);
            $steps[] = ['step' => 'Boshlang\'ich ma\'lumotlar yuklandi', 'ok' => true];

            // ── 6. Admin hisob yaratish / yangilash ──────────────────────────
            $this->createAdmin($admin);
            $steps[] = ['step' => 'Admin hisob yaratildi', 'ok' => true];

            // ── 7. Sayt sozlamalarini yangilash ──────────────────────────────
            $this->updateSettings($site);
            $steps[] = ['step' => 'Sayt sozlamalari saqlandi', 'ok' => true];

            // ── 8. Storage link ──────────────────────────────────────────────
            try {
                Artisan::call('storage:link', ['--force' => true]);
            } catch (\Throwable $e) {
                // Shared hostingda symlink ishlamasligi mumkin — qo'lda yaratamiz
                $target = storage_path('app/public');
                $link   = public_path('storage');
                if (!file_exists($link) && !is_link($link)) {
                    @symlink($target, $link);
                }
            }
            $steps[] = ['step' => 'Storage link yaratildi', 'ok' => true];

            // ── 9. Cache ─────────────────────────────────────────────────────
            Artisan::call('cache:clear');
            Artisan::call('view:clear');
            $steps[] = ['step' => 'Cache tozalandi', 'ok' => true];

            // ── 10. installed fayli yaratish ─────────────────────────────────
            file_put_contents(storage_path('installed'), json_encode([
                'installed_at' => now()->toISOString(),
                'version'      => '1.0.0',
                'domain'       => $site['site_domain'],
            ]));
            $steps[] = ['step' => 'O\'rnatish yakunlandi', 'ok' => true];

            // Session tozalash
            session()->forget(['install_db', 'install_site', 'install_admin']);

            return response()->json([
                'success' => true,
                'steps'   => $steps,
                'redirect'=> '/install/complete',
            ]);

        } catch (\Throwable $e) {
            $steps[] = ['step' => 'Xato: ' . $e->getMessage(), 'ok' => false];
            return response()->json(['success' => false, 'steps' => $steps, 'message' => $e->getMessage()]);
        }
    }

    // ── Yakunlandi ───────────────────────────────────────────────────────────
    public function complete()
    {
        if (!file_exists(storage_path('installed'))) {
            return redirect()->route('install.welcome');
        }
        return view('installer.complete');
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private function writeEnv(array $db, array $site): void
    {
        $envPath = base_path('.env');
        $example = base_path('.env.example');

        $content = file_exists($example) ? file_get_contents($example) : '';

        $replacements = [
            'APP_NAME'     => '"' . $site['site_name'] . '"',
            'APP_URL'      => 'https://' . $site['site_domain'],
            'APP_ENV'      => 'production',
            'APP_DEBUG'    => 'false',
            'DB_HOST'      => $db['db_host'],
            'DB_PORT'      => $db['db_port'],
            'DB_DATABASE'  => $db['db_name'],
            'DB_USERNAME'  => $db['db_user'],
            'DB_PASSWORD'  => $db['db_password'] ?? '',
        ];

        foreach ($replacements as $key => $value) {
            if (preg_match("/^{$key}=/m", $content)) {
                $content = preg_replace("/^{$key}=.*/m", "{$key}={$value}", $content);
            } else {
                $content .= "\n{$key}={$value}";
            }
        }

        file_put_contents($envPath, $content);
    }

    private function createAdmin(array $data): void
    {
        // Avval seeder yaratgan superadmin ni yangilash
        $existing = \App\Models\User::where('username', 'superadmin')->first();
        if ($existing) {
            $existing->update([
                'name'              => $data['name'],
                'email'             => $data['email'],
                'password'          => Hash::make($data['password']),
                'status'            => 'active',
                'email_verified_at' => now(),
            ]);
            $existing->syncRoles(['super-admin', 'user']);
            return;
        }

        $user = \App\Models\User::create([
            'name'              => $data['name'],
            'email'             => $data['email'],
            'username'          => 'superadmin',
            'password'          => Hash::make($data['password']),
            'status'            => 'active',
            'locale'            => 'uz',
            'email_verified_at' => now(),
        ]);
        $user->syncRoles(['super-admin', 'user']);
    }

    private function updateSettings(array $site): void
    {
        $setting = \App\Models\Setting::first();
        if ($setting) {
            $setting->update([
                'site_name'       => ['uz' => $site['site_name'], 'ru' => $site['site_name'], 'en' => $site['site_name']],
                'contact_email'   => $site['contact_email'],
                'site_currency'   => $site['currency'],
                'ais_to_uzs_rate' => $site['ais_rate'],
                'site_domain'     => $site['site_domain'],
            ]);
        }
    }

    private function systemChecks(): array
    {
        return [
            ['name' => 'PHP >= 8.2',        'ok' => version_compare(PHP_VERSION, '8.2.0', '>='), 'value' => PHP_VERSION],
            ['name' => 'PDO MySQL',          'ok' => extension_loaded('pdo_mysql'),               'value' => extension_loaded('pdo_mysql') ? 'Mavjud' : 'Yo\'q'],
            ['name' => 'OpenSSL',            'ok' => extension_loaded('openssl'),                 'value' => extension_loaded('openssl') ? 'Mavjud' : 'Yo\'q'],
            ['name' => 'Mbstring',           'ok' => extension_loaded('mbstring'),                'value' => extension_loaded('mbstring') ? 'Mavjud' : 'Yo\'q'],
            ['name' => 'Tokenizer',          'ok' => extension_loaded('tokenizer'),               'value' => extension_loaded('tokenizer') ? 'Mavjud' : 'Yo\'q'],
            ['name' => 'GD / Imagick',       'ok' => extension_loaded('gd') || extension_loaded('imagick'), 'value' => extension_loaded('gd') ? 'GD' : (extension_loaded('imagick') ? 'Imagick' : 'Yo\'q')],
            ['name' => 'storage/ yozish',    'ok' => is_writable(storage_path()),                 'value' => is_writable(storage_path()) ? 'Yozish mumkin' : 'Yozish mumkin emas'],
            ['name' => 'bootstrap/cache/',   'ok' => is_writable(base_path('bootstrap/cache')),   'value' => is_writable(base_path('bootstrap/cache')) ? 'Yozish mumkin' : 'Yozish mumkin emas'],
            ['name' => '.env.example',       'ok' => file_exists(base_path('.env.example')),      'value' => file_exists(base_path('.env.example')) ? 'Mavjud' : 'Yo\'q'],
        ];
    }
}
