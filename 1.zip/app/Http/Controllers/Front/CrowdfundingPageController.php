<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CrowdfundingPageController extends Controller
{
    public function index()
    {
        try {
            $projects = \App\Models\Crowdfunding\CfProject::where('status', 'active')
                ->with('user')->latest()->paginate(12);
        } catch (\Exception $e) {
            $projects = new \Illuminate\Pagination\LengthAwarePaginator([], 0, 12);
        }

        return view('front.pages.crowdfunding', compact('projects'));
    }

    public function create()
    {
        return view('front.pages.crowdfunding_create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'required|string|max:5000',
            'goal_amount' => 'required|numeric|min:100000',
            'category'    => 'required|in:kocha_tamiri,maktab_jihozlash,kasb_orgatish',
            'expires_at'  => 'nullable|date|after:today',
        ]);

        try {
            \App\Models\Crowdfunding\CfProject::create([
                'user_id'          => auth()->id(),
                'title'            => $request->title,
                'description'      => $request->description,
                'category'         => $request->category,
                'goal_amount'      => $request->goal_amount,
                'collected_amount' => 0,
                'status'           => 'pending',
                'expires_at'       => $request->expires_at ?? now()->addMonths(3),
            ]);

            return redirect()->route('app.crowdfunding')->with('success', 'Loyiha yuborildi! Admin tasdiqlashini kuting.');
        } catch (\Exception $e) {
            return back()->withInput()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }

    public function donate(Request $request, $id)
    {
        $request->validate(['amount' => 'required|numeric|min:1000']);

        try {
            $project = \App\Models\Crowdfunding\CfProject::findOrFail($id);

            // Faqat tasdiqlangan va muddati o'tmagan loyihalarga donate qilish mumkin
            if ($project->status !== 'active') {
                return back()->with('error', 'Bu loyiha hozirda faol emas.');
            }

            if ($project->expires_at && $project->expires_at->isPast()) {
                return back()->with('error', 'Bu loyiha muddati tugagan.');
            }

            $user   = auth()->user();
            $amount = (float) $request->amount;

            if ($user->balance < $amount) {
                return back()->with('error', 'Balansingiz yetarli emas.');
            }

            \Illuminate\Support\Facades\DB::transaction(function () use ($user, $project, $amount) {
                $user    = \App\Models\User::lockForUpdate()->find($user->id);
                $project = \App\Models\Crowdfunding\CfProject::lockForUpdate()->find($project->id);

                if ($user->balance < $amount) {
                    throw new \Exception('Balansingiz yetarli emas.');
                }

                if ($project->status !== 'active') {
                    throw new \Exception('Bu loyiha hozirda faol emas.');
                }

                $balanceBefore = $user->balance;
                $user->decrement('balance', $amount);
                $user->refresh();

                $donation = \App\Models\Crowdfunding\CfDonation::create([
                    'cf_project_id' => $project->id,
                    'user_id'       => $user->id,
                    'amount'        => $amount,
                ]);

                $project->increment('collected_amount', $amount);

                $user->transactions()->create([
                    'amount'               => $amount,
                    'type'                 => 'crowdfunding',
                    'direction'            => 'debit',
                    'balance_before'       => $balanceBefore,
                    'balance_after'        => $user->balance,
                    'status'               => 'completed',
                    'description'          => $project->title . ' loyihasiga xayriya',
                    'transactionable_type' => \App\Models\Crowdfunding\CfDonation::class,
                    'transactionable_id'   => $donation->id,
                ]);
            });

            return back()->with('success', number_format($amount) . ' UZS xayriya qilindi!');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
