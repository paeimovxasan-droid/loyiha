<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class AgroMarketPageController extends Controller
{
    public function index()
    {
        try {
            $listings = \App\Models\AgroMarket\AgroListing::where('status', 'active')
                ->with('user')->latest()->paginate(12);
        } catch (\Exception $e) {
            $listings = new \Illuminate\Pagination\LengthAwarePaginator([], 0, 12);
        }

        return view('front.pages.agromarket', compact('listings'));
    }

    public function create()
    {
        return view('front.pages.agromarket_create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'nullable|string|max:5000',
            'category'    => 'required|in:bugdoy,paxta,sabzavot,meva',
            'price'       => 'required|numeric|min:0',
            'quantity'    => 'required|numeric|min:0.01',
            'location'    => 'required|string|max:255',
        ]);

        try {
            \App\Models\AgroMarket\AgroListing::create([
                'user_id'        => auth()->id(),
                'title'          => $request->title,
                'description'    => $request->description,
                'category'       => $request->category,
                'price_per_unit' => $request->price,
                'quantity'       => $request->quantity,
                'location'       => $request->location,
                'status'         => 'active',
            ]);

            return redirect()->route('app.agromarket')->with('success', 'E\'lon muvaffaqiyatli yaratildi!');
        } catch (\Exception $e) {
            return back()->withInput()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }
}
