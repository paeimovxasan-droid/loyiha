<?php

namespace App\Http\Controllers\Front\Influencer;

use App\Http\Controllers\Controller;
use App\Models\Influencer\InfluencerCampaign;
use App\Models\Influencer\InfluencerChannel;
use App\Models\Influencer\InfluencerReward;
use App\Models\Influencer\InfluencerSubmission;

class InfluencerDashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $stats = [
            'total_channels'      => InfluencerChannel::where('user_id', $user->id)->count(),
            'approved_channels'   => InfluencerChannel::where('user_id', $user->id)->where('status', 'approved')->count(),
            'total_submissions'   => InfluencerSubmission::where('user_id', $user->id)->count(),
            'pending_submissions' => InfluencerSubmission::where('user_id', $user->id)->where('status', 'pending')->count(),
            'total_earned_ais'    => InfluencerReward::where('user_id', $user->id)->sum('amount'),
            'last_30_days_count'  => InfluencerSubmission::where('user_id', $user->id)
                ->where('created_at', '>=', now()->subDays(30))->count(),
        ];

        // Faol kampaniyalar (faqat approved kanali bor Publisherlarga)
        $hasApprovedChannel = InfluencerChannel::where('user_id', $user->id)
            ->where('status', 'approved')->exists();

        $activeCampaigns = [];
        if ($hasApprovedChannel) {
            $activeCampaigns = InfluencerCampaign::active()
                ->orderByDesc('reward_amount')
                ->limit(5)
                ->get();
        }

        // Oxirgi submissionlar
        $recentSubmissions = InfluencerSubmission::with(['campaign', 'channel'])
            ->where('user_id', $user->id)
            ->latest()
            ->limit(5)
            ->get();

        return view('front.influencer.dashboard', compact('stats', 'activeCampaigns', 'recentSubmissions', 'hasApprovedChannel'));
    }
}
