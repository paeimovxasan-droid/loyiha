<?php

namespace App\Http\Controllers\Front\Influencer;

use App\Http\Controllers\Controller;
use App\Models\Influencer\InfluencerCampaign;
use App\Models\Influencer\InfluencerChannel;
use App\Models\Influencer\InfluencerSetting;
use App\Services\Influencer\InfluencerRewardService;

class InfluencerCampaignController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $setting = InfluencerSetting::current();
        if (!$setting->is_enabled) {
            return view('front.influencer.campaigns.index', ['campaigns' => collect(), 'hasApprovedChannel' => false, 'userChannels' => collect()]);
        }

        $userChannels = InfluencerChannel::where('user_id', $user->id)
            ->where('status', 'approved')
            ->get();

        $hasApprovedChannel = $userChannels->isNotEmpty();

        $campaigns = collect();
        if ($hasApprovedChannel) {
            $campaigns = InfluencerCampaign::active()
                ->orderByDesc('reward_amount')
                ->get()
                ->map(function ($campaign) use ($userChannels) {
                    // Har bir kampaniya uchun foydalanuvchining mos kanallarini topish
                    $campaign->eligible_channels = $userChannels->filter(function ($channel) use ($campaign) {
                        return in_array($channel->type, $campaign->target_channel_types ?? [])
                            && $channel->subscriber_count >= $campaign->min_subscribers;
                    });
                    return $campaign;
                })
                ->filter(fn($c) => $c->eligible_channels->isNotEmpty());
        }

        return view('front.influencer.campaigns.index', compact('campaigns', 'hasApprovedChannel', 'userChannels'));
    }
}
