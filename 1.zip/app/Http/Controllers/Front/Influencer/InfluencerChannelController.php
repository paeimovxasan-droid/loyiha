<?php

namespace App\Http\Controllers\Front\Influencer;

use App\Http\Controllers\Controller;
use App\Models\Influencer\InfluencerChannel;
use App\Services\Influencer\InfluencerChannelService;
use Illuminate\Http\Request;

class InfluencerChannelController extends Controller
{
    public function index()
    {
        $user     = auth()->user();
        $channels = InfluencerChannel::where('user_id', $user->id)->latest()->get();
        $types    = InfluencerChannel::TYPES;

        return view('front.influencer.channels.index', compact('channels', 'types'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'type'             => 'required|in:youtube_channel,telegram_channel,telegram_group,telegram_bot',
            'name'             => 'required|string|max:255',
            'url'              => 'required|string|max:500',
            'subscriber_count' => 'nullable|integer|min:0',
            'language'         => 'nullable|in:uz,ru,en',
        ]);

        try {
            InfluencerChannelService::create(auth()->user(), $data);
            return back()->with('success', 'Kanal qo\'shildi! Admin tasdiqlashini kuting.');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage())->withInput();
        }
    }

    public function destroy(InfluencerChannel $channel)
    {
        if ((int) $channel->user_id !== (int) auth()->id()) {
            abort(403);
        }

        try {
            InfluencerChannelService::delete($channel, auth()->user());
            return back()->with('success', 'Kanal o\'chirildi.');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
