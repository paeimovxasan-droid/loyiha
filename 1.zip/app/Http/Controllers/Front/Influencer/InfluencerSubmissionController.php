<?php

namespace App\Http\Controllers\Front\Influencer;

use App\Http\Controllers\Controller;
use App\Models\Influencer\InfluencerSubmission;
use App\Services\Influencer\InfluencerSubmissionService;
use Illuminate\Http\Request;

class InfluencerSubmissionController extends Controller
{
    public function index()
    {
        $user        = auth()->user();
        $submissions = InfluencerSubmission::with(['campaign', 'channel', 'reward'])
            ->where('user_id', $user->id)
            ->latest()
            ->paginate(15);

        return view('front.influencer.submissions.index', compact('submissions'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'campaign_id' => 'required|integer|exists:influencer_campaigns,id',
            'channel_id'  => 'required|integer|exists:influencer_channels,id',
            'post_url'    => 'required|url|max:500',
            'screenshot'  => 'nullable|image|max:5120|mimes:jpg,jpeg,png,webp',
        ]);

        // Kanal egasini tekshirish
        $channel = \App\Models\Influencer\InfluencerChannel::find($request->channel_id);
        if (!$channel || (int) $channel->user_id !== (int) auth()->id()) {
            return back()->with('error', 'Bu kanal sizga tegishli emas.')->withInput();
        }

        try {
            InfluencerSubmissionService::submit(
                auth()->user(),
                $request->only('campaign_id', 'channel_id', 'post_url'),
                $request->file('screenshot')
            );

            return back()->with('success', 'Submission yuborildi! Admin ko\'rib chiqishini kuting.');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage())->withInput();
        }
    }
}
