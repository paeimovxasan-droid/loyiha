<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Package\Package;

class HomeController extends Controller
{
    public function index()
    {
        if (auth()->check()) {
            return redirect()->route('app.dashboard');
        }

        $setting  = \App\Models\Setting::get();
        $packages = \App\Models\Package\Package::active()->limit(6)->get();

        return view('front.pages.home', compact('packages', 'setting'));
    }
}
