<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;

class TransactionController extends Controller
{
    public function index()
    {
        $transactions = auth()->user()->transactions()->latest()->paginate(20);
        return view('front.pages.transactions', compact('transactions'));
    }
}
