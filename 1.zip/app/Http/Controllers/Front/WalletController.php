<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\AIS\AisRate;
use App\Models\AIS\VirtualCard;
use App\Models\AIS\Wallet;
use App\Models\Level\LevelConfig;
use App\Models\Level\UserLevel;
use App\Services\WalletService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class WalletController extends Controller
{
    public function index()
    {
        $user    = auth()->user();
        $wallet  = WalletService::createForUser($user);
        $rate    = AisRate::current() ?? new AisRate(['rate_uzs' => 1000, 'buy_rate' => 1000, 'sell_rate' => 1000]);
        $level   = UserLevel::firstOrCreate(['user_id' => $user->id], [
            'level' => 0, 'total_xp' => 0, 'current_xp' => 0,
            'next_level_xp' => 100, 'title' => 'Newcomer', 'badge_color' => '#64748b',
        ]);

        $levelConfig  = LevelConfig::getForLevel($level->level);
        $p2pUnlocked  = $levelConfig?->p2p_unlocked ?? ($level->level >= 5);
        $cardUnlocked = $levelConfig?->virtual_card_unlocked ?? ($level->level >= 10);

        $cards = $user->virtualCards()->where('status', '!=', 'cancelled')->get();

        $recentTransfers = collect()
            ->merge($user->sentTransfers()->with('receiver')->latest()->limit(5)->get()
                ->map(fn($t) => ['type' => 'sent', 'item' => $t]))
            ->merge($user->receivedTransfers()->with('sender')->latest()->limit(5)->get()
                ->map(fn($t) => ['type' => 'received', 'item' => $t]))
            ->sortByDesc(fn($t) => $t['item']->created_at)
            ->take(10)
            ->values();

        $recentConversions = $user->aisConversions()->with('rate')->latest()->limit(5)->get();

        return view('front.pages.wallet', compact(
            'wallet', 'rate', 'level', 'levelConfig',
            'p2pUnlocked', 'cardUnlocked', 'cards',
            'recentTransfers', 'recentConversions'
        ));
    }

    public function transfer(Request $request)
    {
        $user  = auth()->user();
        $level = UserLevel::where('user_id', $user->id)->first();
        $cfg   = LevelConfig::getForLevel($level?->level ?? 0);

        if (!($cfg?->p2p_unlocked ?? ($level?->level >= 5))) {
            return back()->with('error', 'P2P transfer Level 5 dan ochiladi.');
        }

        $request->validate([
            'receiver'  => 'required|string',
            'amount'    => 'required|numeric|min:0.0001',
            'note'      => 'nullable|string|max:255',
        ]);

        // Receiver mavjudligini tekshirish
        $receiver = \App\Models\User::where('username', $request->receiver)
            ->orWhere('email', $request->receiver)
            ->first();

        if (!$receiver) {
            return back()->with('error', 'Qabul qiluvchi topilmadi.');
        }

        if ($receiver->isBanned()) {
            return back()->with('error', 'Qabul qiluvchi hisobi bloklangan.');
        }

        if ($receiver->id === $user->id) {
            return back()->with('error', 'O\'zingizga transfer qilib bo\'lmaydi.');
        }

        try {
            $transfer = WalletService::transfer(
                $user,
                $request->receiver,
                (float) $request->amount,
                $request->note
            );
            return back()->with('success',
                number_format($transfer->amount, 4) . ' AIS muvaffaqiyatli o\'tkazildi.');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function convert(Request $request)
    {
        $setting = \App\Models\Setting::get();

        $request->validate([
            'direction' => 'required|in:buy,sell',
            'amount'    => 'required|numeric|min:' . ($request->direction === 'buy' ? max(1000, $setting->min_deposit ?? 1000) : '0.001'),
        ]);

        try {
            $user = auth()->user();
            if ($request->direction === 'buy') {
                $conversion = WalletService::depositToWallet($user, (float) $request->amount);
                $msg = number_format($request->amount) . ' UZS → ' . number_format($conversion->ais_amount, 4) . ' AIS';
            } else {
                $conversion = WalletService::withdrawFromWallet($user, (float) $request->amount);
                $msg = number_format($request->amount, 4) . ' AIS → ' . number_format($conversion->uzs_amount) . ' UZS';
            }
            return back()->with('success', 'Konvertatsiya bajarildi: ' . $msg);
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    public function createCard()
    {
        $user  = auth()->user();
        $level = UserLevel::where('user_id', $user->id)->first();
        $cfg   = LevelConfig::getForLevel($level?->level ?? 0);

        if (!($cfg?->virtual_card_unlocked ?? ($level?->level >= 10))) {
            return redirect()->route('app.wallet')->with('error', 'Virtual karta Level 10 dan ochiladi.');
        }

        if ($user->virtualCards()->where('status', '!=', 'cancelled')->count() >= 3) {
            return redirect()->route('app.wallet')->with('error', 'Maksimal 3 ta karta yaratish mumkin.');
        }

        return view('front.pages.wallet_card_create');
    }

    public function storeCard(Request $request)
    {
        $user  = auth()->user();
        $level = UserLevel::where('user_id', $user->id)->first();
        $cfg   = LevelConfig::getForLevel($level?->level ?? 0);

        if (!($cfg?->virtual_card_unlocked ?? ($level?->level >= 10))) {
            return back()->with('error', 'Virtual karta Level 10 dan ochiladi.');
        }

        $request->validate([
            'card_holder' => 'required|string|max:26|regex:/^[A-Za-z\s]+$/',
        ]);

        $wallet = WalletService::createForUser($user);
        $cvv    = str_pad(random_int(0, 999), 3, '0', STR_PAD_LEFT);
        $expiry = now()->addYears(3);

        $card = VirtualCard::create([
            'user_id'      => $user->id,
            'wallet_id'    => $wallet->id,
            'card_number'  => VirtualCard::generateCardNumber(),
            'card_holder'  => strtoupper($request->card_holder),
            'expiry_month' => $expiry->format('m'),
            'expiry_year'  => $expiry->format('Y'),
            'cvv_hash'     => Hash::make($cvv),
            'status'       => 'active',
        ]);

        // CVV faqat Telegram orqali yuboriladi — response'da ko'rsatilmaydi
        $telegramSent = false;
        try {
            \App\Services\TelegramBotService::notify(
                $user,
                "💳 Virtual kartangiz yaratildi!\n\n" .
                "🔐 CVV: <code>{$cvv}</code>\n\n" .
                "⚠️ CVV ni hech kimga bermang! Bu xabar 1 daqiqadan keyin o'chiring."
            );
            $telegramSent = true;
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('CVV notify failed', ['error' => $e->getMessage()]);
        }

        $successMsg = 'Virtual karta yaratildi!';
        if ($telegramSent) {
            $successMsg .= ' CVV Telegram orqali yuborildi.';
        } else {
            // Telegram ishlamasa — CVV ni session'ga saqlash (bir martalik ko'rsatish)
            session()->flash('card_cvv', $cvv);
            $successMsg .= ' CVV quyida ko\'rsatilgan — uni yozib oling!';
        }

        return redirect()->route('app.wallet')->with('success', $successMsg);
    }

    public function freezeCard(Request $request, VirtualCard $card)
    {
        if ($card->user_id !== auth()->id()) abort(403);

        $wasFrozen = $card->isFrozen();

        $card->update([
            'status' => $wasFrozen ? 'active' : 'frozen',
        ]);

        $msg = $wasFrozen ? 'Karta faollashtirildi.' : 'Karta muzlatildi.';
        return back()->with('success', $msg);
    }
}
