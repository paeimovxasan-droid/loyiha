<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RoadmapPageController extends Controller
{
    public function index()
    {
        try {
            $modules = \App\Models\RoadmapModule::orderBy('sort_order')->get();
            $votedIds = \App\Models\RoadmapVote::where('user_id', auth()->id())
                ->pluck('roadmap_module_id')->toArray();
        } catch (\Exception $e) {
            $modules = collect();
            $votedIds = [];
        }

        return view('front.pages.roadmap', compact('modules', 'votedIds'));
    }

    public function vote(Request $request, $id)
    {
        try {
            $module = \App\Models\RoadmapModule::findOrFail($id);
            $existing = \App\Models\RoadmapVote::where('user_id', auth()->id())
                ->where('roadmap_module_id', $module->id)->first();

            if ($existing) {
                $existing->delete();
                $module->decrement('votes_count');
                return back()->with('success', 'Ovoz qaytarildi.');
            }

            \App\Models\RoadmapVote::create([
                'user_id' => auth()->id(),
                'roadmap_module_id' => $module->id,
                'created_at' => now(),
            ]);
            $module->increment('votes_count');

            return back()->with('success', 'Ovoz berildi!');
        } catch (\Exception $e) {
            return back()->with('error', 'Xatolik yuz berdi.');
        }
    }
}
