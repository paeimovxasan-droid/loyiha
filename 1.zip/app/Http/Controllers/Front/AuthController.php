<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class AuthController extends Controller
{
    public function showLogin()
    {
        return view('front.auth.login');
    }

    public function login(Request $request)
    {
        $request->validate([
            'login'    => 'required|string',
            'password' => 'required|string',
        ]);

        $login = $request->input('login');

        // Email yoki username orqali kirish
        $field = filter_var($login, FILTER_VALIDATE_EMAIL) ? 'email' : 'username';

        if (!Auth::attempt([$field => $login, 'password' => $request->password], $request->boolean('remember'))) {
            return back()->withErrors(['login' => 'Login yoki parol noto\'g\'ri.'])->withInput();
        }

        $user = Auth::user();

        if ($user->status === 'banned') {
            Auth::logout();
            return back()->withErrors(['login' => 'Hisobingiz bloklangan.']);
        }

        $request->session()->regenerate();

        // Device tracking on login
        try {
            \App\Models\Security\UserDevice::create([
                'user_id'          => $user->id,
                'ip_address'       => $request->ip(),
                'fingerprint_hash' => $request->input('fingerprint_hash'),
                'user_agent'       => $request->userAgent(),
                'event_type'       => 'login',
            ]);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('UserDevice login tracking failed', ['error' => $e->getMessage()]);
        }

        // Admin bo'lsa admin panelga redirect
        if ($user->hasRole('super-admin') || $user->hasRole('admin') || $user->hasRole('moderator')) {
            return redirect()->route('admin.dashboard');
        }

        return redirect()->route('app.dashboard');
    }

    public function showRegister(?string $ref = null)
    {
        $referrer = null;
        if ($ref) {
            $referrer = User::where('username', $ref)->first();
        }

        return view('front.auth.register', compact('referrer'));
    }

    public function register(Request $request)
    {
        $request->validate([
            'name'                  => 'required|string|max:100',
            'username'              => 'required|string|alpha_dash|max:30|unique:users',
            'email'                 => 'required|email|unique:users',
            'phone'                 => 'nullable|string|max:20',
            'password'              => ['required', 'confirmed', Password::min(8)],
            'ref'                   => 'nullable|string|exists:users,username',
        ]);

        // ref ni kichik harfga o'tkazish (username kichik harfda saqlanadi)
        $ref = $request->ref ? strtolower($request->ref) : null;

        $user = User::create([
            'name'        => $request->name,
            'username'    => strtolower($request->username),
            'email'       => strtolower($request->email),
            'phone'       => $request->phone,
            'password'    => Hash::make($request->password),
            'referred_by' => $ref,
            'status'      => 'active',
        ]);

        $user->assignRole('user');

        // Hamyon yaratish
        \App\Services\WalletService::createForUser($user);

        // Ro'yxatdan o'tish uchun XP berish
        \App\Services\XpService::award($user, \App\Models\Level\XpLog::ACTION_REGISTER, 50, 'Ro\'yxatdan o\'tish');

        // Referral quest progress (taklif qilgan foydalanuvchi uchun)
        if ($request->ref) {
            $referrer = User::where('username', $request->ref)->first();
            if ($referrer) {
                \App\Services\QuestService::updateProgress($referrer, \App\Models\Game\Quest::REQ_REFERRAL_COUNT);
                \App\Services\XpService::award($referrer, \App\Models\Level\XpLog::ACTION_REFERRAL, 20,
                    $user->name . ' ro\'yxatdan o\'tdi');
            }
        }

        // Fraud detection: device tracking + VPN check + multi-account detection
        try {
            \App\Services\Security\FraudDetectionService::onRegister($user, $request);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('FraudDetection onRegister failed', ['error' => $e->getMessage()]);
        }

        Auth::login($user);

        return redirect()->route('app.dashboard')->with('success', 'Xush kelibsiz! Hisobingiz muvaffaqiyatli yaratildi.');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
