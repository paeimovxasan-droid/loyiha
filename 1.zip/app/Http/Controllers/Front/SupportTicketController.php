<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Support\SupportTicket;
use App\Models\Support\SupportTicketMessage;
use App\Services\TelegramBotService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class SupportTicketController extends Controller
{
    /**
     * Ticketlar ro'yxati
     */
    public function index()
    {
        $tickets = SupportTicket::with('lastMessage')
            ->where('user_id', auth()->id())
            ->latest()
            ->paginate(10);

        return view('front.pages.support.index', compact('tickets'));
    }

    /**
     * Yangi ticket yaratish formasi
     */
    public function create()
    {
        $categories = SupportTicket::CATEGORIES;
        return view('front.pages.support.create', compact('categories'));
    }

    /**
     * Yangi ticket saqlash
     */
    public function store(Request $request)
    {
        $request->validate([
            'subject'    => 'required|string|max:255',
            'category'   => 'required|in:' . implode(',', array_keys(SupportTicket::CATEGORIES)),
            'message'    => 'required|string|min:10|max:5000',
            'attachment' => 'nullable|file|max:5120|mimes:jpg,jpeg,png,pdf,doc,docx',
        ]);

        $user = auth()->user();

        // Ochiq ticketlar soni cheklash (max 5 ta)
        $openCount = SupportTicket::where('user_id', $user->id)
            ->whereIn('status', ['open', 'in_progress', 'reopened'])
            ->count();

        if ($openCount >= 5) {
            return back()->with('error', 'Siz bir vaqtda maksimal 5 ta ochiq ticket yuborishingiz mumkin.');
        }

        DB::transaction(function () use ($request, $user) {
            $ticket = SupportTicket::create([
                'ticket_number' => SupportTicket::generateNumber(),
                'user_id'       => $user->id,
                'subject'       => $request->subject,
                'category'      => $request->category,
                'priority'      => 'medium',
                'status'        => 'open',
                'last_reply_at' => now(),
            ]);

            // Fayl yuklash
            $attachmentPath = null;
            if ($request->hasFile('attachment')) {
                $attachmentPath = $request->file('attachment')
                    ->store('support/attachments', 'public');
            }

            // Birinchi xabar
            SupportTicketMessage::create([
                'ticket_id'      => $ticket->id,
                'user_id'        => $user->id,
                'message'        => $request->message,
                'attachment'     => $attachmentPath,
                'is_admin_reply' => false,
                'is_read'        => false,
            ]);

            // Admin ga Telegram bildirishnoma
            try {
                TelegramBotService::notifyAdminNewTicket(
                    $ticket->ticket_number,
                    $ticket->subject,
                    "{$user->name} (@{$user->username})",
                    $ticket->id
                );
            } catch (\Throwable $e) {
                Log::warning('Support ticket notify failed', ['error' => $e->getMessage()]);
            }
        });

        return redirect()->route('app.support.index')
            ->with('success', 'Ticketingiz yuborildi! Tez orada javob beramiz.');
    }

    /**
     * Ticket ko'rish va javob berish
     */
    public function show(SupportTicket $ticket)
    {
        // Faqat o'z ticketini yoki admin ko'rishi mumkin
        if ((int) $ticket->user_id !== (int) auth()->id() && !auth()->user()->isAdmin()) {
            abort(403);
        }

        // Admin xabarlarini o'qilgan deb belgilash
        $ticket->messages()
            ->where('is_admin_reply', true)
            ->where('is_read', false)
            ->update(['is_read' => true]);

        $messages   = $ticket->messages()->with('user')->get();
        $categories = SupportTicket::CATEGORIES;

        return view('front.pages.support.show', compact('ticket', 'messages', 'categories'));
    }

    /**
     * Ticketga javob yozish
     */
    public function reply(Request $request, SupportTicket $ticket)
    {
        if ((int) $ticket->user_id !== (int) auth()->id() && !auth()->user()->isAdmin()) {
            abort(403);
        }

        if ($ticket->isClosed()) {
            return back()->with('error', 'Yopilgan ticketga javob yozib bo\'lmaydi.');
        }

        $request->validate([
            'message'    => 'required|string|min:2|max:5000',
            'attachment' => 'nullable|file|max:5120|mimes:jpg,jpeg,png,pdf,doc,docx',
        ]);

        $attachmentPath = null;
        if ($request->hasFile('attachment')) {
            $attachmentPath = $request->file('attachment')
                ->store('support/attachments', 'public');
        }

        SupportTicketMessage::create([
            'ticket_id'      => $ticket->id,
            'user_id'        => auth()->id(),
            'message'        => $request->message,
            'attachment'     => $attachmentPath,
            'is_admin_reply' => false,
            'is_read'        => false,
        ]);

        $ticket->update([
            'status'        => $ticket->status === 'answered' ? 'reopened' : $ticket->status,
            'last_reply_at' => now(),
        ]);

        // Admin ga bildirishnoma
        try {
            TelegramBotService::notifyAdmin(
                "💬 Ticket #{$ticket->ticket_number} ga yangi xabar!\n\n" .
                "👤 " . ($ticket->user?->name ?? 'Foydalanuvchi') . "\n" .
                "📌 {$ticket->subject}\n\n" .
                mb_substr($request->message, 0, 200),
                [[['text' => '👁 Ko\'rish', 'url' => config('app.url') . '/admin/support/' . $ticket->id]]]
            );
        } catch (\Throwable $e) {
            Log::warning('Support reply notify failed', ['error' => $e->getMessage()]);
        }

        return back()->with('success', 'Xabaringiz yuborildi.');
    }

    /**
     * Ticketni yopish (foydalanuvchi tomonidan)
     */
    public function close(SupportTicket $ticket)
    {
        if ((int) $ticket->user_id !== (int) auth()->id() && !auth()->user()->isAdmin()) {
            abort(403);
        }

        $ticket->update([
            'status'    => 'closed',
            'closed_at' => now(),
        ]);

        return back()->with('success', 'Ticket yopildi. Muammo hal bo\'lganidan xursandmiz!');
    }
}
