<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CatalogPageController extends Controller
{
    public function index()
    {
        try {
            $shops = \App\Models\Catalog\Shop::where('status', 'active')
                ->with('user')->paginate(12);
            $products = \App\Models\Catalog\Product::where('status', 'active')
                ->with('shop')->latest()->paginate(12, ['*'], 'product_page');
        } catch (\Exception $e) {
            $shops = new \Illuminate\Pagination\LengthAwarePaginator([], 0, 12);
            $products = new \Illuminate\Pagination\LengthAwarePaginator([], 0, 12);
        }

        return view('front.pages.catalog', compact('shops', 'products'));
    }

    public function createShop()
    {
        return view('front.pages.catalog_create_shop');
    }

    public function storeShop(Request $request)
    {
        $request->validate([
            'name'        => 'required|string|max:255',
            'category'    => 'required|string|max:100',
            'description' => 'nullable|string|max:3000',
            'address'     => 'required|string|max:255',
            'phone'       => 'required|string|max:20',
        ]);

        try {
            $user = auth()->user();
            $existing = \App\Models\Catalog\Shop::where('user_id', $user->id)->first();
            if ($existing) {
                return back()->withInput()->with('error', 'Sizda allaqachon do\'kon mavjud.');
            }

            $wallet = \App\Models\AIS\Wallet::where('user_id', $user->id)->first();
            if (!$wallet || $wallet->balance < 10) {
                return back()->withInput()->with('error', 'Do\'kon ochish uchun 10 AIS kerak.');
            }

            \Illuminate\Support\Facades\DB::transaction(function () use ($user, $wallet, $request) {
                $wallet->decrement('balance', 10);

                \App\Models\Catalog\Shop::create([
                    'user_id'     => $user->id,
                    'name'        => $request->name,
                    'category'    => $request->category,
                    'description' => $request->description,
                    'address'     => $request->address,
                    'phone'       => $request->phone,
                    'status'      => 'active',
                ]);
            });

            return redirect()->route('app.catalog')->with('success', 'Do\'kon yaratildi! 10 AIS yechildi.');
        } catch (\Exception $e) {
            return back()->withInput()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }

    public function createProduct()
    {
        $shops = \App\Models\Catalog\Shop::where('user_id', auth()->id())->get();
        if ($shops->isEmpty()) {
            return redirect()->route('app.catalog.shop.create')->with('error', 'Avval do\'kon oching.');
        }
        return view('front.pages.catalog_create_product', compact('shops'));
    }

    public function storeProduct(Request $request)
    {
        $request->validate([
            'shop_id'     => 'required|exists:shops,id',
            'name'        => 'required|string|max:255',
            'description' => 'nullable|string|max:3000',
            'price'       => 'required|numeric|min:0',
        ]);

        try {
            $shop = \App\Models\Catalog\Shop::where('id', $request->shop_id)
                ->where('user_id', auth()->id())->firstOrFail();

            \App\Models\Catalog\Product::create([
                'shop_id'     => $shop->id,
                'name'        => $request->name,
                'description' => $request->description,
                'price'       => $request->price,
                'status'      => 'active',
            ]);

            return redirect()->route('app.catalog')->with('success', 'Mahsulot qo\'shildi!');
        } catch (\Exception $e) {
            return back()->withInput()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }
}
