<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Package\Package;
use App\Models\Package\Mining;
use App\Models\Package\Purchase;
use App\Models\Finance\Commission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PackageController extends Controller
{
    public function index()
    {
        $packages = Package::active()->get();
        $myPurchases = auth()->user()->purchases()->pluck('package_id')->toArray();

        return view('front.pages.packages', compact('packages', 'myPurchases'));
    }

    public function buy(Request $request, Package $package)
    {
        $user = auth()->user();

        if ($user->isBanned()) {
            return back()->with('error', 'Hisobingiz bloklangan. Xarid qilib bo\'lmaydi.');
        }

        if ($package->status !== 'active') {
            return back()->with('error', 'Bu paket faol emas.');
        }

        try {
            $purchase = DB::transaction(function () use ($user, $package) {
                // Pessimistic lock — balansni qayta o'qish
                $user = \App\Models\User::lockForUpdate()->find($user->id);

                if ($user->balance < $package->price) {
                    throw new \Exception('Balansingiz yetarli emas. Avval depozit qiling.');
                }

                $balanceBefore = $user->balance;

                $user->decrement('balance', $package->price);
                $user->refresh();

                $purchase = Purchase::create([
                    'user_id'    => $user->id,
                    'package_id' => $package->id,
                    'amount'     => $package->price,
                    'status'     => 'active',
                    'started_at' => now(),
                    'expires_at' => now()->addDays($package->validity_days),
                ]);

                // Mining yozuvini yaratish
                $dailyProfit = $package->calcDailyProfit($package->price);
                $hourlyProfit = round($dailyProfit / 24, 4);
                $totalHours = $package->validity_days * 24;

                Mining::create([
                    'user_id'      => $user->id,
                    'package_id'   => $package->id,
                    'purchase_id'  => $purchase->id,
                    'started_at'   => now(),
                    'ended_at'     => now()->addDays($package->validity_days),
                    'total_hours'  => $totalHours,
                    'completed_hours' => 0,
                    'hourly_profit'   => $hourlyProfit,
                    'daily_profit'    => $dailyProfit,
                    'total_earned'    => 0,
                    'status'          => 'running',
                ]);

                $user->transactions()->create([
                    'amount'         => $package->price,
                    'type'           => 'mining',
                    'direction'      => 'debit',
                    'balance_before' => $balanceBefore,
                    'balance_after'  => $user->balance,
                    'status'         => 'completed',
                    'description'    => $package->getTranslation('name', app()->getLocale()) . ' paketi xarid qilindi',
                    'transactionable_type' => Purchase::class,
                    'transactionable_id'   => $purchase->id,
                ]);

                // Referral komissiya hisoblash (3 daraja)
                $this->processReferralCommissions($user, $package, $purchase);

                return $purchase;
            });
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }

        // XP: paket xaridi (transaction tashqarisida — kritik emas)
        $xpAmount = min(50, max(10, (int) ($package->price / 10000)));
        \App\Services\XpService::award(
            $user,
            \App\Models\Level\XpLog::ACTION_PURCHASE,
            $xpAmount,
            $package->getTranslation('name', app()->getLocale()) . ' paketi xarid qilindi',
            $purchase
        );

        // Quest progress
        \App\Services\QuestService::updateProgress($user, \App\Models\Game\Quest::REQ_PURCHASE_COUNT);

        // VIP cashback
        \App\Services\Marketing\MembershipService::applyCashback($user, $package->price, 'package_purchase');

        // Referral ga XP berish
        if ($user->referred_by) {
            $referrer = \App\Models\User::where('username', $user->referred_by)->first();
            if ($referrer) {
                \App\Services\XpService::award(
                    $referrer,
                    \App\Models\Level\XpLog::ACTION_REFERRAL,
                    20,
                    $user->name . ' paket xarid qildi',
                    $purchase
                );
            }
        }

        return redirect()->route('app.dashboard')->with('success', 'Paket muvaffaqiyatli xarid qilindi!');
    }

    /**
     * 3 darajali referral komissiya hisoblash
     */
    private function processReferralCommissions(\App\Models\User $user, Package $package, Purchase $purchase): void
    {
        $levels = [
            1 => $package->ref_level1,
            2 => $package->ref_level2,
            3 => $package->ref_level3,
        ];

        $current = $user;

        foreach ($levels as $level => $percent) {
            if ($percent <= 0) continue;

            $referrer = $current->referrer;
            if (!$referrer || $referrer->isBanned()) break;

            $commissionAmount = round($package->price * $percent / 100, 2);

            if ($commissionAmount > 0) {
                Commission::create([
                    'user_id'      => $referrer->id,
                    'from_user_id' => $user->id,
                    'reason'       => 'purchase',
                    'level'        => $level,
                    'percent'      => $percent,
                    'amount'       => $commissionAmount,
                    'date'         => now()->toDateString(),
                    'status'       => 'active',
                ]);

                $balanceBefore = $referrer->balance;
                $referrer->increment('balance', $commissionAmount);
                $referrer->refresh();

                $referrer->transactions()->create([
                    'amount'         => $commissionAmount,
                    'type'           => 'commission',
                    'direction'      => 'credit',
                    'balance_before' => $balanceBefore,
                    'balance_after'  => $referrer->balance,
                    'status'         => 'completed',
                    'description'    => "Level {$level} referral komissiya ({$percent}%): " . $user->name,
                    'transactionable_type' => Purchase::class,
                    'transactionable_id'   => $purchase->id,
                ]);
            }

            $current = $referrer;
        }
    }
}
