<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Game\CheckIn;
use App\Models\Level\XpLog;
use App\Services\Marketing\BadgeService;
use App\Services\XpService;
use Illuminate\Http\Request;

class CheckInController extends Controller
{
    public function store(Request $request)
    {
        $user = auth()->user();

        // Tezkor tekshiruv (lock'siz) — DB hit kamaytirish uchun
        if (CheckIn::todayFor($user->id)) {
            return back()->with('error', 'Bugun allaqachon belgiladingiz.');
        }

        // Streak hisoblash
        $yesterday = CheckIn::where('user_id', $user->id)
            ->whereDate('checked_at', today()->subDay())
            ->first();

        $streak = $yesterday ? ($yesterday->streak + 1) : 1;

        // Streak asosida reward
        $reward = match(true) {
            $streak >= 30 => 50.0,
            $streak >= 14 => 30.0,
            $streak >= 7  => 20.0,
            $streak >= 3  => 10.0,
            default       => 5.0,
        };

        try {
            $checkIn = \Illuminate\Support\Facades\DB::transaction(function () use ($user, $streak, $reward) {
                // Lock bilan qayta tekshirish — race condition oldini olish
                $alreadyChecked = CheckIn::where('user_id', $user->id)
                    ->whereDate('checked_at', today())
                    ->lockForUpdate()
                    ->exists();

                if ($alreadyChecked) {
                    throw new \Exception('Bugun allaqachon belgiladingiz.');
                }

                $checkIn = CheckIn::create([
                    'user_id'    => $user->id,
                    'checked_at' => today(),
                    'reward'     => $reward,
                    'streak'     => $streak,
                ]);

                // Balance lock bilan
                $lockedUser = \App\Models\User::lockForUpdate()->find($user->id);
                $lockedUser->increment('balance', $reward);

                return $checkIn;
            });
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }

        // XP berish (streak asosida ko'proq XP)
        $xp = 10 + min($streak * 2, 30); // max 40 XP
        XpService::award(
            $user,
            XpLog::ACTION_CHECKIN,
            $xp,
            "Kunlik belgilash (streak: {$streak})",
            $checkIn
        );

        // Quest progress — streak asosida
        \App\Services\QuestService::updateProgress($user, \App\Models\Game\Quest::REQ_CHECKIN_STREAK, $streak);

        // Badge tekshirish va berish
        BadgeService::checkAndAward($user, $streak);

        return back()->with('success',
            "✅ Kunlik belgilash! +{$reward} UZS, +{$xp} XP. Streak: {$streak} kun 🔥"
        );
    }
}
