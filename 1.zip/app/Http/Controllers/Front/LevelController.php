<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Level\LevelConfig;
use App\Models\Level\UserLevel;
use App\Models\Level\XpLog;

class LevelController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $userLevel = UserLevel::firstOrCreate(['user_id' => $user->id], [
            'level' => 0, 'total_xp' => 0, 'current_xp' => 0,
            'next_level_xp' => 100, 'title' => 'Newcomer', 'badge_color' => '#64748b',
        ]);

        // Joriy va keyingi daraja konfiguratsiyasi
        $currentConfig = LevelConfig::getForLevel($userLevel->level);
        $nextConfig    = LevelConfig::getForLevel(min(99, $userLevel->level + 1));

        // So'nggi XP loglari
        $xpLogs = XpLog::where('user_id', $user->id)
            ->latest()->limit(20)->get();

        // Barcha darajalar (progress uchun)
        $milestones = LevelConfig::orderBy('level')->get();

        // Leaderboard top 3
        $topUsers = UserLevel::with('user')
            ->orderByDesc('total_xp')
            ->limit(3)
            ->get();

        // Foydalanuvchi reytingi
        $userRank = UserLevel::where('total_xp', '>', $userLevel->total_xp)->count() + 1;

        return view('front.pages.level', compact(
            'userLevel', 'currentConfig', 'nextConfig',
            'xpLogs', 'milestones', 'topUsers', 'userRank'
        ));
    }

    public function leaderboard()
    {
        $topUsers = UserLevel::with('user')
            ->orderByDesc('total_xp')
            ->limit(50)
            ->get();

        $userLevel = UserLevel::where('user_id', auth()->id())->first();
        $userRank  = UserLevel::where('total_xp', '>', $userLevel?->total_xp ?? 0)->count() + 1;

        return view('front.pages.leaderboard', compact('topUsers', 'userLevel', 'userRank'));
    }
}
