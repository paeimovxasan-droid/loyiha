<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Payment\Deposit;
use App\Models\Payment\PaymentMethod;
use App\Models\Payment\Withdrawal;
use Illuminate\Http\Request;

class WithdrawalController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $methods = PaymentMethod::active()->get();
        $withdrawals = $user->withdrawals()->with('paymentMethod')->latest()->paginate(10);
        $setting = \App\Models\Setting::get();

        // Withdrawal scoring
        $scoring = \App\Services\WithdrawalScoringService::calculate($user);

        // Oxirgi yechishdan keyin yangi depozit bormi?
        $lastWithdrawal = Withdrawal::where('user_id', $user->id)->latest()->first();
        $needsNewDeposit = false;
        if ($lastWithdrawal) {
            $needsNewDeposit = !Deposit::where('user_id', $user->id)
                ->where('status', 'approved')
                ->where('final_amount', '>=', $setting->min_deposit)
                ->where('created_at', '>', $lastWithdrawal->created_at)
                ->exists();
        }

        return view('front.pages.withdraw', compact('methods', 'withdrawals', 'setting', 'scoring', 'needsNewDeposit'));
    }

    public function store(Request $request)
    {
        $user = auth()->user();
        $setting = \App\Models\Setting::get();

        if ($user->isBanned()) {
            return back()->with('error', 'Hisobingiz bloklangan. Yechib olish mumkin emas.');
        }

        $request->validate([
            'payment_method_id' => 'required|exists:payment_methods,id',
            'amount'            => "required|numeric|min:{$setting->min_withdraw}|max:{$setting->max_withdraw}",
            'account_number'    => 'required|string|max:64',
        ]);

        // ═══ WITHDRAWAL SCORING TEKSHIRUVI ═══
        $scoring = \App\Services\WithdrawalScoringService::calculate($user);
        if (!$scoring['can_withdraw']) {
            return back()->with('error', $scoring['message']);
        }

        // ═══ HAR YECHISH OLDIDAN YANGI DEPOZIT MAJBURIY ═══
        // Oxirgi yechish so'rovidan keyin kamida 1 ta yangi depozit bo'lishi kerak
        $lastWithdrawal = Withdrawal::where('user_id', $user->id)
            ->latest()
            ->first();

        $lastWithdrawalDate = $lastWithdrawal?->created_at;

        $newDepositAfterLastWithdrawal = \App\Models\Payment\Deposit::where('user_id', $user->id)
            ->where('status', 'approved')
            ->where('final_amount', '>=', $setting->min_deposit)
            ->when($lastWithdrawalDate, fn($q) => $q->where('created_at', '>', $lastWithdrawalDate))
            ->exists();

        if ($lastWithdrawal && !$newDepositAfterLastWithdrawal) {
            return back()->with('error',
                "Har yechish oldidan yangi depozit qilish majburiy. " .
                "Kamida " . number_format($setting->min_deposit, 0) . " UZS miqdorida depozit qiling."
            );
        }

        // Withdrawal cooldown tekshiruvi (1 kun)
        $cooldownDays = config('anti-fraud.fraud_thresholds.withdrawal_cooldown_days', 1);
        $lastDeposit = Deposit::where('user_id', $user->id)
            ->where('status', 'approved')
            ->latest('approved_at')
            ->first();

        // Hech qachon depozit qilmagan foydalanuvchi yechib ola olmaydi
        if (!$lastDeposit) {
            return back()->with('error', "Yechib olish uchun kamida bitta tasdiqlangan depozit bo'lishi kerak.");
        }

        // Yangi depozit talabi — so'nggi 7 kunda kamida 1 ta depozit bo'lishi kerak
        $recentDeposit = Deposit::where('user_id', $user->id)
            ->where('status', 'approved')
            ->where('created_at', '>=', now()->subDays(7))
            ->exists();

        if (!$recentDeposit) {
            return back()->with('error', "Yechib olish uchun so'nggi 7 kun ichida kamida 1 ta yangi depozit qilishingiz kerak.");
        }

        // Cooldown tekshiruvi
        $depositDate = $lastDeposit->deposited_at ?? $lastDeposit->approved_at ?? $lastDeposit->updated_at;
        if ($depositDate) {
            $daysSinceDeposit = (int) $depositDate->diffInDays(now());
            if ($daysSinceDeposit < $cooldownDays) {
                $daysLeft = $cooldownDays - $daysSinceDeposit;
                return back()->with('error', "Yechib olish uchun yana {$daysLeft} kun kutishingiz kerak. Depozit qilinganidan {$cooldownDays} kun o'tishi shart.");
            }
        }

        $method = PaymentMethod::findOrFail($request->payment_method_id);

        // Komissiya: global fee + payment method fee
        $setting         = \App\Models\Setting::get();
        $globalFeePercent = (float) ($setting->withdrawal_fee_percent ?? 1.0);
        $methodFeePercent = (float) ($method->withdraw_charge_percent ?? 0);
        $totalFeePercent  = $globalFeePercent + $methodFeePercent;

        $charge      = round($request->amount * $totalFeePercent / 100, 2);
        $finalAmount = round($request->amount - $charge, 2);

        try {
            \Illuminate\Support\Facades\DB::transaction(function () use ($user, $method, $request, $charge, $finalAmount) {
                // Pessimistic lock
                $user = \App\Models\User::lockForUpdate()->find($user->id);

                if ($user->balance < $request->amount) {
                    throw new \Exception('Balansingiz yetarli emas.');
                }

                $balanceBefore = $user->balance;

                $user->decrement('balance', $request->amount);
                $user->refresh();

                $withdrawal = Withdrawal::create([
                    'user_id'           => $user->id,
                    'payment_method_id' => $method->id,
                    'method_name'       => $method->getTranslation('name', app()->getLocale()),
                    'receiver_number'   => $request->account_number,
                    'amount'            => $request->amount,
                    'charge'            => $charge,
                    'final_amount'      => $finalAmount,
                    'status'            => 'pending',
                ]);

                $user->transactions()->create([
                    'amount'                => $request->amount,
                    'type'                  => 'withdraw',
                    'direction'             => 'debit',
                    'balance_before'        => $balanceBefore,
                    'balance_after'         => $user->balance,
                    'status'                => 'pending',
                    'description'           => $method->getTranslation('name', app()->getLocale()) . ' ga pul yechish so\'rovi',
                    'transactionable_type'  => Withdrawal::class,
                    'transactionable_id'    => $withdrawal->id,
                ]);
            });
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }

        // Admin ga Telegram bildirishnoma (tugma bilan)
        try {
            \App\Services\TelegramBotService::notifyAdminNewWithdrawal(
                "{$user->name} (@{$user->username})",
                $request->amount,
                Withdrawal::where('user_id', $user->id)->latest()->first()?->id ?? 0
            );
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Withdrawal notify failed', ['error' => $e->getMessage()]);
        }

        return back()->with('success', 'Yechish so\'rovi yuborildi. Admin tasdiqlashini kuting.');
    }
}