<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SavingsPageController extends Controller
{
    public function index()
    {
        try {
            $plans = \App\Models\Savings\SavingsPlan::where('user_id', auth()->id())
                ->latest()->get();
            $activePlan = $plans->where('status', 'active')->first();
        } catch (\Exception $e) {
            $plans = collect();
            $activePlan = null;
        }

        return view('front.pages.savings', compact('plans', 'activePlan'));
    }

    public function create(Request $request)
    {
        $request->validate([
            'term_months'    => 'required|integer|in:3,6,12',
            'monthly_amount' => 'required|numeric|min:10000',
            'currency'       => 'nullable|in:UZS,AIS',
        ]);

        try {
            \App\Services\Savings\SavingsService::createPlan(
                auth()->user(),
                (int) $request->term_months,
                (float) $request->monthly_amount,
                $request->currency ?? 'UZS'
            );

            return back()->with('success', 'Jamg\'arma rejasi yaratildi!');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
