<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Marketing\SpinWheelLog;
use App\Models\Marketing\SpinWheelPrize;
use App\Services\Marketing\SpinWheelService;
use Illuminate\Http\Request;

class SpinWheelController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $canSpin = SpinWheelService::canSpin($user);

        $prizes = SpinWheelPrize::active()->orderBy('id')->get();

        $history = SpinWheelLog::where('user_id', $user->id)
            ->orderByDesc('created_at')
            ->limit(10)
            ->get();

        $lastSpin = SpinWheelLog::where('user_id', $user->id)
            ->where('spun_at', today())
            ->first();

        $nextSpinAt = $lastSpin
            ? today()->addDay()->startOfDay()
            : null;

        return view('front.pages.spin_wheel', compact('canSpin', 'prizes', 'history', 'nextSpinAt'));
    }

    public function spin(Request $request)
    {
        try {
            $result = SpinWheelService::spin(auth()->user());

            return back()->with('spin_result', $result);
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
