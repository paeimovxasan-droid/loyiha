<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Game\Quest;
use App\Models\Game\UserQuest;
use App\Services\QuestService;
use Illuminate\Http\Request;

class QuestController extends Controller
{
    public function index()
    {
        $user   = auth()->user();
        $quests = QuestService::getForUser($user);

        // Kategoriyalar bo'yicha guruhlash
        $grouped = $quests->groupBy(fn($uq) => $uq->quest?->category ?? 'general');

        $stats = [
            'total'     => $quests->count(),
            'completed' => $quests->filter(fn($uq) => $uq->isCompleted())->count(),
            'claimed'   => $quests->filter(fn($uq) => $uq->isClaimed())->count(),
            'available' => $quests->filter(fn($uq) => !$uq->isClaimed())->count(),
        ];

        return view('front.pages.quests', compact('quests', 'grouped', 'stats'));
    }

    public function claim(Request $request, UserQuest $userQuest)
    {
        // UserQuest topilmasa
        if (!$userQuest || !$userQuest->exists) {
            return back()->with('error', 'Kvest topilmadi.');
        }

        // Faqat o'z kvestini claim qilishi mumkin
        if ((int) $userQuest->user_id !== (int) auth()->id()) {
            abort(403);
        }

        try {
            $rewards = QuestService::claim(auth()->user(), $userQuest);

            $msg = 'Mukofot olindi! ';
            if (!empty($rewards['ais']))  $msg .= number_format($rewards['ais'], 2) . ' AIS ';
            if (!empty($rewards['uzs']))  $msg .= number_format($rewards['uzs'], 0) . ' UZS ';
            if (!empty($rewards['xp']))   $msg .= '+' . $rewards['xp'] . ' XP ';

            return back()->with('success', trim($msg));
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
