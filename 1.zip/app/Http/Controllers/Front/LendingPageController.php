<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class LendingPageController extends Controller
{
    public function index()
    {
        try {
            $offers = \App\Models\Lending\LoanOffer::where('status', 'active')
                ->with('lender')->latest()->paginate(12);
            $myLoans = \App\Models\Lending\Loan::where('borrower_id', auth()->id())
                ->with('lender')->latest()->get();
            $myOffers = \App\Models\Lending\LoanOffer::where('lender_id', auth()->id())
                ->latest()->get();
        } catch (\Exception $e) {
            $offers = new \Illuminate\Pagination\LengthAwarePaginator([], 0, 12);
            $myLoans = collect();
            $myOffers = collect();
        }

        return view('front.pages.lending', compact('offers', 'myLoans', 'myOffers'));
    }

    public function createOffer()
    {
        return view('front.pages.lending_create');
    }

    public function storeOffer(Request $request)
    {
        $request->validate([
            'amount'        => 'required|numeric|min:1',
            'interest_rate' => 'required|numeric|min:0|max:100',
            'duration_days' => 'required|integer|min:1|max:365',
            'description'   => 'nullable|string|max:500',
        ]);

        try {
            \App\Services\LendingService::createOffer(auth()->user(), $request->only([
                'amount', 'interest_rate', 'duration_days', 'description',
            ]));

            return redirect()->route('app.lending')->with('success', 'Kredit taklifi yaratildi!');
        } catch (\Exception $e) {
            return back()->withInput()->with('error', $e->getMessage());
        }
    }

    public function borrow(Request $request, $offerId)
    {
        try {
            $offer = \App\Models\Lending\LoanOffer::where('id', $offerId)
                ->where('status', 'active')->firstOrFail();

            $loan = \App\Services\LendingService::acceptOffer(auth()->user(), $offer);

            return back()->with('success', number_format($offer->amount, 4) . ' AIS qarz olindi!');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
