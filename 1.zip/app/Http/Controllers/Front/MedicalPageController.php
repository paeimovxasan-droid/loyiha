<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Medical\Consultation;
use App\Models\Medical\DoctorProfile;
use App\Models\Medical\HomeVisit;
use App\Models\Medical\MedicineOrder;
use App\Services\Medical\MedicalService;
use Illuminate\Http\Request;

class MedicalPageController extends Controller
{
    /**
     * Tibbiyot xizmatlari bosh sahifasi
     */
    public function index()
    {
        $specialties = DoctorProfile::SPECIALTIES;
        $topDoctors = DoctorProfile::approved()
            ->with('user:id,name,avatar')
            ->orderByDesc('rating')
            ->limit(6)
            ->get();

        return view('front.pages.medical.index', compact('specialties', 'topDoctors'));
    }

    /**
     * Shifokorlar ro'yxati
     */
    public function doctors(Request $request)
    {
        $query = DoctorProfile::approved()->with('user:id,name,avatar');

        if ($request->filled('specialty')) {
            $query->bySpecialty($request->specialty);
        }

        $doctors = $query->orderByDesc('is_online')->orderByDesc('rating')->paginate(12);
        $specialties = DoctorProfile::SPECIALTIES;

        return view('front.pages.medical.doctors', compact('doctors', 'specialties'));
    }

    /**
     * Shifokor profili
     */
    public function doctorShow(DoctorProfile $doctorProfile)
    {
        if (!$doctorProfile->isApproved()) {
            return redirect()->route('app.medical.doctors')->with('error', 'Shifokor topilmadi.');
        }

        $doctorProfile->load(['user:id,name,avatar', 'reviews' => fn($q) => $q->with('patient:id,name')->latest()->limit(10)]);

        return view('front.pages.medical.doctor-show', compact('doctorProfile'));
    }

    /**
     * Maslahat boshlash
     */
    public function startConsultation(Request $request)
    {
        $request->validate(['doctor_profile_id' => 'required|exists:doctor_profiles,id']);

        $user = auth()->user();
        $doctorProfile = DoctorProfile::findOrFail($request->doctor_profile_id);

        if ($doctorProfile->user_id === $user->id) {
            return back()->with('error', 'O\'zingizdan maslahat ololmaysiz.');
        }

        try {
            $consultation = MedicalService::startConsultation($user, $doctorProfile);
            return redirect()->route('app.medical.consultation', $consultation)->with('success', 'Maslahat so\'rovi yuborildi!');
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }

    /**
     * Mening maslahatlarim
     */
    public function consultations()
    {
        $user = auth()->user();
        $consultations = Consultation::where(function ($q) use ($user) {
            $q->where('patient_id', $user->id)->orWhere('doctor_id', $user->id);
        })->with(['patient:id,name,avatar', 'doctor:id,name,avatar', 'doctorProfile:id,specialty'])
          ->latest()
          ->paginate(15);

        return view('front.pages.medical.consultations', compact('consultations'));
    }

    /**
     * Maslahat chat sahifasi
     */
    public function consultation(Consultation $consultation)
    {
        $user = auth()->user();

        if ($consultation->patient_id !== $user->id && $consultation->doctor_id !== $user->id) {
            abort(403);
        }

        $consultation->load([
            'patient:id,name,avatar',
            'doctor:id,name,avatar',
            'doctorProfile:id,specialty,workplace',
            'messages' => fn($q) => $q->with('sender:id,name')->oldest(),
            'prescriptions.items',
            'referrals',
        ]);

        $isDoctor = $consultation->doctor_id === $user->id;

        return view('front.pages.medical.consultation-chat', compact('consultation', 'isDoctor'));
    }

    /**
     * Shifokor profili yaratish sahifasi
     */
    public function doctorProfileCreate()
    {
        $user = auth()->user();
        $profile = DoctorProfile::where('user_id', $user->id)->first();

        if ($profile) {
            return redirect()->route('app.medical.doctor.dashboard');
        }

        return view('front.pages.medical.doctor-profile-create', [
            'specialties' => DoctorProfile::SPECIALTIES,
        ]);
    }

    /**
     * Shifokor dashboard
     */
    public function doctorDashboard()
    {
        $user = auth()->user();
        $profile = DoctorProfile::where('user_id', $user->id)->first();

        if (!$profile) {
            return redirect()->route('app.medical.doctor.create');
        }

        $pendingConsultations = Consultation::where('doctor_id', $user->id)
            ->pending()->latest()->limit(5)->get();

        $activeConsultations = Consultation::where('doctor_id', $user->id)
            ->active()->latest()->limit(5)->get();

        $stats = [
            'total_consultations' => Consultation::where('doctor_id', $user->id)->completed()->count(),
            'total_earnings'      => Consultation::where('doctor_id', $user->id)->completed()->sum('doctor_earning'),
            'monthly_earnings'    => Consultation::where('doctor_id', $user->id)->completed()
                ->where('completed_at', '>=', now()->startOfMonth())->sum('doctor_earning'),
            'pending_home_visits' => HomeVisit::where('doctor_id', $user->id)->pending()->count(),
        ];

        return view('front.pages.medical.doctor-dashboard', compact('profile', 'pendingConsultations', 'activeConsultations', 'stats'));
    }

    /**
     * Mening buyurtmalarim
     */
    public function medicineOrders()
    {
        $orders = MedicineOrder::where('patient_id', auth()->id())
            ->with('items')
            ->latest()
            ->paginate(15);

        return view('front.pages.medical.medicine-orders', compact('orders'));
    }
}
