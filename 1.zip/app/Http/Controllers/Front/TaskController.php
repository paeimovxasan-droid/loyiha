<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Game\Task;
use App\Models\Game\UserTask;
use App\Services\XpService;
use App\Models\Level\XpLog;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function index()
    {
        $user  = auth()->user();

        $maxPackageLevel = $user->purchases()
            ->where('status', 'active')
            ->count();

        $tasks = Task::where('status', 'active')
            ->where('required_package_level', '<=', $maxPackageLevel)
            ->orderBy('sort_order')
            ->get();

        // Har bir topshiriq uchun oxirgi yuborish holatini olish
        $myTasks = UserTask::where('user_id', $user->id)
            ->orderByDesc('id')
            ->get()
            ->unique('task_id')
            ->pluck('status', 'task_id');

        return view('front.pages.tasks', compact('tasks', 'myTasks'));
    }

    public function submit(Request $request, Task $task)
    {
        $user = auth()->user();

        // Faqat pending holatdagi yuborishni tekshirish (takroriy yuborishga ruxsat)
        $lastSubmission = UserTask::where('user_id', $user->id)
            ->where('task_id', $task->id)
            ->latest()
            ->first();

        if ($lastSubmission && $lastSubmission->status === 'pending') {
            return back()->with('error', 'Bu topshiriq hali ko\'rib chiqilmoqda. Admin javobini kuting.');
        }

        $request->validate([
            'proof'      => 'nullable|string|max:500',
            'proof_file' => 'nullable|file|mimes:jpg,jpeg,png,webp,mp4,webm|max:30720', // max 30MB
        ]);

        $proofFilePath = null;
        if ($request->hasFile('proof_file')) {
            $file = \App\Services\FileUploadService::upload($request->file('proof_file'), 'task-proofs');
            $proofFilePath = $file->path;
        }

        UserTask::create([
            'user_id'    => $user->id,
            'task_id'    => $task->id,
            'proof'      => $request->proof,
            'proof_file' => $proofFilePath,
            'status'     => 'pending',
        ]);

        return back()->with('success', 'Topshiriq yuborildi. Admin tasdiqlashini kuting.');
    }
}
