<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\AiAssistant\AiConversation;
use App\Models\AiAssistant\AiMessage;
use App\Models\AiAssistant\FaqEntry;
use Illuminate\Http\Request;

class AiAssistantController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $conversation = AiConversation::firstOrCreate(
            ['user_id' => $user->id],
            ['title' => 'Chat']
        );
        $messages = $conversation->messages()->oldest()->get();
        $categories = FaqEntry::active()
            ->whereNotNull('category')
            ->distinct()->pluck('category');
        $faqs = FaqEntry::active()->get();

        return view('front.pages.ai_assistant', compact(
            'conversation', 'messages', 'categories', 'faqs'
        ));
    }

    public function send(Request $request)
    {
        $request->validate(['message' => 'required|string|max:1000']);

        $user = auth()->user();
        $conversation = AiConversation::firstOrCreate(
            ['user_id' => $user->id],
            ['title' => 'Chat']
        );

        // User xabarini saqlash
        $conversation->messages()->create([
            'role' => 'user',
            'content' => $request->message,
        ]);

        // FAQ dan javob qidirish
        $answer = $this->findAnswer($request->message);

        $conversation->messages()->create([
            'role' => 'assistant',
            'content' => $answer['text'],
            'faq_entry_id' => $answer['faq_id'],
        ]);

        return back();
    }

    private function findAnswer(string $question): array
    {
        $q = mb_strtolower(trim($question));

        // 1. Kalit so'zlar bo'yicha qidirish
        $faqs = FaqEntry::active()->get();
        $bestMatch = null;
        $bestScore = 0;

        foreach ($faqs as $faq) {
            $score = 0;
            $keywords = array_filter(array_map('trim', explode(',', $faq->keywords ?? '')));

            foreach ($keywords as $kw) {
                if (mb_stripos($q, mb_strtolower($kw)) !== false) {
                    $score += 3;
                }
            }

            // Savol o'xshashligini tekshirish
            similar_text($q, mb_strtolower($faq->question), $percent);
            $score += $percent / 20;

            if ($score > $bestScore) {
                $bestScore = $score;
                $bestMatch = $faq;
            }
        }

        if ($bestMatch && $bestScore >= 2) {
            return ['text' => $bestMatch->answer, 'faq_id' => $bestMatch->id];
        }

        return [
            'text' => 'Kechirasiz, savolingizga javob topa olmadim. Iltimos, boshqacha so\'rang yoki admin bilan bog\'laning.',
            'faq_id' => null,
        ];
    }
}
