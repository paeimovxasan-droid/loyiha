<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Payment\Deposit;
use App\Models\Payment\PaymentMethod;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class DepositController extends Controller
{
    public function index()
    {
        $methods = PaymentMethod::active()->get();
        $deposits = auth()->user()->deposits()->with('paymentMethod')->latest()->paginate(10);
        $setting = \App\Models\Setting::get();

        return view('front.pages.deposit', compact('methods', 'deposits', 'setting'));
    }

    public function store(Request $request)
    {
        $setting = \App\Models\Setting::get();
        $user = auth()->user();

        if ($user->isBanned()) {
            return back()->with('error', 'Hisobingiz bloklangan.');
        }

        $request->validate([
            'payment_method_id' => 'required|exists:payment_methods,id',
            'amount'            => "required|numeric|min:{$setting->min_deposit}|max:{$setting->max_deposit}",
            'sender_number'     => ['required', 'string', 'max:64', 'regex:/^[\d\s\+\-\(\)]+$/'],
            'screenshot'        => 'nullable|image|max:5120',
        ]);

        $method = PaymentMethod::findOrFail($request->payment_method_id);
        $charge = round($request->amount * $method->deposit_charge_percent / 100, 2);
        $finalAmount = $request->amount - $charge;

        $screenshotPath = null;
        if ($request->hasFile('screenshot')) {
            $file = \App\Services\FileUploadService::upload($request->file('screenshot'), 'deposits/screenshots');
            $screenshotPath = $file->path;
        }

        $deposit = Deposit::create([
            'user_id'           => $user->id,
            'payment_method_id' => $method->id,
            'method_name'       => $method->getTranslation('name', app()->getLocale()),
            'method_number'     => $method->number,
            'order_id'          => (string) Str::uuid(),
            'sender_number'     => $request->sender_number,
            'amount'            => $request->amount,
            'charge'            => $charge,
            'final_amount'      => $finalAmount,
            'screenshot'        => $screenshotPath,
            'status'            => 'pending',
        ]);

        // Fraud detection: VPN check + yangi foydalanuvchi katta depozit
        try {
            \App\Services\Security\FraudDetectionService::onDeposit($user, $deposit, $request);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('FraudDetection onDeposit failed', ['error' => $e->getMessage()]);
        }

        // Admin ga Telegram bildirishnoma (tugma bilan)
        try {
            \App\Services\TelegramBotService::notifyAdminNewDeposit(
                "{$user->name} (@{$user->username})",
                $request->amount,
                $deposit->id
            );
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Deposit notify failed', ['error' => $e->getMessage()]);
        }

        // Birinchi haqiqiy depozit uchun behavioral score +20 (faqat bir marta)
        try {
            $approvedCount = Deposit::where('user_id', $user->id)->where('status', 'approved')->count();
            if ($approvedCount === 0) {
                \App\Services\Security\BehavioralScoreService::adjust($user, 20, 'first_deposit');
            }
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('BehavioralScore first_deposit failed', ['error' => $e->getMessage()]);
        }

        return back()->with('success', 'Depozit so\'rovi yuborildi. Admin tasdiqlashini kuting.');
    }
}
