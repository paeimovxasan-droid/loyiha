<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GigPageController extends Controller
{
    public function index()
    {
        try {
            $gigs = \App\Models\GigEconomy\GigListing::where('status', 'open')
                ->with('user')->latest()->paginate(12);
        } catch (\Exception $e) {
            $gigs = new \Illuminate\Pagination\LengthAwarePaginator([], 0, 12);
        }

        return view('front.pages.gig', compact('gigs'));
    }

    public function create()
    {
        return view('front.pages.gig_create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'required|string|max:5000',
            'category'    => 'required|in:yuk_tashish,tozalash,qurilish,kuryer',
            'location'    => 'required|string|max:255',
            'price'       => 'required|numeric|min:1',
            'work_date'   => 'required|date|after_or_equal:today',
        ]);

        try {
            \App\Models\GigEconomy\GigListing::create([
                'user_id'     => auth()->id(),
                'title'       => $request->title,
                'description' => $request->description,
                'category'    => $request->category,
                'location'    => $request->location,
                'price'       => $request->price,
                'work_date'   => $request->work_date,
                'status'      => 'open',
            ]);

            return redirect()->route('app.gig')->with('success', 'E\'lon muvaffaqiyatli yaratildi!');
        } catch (\Exception $e) {
            return back()->withInput()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }
}
