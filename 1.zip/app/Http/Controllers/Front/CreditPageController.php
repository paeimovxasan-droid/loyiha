<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class CreditPageController extends Controller
{
    public function index()
    {
        try {
            $credits = \App\Models\Credit\Credit::where('user_id', auth()->id())
                ->latest()->get();
            $activeCredit = $credits->where('status', 'active')->first();
        } catch (\Exception $e) {
            $credits = collect();
            $activeCredit = null;
        }

        return view('front.pages.credit', compact('credits', 'activeCredit'));
    }

    public function apply(Request $request)
    {
        $request->validate([
            'amount'    => 'required|numeric|min:10000|max:500000',
            'term_days' => 'required|integer|in:7,14,30',
            'currency'  => 'nullable|in:UZS,AIS',
        ]);

        try {
            $result = \App\Services\Credit\CreditService::issue(
                auth()->user(),
                (float) $request->amount,
                (int) $request->term_days,
                $request->currency ?? 'UZS'
            );

            return back()->with('success',
                number_format($request->amount) . ' UZS kredit berildi! ' .
                'Qaytarish sanasi: ' . $result->due_date->format('d.m.Y')
            );
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
