<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;

class MarketplacePageController extends Controller
{
    public function index()
    {
        try {
            $gigs = \App\Models\Marketplace\Gig::where('status', 'active')
                ->with('user', 'category')->latest()->paginate(12);
        } catch (\Exception $e) {
            $gigs = new \Illuminate\Pagination\LengthAwarePaginator([], 0, 12);
        }

        return view('front.pages.marketplace', compact('gigs'));
    }
}
