<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Services\FileUploadService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth()->user();

        $stats = [
            'balance'       => $user->balance,
            'total_earn'    => $user->transactions()->where('type', 'mining')->where('direction', 'credit')->sum('amount'),
            'total_deposit' => $user->deposits()->where('status', 'approved')->sum('amount'),
            'total_ref'     => $user->referrals()->count(),
        ];

        $activePurchases = $user->purchases()
            ->with('package')
            ->where('status', 'active')
            ->get();

        $recentTransactions = $user->transactions()
            ->latest()
            ->limit(3)
            ->get();

        return view('front.pages.dashboard', compact('stats', 'activePurchases', 'recentTransactions'));
    }

    public function profile()
    {
        $user = auth()->user();
        return view('front.pages.profile', compact('user'));
    }

    public function updateProfile(Request $request)
    {
        $user = auth()->user();

        $request->validate([
            'name'     => 'required|string|max:100',
            'username' => 'required|string|alpha_dash|max:30|unique:users,username,' . $user->id,
            'email'    => 'required|email|unique:users,email,' . $user->id,
            'phone'    => 'nullable|string|max:20',
            'avatar'   => 'nullable|image|max:5120',
        ]);

        $data = $request->only('name', 'username', 'email', 'phone');

        if ($request->hasFile('avatar')) {
            $file = FileUploadService::upload($request->file('avatar'), 'avatars');
            $data['avatar'] = $file->path;
        }

        $user->update($data);

        // Profil to'ldirilganda XP (bir marta)
        $alreadyAwarded = \App\Models\Level\XpLog::where('user_id', $user->id)
            ->where('action', \App\Models\Level\XpLog::ACTION_PROFILE)
            ->exists();
        if (!$alreadyAwarded) {
            \App\Services\XpService::award($user, \App\Models\Level\XpLog::ACTION_PROFILE, 30, 'Profil to\'ldirildi');
            \App\Services\QuestService::updateProgress($user, \App\Models\Game\Quest::REQ_PROFILE_FILL);
        }

        return back()->with('success', 'Profil muvaffaqiyatli yangilandi.');
    }

    public function updatePassword(Request $request)
    {
        $user = auth()->user();

        $request->validate([
            'current_password' => 'required|string',
            'password'         => ['required', 'confirmed', Password::min(8)],
        ]);

        if (!Hash::check($request->current_password, $user->password)) {
            return back()->withErrors(['current_password' => 'Joriy parol noto\'g\'ri.']);
        }

        $user->update(['password' => Hash::make($request->password)]);

        return back()->with('success', 'Parol muvaffaqiyatli yangilandi.');
    }
}
