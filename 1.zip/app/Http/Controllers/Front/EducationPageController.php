<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class EducationPageController extends Controller
{
    public function index()
    {
        try {
            $courses = \App\Models\Education\Course::where('status', 'published')
                ->with('user')->latest()->paginate(12);
        } catch (\Exception $e) {
            $courses = new \Illuminate\Pagination\LengthAwarePaginator([], 0, 12);
        }

        return view('front.pages.education', compact('courses'));
    }

    public function create()
    {
        return view('front.pages.education_create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'required|string|max:5000',
            'category'    => 'required|string|max:100',
            'price'       => 'required|numeric|min:0',
        ]);

        try {
            \App\Models\Education\Course::create([
                'user_id'     => auth()->id(),
                'title'       => $request->title,
                'description' => $request->description,
                'category'    => $request->category,
                'price'       => $request->price,
                'status'      => 'draft',
            ]);

            return redirect()->route('app.education')->with('success', 'Kurs yaratildi! Admin tekshiruvidan keyin chop etiladi.');
        } catch (\Exception $e) {
            return back()->withInput()->with('error', 'Xatolik: ' . $e->getMessage());
        }
    }
}
