<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;

class ReferralController extends Controller
{
    public function index()
    {
        $user = auth()->user();
        $referrals = $user->referrals()->latest()->paginate(20);
        $totalCommission = $user->commissions()->sum('amount');

        return view('front.pages.referrals', compact('referrals', 'totalCommission'));
    }
}
