<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Game\LuckyDraw;
use App\Models\Game\LuckyDrawTicket;
use App\Services\XpService;
use App\Models\Level\XpLog;
use Illuminate\Http\Request;

class LuckyDrawController extends Controller
{
    public function index()
    {
        $draws   = LuckyDraw::where('status', 'active')->latest()->get();

        // Oxirgi tugagan o'yinlar (g'oliblar)
        $recentWinners = LuckyDraw::with('winner')
            ->where('status', 'completed')
            ->whereNotNull('winner_id')
            ->latest('drawn_at')
            ->limit(5)
            ->get();

        $myTickets = LuckyDrawTicket::where('user_id', auth()->id())
            ->with('luckyDraw')->latest()->limit(10)->get();

        return view('front.pages.lucky_draw', compact('draws', 'myTickets', 'recentWinners'));
    }

    public function buy(Request $request, LuckyDraw $draw)
    {
        $request->validate([
            'quantity' => 'required|integer|min:1|max:100',
        ]);

        if ($draw->status !== 'active') {
            return back()->with('error', 'Bu o\'yin faol emas.');
        }

        $user = auth()->user();

        if ($user->isBanned()) {
            return back()->with('error', 'Hisobingiz bloklangan.');
        }

        $quantity = (int) $request->quantity;
        $total    = $draw->entry_fee * $quantity;

        try {
            \Illuminate\Support\Facades\DB::transaction(function () use ($user, $draw, $quantity, $total) {
                $user = \App\Models\User::lockForUpdate()->find($user->id);

                if ($user->balance < $total) {
                    throw new \Exception('Balansingiz yetarli emas.');
                }

                // Limit tekshirish — lock bilan (race condition oldini olish)
                if ($draw->max_tickets > 0) {
                    $draw = \App\Models\Game\LuckyDraw::lockForUpdate()->find($draw->id);
                    $sold = LuckyDrawTicket::where('lucky_draw_id', $draw->id)->sum('quantity');
                    if ($sold + $quantity > $draw->max_tickets) {
                        throw new \Exception('Yetarli chipta qolmagan.');
                    }
                }

                $user->decrement('balance', $total);

                LuckyDrawTicket::create([
                    'user_id'       => $user->id,
                    'lucky_draw_id' => $draw->id,
                    'quantity'      => $quantity,
                    'total_paid'    => $total,
                ]);
            });
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }

        XpService::award($user, XpLog::ACTION_LUCKY_DRAW, 15 * $quantity,
            "Lucky Draw: {$quantity} ta chipta");

        // Quest progress
        \App\Services\QuestService::updateProgress($user, \App\Models\Game\Quest::REQ_LUCKY_DRAW, $quantity);

        return back()->with('success', "{$quantity} ta chipta xarid qilindi! Jami: " . number_format($total) . ' UZS');
    }
}
