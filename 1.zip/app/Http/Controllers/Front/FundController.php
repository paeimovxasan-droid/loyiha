<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Investment\Fund;
use App\Models\Investment\FundInvest;
use App\Services\XpService;
use App\Models\Level\XpLog;
use Illuminate\Http\Request;

class FundController extends Controller
{
    public function index()
    {
        $funds     = Fund::active()->get();
        $myInvests = auth()->user()->fundInvests()
            ->with('fund')->latest()->paginate(10);

        return view('front.pages.funds', compact('funds', 'myInvests'));
    }

    public function invest(Request $request, Fund $fund)
    {
        if ($fund->status !== 'active') {
            return back()->with('error', 'Bu fond faol emas.');
        }

        $user = auth()->user();

        if ($user->isBanned()) {
            return back()->with('error', 'Hisobingiz bloklangan.');
        }

        $request->validate([
            'amount' => "required|numeric|min:{$fund->min_invest}",
        ]);

        $amount = (float) $request->amount;

        try {
            $invest = \Illuminate\Support\Facades\DB::transaction(function () use ($user, $fund, $amount) {
                $user = \App\Models\User::lockForUpdate()->find($user->id);

                if ($user->balance < $amount) {
                    throw new \Exception('Balansingiz yetarli emas.');
                }

                $expectedProfit = round($amount * $fund->commission_percent / 100, 2);
                $startedAt      = now()->toDateString();
                $expiresAt      = now()->addDays($fund->validity_days)->toDateString();

                $balanceBefore = $user->balance;
                $user->decrement('balance', $amount);
                $user->refresh();

                $invest = FundInvest::create([
                    'user_id'         => $user->id,
                    'fund_id'         => $fund->id,
                    'amount'          => $amount,
                    'expected_profit' => $expectedProfit,
                    'started_at'      => $startedAt,
                    'expires_at'      => $expiresAt,
                    'status'          => 'active',
                ]);

                $user->transactions()->create([
                    'amount'                => $amount,
                    'type'                  => 'fund',
                    'direction'             => 'debit',
                    'balance_before'        => $balanceBefore,
                    'balance_after'         => $user->balance,
                    'status'                => 'completed',
                    'description'           => $fund->getTranslation('name', app()->getLocale()) . ' fondiga investitsiya',
                    'transactionable_type'  => FundInvest::class,
                    'transactionable_id'    => $invest->id,
                ]);

                return $invest;
            });
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }

        XpService::award($user, XpLog::ACTION_FUND, 15,
            $fund->getTranslation('name', app()->getLocale()) . ' fondiga investitsiya', $invest);

        \App\Services\QuestService::updateProgress($user, \App\Models\Game\Quest::REQ_FUND_INVEST);

        // VIP cashback
        \App\Services\Marketing\MembershipService::applyCashback($user, $amount, 'fund_invest');

        return back()->with('success',
            number_format($amount) . ' UZS investitsiya qilindi. Kutilayotgan foyda: ' . number_format($invest->expected_profit) . ' UZS');
    }
}
