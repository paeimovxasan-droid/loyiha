<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use Illuminate\Validation\Rules\Password;

class PasswordResetController extends Controller
{
    public function showForgot()
    {
        return view('front.auth.forgot_password');
    }

    public function sendResetLink(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $user = User::where('email', $request->email)->first();

        // User topilmasa ham xuddi shu xabarni ko'rsatamiz (user enumeration oldini olish)
        if (!$user) {
            return back()->with('success', 'Agar bu email ro\'yxatdan o\'tgan bo\'lsa, parolni tiklash havolasi yuborildi.');
        }

        $token = Str::random(64);

        DB::table('password_reset_tokens')->updateOrInsert(
            ['email' => $request->email],
            ['token' => Hash::make($token), 'created_at' => now()]
        );

        // Token ni session ga saqlash (email yuborish o'rniga)
        // Production da email yuborish kerak
        try {
            Mail::raw(
                "Parolni tiklash uchun havola: " . route('password.reset', $token) . "?email=" . urlencode($request->email),
                function ($message) use ($request) {
                    $message->to($request->email)->subject('Parolni tiklash — AISOQQA');
                }
            );
        } catch (\Exception $e) {
            // Email yuborilmasa ham davom etamiz
        }

        return back()->with('success', 'Agar bu email ro\'yxatdan o\'tgan bo\'lsa, parolni tiklash havolasi yuborildi.');
    }

    public function showReset(string $token, Request $request)
    {
        return view('front.auth.reset_password', [
            'token' => $token,
            'email' => $request->email,
        ]);
    }

    public function reset(Request $request)
    {
        $request->validate([
            'token'    => 'required|string',
            'email'    => 'required|email',
            'password' => ['required', 'confirmed', Password::min(8)],
        ]);

        $record = DB::table('password_reset_tokens')
            ->where('email', $request->email)
            ->first();

        if (!$record || !Hash::check($request->token, $record->token)) {
            return back()->withErrors(['email' => 'Token noto\'g\'ri yoki muddati o\'tgan.']);
        }

        // Token 60 daqiqadan eski bo'lsa
        if (now()->diffInMinutes($record->created_at) > 60) {
            DB::table('password_reset_tokens')->where('email', $request->email)->delete();
            return back()->withErrors(['email' => 'Token muddati o\'tgan. Qaytadan so\'rang.']);
        }

        $user = User::where('email', $request->email)->first();

        if (!$user) {
            return back()->withErrors(['email' => 'Token noto\'g\'ri yoki muddati o\'tgan.']);
        }

        $user->update(['password' => Hash::make($request->password)]);

        DB::table('password_reset_tokens')->where('email', $request->email)->delete();

        return redirect()->route('login')->with('success', 'Parol muvaffaqiyatli yangilandi. Endi kiring.');
    }
}
