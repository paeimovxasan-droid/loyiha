<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Security\AuditLog;
use App\Models\Security\FaceKycAttempt;
use App\Services\Security\FaceKycService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class KycController extends Controller
{
    /**
     * KYC sahifasi — joriy bosqichni ko'rsatish
     */
    public function index()
    {
        $user = auth()->user();
        return view('front.pages.kyc', compact('user'));
    }

    /**
     * 1-bosqich: Pasport yuklash
     * POST /app/kyc/passport
     */
    public function submitPassport(Request $request)
    {
        $user = auth()->user();

        // Allaqachon yuborilgan yoki tasdiqlangan bo'lsa rad etish
        if (in_array($user->kyc_status, ['passport_pending', 'passport_verified', 'face_pending', 'verified'])) {
            return back()->with('error', 'KYC allaqachon yuborilgan yoki ko\'rib chiqilmoqda.');
        }

        $request->validate([
            'document_front' => 'required|image|mimes:jpg,jpeg,png,webp|max:5120',
            'document_back'  => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'document_type'  => 'required|in:passport,id_card',
        ]);

        try {
            DB::transaction(function () use ($user, $request) {
                // Concurrent lock — parallel so'rovlarni bloklash
                $freshUser = \App\Models\User::lockForUpdate()->find($user->id);

                if (in_array($freshUser->kyc_status, ['passport_pending', 'passport_verified', 'face_pending', 'verified'])) {
                    throw new \Exception('KYC allaqachon yuborilgan yoki ko\'rib chiqilmoqda.', 409);
                }

                // Pasport rasmini private storage'ga saqlash
                $docFrontPath = FaceKycService::saveKycImagePublic(
                    $request->file('document_front'),
                    'kyc/documents',
                    $user->id
                );

                $docBackPath = $request->hasFile('document_back')
                    ? FaceKycService::saveKycImagePublic(
                        $request->file('document_back'),
                        'kyc/documents',
                        $user->id
                    )
                    : null;

                $freshUser->update([
                    'kyc_status'      => 'passport_pending',
                    'kyc_stage'       => 'passport',
                    'kyc_type'        => 'passport',
                    'kyc_document'    => $docFrontPath,
                    'kyc_submitted_at' => now(),
                    'kyc_rejection_reason' => null,
                ]);
            });

            try {
                AuditLog::log('kyc_passport_submitted', $user);
            } catch (\Throwable $e) {
                Log::warning('KycController: AuditLog error', ['error' => $e->getMessage()]);
            }

            // Admin ga Telegram bildirishnoma (tugma bilan)
            try {
                \App\Services\TelegramBotService::notifyAdminKyc(
                    "{$user->name} (@{$user->username})",
                    $user->id,
                    'passport'
                );
            } catch (\Throwable $e) {
                Log::warning('KYC passport notify failed', ['error' => $e->getMessage()]);
            }

            return back()->with('success', 'Pasportingiz yuborildi. Admin ko\'rib chiqadi va 24 soat ichida natija bildiriladi.');

        } catch (\Exception $e) {
            if ($e->getCode() === 409) {
                return back()->with('error', $e->getMessage());
            }
            Log::error('KYC passport submit failed', ['user_id' => $user->id, 'error' => $e->getMessage()]);
            return back()->with('error', 'Xatolik yuz berdi. Qaytadan urinib ko\'ring.');
        }
    }

    /**
     * 2-bosqich: Face ID sessiyasini boshlash
     * POST /app/kyc/face/start
     */
    public function startFaceId(): \Illuminate\Http\JsonResponse
    {
        $user = auth()->user();

        // Faqat passport_verified holatida ruxsat
        if ($user->kyc_status !== 'passport_verified') {
            return response()->json([
                'error' => 'Avval pasportingizni tasdiqlating.',
                'kyc_status' => $user->kyc_status,
            ], 403);
        }

        // Oxirgi 1 soatda 3 dan ortiq urinish bo'lsa bloklash
        $recentAttempts = FaceKycAttempt::where('user_id', $user->id)
            ->where('created_at', '>=', now()->subHour())
            ->count();

        if ($recentAttempts >= 3) {
            return response()->json([
                'error' => 'Juda ko\'p urinish. 1 soatdan keyin qayta urinib ko\'ring.',
            ], 429);
        }

        // Mavjud pending sessiyani expired qilish
        FaceKycAttempt::where('user_id', $user->id)
            ->where('status', 'pending')
            ->update(['status' => 'expired']);

        $challenge = FaceKycService::generateChallenge();

        $attempt = FaceKycAttempt::create([
            'user_id'    => $user->id,
            'session_id' => $challenge['session_id'],
            'challenge'  => $challenge['steps'],
            'status'     => 'pending',
            'expires_at' => now()->addMinutes(10),
        ]);

        try {
            AuditLog::log('face_kyc_started', $user, ['attempt_id' => $attempt->id]);
        } catch (\Throwable $e) {
            Log::warning('KycController: AuditLog error', ['error' => $e->getMessage()]);
        }

        return response()->json([
            'session_id' => $challenge['session_id'],
            'challenge'  => $challenge['steps'],
            'expires_at' => $attempt->expires_at->toIso8601String(),
        ]);
    }

    /**
     * 2-bosqich: Selfie va liveness natijasini yuborish
     * POST /app/kyc/face/submit
     */
    public function submitFaceId(Request $request)
    {
        $user = auth()->user();

        if ($user->kyc_status !== 'passport_verified') {
            return back()->with('error', 'Avval pasportingizni tasdiqlating.');
        }

        $request->validate([
            'session_id'      => 'required|string',
            'selfie'          => 'required|image|mimes:jpg,jpeg,png,webp|max:5120',
            'document_front'  => 'required|image|mimes:jpg,jpeg,png,webp|max:5120',
            'document_back'   => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'document_type'   => 'required|in:passport,id_card',
            'liveness_passed' => 'required|boolean',
            'liveness_score'  => 'required|numeric|min:0|max:1',
        ]);

        // Sessiyani topish
        $attempt = FaceKycAttempt::where('user_id', $user->id)
            ->where('session_id', $request->session_id)
            ->where('status', 'pending')
            ->first();

        if (!$attempt) {
            return back()->with('error', 'Sessiya topilmadi yoki muddati o\'tgan. Qaytadan boshlang.');
        }

        if ($attempt->expires_at->isPast()) {
            $attempt->update(['status' => 'expired']);
            return back()->with('error', 'Sessiya muddati tugagan. Qaytadan boshlang.');
        }

        // Liveness tekshiruvi
        if (!$request->boolean('liveness_passed')) {
            $attempt->update(['status' => 'failed', 'fail_reason' => 'liveness_failed']);
            return back()->with('error', 'Yashashlik tekshiruvi muvaffaqiyatsiz. Yaxshi yorug\'likda qayta urinib ko\'ring.');
        }

        if ((float) $request->liveness_score < 0.7) {
            $attempt->update(['status' => 'failed', 'fail_reason' => 'low_liveness_score']);
            return back()->with('error', 'Yuz aniqlanmadi. Kamerani to\'g\'ri ushlab, yaxshi yorug\'likda qayta urinib ko\'ring.');
        }

        try {
            $result = FaceKycService::processSubmission(
                user: $user,
                attempt: $attempt,
                selfie: $request->file('selfie'),
                documentFront: $request->file('document_front'),
                documentBack: $request->file('document_back'),
                documentType: $request->document_type,
                livenessScore: (float) $request->liveness_score,
            );

            try {
                AuditLog::log('face_kyc_submitted', $user, [
                    'attempt_id'    => $attempt->id,
                    'liveness_score' => $request->liveness_score,
                    'auto_approved' => $result['auto_approved'],
                ]);
            } catch (\Throwable $e) {
                Log::warning('KycController: AuditLog error', ['error' => $e->getMessage()]);
            }

            if ($result['auto_approved']) {
                return back()->with('success', 'KYC muvaffaqiyatli tasdiqlandi! Endi moliyaviy amallar qilishingiz mumkin.');
            }

            // Admin ga Telegram bildirishnoma (tugma bilan)
            try {
                \App\Services\TelegramBotService::notifyAdminKyc(
                    "{$user->name} (@{$user->username})",
                    $user->id,
                    'face'
                );
            } catch (\Throwable $e) {
                Log::warning('KYC face notify failed', ['error' => $e->getMessage()]);
            }

            return back()->with('success', 'Selfi yuborildi. Admin ko\'rib chiqadi va 24 soat ichida natija bildiriladi.');

        } catch (\Exception $e) {
            Log::error('KYC face submit failed', ['user_id' => $user->id, 'error' => $e->getMessage()]);
            $attempt->update(['status' => 'failed', 'fail_reason' => $e->getMessage()]);
            return back()->with('error', 'Xatolik yuz berdi. Qaytadan urinib ko\'ring.');
        }
    }
}
