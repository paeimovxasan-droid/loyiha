<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ExchangePageController extends Controller
{
    public function index()
    {
        try {
            $buyRate = \App\Models\Exchange\ExchangeSetting::get('buy_rate', 0);
            $sellRate = \App\Models\Exchange\ExchangeSetting::get('sell_rate', 0);
            $minOrder = \App\Models\Exchange\ExchangeSetting::get('min_order', 1000);
            $myOrders = \App\Models\Exchange\ExchangeOrder::where('user_id', auth()->id())
                ->latest()->limit(20)->get();
        } catch (\Exception $e) {
            $buyRate = 0;
            $sellRate = 0;
            $minOrder = 1000;
            $myOrders = collect();
        }

        return view('front.pages.exchange', compact('buyRate', 'sellRate', 'minOrder', 'myOrders'));
    }

    public function order(Request $request)
    {
        $request->validate([
            'side'   => 'required|in:buy,sell',
            'amount' => 'required|numeric|min:1',
            'type'   => 'nullable|in:market,limit',
            'price'  => 'nullable|numeric|min:1',
        ]);

        try {
            $user   = auth()->user();
            $side   = $request->side;
            $amount = (float) $request->amount;
            $type   = $request->type ?? 'market';

            if ($type === 'limit') {
                $request->validate(['price' => 'required|numeric|min:1']);
                $order = \App\Services\Exchange\ExchangeService::placeLimitOrder(
                    $user, $side, (float) $request->price, $amount
                );
            } else {
                $order = \App\Services\Exchange\ExchangeService::placeMarketOrder(
                    $user, $side, $amount
                );
            }

            $msg = $order->filled_amount > 0
                ? "Buyurtma bajarildi! {$order->filled_amount} AIS savdosi amalga oshdi."
                : "Buyurtma yaratildi va navbatda kutmoqda.";

            return back()->with('success', $msg);
        } catch (\Exception $e) {
            return back()->with('error', $e->getMessage());
        }
    }
}
