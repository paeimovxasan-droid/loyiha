<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Payment\Deposit;
use App\Models\Payment\Withdrawal;
use App\Models\Game\UserTask;
use App\Models\User;
use App\Services\Telegram\AdminNotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class AdminTelegramController extends Controller
{
    public function handle(Request $request)
    {
        $update = $request->all();
        $callbackQuery = $update['callback_query'] ?? null;

        if (!$callbackQuery) return response()->json(['ok' => true]);

        $data = $callbackQuery['data'];
        $from = $callbackQuery['from'];
        $message = $callbackQuery['message'];
        $chatId = $message['chat']['id'];
        $messageId = $message['message_id'];

        // Xavfsizlik: Faqat bizning guruhdan va adminlardan kelishini tekshirish
        if ($chatId != config('services.telegram_admin.group_id')) {
            return response()->json(['ok' => true]);
        }

        // Amallar: [action]_[type]_[id] ko'rinishida bo'ladi
        $parts = explode('_', $data);
        if (count($parts) < 3) return response()->json(['ok' => true]);

        $action = $parts[0]; // approve, reject
        $type = $parts[1];   // deposit, withdrawal, kyc, task
        $id = $parts[2];     // Model ID

        $result = $this->processAction($action, $type, $id, $from['username'] ?? $from['id']);

        if ($result['success']) {
            $this->updateMessage($chatId, $messageId, $message['text'] ?? $message['caption'] ?? '', $result['message']);
        }

        return response()->json(['ok' => true]);
    }

    protected function processAction($action, $type, $id, $adminName): array
    {
        try {
            switch ($type) {
                case 'deposit':
                    return $this->handleDeposit($action, $id, $adminName);
                case 'withdrawal':
                    return $this->handleWithdrawal($action, $id, $adminName);
                case 'kyc':
                    return $this->handleKyc($action, $id, $adminName);
                case 'task':
                    return $this->handleTask($action, $id, $adminName);
            }
        } catch (\Exception $e) {
            Log::error("Admin Bot Action Error ($type): " . $e->getMessage());
            return ['success' => false, 'message' => 'Xatolik: ' . $e->getMessage()];
        }

        return ['success' => false, 'message' => 'Noma\'lum tur'];
    }

    private function handleDeposit($action, $id, $adminName): array
    {
        $deposit = Deposit::findOrFail($id);
        if (!$deposit->isPending()) return ['success' => false, 'message' => 'Allaqachon ko\'rib chiqilgan'];

        if ($action === 'approve') {
            // Admin kontrolleridagi mantiqni chaqiramiz (yoki shunga o'xshash)
            // Hozircha soddalashtirilgan, lekin keyinchalik to'liq o'tkaziladi
            DB::transaction(function() use ($deposit) {
                $deposit->update(['status' => 'approved', 'approved_at' => now(), 'feedback' => 'Bot orqali']);
                $deposit->user->increment('balance', $deposit->final_amount);
            });
            return ['success' => true, 'message' => "✅ Tasdiqlandi (Admin: @$adminName)"];
        }

        $deposit->update(['status' => 'rejected', 'feedback' => 'Bot orqali rad etildi']);
        return ['success' => true, 'message' => "❌ Rad etildi (Admin: @$adminName)"];
    }

    private function handleWithdrawal($action, $id, $adminName): array
    {
        $withdrawal = Withdrawal::findOrFail($id);
        if ($withdrawal->status !== 'pending') return ['success' => false, 'message' => 'Allaqachon ko\'rib chiqilgan'];

        if ($action === 'approve') {
            $withdrawal->update(['status' => 'approved', 'approved_at' => now(), 'feedback' => "Bot orqali (@{$adminName})"]);

            // Transaction statusini yangilash
            if ($withdrawal->user) {
                $withdrawal->user->transactions()
                    ->where('transactionable_type', Withdrawal::class)
                    ->where('transactionable_id', $withdrawal->id)
                    ->where('status', 'pending')
                    ->update(['status' => 'completed']);

                // Foydalanuvchiga Telegram bildirishnoma
                try {
                    \App\Services\TelegramBotService::notify(
                        $withdrawal->user,
                        "✅ Yechim so'rovingiz tasdiqlandi!\n\n" .
                        "💵 Summa: " . number_format($withdrawal->final_amount, 2) . " UZS\n" .
                        "📲 " . ($withdrawal->method_name ?? '') . " ga o'tkazildi.",
                        [[['text' => '📊 Tranzaksiyalarni ko\'rish', 'url' => config('app.url') . '/app/transactions']]]
                    );
                } catch (\Throwable $e) {}

                // Kanalga to'lov cheki yuborish
                try {
                    \App\Services\TelegramBotService::sendWithdrawalReceiptToChannel($withdrawal);
                } catch (\Throwable $e) {}
            }

            return ['success' => true, 'message' => "✅ Tasdiqlandi (Admin: @$adminName)"];
        }

        $withdrawal->update(['status' => 'rejected', 'feedback' => "Bot orqali rad etildi (@{$adminName})"]);

        // Pulni qaytarish
        if ($withdrawal->user) {
            $withdrawal->user->increment('balance', $withdrawal->amount);

            // Transaction statusini yangilash
            $withdrawal->user->transactions()
                ->where('transactionable_type', Withdrawal::class)
                ->where('transactionable_id', $withdrawal->id)
                ->where('status', 'pending')
                ->update(['status' => 'reversed']);

            // Foydalanuvchiga bildirishnoma
            try {
                \App\Services\TelegramBotService::notify(
                    $withdrawal->user,
                    "❌ Yechim so'rovingiz rad etildi.\n\n" .
                    "💵 Summa: " . number_format($withdrawal->amount, 2) . " UZS\n" .
                    "Pul balansingizga qaytarildi.",
                    [[['text' => '💰 Balansni ko\'rish', 'url' => config('app.url') . '/app/deposit']]]
                );
            } catch (\Throwable $e) {}
        }

        return ['success' => true, 'message' => "❌ Rad etildi va pul qaytarildi (Admin: @$adminName)"];
    }

    private function handleKyc($action, $id, $adminName): array
    {
        $user = User::findOrFail($id);
        if ($action === 'approve') {
            $user->update(['kyc_status' => 'verified', 'kyc_verified_at' => now()]);
            return ['success' => true, 'message' => "✅ KYC tasdiqlandi (Admin: @$adminName)"];
        }
        $user->update(['kyc_status' => 'rejected']);
        return ['success' => true, 'message' => "❌ KYC rad etildi (Admin: @$adminName)"];
    }

    private function handleTask($action, $id, $adminName): array
    {
        $userTask = UserTask::findOrFail($id);
        if ($action === 'approve') {
            $userTask->update(['status' => 'approved']);
            return ['success' => true, 'message' => "✅ Vazifa tasdiqlandi (Admin: @$adminName)"];
        }
        $userTask->update(['status' => 'rejected']);
        return ['success' => true, 'message' => "❌ Vazifa rad etildi (Admin: @$adminName)"];
    }

    private function updateMessage($chatId, $messageId, $oldText, $statusText): void
    {
        $token = config('services.telegram_admin.bot_token');
        $newText = $oldText . "\n\n" . $statusText;

        Http::post("https://api.telegram.org/bot{$token}/editMessageText", [
            'chat_id'    => $chatId,
            'message_id' => $messageId,
            'text'       => $newText,
            'parse_mode' => 'HTML',
        ]);
        
        // Agar rasm bo'lsa (editMessageText ishlamaydi), editMessageCaption ishlatamiz
        Http::post("https://api.telegram.org/bot{$token}/editMessageCaption", [
            'chat_id'    => $chatId,
            'message_id' => $messageId,
            'caption'    => $newText,
            'parse_mode' => 'HTML',
        ]);
    }
}
