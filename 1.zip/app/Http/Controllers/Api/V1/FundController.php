<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Game\Quest;
use App\Models\Investment\Fund;
use App\Models\Investment\FundInvest;
use App\Models\Level\XpLog;
use App\Models\User;
use App\Services\QuestService;
use App\Services\XpService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FundController extends Controller
{
    use ApiResponse;

    /**
     * Aktiv fondlar + foydalanuvchining investitsiyalari
     */
    public function index(): JsonResponse
    {
        $locale = app()->getLocale();

        $funds = Fund::active()->get()->map(fn($fund) => [
            'id'                 => $fund->id,
            'name'               => $fund->getTranslation('name', $locale),
            'description'        => $fund->getTranslation('description', $locale),
            'photo_url'          => $fund->photo_url,
            'commission_percent' => (float) $fund->commission_percent,
            'validity_days'      => $fund->validity_days,
            'min_invest'         => (float) $fund->min_invest,
        ]);

        $myInvests = auth()->user()->fundInvests()
            ->with('fund')
            ->latest()
            ->limit(20)
            ->get()
            ->map(fn($inv) => [
                'id'              => $inv->id,
                'fund_name'       => $inv->fund?->getTranslation('name', $locale),
                'amount'          => (float) $inv->amount,
                'expected_profit' => (float) $inv->expected_profit,
                'started_at'      => $inv->started_at?->toDateString(),
                'expires_at'      => $inv->expires_at?->toDateString(),
                'status'          => $inv->status,
            ]);

        return $this->success([
            'funds'      => $funds,
            'my_invests' => $myInvests,
        ]);
    }

    /**
     * Fondga investitsiya qilish
     */
    public function invest(Request $request, Fund $fund): JsonResponse
    {
        if ($fund->status !== 'active') {
            return $this->error('Bu fond faol emas', 422);
        }

        $request->validate([
            'amount' => "required|numeric|min:{$fund->min_invest}",
        ]);

        $user   = auth()->user();
        $amount = (float) $request->amount;

        try {
            $invest = DB::transaction(function () use ($user, $fund, $amount) {
                $user = User::lockForUpdate()->find($user->id);

                if ($user->balance < $amount) {
                    throw new \Exception('Balansingiz yetarli emas.');
                }

                $expectedProfit = round($amount * $fund->commission_percent / 100, 2);
                $startedAt      = now()->toDateString();
                $expiresAt      = now()->addDays($fund->validity_days)->toDateString();

                $balanceBefore = $user->balance;
                $user->decrement('balance', $amount);
                $user->refresh();

                $invest = FundInvest::create([
                    'user_id'         => $user->id,
                    'fund_id'         => $fund->id,
                    'amount'          => $amount,
                    'expected_profit' => $expectedProfit,
                    'started_at'      => $startedAt,
                    'expires_at'      => $expiresAt,
                    'status'          => 'active',
                ]);

                $user->transactions()->create([
                    'amount'               => $amount,
                    'type'                 => 'fund',
                    'direction'            => 'debit',
                    'balance_before'       => $balanceBefore,
                    'balance_after'        => $user->balance,
                    'status'               => 'completed',
                    'description'          => $fund->getTranslation('name', app()->getLocale()) . ' fondiga investitsiya',
                    'transactionable_type' => FundInvest::class,
                    'transactionable_id'   => $invest->id,
                ]);

                // XP va Quest — transaksiya ichida
                XpService::award($user, XpLog::ACTION_FUND, 15,
                    $fund->getTranslation('name', app()->getLocale()) . ' fondiga investitsiya', $invest);
                QuestService::updateProgress($user, Quest::REQ_FUND_INVEST);

                return $invest;
            });
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        return $this->success([
            'invest' => [
                'id'              => $invest->id,
                'amount'          => (float) $invest->amount,
                'expected_profit' => (float) $invest->expected_profit,
                'started_at'      => $invest->started_at?->toDateString(),
                'expires_at'      => $invest->expires_at?->toDateString(),
                'status'          => $invest->status,
            ],
        ], 'Investitsiya muvaffaqiyatli amalga oshirildi');
    }
}
