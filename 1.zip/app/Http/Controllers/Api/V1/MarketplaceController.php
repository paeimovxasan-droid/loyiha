<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Marketplace\Gig;
use App\Models\Marketplace\GigCategory;
use App\Models\Marketplace\GigDispute;
use App\Models\Marketplace\GigOrder;
use App\Models\User;
use App\Services\Marketplace\EscrowService;
use App\Services\Marketplace\GigService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use App\Http\Requests\Marketplace\StoreGigRequest;

class MarketplaceController extends Controller
{
    use ApiResponse;

    // ─── Categories ────────────────────────────────────────────────────

    public function categories(): JsonResponse
    {
        $categories = GigCategory::active()->orderBy('sort_order')->get();
        return $this->success($categories);
    }

    // ─── Gigs ──────────────────────────────────────────────────────────

    public function gigIndex(Request $request): JsonResponse
    {
        $gigs = GigService::list($request->only([
            'category_id', 'search', 'sort_by', 'sort_dir', 'per_page',
        ]));

        return $this->success($gigs);
    }

    public function gigShow(Gig $gig): JsonResponse
    {
        if ($gig->status === Gig::STATUS_DELETED) {
            return $this->error('Xizmat topilmadi.', 404);
        }

        $gig->load(['user', 'category', 'reviews.reviewer']);
        return $this->success($gig);
    }

    public function gigStore(StoreGigRequest $request): JsonResponse
    {

        try {
            $gig = GigService::create($request->user(), $request->all());
            return $this->success($gig, 'Xizmat muvaffaqiyatli yaratildi.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function gigUpdate(StoreGigRequest $request, Gig $gig): JsonResponse
    {

        try {
            $gig = GigService::update($request->user(), $gig, $request->all());
            return $this->success($gig, 'Xizmat muvaffaqiyatli yangilandi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), $e->getMessage() === 'Sizda bu gigni tahrirlash huquqi yo\'q.' ? 403 : 422);
        }
    }

    public function gigDestroy(Request $request, Gig $gig): JsonResponse
    {
        try {
            GigService::delete($request->user(), $gig);
            return $this->success(null, 'Xizmat muvaffaqiyatli o\'chirildi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), $e->getMessage() === 'Sizda bu gigni o\'chirish huquqi yo\'q.' ? 403 : 422);
        }
    }

    // ─── Orders ────────────────────────────────────────────────────────

    public function orderStore(Request $request): JsonResponse
    {
        $request->validate([
            'gig_id' => 'required|exists:gigs,id',
        ]);

        $gig = Gig::active()->findOrFail($request->gig_id);

        try {
            $order = EscrowService::createOrder($request->user(), $gig);
            return $this->success($order, 'Buyurtma muvaffaqiyatli yaratildi.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function orderIndex(Request $request): JsonResponse
    {
        $user = $request->user();

        $orders = GigOrder::where(function ($q) use ($user) {
            $q->where('buyer_id', $user->id)
              ->orWhere('seller_id', $user->id);
        })
        ->with(['gig', 'buyer', 'seller'])
        ->orderByDesc('created_at')
        ->paginate(15);

        return $this->success($orders);
    }

    public function orderShow(GigOrder $order, Request $request): JsonResponse
    {
        $user = $request->user();
        if ($order->buyer_id !== $user->id && $order->seller_id !== $user->id) {
            return $this->error('Buyurtma topilmadi.', 404);
        }

        $order->load(['gig', 'buyer', 'seller', 'review', 'dispute']);
        return $this->success($order);
    }

    public function orderAccept(Request $request, GigOrder $order): JsonResponse
    {
        try {
            $order = EscrowService::acceptOrder($request->user(), $order);
            return $this->success($order, 'Buyurtma qabul qilindi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function orderReject(Request $request, GigOrder $order): JsonResponse
    {
        try {
            $order = EscrowService::rejectOrder($request->user(), $order);
            return $this->success($order, 'Buyurtma rad etildi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function orderDeliver(Request $request, GigOrder $order): JsonResponse
    {
        try {
            $order = EscrowService::deliverOrder($request->user(), $order);
            return $this->success($order, 'Ish topshirildi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function orderComplete(Request $request, GigOrder $order): JsonResponse
    {
        try {
            $order = EscrowService::completeOrder($request->user(), $order);
            return $this->success($order, 'Buyurtma tugallandi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    // ─── Disputes ──────────────────────────────────────────────────────

    public function disputeStore(Request $request, GigOrder $order): JsonResponse
    {
        $request->validate([
            'reason' => 'required|string|min:10',
        ]);

        try {
            $dispute = EscrowService::openDispute($request->user(), $order, $request->reason);
            return $this->success($dispute, 'Nizo ochildi.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function disputeResolve(Request $request, GigDispute $dispute): JsonResponse
    {
        $request->validate([
            'resolution' => 'required|in:buyer_wins,seller_wins',
            'admin_note' => 'nullable|string',
        ]);

        try {
            $order = EscrowService::resolveDispute(
                $dispute,
                $request->resolution,
                $request->user()->id,
                $request->admin_note
            );
            return $this->success($order, 'Nizo hal qilindi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    // ─── Reviews ───────────────────────────────────────────────────────

    public function reviewStore(Request $request, GigOrder $order): JsonResponse
    {
        $request->validate([
            'rating'  => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string',
        ]);

        try {
            $review = EscrowService::createReview(
                $request->user(),
                $order,
                $request->rating,
                $request->comment
            );
            return $this->success($review, 'Baho muvaffaqiyatli qo\'yildi.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    // ─── Seller Profile ────────────────────────────────────────────────

    public function sellerProfile(User $user): JsonResponse
    {
        $user->load(['gigs' => function ($q) {
            $q->active()->with('category');
        }]);

        $stats = [
            'total_gigs'    => $user->gigs()->active()->count(),
            'total_orders'  => GigOrder::where('seller_id', $user->id)->where('status', 'completed')->count(),
            'avg_rating'    => (float) \App\Models\Marketplace\GigReview::where('seller_id', $user->id)->avg('rating') ?? 0,
            'total_reviews' => \App\Models\Marketplace\GigReview::where('seller_id', $user->id)->count(),
        ];

        return $this->success([
            'user'  => $user,
            'stats' => $stats,
        ]);
    }
}
