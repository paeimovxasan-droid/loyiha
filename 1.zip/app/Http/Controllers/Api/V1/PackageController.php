<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Finance\Commission;
use App\Models\Game\Quest;
use App\Models\Level\XpLog;
use App\Models\Package\Mining;
use App\Models\Package\Package;
use App\Models\Package\Purchase;
use App\Models\User;
use App\Services\QuestService;
use App\Services\XpService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PackageController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/packages
     * Aktiv paketlar ro'yxati
     */
    public function index(): JsonResponse
    {
        $locale   = app()->getLocale();
        $packages = Package::active()->orderBy('sort_order')->get();

        $myPackageIds = auth()->user()
            ->purchases()
            ->where('status', 'active')
            ->pluck('package_id')
            ->toArray();

        $data = $packages->map(fn($p) => [
            'id'                   => $p->id,
            'name'                 => $p->getTranslation('name', $locale),
            'photo_url'            => $p->photo_url ?? null,
            'price'                => (float) $p->price,
            'validity_days'        => $p->validity_days,
            'daily_profit_percent' => (float) $p->daily_profit_percent,
            'total_profit_percent' => (float) $p->total_profit_percent,
            'sponsor_income'       => (float) $p->sponsor_income,
            'ref_level1'           => (float) $p->ref_level1,
            'ref_level2'           => (float) $p->ref_level2,
            'ref_level3'           => (float) $p->ref_level3,
            'is_default'           => (bool) $p->is_default,
            'is_purchased'         => in_array($p->id, $myPackageIds),
        ]);

        return $this->success(['packages' => $data]);
    }

    /**
     * POST /api/v1/packages/{package}/buy
     * Paket xarid qilish
     */
    public function buy(Request $request, Package $package): JsonResponse
    {
        if ($package->status !== 'active') {
            return $this->error('Bu paket faol emas.', 422);
        }

        $user = auth()->user();

        try {
            $purchase = DB::transaction(function () use ($user, $package) {
                $user = User::lockForUpdate()->find($user->id);

                if ($user->balance < $package->price) {
                    throw new \Exception('Balansingiz yetarli emas. Avval depozit qiling.');
                }

                $balanceBefore = $user->balance;
                $user->decrement('balance', $package->price);
                $user->refresh();

                $purchase = Purchase::create([
                    'user_id'    => $user->id,
                    'package_id' => $package->id,
                    'amount'     => $package->price,
                    'status'     => 'active',
                    'started_at' => now(),
                    'expires_at' => now()->addDays($package->validity_days),
                ]);

                // Mining yozuvi
                $dailyProfit  = $package->calcDailyProfit($package->price);
                $hourlyProfit = round($dailyProfit / 24, 4);
                $totalHours   = $package->validity_days * 24;

                Mining::create([
                    'user_id'         => $user->id,
                    'package_id'      => $package->id,
                    'purchase_id'     => $purchase->id,
                    'started_at'      => now(),
                    'ended_at'        => now()->addDays($package->validity_days),
                    'total_hours'     => $totalHours,
                    'completed_hours' => 0,
                    'hourly_profit'   => $hourlyProfit,
                    'daily_profit'    => $dailyProfit,
                    'total_earned'    => 0,
                    'status'          => 'running',
                ]);

                $user->transactions()->create([
                    'amount'               => $package->price,
                    'type'                 => 'mining',
                    'direction'            => 'debit',
                    'balance_before'       => $balanceBefore,
                    'balance_after'        => $user->balance,
                    'status'               => 'completed',
                    'description'          => $package->getTranslation('name', app()->getLocale()) . ' paketi xarid qilindi',
                    'transactionable_type' => Purchase::class,
                    'transactionable_id'   => $purchase->id,
                ]);

                // Referral komissiyalar
                $this->processReferralCommissions($user, $package, $purchase);

                return $purchase;
            });
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        // XP (transaction tashqarisida)
        $xpAmount = min(50, max(10, (int) ($package->price / 10000)));
        XpService::award(
            $user,
            XpLog::ACTION_PURCHASE,
            $xpAmount,
            $package->getTranslation('name', app()->getLocale()) . ' paketi xarid qilindi',
            $purchase
        );

        QuestService::updateProgress($user, Quest::REQ_PURCHASE_COUNT);
        \App\Services\Marketing\MembershipService::applyCashback($user, $package->price, 'package_purchase');

        if ($user->referred_by) {
            $referrer = User::where('username', $user->referred_by)->first();
            if ($referrer) {
                XpService::award($referrer, XpLog::ACTION_REFERRAL, 20,
                    $user->name . ' paket xarid qildi', $purchase);
            }
        }

        return $this->success([
            'purchase' => [
                'id'         => $purchase->id,
                'package_id' => $purchase->package_id,
                'amount'     => (float) $purchase->amount,
                'status'     => $purchase->status,
                'started_at' => $purchase->started_at?->toIso8601String(),
                'expires_at' => $purchase->expires_at?->toIso8601String(),
            ],
        ], 'Paket muvaffaqiyatli xarid qilindi!');
    }

    private function processReferralCommissions(User $user, Package $package, Purchase $purchase): void
    {
        $levels  = [1 => $package->ref_level1, 2 => $package->ref_level2, 3 => $package->ref_level3];
        $current = $user;

        foreach ($levels as $level => $percent) {
            if ($percent <= 0) continue;
            $referrer = $current->referrer;
            if (!$referrer || $referrer->isBanned()) break;

            $amount = round($package->price * $percent / 100, 2);
            if ($amount <= 0) { $current = $referrer; continue; }

            Commission::create([
                'user_id'      => $referrer->id,
                'from_user_id' => $user->id,
                'reason'       => 'purchase',
                'level'        => $level,
                'percent'      => $percent,
                'amount'       => $amount,
                'date'         => now()->toDateString(),
                'status'       => 'active',
            ]);

            // lockForUpdate — parallel request'da race condition oldini olish
            $lockedReferrer = User::lockForUpdate()->find($referrer->id);
            $before = $lockedReferrer->balance;
            $lockedReferrer->increment('balance', $amount);
            $lockedReferrer->refresh();

            $lockedReferrer->transactions()->create([
                'amount'               => $amount,
                'type'                 => 'commission',
                'direction'            => 'credit',
                'balance_before'       => $before,
                'balance_after'        => $lockedReferrer->balance,
                'status'               => 'completed',
                'description'          => "Level {$level} referral komissiya ({$percent}%): " . $user->name,
                'transactionable_type' => Purchase::class,
                'transactionable_id'   => $purchase->id,
            ]);

            $current = $referrer;
        }
    }
}
