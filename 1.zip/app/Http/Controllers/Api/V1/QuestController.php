<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Game\UserQuest;
use App\Services\QuestService;
use Illuminate\Http\JsonResponse;

class QuestController extends Controller
{
    use ApiResponse;

    /**
     * Kategoriya bo'yicha guruhlangan kvestlar
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();
        $quests = QuestService::getForUser($user);

        $grouped = $quests->groupBy(fn($uq) => $uq->quest?->category ?? 'general')
            ->map(fn($items) => $items->map(fn($uq) => [
                'id'               => $uq->id,
                'quest_id'         => $uq->quest_id,
                'title'            => $uq->quest?->getTranslation('title', app()->getLocale()),
                'description'      => $uq->quest?->getTranslation('description', app()->getLocale()),
                'icon'             => $uq->quest?->icon,
                'category'         => $uq->quest?->category,
                'progress'         => $uq->progress,
                'requirement_value' => $uq->quest?->requirement_value,
                'progress_percent' => $uq->progress_percent,
                'status'           => $uq->status,
                'reward_text'      => $uq->quest?->reward_text,
                'reward_ais'       => (float) ($uq->quest?->reward_ais ?? 0),
                'reward_uzs'       => (float) ($uq->quest?->reward_uzs ?? 0),
                'reward_xp'        => (int) ($uq->quest?->reward_xp ?? 0),
                'completed_at'     => $uq->completed_at?->toIso8601String(),
                'claimed_at'       => $uq->claimed_at?->toIso8601String(),
            ])->values());

        return $this->success(['quests' => $grouped]);
    }

    /**
     * Mukofot olish (claim)
     */
    public function claim(UserQuest $userQuest): JsonResponse
    {
        if ($userQuest->user_id !== auth()->id()) {
            return $this->error('Ruxsat berilmagan', 403);
        }

        try {
            $rewards = QuestService::claim(auth()->user(), $userQuest);
            return $this->success(['rewards' => $rewards], 'Mukofot olindi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * Kvest statistikasi
     */
    public function stats(): JsonResponse
    {
        $user = auth()->user();
        $quests = QuestService::getForUser($user);

        return $this->success([
            'total'     => $quests->count(),
            'completed' => $quests->filter(fn($uq) => $uq->isCompleted())->count(),
            'claimed'   => $quests->filter(fn($uq) => $uq->isClaimed())->count(),
            'available' => $quests->filter(fn($uq) => !$uq->isClaimed())->count(),
        ]);
    }
}
