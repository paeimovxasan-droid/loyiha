<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Education\Course;
use App\Models\Education\CourseLesson;
use App\Models\Education\CoursePurchase;
use App\Services\Education\CourseService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    use ApiResponse;

    /**
     * Kurslar ro'yxati
     */
    public function index(Request $request): JsonResponse
    {
        $courses = CourseService::list($request->only('category', 'search', 'per_page'));

        return $this->success($courses);
    }

    /**
     * Kurs tafsilotlari (sotib olmagan foydalanuvchi uchun video URL yashiriladi)
     */
    public function show(Course $course): JsonResponse
    {
        $course->load(['user:id,name,username,avatar', 'lessons']);

        $user = auth()->user();
        $purchased = CoursePurchase::where('user_id', $user->id)
            ->where('course_id', $course->id)
            ->exists();

        $lessons = $course->lessons->map(function ($lesson) use ($purchased) {
            $data = [
                'id'               => $lesson->id,
                'title'            => $lesson->title,
                'duration_minutes' => $lesson->duration_minutes,
                'sort_order'       => $lesson->sort_order,
            ];

            if ($purchased) {
                $data['video_url'] = $lesson->video_url;
            }

            return $data;
        });

        $progress = null;
        if ($purchased) {
            $progress = CourseService::getProgress($user, $course);
        }

        return $this->success([
            'course' => [
                'id'             => $course->id,
                'title'          => $course->title,
                'description'    => $course->description,
                'price'          => (float) $course->price,
                'category'       => $course->category,
                'thumbnail'      => $course->thumbnail,
                'status'         => $course->status,
                'total_lessons'  => $course->total_lessons,
                'total_duration' => $course->total_duration,
                'instructor'     => $course->user,
                'created_at'     => $course->created_at?->toDateTimeString(),
            ],
            'lessons'   => $lessons,
            'purchased' => $purchased,
            'progress'  => $progress,
        ]);
    }

    /**
     * Kurs yaratish
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'required|string',
            'price'       => 'required|numeric|min:0.0001',
            'category'    => 'required|string|max:100',
            'thumbnail'   => 'nullable|string',
        ]);

        try {
            $course = CourseService::create(auth()->user(), $request->only(
                'title', 'description', 'price', 'category', 'thumbnail'
            ));

            return $this->success(['course' => $course], 'Kurs muvaffaqiyatli yaratildi', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * Dars qo'shish
     */
    public function addLesson(Request $request, Course $course): JsonResponse
    {
        if ($course->user_id !== auth()->id()) {
            return $this->error('Sizda bu kursga dars qo\'shish huquqi yo\'q', 403);
        }

        $request->validate([
            'title'            => 'required|string|max:255',
            'video_url'        => 'required|string|max:500',
            'duration_minutes' => 'required|integer|min:1',
            'sort_order'       => 'nullable|integer|min:1',
        ]);

        try {
            $lesson = CourseService::addLesson($course, $request->only(
                'title', 'video_url', 'duration_minutes', 'sort_order'
            ));

            return $this->success(['lesson' => $lesson], 'Dars muvaffaqiyatli qo\'shildi', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * Kursni nashr qilish
     */
    public function publish(Course $course): JsonResponse
    {
        if ($course->user_id !== auth()->id()) {
            return $this->error('Sizda bu kursni nashr qilish huquqi yo\'q', 403);
        }

        try {
            $course = CourseService::publish($course);
            return $this->success(['course' => $course], 'Kurs muvaffaqiyatli nashr qilindi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * Kursni sotib olish
     */
    public function purchase(Course $course): JsonResponse
    {
        if ($course->status !== 'published') {
            return $this->error('Faqat nashr qilingan kurslarni sotib olish mumkin', 422);
        }

        try {
            $purchase = CourseService::purchase(auth()->user(), $course);
            return $this->success(['purchase' => $purchase], 'Kurs muvaffaqiyatli sotib olindi');
        } catch (\Exception $e) {
            $code = str_contains($e->getMessage(), 'allaqachon') ? 409 : 400;
            return $this->error($e->getMessage(), $code);
        }
    }

    /**
     * Darsni tugatish
     */
    public function completeLesson(CourseLesson $lesson): JsonResponse
    {
        try {
            $progress = CourseService::completeLesson(auth()->user(), $lesson);
            $courseProgress = CourseService::getProgress(auth()->user(), $lesson->course);

            return $this->success([
                'progress'        => $progress,
                'course_progress' => $courseProgress,
            ], 'Dars tugatildi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 403);
        }
    }

    /**
     * Sotib olingan kurslar
     */
    public function myPurchases(): JsonResponse
    {
        $purchases = CourseService::myPurchases(auth()->user());

        $data = $purchases->map(function ($purchase) {
            $progress = CourseService::getProgress(auth()->user(), $purchase->course);
            return [
                'id'         => $purchase->id,
                'course'     => $purchase->course,
                'amount'     => (float) $purchase->amount,
                'progress'   => $progress,
                'created_at' => $purchase->created_at?->toDateTimeString(),
            ];
        });

        return $this->success($data);
    }
}
