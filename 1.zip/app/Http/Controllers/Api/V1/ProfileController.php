<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Level\XpLog;
use App\Services\FileUploadService;
use App\Services\QuestService;
use App\Services\XpService;
use App\Models\Game\Quest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProfileController extends Controller
{
    use ApiResponse;

    public function show(): JsonResponse
    {
        $user = auth()->user();

        return $this->success([
            'name'               => $user->name,
            'username'           => $user->username,
            'email'              => $user->email,
            'phone'              => $user->phone,
            'avatar_url'         => $user->avatar_url,
            'level'              => $user->userLevel?->level ?? 0,
            'kyc_status'         => $user->kyc_status ?? 'none',
            'kyc_stage'          => $user->kyc_stage,
            'kyc_type'           => $user->kyc_type,
            'kyc_verified_at'    => $user->kyc_verified_at?->toIso8601String(),
            'kyc_rejection_reason' => $user->kyc_rejection_reason,
            'created_at'         => $user->created_at?->toIso8601String(),
            'telegram_username'  => $user->telegram_username,
            'telegram_photo_url' => $user->telegram_photo_url,
        ]);
    }

    public function update(Request $request): JsonResponse
    {
        $user = auth()->user();

        $validated = $request->validate([
            'name'     => 'required|string|max:100',
            'username' => 'required|alpha_dash|max:30|unique:users,username,' . $user->id,
            'email'    => 'required|email|unique:users,email,' . $user->id,
            'phone'    => 'nullable|string|max:20',
            'avatar'   => 'nullable|image|max:5120',
        ]);

        $data = $request->only('name', 'username', 'email', 'phone');

        if ($request->hasFile('avatar')) {
            $file = FileUploadService::upload($request->file('avatar'), 'avatars');
            $data['avatar'] = $file->path;
        }

        $user->update($data);
        $user->refresh();

        // Award 30 XP once when profile is fully filled (name, phone, avatar all present)
        if ($user->name && $user->phone && $user->avatar) {
            $alreadyAwarded = XpLog::where('user_id', $user->id)
                ->where('action', XpLog::ACTION_PROFILE)
                ->exists();

            if (!$alreadyAwarded) {
                XpService::award($user, XpLog::ACTION_PROFILE, 30, 'Profil to\'ldirildi');
                QuestService::updateProgress($user, Quest::REQ_PROFILE_FILL);
            }
        }

        return $this->success([
            'name'               => $user->name,
            'username'           => $user->username,
            'email'              => $user->email,
            'phone'              => $user->phone,
            'avatar_url'         => $user->avatar_url,
            'level'              => $user->userLevel?->level ?? 0,
            'kyc_status'         => $user->kyc_status ?? 'none',
            'kyc_stage'          => $user->kyc_stage,
            'kyc_type'           => $user->kyc_type,
            'kyc_verified_at'    => $user->kyc_verified_at?->toIso8601String(),
            'kyc_rejection_reason' => $user->kyc_rejection_reason,
            'created_at'         => $user->created_at?->toIso8601String(),
            'telegram_username'  => $user->telegram_username,
            'telegram_photo_url' => $user->telegram_photo_url,
        ]);
    }
}
