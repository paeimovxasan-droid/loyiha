<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\Marketing\ChallengeService;
use Illuminate\Http\JsonResponse;

class InviteChallengeController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/invite-challenge — challenge holati
     */
    public function index(): JsonResponse
    {
        $status = ChallengeService::getStatus(auth()->user());

        return $this->success([
            'active'    => $status !== null,
            'challenge' => $status,
        ]);
    }

    /**
     * POST /api/v1/invite-challenge/start — yangi challenge boshlash
     */
    public function start(): JsonResponse
    {
        try {
            $challenge = ChallengeService::start(auth()->user());

            return $this->success([
                'challenge' => [
                    'id'         => $challenge->id,
                    'target'     => $challenge->target_referrals,
                    'reward_ais' => (float) $challenge->reward_ais,
                    'ends_at'    => $challenge->ends_at->toDateTimeString(),
                ],
            ], 'Challenge boshlandi!');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }
}
