<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Credit\Credit;
use App\Services\Credit\CreditService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CreditController extends Controller
{
    use ApiResponse;

    /**
     * Kredit reytingini olish
     */
    public function rating(): JsonResponse
    {
        $rating = CreditService::calculateRating(auth()->user());

        return $this->success([
            'score'      => $rating['score'],
            'max_amount' => $rating['max_amount'],
            'rates'      => $rating['rates'],
        ]);
    }

    /**
     * Kredit so'rovi
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'amount'    => 'required|numeric|min:10000|max:500000',
            'term_days' => 'required|in:7,14,30',
            'currency'  => 'sometimes|in:UZS,AIS',
        ]);

        try {
            $credit = CreditService::issue(
                auth()->user(),
                (float) $request->amount,
                (int) $request->term_days,
                $request->input('currency', 'UZS')
            );
        } catch (\Exception $e) {
            $message = $e->getMessage();

            if (str_contains($message, 'KYC')) {
                return $this->error($message, 403);
            }
            if (str_contains($message, 'faol kredit')) {
                return $this->error($message, 409);
            }

            return $this->error($message, 422);
        }

        return $this->success([
            'credit' => [
                'id'              => $credit->id,
                'amount'          => (float) $credit->amount,
                'currency'        => $credit->currency,
                'interest_rate'   => (float) $credit->interest_rate,
                'interest_amount' => (float) $credit->interest_amount,
                'term_days'       => $credit->term_days,
                'credit_score'    => $credit->credit_score,
                'status'          => $credit->status,
                'issued_at'       => $credit->issued_at?->toIso8601String(),
                'due_date'        => $credit->due_date?->toIso8601String(),
            ],
        ], 'Kredit muvaffaqiyatli berildi');
    }

    /**
     * Foydalanuvchi kreditlari ro'yxati
     */
    public function index(): JsonResponse
    {
        $credits = auth()->user()->credits()->latest()->paginate(20);

        $items = collect($credits->items())->map(fn($c) => [
            'id'              => $c->id,
            'amount'          => (float) $c->amount,
            'currency'        => $c->currency,
            'interest_rate'   => (float) $c->interest_rate,
            'interest_amount' => (float) $c->interest_amount,
            'term_days'       => $c->term_days,
            'credit_score'    => $c->credit_score,
            'status'          => $c->status,
            'issued_at'       => $c->issued_at?->toIso8601String(),
            'due_date'        => $c->due_date?->toIso8601String(),
            'paid_at'         => $c->paid_at?->toIso8601String(),
        ]);

        return $this->success([
            'credits'    => $items,
            'pagination' => [
                'current_page' => $credits->currentPage(),
                'last_page'    => $credits->lastPage(),
                'per_page'     => $credits->perPage(),
                'total'        => $credits->total(),
            ],
        ]);
    }

    /**
     * Kredit qaytarish
     */
    public function repay(Credit $credit): JsonResponse
    {
        try {
            $payment = CreditService::repay(auth()->user(), $credit);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        return $this->success([
            'payment' => [
                'id'        => $payment->id,
                'amount'    => (float) $payment->amount,
                'principal' => (float) $payment->principal,
                'interest'  => (float) $payment->interest,
                'currency'  => $payment->currency,
            ],
        ], 'Kredit muvaffaqiyatli qaytarildi');
    }
}
