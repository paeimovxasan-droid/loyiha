<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Crowdfunding\CfProject;
use App\Services\CrowdfundingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CrowdfundingController extends Controller
{
    use ApiResponse;

    /**
     * Aktiv loyihalar ro'yxati (filter: category, status) + pagination
     */
    public function index(Request $request): JsonResponse
    {
        $query = CfProject::query();

        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        } else {
            $query->where('status', 'active');
        }

        $projects = $query->latest()->paginate(15);

        $items = $projects->getCollection()->map(fn(CfProject $p) => [
            'id'               => $p->id,
            'title'            => $p->title,
            'description'      => $p->description,
            'category'         => $p->category,
            'goal_amount'      => (float) $p->goal_amount,
            'collected_amount' => (float) $p->collected_amount,
            'progress'         => $p->progress,
            'status'           => $p->status,
            'expires_at'       => $p->expires_at?->toDateTimeString(),
            'created_at'       => $p->created_at?->toDateTimeString(),
        ]);

        return $this->success([
            'projects' => $items,
            'pagination' => [
                'current_page' => $projects->currentPage(),
                'last_page'    => $projects->lastPage(),
                'per_page'     => $projects->perPage(),
                'total'        => $projects->total(),
            ],
        ]);
    }

    /**
     * Loyiha tafsilotlari + progress + xayriyachilar + xarajatlar
     */
    public function show(CfProject $project): JsonResponse
    {
        $donors = $project->donations()
            ->with('user:id,name,username')
            ->latest()
            ->get()
            ->map(fn($d) => [
                'user'   => $d->user?->name,
                'amount' => (float) $d->amount,
                'date'   => $d->created_at?->toDateTimeString(),
            ]);

        $expenses = $project->expenses()
            ->latest('spent_at')
            ->get()
            ->map(fn($e) => [
                'amount'      => (float) $e->amount,
                'description' => $e->description,
                'spent_at'    => $e->spent_at?->toDateString(),
            ]);

        return $this->success([
            'project' => [
                'id'               => $project->id,
                'title'            => $project->title,
                'description'      => $project->description,
                'category'         => $project->category,
                'goal_amount'      => (float) $project->goal_amount,
                'collected_amount' => (float) $project->collected_amount,
                'progress'         => $project->progress,
                'status'           => $project->status,
                'expires_at'       => $project->expires_at?->toDateTimeString(),
                'created_at'       => $project->created_at?->toDateTimeString(),
            ],
            'donors'   => $donors,
            'expenses' => $expenses,
        ]);
    }

    /**
     * Yangi loyiha yaratish
     */
    public function store(Request $request): JsonResponse
    {
        $data = $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'required|string',
            'category'    => 'required|in:kocha_tamiri,maktab_jihozlash,kasb_orgatish',
            'goal_amount' => 'required|numeric|min:1',
            'expires_at'  => 'required|date|after:today',
        ]);

        $project = CrowdfundingService::createProject(auth()->user(), $data);

        return $this->success([
            'project' => [
                'id'          => $project->id,
                'title'       => $project->title,
                'status'      => $project->status,
                'goal_amount' => (float) $project->goal_amount,
                'expires_at'  => $project->expires_at?->toDateTimeString(),
            ],
        ], 'Loyiha yaratildi va admin tasdiqini kutmoqda', 201);
    }

    /**
     * Xayriya qilish
     */
    public function donate(Request $request, CfProject $project): JsonResponse
    {
        $request->validate([
            'amount' => 'required|numeric|min:0.0001',
        ]);

        try {
            $donation = CrowdfundingService::donate(
                auth()->user(),
                $project,
                (float) $request->amount
            );
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        return $this->success([
            'donation' => [
                'id'     => $donation->id,
                'amount' => (float) $donation->amount,
            ],
        ], 'Xayriya muvaffaqiyatli amalga oshirildi');
    }
}
