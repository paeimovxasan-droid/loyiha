<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Game\Task;
use App\Models\Game\UserTask;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    use ApiResponse;

    /**
     * Foydalanuvchining aktiv paket darajasiga mos topshiriqlar + yuborish statusi
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();

        $maxPackageLevel = $user->purchases()
            ->where('status', 'active')
            ->count();

        $tasks = Task::where('status', 'active')
            ->where('required_package_level', '<=', $maxPackageLevel)
            ->orderBy('sort_order')
            ->get();

        $myTasks = UserTask::where('user_id', $user->id)
            ->pluck('status', 'task_id');

        $taskList = $tasks->map(fn($task) => [
            'id'          => $task->id,
            'title'       => $task->getTranslation('title', app()->getLocale()),
            'description' => $task->getTranslation('description', app()->getLocale()),
            'link'        => $task->link,
            'platform'    => $task->platform,
            'reward'      => (float) $task->reward,
            'status'      => $myTasks->get($task->id, 'not_submitted'),
        ]);

        return $this->success(['tasks' => $taskList]);
    }

    /**
     * Topshiriq yuborish — proof matnini qabul qilish
     */
    public function submit(Request $request, Task $task): JsonResponse
    {
        $user = auth()->user();

        if (UserTask::where('user_id', $user->id)->where('task_id', $task->id)->exists()) {
            return $this->error('Bu topshiriqni allaqachon yubordingiz', 422);
        }

        $request->validate([
            'proof' => 'nullable|string|max:500',
        ]);

        $userTask = UserTask::create([
            'user_id' => $user->id,
            'task_id' => $task->id,
            'proof'   => $request->proof,
            'status'  => 'pending',
        ]);

        return $this->success([
            'user_task' => [
                'id'     => $userTask->id,
                'status' => $userTask->status,
                'proof'  => $userTask->proof,
            ],
        ], 'Topshiriq yuborildi. Admin tasdiqlashini kuting.');
    }
}
