<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Education\Certificate;
use App\Services\Education\CertificateService;
use Illuminate\Http\JsonResponse;

class CertificateController extends Controller
{
    use ApiResponse;

    /**
     * Mening sertifikatlarim
     */
    public function index(): JsonResponse
    {
        $certificates = Certificate::where('user_id', auth()->id())
            ->with('course:id,title,category')
            ->latest('issued_at')
            ->get()
            ->map(fn($cert) => [
                'id'        => $cert->id,
                'course'    => $cert->course,
                'code'      => $cert->code,
                'issued_at' => $cert->issued_at?->toDateTimeString(),
            ]);

        return $this->success($certificates);
    }

    /**
     * Sertifikatni yuklab olish (HTML)
     */
    public function download(Certificate $certificate)
    {
        if ($certificate->user_id !== auth()->id()) {
            return $this->error('Sizda bu sertifikatni yuklab olish huquqi yo\'q', 403);
        }

        return CertificateService::downloadPdf($certificate);
    }

    /**
     * Sertifikatni tekshirish (public)
     */
    public function verify(string $code): JsonResponse
    {
        $certificate = CertificateService::verify($code);

        if (!$certificate) {
            return $this->error('Sertifikat topilmadi', 404);
        }

        return $this->success([
            'certificate' => [
                'code'      => $certificate->code,
                'user_name' => $certificate->user->name ?? null,
                'course'    => $certificate->course->title ?? null,
                'issued_at' => $certificate->issued_at?->toDateTimeString(),
            ],
        ]);
    }
}
