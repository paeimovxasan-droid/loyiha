<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\GigEconomy\GigApplication;
use App\Models\GigEconomy\GigListing;
use App\Services\GigEconomyService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class GigEconomyController extends Controller
{
    use ApiResponse;

    public function listings(Request $request): JsonResponse
    {
        $query = GigListing::where('status', 'open');

        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }
        if ($request->filled('location')) {
            $query->where('location', 'like', '%' . $request->location . '%');
        }

        $listings = $query->with('user:id,name')->latest()->paginate(15);
        return $this->success(['listings' => $listings->items()]);
    }

    public function showListing(GigListing $listing): JsonResponse
    {
        $listing->load('user:id,name', 'applications.user:id,name', 'ratings');
        return $this->success(['listing' => $listing]);
    }

    public function storeListing(Request $request): JsonResponse
    {
        $data = $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'required|string',
            'category'    => 'required|in:yuk_tashish,tozalash,qurilish,kuryer',
            'location'    => 'required|string|max:255',
            'price'       => 'required|numeric|min:0.0001',
            'work_date'   => 'required|date|after_or_equal:today',
        ]);

        $listing = GigEconomyService::createListing(auth()->user(), $data);
        return $this->success(['listing' => $listing], 'E\'lon yaratildi', 201);
    }

    public function apply(GigListing $listing): JsonResponse
    {
        try {
            $application = GigEconomyService::apply(auth()->user(), $listing);
            return $this->success(['application' => $application], 'Ariza berildi', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function acceptApplication(GigApplication $application): JsonResponse
    {
        $listing = $application->listing;
        if ($listing->user_id !== auth()->id()) {
            return $this->error('Ruxsat yo\'q', 403);
        }

        try {
            $application = GigEconomyService::acceptApplication($application);
            return $this->success(['application' => $application], 'Ariza qabul qilindi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function completeListing(GigListing $listing): JsonResponse
    {
        if ($listing->user_id !== auth()->id()) {
            return $this->error('Ruxsat yo\'q', 403);
        }

        try {
            $listing = GigEconomyService::completeListing($listing);
            return $this->success(['listing' => $listing], 'Ish yakunlandi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function rate(Request $request, GigListing $listing): JsonResponse
    {
        $data = $request->validate([
            'rating'  => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string',
        ]);

        try {
            $rating = GigEconomyService::rate(auth()->user(), $listing, $data['rating'], $data['comment'] ?? null);
            return $this->success(['rating' => $rating], 'Baho berildi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function myListings(): JsonResponse
    {
        $listings = GigListing::where('user_id', auth()->id())
            ->withCount('applications')
            ->latest()->get();
        return $this->success(['listings' => $listings]);
    }

    public function myApplications(): JsonResponse
    {
        $applications = GigApplication::where('user_id', auth()->id())
            ->with('listing:id,title,price,status')
            ->latest()->get();
        return $this->success(['applications' => $applications]);
    }
}
