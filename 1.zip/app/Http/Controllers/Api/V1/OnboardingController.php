<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\Marketing\OnboardingService;
use Illuminate\Http\JsonResponse;

class OnboardingController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/onboarding — onboarding progressi
     */
    public function index(): JsonResponse
    {
        $progress = OnboardingService::getProgress(auth()->user());

        return $this->success($progress);
    }
}
