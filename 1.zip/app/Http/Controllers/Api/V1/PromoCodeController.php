<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\Marketing\PromoService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PromoCodeController extends Controller
{
    use ApiResponse;

    /**
     * POST /api/v1/promo/redeem
     */
    public function redeem(Request $request): JsonResponse
    {
        $request->validate([
            'code' => 'required|string|max:50',
        ]);

        try {
            $result = PromoService::redeem(auth()->user(), $request->input('code'));

            return $this->success([
                'reward_ais' => $result['ais'],
                'reward_xp'  => $result['xp'],
            ], 'Promo-kod muvaffaqiyatli ishlatildi!');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }
}
