<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Tokenization\Asset;
use App\Services\TokenizationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TokenController extends Controller
{
    use ApiResponse;

    public function assets(): JsonResponse
    {
        $assets = Asset::where('status', '!=', 'closed')
            ->latest()->paginate(15);

        return $this->success(['assets' => $assets->items()]);
    }

    public function showAsset(Asset $asset): JsonResponse
    {
        return $this->success([
            'asset' => $asset,
            'sold_tokens' => $asset->sold_tokens,
        ]);
    }

    public function purchase(Request $request, Asset $asset): JsonResponse
    {
        $request->validate([
            'quantity' => 'required|integer|min:1',
        ]);

        try {
            $purchase = TokenizationService::purchaseTokens(
                auth()->user(), $asset, (int) $request->quantity
            );
            return $this->success(['purchase' => $purchase], 'Token sotib olindi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function portfolio(): JsonResponse
    {
        $portfolio = TokenizationService::getUserPortfolio(auth()->user());
        return $this->success(['portfolio' => $portfolio]);
    }
}
