<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\AdNetwork\Ad;
use App\Models\AdNetwork\AdCampaign;
use App\Services\AdService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AdController extends Controller
{
    use ApiResponse;

    public function index(): JsonResponse
    {
        $ads = AdService::getAvailableAds(auth()->user());
        return $this->success(['ads' => $ads]);
    }

    public function createCampaign(Request $request): JsonResponse
    {
        $data = $request->validate([
            'name'          => 'required|string|max:255',
            'budget'        => 'required|numeric|min:1',
            'cost_per_view' => 'required|numeric|min:0.0001',
        ]);

        try {
            $campaign = AdService::createCampaign(auth()->user(), $data);
            return $this->success(['campaign' => $campaign], 'Kampaniya yaratildi', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function myCampaigns(): JsonResponse
    {
        $campaigns = AdCampaign::where('user_id', auth()->id())
            ->withCount('ads')
            ->latest()->get();
        return $this->success(['campaigns' => $campaigns]);
    }

    public function showCampaign(AdCampaign $campaign): JsonResponse
    {
        if ($campaign->user_id !== auth()->id()) {
            return $this->error('Ruxsat yo\'q', 403);
        }

        $campaign->load('ads');
        $totalViews = $campaign->ads->sum(fn($ad) => $ad->views()->count());

        return $this->success([
            'campaign'    => $campaign,
            'total_views' => $totalViews,
        ]);
    }

    public function createAd(Request $request, AdCampaign $campaign): JsonResponse
    {
        if ($campaign->user_id !== auth()->id()) {
            return $this->error('Ruxsat yo\'q', 403);
        }

        $data = $request->validate([
            'title'       => 'required|string|max:255',
            'description' => 'required|string',
            'image_url'   => 'nullable|string|max:500',
            'target_url'  => 'nullable|string|max:500',
        ]);

        $ad = AdService::createAd($campaign, $data);
        return $this->success(['ad' => $ad], 'Reklama yaratildi', 201);
    }

    public function watchAd(Ad $ad): JsonResponse
    {
        try {
            $view = AdService::watchAd(auth()->user(), $ad);
            return $this->success([
                'earned' => (float) $view->earned,
            ], 'Reklama ko\'rildi, AIS ishlandi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }
}
