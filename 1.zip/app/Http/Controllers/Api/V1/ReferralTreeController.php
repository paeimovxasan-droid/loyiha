<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Finance\Commission;
use App\Models\User;
use App\Services\Marketing\ReferralTreeService;
use App\Services\Marketing\SocialProofService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ReferralTreeController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/referral-tree — statistika va daraxt
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();

        $stats = ReferralTreeService::getLevelStats($user);
        $tree  = ReferralTreeService::getTree($user);

        return $this->success([
            'stats' => $stats,
            'tree'  => $tree,
        ]);
    }

    /**
     * GET /api/v1/referral-tree/level/{level} — daraja bo'yicha referrallar (paginated)
     */
    public function level(Request $request, int $level): JsonResponse
    {
        if ($level < 1 || $level > 3) {
            return $this->error('Daraja 1 dan 3 gacha bo\'lishi kerak.', 422);
        }

        $user = auth()->user();
        $perPage = 15;
        $page = (int) $request->input('page', 1);

        // Daraja bo'yicha referrallarni olish
        $referrals = $this->getReferralsByLevel($user, $level);

        $total = $referrals->count();
        $paginated = $referrals->forPage($page, $perPage);

        $items = $paginated->map(fn (User $ref) => [
            'masked_name'   => SocialProofService::maskName($ref->name),
            'level'         => $level,
            'registered_at' => $ref->created_at->toDateString(),
            'is_active'     => $ref->status === 'active',
            'commission'    => (float) Commission::where('user_id', $user->id)
                ->where('from_user_id', $ref->id)
                ->sum('amount'),
        ])->values();

        return $this->success([
            'referrals'  => $items,
            'pagination' => [
                'current_page' => $page,
                'last_page'    => (int) ceil($total / $perPage),
                'per_page'     => $perPage,
                'total'        => $total,
            ],
        ]);
    }

    private function getReferralsByLevel(User $user, int $level): \Illuminate\Support\Collection
    {
        $level1 = User::where('referred_by', $user->username)->get();

        if ($level === 1) {
            return $level1;
        }

        $level1Usernames = $level1->pluck('username');
        $level2 = User::whereIn('referred_by', $level1Usernames)->get();

        if ($level === 2) {
            return $level2;
        }

        $level2Usernames = $level2->pluck('username');
        return User::whereIn('referred_by', $level2Usernames)->get();
    }
}
