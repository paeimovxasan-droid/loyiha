<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Catalog\CatalogOrder;
use App\Models\Catalog\Product;
use App\Models\Catalog\Shop;
use App\Services\Catalog\CatalogOrderService;
use App\Services\Catalog\ShopService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class CatalogController extends Controller
{
    use ApiResponse;

    // ─── Shop CRUD ─────────────────────────────────────────────────────

    public function shopStore(Request $request): JsonResponse
    {
        $request->validate([
            'name'             => 'required|string|max:255',
            'category'         => 'required|string|max:100',
            'address'          => 'required|string|max:255',
            'phone'            => 'required|string|max:20',
            'description'      => 'nullable|string',
            'image'            => 'nullable|string',
            'cashback_percent' => 'nullable|numeric|min:1|max:5',
        ]);

        try {
            $shop = ShopService::createShop($request->user(), $request->all());
            return $this->success($shop, 'Do\'kon muvaffaqiyatli yaratildi.', 201);
        } catch (\Exception $e) {
            $code = match ($e->getMessage()) {
                'Sizda allaqachon do\'kon mavjud.' => 409,
                'Balansingiz yetarli emas.'        => 422,
                default                            => 422,
            };
            return $this->error($e->getMessage(), $code);
        }
    }

    public function shopUpdate(Request $request, Shop $shop): JsonResponse
    {
        if ($shop->user_id !== $request->user()->id) {
            return $this->error('Sizga ruxsat berilmagan.', 403);
        }

        $request->validate([
            'name'             => 'nullable|string|max:255',
            'category'         => 'nullable|string|max:100',
            'address'          => 'nullable|string|max:255',
            'phone'            => 'nullable|string|max:20',
            'description'      => 'nullable|string',
            'image'            => 'nullable|string',
            'cashback_percent' => 'nullable|numeric|min:1|max:5',
        ]);

        try {
            $shop = ShopService::updateShop($shop, $request->all());
            return $this->success($shop, 'Do\'kon yangilandi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function shopIndex(Request $request): JsonResponse
    {
        $query = Shop::where('status', Shop::STATUS_ACTIVE);

        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }

        if ($request->filled('address')) {
            $query->where('address', 'like', '%' . $request->address . '%');
        }

        if ($request->filled('min_rating')) {
            $query->where('avg_rating', '>=', (float) $request->min_rating);
        }

        $shops = $query->orderByDesc('avg_rating')
            ->paginate($request->input('per_page', 15));

        return $this->success($shops);
    }

    public function shopShow(Shop $shop): JsonResponse
    {
        $shop->load(['products' => fn($q) => $q->active(), 'reviews.reviewer']);
        return $this->success($shop);
    }

    // ─── Product CRUD ──────────────────────────────────────────────────

    public function productStore(Request $request, Shop $shop): JsonResponse
    {
        if ($shop->user_id !== $request->user()->id) {
            return $this->error('Sizga ruxsat berilmagan.', 403);
        }

        $request->validate([
            'name'        => 'required|string|max:255',
            'description' => 'nullable|string',
            'price'       => 'required|numeric|gt:0',
            'image'       => 'nullable|string',
        ]);

        try {
            $product = ShopService::addProduct($shop, $request->all());
            return $this->success($product, 'Mahsulot qo\'shildi.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function productUpdate(Request $request, Product $product): JsonResponse
    {
        if ($product->shop->user_id !== $request->user()->id) {
            return $this->error('Sizga ruxsat berilmagan.', 403);
        }

        $request->validate([
            'name'        => 'nullable|string|max:255',
            'description' => 'nullable|string',
            'price'       => 'nullable|numeric|gt:0',
            'image'       => 'nullable|string',
        ]);

        try {
            $product = ShopService::updateProduct($product, $request->all());
            return $this->success($product, 'Mahsulot yangilandi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function productDestroy(Request $request, Product $product): JsonResponse
    {
        if ($product->shop->user_id !== $request->user()->id) {
            return $this->error('Sizga ruxsat berilmagan.', 403);
        }

        ShopService::deleteProduct($product);
        return $this->success(null, 'Mahsulot o\'chirildi.');
    }

    public function productIndex(Request $request): JsonResponse
    {
        $query = Product::active()->with('shop');

        if ($request->filled('shop_id')) {
            $query->where('shop_id', $request->shop_id);
        }

        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $products = $query->orderByDesc('created_at')
            ->paginate($request->input('per_page', 15));

        return $this->success($products);
    }

    // ─── Orders ────────────────────────────────────────────────────────

    public function orderStore(Request $request): JsonResponse
    {
        $request->validate([
            'product_id' => 'required|exists:products,id',
        ]);

        $product = Product::active()->findOrFail($request->product_id);

        try {
            $order = CatalogOrderService::placeOrder($request->user(), $product);
            return $this->success($order, 'Buyurtma yaratildi.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function orderIndex(Request $request): JsonResponse
    {
        $user = $request->user();

        $orders = CatalogOrder::where(function ($q) use ($user) {
            $q->where('buyer_id', $user->id)
              ->orWhere('seller_id', $user->id);
        })
        ->with(['product', 'shop', 'buyer', 'seller'])
        ->orderByDesc('created_at')
        ->paginate(15);

        return $this->success($orders);
    }

    public function orderConfirm(Request $request, CatalogOrder $order): JsonResponse
    {
        try {
            $order = CatalogOrderService::confirmOrder($order, $request->user());
            return $this->success($order, 'Buyurtma tasdiqlandi.');
        } catch (\Exception $e) {
            $code = $e->getMessage() === 'Sizga ruxsat berilmagan.' ? 403 : 422;
            return $this->error($e->getMessage(), $code);
        }
    }

    public function orderDeliver(Request $request, CatalogOrder $order): JsonResponse
    {
        try {
            $order = CatalogOrderService::deliverOrder($order, $request->user());
            return $this->success($order, 'Buyurtma yetkazildi.');
        } catch (\Exception $e) {
            $code = $e->getMessage() === 'Sizga ruxsat berilmagan.' ? 403 : 422;
            return $this->error($e->getMessage(), $code);
        }
    }

    public function orderComplete(Request $request, CatalogOrder $order): JsonResponse
    {
        try {
            $order = CatalogOrderService::completeOrder($order, $request->user());
            return $this->success($order, 'Buyurtma yakunlandi.');
        } catch (\Exception $e) {
            $code = $e->getMessage() === 'Sizga ruxsat berilmagan.' ? 403 : 422;
            return $this->error($e->getMessage(), $code);
        }
    }

    // ─── Reviews ───────────────────────────────────────────────────────

    public function reviewStore(Request $request, CatalogOrder $order): JsonResponse
    {
        $request->validate([
            'rating'  => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string',
        ]);

        try {
            $review = CatalogOrderService::leaveReview($order, $request->user(), $request->all());
            return $this->success($review, 'Sharh qo\'yildi.', 201);
        } catch (\Exception $e) {
            $code = match ($e->getMessage()) {
                'Bu buyurtmaga allaqachon sharh berilgan.' => 409,
                'Sizga ruxsat berilmagan.'                 => 403,
                default                                    => 422,
            };
            return $this->error($e->getMessage(), $code);
        }
    }
}
