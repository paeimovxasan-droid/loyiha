<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\Marketing\MembershipService;
use Illuminate\Http\JsonResponse;

class VipMembershipController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/vip — VIP holati
     */
    public function index(): JsonResponse
    {
        $status = MembershipService::getStatus(auth()->user());

        return $this->success($status);
    }
}
