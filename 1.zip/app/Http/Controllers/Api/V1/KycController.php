<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Security\AuditLog;
use App\Models\User;
use App\Services\Security\FaceKycService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class KycController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/kyc/status
     * Joriy KYC holati, bosqich va rad etish sababi
     */
    public function status(): JsonResponse
    {
        $user = auth()->user();

        return $this->success([
            'status'           => $user->kyc_status ?? 'none',
            'stage'            => $user->kyc_stage,
            'type'             => $user->kyc_type,
            'rejection_reason' => $user->kyc_rejection_reason,
            'submitted_at'     => $user->kyc_submitted_at?->toIso8601String(),
            'verified_at'      => $user->kyc_verified_at?->toIso8601String(),
        ]);
    }

    /**
     * POST /api/v1/kyc/passport
     * 1-bosqich: Pasport rasmini yuklash
     */
    public function submitPassport(Request $request): JsonResponse
    {
        $user = auth()->user();

        // Allaqachon yuborilgan yoki tasdiqlangan bo'lsa rad etish
        if (in_array($user->kyc_status, ['passport_pending', 'passport_verified', 'face_pending', 'verified'])) {
            return $this->error('KYC allaqachon yuborilgan yoki ko\'rib chiqilmoqda.', 409);
        }

        $request->validate([
            'document_front' => 'required|image|mimes:jpg,jpeg,png,webp|max:5120',
            'document_back'  => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'document_type'  => 'required|in:passport,id_card',
        ]);

        try {
            DB::transaction(function () use ($user, $request) {
                // Concurrent lock — parallel so'rovlarni bloklash
                $freshUser = User::lockForUpdate()->find($user->id);

                if (in_array($freshUser->kyc_status, ['passport_pending', 'passport_verified', 'face_pending', 'verified'])) {
                    throw new \Exception('KYC allaqachon yuborilgan yoki ko\'rib chiqilmoqda.', 409);
                }

                $docFrontPath = FaceKycService::saveKycImagePublic(
                    $request->file('document_front'),
                    'kyc/documents',
                    $user->id
                );

                $docBackPath = $request->hasFile('document_back')
                    ? FaceKycService::saveKycImagePublic(
                        $request->file('document_back'),
                        'kyc/documents',
                        $user->id
                    )
                    : null;

                $freshUser->update([
                    'kyc_status'           => 'passport_pending',
                    'kyc_stage'            => 'passport',
                    'kyc_type'             => 'passport',
                    'kyc_document'         => $docFrontPath,
                    'kyc_submitted_at'     => now(),
                    'kyc_rejection_reason' => null,
                ]);
            });

            try {
                AuditLog::log('kyc_passport_submitted', $user);
            } catch (\Throwable $e) {
                Log::warning('KycController API: AuditLog error', ['error' => $e->getMessage()]);
            }

            return $this->success(
                ['status' => 'passport_pending'],
                'Pasport yuborildi. Admin ko\'rib chiqadi.'
            );

        } catch (\Exception $e) {
            if ($e->getCode() === 409) {
                return $this->error($e->getMessage(), 409);
            }
            Log::error('KYC passport API submit failed', ['user_id' => $user->id, 'error' => $e->getMessage()]);
            return $this->error('Xatolik yuz berdi. Qaytadan urinib ko\'ring.', 500);
        }
    }
}
