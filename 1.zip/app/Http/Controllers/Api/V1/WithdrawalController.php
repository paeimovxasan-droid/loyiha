<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Payment\PaymentMethod;
use App\Models\Payment\Withdrawal;
use App\Models\Setting;
use App\Services\Security\TwoFactorService;
use App\Models\Security\AuditLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WithdrawalController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/withdrawals/scoring
     * Foydalanuvchining yechish skoringini olish
     */
    public function scoring(): JsonResponse
    {
        $scoring = \App\Services\WithdrawalScoringService::calculate(auth()->user());

        return $this->success([
            'score'        => $scoring['score'],
            'min_score'    => $scoring['min_score'],
            'can_withdraw' => $scoring['can_withdraw'],
            'message'      => $scoring['message'],
            'details'      => $scoring['details'],
        ]);
    }

    /**
     * GET /api/v1/withdrawals
     * Sahifalangan yechishlar tarixi
     */
    public function index(): JsonResponse
    {
        $withdrawals = auth()->user()
            ->withdrawals()
            ->with('paymentMethod')
            ->latest()
            ->paginate(15);

        $items = $withdrawals->getCollection()->map(fn(Withdrawal $w) => [
            'id'           => $w->id,
            'amount'       => (float) $w->amount,
            'charge'       => (float) $w->charge,
            'final_amount' => (float) $w->final_amount,
            'status'       => $w->status,
            'method_name'  => $w->method_name,
            'created_at'   => $w->created_at?->toIso8601String(),
        ]);

        return $this->success([
            'withdrawals' => $items,
            'pagination'  => [
                'current_page' => $withdrawals->currentPage(),
                'last_page'    => $withdrawals->lastPage(),
                'per_page'     => $withdrawals->perPage(),
                'total'        => $withdrawals->total(),
            ],
        ]);
    }

    /**
     * POST /api/v1/withdrawals
     * Yangi yechish so'rovi yaratish
     */
    public function store(Request $request): JsonResponse
    {
        $setting = Setting::get();

        $request->validate([
            'payment_method_id' => 'required|exists:payment_methods,id',
            'amount'            => "required|numeric|min:{$setting->min_withdraw}|max:{$setting->max_withdraw}",
            'account_number'    => 'required|string|max:64',
            'two_fa_code'       => 'nullable|string|size:6',
        ]);

        $user = auth()->user();

        // ═══ WITHDRAWAL SCORING TEKSHIRUVI ═══
        $scoring = \App\Services\WithdrawalScoringService::calculate($user);
        if (!$scoring['can_withdraw']) {
            return $this->error($scoring['message'], 403, [
                'scoring' => [
                    'score' => $scoring['score'],
                    'min_score' => $scoring['min_score'],
                    'details' => $scoring['details'],
                ],
            ]);
        }

        // ═══ HAR YECHISH OLDIDAN YANGI DEPOZIT MAJBURIY ═══
        $lastWithdrawal = Withdrawal::where('user_id', $user->id)
            ->latest()
            ->first();

        $lastWithdrawalDate = $lastWithdrawal?->created_at;

        $newDepositAfterLastWithdrawal = \App\Models\Payment\Deposit::where('user_id', $user->id)
            ->where('status', 'approved')
            ->where('final_amount', '>=', $setting->min_deposit)
            ->when($lastWithdrawalDate, fn($q) => $q->where('created_at', '>', $lastWithdrawalDate))
            ->exists();

        if ($lastWithdrawal && !$newDepositAfterLastWithdrawal) {
            return $this->error(
                "Har yechish oldidan yangi depozit qilish majburiy. Kamida " . number_format($setting->min_deposit, 0) . " UZS miqdorida depozit qiling.",
                403
            );
        }

        // Yangi depozit talabi — so'nggi 7 kunda kamida 1 ta
        $recentDeposit = \App\Models\Payment\Deposit::where('user_id', $user->id)
            ->where('status', 'approved')
            ->where('created_at', '>=', now()->subDays(7))
            ->exists();

        if (!$recentDeposit) {
            return $this->error("Yechib olish uchun so'nggi 7 kun ichida kamida 1 ta yangi depozit qilishingiz kerak.", 403);
        }

        // 2FA tekshiruvi
        if ($user->two_fa_enabled) {
            if (!$request->two_fa_code || !TwoFactorService::verify($user->two_fa_secret, $request->two_fa_code)) {
                return $this->error('2FA kod noto\'g\'ri.', 422);
            }
        }
        $method = PaymentMethod::findOrFail($request->payment_method_id);

        // Global fee + method fee
        $globalFeePercent = (float) ($setting->withdrawal_fee_percent ?? 1.0);
        $methodFeePercent = (float) ($method->withdraw_charge_percent ?? 0);
        $totalFeePercent  = $globalFeePercent + $methodFeePercent;

        $charge      = round($request->amount * $totalFeePercent / 100, 2);
        $finalAmount = $request->amount - $charge;

        try {
            $withdrawal = DB::transaction(function () use ($user, $method, $request, $charge, $finalAmount) {
                // Pessimistic lock
                $user = \App\Models\User::lockForUpdate()->find($user->id);

                if ($user->balance < $request->amount) {
                    throw new \Exception('Balansingiz yetarli emas.');
                }

                $balanceBefore = $user->balance;

                $user->decrement('balance', $request->amount);
                $user->refresh();

                $withdrawal = Withdrawal::create([
                    'user_id'           => $user->id,
                    'payment_method_id' => $method->id,
                    'method_name'       => $method->getTranslation('name', app()->getLocale()),
                    'receiver_number'   => $request->account_number,
                    'amount'            => $request->amount,
                    'charge'            => $charge,
                    'final_amount'      => $finalAmount,
                    'status'            => 'pending',
                ]);

                $user->transactions()->create([
                    'amount'                => $request->amount,
                    'type'                  => 'withdraw',
                    'direction'             => 'debit',
                    'balance_before'        => $balanceBefore,
                    'balance_after'         => $user->balance,
                    'status'                => 'pending',
                    'description'           => $method->getTranslation('name', app()->getLocale()) . ' ga pul yechish so\'rovi',
                    'transactionable_type'  => Withdrawal::class,
                    'transactionable_id'    => $withdrawal->id,
                ]);

                AuditLog::log('withdrawal_requested', $withdrawal, [
                    'amount'         => $request->amount,
                    'method'         => $method->name,
                    'account_number' => $request->account_number,
                ]);

                return $withdrawal;
            });
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        return $this->success([
            'withdrawal' => [
                'id'           => $withdrawal->id,
                'amount'       => (float) $withdrawal->amount,
                'charge'       => (float) $withdrawal->charge,
                'final_amount' => (float) $withdrawal->final_amount,
                'status'       => $withdrawal->status,
                'method_name'  => $withdrawal->method_name,
                'created_at'   => $withdrawal->created_at?->toIso8601String(),
            ],
        ], 'Yechish so\'rovi yuborildi. Admin tasdiqlashini kuting.', 201);
    }
}
