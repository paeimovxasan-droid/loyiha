<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Level\LevelConfig;
use App\Models\Level\UserLevel;
use App\Models\Level\XpLog;
use Illuminate\Http\JsonResponse;

class LevelController extends Controller
{
    use ApiResponse;

    /**
     * Daraja ma'lumotlari — level, title, XP, progress
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();

        $userLevel = UserLevel::firstOrCreate(['user_id' => $user->id], [
            'level' => 0, 'total_xp' => 0, 'current_xp' => 0,
            'next_level_xp' => 100, 'title' => 'Newcomer', 'badge_color' => '#64748b',
        ]);

        return $this->success([
            'level'            => $userLevel->level,
            'title'            => $userLevel->title,
            'total_xp'         => $userLevel->total_xp,
            'current_xp'       => $userLevel->current_xp,
            'next_level_xp'    => $userLevel->next_level_xp,
            'progress_percent' => $userLevel->progress_percent,
            'badge_color'      => $userLevel->badge_color,
        ]);
    }

    /**
     * So'nggi 20 ta XP log yozuvi
     */
    public function xpHistory(): JsonResponse
    {
        $logs = XpLog::where('user_id', auth()->id())
            ->latest()
            ->limit(20)
            ->get()
            ->map(fn($log) => [
                'action'      => $log->action,
                'xp'          => $log->xp,
                'description' => $log->description,
                'created_at'  => $log->created_at?->toIso8601String(),
            ]);

        return $this->success(['xp_logs' => $logs]);
    }

    /**
     * Top 50 foydalanuvchi + joriy foydalanuvchi reytingi
     */
    public function leaderboard(): JsonResponse
    {
        $topUsers = UserLevel::with('user:id,name,username,avatar')
            ->orderByDesc('total_xp')
            ->limit(50)
            ->get()
            ->map(fn($ul) => [
                'name'       => $ul->user?->name,
                'username'   => $ul->user?->username,
                'avatar'     => $ul->user?->avatar,
                'level'      => $ul->level,
                'total_xp'   => $ul->total_xp,
                'title'      => $ul->title,
                'badge_color' => $ul->badge_color,
            ]);

        $userLevel = UserLevel::where('user_id', auth()->id())->first();
        $userRank = UserLevel::where('total_xp', '>', $userLevel?->total_xp ?? 0)->count() + 1;

        return $this->success([
            'top_users' => $topUsers,
            'user_rank' => $userRank,
        ]);
    }

    /**
     * Barcha daraja konfiguratsiyalari (milestones)
     */
    public function milestones(): JsonResponse
    {
        $milestones = LevelConfig::orderBy('level')->get()->map(fn($config) => [
            'level'       => $config->level,
            'title'       => $config->title,
            'badge_color' => $config->badge_color,
            'xp_required' => $config->xp_required,
            'ref_bonus_percent'     => (float) $config->ref_bonus_percent,
            'cashback_percent'      => (float) $config->cashback_percent,
            'daily_mining_bonus'    => (float) $config->daily_mining_bonus,
            'transfer_fee_discount' => (float) $config->transfer_fee_discount,
            'virtual_card_unlocked' => $config->virtual_card_unlocked,
            'p2p_unlocked'          => $config->p2p_unlocked,
        ]);

        return $this->success(['milestones' => $milestones]);
    }
}
