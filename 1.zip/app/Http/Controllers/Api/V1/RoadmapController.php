<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\RoadmapService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class RoadmapController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/roadmap — modullar ro'yxati
     */
    public function index(Request $request): JsonResponse
    {
        $status = $request->query('status');
        $userId = $request->user()?->id;

        $modules = RoadmapService::getModules($status, $userId);

        return $this->success($modules);
    }

    /**
     * POST /api/v1/roadmap/{id}/vote — ovoz berish toggle
     */
    public function vote(Request $request, int $id): JsonResponse
    {
        try {
            $result = RoadmapService::toggleVote($request->user(), $id);
            return $this->success($result);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return $this->error('Roadmap modul topilmadi', 404);
        }
    }

    /**
     * POST /api/v1/roadmap/{id}/notify — obuna toggle
     */
    public function notify(Request $request, int $id): JsonResponse
    {
        try {
            $result = RoadmapService::toggleNotify($request->user(), $id);
            return $this->success($result);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return $this->error('Roadmap modul topilmadi', 404);
        }
    }
}
