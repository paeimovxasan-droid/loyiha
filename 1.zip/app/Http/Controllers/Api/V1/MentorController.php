<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Education\MentorProfile;
use App\Models\Education\MentorSession;
use App\Services\Education\MentorService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MentorController extends Controller
{
    use ApiResponse;

    /**
     * Mentorlar ro'yxati
     */
    public function index(Request $request): JsonResponse
    {
        $mentors = MentorService::list($request->only('expertise', 'per_page'));

        return $this->success($mentors);
    }

    /**
     * Mentor profili yaratish
     */
    public function createProfile(Request $request): JsonResponse
    {
        $request->validate([
            'expertise'   => 'required|string|max:255',
            'bio'         => 'required|string',
            'hourly_rate' => 'required|numeric|min:0.0001',
        ]);

        try {
            $profile = MentorService::createProfile(auth()->user(), $request->only(
                'expertise', 'bio', 'hourly_rate'
            ));

            return $this->success(['profile' => $profile], 'Mentor profili yaratildi', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * Mentorlik so'rovi yuborish
     */
    public function requestSession(Request $request, MentorProfile $mentor): JsonResponse
    {
        $request->validate([
            'hours'   => 'required|integer|min:1',
            'message' => 'nullable|string',
        ]);

        try {
            $session = MentorService::requestSession(auth()->user(), $mentor, $request->only(
                'hours', 'message'
            ));

            return $this->success(['session' => $session], 'Mentorlik so\'rovi yuborildi', 201);
        } catch (\Exception $e) {
            $code = str_contains($e->getMessage(), 'O\'zingizga') ? 422 : 400;
            return $this->error($e->getMessage(), $code);
        }
    }

    /**
     * So'rovni qabul qilish
     */
    public function acceptSession(MentorSession $session): JsonResponse
    {
        // Faqat mentor qabul qilishi mumkin
        $mentorProfile = $session->mentorProfile;
        if ($mentorProfile->user_id !== auth()->id()) {
            return $this->error('Sizda bu so\'rovni qabul qilish huquqi yo\'q', 403);
        }

        try {
            $session = MentorService::acceptSession($session);
            return $this->success(['session' => $session], 'So\'rov qabul qilindi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * Seansni tugatish
     */
    public function completeSession(MentorSession $session): JsonResponse
    {
        $mentorProfile = $session->mentorProfile;
        if ($mentorProfile->user_id !== auth()->id()) {
            return $this->error('Sizda bu seansni tugatish huquqi yo\'q', 403);
        }

        try {
            $session = MentorService::completeSession($session);
            return $this->success(['session' => $session], 'Seans tugatildi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * Mening seanslarim
     */
    public function mySessions(): JsonResponse
    {
        $user = auth()->user();

        // Talaba sifatida
        $asStudent = MentorSession::where('student_id', $user->id)
            ->with('mentorProfile.user:id,name,username')
            ->latest()
            ->get();

        // Mentor sifatida
        $asMentor = collect();
        $mentorProfile = $user->mentorProfile;
        if ($mentorProfile) {
            $asMentor = MentorSession::where('mentor_profile_id', $mentorProfile->id)
                ->with('student:id,name,username')
                ->latest()
                ->get();
        }

        return $this->success([
            'as_student' => $asStudent,
            'as_mentor'  => $asMentor,
        ]);
    }
}
