<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Savings\SavingsPlan;
use App\Services\Savings\SavingsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SavingsController extends Controller
{
    use ApiResponse;

    /**
     * Jamg'arma rejasi yaratish
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'term_months'    => 'required|in:3,6,12',
            'monthly_amount' => 'required|numeric|min:1',
            'currency'       => 'sometimes|in:UZS,AIS',
        ]);

        try {
            $plan = SavingsService::createPlan(
                auth()->user(),
                (int) $request->term_months,
                (float) $request->monthly_amount,
                $request->input('currency', 'UZS')
            );
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        return $this->success([
            'plan' => self::formatPlan($plan),
        ], 'Jamg\'arma rejasi yaratildi');
    }

    /**
     * Foydalanuvchi rejalari
     */
    public function index(): JsonResponse
    {
        $plans = auth()->user()->savingsPlans()->latest()->paginate(20);

        $items = collect($plans->items())->map(fn($p) => self::formatPlan($p));

        return $this->success([
            'plans'      => $items,
            'pagination' => [
                'current_page' => $plans->currentPage(),
                'last_page'    => $plans->lastPage(),
                'per_page'     => $plans->perPage(),
                'total'        => $plans->total(),
            ],
        ]);
    }

    /**
     * Reja tafsilotlari
     */
    public function show(SavingsPlan $plan): JsonResponse
    {
        if ($plan->user_id !== auth()->id()) {
            return $this->error('Bu reja sizga tegishli emas.', 403);
        }

        return $this->success([
            'plan'     => self::formatPlan($plan),
            'payments' => $plan->payments()->latest()->get()->map(fn($p) => [
                'id'           => $p->id,
                'amount'       => (float) $p->amount,
                'month_number' => $p->month_number,
                'status'       => $p->status,
                'created_at'   => $p->created_at?->toIso8601String(),
            ]),
        ]);
    }

    /**
     * Muddatidan oldin yechish
     */
    public function cancel(SavingsPlan $plan): JsonResponse
    {
        if ($plan->user_id !== auth()->id()) {
            return $this->error('Bu reja sizga tegishli emas.', 403);
        }

        try {
            SavingsService::cancelPlan($plan);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        return $this->success(null, 'Jamg\'arma bekor qilindi. Yig\'ilgan summa qaytarildi (bonussiz).');
    }

    private static function formatPlan(SavingsPlan $plan): array
    {
        return [
            'id'                => $plan->id,
            'term_months'       => $plan->term_months,
            'monthly_amount'    => (float) $plan->monthly_amount,
            'currency'          => $plan->currency,
            'bonus_rate'        => (float) $plan->bonus_rate,
            'total_saved'       => (float) $plan->total_saved,
            'paid_months'       => $plan->paid_months,
            'status'            => $plan->status,
            'next_payment_date' => $plan->next_payment_date?->toDateString(),
            'created_at'        => $plan->created_at?->toIso8601String(),
        ];
    }
}
