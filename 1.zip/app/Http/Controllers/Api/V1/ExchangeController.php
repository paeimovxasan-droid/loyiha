<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Exchange\ExchangeOrder;
use App\Models\Exchange\ExchangeTrade;
use App\Services\Exchange\ExchangeService;
use App\Services\Exchange\OhlcvService;
use App\Services\Exchange\OrderBookService;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use App\Http\Requests\Exchange\StoreExchangeOrderRequest;

class ExchangeController extends Controller
{
    use ApiResponse;

    /**
     * POST /api/v1/exchange/orders — Buyurtma berish
     */
    public function placeOrder(StoreExchangeOrderRequest $request): JsonResponse
    {

        try {
            $user = auth()->user();

            if ($request->type === 'limit') {
                $order = ExchangeService::placeLimitOrder(
                    $user,
                    $request->side,
                    (float) $request->price,
                    (float) $request->amount
                );
            } else {
                $order = ExchangeService::placeMarketOrder(
                    $user,
                    $request->side,
                    (float) $request->amount
                );
            }

            $trades = $order->side === 'buy'
                ? $order->buyTrades()->get()
                : $order->sellTrades()->get();

            return $this->success([
                'order'  => static::formatOrder($order),
                'trades' => $trades->map(fn ($t) => static::formatTrade($t))->values(),
            ], 'Buyurtma muvaffaqiyatli yaratildi.');
        } catch (\Exception $e) {
            $code = match (true) {
                str_contains($e->getMessage(), 'to\'xtatilgan') => 503,
                str_contains($e->getMessage(), 'Ruxsat')        => 403,
                default                                          => 422,
            };
            return $this->error($e->getMessage(), $code);
        }
    }

    /**
     * DELETE /api/v1/exchange/orders/{order} — Buyurtmani bekor qilish
     */
    public function cancelOrder(ExchangeOrder $order): JsonResponse
    {
        try {
            $user = auth()->user();
            $order = ExchangeService::cancelOrder($user, $order);

            return $this->success([
                'order'           => static::formatOrder($order),
                'unfrozen_amount' => (float) $order->remaining_amount,
            ], 'Buyurtma bekor qilindi.');
        } catch (\Exception $e) {
            $code = str_contains($e->getMessage(), 'Ruxsat') ? 403 : 422;
            return $this->error($e->getMessage(), $code);
        }
    }

    /**
     * GET /api/v1/exchange/orders/open — Ochiq buyurtmalar
     */
    public function myOpenOrders(): JsonResponse
    {
        $orders = ExchangeOrder::where('user_id', auth()->id())
            ->active()
            ->orderByDesc('created_at')
            ->get()
            ->map(fn ($o) => static::formatOrder($o));

        return $this->success(['orders' => $orders]);
    }

    /**
     * GET /api/v1/exchange/orders/history — Buyurtma tarixi
     */
    public function myOrderHistory(Request $request): JsonResponse
    {
        $perPage = min((int) $request->get('per_page', 20), 100);

        $orders = ExchangeOrder::where('user_id', auth()->id())
            ->orderByDesc('created_at')
            ->paginate($perPage);

        return $this->success([
            'orders'     => collect($orders->items())->map(fn ($o) => static::formatOrder($o)),
            'pagination' => [
                'current_page' => $orders->currentPage(),
                'last_page'    => $orders->lastPage(),
                'per_page'     => $orders->perPage(),
                'total'        => $orders->total(),
            ],
        ]);
    }

    /**
     * GET /api/v1/exchange/trades/my — Shaxsiy savdo tarixi
     */
    public function myTrades(Request $request): JsonResponse
    {
        $perPage = min((int) $request->get('per_page', 20), 100);
        $userId  = auth()->id();

        $trades = ExchangeTrade::where(function ($q) use ($userId) {
                $q->where('buyer_id', $userId)->orWhere('seller_id', $userId);
            })
            ->orderByDesc('created_at')
            ->paginate($perPage);

        return $this->success([
            'trades'     => collect($trades->items())->map(fn ($t) => static::formatTrade($t)),
            'pagination' => [
                'current_page' => $trades->currentPage(),
                'last_page'    => $trades->lastPage(),
                'per_page'     => $trades->perPage(),
                'total'        => $trades->total(),
            ],
        ]);
    }

    /**
     * GET /api/v1/exchange/trades/recent — So'nggi savdolar (public)
     */
    public function recentTrades(Request $request): JsonResponse
    {
        $limit = min((int) $request->get('limit', 50), 100);

        $trades = ExchangeTrade::orderByDesc('created_at')
            ->limit($limit)
            ->get()
            ->map(fn ($t) => [
                'price'      => (float) $t->price,
                'amount'     => (float) $t->amount,
                'total'      => (float) $t->total,
                'side'       => $t->buyOrder?->user_id === $t->buyer_id ? 'buy' : 'sell',
                'created_at' => $t->created_at?->toIso8601String(),
            ]);

        return $this->success(['trades' => $trades]);
    }

    /**
     * GET /api/v1/exchange/order-book — Order book (public)
     */
    public function orderBook(Request $request): JsonResponse
    {
        $depth = min((int) $request->get('depth', 20), 50);
        return $this->success(OrderBookService::getOrderBook($depth));
    }

    /**
     * GET /api/v1/exchange/ticker — Bozor statistikasi (public)
     */
    public function ticker(): JsonResponse
    {
        return $this->success(OhlcvService::getTicker());
    }

    /**
     * GET /api/v1/exchange/candles — OHLCV (public)
     */
    public function candles(Request $request): JsonResponse
    {
        $request->validate([
            'interval' => 'nullable|in:1h,1d,1w,1M',
            'from'     => 'nullable|date',
            'to'       => 'nullable|date',
        ]);

        $interval = $request->get('interval', '1h');
        $from     = $request->from ? Carbon::parse($request->from) : null;
        $to       = $request->to ? Carbon::parse($request->to) : null;

        $candles = OhlcvService::getCandles($interval, $from, $to);

        return $this->success(['candles' => $candles]);
    }

    // ─── Helpers ───────────────────────────────────────────────────────

    private static function formatOrder(ExchangeOrder $order): array
    {
        return [
            'id'               => $order->id,
            'reference'        => $order->reference,
            'type'             => $order->type,
            'side'             => $order->side,
            'price'            => $order->price ? (float) $order->price : null,
            'amount'           => (float) $order->amount,
            'filled_amount'    => (float) $order->filled_amount,
            'remaining_amount' => (float) $order->remaining_amount,
            'avg_fill_price'   => $order->avg_fill_price ? (float) $order->avg_fill_price : null,
            'total_fee'        => (float) $order->total_fee,
            'status'           => $order->status,
            'created_at'       => $order->created_at?->toIso8601String(),
        ];
    }

    private static function formatTrade(ExchangeTrade $trade): array
    {
        return [
            'id'          => $trade->id,
            'price'       => (float) $trade->price,
            'amount'      => (float) $trade->amount,
            'total'       => (float) $trade->total,
            'buyer_fee'   => (float) $trade->buyer_fee,
            'seller_fee'  => (float) $trade->seller_fee,
            'buyer_role'  => $trade->buyer_role,
            'seller_role' => $trade->seller_role,
            'created_at'  => $trade->created_at?->toIso8601String(),
        ];
    }
}
