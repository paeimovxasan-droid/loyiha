<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Game\LuckyDraw;
use App\Models\Game\LuckyDrawTicket;
use App\Models\Game\Quest;
use App\Models\Level\XpLog;
use App\Models\User;
use App\Services\QuestService;
use App\Services\XpService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class LuckyDrawController extends Controller
{
    use ApiResponse;

    /**
     * Aktiv Lucky Draw lar va foydalanuvchining so'nggi chiptalari
     */
    public function index(): JsonResponse
    {
        $draws = LuckyDraw::where('status', 'active')->latest()->get()->map(fn($draw) => [
            'id'            => $draw->id,
            'name'          => $draw->getTranslation('name', app()->getLocale()),
            'entry_fee'     => (float) $draw->entry_fee,
            'prize_amount'  => (float) $draw->prize_amount,
            'max_tickets'   => $draw->max_tickets,
            'tickets_sold'  => $draw->getTotalTicketsSold(),
            'draw_at'       => $draw->draw_at?->toIso8601String(),
        ]);

        $myTickets = LuckyDrawTicket::where('user_id', auth()->id())
            ->with('luckyDraw')
            ->latest()
            ->limit(10)
            ->get()
            ->map(fn($ticket) => [
                'id'         => $ticket->id,
                'draw_name'  => $ticket->luckyDraw?->getTranslation('name', app()->getLocale()),
                'quantity'   => $ticket->quantity,
                'total_paid' => (float) $ticket->total_paid,
                'is_winner'  => $ticket->is_winner,
                'prize_won'  => (float) ($ticket->prize_won ?? 0),
                'created_at' => $ticket->created_at?->toIso8601String(),
            ]);

        return $this->success([
            'draws'      => $draws,
            'my_tickets' => $myTickets,
        ]);
    }

    /**
     * Chipta xarid qilish
     */
    public function buy(Request $request, LuckyDraw $draw): JsonResponse
    {
        $request->validate([
            'quantity' => 'required|integer|min:1|max:100',
        ]);

        if ($draw->status !== 'active') {
            return $this->error('Bu o\'yin faol emas', 422);
        }

        $user     = auth()->user();
        $quantity = (int) $request->quantity;
        $total    = $draw->entry_fee * $quantity;

        try {
            $ticket = DB::transaction(function () use ($user, $draw, $quantity, $total) {
                $user = User::lockForUpdate()->find($user->id);

                if ($user->balance < $total) {
                    throw new \Exception('Balansingiz yetarli emas.');
                }

                if ($draw->max_tickets > 0) {
                    $sold = LuckyDrawTicket::where('lucky_draw_id', $draw->id)->sum('quantity');
                    if ($sold + $quantity > $draw->max_tickets) {
                        throw new \Exception('Yetarli chipta qolmagan.');
                    }
                }

                $user->decrement('balance', $total);

                $ticket = LuckyDrawTicket::create([
                    'user_id'       => $user->id,
                    'lucky_draw_id' => $draw->id,
                    'quantity'      => $quantity,
                    'total_paid'    => $total,
                ]);

                // XP va Quest — transaksiya ichida
                XpService::award($user, XpLog::ACTION_LUCKY_DRAW, 15 * $quantity, "Lucky Draw: {$quantity} ta chipta");
                QuestService::updateProgress($user, Quest::REQ_LUCKY_DRAW, $quantity);

                return $ticket;
            });
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        return $this->success([
            'ticket' => [
                'id'         => $ticket->id,
                'quantity'   => $ticket->quantity,
                'total_paid' => (float) $ticket->total_paid,
            ],
        ], "{$quantity} ta chipta xarid qilindi!");
    }
}
