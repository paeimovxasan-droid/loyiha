<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\Security\TwoFactorService;
use App\Models\Security\AuditLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SecurityController extends Controller
{
    use ApiResponse;

    /**
     * 2FA holatini ko'rish va yangi secret olish
     */
    public function getTwoFactorStatus(): JsonResponse
    {
        $user = auth()->user();
        
        $data = [
            'enabled' => (bool) $user->two_fa_enabled,
        ];

        if (!$user->two_fa_enabled) {
            // Agar yoqilmagan bo'lsa, yangi secret generatsiya qilamiz (agar hali yo'q bo'lsa)
            $secret = $user->two_fa_secret ?: TwoFactorService::generateSecret();
            
            if (!$user->two_fa_secret) {
                $user->update(['two_fa_secret' => $secret]);
            }

            $data['secret'] = $secret;
            $data['qr_url'] = TwoFactorService::getQrCodeUrl($user->email ?? $user->username, $secret);
        }

        return $this->success($data);
    }

    /**
     * 2FA ni yoqish
     */
    public function enableTwoFactor(Request $request): JsonResponse
    {
        $request->validate([
            'code' => 'required|string|size:6',
        ]);

        $user = auth()->user();

        if ($user->two_fa_enabled) {
            return $this->error('2FA allaqachon yoqilgan.', 422);
        }

        if (!TwoFactorService::verify($user->two_fa_secret, $request->code)) {
            return $this->error('Tasdiqlash kodi noto\'g\'ri.', 422);
        }

        $user->update(['two_fa_enabled' => true]);

        AuditLog::log('2fa_enabled');

        return $this->success(null, 'Ikki bosqichli autentifikatsiya muvaffaqiyatli yoqildi.');
    }

    /**
     * 2FA ni o'chirish
     */
    public function disableTwoFactor(Request $request): JsonResponse
    {
        $request->validate([
            'code' => 'required|string|size:6',
        ]);

        $user = auth()->user();

        if (!$user->two_fa_enabled) {
            return $this->error('2FA yoqilmagan.', 422);
        }

        if (!TwoFactorService::verify($user->two_fa_secret, $request->code)) {
            return $this->error('Tasdiqlash kodi noto\'g\'ri.', 422);
        }

        $user->update([
            'two_fa_enabled' => false,
            'two_fa_secret'  => null,
        ]);

        AuditLog::log('2fa_disabled');

        return $this->success(null, 'Ikki bosqichli autentifikatsiya o\'chirildi.');
    }
}
