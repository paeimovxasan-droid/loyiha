<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\Marketing\SocialProofService;
use Illuminate\Http\JsonResponse;

class SocialProofController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/social-proof — so'nggi hodisalar va kunlik statistika
     */
    public function index(): JsonResponse
    {
        $events = SocialProofService::getRecent();
        $stats  = SocialProofService::getDailyStats();

        return $this->success([
            'events' => $events,
            'stats'  => $stats,
        ]);
    }
}
