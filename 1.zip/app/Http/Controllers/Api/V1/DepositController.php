<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Payment\Deposit;
use App\Models\Payment\PaymentMethod;
use App\Models\Setting;
use App\Services\FileUploadService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class DepositController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/deposits
     * Sahifalangan depozitlar tarixi
     */
    public function index(): JsonResponse
    {
        $deposits = auth()->user()
            ->deposits()
            ->with('paymentMethod')
            ->latest()
            ->paginate(15);

        $items = $deposits->getCollection()->map(fn(Deposit $d) => [
            'id'           => $d->id,
            'amount'       => (float) $d->amount,
            'charge'       => (float) $d->charge,
            'final_amount' => (float) $d->final_amount,
            'status'       => $d->status,
            'method_name'  => $d->method_name,
            'created_at'   => $d->created_at?->toIso8601String(),
        ]);

        return $this->success([
            'deposits'   => $items,
            'pagination' => [
                'current_page' => $deposits->currentPage(),
                'last_page'    => $deposits->lastPage(),
                'per_page'     => $deposits->perPage(),
                'total'        => $deposits->total(),
            ],
        ]);
    }

    /**
     * POST /api/v1/deposits
     * Yangi depozit yaratish
     */
    public function store(Request $request): JsonResponse
    {
        $setting = Setting::get();

        $request->validate([
            'payment_method_id' => 'required|exists:payment_methods,id',
            'amount'            => "required|numeric|min:{$setting->min_deposit}|max:{$setting->max_deposit}",
            'sender_number'     => ['required', 'string', 'max:64', 'regex:/^[\d\s\+\-\(\)]+$/'],
            'screenshot'        => 'nullable|image|max:5120',
        ]);

        $method = PaymentMethod::findOrFail($request->payment_method_id);
        $charge = round($request->amount * $method->deposit_charge_percent / 100, 2);
        $finalAmount = $request->amount - $charge;

        $screenshotPath = null;
        if ($request->hasFile('screenshot')) {
            $file = FileUploadService::upload($request->file('screenshot'), 'deposits/screenshots');
            $screenshotPath = $file->path;
        }

        $deposit = Deposit::create([
            'user_id'           => auth()->id(),
            'payment_method_id' => $method->id,
            'method_name'       => $method->getTranslation('name', app()->getLocale()),
            'method_number'     => $method->number,
            'order_id'          => (string) Str::uuid(),
            'sender_number'     => $request->sender_number,
            'amount'            => $request->amount,
            'charge'            => $charge,
            'final_amount'      => $finalAmount,
            'screenshot'        => $screenshotPath,
            'status'            => 'pending',
        ]);

        return $this->success([
            'deposit' => [
                'id'           => $deposit->id,
                'amount'       => (float) $deposit->amount,
                'charge'       => (float) $deposit->charge,
                'final_amount' => (float) $deposit->final_amount,
                'status'       => $deposit->status,
                'method_name'  => $deposit->method_name,
                'created_at'   => $deposit->created_at?->toIso8601String(),
            ],
        ], 'Depozit so\'rovi yuborildi. Admin tasdiqlashini kuting.', 201);
    }
}
