<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    use ApiResponse;

    /**
     * Sahifalangan tranzaksiyalar; type va direction bo'yicha filtrlash
     */
    public function index(Request $request): JsonResponse
    {
        $query = auth()->user()->transactions()->latest();

        if ($request->filled('type')) {
            $types = explode(',', $request->type);
            if (count($types) > 1) {
                $query->whereIn('type', $types);
            } else {
                $query->where('type', $request->type);
            }
        }

        if ($request->filled('direction')) {
            $query->where('direction', $request->direction);
        }

        $transactions = $query->paginate(20);

        $items = collect($transactions->items())->map(fn($tx) => [
            'id'             => $tx->id,
            'amount'         => (float) $tx->amount,
            'type'           => $tx->type,
            'direction'      => $tx->direction,
            'balance_before' => (float) $tx->balance_before,
            'balance_after'  => (float) $tx->balance_after,
            'status'         => $tx->status,
            'description'    => $tx->description,
            'created_at'     => $tx->created_at?->toIso8601String(),
        ]);

        return $this->success([
            'transactions' => $items,
            'pagination'   => [
                'current_page' => $transactions->currentPage(),
                'last_page'    => $transactions->lastPage(),
                'per_page'     => $transactions->perPage(),
                'total'        => $transactions->total(),
            ],
        ]);
    }
}
