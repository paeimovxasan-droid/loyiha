<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\Marketing\ShareService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ShareController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/share — ulashish statistikasi (auth kerak)
     */
    public function index(): JsonResponse
    {
        $stats = ShareService::getStats(auth()->user());

        return $this->success($stats);
    }

    /**
     * GET /api/v1/s/{code} — public endpoint, klikni qayd etish va redirect
     */
    public function track(Request $request, string $code)
    {
        ShareService::trackClick(
            $code,
            $request->ip(),
            $request->userAgent() ?? ''
        );

        $botUsername = config('services.telegram.bot_username', 'aisoqqa_bot');

        return redirect("https://t.me/{$botUsername}?start=share_{$code}");
    }
}
