<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\TelegramBotService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class TelegramBotController extends Controller
{
    use ApiResponse;

    /**
     * Telegram webhook endpoint
     */
    public function webhook(Request $request): JsonResponse
    {
        // Webhook secret tekshirish
        $secret = config('services.telegram.webhook_secret');
        if ($secret && $request->header('X-Telegram-Bot-Api-Secret-Token') !== $secret) {
            return $this->error('Unauthorized', 401);
        }

        $update = $request->all();

        $service = new TelegramBotService();
        $service->handleWebhook($update);

        return $this->success(null, 'ok');
    }
}
