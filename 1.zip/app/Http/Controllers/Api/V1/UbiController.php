<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Ubi\UbiClaim;
use App\Models\Ubi\UbiSetting;
use App\Services\UbiService;
use Illuminate\Http\JsonResponse;

class UbiController extends Controller
{
    use ApiResponse;

    public function status(): JsonResponse
    {
        $user = auth()->user();
        $check = UbiService::canClaim($user);
        $setting = UbiSetting::current();

        return $this->success([
            'eligible'     => $check['eligible'],
            'reason'       => $check['reason'],
            'daily_amount' => (float) $setting->daily_amount,
            'is_active'    => $setting->is_active,
        ]);
    }

    public function claim(): JsonResponse
    {
        try {
            $claim = UbiService::claim(auth()->user());
            return $this->success([
                'claim' => [
                    'id'         => $claim->id,
                    'amount'     => (float) $claim->amount,
                    'claimed_at' => $claim->claimed_at->toDateString(),
                ],
            ], 'UBI muvaffaqiyatli olindi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function history(): JsonResponse
    {
        $claims = UbiClaim::where('user_id', auth()->id())
            ->latest('claimed_at')->paginate(30);

        return $this->success(['claims' => $claims->items()]);
    }

    public function stats(): JsonResponse
    {
        $userId = auth()->id();
        $totalClaimed = UbiClaim::where('user_id', $userId)->sum('amount');
        $claimCount = UbiClaim::where('user_id', $userId)->count();

        return $this->success([
            'total_claimed' => (float) $totalClaimed,
            'claim_count'   => $claimCount,
        ]);
    }
}
