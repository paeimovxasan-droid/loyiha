<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Savings\SavingGroup;
use App\Models\Savings\SavingGroupMember;
use App\Services\Savings\GroupSavingsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class GroupSavingsController extends Controller
{
    use ApiResponse;

    /**
     * Guruh yaratish
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'name'           => 'required|string|max:255',
            'max_members'    => 'required|integer|min:5|max:20',
            'monthly_amount' => 'required|numeric|min:1',
            'currency'       => 'sometimes|in:UZS,AIS',
        ]);

        try {
            $group = GroupSavingsService::createGroup(
                auth()->user(),
                $request->name,
                (int) $request->max_members,
                (float) $request->monthly_amount,
                $request->input('currency', 'UZS')
            );
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        return $this->success([
            'group' => self::formatGroup($group),
        ], 'Guruh yaratildi');
    }

    /**
     * Guruhlar ro'yxati (foydalanuvchi a'zo bo'lgan)
     */
    public function index(): JsonResponse
    {
        $groupIds = SavingGroupMember::where('user_id', auth()->id())
            ->pluck('saving_group_id');

        $groups = SavingGroup::whereIn('id', $groupIds)
            ->latest()
            ->paginate(20);

        $items = collect($groups->items())->map(fn($g) => self::formatGroup($g));

        return $this->success([
            'groups'     => $items,
            'pagination' => [
                'current_page' => $groups->currentPage(),
                'last_page'    => $groups->lastPage(),
                'per_page'     => $groups->perPage(),
                'total'        => $groups->total(),
            ],
        ]);
    }

    /**
     * Guruh tafsilotlari
     */
    public function show(SavingGroup $savingGroup): JsonResponse
    {
        $group = $savingGroup;

        return $this->success([
            'group'   => self::formatGroup($group),
            'members' => $group->members()->with('user:id,name,username')->get()->map(fn($m) => [
                'id'          => $m->id,
                'user'        => [
                    'id'       => $m->user->id,
                    'name'     => $m->user->name,
                    'username' => $m->user->username,
                ],
                'round_order' => $m->round_order,
                'status'      => $m->status,
                'joined_at'   => $m->joined_at?->toIso8601String(),
            ]),
            'rounds'  => $group->rounds()->latest()->get()->map(fn($r) => [
                'id'              => $r->id,
                'round_number'    => $r->round_number,
                'recipient_id'    => $r->recipient_id,
                'total_collected' => (float) $r->total_collected,
                'status'          => $r->status,
                'completed_at'    => $r->completed_at?->toIso8601String(),
            ]),
        ]);
    }

    /**
     * Guruhga qo'shilish so'rovi
     */
    public function join(SavingGroup $savingGroup): JsonResponse
    {
        try {
            $member = GroupSavingsService::joinRequest(auth()->user(), $savingGroup);
        } catch (\Exception $e) {
            $message = $e->getMessage();
            if (str_contains($message, 'to\'liq')) {
                return $this->error($message, 409);
            }
            return $this->error($message, 422);
        }

        return $this->success([
            'member' => [
                'id'     => $member->id,
                'status' => $member->status,
            ],
        ], 'Qo\'shilish so\'rovi yuborildi');
    }

    /**
     * So'rovni tasdiqlash (faqat admin)
     */
    public function approve(SavingGroup $savingGroup, SavingGroupMember $member): JsonResponse
    {
        if ($savingGroup->admin_id !== auth()->id()) {
            return $this->error('Faqat guruh admini tasdiqlashi mumkin.', 403);
        }

        try {
            GroupSavingsService::approveJoin($savingGroup, $member);
        } catch (\Exception $e) {
            $message = $e->getMessage();
            if (str_contains($message, 'to\'liq')) {
                return $this->error($message, 409);
            }
            return $this->error($message, 422);
        }

        // Guruh to'ldimi tekshirish — to'lsa navbat belgilash
        $savingGroup->refresh();
        if ($savingGroup->activeMembers()->count() >= $savingGroup->max_members) {
            GroupSavingsService::assignRounds($savingGroup);
        }

        return $this->success(null, 'A\'zo tasdiqlandi');
    }

    private static function formatGroup(SavingGroup $group): array
    {
        return [
            'id'              => $group->id,
            'name'            => $group->name,
            'admin_id'        => $group->admin_id,
            'max_members'     => $group->max_members,
            'monthly_amount'  => (float) $group->monthly_amount,
            'currency'        => $group->currency,
            'current_round'   => $group->current_round,
            'status'          => $group->status,
            'members_count'   => $group->activeMembers()->count(),
            'started_at'      => $group->started_at?->toIso8601String(),
            'created_at'      => $group->created_at?->toIso8601String(),
        ];
    }
}
