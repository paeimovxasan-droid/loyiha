<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Game\CheckIn;
use App\Models\Game\Quest;
use App\Models\Level\XpLog;
use App\Services\Marketing\BadgeService;
use App\Services\QuestService;
use App\Services\XpService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\DB;

class CheckInController extends Controller
{
    use ApiResponse;

    /**
     * Kunlik belgilash — streak, mukofot, XP, Quest progress
     */
    public function store(): JsonResponse
    {
        $user = auth()->user();

        if (CheckIn::todayFor($user->id)) {
            return $this->error('Bugun allaqachon belgiladingiz', 422);
        }

        // Streak hisoblash
        $yesterday = CheckIn::where('user_id', $user->id)
            ->whereDate('checked_at', today()->subDay())
            ->first();

        $streak = $yesterday ? ($yesterday->streak + 1) : 1;

        // Streak asosida reward
        $reward = match (true) {
            $streak >= 30 => 50.0,
            $streak >= 14 => 30.0,
            $streak >= 7  => 20.0,
            $streak >= 3  => 10.0,
            default       => 5.0,
        };

        // XP streak asosida
        $xp = 10 + min($streak * 2, 30);

        try {
            $checkIn = DB::transaction(function () use ($user, $streak, $reward, $xp) {
                // Ikki marta bosish oldini olish (race condition)
                if (CheckIn::todayFor($user->id)) {
                    throw new \Exception('Bugun allaqachon belgiladingiz.');
                }

                $checkIn = CheckIn::create([
                    'user_id'    => $user->id,
                    'checked_at' => today(),
                    'reward'     => $reward,
                    'streak'     => $streak,
                ]);

                // Balance, XP, Quest — hammasi bir transaksiyada
                // Agar birontasi xato bo'lsa — hammasi rollback bo'ladi
                $user->increment('balance', $reward);

                XpService::award(
                    $user,
                    XpLog::ACTION_CHECKIN,
                    $xp,
                    "Kunlik belgilash (streak: {$streak})",
                    $checkIn
                );

                QuestService::updateProgress($user, Quest::REQ_CHECKIN_STREAK, $streak);

                BadgeService::checkAndAward($user, $streak);

                return $checkIn;
            });
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }

        return $this->success([
            'reward' => $reward,
            'xp'     => $xp,
            'streak' => $streak,
        ], "Kunlik belgilash! +{$reward} UZS, +{$xp} XP. Streak: {$streak} kun");
    }
}
