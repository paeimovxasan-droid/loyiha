<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\AIS\AisRate;
use App\Models\AIS\VirtualCard;
use App\Models\Level\LevelConfig;
use App\Models\Level\UserLevel;
use App\Models\Setting;
use App\Services\WalletService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\Wallet\TransferRequest;
use App\Http\Requests\Wallet\ConvertRequest;
use App\Http\Requests\Wallet\CreateCardRequest;

class WalletController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/wallet
     * Hamyon ma'lumotlari: balans, kurs, kartalar, transferlar, konvertatsiyalar
     */
    public function index(): JsonResponse
    {
        $user   = auth()->user();
        $wallet = WalletService::createForUser($user);
        $rate   = AisRate::current();

        // firstOrCreate o'rniga where()->first() — GET da DB write bo'lmasligi kerak
        // UserLevel yo'q bo'lsa default qiymatlar ishlatiladi
        $level = UserLevel::where('user_id', $user->id)->first();

        $currentLevel = $level?->level ?? 0;
        $levelConfig  = LevelConfig::getForLevel($currentLevel);
        $p2pUnlocked  = $levelConfig?->p2p_unlocked ?? ($currentLevel >= 5);
        $cardUnlocked = $levelConfig?->virtual_card_unlocked ?? ($currentLevel >= 10);

        $cards = $user->virtualCards()
            ->where('status', '!=', 'cancelled')
            ->get()
            ->map(fn($card) => [
                'id'               => $card->id,
                'card_number'      => $card->card_number,
                'formatted_number' => $card->formatted_number,
                'card_holder'      => $card->card_holder,
                'expiry'           => $card->expiry,
                'status'           => $card->status,
                'daily_limit'      => (float) $card->daily_limit,
                'monthly_limit'    => (float) $card->monthly_limit,
            ]);

        $recentTransfers = collect()
            ->merge(
                $user->sentTransfers()->with('receiver:id,name,username')->latest()->limit(5)->get()
                    ->map(fn($t) => [
                        'type'       => 'sent',
                        'amount'     => (float) $t->amount,
                        'fee'        => (float) $t->fee,
                        'note'       => $t->note,
                        'reference'  => $t->reference,
                        'status'     => $t->status,
                        'user'       => $t->receiver?->name,
                        'username'   => $t->receiver?->username,
                        'created_at' => $t->created_at?->toIso8601String(),
                    ])
            )
            ->merge(
                $user->receivedTransfers()->with('sender:id,name,username')->latest()->limit(5)->get()
                    ->map(fn($t) => [
                        'type'       => 'received',
                        'amount'     => (float) $t->amount,
                        'fee'        => (float) $t->fee,
                        'note'       => $t->note,
                        'reference'  => $t->reference,
                        'status'     => $t->status,
                        'user'       => $t->sender?->name,
                        'username'   => $t->sender?->username,
                        'created_at' => $t->created_at?->toIso8601String(),
                    ])
            )
            ->sortByDesc('created_at')
            ->take(10)
            ->values();

        $recentConversions = $user->aisConversions()
            ->with('rate')
            ->latest()
            ->limit(5)
            ->get()
            ->map(fn($c) => [
                'id'         => $c->id,
                'direction'  => $c->direction,
                'uzs_amount' => (float) $c->uzs_amount,
                'ais_amount' => (float) $c->ais_amount,
                'rate_used'  => (float) $c->rate_used,
                'fee'        => (float) $c->fee,
                'status'     => $c->status,
                'created_at' => $c->created_at?->toIso8601String(),
            ]);

        return $this->success([
            'wallet' => [
                'balance'          => (float) $wallet->balance,
                'wallet_number'    => $wallet->wallet_number,
                'formatted_number' => $wallet->formatted_number,
                'is_frozen'        => $wallet->is_frozen,
            ],
            'rate' => [
                'rate_uzs'  => (float) $rate->rate_uzs,
                'buy_rate'  => (float) $rate->buy_rate,
                'sell_rate' => (float) $rate->sell_rate,
            ],
            'p2p_unlocked'       => $p2pUnlocked,
            'card_unlocked'      => $cardUnlocked,
            'cards'              => $cards,
            'recent_transfers'   => $recentTransfers,
            'recent_conversions' => $recentConversions,
        ]);
    }

    /**
     * POST /api/v1/wallet/transfer
     * P2P transfer: receiver, amount, note
     */
    public function transfer(TransferRequest $request): JsonResponse
    {

        $user  = auth()->user();
        $level = UserLevel::where('user_id', $user->id)->first();
        $cfg   = LevelConfig::getForLevel($level?->level ?? 0);

        if (!($cfg?->p2p_unlocked ?? ($level?->level >= 5))) {
            return $this->error('P2P transfer Level 5 dan ochiladi.', 403);
        }

        try {
            $transfer = WalletService::transfer(
                $user,
                $request->receiver,
                (float) $request->amount,
                $request->note
            );

            return $this->success([
                'transfer' => [
                    'id'         => $transfer->id,
                    'amount'     => (float) $transfer->amount,
                    'fee'        => (float) $transfer->fee,
                    'note'       => $transfer->note,
                    'reference'  => $transfer->reference,
                    'status'     => $transfer->status,
                    'created_at' => $transfer->created_at?->toIso8601String(),
                ],
            ], 'Transfer muvaffaqiyatli bajarildi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * POST /api/v1/wallet/convert
     * UZS↔AIS konvertatsiya: direction (buy/sell), amount
     */
    public function convert(ConvertRequest $request): JsonResponse
    {
        $setting = Setting::get();

        $minBuyAmount = max(1000, (int) ($setting->min_deposit ?? 1000));

        // Buy uchun minimal summa tekshirish
        if ($request->direction === 'buy' && $request->amount < $minBuyAmount) {
            return $this->error(
                "Minimal summa: " . number_format($minBuyAmount) . " UZS",
                422
            );
        }

        try {
            $user = auth()->user();

            if ($request->direction === 'buy') {
                $conversion = WalletService::depositToWallet($user, (float) $request->amount);
            } else {
                $conversion = WalletService::withdrawFromWallet($user, (float) $request->amount);
            }

            return $this->success([
                'conversion' => [
                    'id'         => $conversion->id,
                    'direction'  => $conversion->direction,
                    'uzs_amount' => (float) $conversion->uzs_amount,
                    'ais_amount' => (float) $conversion->ais_amount,
                    'rate_used'  => (float) $conversion->rate_used,
                    'fee'        => (float) $conversion->fee,
                    'status'     => $conversion->status,
                    'created_at' => $conversion->created_at?->toIso8601String(),
                ],
            ], 'Konvertatsiya muvaffaqiyatli bajarildi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * POST /api/v1/wallet/card
     * Virtual karta yaratish: card_holder
     */
    public function createCard(CreateCardRequest $request): JsonResponse
    {

        $user  = auth()->user();
        $level = UserLevel::where('user_id', $user->id)->first();
        $cfg   = LevelConfig::getForLevel($level?->level ?? 0);

        if (!($cfg?->virtual_card_unlocked ?? ($level?->level >= 10))) {
            return $this->error('Virtual karta Level 10 dan ochiladi.', 403);
        }

        if ($user->virtualCards()->where('status', '!=', 'cancelled')->count() >= 3) {
            return $this->error('Maksimal 3 ta karta yaratish mumkin.', 422);
        }

        $wallet = WalletService::createForUser($user);
        $cvv    = str_pad(random_int(0, 999), 3, '0', STR_PAD_LEFT);
        $expiry = now()->addYears(3);

        $card = VirtualCard::create([
            'user_id'      => $user->id,
            'wallet_id'    => $wallet->id,
            'card_number'  => VirtualCard::generateCardNumber(),
            'card_holder'  => strtoupper($request->card_holder),
            'expiry_month' => $expiry->format('m'),
            'expiry_year'  => $expiry->format('Y'),
            'cvv_hash'     => Hash::make($cvv),
            'status'       => 'active',
        ]);

        return $this->success([
            'card' => [
                'id'               => $card->id,
                'card_number'      => $card->card_number,
                'formatted_number' => $card->formatted_number,
                'card_holder'      => $card->card_holder,
                'expiry'           => $card->expiry,
                'status'           => $card->status,
            ],
            // CVV faqat bir marta ko'rsatiladi — foydalanuvchi yozib olishi kerak
            // Telegram'ga ham yuboriladi
            'cvv' => $cvv,
            'cvv_warning' => 'CVV ni hech kimga bermang! Bu safar ko\'rsatiladi, keyingi safar ko\'rsatilmaydi.',
        ], 'Virtual karta yaratildi. CVV faqat bir marta ko\'rsatiladi.', 201);
    }
}
