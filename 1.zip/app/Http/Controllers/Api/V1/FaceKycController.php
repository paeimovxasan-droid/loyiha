<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Security\AuditLog;
use App\Models\Security\FaceKycAttempt;
use App\Services\Security\FaceKycService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

/**
 * Face ID KYC — 2-bosqich (pasport tasdiqlangandan keyin)
 *
 * Flow:
 *  1. POST /api/v1/kyc/face/start   → sessiya boshlash (faqat passport_verified dan keyin)
 *  2. POST /api/v1/kyc/face/submit  → selfie + liveness natijasini yuborish
 *  3. GET  /api/v1/kyc/face/status  → holat tekshirish
 */
class FaceKycController extends Controller
{
    use ApiResponse;

    /**
     * POST /api/v1/kyc/face/start
     * Face ID sessiyasini boshlash — faqat passport_verified holatida
     */
    public function start(): JsonResponse
    {
        $user = auth()->user();

        // Faqat passport_verified holatida ruxsat
        if ($user->kyc_status !== 'passport_verified') {
            return $this->error(
                'Avval pasportingizni tasdiqlating.',
                403,
                ['kyc_status' => $user->kyc_status]
            );
        }

        // Oxirgi 1 soatda 3 dan ortiq urinish bo'lsa bloklash
        $recentAttempts = FaceKycAttempt::where('user_id', $user->id)
            ->where('created_at', '>=', now()->subHour())
            ->count();

        if ($recentAttempts >= 3) {
            return $this->error('Juda ko\'p urinish. 1 soatdan keyin qayta urinib ko\'ring.', 429);
        }

        // Mavjud pending sessiyani expired qilish
        FaceKycAttempt::where('user_id', $user->id)
            ->where('status', 'pending')
            ->update(['status' => 'expired']);

        $challenge = FaceKycService::generateChallenge();

        $attempt = FaceKycAttempt::create([
            'user_id'    => $user->id,
            'session_id' => $challenge['session_id'],
            'challenge'  => $challenge['steps'],
            'status'     => 'pending',
            'expires_at' => now()->addMinutes(10),
        ]);

        AuditLog::log('face_kyc_started', $user, [
            'attempt_id' => $attempt->id,
        ]);

        return $this->success([
            'session_id'   => $challenge['session_id'],
            'challenge'    => $challenge['steps'],
            'expires_at'   => $attempt->expires_at->toIso8601String(),
            'instructions' => [
                'uz' => 'Kamera oldida to\'g\'ri turing. Ko\'rsatilgan harakatlarni bajaring.',
                'ru' => 'Встаньте прямо перед камерой. Выполните указанные действия.',
                'en' => 'Stand straight in front of the camera. Follow the instructions.',
            ],
        ]);
    }

    /**
     * POST /api/v1/kyc/face/submit
     * Selfie + hujjat rasmi + liveness natijasini yuborish
     */
    public function submit(Request $request): JsonResponse
    {
        $request->validate([
            'session_id'      => 'required|string',
            'selfie'          => 'required|image|mimes:jpg,jpeg,png,webp|max:5120',
            'document_front'  => 'required|image|mimes:jpg,jpeg,png,webp|max:5120',
            'document_back'   => 'nullable|image|mimes:jpg,jpeg,png,webp|max:5120',
            'document_type'   => 'required|in:passport,id_card',
            'liveness_passed' => 'required|boolean',
            'liveness_score'  => 'required|numeric|min:0|max:1',
        ]);

        $user = auth()->user();

        if ($user->kyc_status === 'verified') {
            return $this->error('KYC allaqachon tasdiqlangan.', 422);
        }

        // Sessiyani topish va tekshirish
        $attempt = FaceKycAttempt::where('user_id', $user->id)
            ->where('session_id', $request->session_id)
            ->where('status', 'pending')
            ->first();

        if (!$attempt) {
            return $this->error('Sessiya topilmadi yoki muddati o\'tgan. Qaytadan boshlang.', 422);
        }

        if ($attempt->expires_at->isPast()) {
            $attempt->update(['status' => 'expired']);
            return $this->error('Sessiya muddati tugagan. Qaytadan boshlang.', 422);
        }

        // Liveness tekshiruvi
        if (!$request->boolean('liveness_passed')) {
            $attempt->update(['status' => 'failed', 'fail_reason' => 'liveness_failed']);
            return $this->error(
                'Yashashlik tekshiruvi muvaffaqiyatsiz. Yaxshi yorug\'likda qayta urinib ko\'ring.',
                422
            );
        }

        if ((float) $request->liveness_score < config('kyc.min_liveness_score', 0.70)) {
            $attempt->update(['status' => 'failed', 'fail_reason' => 'low_liveness_score']);
            return $this->error(
                'Yuz aniqlanmadi. Kamerani to\'g\'ri ushlab, yaxshi yorug\'likda qayta urinib ko\'ring.',
                422
            );
        }

        try {
            $result = FaceKycService::processSubmission(
                user: $user,
                attempt: $attempt,
                selfie: $request->file('selfie'),
                documentFront: $request->file('document_front'),
                documentBack: $request->file('document_back'),
                documentType: $request->document_type,
                livenessScore: (float) $request->liveness_score,
            );

            AuditLog::log('face_kyc_submitted', $user, [
                'attempt_id'     => $attempt->id,
                'document_type'  => $request->document_type,
                'liveness_score' => $request->liveness_score,
                'auto_approved'  => $result['auto_approved'],
            ]);

            if ($result['auto_approved']) {
                return $this->success([
                    'status'     => 'verified',
                    'message_uz' => 'Shaxsingiz muvaffaqiyatli tasdiqlandi!',
                ], 'KYC tasdiqlandi!');
            }

            return $this->success([
                'status'     => 'face_pending',
                'message_uz' => 'Ma\'lumotlaringiz yuborildi. 24 soat ichida ko\'rib chiqiladi.',
            ], 'KYC so\'rovi yuborildi.');

        } catch (\Exception $e) {
            Log::error('FaceKYC API submit failed', [
                'user_id' => $user->id,
                'error'   => $e->getMessage(),
            ]);

            $attempt->update(['status' => 'failed', 'fail_reason' => $e->getMessage()]);

            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * GET /api/v1/kyc/face/status
     * Face ID sessiyasi va umumiy KYC holati
     */
    public function status(): JsonResponse
    {
        $user = auth()->user();

        $lastAttempt = FaceKycAttempt::where('user_id', $user->id)
            ->latest()
            ->first();

        return $this->success([
            'kyc_status'       => $user->kyc_status ?? 'none',
            'kyc_type'         => $user->kyc_type,
            'kyc_stage'        => $user->kyc_stage,
            'kyc_verified_at'  => $user->kyc_verified_at?->toIso8601String(),
            'rejection_reason' => $user->kyc_rejection_reason,
            'last_attempt'     => $lastAttempt ? [
                'status'      => $lastAttempt->status,
                'fail_reason' => $lastAttempt->fail_reason,
                'created_at'  => $lastAttempt->created_at->toIso8601String(),
            ] : null,
        ]);
    }
}
