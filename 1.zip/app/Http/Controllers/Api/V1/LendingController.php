<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Lending\Loan;
use App\Models\Lending\LoanOffer;
use App\Services\LendingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class LendingController extends Controller
{
    use ApiResponse;

    public function offers(Request $request): JsonResponse
    {
        $offers = LoanOffer::where('status', 'active')
            ->with('lender:id,name')
            ->latest()->paginate(15);

        return $this->success(['offers' => $offers->items()]);
    }

    public function createOffer(Request $request): JsonResponse
    {
        $data = $request->validate([
            'amount'        => 'required|numeric|min:1',
            'interest_rate' => 'required|numeric|min:0|max:100',
            'duration_days' => 'required|integer|min:1|max:365',
            'description'   => 'nullable|string',
        ]);

        try {
            $offer = LendingService::createOffer(auth()->user(), $data);
            return $this->success(['offer' => $offer], 'Taklif yaratildi', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function acceptOffer(LoanOffer $offer): JsonResponse
    {
        try {
            $loan = LendingService::acceptOffer(auth()->user(), $offer);
            return $this->success(['loan' => $loan], 'Qarz olindi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function cancelOffer(LoanOffer $offer): JsonResponse
    {
        if ($offer->lender_id !== auth()->id()) {
            return $this->error('Ruxsat yo\'q', 403);
        }

        try {
            $offer = LendingService::cancelOffer($offer);
            return $this->success(['offer' => $offer], 'Taklif bekor qilindi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function loans(): JsonResponse
    {
        $user = auth()->user();
        $loans = Loan::where('borrower_id', $user->id)
            ->orWhere('lender_id', $user->id)
            ->with('lender:id,name', 'borrower:id,name')
            ->latest()->get();

        return $this->success(['loans' => $loans]);
    }

    public function showLoan(Loan $loan): JsonResponse
    {
        $userId = auth()->id();
        if ($loan->borrower_id !== $userId && $loan->lender_id !== $userId) {
            return $this->error('Ruxsat yo\'q', 403);
        }

        $loan->load('payments', 'lender:id,name', 'borrower:id,name');
        return $this->success(['loan' => $loan]);
    }

    public function makePayment(Request $request, Loan $loan): JsonResponse
    {
        $request->validate([
            'amount' => 'required|numeric|min:0.0001',
        ]);

        try {
            $payment = LendingService::makePayment(auth()->user(), $loan, (float) $request->amount);
            return $this->success(['payment' => $payment], 'To\'lov amalga oshirildi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }
}
