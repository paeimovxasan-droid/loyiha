<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\TelegramAuthService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    use ApiResponse;

    /**
     * Telegram initData orqali autentifikatsiya
     */
    public function telegramAuth(Request $request): JsonResponse
    {
        $request->validate([
            'initData' => 'required|string',
            'ref'      => 'nullable|string',
        ]);

        try {
            $telegramUser = TelegramAuthService::validateInitData($request->initData);

            $result = TelegramAuthService::authenticateOrRegister(
                $telegramUser,
                $request->ref
            );

            return $this->success([
                'user'   => $result['user'],
                'token'  => $result['token'],
                'is_new' => $result['is_new'] ?? false,
            ]);
        } catch (ValidationException $e) {
            return $this->error(
                $e->getMessage() ?: 'Yaroqsiz Telegram ma\'lumotlari',
                401,
                $e->errors()
            );
        }
    }
}
