<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Marketing\LeaderboardCompetition;
use App\Services\Marketing\LeaderboardService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class LeaderboardChallengeController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/competitions — aktiv musobaqalar
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();

        $weekly = LeaderboardCompetition::active()->weekly()->first();
        $monthly = LeaderboardCompetition::active()->monthly()->first();

        $data = [];

        if ($weekly) {
            $data['weekly'] = [
                'id'          => $weekly->id,
                'type'        => $weekly->type,
                'leaderboard' => LeaderboardService::getLeaderboard($weekly),
                'user_rank'   => LeaderboardService::getUserRank($weekly, $user),
                'ends_at'     => $weekly->ends_at->toDateTimeString(),
                'prizes'      => $weekly->prizes,
            ];
        }

        if ($monthly) {
            $data['monthly'] = [
                'id'          => $monthly->id,
                'type'        => $monthly->type,
                'leaderboard' => LeaderboardService::getLeaderboard($monthly),
                'user_rank'   => LeaderboardService::getUserRank($monthly, $user),
                'ends_at'     => $monthly->ends_at->toDateTimeString(),
                'prizes'      => $monthly->prizes,
            ];
        }

        return $this->success($data);
    }

    /**
     * GET /api/v1/competitions/history — musobaqa tarixi (paginated)
     */
    public function history(Request $request): JsonResponse
    {
        $competitions = LeaderboardCompetition::where('status', 'finalized')
            ->orderByDesc('ends_at')
            ->paginate(15);

        return $this->success([
            'competitions' => $competitions->map(fn ($c) => [
                'id'     => $c->id,
                'period' => $c->period,
                'type'   => $c->type,
                'status' => $c->status,
                'starts_at' => $c->starts_at->toDateTimeString(),
                'ends_at'   => $c->ends_at->toDateTimeString(),
                'prizes'    => $c->prizes,
            ]),
            'pagination' => [
                'current_page' => $competitions->currentPage(),
                'last_page'    => $competitions->lastPage(),
                'per_page'     => $competitions->perPage(),
                'total'        => $competitions->total(),
            ],
        ]);
    }
}
