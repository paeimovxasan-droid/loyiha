<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use Illuminate\Http\JsonResponse;

class DashboardController extends Controller
{
    use ApiResponse;

    public function index(): JsonResponse
    {
        $user = auth()->user();

        $wallet = $user->wallet;
        $userStats = \App\Models\UserStats::firstOrCreate(['user_id' => $user->id]);

        $stats = [
            'balance'         => (float) $user->balance,
            'ais_balance'     => (float) ($wallet?->balance ?? 0),
            'total_earn'      => (float) $userStats->total_earn_ais,
            'total_deposit'   => (float) $userStats->total_deposit_uzs,
            'referrals_count' => (int) $userStats->referrals_count,
        ];

        $activePackages = $user->purchases()
            ->with('package:id,name,price')
            ->where('status', 'active')
            ->get()
            ->map(fn($purchase) => [
                'name'       => $purchase->package?->name,
                'price'      => (float) $purchase->package?->price,
                'started_at' => $purchase->started_at?->toDateString(),
                'expires_at' => $purchase->expires_at?->toDateString(),
            ]);

        $recentTransactions = $user->transactions()
            ->latest()
            ->limit(8)
            ->get()
            ->map(fn($tx) => [
                'amount'      => (float) $tx->amount,
                'type'        => $tx->type,
                'direction'   => $tx->direction,
                'description' => $tx->description,
                'status'      => $tx->status,
                'created_at'  => $tx->created_at?->toIso8601String(),
            ]);

        $userLevel = $user->userLevel;
        $level = $userLevel ? [
            'level'            => $userLevel->level,
            'title'            => $userLevel->title,
            'total_xp'         => $userLevel->total_xp,
            'current_xp'       => $userLevel->current_xp,
            'next_level_xp'    => $userLevel->next_level_xp,
            'progress_percent' => $userLevel->progress_percent,
            'badge_color'      => $userLevel->badge_color,
        ] : null;

        return $this->success([
            'balance'              => $stats['balance'],
            'ais_balance'          => $stats['ais_balance'],
            'total_earn'           => $stats['total_earn'],
            'total_deposit'        => $stats['total_deposit'],
            'referrals_count'      => $stats['referrals_count'],
            'active_packages'      => $activePackages,
            'recent_transactions'  => $recentTransactions,
            'level'                => $level,
        ]);
    }
}
