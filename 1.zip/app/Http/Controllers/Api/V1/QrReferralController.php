<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\Marketing\QrService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Storage;

class QrReferralController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/qr-referral — QR-kod URL qaytarish
     */
    public function generate(): JsonResponse
    {
        $user = auth()->user();

        $qrUrl = QrService::getUrl($user);
        $botUsername = config('services.telegram.bot_username', 'aisoqqa_bot');
        $referralLink = "https://t.me/{$botUsername}?start=ref_{$user->username}";

        return $this->success([
            'qr_url'        => $qrUrl,
            'referral_link' => $referralLink,
        ]);
    }

    /**
     * GET /api/v1/qr-referral/download — QR-kod PNG yuklab olish
     */
    public function download()
    {
        $user = auth()->user();
        $filename = "qr-codes/ref_{$user->username}.png";

        if (!Storage::disk('public')->exists($filename)) {
            QrService::generate($user);
        }

        if (!Storage::disk('public')->exists($filename)) {
            return $this->error('QR-kod generatsiya qilib bo\'lmadi.', 500);
        }

        return Storage::disk('public')->download($filename, "qr-referral-{$user->username}.png", [
            'Content-Type' => 'image/png',
        ]);
    }
}
