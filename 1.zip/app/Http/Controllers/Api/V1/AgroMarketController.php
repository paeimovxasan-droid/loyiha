<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\AgroMarket\AgroListing;
use App\Models\AgroMarket\AgroOrder;
use App\Services\AgroService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AgroMarketController extends Controller
{
    use ApiResponse;

    public function listings(Request $request): JsonResponse
    {
        $query = AgroListing::where('status', 'active');

        if ($request->filled('category')) {
            $query->where('category', $request->category);
        }
        if ($request->filled('location')) {
            $query->where('location', 'like', '%' . $request->location . '%');
        }

        $listings = $query->with('user:id,name')->latest()->paginate(15);

        return $this->success([
            'listings'   => $listings->items(),
            'pagination' => [
                'current_page' => $listings->currentPage(),
                'last_page'    => $listings->lastPage(),
                'total'        => $listings->total(),
            ],
        ]);
    }

    public function showListing(AgroListing $listing): JsonResponse
    {
        $listing->load('user:id,name', 'orders');
        return $this->success(['listing' => $listing]);
    }

    public function storeListing(Request $request): JsonResponse
    {
        $data = $request->validate([
            'title'          => 'required|string|max:255',
            'description'    => 'nullable|string',
            'category'       => 'required|in:bugdoy,paxta,sabzavot,meva',
            'quantity'       => 'required|numeric|min:0.01',
            'price_per_unit' => 'required|numeric|min:0.0001',
            'location'       => 'required|string|max:255',
            'is_forward'     => 'boolean',
            'delivery_date'  => 'nullable|date|after:today',
        ]);

        $listing = AgroService::createListing(auth()->user(), $data);
        return $this->success(['listing' => $listing], 'E\'lon yaratildi', 201);
    }

    public function updateListing(Request $request, AgroListing $listing): JsonResponse
    {
        if ($listing->user_id !== auth()->id()) {
            return $this->error('Ruxsat yo\'q', 403);
        }

        $data = $request->validate([
            'title'          => 'string|max:255',
            'description'    => 'nullable|string',
            'quantity'       => 'numeric|min:0.01',
            'price_per_unit' => 'numeric|min:0.0001',
            'location'       => 'string|max:255',
            'status'         => 'in:active,inactive',
        ]);

        $listing->update($data);
        return $this->success(['listing' => $listing->fresh()]);
    }

    public function placeOrder(Request $request): JsonResponse
    {
        $data = $request->validate([
            'agro_listing_id' => 'required|exists:agro_listings,id',
            'quantity'        => 'required|numeric|min:0.01',
            'is_forward'      => 'boolean',
            'delivery_date'   => 'nullable|date|after:today',
        ]);

        try {
            $listing = AgroListing::findOrFail($data['agro_listing_id']);
            $order = AgroService::placeOrder(auth()->user(), $listing, $data);
            return $this->success(['order' => $order], 'Buyurtma berildi', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function orders(Request $request): JsonResponse
    {
        $user = auth()->user();
        $orders = AgroOrder::where('buyer_id', $user->id)
            ->orWhere('seller_id', $user->id)
            ->with('listing:id,title', 'buyer:id,name', 'seller:id,name')
            ->latest()->paginate(15);

        return $this->success(['orders' => $orders->items()]);
    }

    public function confirmOrder(AgroOrder $order): JsonResponse
    {
        if ($order->seller_id !== auth()->id()) {
            return $this->error('Ruxsat yo\'q', 403);
        }

        try {
            $order = AgroService::confirmOrder($order);
            return $this->success(['order' => $order], 'Buyurtma tasdiqlandi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    public function cancelOrder(AgroOrder $order): JsonResponse
    {
        if ($order->buyer_id !== auth()->id() && $order->seller_id !== auth()->id()) {
            return $this->error('Ruxsat yo\'q', 403);
        }

        try {
            $order = AgroService::cancelOrder($order);
            return $this->success(['order' => $order], 'Buyurtma bekor qilindi');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }
}
