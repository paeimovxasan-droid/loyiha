<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\AiAssistant\AiConversation;
use App\Models\AiAssistant\FaqEntry;
use App\Services\AiAssistantService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AiAssistantController extends Controller
{
    use ApiResponse;

    public function ask(Request $request): JsonResponse
    {
        $request->validate([
            'question' => 'required|string|max:1000',
        ]);

        $message = AiAssistantService::askQuestion(auth()->user(), $request->question);

        return $this->success([
            'answer'          => $message->content,
            'conversation_id' => $message->ai_conversation_id,
        ]);
    }

    public function conversations(): JsonResponse
    {
        $conversations = AiAssistantService::getConversations(auth()->user());
        return $this->success(['conversations' => $conversations]);
    }

    public function showConversation(AiConversation $conversation): JsonResponse
    {
        if ($conversation->user_id !== auth()->id()) {
            return $this->error('Ruxsat yo\'q', 403);
        }

        $messages = $conversation->messages()->oldest()->get();
        return $this->success(['messages' => $messages]);
    }

    public function faq(): JsonResponse
    {
        $faqs = FaqEntry::active()->get(['id', 'question', 'answer', 'category']);
        return $this->success(['faqs' => $faqs]);
    }

    public function advice(): JsonResponse
    {
        $advice = AiAssistantService::getFinancialAdvice(auth()->user());
        return $this->success($advice);
    }
}
