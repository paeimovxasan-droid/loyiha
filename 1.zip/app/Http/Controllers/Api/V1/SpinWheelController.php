<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Marketing\SpinWheelLog;
use App\Models\Marketing\SpinWheelPrize;
use App\Services\Marketing\SpinWheelService;
use Illuminate\Http\JsonResponse;

class SpinWheelController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/spin-wheel
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();

        $canSpin = SpinWheelService::canSpin($user);

        $prizes = SpinWheelPrize::active()
            ->orderBy('id')
            ->get()
            ->map(fn (SpinWheelPrize $p) => [
                'type'  => $p->type,
                'value' => (float) $p->value,
                'label' => $p->label,
                'color' => $p->color,
            ]);

        $history = SpinWheelLog::where('user_id', $user->id)
            ->orderByDesc('created_at')
            ->limit(10)
            ->get()
            ->map(fn (SpinWheelLog $log) => [
                'prize_type'  => $log->prize_type,
                'prize_value' => (float) $log->prize_value,
                'spun_at'     => $log->spun_at,
            ]);

        $lastSpin = SpinWheelLog::where('user_id', $user->id)
            ->where('spun_at', today())
            ->first();

        return $this->success([
            'can_spin'    => $canSpin,
            'next_spin_at' => $lastSpin ? today()->addDay()->toDateTimeString() : now()->toDateTimeString(),
            'prizes'      => $prizes,
            'history'     => $history,
        ]);
    }

    /**
     * POST /api/v1/spin-wheel/spin
     */
    public function spin(): JsonResponse
    {
        try {
            $result = SpinWheelService::spin(auth()->user());

            return $this->success($result, 'G\'ildirak aylantirildi!');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }
}
