<?php

namespace App\Http\Controllers\Api\V1\Medical;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Medical\DoctorProfile;
use App\Services\TelegramBotService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DoctorProfileController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/medical/doctors
     * Tasdiqlangan shifokorlar ro'yxati
     */
    public function index(Request $request): JsonResponse
    {
        $query = DoctorProfile::approved()->with('user:id,name,avatar');

        if ($request->filled('specialty')) {
            $query->bySpecialty($request->specialty);
        }

        if ($request->boolean('online_only')) {
            $query->online();
        }

        if ($request->filled('sort')) {
            match ($request->sort) {
                'rating'     => $query->orderByDesc('rating'),
                'price_low'  => $query->orderBy('consultation_price'),
                'price_high' => $query->orderByDesc('consultation_price'),
                'experience' => $query->orderByDesc('experience_years'),
                default      => $query->orderByDesc('is_online')->orderByDesc('rating'),
            };
        } else {
            $query->orderByDesc('is_online')->orderByDesc('rating');
        }

        $doctors = $query->paginate(15);

        $data = $doctors->through(fn($d) => [
            'id'                 => $d->id,
            'name'               => $d->user->name,
            'avatar'             => $d->user->avatar,
            'specialty'          => $d->specialty,
            'experience_years'   => $d->experience_years,
            'consultation_price' => (float) $d->consultation_price,
            'home_visit_price'   => (float) $d->home_visit_price,
            'rating'             => (float) $d->rating,
            'reviews_count'      => $d->reviews_count,
            'is_online'          => $d->is_online,
            'offers_home_visit'  => $d->offers_home_visit,
        ]);

        return $this->success($data);
    }

    /**
     * GET /api/v1/medical/doctors/{doctorProfile}
     * Shifokor to'liq profili
     */
    public function show(DoctorProfile $doctorProfile): JsonResponse
    {
        if (!$doctorProfile->isApproved()) {
            return $this->error('Shifokor topilmadi.', 404);
        }

        $doctorProfile->load(['user:id,name,avatar', 'reviews' => fn($q) => $q->latest()->limit(10), 'reviews.patient:id,name']);

        return $this->success([
            'id'                 => $doctorProfile->id,
            'name'               => $doctorProfile->user->name,
            'avatar'             => $doctorProfile->user->avatar,
            'specialty'          => $doctorProfile->specialty,
            'experience_years'   => $doctorProfile->experience_years,
            'workplace'          => $doctorProfile->workplace,
            'bio'                => $doctorProfile->bio,
            'consultation_price' => (float) $doctorProfile->consultation_price,
            'home_visit_price'   => (float) $doctorProfile->home_visit_price,
            'rating'             => (float) $doctorProfile->rating,
            'reviews_count'      => $doctorProfile->reviews_count,
            'consultations_count' => $doctorProfile->consultations_count,
            'is_online'          => $doctorProfile->is_online,
            'offers_home_visit'  => $doctorProfile->offers_home_visit,
            'reviews'            => $doctorProfile->reviews->map(fn($r) => [
                'rating'     => $r->rating,
                'comment'    => $r->comment,
                'patient'    => $r->patient->name,
                'created_at' => $r->created_at->toIso8601String(),
            ]),
        ]);
    }

    /**
     * POST /api/v1/medical/doctor-profile
     * Shifokor profili yaratish
     */
    public function store(Request $request): JsonResponse
    {
        $user = auth()->user();

        if (DoctorProfile::where('user_id', $user->id)->exists()) {
            return $this->error('Siz allaqachon shifokor profili yaratgansiz.', 422);
        }

        $validated = $request->validate([
            'specialty'          => 'required|string|in:' . implode(',', DoctorProfile::SPECIALTIES),
            'experience_years'   => 'required|integer|min:1|max:60',
            'diploma_image'      => 'required|string|max:500',
            'license_number'     => 'required|string|max:100',
            'workplace'          => 'required|string|max:255',
            'consultation_price' => 'required|numeric|min:1',
            'home_visit_price'   => 'nullable|numeric|min:0',
            'bio'                => 'nullable|string|max:1000',
            'offers_home_visit'  => 'nullable|boolean',
        ]);

        $profile = DoctorProfile::create([
            'user_id'            => $user->id,
            'specialty'          => $validated['specialty'],
            'experience_years'   => $validated['experience_years'],
            'diploma_image'      => $validated['diploma_image'],
            'license_number'     => $validated['license_number'],
            'workplace'          => $validated['workplace'],
            'consultation_price' => $validated['consultation_price'],
            'home_visit_price'   => $validated['home_visit_price'] ?? 0,
            'bio'                => $validated['bio'] ?? null,
            'offers_home_visit'  => $validated['offers_home_visit'] ?? false,
            'status'             => DoctorProfile::STATUS_PENDING,
        ]);

        // Adminga bildirishnoma
        TelegramBotService::notifyAdmin(
            "👨‍⚕️ Yangi shifokor profili yaratildi!\n\n"
            . "👤 {$user->name}\n"
            . "🏥 {$validated['specialty']}\n"
            . "💰 Narx: {$validated['consultation_price']} AIS\n\n"
            . "Tasdiqlash kutilmoqda."
        );

        return $this->success($profile, 'Profil yaratildi. Admin tasdiqlashini kuting.', 201);
    }

    /**
     * PUT /api/v1/medical/doctor-profile
     * Shifokor profilini yangilash
     */
    public function update(Request $request): JsonResponse
    {
        $user = auth()->user();
        $profile = DoctorProfile::where('user_id', $user->id)->first();

        if (!$profile) {
            return $this->error('Shifokor profilingiz topilmadi.', 404);
        }

        $validated = $request->validate([
            'workplace'          => 'sometimes|string|max:255',
            'consultation_price' => 'sometimes|numeric|min:1',
            'home_visit_price'   => 'sometimes|numeric|min:0',
            'bio'                => 'sometimes|nullable|string|max:1000',
            'offers_home_visit'  => 'sometimes|boolean',
        ]);

        $profile->update($validated);

        return $this->success($profile, 'Profil yangilandi.');
    }

    /**
     * GET /api/v1/medical/doctor-profile/me
     * O'z profilim
     */
    public function me(): JsonResponse
    {
        $user = auth()->user();
        $profile = DoctorProfile::where('user_id', $user->id)->first();

        if (!$profile) {
            return $this->success(null, 'Shifokor profilingiz yo\'q.');
        }

        return $this->success([
            'id'                  => $profile->id,
            'specialty'           => $profile->specialty,
            'experience_years'    => $profile->experience_years,
            'workplace'           => $profile->workplace,
            'consultation_price'  => (float) $profile->consultation_price,
            'home_visit_price'    => (float) $profile->home_visit_price,
            'bio'                 => $profile->bio,
            'status'              => $profile->status,
            'rejection_reason'    => $profile->rejection_reason,
            'rating'              => (float) $profile->rating,
            'reviews_count'       => $profile->reviews_count,
            'consultations_count' => $profile->consultations_count,
            'is_online'           => $profile->is_online,
            'offers_home_visit'   => $profile->offers_home_visit,
        ]);
    }

    /**
     * POST /api/v1/medical/doctor-profile/toggle-online
     * Onlayn/oflayn holat
     */
    public function toggleOnline(): JsonResponse
    {
        $user = auth()->user();
        $profile = DoctorProfile::where('user_id', $user->id)->approved()->first();

        if (!$profile) {
            return $this->error('Tasdiqlangan shifokor profilingiz yo\'q.', 403);
        }

        $profile->update([
            'is_online'      => !$profile->is_online,
            'last_active_at' => now(),
        ]);

        return $this->success([
            'is_online' => $profile->is_online,
        ], $profile->is_online ? 'Siz onlaysiz.' : 'Siz oflaynsiz.');
    }

    /**
     * GET /api/v1/medical/specialties
     * Ixtisosliklar ro'yxati
     */
    public function specialties(): JsonResponse
    {
        return $this->success(DoctorProfile::SPECIALTIES);
    }
}
