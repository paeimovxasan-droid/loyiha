<?php

namespace App\Http\Controllers\Api\V1\Medical;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Medical\Consultation;
use App\Models\Medical\MedicalReferral;
use App\Services\TelegramBotService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class MedicalReferralController extends Controller
{
    use ApiResponse;

    /**
     * POST /api/v1/medical/consultations/{consultation}/referrals
     * Analiz yo'llanma yozish (shifokor)
     */
    public function store(Request $request, Consultation $consultation): JsonResponse
    {
        $user = auth()->user();

        if ($consultation->doctor_id !== $user->id) {
            return $this->error('Ruxsat yo\'q.', 403);
        }

        if (!$consultation->isActive()) {
            return $this->error('Faqat faol maslahatda yo\'llanma yozish mumkin.', 422);
        }

        $validated = $request->validate([
            'analysis_type' => 'required|string|max:255',
            'laboratory'    => 'nullable|string|max:255',
            'instructions'  => 'nullable|string|max:1000',
        ]);

        $referral = MedicalReferral::create([
            'consultation_id' => $consultation->id,
            'doctor_id'       => $user->id,
            'patient_id'      => $consultation->patient_id,
            'analysis_type'   => $validated['analysis_type'],
            'laboratory'      => $validated['laboratory'] ?? null,
            'instructions'    => $validated['instructions'] ?? null,
        ]);

        // Bemorga bildirishnoma
        TelegramBotService::notify(
            $consultation->patient,
            "🔬 Shifokor sizga analiz yo'llanma berdi!\n"
            . "📋 Analiz: {$validated['analysis_type']}",
            [[['text' => 'Yo\'llanmani ko\'rish', 'url' => config('app.url') . '/app/consultations/' . $consultation->id]]]
        );

        return $this->success([
            'id'            => $referral->id,
            'analysis_type' => $referral->analysis_type,
            'laboratory'    => $referral->laboratory,
            'instructions'  => $referral->instructions,
        ], 'Yo\'llanma yaratildi.', 201);
    }
}
