<?php

namespace App\Http\Controllers\Api\V1\Medical;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Medical\Consultation;
use App\Models\Medical\ConsultationMessage;
use App\Models\Medical\DoctorProfile;
use App\Services\Medical\MedicalService;
use App\Services\TelegramBotService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ConsultationController extends Controller
{
    use ApiResponse;

    /**
     * POST /api/v1/medical/consultations
     * Maslahat boshlash (bemor)
     */
    public function store(Request $request): JsonResponse
    {
        $request->validate([
            'doctor_profile_id' => 'required|exists:doctor_profiles,id',
        ]);

        $patient = auth()->user();
        $doctorProfile = DoctorProfile::findOrFail($request->doctor_profile_id);

        if (!$doctorProfile->isApproved()) {
            return $this->error('Bu shifokor hozirda xizmat ko\'rsatmaydi.', 422);
        }

        if ($doctorProfile->user_id === $patient->id) {
            return $this->error('O\'zingizdan maslahat ololmaysiz.', 422);
        }

        try {
            $consultation = MedicalService::startConsultation($patient, $doctorProfile);
            return $this->success([
                'id'     => $consultation->id,
                'status' => $consultation->status,
                'price'  => (float) $consultation->price,
            ], 'Maslahat so\'rovi yuborildi. Shifokor javobini kuting.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * GET /api/v1/medical/consultations
     * Mening maslahatlarim (bemor yoki shifokor)
     */
    public function index(Request $request): JsonResponse
    {
        $user = auth()->user();

        $query = Consultation::where(function ($q) use ($user) {
            $q->where('patient_id', $user->id)
              ->orWhere('doctor_id', $user->id);
        })->with(['patient:id,name,avatar', 'doctor:id,name,avatar', 'doctorProfile:id,specialty']);

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $consultations = $query->latest()->paginate(15);

        $data = $consultations->through(fn($c) => [
            'id'         => $c->id,
            'patient'    => ['id' => $c->patient->id, 'name' => $c->patient->name, 'avatar' => $c->patient->avatar],
            'doctor'     => ['id' => $c->doctor->id, 'name' => $c->doctor->name, 'avatar' => $c->doctor->avatar],
            'specialty'  => $c->doctorProfile->specialty,
            'price'      => (float) $c->price,
            'status'     => $c->status,
            'created_at' => $c->created_at->toIso8601String(),
            'expires_at' => $c->expires_at?->toIso8601String(),
            'is_mine'    => $c->patient_id === $user->id,
        ]);

        return $this->success($data);
    }

    /**
     * GET /api/v1/medical/consultations/{consultation}
     * Maslahat tafsilotlari
     */
    public function show(Consultation $consultation): JsonResponse
    {
        $user = auth()->user();

        if ($consultation->patient_id !== $user->id && $consultation->doctor_id !== $user->id) {
            return $this->error('Ruxsat yo\'q.', 403);
        }

        $consultation->load([
            'patient:id,name,avatar',
            'doctor:id,name,avatar',
            'doctorProfile:id,specialty,workplace',
            'messages' => fn($q) => $q->with('sender:id,name')->latest()->limit(50),
            'prescriptions.items',
            'referrals',
            'review',
        ]);

        return $this->success([
            'id'            => $consultation->id,
            'patient'       => ['id' => $consultation->patient->id, 'name' => $consultation->patient->name, 'avatar' => $consultation->patient->avatar],
            'doctor'        => ['id' => $consultation->doctor->id, 'name' => $consultation->doctor->name, 'avatar' => $consultation->doctor->avatar],
            'specialty'     => $consultation->doctorProfile->specialty,
            'workplace'     => $consultation->doctorProfile->workplace,
            'price'         => (float) $consultation->price,
            'status'        => $consultation->status,
            'created_at'    => $consultation->created_at->toIso8601String(),
            'accepted_at'   => $consultation->accepted_at?->toIso8601String(),
            'completed_at'  => $consultation->completed_at?->toIso8601String(),
            'expires_at'    => $consultation->expires_at?->toIso8601String(),
            'can_message'   => $consultation->canSendMessage(),
            'can_cancel'    => $consultation->canCancel() && $consultation->patient_id === $user->id,
            'has_review'    => (bool) $consultation->review,
            'messages'      => $consultation->messages->map(fn($m) => [
                'id'         => $m->id,
                'sender'     => $m->sender->name,
                'sender_id'  => $m->sender_id,
                'message'    => $m->message,
                'is_read'    => $m->is_read,
                'created_at' => $m->created_at->toIso8601String(),
            ]),
            'prescriptions' => $consultation->prescriptions->map(fn($p) => [
                'id'    => $p->id,
                'notes' => $p->notes,
                'items' => $p->items->map(fn($i) => [
                    'medicine_name' => $i->medicine_name,
                    'dosage'        => $i->dosage,
                    'frequency'     => $i->frequency,
                    'duration'      => $i->duration,
                    'instructions'  => $i->instructions,
                ]),
                'created_at' => $p->created_at->toIso8601String(),
            ]),
            'referrals' => $consultation->referrals->map(fn($r) => [
                'id'            => $r->id,
                'analysis_type' => $r->analysis_type,
                'laboratory'    => $r->laboratory,
                'instructions'  => $r->instructions,
                'created_at'    => $r->created_at->toIso8601String(),
            ]),
        ]);
    }

    /**
     * POST /api/v1/medical/consultations/{consultation}/accept
     * Maslahatni qabul qilish (shifokor)
     */
    public function accept(Consultation $consultation): JsonResponse
    {
        $user = auth()->user();

        if ($consultation->doctor_id !== $user->id) {
            return $this->error('Ruxsat yo\'q.', 403);
        }

        try {
            MedicalService::acceptConsultation($consultation);
            return $this->success(null, 'Maslahat qabul qilindi. Chat boshlandi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * POST /api/v1/medical/consultations/{consultation}/complete
     * Maslahatni tugatish (shifokor)
     */
    public function complete(Consultation $consultation): JsonResponse
    {
        $user = auth()->user();

        if ($consultation->doctor_id !== $user->id) {
            return $this->error('Ruxsat yo\'q.', 403);
        }

        try {
            MedicalService::completeConsultation($consultation);
            return $this->success(null, 'Maslahat tugallandi. To\'lov hisobingizga o\'tkazildi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * POST /api/v1/medical/consultations/{consultation}/cancel
     * Maslahatni bekor qilish (bemor)
     */
    public function cancel(Consultation $consultation): JsonResponse
    {
        $user = auth()->user();

        if ($consultation->patient_id !== $user->id) {
            return $this->error('Ruxsat yo\'q.', 403);
        }

        try {
            MedicalService::cancelConsultation($consultation, $user);
            return $this->success(null, 'Maslahat bekor qilindi. To\'lov qaytarildi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * POST /api/v1/medical/consultations/{consultation}/messages
     * Xabar yuborish
     */
    public function sendMessage(Request $request, Consultation $consultation): JsonResponse
    {
        $user = auth()->user();

        if ($consultation->patient_id !== $user->id && $consultation->doctor_id !== $user->id) {
            return $this->error('Ruxsat yo\'q.', 403);
        }

        if (!$consultation->canSendMessage()) {
            return $this->error('Bu maslahatda xabar yuborib bo\'lmaydi.', 422);
        }

        $request->validate([
            'message' => 'required|string|max:2000',
        ]);

        $msg = ConsultationMessage::create([
            'consultation_id' => $consultation->id,
            'sender_id'       => $user->id,
            'message'         => $request->message,
        ]);

        // Ikkinchi tomonga bildirishnoma
        $recipient = $consultation->patient_id === $user->id
            ? $consultation->doctor
            : $consultation->patient;

        TelegramBotService::notify(
            $recipient,
            "💬 Yangi xabar ({$user->name}):\n" . mb_substr($request->message, 0, 100),
            [[['text' => 'Chatga o\'tish', 'url' => config('app.url') . '/app/consultations/' . $consultation->id]]]
        );

        return $this->success([
            'id'         => $msg->id,
            'message'    => $msg->message,
            'sender_id'  => $msg->sender_id,
            'created_at' => $msg->created_at->toIso8601String(),
        ], null, 201);
    }

    /**
     * POST /api/v1/medical/consultations/{consultation}/review
     * Sharh qoldirish (bemor)
     */
    public function review(Request $request, Consultation $consultation): JsonResponse
    {
        $user = auth()->user();

        $request->validate([
            'rating'  => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:500',
        ]);

        try {
            $review = MedicalService::addReview($consultation, $user, $request->rating, $request->comment);
            return $this->success([
                'rating'  => $review->rating,
                'comment' => $review->comment,
            ], 'Sharh qoldirildi. Rahmat!', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * POST /api/v1/medical/consultations/{consultation}/complaint
     * Shikoyat yuborish (bemor)
     */
    public function complaint(Request $request, Consultation $consultation): JsonResponse
    {
        $user = auth()->user();

        $request->validate([
            'type'    => 'required|string|in:wrong_advice,rude_behavior,no_response,other',
            'message' => 'required|string|max:1000',
        ]);

        try {
            MedicalService::submitComplaint($consultation, $user, $request->type, $request->message);
            return $this->success(null, 'Shikoyat yuborildi. Admin ko\'rib chiqadi.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }
}
