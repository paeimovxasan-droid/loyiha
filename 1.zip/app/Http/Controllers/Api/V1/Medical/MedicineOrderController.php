<?php

namespace App\Http\Controllers\Api\V1\Medical;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\AIS\Wallet;
use App\Models\Finance\Transaction;
use App\Models\Medical\Medicine;
use App\Models\Medical\MedicineOrder;
use App\Models\Medical\MedicineOrderItem;
use App\Models\Medical\Prescription;
use App\Models\Setting;
use App\Services\TelegramBotService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MedicineOrderController extends Controller
{
    use ApiResponse;

    /**
     * POST /api/v1/medical/medicine-orders
     * Dori buyurtma qilish
     */
    public function store(Request $request): JsonResponse
    {
        $user = auth()->user();

        $validated = $request->validate([
            'prescription_id'   => 'nullable|exists:prescriptions,id',
            'delivery_address'  => 'required|string|max:500',
            'items'             => 'required|array|min:1',
            'items.*.medicine_id' => 'required|exists:medicines,id',
            'items.*.quantity'  => 'required|integer|min:1|max:100',
        ]);

        // Retsept tekshirish (agar berilgan bo'lsa)
        if (!empty($validated['prescription_id'])) {
            $prescription = Prescription::where('id', $validated['prescription_id'])
                ->where('patient_id', $user->id)
                ->first();
            if (!$prescription) {
                return $this->error('Retsept topilmadi.', 404);
            }
        }

        // Narxlarni hisoblash
        $medicinesTotal = 0;
        $orderItems = [];

        foreach ($validated['items'] as $item) {
            $medicine = Medicine::available()->find($item['medicine_id']);
            if (!$medicine) {
                return $this->error("Dori mavjud emas: ID {$item['medicine_id']}", 422);
            }

            $totalPrice = $medicine->price * $item['quantity'];
            $medicinesTotal += $totalPrice;

            $orderItems[] = [
                'medicine_id'   => $medicine->id,
                'medicine_name' => $medicine->name,
                'quantity'      => $item['quantity'],
                'unit_price'    => $medicine->price,
                'total_price'   => $totalPrice,
            ];
        }

        $setting = Setting::get();
        $deliveryFee = (float) ($setting->medical_delivery_fee ?? 5); // AIS
        $platformFee = (float) ($setting->medical_platform_fee ?? 2); // AIS
        $totalAmount = $medicinesTotal + $deliveryFee + $platformFee;

        // Balans tekshirish va to'lov
        return DB::transaction(function () use ($user, $validated, $medicinesTotal, $deliveryFee, $platformFee, $totalAmount, $orderItems) {
            $wallet = Wallet::where('user_id', $user->id)->lockForUpdate()->first();

            if (!$wallet || !$wallet->hasEnough($totalAmount)) {
                return $this->error("Balansingiz yetarli emas. Kerak: {$totalAmount} AIS", 422);
            }

            $wallet->decrement('balance', $totalAmount);

            $order = MedicineOrder::create([
                'patient_id'       => $user->id,
                'prescription_id'  => $validated['prescription_id'] ?? null,
                'delivery_address' => $validated['delivery_address'],
                'medicines_total'  => $medicinesTotal,
                'delivery_fee'     => $deliveryFee,
                'platform_fee'     => $platformFee,
                'total_amount'     => $totalAmount,
                'status'           => MedicineOrder::STATUS_NEW,
            ]);

            foreach ($orderItems as $item) {
                MedicineOrderItem::create(array_merge($item, [
                    'medicine_order_id' => $order->id,
                ]));
            }

            // Tranzaksiya
            Transaction::create([
                'user_id'              => $user->id,
                'type'                 => 'medical_medicine_order',
                'transactionable_type' => MedicineOrder::class,
                'transactionable_id'   => $order->id,
                'amount'               => $totalAmount,
                'balance_before'       => $wallet->balance + $totalAmount,
                'balance_after'        => $wallet->balance,
                'direction'            => 'debit',
                'status'               => 'completed',
                'description'          => 'Dori buyurtma to\'lovi',
            ]);

            // Adminga bildirishnoma
            TelegramBotService::notifyAdmin(
                "💊 Yangi dori buyurtma!\n\n"
                . "👤 {$user->name}\n"
                . "📦 Dorilar: " . count($orderItems) . " ta\n"
                . "💰 Jami: {$totalAmount} AIS\n"
                . "📍 Manzil: {$validated['delivery_address']}"
            );

            return $this->success([
                'id'           => $order->id,
                'total_amount' => (float) $order->total_amount,
                'status'       => $order->status,
            ], 'Buyurtma yaratildi.', 201);
        });
    }

    /**
     * GET /api/v1/medical/medicine-orders
     * Mening buyurtmalarim
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();

        $orders = MedicineOrder::where('patient_id', $user->id)
            ->with('items')
            ->latest()
            ->paginate(15);

        $data = $orders->through(fn($o) => [
            'id'              => $o->id,
            'total_amount'    => (float) $o->total_amount,
            'status'          => $o->status,
            'items_count'     => $o->items->count(),
            'delivery_address' => $o->delivery_address,
            'created_at'      => $o->created_at->toIso8601String(),
        ]);

        return $this->success($data);
    }

    /**
     * POST /api/v1/medical/medicine-orders/{medicineOrder}/cancel
     * Buyurtmani bekor qilish
     */
    public function cancel(MedicineOrder $medicineOrder): JsonResponse
    {
        $user = auth()->user();

        if ($medicineOrder->patient_id !== $user->id) {
            return $this->error('Ruxsat yo\'q.', 403);
        }

        if (!$medicineOrder->canCancel()) {
            return $this->error('Bu buyurtmani bekor qilib bo\'lmaydi.', 422);
        }

        return DB::transaction(function () use ($medicineOrder, $user) {
            $medicineOrder = MedicineOrder::lockForUpdate()->find($medicineOrder->id);

            if (!$medicineOrder->canCancel()) {
                return $this->error('Bu buyurtmani bekor qilib bo\'lmaydi.', 422);
            }

            $wallet = Wallet::where('user_id', $user->id)->lockForUpdate()->first();
            $wallet->increment('balance', $medicineOrder->total_amount);

            $medicineOrder->update([
                'status'        => MedicineOrder::STATUS_CANCELLED,
                'cancel_reason' => 'Bemor tomonidan bekor qilindi',
            ]);

            Transaction::create([
                'user_id'              => $user->id,
                'type'                 => 'medical_refund',
                'transactionable_type' => MedicineOrder::class,
                'transactionable_id'   => $medicineOrder->id,
                'amount'               => $medicineOrder->total_amount,
                'balance_before'       => $wallet->balance - $medicineOrder->total_amount,
                'balance_after'        => $wallet->balance,
                'direction'            => 'credit',
                'status'               => 'completed',
                'description'          => 'Dori buyurtma bekor qilindi — to\'lov qaytarildi',
            ]);

            return $this->success(null, 'Buyurtma bekor qilindi. To\'lov qaytarildi.');
        });
    }
}
