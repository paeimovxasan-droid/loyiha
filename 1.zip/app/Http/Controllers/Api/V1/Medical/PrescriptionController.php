<?php

namespace App\Http\Controllers\Api\V1\Medical;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Medical\Consultation;
use App\Models\Medical\Medicine;
use App\Models\Medical\Prescription;
use App\Models\Medical\PrescriptionItem;
use App\Services\TelegramBotService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PrescriptionController extends Controller
{
    use ApiResponse;

    /**
     * POST /api/v1/medical/consultations/{consultation}/prescriptions
     * Retsept yozish (shifokor)
     */
    public function store(Request $request, Consultation $consultation): JsonResponse
    {
        $user = auth()->user();

        if ($consultation->doctor_id !== $user->id) {
            return $this->error('Ruxsat yo\'q.', 403);
        }

        if (!$consultation->isActive()) {
            return $this->error('Faqat faol maslahatda retsept yozish mumkin.', 422);
        }

        $validated = $request->validate([
            'notes'                => 'nullable|string|max:1000',
            'items'                => 'required|array|min:1',
            'items.*.medicine_id'  => 'nullable|exists:medicines,id',
            'items.*.medicine_name' => 'required|string|max:255',
            'items.*.dosage'       => 'required|string|max:255',
            'items.*.frequency'    => 'required|string|max:255',
            'items.*.duration'     => 'required|string|max:255',
            'items.*.instructions' => 'nullable|string|max:500',
        ]);

        $prescription = Prescription::create([
            'consultation_id' => $consultation->id,
            'doctor_id'       => $user->id,
            'patient_id'      => $consultation->patient_id,
            'notes'           => $validated['notes'] ?? null,
        ]);

        foreach ($validated['items'] as $item) {
            PrescriptionItem::create([
                'prescription_id' => $prescription->id,
                'medicine_id'     => $item['medicine_id'] ?? null,
                'medicine_name'   => $item['medicine_name'],
                'dosage'          => $item['dosage'],
                'frequency'       => $item['frequency'],
                'duration'        => $item['duration'],
                'instructions'    => $item['instructions'] ?? null,
            ]);
        }

        // Bemorga bildirishnoma
        TelegramBotService::notify(
            $consultation->patient,
            "📋 Shifokor sizga retsept yozdi!\n"
            . "Dorilar soni: " . count($validated['items']),
            [[['text' => '📋 Retseptni ko\'rish', 'url' => config('app.url') . '/app/consultations/' . $consultation->id]]]
        );

        $prescription->load('items');

        return $this->success([
            'id'    => $prescription->id,
            'notes' => $prescription->notes,
            'items' => $prescription->items->map(fn($i) => [
                'medicine_name' => $i->medicine_name,
                'dosage'        => $i->dosage,
                'frequency'     => $i->frequency,
                'duration'      => $i->duration,
                'instructions'  => $i->instructions,
            ]),
        ], 'Retsept yozildi.', 201);
    }

    /**
     * GET /api/v1/medical/medicines
     * Dori katalogi (autocomplete uchun)
     */
    public function medicines(Request $request): JsonResponse
    {
        $query = Medicine::available();

        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }

        $medicines = $query->select('id', 'name', 'type', 'price')->limit(20)->get();

        return $this->success($medicines);
    }
}
