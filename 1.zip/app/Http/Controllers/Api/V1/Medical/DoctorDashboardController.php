<?php

namespace App\Http\Controllers\Api\V1\Medical;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Medical\Consultation;
use App\Models\Medical\DoctorProfile;
use Illuminate\Http\JsonResponse;

class DoctorDashboardController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/medical/doctor/dashboard
     * Shifokor daromad paneli
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();
        $profile = DoctorProfile::where('user_id', $user->id)->first();

        if (!$profile) {
            return $this->error('Shifokor profilingiz topilmadi.', 404);
        }

        $totalConsultations = Consultation::where('doctor_id', $user->id)
            ->where('status', Consultation::STATUS_COMPLETED)
            ->count();

        $totalEarnings = Consultation::where('doctor_id', $user->id)
            ->where('status', Consultation::STATUS_COMPLETED)
            ->sum('doctor_earning');

        $monthlyEarnings = Consultation::where('doctor_id', $user->id)
            ->where('status', Consultation::STATUS_COMPLETED)
            ->where('completed_at', '>=', now()->startOfMonth())
            ->sum('doctor_earning');

        $recentEarnings = Consultation::where('doctor_id', $user->id)
            ->where('status', Consultation::STATUS_COMPLETED)
            ->latest('completed_at')
            ->limit(20)
            ->get()
            ->map(fn($c) => [
                'id'              => $c->id,
                'price'           => (float) $c->price,
                'commission'      => (float) $c->commission_amount,
                'earning'         => (float) $c->doctor_earning,
                'completed_at'    => $c->completed_at->toIso8601String(),
            ]);

        return $this->success([
            'profile' => [
                'status'              => $profile->status,
                'rating'              => (float) $profile->rating,
                'reviews_count'       => $profile->reviews_count,
                'consultations_count' => $profile->consultations_count,
                'is_online'           => $profile->is_online,
            ],
            'stats' => [
                'total_consultations' => $totalConsultations,
                'total_earnings'      => (float) $totalEarnings,
                'monthly_earnings'    => (float) $monthlyEarnings,
                'average_rating'      => (float) $profile->rating,
            ],
            'recent_earnings' => $recentEarnings,
        ]);
    }
}
