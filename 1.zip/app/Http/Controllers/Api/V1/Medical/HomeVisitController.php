<?php

namespace App\Http\Controllers\Api\V1\Medical;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Medical\DoctorProfile;
use App\Models\Medical\HomeVisit;
use App\Services\Medical\MedicalService;
use App\Services\TelegramBotService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class HomeVisitController extends Controller
{
    use ApiResponse;

    /**
     * POST /api/v1/medical/home-visits
     * Uyga chaqirish so'rovi (bemor)
     */
    public function store(Request $request): JsonResponse
    {
        $user = auth()->user();

        $validated = $request->validate([
            'doctor_profile_id' => 'required|exists:doctor_profiles,id',
            'address'           => 'required|string|max:500',
            'symptoms'          => 'nullable|string|max:1000',
        ]);

        $doctorProfile = DoctorProfile::findOrFail($validated['doctor_profile_id']);

        if (!$doctorProfile->isApproved() || !$doctorProfile->offers_home_visit) {
            return $this->error('Bu shifokor uyga chaqirish xizmatini taqdim etmaydi.', 422);
        }

        if ($doctorProfile->user_id === $user->id) {
            return $this->error('O\'zingizni chaqira olmaysiz.', 422);
        }

        try {
            $homeVisit = MedicalService::createHomeVisit(
                $user, $doctorProfile, $validated['address'], $validated['symptoms'] ?? null
            );

            return $this->success([
                'id'     => $homeVisit->id,
                'status' => $homeVisit->status,
                'price'  => (float) $homeVisit->price,
            ], 'Uyga chaqirish so\'rovi yuborildi.', 201);
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }

    /**
     * GET /api/v1/medical/home-visits
     * Mening uyga chaqirishlarim
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();

        $visits = HomeVisit::where(function ($q) use ($user) {
            $q->where('patient_id', $user->id)
              ->orWhere('doctor_id', $user->id);
        })->with(['patient:id,name', 'doctor:id,name', 'doctorProfile:id,specialty'])
          ->latest()
          ->paginate(15);

        $data = $visits->through(fn($v) => [
            'id'         => $v->id,
            'patient'    => $v->patient->name,
            'doctor'     => $v->doctor->name,
            'specialty'  => $v->doctorProfile->specialty,
            'address'    => $v->address,
            'price'      => (float) $v->price,
            'status'     => $v->status,
            'created_at' => $v->created_at->toIso8601String(),
        ]);

        return $this->success($data);
    }

    /**
     * POST /api/v1/medical/home-visits/{homeVisit}/accept
     * Qabul qilish (shifokor)
     */
    public function accept(HomeVisit $homeVisit): JsonResponse
    {
        $user = auth()->user();

        if ($homeVisit->doctor_id !== $user->id) {
            return $this->error('Ruxsat yo\'q.', 403);
        }

        if (!$homeVisit->isPending()) {
            return $this->error('Bu so\'rov allaqachon qayta ishlangan.', 422);
        }

        $homeVisit->update([
            'status'      => HomeVisit::STATUS_ACCEPTED,
            'accepted_at' => now(),
        ]);

        TelegramBotService::notify(
            $homeVisit->patient,
            "✅ Shifokor uyga chaqirish so'rovingizni qabul qildi!\n"
            . "👨‍⚕️ {$user->name}"
        );

        return $this->success(null, 'So\'rov qabul qilindi.');
    }

    /**
     * POST /api/v1/medical/home-visits/{homeVisit}/on-the-way
     * Yo'lda (shifokor)
     */
    public function onTheWay(HomeVisit $homeVisit): JsonResponse
    {
        $user = auth()->user();

        if ($homeVisit->doctor_id !== $user->id) {
            return $this->error('Ruxsat yo\'q.', 403);
        }

        if ($homeVisit->status !== HomeVisit::STATUS_ACCEPTED) {
            return $this->error('Avval so\'rovni qabul qiling.', 422);
        }

        $homeVisit->update(['status' => HomeVisit::STATUS_ON_THE_WAY]);

        TelegramBotService::notify(
            $homeVisit->patient,
            "🚗 Shifokor yo'lda! Tez orada yetib boradi."
        );

        return $this->success(null, 'Holat yangilandi: yo\'lda.');
    }

    /**
     * POST /api/v1/medical/home-visits/{homeVisit}/complete
     * Tugatish (shifokor)
     */
    public function complete(HomeVisit $homeVisit): JsonResponse
    {
        $user = auth()->user();

        if ($homeVisit->doctor_id !== $user->id) {
            return $this->error('Ruxsat yo\'q.', 403);
        }

        try {
            MedicalService::completeHomeVisit($homeVisit);
            return $this->success(null, 'Xizmat tugallandi. To\'lov hisobingizga o\'tkazildi.');
        } catch (\Exception $e) {
            return $this->error($e->getMessage(), 422);
        }
    }
}
