<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Models\Marketing\SeasonalEvent;
use App\Services\Marketing\EventService;
use Illuminate\Http\JsonResponse;

class SeasonalEventController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/events — aktiv tadbirlar ro'yxati
     */
    public function index(): JsonResponse
    {
        $events = EventService::getActive()->map(fn (SeasonalEvent $e) => [
            'id'          => $e->id,
            'name'        => $e->name,
            'description' => $e->description,
            'banner'      => $e->banner ? asset('storage/' . $e->banner) : null,
            'starts_at'   => $e->starts_at->toDateTimeString(),
            'ends_at'     => $e->ends_at->toDateTimeString(),
            'quests'      => $e->quests->map(fn ($q) => [
                'id'   => $q->id,
                'name' => $q->name ?? null,
            ]),
        ]);

        return $this->success(['events' => $events]);
    }

    /**
     * GET /api/v1/events/{event} — tadbir tafsilotlari
     */
    public function show(SeasonalEvent $event): JsonResponse
    {
        $leaderboard = EventService::getEventLeaderboard($event);

        return $this->success([
            'event' => [
                'id'          => $event->id,
                'name'        => $event->name,
                'description' => $event->description,
                'banner'      => $event->banner ? asset('storage/' . $event->banner) : null,
                'starts_at'   => $event->starts_at->toDateTimeString(),
                'ends_at'     => $event->ends_at->toDateTimeString(),
                'prizes'      => $event->prizes,
            ],
            'leaderboard' => $leaderboard,
        ]);
    }
}
