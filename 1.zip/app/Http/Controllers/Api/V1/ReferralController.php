<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use Illuminate\Http\JsonResponse;

class ReferralController extends Controller
{
    use ApiResponse;

    /**
     * Referral havola, jalb qilganlar ro'yxati, jami komissiya
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();

        $referrals = $user->referrals()
            ->select('id', 'name', 'username', 'avatar', 'created_at')
            ->latest()
            ->paginate(20);

        $totalCommission = (float) $user->commissions()->sum('amount');

        $botUsername = config('services.telegram.bot_username', 'aisoqqa_bot');

        return $this->success([
            'referral_link_telegram' => "https://t.me/{$botUsername}?start=ref_{$user->username}",
            'referral_link_web'      => "https://aisoqqa.uz/register/{$user->username}",
            'referrals'              => $referrals->items(),
            'total_commission'       => $totalCommission,
            'pagination'             => [
                'current_page' => $referrals->currentPage(),
                'last_page'    => $referrals->lastPage(),
                'per_page'     => $referrals->perPage(),
                'total'        => $referrals->total(),
            ],
        ]);
    }
}
