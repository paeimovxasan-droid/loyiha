<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Http\Traits\ApiResponse;
use App\Services\Marketing\BadgeService;
use Illuminate\Http\JsonResponse;

class BadgeController extends Controller
{
    use ApiResponse;

    /**
     * GET /api/v1/badges
     */
    public function index(): JsonResponse
    {
        $user = auth()->user();

        $userBadges = BadgeService::getUserBadges($user->id)
            ->map(fn ($ub) => [
                'id'         => $ub->id,
                'type'       => $ub->badgeConfig?->type,
                'name'       => $ub->badgeConfig?->name,
                'icon'       => $ub->badgeConfig?->icon,
                'color'      => $ub->badgeConfig?->color,
                'reward_ais' => (float) ($ub->badgeConfig?->reward_ais ?? 0),
                'awarded_at' => $ub->awarded_at?->toDateTimeString(),
            ]);

        $availableBadges = BadgeService::getBadgeConfig();

        return $this->success([
            'badges'           => $userBadges,
            'available_badges' => $availableBadges,
        ]);
    }
}
