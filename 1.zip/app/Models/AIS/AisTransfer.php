<?php

namespace App\Models\AIS;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class AisTransfer extends Model
{
    protected $fillable = [
        'sender_id', 'receiver_id', 'amount',
        'fee', 'note', 'reference', 'status',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:4',
            'fee'    => 'decimal:4',
        ];
    }

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn($m) => $m->reference ??= strtoupper(Str::random(12)));
    }

    public function sender(): BelongsTo
    {
        return $this->belongsTo(User::class, 'sender_id');
    }

    public function receiver(): BelongsTo
    {
        return $this->belongsTo(User::class, 'receiver_id');
    }

    /** Jami yechilgan summa (amount + fee) */
    public function getTotalDebitAttribute(): float
    {
        return round($this->amount + $this->fee, 4);
    }

    public function isCompleted(): bool { return $this->status === 'completed'; }
}
