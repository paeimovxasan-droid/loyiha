<?php

namespace App\Models\AIS;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AisConversion extends Model
{
    protected $fillable = [
        'user_id', 'rate_id', 'direction',
        'uzs_amount', 'ais_amount', 'rate_used', 'fee', 'status',
    ];

    protected function casts(): array
    {
        return [
            'uzs_amount' => 'decimal:2',
            'ais_amount' => 'decimal:4',
            'rate_used'  => 'decimal:2',
            'fee'        => 'decimal:4',
        ];
    }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function rate(): BelongsTo { return $this->belongsTo(AisRate::class); }

    public function isBuy(): bool { return $this->direction === 'buy'; }
    public function isSell(): bool { return $this->direction === 'sell'; }
}
