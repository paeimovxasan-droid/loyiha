<?php

namespace App\Models\AIS;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Hash;

class VirtualCard extends Model
{
    protected $fillable = [
        'user_id', 'wallet_id', 'card_number', 'card_holder',
        'expiry_month', 'expiry_year', 'cvv_hash',
        'daily_limit', 'monthly_limit', 'status',
    ];

    protected $hidden = ['cvv_hash'];

    protected function casts(): array
    {
        return [
            'daily_limit'   => 'decimal:4',
            'monthly_limit' => 'decimal:4',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function wallet(): BelongsTo
    {
        return $this->belongsTo(Wallet::class);
    }

    /** Karta raqamini formatlash: XXXX XXXX XXXX XXXX */
    public function getFormattedNumberAttribute(): string
    {
        return implode(' ', str_split(str_replace(' ', '', $this->card_number), 4));
    }

    /** Muddati: MM/YY */
    public function getExpiryAttribute(): string
    {
        return $this->expiry_month . '/' . substr($this->expiry_year, -2);
    }

    /** Karta raqami generatsiya (Luhn algoritmi) */
    public static function generateCardNumber(): string
    {
        do {
            $number = '4' . implode('', array_map(fn() => random_int(0, 9), range(1, 15)));
            $number = static::luhnCheck($number);
        } while (static::where('card_number', $number)->exists());

        return $number;
    }

    private static function luhnCheck(string $number): string
    {
        $digits = str_split($number);
        $sum = 0;
        $reverse = array_reverse($digits);
        foreach ($reverse as $i => $digit) {
            $n = (int) $digit;
            if ($i % 2 === 1) {
                $n *= 2;
                if ($n > 9) $n -= 9;
            }
            $sum += $n;
        }
        $check = (10 - ($sum % 10)) % 10;
        $digits[15] = $check;
        return implode('', $digits);
    }

    public function isActive(): bool { return $this->status === 'active'; }
    public function isFrozen(): bool { return $this->status === 'frozen'; }

    public function verifyCvv(string $cvv): bool
    {
        return Hash::check($cvv, $this->cvv_hash);
    }
}
