<?php

namespace App\Models\AIS;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\User;
use Illuminate\Support\Facades\Cache;

class AisRate extends Model
{
    protected $table = 'ais_rates';

    protected $fillable = [
        'rate_uzs', 'buy_rate', 'sell_rate', 'set_by', 'is_active',
    ];

    protected function casts(): array
    {
        return [
            'rate_uzs'  => 'decimal:2',
            'buy_rate'  => 'decimal:2',
            'sell_rate' => 'decimal:2',
            'is_active' => 'boolean',
        ];
    }

    protected static function booted()
    {
        static::saved(function ($model) {
            Cache::forget('ais_current_rate');
        });

        static::deleted(function ($model) {
            Cache::forget('ais_current_rate');
        });
    }

    public function setBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'set_by');
    }

    /** Joriy aktiv kursni olish (Keshlangan — 1 soat) */
    public static function current(): static
    {
        return Cache::remember('ais_current_rate', now()->addHour(), function () {
            $rate = static::where('is_active', true)->latest()->first();

            if (!$rate) {
                // Default kurs yaratish
                $rate = static::create([
                    'rate_uzs'  => 1000,
                    'buy_rate'  => 1000,
                    'sell_rate' => 950,
                    'is_active' => true,
                ]);
            }

            return $rate;
        });
    }

    /** UZS → AIS konvertatsiya */
    public function uzsToAis(float $uzs): float
    {
        return round($uzs / $this->buy_rate, 4);
    }

    /** AIS → UZS konvertatsiya */
    public function aisToUzs(float $ais): float
    {
        return round($ais * $this->sell_rate, 2);
    }
}
