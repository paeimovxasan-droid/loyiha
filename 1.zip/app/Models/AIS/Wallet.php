<?php

namespace App\Models\AIS;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Wallet extends Model
{
    protected $fillable = [
        'user_id', 'wallet_number', 'balance',
        'frozen_balance', 'is_frozen',
    ];

    protected function casts(): array
    {
        return [
            'balance'        => 'decimal:4',
            'frozen_balance' => 'decimal:4',
            'is_frozen'      => 'boolean',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function cards(): HasMany
    {
        return $this->hasMany(VirtualCard::class);
    }

    public function sentTransfers(): HasMany
    {
        return $this->hasMany(AisTransfer::class, 'sender_id', 'user_id');
    }

    public function receivedTransfers(): HasMany
    {
        return $this->hasMany(AisTransfer::class, 'receiver_id', 'user_id');
    }

    /** Mavjud balans (frozen chiqarib) */
    public function getAvailableBalanceAttribute(): float
    {
        return max(0, $this->balance - $this->frozen_balance);
    }

    /** Hamyon raqamini formatlash: AIS-1234-5678-9012 */
    public function getFormattedNumberAttribute(): string
    {
        return $this->wallet_number;
    }

    /** Yangi hamyon raqami generatsiya */
    public static function generateNumber(): string
    {
        do {
            $number = 'AIS-' . str_pad(random_int(0, 9999), 4, '0', STR_PAD_LEFT)
                    . '-' . str_pad(random_int(0, 9999), 4, '0', STR_PAD_LEFT)
                    . '-' . str_pad(random_int(0, 9999), 4, '0', STR_PAD_LEFT);
        } while (static::where('wallet_number', $number)->exists());

        return $number;
    }

    public function isFrozen(): bool
    {
        return $this->is_frozen;
    }

    public function hasEnough(float $amount): bool
    {
        return $this->available_balance >= $amount;
    }
}
