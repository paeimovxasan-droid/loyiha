<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ChargingSession extends Model
{
    protected $fillable = [
        'user_id', 'station_id', 'vehicle_id',
        'started_at', 'ended_at',
        'consumed_kw', 'total_amount', 'status',
    ];

    protected function casts(): array
    {
        return [
            'started_at'   => 'datetime',
            'ended_at'     => 'datetime',
            'consumed_kw'  => 'decimal:2',
            'total_amount' => 'decimal:2',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function station(): BelongsTo
    {
        return $this->belongsTo(Station::class);
    }

    public function vehicle(): BelongsTo
    {
        return $this->belongsTo(ElectricVehicle::class, 'vehicle_id');
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }
}
