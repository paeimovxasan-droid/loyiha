<?php

namespace App\Models\Finance;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Translatable\HasTranslations;

class Bonus extends Model
{
    use HasTranslations;

    protected $fillable = ['name', 'code', 'required_services', 'amount', 'status'];

    public array $translatable = ['name'];

    protected function casts(): array
    {
        return ['amount' => 'decimal:2'];
    }

    public function scopeActive($query) { return $query->where('status', 'active'); }

    public function ledgers(): HasMany { return $this->hasMany(BonusLedger::class); }
}
