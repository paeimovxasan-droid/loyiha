<?php

namespace App\Models\Finance;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Commission extends Model
{
    protected $fillable = [
        'user_id', 'from_user_id', 'reason',
        'level', 'percent', 'amount', 'date', 'status',
    ];

    protected function casts(): array
    {
        return [
            'percent' => 'decimal:2',
            'amount'  => 'decimal:2',
            'date'    => 'date',
        ];
    }

    public function scopeActive($query) { return $query->where('status', 'active'); }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function fromUser(): BelongsTo { return $this->belongsTo(User::class, 'from_user_id'); }
}
