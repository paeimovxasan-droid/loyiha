<?php

namespace App\Models\Finance;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class Transaction extends Model
{
    protected $fillable = [
        'user_id', 'type',
        'transactionable_type', 'transactionable_id',
        'description',
        'amount', 'balance_before', 'balance_after',
        'direction', 'status',
    ];

    protected function casts(): array
    {
        return [
            'amount'         => 'decimal:4',  // AIS tranzaksiyalar uchun 4 kasr kerak (0.0001 AIS)
            'balance_before' => 'decimal:4',
            'balance_after'  => 'decimal:4',
        ];
    }

    // Transaction types constants
    const TYPE_DEPOSIT     = 'deposit';
    const TYPE_WITHDRAW    = 'withdraw';
    const TYPE_MINING      = 'mining';
    const TYPE_COMMISSION  = 'commission';
    const TYPE_BONUS       = 'bonus';
    const TYPE_LUCKY_DRAW  = 'lucky_draw';
    const TYPE_FUND        = 'fund';
    const TYPE_CHECKIN     = 'checkin';
    const TYPE_TASK        = 'task';
    const TYPE_CREDIT      = 'credit';
    const TYPE_SAVINGS     = 'savings';
    const TYPE_GROUP_SAVINGS = 'group_savings';

    public function scopeCredit($query) { return $query->where('direction', 'credit'); }
    public function scopeDebit($query) { return $query->where('direction', 'debit'); }
    public function scopeByType($query, string $type) { return $query->where('type', $type); }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }

    /**
     * Polymorphic - Deposit, Withdrawal, Mining, Purchase...ga bog'lanadi
     */
    public function transactionable(): MorphTo { return $this->morphTo(); }

    public function isCredit(): bool { return $this->direction === 'credit'; }
    public function isDebit(): bool { return $this->direction === 'debit'; }
}
