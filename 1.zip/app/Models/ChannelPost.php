<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ChannelPost extends Model
{
    protected $fillable = [
        'type',
        'content',
        'photo',
        'telegram_message_id',
        'sent_at',
        'status',
        'created_by',
    ];

    protected function casts(): array
    {
        return [
            'sent_at' => 'datetime',
        ];
    }

    // ─── Relations ─────────────────────────────────────────────────────────────

    public function creator(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    // ─── Scopes ────────────────────────────────────────────────────────────────

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    public function scopeSent($query)
    {
        return $query->where('status', 'sent');
    }
}
