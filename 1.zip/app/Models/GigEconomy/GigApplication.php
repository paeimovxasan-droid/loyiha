<?php

namespace App\Models\GigEconomy;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class GigApplication extends Model
{
    protected $fillable = ['gig_listing_id', 'user_id', 'status'];

    public function listing(): BelongsTo
    {
        return $this->belongsTo(GigListing::class, 'gig_listing_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class);
    }
}
