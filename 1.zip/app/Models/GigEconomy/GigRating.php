<?php

namespace App\Models\GigEconomy;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class GigRating extends Model
{
    protected $fillable = ['gig_listing_id', 'rater_id', 'rated_user_id', 'rating', 'comment'];

    protected function casts(): array
    {
        return ['rating' => 'integer'];
    }

    public function listing(): BelongsTo
    {
        return $this->belongsTo(GigListing::class, 'gig_listing_id');
    }

    public function rater(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'rater_id');
    }

    public function ratedUser(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'rated_user_id');
    }
}
