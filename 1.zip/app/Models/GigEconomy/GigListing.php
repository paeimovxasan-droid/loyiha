<?php

namespace App\Models\GigEconomy;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class GigListing extends Model
{
    protected $fillable = [
        'user_id', 'title', 'description', 'category',
        'location', 'price', 'work_date', 'status',
    ];

    protected function casts(): array
    {
        return [
            'price'     => 'decimal:4',
            'work_date' => 'date',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function applications(): HasMany
    {
        return $this->hasMany(GigApplication::class);
    }

    public function acceptedApplication(): HasOne
    {
        return $this->hasOne(GigApplication::class)->where('status', 'accepted');
    }

    public function ratings(): HasMany
    {
        return $this->hasMany(GigRating::class);
    }

    public function isOpen(): bool
    {
        return $this->status === 'open';
    }
}
