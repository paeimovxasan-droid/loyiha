<?php

namespace App\Models\Crowdfunding;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CfExpense extends Model
{
    protected $fillable = [
        'cf_project_id', 'amount', 'description', 'spent_at',
    ];

    protected function casts(): array
    {
        return [
            'amount'   => 'decimal:4',
            'spent_at' => 'date',
        ];
    }

    public function project(): BelongsTo
    {
        return $this->belongsTo(CfProject::class, 'cf_project_id');
    }
}
