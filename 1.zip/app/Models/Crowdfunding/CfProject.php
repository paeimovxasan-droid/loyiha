<?php

namespace App\Models\Crowdfunding;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CfProject extends Model
{
    protected $fillable = [
        'user_id', 'title', 'description', 'category',
        'goal_amount', 'collected_amount', 'status',
        'rejection_reason', 'expires_at',
    ];

    protected function casts(): array
    {
        return [
            'goal_amount'      => 'decimal:4',
            'collected_amount' => 'decimal:4',
            'expires_at'       => 'datetime',
        ];
    }

    // ─── Relations ─────────────────────────────────────────────

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function donations(): HasMany
    {
        return $this->hasMany(CfDonation::class);
    }

    public function expenses(): HasMany
    {
        return $this->hasMany(CfExpense::class);
    }

    // ─── Accessors ─────────────────────────────────────────────

    public function getProgressAttribute(): float
    {
        if ($this->goal_amount <= 0) {
            return 0;
        }

        return round(($this->collected_amount / $this->goal_amount) * 100, 2);
    }

    // ─── Helpers ───────────────────────────────────────────────

    public function isExpired(): bool
    {
        return $this->expires_at && $this->expires_at->isPast();
    }

    public function isActive(): bool
    {
        return $this->status === 'active' && !$this->isExpired();
    }
}
