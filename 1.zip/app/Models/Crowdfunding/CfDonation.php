<?php

namespace App\Models\Crowdfunding;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CfDonation extends Model
{
    protected $fillable = [
        'user_id', 'cf_project_id', 'amount',
    ];

    protected function casts(): array
    {
        return [
            'amount' => 'decimal:4',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function project(): BelongsTo
    {
        return $this->belongsTo(CfProject::class, 'cf_project_id');
    }
}
