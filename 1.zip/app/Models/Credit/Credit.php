<?php

namespace App\Models\Credit;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class Credit extends Model
{
    protected $fillable = [
        'user_id', 'amount', 'currency', 'interest_rate', 'interest_amount',
        'term_days', 'credit_score', 'status', 'issued_at', 'due_date', 'paid_at',
    ];

    protected function casts(): array
    {
        return [
            'amount'          => 'decimal:2',
            'interest_rate'   => 'decimal:2',
            'interest_amount' => 'decimal:2',
            'issued_at'       => 'datetime',
            'due_date'        => 'datetime',
            'paid_at'         => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(CreditPayment::class);
    }

    public function transactions(): MorphMany
    {
        return $this->morphMany(\App\Models\Finance\Transaction::class, 'transactionable');
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeOverdue($query)
    {
        return $query->where('status', 'overdue');
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }
}
