<?php

namespace App\Models\Credit;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class CreditPayment extends Model
{
    protected $fillable = [
        'credit_id', 'user_id', 'amount', 'principal', 'interest', 'currency',
    ];

    protected function casts(): array
    {
        return [
            'amount'    => 'decimal:2',
            'principal' => 'decimal:2',
            'interest'  => 'decimal:2',
        ];
    }

    public function credit(): BelongsTo
    {
        return $this->belongsTo(Credit::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function transactions(): MorphMany
    {
        return $this->morphMany(\App\Models\Finance\Transaction::class, 'transactionable');
    }
}
