<?php

namespace App\Models\Influencer;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Facades\Cache;

class InfluencerSetting extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'is_enabled',
        'coeff_youtube_channel',
        'coeff_telegram_channel',
        'coeff_telegram_group',
        'coeff_telegram_bot',
        'min_subscribers_youtube',
        'min_subscribers_telegram',
        'screenshot_required',
        'max_daily_submissions',
        'max_channels_per_user',
        'updated_at',
        'updated_by',
    ];

    protected function casts(): array
    {
        return [
            'is_enabled'               => 'boolean',
            'coeff_youtube_channel'    => 'decimal:2',
            'coeff_telegram_channel'   => 'decimal:2',
            'coeff_telegram_group'     => 'decimal:2',
            'coeff_telegram_bot'       => 'decimal:2',
            'min_subscribers_youtube'  => 'integer',
            'min_subscribers_telegram' => 'integer',
            'screenshot_required'      => 'boolean',
            'max_daily_submissions'    => 'integer',
            'max_channels_per_user'    => 'integer',
            'updated_at'               => 'datetime',
        ];
    }

    // ─── Singleton ────────────────────────────────────────────────────────────

    public static function current(): self
    {
        return Cache::remember('influencer_settings', 300, function () {
            return self::firstOrCreate([], [
                'is_enabled'               => true,
                'coeff_youtube_channel'    => 1.50,
                'coeff_telegram_channel'   => 1.20,
                'coeff_telegram_group'     => 1.00,
                'coeff_telegram_bot'       => 0.80,
                'min_subscribers_youtube'  => 1000,
                'min_subscribers_telegram' => 500,
                'screenshot_required'      => true,
                'max_daily_submissions'    => 5,
                'max_channels_per_user'    => 10,
            ]);
        });
    }

    public static function clearCache(): void
    {
        Cache::forget('influencer_settings');
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    public function getCoefficientForType(string $channelType): float
    {
        return match($channelType) {
            'youtube_channel'  => (float) $this->coeff_youtube_channel,
            'telegram_channel' => (float) $this->coeff_telegram_channel,
            'telegram_group'   => (float) $this->coeff_telegram_group,
            'telegram_bot'     => (float) $this->coeff_telegram_bot,
            default            => 1.0,
        };
    }

    public function getMinSubscribersForType(string $channelType): int
    {
        return match($channelType) {
            'youtube_channel' => $this->min_subscribers_youtube,
            default           => $this->min_subscribers_telegram,
        };
    }

    // ─── Relations ────────────────────────────────────────────────────────────

    public function updatedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }
}
