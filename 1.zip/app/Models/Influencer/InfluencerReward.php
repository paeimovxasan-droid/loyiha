<?php

namespace App\Models\Influencer;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class InfluencerReward extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'user_id', 'submission_id', 'campaign_id', 'channel_id',
        'amount', 'coefficient', 'wallet_tx_id', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'amount'      => 'decimal:4',
            'coefficient' => 'decimal:2',
            'created_at'  => 'datetime',
        ];
    }

    // ─── Relations ────────────────────────────────────────────────────────────

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function submission(): BelongsTo
    {
        return $this->belongsTo(InfluencerSubmission::class, 'submission_id');
    }

    public function campaign(): BelongsTo
    {
        return $this->belongsTo(InfluencerCampaign::class, 'campaign_id');
    }

    public function channel(): BelongsTo
    {
        return $this->belongsTo(InfluencerChannel::class, 'channel_id');
    }
}
