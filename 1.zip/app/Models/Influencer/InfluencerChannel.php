<?php

namespace App\Models\Influencer;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class InfluencerChannel extends Model
{
    protected $fillable = [
        'user_id', 'type', 'name', 'url', 'subscriber_count',
        'language', 'status', 'rejection_reason',
        'approved_at', 'approved_by',
    ];

    protected function casts(): array
    {
        return [
            'subscriber_count' => 'integer',
            'approved_at'      => 'datetime',
        ];
    }

    // ─── Constants ────────────────────────────────────────────────────────────

    const TYPE_YOUTUBE   = 'youtube_channel';
    const TYPE_TG_CHANNEL = 'telegram_channel';
    const TYPE_TG_GROUP  = 'telegram_group';
    const TYPE_TG_BOT    = 'telegram_bot';

    const STATUS_PENDING   = 'pending';
    const STATUS_APPROVED  = 'approved';
    const STATUS_REJECTED  = 'rejected';
    const STATUS_SUSPENDED = 'suspended';

    const TYPES = [
        self::TYPE_YOUTUBE    => 'YouTube Kanal',
        self::TYPE_TG_CHANNEL => 'Telegram Kanal',
        self::TYPE_TG_GROUP   => 'Telegram Guruh',
        self::TYPE_TG_BOT     => 'Telegram Bot',
    ];

    // ─── Relations ────────────────────────────────────────────────────────────

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function approvedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function submissions(): HasMany
    {
        return $this->hasMany(InfluencerSubmission::class, 'channel_id');
    }

    // ─── Scopes ───────────────────────────────────────────────────────────────

    public function scopeApproved($query)
    {
        return $query->where('status', self::STATUS_APPROVED);
    }

    public function scopePending($query)
    {
        return $query->where('status', self::STATUS_PENDING);
    }

    public function scopeOfType($query, string $type)
    {
        return $query->where('type', $type);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    public function isApproved(): bool
    {
        return $this->status === self::STATUS_APPROVED;
    }

    public function isSuspended(): bool
    {
        return $this->status === self::STATUS_SUSPENDED;
    }

    public function getTypeLabelAttribute(): string
    {
        return self::TYPES[$this->type] ?? $this->type;
    }

    public function getStatusBadgeAttribute(): string
    {
        return match($this->status) {
            'pending'   => '<span class="badge bg-warning">Kutilmoqda</span>',
            'approved'  => '<span class="badge bg-success">Tasdiqlangan</span>',
            'rejected'  => '<span class="badge bg-danger">Rad etilgan</span>',
            'suspended' => '<span class="badge bg-secondary">Bloklangan</span>',
            default     => $this->status,
        };
    }
}
