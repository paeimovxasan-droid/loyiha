<?php

namespace App\Models\Influencer;

use App\Models\File;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Translatable\HasTranslations;

class InfluencerCampaign extends Model
{
    use HasTranslations;

    public array $translatable = ['ad_text'];

    protected $fillable = [
        'name', 'description', 'ad_text', 'image_id', 'target_url',
        'reward_amount', 'total_budget', 'spent_budget', 'status',
        'target_channel_types', 'min_subscribers', 'max_submissions_per_channel',
        'starts_at', 'ends_at', 'created_by',
    ];

    protected function casts(): array
    {
        return [
            'reward_amount'              => 'decimal:4',
            'total_budget'               => 'decimal:4',
            'spent_budget'               => 'decimal:4',
            'target_channel_types'       => 'array',
            'min_subscribers'            => 'integer',
            'max_submissions_per_channel'=> 'integer',
            'starts_at'                  => 'datetime',
            'ends_at'                    => 'datetime',
        ];
    }

    // ─── Constants ────────────────────────────────────────────────────────────

    const STATUS_ACTIVE    = 'active';
    const STATUS_PAUSED    = 'paused';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';

    // ─── Relations ────────────────────────────────────────────────────────────

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function image(): BelongsTo
    {
        return $this->belongsTo(File::class, 'image_id');
    }

    public function submissions(): HasMany
    {
        return $this->hasMany(InfluencerSubmission::class, 'campaign_id');
    }

    public function rewards(): HasMany
    {
        return $this->hasMany(InfluencerReward::class, 'campaign_id');
    }

    // ─── Scopes ───────────────────────────────────────────────────────────────

    public function scopeActive($query)
    {
        return $query->where('status', self::STATUS_ACTIVE)
                     ->where('starts_at', '<=', now())
                     ->where('ends_at', '>=', now());
    }

    public function scopeForChannelType($query, string $type)
    {
        return $query->whereJsonContains('target_channel_types', $type);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE
            && $this->starts_at <= now()
            && $this->ends_at >= now();
    }

    public function getRemainingBudgetAttribute(): float
    {
        return max(0, (float) $this->total_budget - (float) $this->spent_budget);
    }

    public function getBudgetPercentAttribute(): float
    {
        if ($this->total_budget <= 0) return 0;
        return min(100, round(($this->spent_budget / $this->total_budget) * 100, 1));
    }

    public function hasEnoughBudget(float $amount): bool
    {
        return $this->remaining_budget >= $amount;
    }

    public function getImageUrlAttribute(): string
    {
        return $this->image ? $this->image->url : asset('images/campaign-default.png');
    }
}
