<?php

namespace App\Models\Influencer;

use App\Models\File;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class InfluencerSubmission extends Model
{
    protected $fillable = [
        'user_id', 'channel_id', 'campaign_id', 'post_url',
        'screenshot_id', 'screenshot_hash', 'status',
        'rejection_reason', 'reward_amount',
        'reviewed_at', 'reviewed_by',
    ];

    protected function casts(): array
    {
        return [
            'reward_amount' => 'decimal:4',
            'reviewed_at'   => 'datetime',
        ];
    }

    // ─── Constants ────────────────────────────────────────────────────────────

    const STATUS_PENDING       = 'pending';
    const STATUS_APPROVED      = 'approved';
    const STATUS_REJECTED      = 'rejected';
    const STATUS_REWARD_FAILED = 'reward_failed';

    // ─── Relations ────────────────────────────────────────────────────────────

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function channel(): BelongsTo
    {
        return $this->belongsTo(InfluencerChannel::class, 'channel_id');
    }

    public function campaign(): BelongsTo
    {
        return $this->belongsTo(InfluencerCampaign::class, 'campaign_id');
    }

    public function screenshot(): BelongsTo
    {
        return $this->belongsTo(File::class, 'screenshot_id');
    }

    public function reviewedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }

    public function reward(): HasOne
    {
        return $this->hasOne(InfluencerReward::class, 'submission_id');
    }

    // ─── Scopes ───────────────────────────────────────────────────────────────

    public function scopePending($query)
    {
        return $query->where('status', self::STATUS_PENDING);
    }

    public function scopeApproved($query)
    {
        return $query->where('status', self::STATUS_APPROVED);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }

    public function isApproved(): bool
    {
        return $this->status === self::STATUS_APPROVED;
    }

    public function getScreenshotUrlAttribute(): ?string
    {
        return $this->screenshot?->url;
    }

    public function getStatusBadgeAttribute(): string
    {
        return match($this->status) {
            'pending'       => '<span class="badge bg-warning text-dark">Kutilmoqda</span>',
            'approved'      => '<span class="badge bg-success">Tasdiqlangan</span>',
            'rejected'      => '<span class="badge bg-danger">Rad etilgan</span>',
            'reward_failed' => '<span class="badge bg-dark">Mukofot xatosi</span>',
            default         => $this->status,
        };
    }
}
