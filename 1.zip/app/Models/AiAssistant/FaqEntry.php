<?php

namespace App\Models\AiAssistant;

use Illuminate\Database\Eloquent\Model;

class FaqEntry extends Model
{
    protected $fillable = ['question', 'answer', 'category', 'keywords', 'is_active'];

    protected function casts(): array
    {
        return ['is_active' => 'boolean'];
    }

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }
}
