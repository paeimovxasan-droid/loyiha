<?php

namespace App\Models\AiAssistant;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AiMessage extends Model
{
    protected $fillable = ['ai_conversation_id', 'role', 'content', 'faq_entry_id'];

    public function conversation(): BelongsTo
    {
        return $this->belongsTo(AiConversation::class, 'ai_conversation_id');
    }

    public function faqEntry(): BelongsTo
    {
        return $this->belongsTo(FaqEntry::class);
    }
}
