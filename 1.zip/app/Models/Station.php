<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Station extends Model
{
    use HasTranslations;

    protected $guarded = ['id'];

    public $translatable = ['name', 'address', 'district'];
}
