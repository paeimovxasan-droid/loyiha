<?php

namespace App\Models\AdNetwork;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AdView extends Model
{
    protected $fillable = ['ad_id', 'user_id', 'earned', 'viewed_at'];

    protected function casts(): array
    {
        return [
            'earned'    => 'decimal:4',
            'viewed_at' => 'datetime',
        ];
    }

    public function ad(): BelongsTo
    {
        return $this->belongsTo(Ad::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class);
    }
}
