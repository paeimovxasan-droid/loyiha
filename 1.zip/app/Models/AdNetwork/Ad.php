<?php

namespace App\Models\AdNetwork;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Ad extends Model
{
    protected $fillable = ['ad_campaign_id', 'title', 'description', 'image_url', 'target_url', 'status'];

    public function campaign(): BelongsTo
    {
        return $this->belongsTo(AdCampaign::class, 'ad_campaign_id');
    }

    public function views(): HasMany
    {
        return $this->hasMany(AdView::class);
    }
}
