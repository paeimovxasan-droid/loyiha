<?php

namespace App\Models\AdNetwork;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AdCampaign extends Model
{
    protected $fillable = ['user_id', 'name', 'budget', 'spent', 'cost_per_view', 'status'];

    protected function casts(): array
    {
        return [
            'budget'        => 'decimal:4',
            'spent'         => 'decimal:4',
            'cost_per_view' => 'decimal:4',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function ads(): HasMany
    {
        return $this->hasMany(Ad::class);
    }

    public function getRemainingBudgetAttribute(): float
    {
        return (float) $this->budget - (float) $this->spent;
    }
}
