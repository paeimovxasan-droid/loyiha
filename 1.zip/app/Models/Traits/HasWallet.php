<?php

namespace App\Models\Traits;

trait HasWallet
{
    public function wallet(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(\App\Models\AIS\Wallet::class);
    }

    public function virtualCards(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\AIS\VirtualCard::class);
    }

    public function sentTransfers(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\AIS\AisTransfer::class, 'sender_id');
    }

    public function receivedTransfers(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\AIS\AisTransfer::class, 'receiver_id');
    }

    public function aisConversions(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\AIS\AisConversion::class);
    }
}
