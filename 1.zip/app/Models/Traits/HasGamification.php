<?php

namespace App\Models\Traits;

trait HasGamification
{
    public function checkIns(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Game\CheckIn::class);
    }

    public function luckyTickets(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Game\LuckyDrawTicket::class);
    }

    public function userTasks(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Game\UserTask::class);
    }

    public function userLevel(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(\App\Models\Level\UserLevel::class);
    }

    public function xpLogs(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Level\XpLog::class);
    }

    public function getLevelAttribute(): int
    {
        return $this->userLevel?->level ?? 0;
    }

    public function getTotalXpAttribute(): int
    {
        return $this->userLevel?->total_xp ?? 0;
    }

    public function getLevelTitleAttribute(): string
    {
        return $this->userLevel?->title ?? 'Newcomer';
    }

    public function quests(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Game\UserQuest::class);
    }

    public function badges(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Marketing\UserBadge::class);
    }

    public function onboarding(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(\App\Models\Marketing\UserOnboarding::class);
    }

    public function inviteChallenges(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Marketing\InviteChallenge::class);
    }
}
