<?php

namespace App\Models\Traits;

use App\Models\Medical\Consultation;
use App\Models\Medical\DoctorProfile;
use App\Models\Medical\HomeVisit;
use App\Models\Medical\MedicineOrder;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

trait HasMedical
{
    public function doctorProfile(): HasOne
    {
        return $this->hasOne(DoctorProfile::class);
    }

    public function patientConsultations(): HasMany
    {
        return $this->hasMany(Consultation::class, 'patient_id');
    }

    public function doctorConsultations(): HasMany
    {
        return $this->hasMany(Consultation::class, 'doctor_id');
    }

    public function medicineOrders(): HasMany
    {
        return $this->hasMany(MedicineOrder::class, 'patient_id');
    }

    public function homeVisitRequests(): HasMany
    {
        return $this->hasMany(HomeVisit::class, 'patient_id');
    }

    public function isDoctor(): bool
    {
        return $this->doctorProfile !== null
            && $this->doctorProfile->status === 'approved';
    }

    public function isActiveDoctor(): bool
    {
        return $this->isDoctor()
            && !in_array($this->doctorProfile->status, ['suspended', 'inactive']);
    }
}
