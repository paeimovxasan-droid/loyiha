<?php

namespace App\Models\Traits;

trait HasMarketplace
{
    public function gigs(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Marketplace\Gig::class);
    }

    public function gigOrders(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Marketplace\GigOrder::class, 'buyer_id');
    }

    public function gigSales(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Marketplace\GigOrder::class, 'seller_id');
    }

    public function gigReviews(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Marketplace\GigReview::class, 'reviewer_id');
    }

    public function shop(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(\App\Models\Catalog\Shop::class);
    }

    public function catalogOrders(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Catalog\CatalogOrder::class, 'buyer_id');
    }
}
