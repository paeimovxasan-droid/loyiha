<?php

namespace App\Models\Tokenization;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TokenPurchase extends Model
{
    protected $fillable = ['user_id', 'asset_id', 'quantity', 'total_price'];

    protected function casts(): array
    {
        return [
            'quantity'    => 'integer',
            'total_price' => 'decimal:4',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function asset(): BelongsTo
    {
        return $this->belongsTo(Asset::class);
    }
}
