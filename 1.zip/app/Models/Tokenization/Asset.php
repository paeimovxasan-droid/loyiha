<?php

namespace App\Models\Tokenization;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Asset extends Model
{
    protected $fillable = [
        'name', 'description', 'total_value', 'total_tokens',
        'available_tokens', 'token_price', 'status',
    ];

    protected function casts(): array
    {
        return [
            'total_value'      => 'decimal:4',
            'token_price'      => 'decimal:4',
            'total_tokens'     => 'integer',
            'available_tokens' => 'integer',
        ];
    }

    public function tokens(): HasMany
    {
        return $this->hasMany(AssetToken::class);
    }

    public function purchases(): HasMany
    {
        return $this->hasMany(TokenPurchase::class);
    }

    public function getSoldTokensAttribute(): int
    {
        return $this->total_tokens - $this->available_tokens;
    }
}
