<?php

namespace App\Models\Lending;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Loan extends Model
{
    protected $fillable = [
        'loan_offer_id', 'lender_id', 'borrower_id', 'amount',
        'interest_rate', 'total_due', 'total_paid', 'status', 'due_date',
    ];

    protected function casts(): array
    {
        return [
            'amount'        => 'decimal:4',
            'interest_rate' => 'decimal:2',
            'total_due'     => 'decimal:4',
            'total_paid'    => 'decimal:4',
            'due_date'      => 'date',
        ];
    }

    public function offer(): BelongsTo
    {
        return $this->belongsTo(LoanOffer::class, 'loan_offer_id');
    }

    public function lender(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'lender_id');
    }

    public function borrower(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'borrower_id');
    }

    public function payments(): HasMany
    {
        return $this->hasMany(LoanPayment::class);
    }

    public function getRemainingAttribute(): float
    {
        return (float) $this->total_due - (float) $this->total_paid;
    }
}
