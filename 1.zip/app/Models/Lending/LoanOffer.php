<?php

namespace App\Models\Lending;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class LoanOffer extends Model
{
    protected $fillable = ['lender_id', 'amount', 'interest_rate', 'duration_days', 'description', 'status'];

    protected function casts(): array
    {
        return [
            'amount'        => 'decimal:4',
            'interest_rate' => 'decimal:2',
            'duration_days' => 'integer',
        ];
    }

    public function lender(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'lender_id');
    }

    public function loan(): HasOne
    {
        return $this->hasOne(Loan::class);
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }
}
