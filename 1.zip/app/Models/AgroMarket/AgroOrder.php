<?php

namespace App\Models\AgroMarket;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class AgroOrder extends Model
{
    protected $fillable = [
        'buyer_id', 'seller_id', 'agro_listing_id', 'quantity',
        'total_price', 'status', 'is_forward', 'delivery_date',
    ];

    protected function casts(): array
    {
        return [
            'quantity'      => 'decimal:2',
            'total_price'   => 'decimal:4',
            'is_forward'    => 'boolean',
            'delivery_date' => 'date',
        ];
    }

    public function buyer(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'buyer_id');
    }

    public function seller(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'seller_id');
    }

    public function listing(): BelongsTo
    {
        return $this->belongsTo(AgroListing::class, 'agro_listing_id');
    }
}
