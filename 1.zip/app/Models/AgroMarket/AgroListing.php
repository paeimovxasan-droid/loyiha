<?php

namespace App\Models\AgroMarket;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class AgroListing extends Model
{
    protected $fillable = [
        'user_id', 'title', 'description', 'category', 'quantity',
        'price_per_unit', 'location', 'status', 'is_forward', 'delivery_date',
    ];

    protected function casts(): array
    {
        return [
            'quantity'       => 'decimal:2',
            'price_per_unit' => 'decimal:4',
            'is_forward'     => 'boolean',
            'delivery_date'  => 'date',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function orders(): HasMany
    {
        return $this->hasMany(AgroOrder::class);
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }
}
