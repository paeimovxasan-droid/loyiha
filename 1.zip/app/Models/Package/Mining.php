<?php

namespace App\Models\Package;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Mining extends Model
{
    protected $fillable = [
        'user_id', 'package_id', 'purchase_id',
        'started_at', 'ended_at',
        'total_hours', 'completed_hours',
        'hourly_profit', 'daily_profit', 'total_earned',
        'status',
    ];

    protected function casts(): array
    {
        return [
            'started_at'      => 'datetime',
            'ended_at'        => 'datetime',
            'hourly_profit'   => 'decimal:4',
            'daily_profit'    => 'decimal:2',
            'total_earned'    => 'decimal:2',
        ];
    }

    public function scopeRunning($query) { return $query->where('status', 'running'); }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function package(): BelongsTo { return $this->belongsTo(Package::class); }
    public function purchase(): BelongsTo { return $this->belongsTo(Purchase::class); }

    public function isRunning(): bool { return $this->status === 'running'; }

    /**
     * Tugallangan foiz (progress bar uchun)
     */
    public function getProgressPercent(): float
    {
        if ($this->total_hours === 0) return 0;
        return round(($this->completed_hours / $this->total_hours) * 100, 1);
    }
}
