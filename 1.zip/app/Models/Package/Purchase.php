<?php

namespace App\Models\Package;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Purchase extends Model
{
    protected $fillable = [
        'user_id', 'package_id', 'amount',
        'started_at', 'expires_at', 'note', 'status',
    ];

    protected function casts(): array
    {
        return [
            'amount'     => 'decimal:2',
            'started_at' => 'date',
            'expires_at' => 'date',
        ];
    }

    public function scopeActive($query) { return $query->where('status', 'active'); }
    public function scopePending($query) { return $query->where('status', 'pending'); }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function package(): BelongsTo { return $this->belongsTo(Package::class); }
    public function mining(): HasOne { return $this->hasOne(Mining::class); }

    public function isActive(): bool { return $this->status === 'active'; }
    public function isExpired(): bool { return $this->status === 'expired'; }
}
