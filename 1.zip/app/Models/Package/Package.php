<?php

namespace App\Models\Package;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Translatable\HasTranslations;
use Illuminate\Support\Str;

class Package extends Model
{
    use HasTranslations;

    protected $fillable = [
        'name', 'photo_id', 'price', 'code', 'validity_days',
        'daily_profit_percent', 'total_profit_percent', 'sponsor_income',
        'ref_level1', 'ref_level2', 'ref_level3',
        'is_default', 'status', 'sort_order',
    ];

    public array $translatable = ['name'];

    protected function casts(): array
    {
        return [
            'price'                => 'decimal:2',
            'daily_profit_percent' => 'decimal:2',
            'total_profit_percent' => 'decimal:2',
            'sponsor_income'       => 'decimal:2',
            'ref_level1'           => 'decimal:2',
            'ref_level2'           => 'decimal:2',
            'ref_level3'           => 'decimal:2',
            'is_default'           => 'boolean',
            'validity_days'        => 'integer',
        ];
    }

    protected static function boot(): void
    {
        parent::boot();
        static::creating(fn($m) => $m->code ??= (string) Str::uuid());
    }

    public function scopeActive($query) { return $query->where('status', 'active')->orderBy('sort_order'); }

    public function purchases(): HasMany { return $this->hasMany(Purchase::class); }
    public function minings(): HasMany { return $this->hasMany(Mining::class); }

    public function photoFile()
    {
        return $this->belongsTo(\App\Models\File::class, 'photo_id');
    }

    public function getPhotoUrlAttribute(): string
    {
        return $this->photoFile ? $this->photoFile->url : asset('images/package-default.png');
    }

    /**
     * Kunlik foydani hisoblash
     */
    public function calcDailyProfit(float $investedAmount): float
    {
        return round($investedAmount * $this->daily_profit_percent / 100, 2);
    }

    /**
     * Umumiy foydani hisoblash
     */
    public function calcTotalProfit(float $investedAmount): float
    {
        return round($investedAmount * $this->total_profit_percent / 100, 2);
    }
}
