<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;
use Spatie\Translatable\HasTranslations;
use App\Models\File;

class Setting extends Model
{
    use HasTranslations;

    protected $fillable = [
        'logo_id', 'favicon_id',
        'site_name', 'site_title', 'site_description',
        'contact_phone', 'contact_email',
        'telegram', 'instagram', 'facebook', 'youtube',
        'min_deposit', 'max_deposit',
        'min_withdraw', 'max_withdraw',
        'currency',
        'site_currency', 'ais_to_uzs_rate',
        'transfer_fee_percent', 'conversion_fee_percent',
        'withdrawal_fee_percent',
        'lucky_draw_rake_percent',
        'require_first_deposit', 'first_deposit_min_amount',
        'vip_silver_price', 'vip_gold_price', 'vip_platinum_price',
        'site_domain',
        'telegram_bot_token', 'telegram_bot_username',
        'telegram_channel_id', 'telegram_miniapp_url',
        'telegram_auto_posts_enabled', 'telegram_webhook_secret',
        'marketplace_commission_rate',
    ];

    public array $translatable = ['site_name', 'site_title', 'site_description'];

    protected function casts(): array
    {
        return [
            'min_deposit'              => 'decimal:2',
            'max_deposit'              => 'decimal:2',
            'min_withdraw'             => 'decimal:2',
            'max_withdraw'             => 'decimal:2',
            'withdrawal_fee_percent'   => 'decimal:2',
            'lucky_draw_rake_percent'  => 'decimal:2',
            'require_first_deposit'    => 'boolean',
            'first_deposit_min_amount' => 'decimal:2',
            'vip_silver_price'         => 'decimal:2',
            'vip_gold_price'           => 'decimal:2',
            'vip_platinum_price'       => 'decimal:2',
        ];
    }

    /**
     * Sozlama o'zgarganda keshni tozalash
     */
    protected static function booted(): void
    {
        static::saved(function () {
            Cache::forget('app_settings');
        });

        static::deleted(function () {
            Cache::forget('app_settings');
        });
    }

    /**
     * Sozlamalarni olish — 1 soat kesh bilan
     * Avval har so'rovda DB query bo'lardi
     */
    public static function get(): static
    {
        return Cache::remember('app_settings', now()->addHour(), function () {
            return static::firstOrCreate([], [
                'site_name'    => ['uz' => 'AISOQQA', 'ru' => 'AISOQQA', 'en' => 'AISOQQA'],
                'currency'     => 'UZS',
                'site_currency'=> 'AIS',
                'min_deposit'  => 10000,
                'max_deposit'  => 50000000,
                'min_withdraw' => 20000,
                'max_withdraw' => 10000000,
            ]);
        });
    }

    /**
     * Keshni qo'lda tozalash (admin sozlamalarni yangilaganda)
     */
    public static function clearCache(): void
    {
        Cache::forget('app_settings');
    }

    public function logoFile()
    {
        return $this->belongsTo(File::class, 'logo_id');
    }

    public function faviconFile()
    {
        return $this->belongsTo(File::class, 'favicon_id');
    }

    public function getLogoUrlAttribute(): string
    {
        return $this->logoFile ? $this->logoFile->url : asset('images/logo.svg');
    }

    public function getFaviconUrlAttribute(): string
    {
        return $this->faviconFile ? $this->faviconFile->url : asset('images/favicon.svg');
    }
}
