<?php

namespace App\Models\Support;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class SupportTicket extends Model
{
    protected $fillable = [
        'ticket_number', 'user_id', 'assigned_to',
        'subject', 'category', 'priority', 'status',
        'last_reply_at', 'closed_at',
    ];

    protected function casts(): array
    {
        return [
            'last_reply_at' => 'datetime',
            'closed_at'     => 'datetime',
            'is_read'       => 'boolean',
        ];
    }

    // ─── Constants ────────────────────────────────────────────────────────────

    const CATEGORIES = [
        'general'    => 'Umumiy savol',
        'deposit'    => 'Depozit muammosi',
        'withdrawal' => 'Yechim muammosi',
        'technical'  => 'Texnik muammo',
        'kyc'        => 'KYC muammosi',
        'account'    => 'Hisob muammosi',
        'investment' => 'Investitsiya',
        'other'      => 'Boshqa',
    ];

    const PRIORITIES = [
        'low'    => ['label' => 'Past',     'color' => '#64748b'],
        'medium' => ['label' => 'O\'rta',   'color' => '#f59e0b'],
        'high'   => ['label' => 'Yuqori',   'color' => '#f97316'],
        'urgent' => ['label' => 'Shoshilinch', 'color' => '#ef4444'],
    ];

    const STATUSES = [
        'open'        => ['label' => 'Yangi',          'color' => 'bg-primary/10 text-primary'],
        'in_progress' => ['label' => 'Ko\'rib chiqilmoqda', 'color' => 'bg-warning/10 text-warning'],
        'answered'    => ['label' => 'Javob berildi',  'color' => 'bg-success/10 text-success'],
        'closed'      => ['label' => 'Yopildi',        'color' => 'bg-slate-200 text-slate-500'],
        'reopened'    => ['label' => 'Qayta ochildi',  'color' => 'bg-error/10 text-error'],
    ];

    // ─── Relations ────────────────────────────────────────────────────────────

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function assignedTo(): BelongsTo
    {
        return $this->belongsTo(User::class, 'assigned_to');
    }

    public function messages(): HasMany
    {
        return $this->hasMany(SupportTicketMessage::class, 'ticket_id')->orderBy('created_at');
    }

    public function lastMessage()
    {
        return $this->hasOne(SupportTicketMessage::class, 'ticket_id')->latestOfMany();
    }

    // ─── Scopes ───────────────────────────────────────────────────────────────

    public function scopeOpen($query)
    {
        return $query->whereIn('status', ['open', 'reopened']);
    }

    public function scopeActive($query)
    {
        return $query->whereNotIn('status', ['closed']);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    public static function generateNumber(): string
    {
        $year  = now()->year;
        $count = static::whereYear('created_at', $year)->count() + 1;
        return 'TKT-' . $year . '-' . str_pad($count, 6, '0', STR_PAD_LEFT);
    }

    public function getStatusBadgeAttribute(): string
    {
        $s = self::STATUSES[$this->status] ?? ['label' => $this->status, 'color' => 'bg-slate-200 text-slate-500'];
        return '<span class="badge ' . e($s['color']) . '">' . e($s['label']) . '</span>';
    }

    public function getPriorityLabelAttribute(): string
    {
        return self::PRIORITIES[$this->priority]['label'] ?? $this->priority;
    }

    public function getPriorityColorAttribute(): string
    {
        return self::PRIORITIES[$this->priority]['color'] ?? '#64748b';
    }

    public function getCategoryLabelAttribute(): string
    {
        return self::CATEGORIES[$this->category] ?? $this->category;
    }

    public function isOpen(): bool
    {
        return in_array($this->status, ['open', 'reopened', 'in_progress']);
    }

    public function isClosed(): bool
    {
        return $this->status === 'closed';
    }

    public function getUnreadCountForAdmin(): int
    {
        return $this->messages()->where('is_admin_reply', false)->where('is_read', false)->count();
    }
}
