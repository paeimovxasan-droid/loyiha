<?php

namespace App\Models\Marketing;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ShareClick extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'share_link_id', 'ip_address', 'user_agent', 'clicked_at', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'clicked_at' => 'datetime',
            'created_at' => 'datetime',
        ];
    }

    public function shareLink(): BelongsTo
    {
        return $this->belongsTo(ShareLink::class);
    }
}
