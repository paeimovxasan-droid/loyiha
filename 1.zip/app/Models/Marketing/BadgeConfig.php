<?php

namespace App\Models\Marketing;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Translatable\HasTranslations;

class BadgeConfig extends Model
{
    use HasTranslations;

    protected $fillable = [
        'type', 'required_streak', 'reward_ais', 'name', 'icon', 'color',
    ];

    public array $translatable = ['name'];

    protected function casts(): array
    {
        return [
            'required_streak' => 'integer',
            'reward_ais'      => 'decimal:4',
        ];
    }

    public function userBadges(): HasMany
    {
        return $this->hasMany(UserBadge::class);
    }
}
