<?php

namespace App\Models\Marketing;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PromoCode extends Model
{
    protected $fillable = [
        'code', 'reward_ais', 'reward_xp', 'max_uses', 'used_count',
        'starts_at', 'expires_at', 'new_users_only', 'new_user_hours', 'status',
    ];

    protected function casts(): array
    {
        return [
            'reward_ais'     => 'decimal:4',
            'reward_xp'      => 'integer',
            'max_uses'        => 'integer',
            'used_count'      => 'integer',
            'starts_at'       => 'datetime',
            'expires_at'      => 'datetime',
            'new_users_only'  => 'boolean',
            'new_user_hours'  => 'integer',
        ];
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeValid($query)
    {
        return $query->active()
            ->where(fn ($q) => $q->whereNull('starts_at')->orWhere('starts_at', '<=', now()))
            ->where(fn ($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now()))
            ->where(fn ($q) => $q->whereNull('max_uses')->orWhereColumn('used_count', '<', 'max_uses'));
    }

    public function uses(): HasMany
    {
        return $this->hasMany(PromoCodeUse::class);
    }
}
