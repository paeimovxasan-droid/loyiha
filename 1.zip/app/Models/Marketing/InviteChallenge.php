<?php

namespace App\Models\Marketing;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class InviteChallenge extends Model
{
    protected $fillable = [
        'user_id', 'target_referrals', 'current_referrals', 'reward_ais',
        'starts_at', 'ends_at', 'status', 'completed_at',
    ];

    protected function casts(): array
    {
        return [
            'target_referrals'  => 'integer',
            'current_referrals' => 'integer',
            'reward_ais'        => 'decimal:4',
            'starts_at'         => 'datetime',
            'ends_at'           => 'datetime',
            'completed_at'      => 'datetime',
        ];
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeExpired($query)
    {
        return $query->where('status', 'active')
            ->where('ends_at', '<', now());
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
