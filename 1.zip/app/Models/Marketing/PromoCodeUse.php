<?php

namespace App\Models\Marketing;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PromoCodeUse extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'promo_code_id', 'user_id', 'reward_ais', 'reward_xp', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'reward_ais' => 'decimal:4',
            'reward_xp'  => 'integer',
            'created_at' => 'datetime',
        ];
    }

    public function promoCode(): BelongsTo
    {
        return $this->belongsTo(PromoCode::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
