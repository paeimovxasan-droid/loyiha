<?php

namespace App\Models\Marketing;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserOnboarding extends Model
{
    protected $fillable = [
        'user_id', 'current_step',
        'step_1_completed', 'step_1_completed_at',
        'step_2_completed', 'step_2_completed_at',
        'step_3_completed', 'step_3_completed_at',
        'step_4_completed', 'step_4_completed_at',
        'step_5_completed', 'step_5_completed_at',
        'bonus_claimed', 'completed_at',
    ];

    protected function casts(): array
    {
        return [
            'current_step'       => 'integer',
            'step_1_completed'   => 'boolean',
            'step_1_completed_at' => 'datetime',
            'step_2_completed'   => 'boolean',
            'step_2_completed_at' => 'datetime',
            'step_3_completed'   => 'boolean',
            'step_3_completed_at' => 'datetime',
            'step_4_completed'   => 'boolean',
            'step_4_completed_at' => 'datetime',
            'step_5_completed'   => 'boolean',
            'step_5_completed_at' => 'datetime',
            'bonus_claimed'      => 'boolean',
            'completed_at'       => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
