<?php

namespace App\Models\Marketing;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LeaderboardEntry extends Model
{
    protected $fillable = [
        'competition_id', 'user_id', 'score', 'rank', 'prize_ais',
    ];

    protected function casts(): array
    {
        return [
            'score'     => 'decimal:4',
            'rank'      => 'integer',
            'prize_ais' => 'decimal:4',
        ];
    }

    public function competition(): BelongsTo
    {
        return $this->belongsTo(LeaderboardCompetition::class, 'competition_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
