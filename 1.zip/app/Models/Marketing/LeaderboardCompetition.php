<?php

namespace App\Models\Marketing;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class LeaderboardCompetition extends Model
{
    protected $fillable = [
        'period', 'type', 'starts_at', 'ends_at', 'status', 'prizes',
    ];

    protected function casts(): array
    {
        return [
            'starts_at' => 'datetime',
            'ends_at'   => 'datetime',
            'prizes'    => 'array',
        ];
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeWeekly($query)
    {
        return $query->where('period', 'weekly');
    }

    public function scopeMonthly($query)
    {
        return $query->where('period', 'monthly');
    }

    public function entries(): HasMany
    {
        return $this->hasMany(LeaderboardEntry::class, 'competition_id');
    }
}
