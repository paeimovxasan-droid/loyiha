<?php

namespace App\Models\Marketing;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SpinWheelLog extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'user_id', 'spin_wheel_prize_id', 'prize_type', 'prize_value', 'spun_at', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'prize_value' => 'decimal:4',
            'spun_at'     => 'date',
            'created_at'  => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function prize(): BelongsTo
    {
        return $this->belongsTo(SpinWheelPrize::class, 'spin_wheel_prize_id');
    }
}
