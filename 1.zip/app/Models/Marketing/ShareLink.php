<?php

namespace App\Models\Marketing;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ShareLink extends Model
{
    protected $fillable = [
        'user_id', 'code', 'total_clicks', 'total_earned_ais',
    ];

    protected function casts(): array
    {
        return [
            'total_clicks'     => 'integer',
            'total_earned_ais' => 'decimal:4',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function clicks(): HasMany
    {
        return $this->hasMany(ShareClick::class);
    }
}
