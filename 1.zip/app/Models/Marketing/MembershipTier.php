<?php

namespace App\Models\Marketing;

use Illuminate\Database\Eloquent\Model;

class MembershipTier extends Model
{
    protected $fillable = [
        'tier', 'min_ais_earned', 'min_referrals',
        'cashback_percent', 'fee_discount_percent',
        'has_special_quests', 'has_personal_manager',
    ];

    protected function casts(): array
    {
        return [
            'min_ais_earned'       => 'decimal:4',
            'min_referrals'        => 'integer',
            'cashback_percent'     => 'decimal:2',
            'fee_discount_percent' => 'decimal:2',
            'has_special_quests'   => 'boolean',
            'has_personal_manager' => 'boolean',
        ];
    }
}
