<?php

namespace App\Models\Marketing;

use Illuminate\Database\Eloquent\Model;

class InviteChallengeSettings extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'duration_days', 'target_referrals', 'reward_ais', 'min_deposit_required', 'updated_at',
    ];

    protected function casts(): array
    {
        return [
            'duration_days'        => 'integer',
            'target_referrals'     => 'integer',
            'reward_ais'           => 'decimal:4',
            'min_deposit_required' => 'boolean',
            'updated_at'           => 'datetime',
        ];
    }

    /** Singleton pattern — bitta yozuvni olish yoki yaratish */
    public static function instance(): static
    {
        return static::firstOrCreate([], [
            'duration_days'        => 7,
            'target_referrals'     => 7,
            'reward_ais'           => 100,
            'min_deposit_required' => true,
        ]);
    }
}
