<?php

namespace App\Models\Marketing;

use App\Models\Game\Quest;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Spatie\Translatable\HasTranslations;

class SeasonalEvent extends Model
{
    use HasTranslations;

    protected $fillable = [
        'name', 'description', 'banner', 'starts_at', 'ends_at', 'prizes', 'status',
    ];

    public array $translatable = ['name', 'description'];

    protected function casts(): array
    {
        return [
            'starts_at' => 'datetime',
            'ends_at'   => 'datetime',
            'prizes'    => 'array',
        ];
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active')
            ->where('starts_at', '<=', now())
            ->where('ends_at', '>=', now());
    }

    public function quests(): BelongsToMany
    {
        return $this->belongsToMany(Quest::class, 'seasonal_event_quests', 'event_id', 'quest_id')
            ->withPivot('sort_order')
            ->orderByPivot('sort_order');
    }
}
