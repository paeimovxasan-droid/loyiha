<?php

namespace App\Models\Marketing;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserMembership extends Model
{
    protected $fillable = [
        'user_id', 'tier', 'total_ais_earned', 'total_referrals',
        'upgraded_at', 'grace_until',
    ];

    protected function casts(): array
    {
        return [
            'total_ais_earned' => 'decimal:4',
            'total_referrals'  => 'integer',
            'upgraded_at'      => 'datetime',
            'grace_until'      => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function tierConfig(): BelongsTo
    {
        return $this->belongsTo(MembershipTier::class, 'tier', 'tier');
    }
}
