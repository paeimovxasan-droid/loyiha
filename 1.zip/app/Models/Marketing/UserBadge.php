<?php

namespace App\Models\Marketing;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserBadge extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'user_id', 'badge_config_id', 'awarded_at', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'awarded_at'  => 'datetime',
            'created_at'  => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function badgeConfig(): BelongsTo
    {
        return $this->belongsTo(BadgeConfig::class);
    }
}
