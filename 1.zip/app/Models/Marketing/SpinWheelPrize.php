<?php

namespace App\Models\Marketing;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Translatable\HasTranslations;

class SpinWheelPrize extends Model
{
    use HasTranslations;

    protected $fillable = [
        'type', 'value', 'label', 'weight', 'color', 'status',
    ];

    public array $translatable = ['label'];

    protected function casts(): array
    {
        return [
            'value'  => 'decimal:4',
            'weight' => 'integer',
        ];
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function logs(): HasMany
    {
        return $this->hasMany(SpinWheelLog::class);
    }
}
