<?php

namespace App\Models\Marketing;

use App\Models\Game\Quest;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SeasonalEventQuest extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'event_id', 'quest_id', 'sort_order', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'sort_order'  => 'integer',
            'created_at'  => 'datetime',
        ];
    }

    public function event(): BelongsTo
    {
        return $this->belongsTo(SeasonalEvent::class, 'event_id');
    }

    public function quest(): BelongsTo
    {
        return $this->belongsTo(Quest::class);
    }
}
