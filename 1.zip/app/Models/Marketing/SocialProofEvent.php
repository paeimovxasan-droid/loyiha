<?php

namespace App\Models\Marketing;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class SocialProofEvent extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'type', 'user_id', 'masked_name', 'amount', 'metadata', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'amount'     => 'decimal:4',
            'metadata'   => 'array',
            'created_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
