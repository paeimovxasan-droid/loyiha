<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

/**
 * UI tarjimalari: buttonlar, labellar, xatolik xabarlari va boshqalar.
 *
 * Guruhlar (group):
 *   auth        → Kirish, Ro'yxatdan o'tish, Parol...
 *   buttons     → Saqlash, Bekor qilish, Yuborish...
 *   navigation  → Bosh sahifa, Profil, Panel...
 *   validation  → Maydon to'ldirilishi shart, Minimum N ta belgi...
 *   errors      → 404, 500, Ruxsat yo'q...
 *   messages    → Muvaffaqiyatli saqlandi, Xatolik yuz berdi...
 *   dashboard   → Panel, Balans, Daromad...
 *   payment     → To'lov, Depozit, Yechib olish...
 *   package     → Paket, Tarif, Muddati...
 *   profile     → Profil, Sozlamalar, Chiqish...
 *   common      → Ha, Yo'q, Barchasi, Holat...
 */
class LanguageLine extends Model
{
    use HasTranslations;

    protected $table = 'language_lines';

    protected $fillable = ['group', 'key', 'text'];

    public array $translatable = ['text'];

    // ─── Static helper ─────────────────────────────────────────────────────────

    /**
     * Tarjimani olish. Topilmasa keyni qaytaradi.
     * Ishlatish: LanguageLine::t('buttons', 'save')
     */
    public static function t(string $group, string $key, ?string $locale = null): string
    {
        $locale ??= app()->getLocale();

        $line = static::where('group', $group)->where('key', $key)->first();

        if (! $line) {
            return "$group.$key";
        }

        return $line->getTranslation('text', $locale, false) ?: "$group.$key";
    }

    /**
     * Guruh bo'yicha barcha tarjimalarni array qaytaradi.
     * Ishlatish: LanguageLine::group('buttons')
     */
    public static function group(string $group, ?string $locale = null): array
    {
        $locale ??= app()->getLocale();

        return static::where('group', $group)
            ->get()
            ->mapWithKeys(fn($line) => [
                $line->key => $line->getTranslation('text', $locale, false) ?: "$group.{$line->key}",
            ])
            ->toArray();
    }
}
