<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserStats extends Model
{
    protected $fillable = [
        'user_id',
        'total_earn_ais',
        'total_deposit_uzs',
        'referrals_count',
        'last_calculated_at',
    ];

    protected $casts = [
        'last_calculated_at' => 'datetime',
        'total_earn_ais'     => 'float',
        'total_deposit_uzs'  => 'float',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
