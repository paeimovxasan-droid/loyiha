<?php

namespace App\Models\Content;

use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class PageSection extends Model
{
    use HasTranslations;

    protected $fillable = [
        'section_key', 'page',
        'title', 'subtitle', 'content',
        'image', 'button_text', 'button_link',
        'extra_data', 'sort_order', 'status',
    ];

    public array $translatable = ['title', 'subtitle', 'content', 'button_text'];

    protected function casts(): array
    {
        return ['extra_data' => 'array'];
    }

    public function scopeActive($query) { return $query->where('status', 'active'); }

    public static function getSection(string $key, string $page = 'home'): ?static
    {
        return static::where('section_key', $key)->where('page', $page)->first();
    }

    public function getImageUrlAttribute(): ?string
    {
        return $this->image ? asset('storage/' . $this->image) : null;
    }
}
