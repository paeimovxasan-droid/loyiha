<?php

namespace App\Models\Content;

use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Notice extends Model
{
    use HasTranslations;

    protected $fillable = [
        'title', 'content', 'type',
        'is_popup', 'published_at', 'expires_at', 'status',
    ];

    public array $translatable = ['title', 'content'];

    protected function casts(): array
    {
        return [
            'is_popup'     => 'boolean',
            'published_at' => 'datetime',
            'expires_at'   => 'datetime',
        ];
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active')
            ->where(fn($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now()))
            ->latest();
    }

    public function scopePopup($query) { return $query->where('is_popup', true); }
}
