<?php

namespace App\Models\Content;

use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Slider extends Model
{
    use HasTranslations;

    protected $fillable = ['title', 'subtitle', 'image', 'link', 'position', 'sort_order', 'status'];

    public array $translatable = ['title', 'subtitle'];

    public function scopeActive($query) { return $query->where('status', 'active')->orderBy('sort_order'); }
    public function scopePosition($query, string $pos) { return $query->where('position', $pos); }

    public function getImageUrlAttribute(): string { return asset('storage/' . $this->image); }
}
