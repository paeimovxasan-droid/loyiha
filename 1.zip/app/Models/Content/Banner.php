<?php

namespace App\Models\Content;

use Illuminate\Database\Eloquent\Model;

class Banner extends Model
{
    protected $fillable = ['image', 'link', 'position', 'sort_order', 'status'];

    public function scopeActive($query) { return $query->where('status', 'active')->orderBy('sort_order'); }
    public function scopePosition($query, string $pos) { return $query->where('position', $pos); }

    public function getImageUrlAttribute(): string
    {
        return asset('storage/' . $this->image);
    }
}
