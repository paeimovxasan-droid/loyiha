<?php

namespace App\Models\Content;

use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Faq extends Model
{
    use HasTranslations;

    protected $fillable = ['question', 'answer', 'category', 'sort_order', 'status'];

    public array $translatable = ['question', 'answer'];

    public function scopeActive($query) { return $query->where('status', 'active')->orderBy('sort_order'); }
    public function scopeCategory($query, string $cat) { return $query->where('category', $cat); }
}
