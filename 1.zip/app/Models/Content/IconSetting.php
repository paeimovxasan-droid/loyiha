<?php

namespace App\Models\Content;

use Illuminate\Database\Eloquent\Model;

class IconSetting extends Model
{
    protected $fillable = ['key', 'icon_path', 'label', 'meta'];

    protected function casts(): array
    {
        return ['meta' => 'array'];
    }

    public static function getIcon(string $key): ?string
    {
        return static::where('key', $key)->value('icon_path');
    }
}
