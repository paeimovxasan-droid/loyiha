<?php

namespace App\Models\Savings;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class SavingGroupRound extends Model
{
    protected $fillable = [
        'saving_group_id', 'recipient_id', 'round_number',
        'total_collected', 'status', 'completed_at',
    ];

    protected function casts(): array
    {
        return [
            'total_collected' => 'decimal:2',
            'completed_at'    => 'datetime',
        ];
    }

    public function group(): BelongsTo
    {
        return $this->belongsTo(SavingGroup::class, 'saving_group_id');
    }

    public function recipient(): BelongsTo
    {
        return $this->belongsTo(User::class, 'recipient_id');
    }

    public function transactions(): MorphMany
    {
        return $this->morphMany(\App\Models\Finance\Transaction::class, 'transactionable');
    }
}
