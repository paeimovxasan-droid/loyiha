<?php

namespace App\Models\Savings;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class SavingsPlan extends Model
{
    protected $fillable = [
        'user_id', 'term_months', 'monthly_amount', 'currency',
        'bonus_rate', 'total_saved', 'paid_months', 'status', 'next_payment_date',
    ];

    protected function casts(): array
    {
        return [
            'monthly_amount'    => 'decimal:2',
            'bonus_rate'        => 'decimal:2',
            'total_saved'       => 'decimal:2',
            'next_payment_date' => 'date',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(SavingsPayment::class);
    }

    public function transactions(): MorphMany
    {
        return $this->morphMany(\App\Models\Finance\Transaction::class, 'transactionable');
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }

    public function isCompleted(): bool
    {
        return $this->paid_months >= $this->term_months;
    }
}
