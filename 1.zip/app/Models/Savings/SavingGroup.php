<?php

namespace App\Models\Savings;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;

class SavingGroup extends Model
{
    protected $fillable = [
        'admin_id', 'name', 'max_members', 'monthly_amount',
        'currency', 'current_round', 'status', 'started_at',
    ];

    protected function casts(): array
    {
        return [
            'monthly_amount' => 'decimal:2',
            'started_at'     => 'datetime',
        ];
    }

    public function admin(): BelongsTo
    {
        return $this->belongsTo(User::class, 'admin_id');
    }

    public function members(): HasMany
    {
        return $this->hasMany(SavingGroupMember::class);
    }

    public function activeMembers(): HasMany
    {
        return $this->hasMany(SavingGroupMember::class)->where('status', 'active');
    }

    public function rounds(): HasMany
    {
        return $this->hasMany(SavingGroupRound::class);
    }

    public function transactions(): MorphMany
    {
        return $this->morphMany(\App\Models\Finance\Transaction::class, 'transactionable');
    }

    public function isFull(): bool
    {
        return $this->activeMembers()->count() >= $this->max_members;
    }

    public function isActive(): bool
    {
        return $this->status === 'active';
    }
}
