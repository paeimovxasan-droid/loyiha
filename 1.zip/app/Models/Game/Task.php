<?php

namespace App\Models\Game;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Translatable\HasTranslations;

class Task extends Model
{
    use HasTranslations;

    protected $fillable = [
        'title', 'description', 'link', 'platform',
        'reward', 'required_package_level', 'status', 'sort_order',
    ];

    public array $translatable = ['title', 'description'];

    protected function casts(): array
    {
        return ['reward' => 'decimal:2'];
    }

    public function scopeActive($query) { return $query->where('status', 'active')->orderBy('sort_order'); }

    public function userTasks(): HasMany { return $this->hasMany(UserTask::class); }
}
