<?php

namespace App\Models\Game;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Translatable\HasTranslations;

class LuckyDraw extends Model
{
    use HasTranslations;

    protected $fillable = [
        'name', 'entry_fee', 'prize_amount',
        'platform_rake_percent', 'winner_prize',
        'max_tickets', 'draw_at', 'status',
        'winner_id', 'drawn_at',
    ];

    public array $translatable = ['name'];

    protected function casts(): array
    {
        return [
            'entry_fee'             => 'decimal:2',
            'prize_amount'          => 'decimal:2',
            'platform_rake_percent' => 'decimal:2',
            'winner_prize'          => 'decimal:2',
            'draw_at'               => 'datetime',
            'drawn_at'              => 'datetime',
        ];
    }

    public function scopeActive($query) { return $query->where('status', 'active'); }

    public function tickets(): HasMany { return $this->hasMany(LuckyDrawTicket::class); }

    public function winner()
    {
        return $this->belongsTo(\App\Models\User::class, 'winner_id');
    }

    public function getTotalTicketsSold(): int
    {
        return $this->tickets()->sum('quantity');
    }

    /**
     * Jami yig'ilgan pul (tiket sotuvi)
     */
    public function getTotalCollectedAttribute(): float
    {
        return (float) $this->tickets()->sum('total_paid');
    }

    /**
     * Platforma daromadi (rake)
     */
    public function getPlatformEarningsAttribute(): float
    {
        return round($this->total_collected * $this->platform_rake_percent / 100, 2);
    }

    /**
     * G'olibga beriladigan summa
     */
    public function calcWinnerPrize(): float
    {
        $total = $this->total_collected;
        return round($total * (1 - $this->platform_rake_percent / 100), 2);
    }
}
