<?php

namespace App\Models\Game;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UserQuest extends Model
{
    protected $fillable = [
        'user_id', 'quest_id', 'progress', 'status',
        'completed_at', 'claimed_at',
    ];

    protected function casts(): array
    {
        return [
            'completed_at' => 'datetime',
            'claimed_at'   => 'datetime',
        ];
    }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function quest(): BelongsTo { return $this->belongsTo(Quest::class); }

    public function isCompleted(): bool { return in_array($this->status, ['completed', 'claimed']); }
    public function isClaimed(): bool   { return $this->status === 'claimed'; }
    public function isInProgress(): bool { return $this->status === 'in_progress'; }

    /** Progress foizi */
    public function getProgressPercentAttribute(): int
    {
        $required = $this->quest?->requirement_value ?? 1;
        return min(100, (int) round($this->progress / max(1, $required) * 100));
    }
}
