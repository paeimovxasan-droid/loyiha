<?php

namespace App\Models\Game;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LuckyDrawTicket extends Model
{
    protected $fillable = [
        'user_id', 'lucky_draw_id',
        'quantity', 'total_paid', 'is_winner', 'prize_won',
    ];

    protected function casts(): array
    {
        return [
            'total_paid' => 'decimal:2',
            'prize_won'  => 'decimal:2',
            'is_winner'  => 'boolean',
        ];
    }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function luckyDraw(): BelongsTo { return $this->belongsTo(LuckyDraw::class); }
}
