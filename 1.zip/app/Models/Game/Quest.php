<?php

namespace App\Models\Game;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Translatable\HasTranslations;

class Quest extends Model
{
    use HasTranslations;

    protected $fillable = [
        'title', 'description', 'icon', 'category', 'type',
        'requirement_type', 'requirement_value',
        'reward_ais', 'reward_uzs', 'reward_xp', 'reward_badge',
        'sort_order', 'min_level', 'status', 'expires_at',
    ];

    public array $translatable = ['title', 'description'];

    protected function casts(): array
    {
        return [
            'reward_ais'  => 'decimal:4',
            'reward_uzs'  => 'decimal:2',
            'reward_xp'   => 'integer',
            'expires_at'  => 'datetime',
        ];
    }

    // Requirement type konstantalari
    const REQ_DEPOSIT_COUNT   = 'deposit_count';
    const REQ_REFERRAL_COUNT  = 'referral_count';
    const REQ_PURCHASE_COUNT  = 'purchase_count';
    const REQ_CHECKIN_STREAK  = 'checkin_streak';
    const REQ_LEVEL_REACH     = 'level_reach';
    const REQ_TRANSFER_COUNT  = 'transfer_count';
    const REQ_TASK_COMPLETE   = 'task_complete';
    const REQ_FUND_INVEST     = 'fund_invest';
    const REQ_PROFILE_FILL    = 'profile_fill';
    const REQ_KYC_VERIFY      = 'kyc_verify';
    const REQ_LUCKY_DRAW      = 'lucky_draw';
    const REQ_TOTAL_DEPOSIT   = 'total_deposit';
    const REQ_SHARE_CLICKS    = 'share_clicks';
    const REQ_BADGE_EARNED    = 'badge_earned';
    const REQ_CHALLENGE_DONE  = 'challenge_done';
    const REQ_ONBOARDING_DONE = 'onboarding_done';
    const REQ_SPIN_WHEEL      = 'spin_wheel';
    const REQ_VIP_TIER        = 'vip_tier';

    public function scopeActive($query)
    {
        return $query->where('status', 'active')
            ->where(fn($q) => $q->whereNull('expires_at')->orWhere('expires_at', '>', now()))
            ->orderBy('sort_order');
    }

    public function userQuests(): HasMany
    {
        return $this->hasMany(UserQuest::class);
    }

    /** Mukofot matnini olish */
    public function getRewardTextAttribute(): string
    {
        $parts = [];
        if ($this->reward_ais > 0)  $parts[] = number_format($this->reward_ais, 2) . ' AIS';
        if ($this->reward_uzs > 0)  $parts[] = number_format($this->reward_uzs, 0) . ' UZS';
        if ($this->reward_xp > 0)   $parts[] = '+' . $this->reward_xp . ' XP';
        if ($this->reward_badge)     $parts[] = '🏅 ' . $this->reward_badge;
        return implode(' + ', $parts) ?: '—';
    }

    /** Kategoriya rangi */
    public function getCategoryColorAttribute(): string
    {
        return match($this->category) {
            'social'      => '#818cf8',
            'investment'  => '#34d399',
            'referral'    => '#fbbf24',
            'daily'       => '#f87171',
            'weekly'      => '#a855f7',
            default       => '#06b6d4',
        };
    }
}
