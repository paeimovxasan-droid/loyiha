<?php

namespace App\Models\Game;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CheckIn extends Model
{
    protected $fillable = ['user_id', 'checked_at', 'reward', 'streak'];

    protected function casts(): array
    {
        return [
            'checked_at' => 'date',
            'reward'     => 'decimal:2',
        ];
    }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }

    public static function todayFor(int $userId): ?static
    {
        return static::where('user_id', $userId)
            ->whereDate('checked_at', today())
            ->first();
    }
}
