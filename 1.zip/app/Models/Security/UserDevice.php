<?php

namespace App\Models\Security;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\User;

class UserDevice extends Model
{
    protected $table = 'user_devices';

    protected $fillable = [
        'user_id',
        'ip_address',
        'fingerprint_hash',
        'user_agent',
        'event_type',
    ];

    protected function casts(): array
    {
        return [
            'event_type' => 'string', // enum values: 'register', 'login'
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
