<?php

namespace App\Models\Security;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\User;

class BehavioralScoreLog extends Model
{
    protected $table = 'behavioral_score_logs';

    protected $fillable = [
        'user_id',
        'delta',
        'reason',
        'score_after',
    ];

    protected function casts(): array
    {
        return [
            'delta'       => 'integer',
            'score_after' => 'integer',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
