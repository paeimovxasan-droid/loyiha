<?php

namespace App\Models\Security;

use Illuminate\Database\Eloquent\Model;

class IpCheck extends Model
{
    protected $table = 'ip_checks';

    protected $fillable = [
        'ip_address',
        'is_vpn',
        'is_proxy',
        'country',
        'source',
        'raw_response',
        'checked_at',
        'expires_at',
    ];

    protected function casts(): array
    {
        return [
            'raw_response' => 'array',
            'is_vpn'       => 'boolean',
            'is_proxy'     => 'boolean',
            'checked_at'   => 'datetime',
            'expires_at'   => 'datetime',
        ];
    }

    public function isExpired(): bool
    {
        return $this->expires_at->isPast();
    }
}
