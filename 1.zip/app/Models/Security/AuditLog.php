<?php

namespace App\Models\Security;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class AuditLog extends Model
{
    protected $fillable = [
        'user_id',
        'action',
        'target_id',
        'target_type',
        'payload',
        'ip_address',
        'user_agent',
    ];

    protected $casts = [
        'payload' => 'array',
    ];

    /**
     * Amalni bajargan foydalanuvchi
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Ta'sir qilingan obyekt (Polymorphic)
     */
    public function target(): MorphTo
    {
        return $this->morphTo();
    }

    /**
     * Yangi audit log yozish
     */
    public static function log(string $action, $target = null, array $payload = []): self
    {
        return self::create([
            'user_id'     => auth()->id(),
            'action'      => $action,
            'target_id'   => $target?->id ?? null,
            'target_type' => $target ? (is_string($target) ? $target : get_class($target)) : null,
            'payload'     => $payload,
            'ip_address'  => request()->ip(),
            'user_agent'  => request()->userAgent(),
        ]);
    }

    /**
     * Xavfsizlik bo'yicha muhim amallar (Financial and Security Audit)
     */
    public static function critical(string $action, $target = null, array $payload = []): self
    {
        // Muhim amallar uchun doim log yozish (hatto auth bo'lmasa ham - masalan Login harakati)
        return self::log($action, $target, array_merge($payload, [
            '_severity' => 'critical',
            '_timestamp' => now()->toDateTimeString(),
        ]));
    }

    /**
     * Append-only: AuditLog yozuvlarini o'zgartirish va o'chirishni taqiqlash
     */
    protected static function boot(): void
    {
        parent::boot();

        static::updating(function () {
            throw new \RuntimeException('AuditLog yozuvlarini o\'zgartirish taqiqlangan (append-only).');
        });

        static::deleting(function () {
            throw new \RuntimeException('AuditLog yozuvlarini o\'chirish taqiqlangan (append-only).');
        });
    }
}
