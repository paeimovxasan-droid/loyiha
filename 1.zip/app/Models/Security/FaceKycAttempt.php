<?php

namespace App\Models\Security;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FaceKycAttempt extends Model
{
    protected $fillable = [
        'user_id',
        'session_id',
        'challenge',
        'status',           // pending | submitted | approved | rejected | expired | failed
        'selfie_path',
        'doc_front_path',
        'doc_back_path',
        'document_type',    // passport | id_card
        'liveness_score',
        'fail_reason',
        'submitted_at',
        'expires_at',
        'reviewed_by',
        'reviewed_at',
    ];

    protected function casts(): array
    {
        return [
            'challenge'      => 'array',
            'liveness_score' => 'float',
            'submitted_at'   => 'datetime',
            'expires_at'     => 'datetime',
            'reviewed_at'    => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function reviewer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'reviewed_by');
    }

    public function isPending(): bool   { return $this->status === 'pending'; }
    public function isSubmitted(): bool { return $this->status === 'submitted'; }
    public function isApproved(): bool  { return $this->status === 'approved'; }
    public function isRejected(): bool  { return $this->status === 'rejected'; }
    public function isExpired(): bool   { return $this->status === 'expired'; }
}
