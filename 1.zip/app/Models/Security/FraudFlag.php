<?php

namespace App\Models\Security;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use App\Models\User;

class FraudFlag extends Model
{
    protected $table = 'fraud_flags';

    protected $fillable = [
        'user_id',
        'reason',
        'flagged_by',
        'admin_id',
        'resolved_at',
        'resolved_by',
    ];

    protected function casts(): array
    {
        return [
            'resolved_at' => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function admin(): BelongsTo
    {
        return $this->belongsTo(User::class, 'admin_id');
    }

    public function isResolved(): bool
    {
        return $this->resolved_at !== null;
    }
}
