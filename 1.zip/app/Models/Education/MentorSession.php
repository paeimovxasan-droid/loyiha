<?php

namespace App\Models\Education;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MentorSession extends Model
{
    protected $fillable = [
        'mentor_profile_id', 'student_id', 'hours',
        'total_amount', 'mentor_share', 'platform_fee',
        'message', 'status',
    ];

    protected function casts(): array
    {
        return [
            'hours'        => 'integer',
            'total_amount' => 'decimal:4',
            'mentor_share' => 'decimal:4',
            'platform_fee' => 'decimal:4',
        ];
    }

    // ─── Relations ─────────────────────────────────────────────

    public function mentorProfile(): BelongsTo
    {
        return $this->belongsTo(MentorProfile::class);
    }

    public function student(): BelongsTo
    {
        return $this->belongsTo(User::class, 'student_id');
    }
}
