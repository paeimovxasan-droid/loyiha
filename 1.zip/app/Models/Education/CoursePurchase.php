<?php

namespace App\Models\Education;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class CoursePurchase extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'user_id', 'course_id', 'amount',
        'instructor_share', 'platform_fee', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'amount'           => 'decimal:4',
            'instructor_share' => 'decimal:4',
            'platform_fee'     => 'decimal:4',
            'created_at'       => 'datetime',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function course(): BelongsTo
    {
        return $this->belongsTo(Course::class);
    }
}
