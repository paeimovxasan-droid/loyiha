<?php

namespace App\Models\Catalog;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Shop extends Model
{
    const STATUS_ACTIVE = 'active';
    const STATUS_PAUSED = 'paused';

    protected $fillable = [
        'user_id', 'name', 'description', 'category',
        'address', 'phone', 'image', 'cashback_percent',
        'avg_rating', 'total_reviews', 'status',
    ];

    protected function casts(): array
    {
        return [
            'cashback_percent' => 'decimal:1',
            'avg_rating'       => 'decimal:2',
            'total_reviews'    => 'integer',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function products(): HasMany
    {
        return $this->hasMany(Product::class);
    }

    public function orders(): HasMany
    {
        return $this->hasMany(CatalogOrder::class);
    }

    public function reviews(): HasMany
    {
        return $this->hasMany(CatalogReview::class);
    }
}
