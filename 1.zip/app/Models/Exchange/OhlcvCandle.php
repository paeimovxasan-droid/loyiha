<?php

namespace App\Models\Exchange;

use Illuminate\Database\Eloquent\Model;

class OhlcvCandle extends Model
{
    protected $fillable = [
        'interval', 'open_time', 'open', 'high', 'low', 'close',
        'volume', 'volume_uzs', 'trade_count',
    ];

    protected function casts(): array
    {
        return [
            'open_time'  => 'datetime',
            'open'       => 'decimal:2',
            'high'       => 'decimal:2',
            'low'        => 'decimal:2',
            'close'      => 'decimal:2',
            'volume'     => 'decimal:4',
            'volume_uzs' => 'decimal:2',
        ];
    }
}
