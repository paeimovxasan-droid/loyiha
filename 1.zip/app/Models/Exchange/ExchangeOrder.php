<?php

namespace App\Models\Exchange;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class ExchangeOrder extends Model
{
    protected $fillable = [
        'user_id', 'reference', 'type', 'side', 'price', 'stop_price', 'amount',
        'filled_amount', 'remaining_amount', 'avg_fill_price',
        'total_fee', 'frozen_amount', 'status',
    ];

    protected function casts(): array
    {
        return [
            'price'            => 'decimal:2',
            'stop_price'       => 'decimal:2',
            'amount'           => 'decimal:4',
            'filled_amount'    => 'decimal:4',
            'remaining_amount' => 'decimal:4',
            'avg_fill_price'   => 'decimal:2',
            'total_fee'        => 'decimal:4',
            'frozen_amount'    => 'decimal:4',
        ];
    }

    // ─── Relations ─────────────────────────────────────────────────────

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function buyTrades(): HasMany
    {
        return $this->hasMany(ExchangeTrade::class, 'buy_order_id');
    }

    public function sellTrades(): HasMany
    {
        return $this->hasMany(ExchangeTrade::class, 'sell_order_id');
    }

    public function trades(): HasMany
    {
        return $this->side === 'buy'
            ? $this->buyTrades()
            : $this->sellTrades();
    }

    // ─── Scopes ────────────────────────────────────────────────────────

    public function scopeOpen($query)
    {
        return $query->where('status', 'open');
    }

    public function scopeActive($query)
    {
        return $query->whereIn('status', ['open', 'partially_filled']);
    }
}
