<?php

namespace App\Models\Exchange;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class ExchangeTrade extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'buy_order_id', 'sell_order_id', 'buyer_id', 'seller_id',
        'price', 'amount', 'total', 'buyer_fee', 'seller_fee',
        'buyer_role', 'seller_role', 'created_at',
    ];

    protected function casts(): array
    {
        return [
            'price'      => 'decimal:2',
            'amount'     => 'decimal:4',
            'total'      => 'decimal:2',
            'buyer_fee'  => 'decimal:4',
            'seller_fee' => 'decimal:4',
            'created_at' => 'datetime',
        ];
    }

    // ─── Relations ─────────────────────────────────────────────────────

    public function buyOrder(): BelongsTo
    {
        return $this->belongsTo(ExchangeOrder::class, 'buy_order_id');
    }

    public function sellOrder(): BelongsTo
    {
        return $this->belongsTo(ExchangeOrder::class, 'sell_order_id');
    }

    public function buyer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'buyer_id');
    }

    public function seller(): BelongsTo
    {
        return $this->belongsTo(User::class, 'seller_id');
    }
}
