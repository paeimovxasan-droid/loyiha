<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Oddiy PersonalAccessToken modeli — Sanctum o'rnatilmaguncha ishlaydi.
 */
class PersonalAccessToken extends Model
{
    protected $fillable = [
        'name', 'token', 'abilities', 'expires_at', 'last_used_at',
    ];

    protected $hidden = ['token'];

    protected function casts(): array
    {
        return [
            'abilities'    => 'array',
            'expires_at'   => 'datetime',
            'last_used_at' => 'datetime',
        ];
    }

    public function tokenable()
    {
        return $this->morphTo('tokenable');
    }

    /**
     * Token orqali foydalanuvchini topish
     */
    public static function findToken(string $token): ?static
    {
        if (str_contains($token, '|')) {
            [$id, $token] = explode('|', $token, 2);
            $instance = static::find($id);
            if ($instance && hash_equals($instance->token, hash('sha256', $token))) {
                return $instance;
            }
            return null;
        }

        return static::where('token', hash('sha256', $token))->first();
    }
}
