<?php

namespace App\Models\Medical;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class HomeVisit extends Model
{
    protected $fillable = [
        'patient_id', 'doctor_id', 'doctor_profile_id',
        'address', 'symptoms', 'price', 'escrow_amount',
        'commission_rate', 'commission_amount', 'doctor_earning',
        'status', 'accepted_at', 'completed_at', 'expires_at',
    ];

    protected function casts(): array
    {
        return [
            'price'             => 'decimal:4',
            'escrow_amount'     => 'decimal:4',
            'commission_rate'   => 'decimal:2',
            'commission_amount' => 'decimal:4',
            'doctor_earning'    => 'decimal:4',
            'accepted_at'      => 'datetime',
            'completed_at'     => 'datetime',
            'expires_at'       => 'datetime',
        ];
    }

    const STATUS_PENDING    = 'pending';
    const STATUS_ACCEPTED   = 'accepted';
    const STATUS_ON_THE_WAY = 'on_the_way';
    const STATUS_COMPLETED  = 'completed';
    const STATUS_CANCELLED  = 'cancelled';

    public function patient(): BelongsTo
    {
        return $this->belongsTo(User::class, 'patient_id');
    }

    public function doctor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'doctor_id');
    }

    public function doctorProfile(): BelongsTo
    {
        return $this->belongsTo(DoctorProfile::class);
    }

    // ── Scopes ───────────────────────────────────────────────────────────
    public function scopePending($query)
    {
        return $query->where('status', self::STATUS_PENDING);
    }

    // ── Helpers ──────────────────────────────────────────────────────────
    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }

    public function isExpired(): bool
    {
        return $this->isPending() && $this->expires_at && $this->expires_at->isPast();
    }

    public function canCancel(): bool
    {
        return in_array($this->status, [self::STATUS_PENDING, self::STATUS_ACCEPTED]);
    }
}
