<?php

namespace App\Models\Medical;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class MedicalSetting extends Model
{
    protected $fillable = ['key', 'value'];

    /**
     * Sozlama qiymatini olish (cache bilan)
     */
    public static function getValue(string $key, mixed $default = null): mixed
    {
        return Cache::remember("medical_setting:{$key}", 3600, function () use ($key, $default) {
            $setting = static::where('key', $key)->first();
            return $setting ? $setting->value : $default;
        });
    }

    /**
     * Sozlama qiymatini o'rnatish
     */
    public static function setValue(string $key, mixed $value): void
    {
        static::updateOrCreate(['key' => $key], ['value' => (string) $value]);
        Cache::forget("medical_setting:{$key}");
    }

    /**
     * Barcha sozlamalarni olish
     */
    public static function getAll(): array
    {
        return Cache::remember('medical_settings_all', 3600, function () {
            return static::pluck('value', 'key')->toArray();
        });
    }

    /**
     * Cache tozalash
     */
    public static function clearCache(): void
    {
        $settings = static::pluck('key');
        foreach ($settings as $key) {
            Cache::forget("medical_setting:{$key}");
        }
        Cache::forget('medical_settings_all');
    }
}
