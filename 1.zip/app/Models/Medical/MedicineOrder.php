<?php

namespace App\Models\Medical;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class MedicineOrder extends Model
{
    protected $fillable = [
        'patient_id', 'prescription_id', 'delivery_address',
        'medicines_total', 'delivery_fee', 'platform_fee', 'total_amount',
        'status', 'cancel_reason', 'delivered_at',
    ];

    protected function casts(): array
    {
        return [
            'medicines_total' => 'decimal:4',
            'delivery_fee'    => 'decimal:4',
            'platform_fee'    => 'decimal:4',
            'total_amount'    => 'decimal:4',
            'delivered_at'    => 'datetime',
        ];
    }

    const STATUS_NEW        = 'new';
    const STATUS_PROCESSING = 'processing';
    const STATUS_DELIVERING = 'delivering';
    const STATUS_DELIVERED  = 'delivered';
    const STATUS_CANCELLED  = 'cancelled';

    public function patient(): BelongsTo
    {
        return $this->belongsTo(User::class, 'patient_id');
    }

    public function prescription(): BelongsTo
    {
        return $this->belongsTo(Prescription::class);
    }

    public function items(): HasMany
    {
        return $this->hasMany(MedicineOrderItem::class);
    }

    // ── Scopes ───────────────────────────────────────────────────────────
    public function scopeByStatus($query, string $status)
    {
        return $query->where('status', $status);
    }

    // ── Helpers ──────────────────────────────────────────────────────────
    public function isNew(): bool
    {
        return $this->status === self::STATUS_NEW;
    }

    public function canCancel(): bool
    {
        return $this->status === self::STATUS_NEW;
    }
}
