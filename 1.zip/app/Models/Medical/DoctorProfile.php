<?php

namespace App\Models\Medical;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class DoctorProfile extends Model
{
    protected $fillable = [
        'user_id', 'specialty', 'experience_years', 'diploma_image',
        'license_number', 'workplace', 'consultation_price', 'home_visit_price',
        'bio', 'status', 'rejection_reason', 'rating', 'reviews_count',
        'consultations_count', 'is_online', 'offers_home_visit',
        'last_active_at', 'approved_at',
    ];

    protected function casts(): array
    {
        return [
            'consultation_price' => 'decimal:4',
            'home_visit_price'   => 'decimal:4',
            'rating'             => 'decimal:2',
            'is_online'          => 'boolean',
            'offers_home_visit'  => 'boolean',
            'experience_years'   => 'integer',
            'reviews_count'      => 'integer',
            'consultations_count' => 'integer',
            'last_active_at'     => 'datetime',
            'approved_at'        => 'datetime',
        ];
    }

    // ── Ixtisosliklar ro'yxati ───────────────────────────────────────────
    const SPECIALTIES = [
        'terapevt', 'kardiolog', 'nevropatolog', 'stomatolog', 'ginekolog',
        'urolog', 'pediatr', 'dermatolog', 'okulist', 'lor',
        'endokrinolog', 'psixolog', 'ortoped', 'xirurg', 'dietolog',
    ];

    // ── Holatlar ─────────────────────────────────────────────────────────
    const STATUS_PENDING   = 'pending';
    const STATUS_APPROVED  = 'approved';
    const STATUS_REJECTED  = 'rejected';
    const STATUS_SUSPENDED = 'suspended';
    const STATUS_INACTIVE  = 'inactive';

    // ── Relationships ────────────────────────────────────────────────────
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function consultations(): HasMany
    {
        return $this->hasMany(Consultation::class);
    }

    public function reviews(): HasMany
    {
        return $this->hasMany(DoctorReview::class);
    }

    public function homeVisits(): HasMany
    {
        return $this->hasMany(HomeVisit::class);
    }

    // ── Scopes ───────────────────────────────────────────────────────────
    public function scopeApproved($query)
    {
        return $query->where('status', self::STATUS_APPROVED);
    }

    public function scopeOnline($query)
    {
        return $query->where('is_online', true);
    }

    public function scopeBySpecialty($query, string $specialty)
    {
        return $query->where('specialty', $specialty);
    }

    // ── Helpers ──────────────────────────────────────────────────────────
    public function isApproved(): bool
    {
        return $this->status === self::STATUS_APPROVED;
    }

    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }

    public function isSuspended(): bool
    {
        return $this->status === self::STATUS_SUSPENDED;
    }

    public function recalculateRating(): void
    {
        $avg = $this->reviews()->avg('rating') ?? 0;
        $count = $this->reviews()->count();
        $this->update([
            'rating'        => round($avg, 2),
            'reviews_count' => $count,
        ]);
    }
}
