<?php

namespace App\Models\Medical;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class MedicalComplaint extends Model
{
    protected $fillable = [
        'consultation_id', 'patient_id', 'doctor_id',
        'type', 'message', 'status', 'admin_response',
        'is_justified', 'reviewed_at',
    ];

    protected function casts(): array
    {
        return [
            'is_justified' => 'boolean',
            'reviewed_at'  => 'datetime',
        ];
    }

    const TYPE_WRONG_ADVICE  = 'wrong_advice';
    const TYPE_RUDE_BEHAVIOR = 'rude_behavior';
    const TYPE_NO_RESPONSE   = 'no_response';
    const TYPE_OTHER         = 'other';

    const TYPES = [
        self::TYPE_WRONG_ADVICE,
        self::TYPE_RUDE_BEHAVIOR,
        self::TYPE_NO_RESPONSE,
        self::TYPE_OTHER,
    ];

    const STATUS_PENDING  = 'pending';
    const STATUS_REVIEWED = 'reviewed';
    const STATUS_RESOLVED = 'resolved';

    public function consultation(): BelongsTo
    {
        return $this->belongsTo(Consultation::class);
    }

    public function patient(): BelongsTo
    {
        return $this->belongsTo(User::class, 'patient_id');
    }

    public function doctor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'doctor_id');
    }

    public function scopePending($query)
    {
        return $query->where('status', self::STATUS_PENDING);
    }
}
