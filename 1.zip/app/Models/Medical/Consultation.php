<?php

namespace App\Models\Medical;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Consultation extends Model
{
    protected $fillable = [
        'patient_id', 'doctor_id', 'doctor_profile_id',
        'price', 'escrow_amount', 'commission_rate',
        'commission_amount', 'doctor_earning',
        'status', 'accepted_at', 'completed_at', 'expires_at',
    ];

    protected function casts(): array
    {
        return [
            'price'             => 'decimal:4',
            'escrow_amount'     => 'decimal:4',
            'commission_rate'   => 'decimal:2',
            'commission_amount' => 'decimal:4',
            'doctor_earning'    => 'decimal:4',
            'accepted_at'      => 'datetime',
            'completed_at'     => 'datetime',
            'expires_at'       => 'datetime',
        ];
    }

    // ── Holatlar ─────────────────────────────────────────────────────────
    const STATUS_PENDING   = 'pending';
    const STATUS_ACTIVE    = 'active';
    const STATUS_COMPLETED = 'completed';
    const STATUS_CANCELLED = 'cancelled';
    const STATUS_EXPIRED   = 'expired';

    // ── Relationships ────────────────────────────────────────────────────
    public function patient(): BelongsTo
    {
        return $this->belongsTo(User::class, 'patient_id');
    }

    public function doctor(): BelongsTo
    {
        return $this->belongsTo(User::class, 'doctor_id');
    }

    public function doctorProfile(): BelongsTo
    {
        return $this->belongsTo(DoctorProfile::class);
    }

    public function messages(): HasMany
    {
        return $this->hasMany(ConsultationMessage::class);
    }

    public function prescriptions(): HasMany
    {
        return $this->hasMany(Prescription::class);
    }

    public function referrals(): HasMany
    {
        return $this->hasMany(MedicalReferral::class);
    }

    public function review(): HasOne
    {
        return $this->hasOne(DoctorReview::class);
    }

    public function complaint(): HasOne
    {
        return $this->hasOne(MedicalComplaint::class);
    }

    // ── Scopes ───────────────────────────────────────────────────────────
    public function scopePending($query)
    {
        return $query->where('status', self::STATUS_PENDING);
    }

    public function scopeActive($query)
    {
        return $query->where('status', self::STATUS_ACTIVE);
    }

    public function scopeCompleted($query)
    {
        return $query->where('status', self::STATUS_COMPLETED);
    }

    public function scopeExpired($query)
    {
        return $query->where('status', self::STATUS_EXPIRED)
            ->orWhere(function ($q) {
                $q->where('status', self::STATUS_PENDING)
                  ->where('expires_at', '<', now());
            });
    }

    // ── Helpers ──────────────────────────────────────────────────────────
    public function isPending(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }

    public function isActive(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }

    public function isCompleted(): bool
    {
        return $this->status === self::STATUS_COMPLETED;
    }

    public function isExpired(): bool
    {
        return $this->status === self::STATUS_EXPIRED || 
               ($this->isPending() && $this->expires_at && $this->expires_at->isPast());
    }

    public function canSendMessage(): bool
    {
        return $this->status === self::STATUS_ACTIVE;
    }

    public function canCancel(): bool
    {
        return $this->status === self::STATUS_PENDING;
    }
}
