<?php

namespace App\Models\Medical;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Medicine extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'name', 'type', 'price', 'description', 'is_active', 'in_stock',
    ];

    protected function casts(): array
    {
        return [
            'price'     => 'decimal:4',
            'is_active' => 'boolean',
            'in_stock'  => 'boolean',
        ];
    }

    const TYPE_TABLET    = 'tablet';
    const TYPE_SYRUP     = 'syrup';
    const TYPE_INJECTION = 'injection';
    const TYPE_OINTMENT  = 'ointment';
    const TYPE_DROPS     = 'drops';
    const TYPE_OTHER     = 'other';

    const TYPES = [
        self::TYPE_TABLET, self::TYPE_SYRUP, self::TYPE_INJECTION,
        self::TYPE_OINTMENT, self::TYPE_DROPS, self::TYPE_OTHER,
    ];

    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeInStock($query)
    {
        return $query->where('in_stock', true);
    }

    public function scopeAvailable($query)
    {
        return $query->active()->inStock();
    }
}
