<?php

namespace App\Models\Level;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class LevelConfig extends Model
{
    protected $fillable = [
        'level', 'title', 'title_uz', 'title_ru', 'title_en',
        'badge_color', 'badge_icon', 'xp_required',
        'ref_bonus_percent', 'cashback_percent', 'daily_mining_bonus',
        'transfer_fee_discount', 'virtual_card_unlocked', 'p2p_unlocked',
    ];

    protected function casts(): array
    {
        return [
            'xp_required'           => 'integer',
            'ref_bonus_percent'     => 'decimal:2',
            'cashback_percent'      => 'decimal:2',
            'daily_mining_bonus'    => 'decimal:2',
            'transfer_fee_discount' => 'decimal:2',
            'virtual_card_unlocked' => 'boolean',
            'p2p_unlocked'          => 'boolean',
        ];
    }

    protected static function booted()
    {
        static::saved(function ($model) {
            Cache::forget("level_config_{$model->level}");
        });

        static::deleted(function ($model) {
            Cache::forget("level_config_{$model->level}");
        });
    }

    public function scopeForLevel($query, int $level)
    {
        return $query->where('level', $level);
    }

    public static function getForLevel(int $level): ?static
    {
        return Cache::remember("level_config_{$level}", now()->addHours(24), function () use ($level) {
            return static::where('level', $level)->first();
        });
    }
}
