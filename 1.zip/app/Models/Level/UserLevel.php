<?php

namespace App\Models\Level;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class UserLevel extends Model
{
    protected $fillable = [
        'user_id', 'level', 'total_xp', 'current_xp',
        'next_level_xp', 'title', 'badge_color',
    ];

    protected function casts(): array
    {
        return [
            'level'         => 'integer',
            'total_xp'      => 'integer',
            'current_xp'    => 'integer',
            'next_level_xp' => 'integer',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function xpLogs(): HasMany
    {
        return $this->hasMany(XpLog::class, 'user_id', 'user_id');
    }

    /** Progress foizi (0–100) */
    public function getProgressPercentAttribute(): float
    {
        if ($this->next_level_xp <= 0) return 100;
        return min(100, round(($this->current_xp / $this->next_level_xp) * 100, 1));
    }

    /** Keyingi darajaga qancha XP qoldi */
    public function getRemainingXpAttribute(): int
    {
        return max(0, $this->next_level_xp - $this->current_xp);
    }

    /** Level formulasi: level = floor(sqrt(total_xp / 100)) */
    public static function calcLevel(int $totalXp): int
    {
        return min(99, (int) floor(sqrt($totalXp / 100)));
    }

    /** Keyingi daraja uchun kerakli XP */
    public static function xpForLevel(int $level): int
    {
        return ($level + 1) * ($level + 1) * 100;
    }

    /** Joriy darajadagi XP (shu darajaga kirish uchun kerakli XP dan ortiqchasi) */
    public static function currentLevelXp(int $totalXp, int $level): int
    {
        $prevRequired = $level * $level * 100;
        return $totalXp - $prevRequired;
    }

    /** Unvon va rang olish */
    public static function getTitleAndColor(int $level): array
    {
        return match(true) {
            $level >= 99 => ['AISOQQA Elite', '#f59e0b'],
            $level >= 75 => ['Legend',        '#a855f7'],
            $level >= 50 => ['Grandmaster',   '#ec4899'],
            $level >= 35 => ['Master',        '#3b82f6'],
            $level >= 20 => ['Expert',        '#10b981'],
            $level >= 10 => ['Experienced',   '#6366f1'],
            $level >= 5  => ['Active',        '#06b6d4'],
            default      => ['Newcomer',      '#64748b'],
        };
    }

    /** Unvon, rang va emoji olish */
    public static function getTitleColorAndIcon(int $level): array
    {
        return match(true) {
            $level >= 99 => ['AISOQQA Elite', '#f59e0b', '🚀'],
            $level >= 75 => ['Legend',        '#a855f7', '🌟'],
            $level >= 50 => ['Grandmaster',   '#ec4899', '👑'],
            $level >= 35 => ['Master',        '#3b82f6', '🏆'],
            $level >= 20 => ['Expert',        '#10b981', '💎'],
            $level >= 10 => ['Experienced',   '#6366f1', '🔥'],
            $level >= 5  => ['Active',        '#06b6d4', '⚡'],
            default      => ['Newcomer',      '#64748b', '🌱'],
        };
    }
}
