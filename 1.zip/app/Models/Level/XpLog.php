<?php

namespace App\Models\Level;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphTo;

class XpLog extends Model
{
    protected $fillable = [
        'user_id', 'action', 'xp', 'description',
        'xpable_type', 'xpable_id',
    ];

    // XP action konstantalari
    const ACTION_REGISTER   = 'register';
    const ACTION_CHECKIN    = 'checkin';
    const ACTION_DEPOSIT    = 'deposit';
    const ACTION_PURCHASE   = 'purchase';
    const ACTION_REFERRAL   = 'referral';
    const ACTION_TRANSFER   = 'transfer';
    const ACTION_TASK       = 'task';
    const ACTION_KYC        = 'kyc';
    const ACTION_PROFILE    = 'profile';
    const ACTION_LUCKY_DRAW = 'lucky_draw';
    const ACTION_FUND       = 'fund_invest';
    const ACTION_PROMO      = 'promo';
    const ACTION_SPIN_WHEEL = 'spin_wheel';
    const ACTION_SHARE      = 'share';
    const ACTION_CHALLENGE  = 'challenge';
    const ACTION_ONBOARDING   = 'onboarding';
    const ACTION_GIG_COMPLETE = 'gig_complete';
    const ACTION_GIG_ORDER    = 'gig_order';
    const ACTION_GIG_REVIEW   = 'gig_review';
    const ACTION_CREDIT_REPAY = 'credit_repay';
    const ACTION_SAVINGS_COMPLETE = 'savings_complete';
    const ACTION_CATALOG_SHOP     = 'catalog_shop';
    const ACTION_CATALOG_ORDER    = 'catalog_order';
    const ACTION_CATALOG_REVIEW   = 'catalog_review';

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function xpable(): MorphTo
    {
        return $this->morphTo();
    }

    /** xp_actions jadvalidan XP miqdorini olish */
    public static function getActionXp(string $action): int
    {
        $row = \Illuminate\Support\Facades\DB::table('xp_actions')
            ->where('action', $action)
            ->where('is_active', true)
            ->first();

        return $row?->xp_amount ?? 0;
    }
}
