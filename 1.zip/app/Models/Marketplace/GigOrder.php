<?php

namespace App\Models\Marketplace;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasOne;

class GigOrder extends Model
{
    const STATUS_PENDING     = 'pending';
    const STATUS_IN_PROGRESS = 'in_progress';
    const STATUS_DELIVERED   = 'delivered';
    const STATUS_COMPLETED   = 'completed';
    const STATUS_REJECTED    = 'rejected';
    const STATUS_DISPUTED    = 'disputed';

    protected $fillable = [
        'gig_id', 'buyer_id', 'seller_id',
        'amount', 'commission_rate', 'commission_amount', 'seller_amount',
        'status', 'delivered_at', 'completed_at',
    ];

    protected function casts(): array
    {
        return [
            'amount'            => 'decimal:4',
            'commission_rate'   => 'decimal:2',
            'commission_amount' => 'decimal:4',
            'seller_amount'     => 'decimal:4',
            'delivered_at'      => 'datetime',
            'completed_at'      => 'datetime',
        ];
    }

    public function gig(): BelongsTo
    {
        return $this->belongsTo(Gig::class);
    }

    public function buyer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'buyer_id');
    }

    public function seller(): BelongsTo
    {
        return $this->belongsTo(User::class, 'seller_id');
    }

    public function review(): HasOne
    {
        return $this->hasOne(GigReview::class, 'order_id');
    }

    public function dispute(): HasOne
    {
        return $this->hasOne(GigDispute::class, 'order_id');
    }
}
