<?php

namespace App\Models\Marketplace;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Gig extends Model
{
    const STATUS_ACTIVE  = 'active';
    const STATUS_PAUSED  = 'paused';
    const STATUS_DELETED = 'deleted';

    protected $fillable = [
        'user_id', 'category_id', 'title', 'description',
        'price', 'delivery_days', 'status',
        'avg_rating', 'total_reviews', 'total_orders',
    ];

    protected function casts(): array
    {
        return [
            'price'      => 'decimal:4',
            'avg_rating' => 'decimal:2',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function category(): BelongsTo
    {
        return $this->belongsTo(GigCategory::class, 'category_id');
    }

    public function orders(): HasMany
    {
        return $this->hasMany(GigOrder::class);
    }

    public function reviews(): HasMany
    {
        return $this->hasMany(GigReview::class);
    }

    public function scopeActive($query)
    {
        return $query->where('status', self::STATUS_ACTIVE);
    }

    public function isOwnedBy(User $user): bool
    {
        return $this->user_id === $user->id;
    }

    public function hasActiveOrders(): bool
    {
        return $this->orders()
            ->whereNotIn('status', [GigOrder::STATUS_COMPLETED, GigOrder::STATUS_REJECTED])
            ->exists();
    }
}
