<?php

namespace App\Models\Marketplace;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class GigDispute extends Model
{
    const RESOLUTION_PENDING      = 'pending';
    const RESOLUTION_BUYER_WINS   = 'buyer_wins';
    const RESOLUTION_SELLER_WINS  = 'seller_wins';

    protected $fillable = [
        'order_id', 'opened_by', 'reason',
        'resolution', 'resolved_by', 'resolved_at', 'admin_note',
    ];

    protected function casts(): array
    {
        return [
            'resolved_at' => 'datetime',
        ];
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(GigOrder::class, 'order_id');
    }

    public function opener(): BelongsTo
    {
        return $this->belongsTo(User::class, 'opened_by');
    }

    public function resolver(): BelongsTo
    {
        return $this->belongsTo(User::class, 'resolved_by');
    }
}
