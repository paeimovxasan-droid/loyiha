<?php

namespace App\Models\Payment;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Deposit extends Model
{
    protected $fillable = [
        'user_id', 'payment_method_id',
        'method_name', 'method_number',
        'order_id', 'transaction_id',
        'sender_number', 'amount', 'charge', 'final_amount',
        'feedback', 'screenshot', 'status', 'approved_at',
    ];

    protected function casts(): array
    {
        return [
            'amount'       => 'decimal:2',
            'charge'       => 'decimal:2',
            'final_amount' => 'decimal:2',
            'approved_at'  => 'datetime',
        ];
    }

    public function scopePending($query) { return $query->where('status', 'pending'); }
    public function scopeApproved($query) { return $query->where('status', 'approved'); }
    public function scopeRejected($query) { return $query->where('status', 'rejected'); }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function paymentMethod(): BelongsTo { return $this->belongsTo(PaymentMethod::class); }

    public function getScreenshotUrlAttribute(): ?string
    {
        return $this->screenshot ? asset('storage/' . $this->screenshot) : null;
    }

    public function isPending(): bool { return $this->status === 'pending'; }
    public function isApproved(): bool { return $this->status === 'approved'; }
}
