<?php

namespace App\Models\Payment;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Translatable\HasTranslations;

class PaymentMethod extends Model
{
    use HasTranslations;

    protected $fillable = [
        'name', 'slug', 'photo_id', 'number',
        'minimum_deposit', 'maximum_deposit', 'deposit_charge_percent',
        'minimum_withdraw', 'maximum_withdraw', 'withdraw_charge_percent',
        'status', 'sort_order',
    ];

    public array $translatable = ['name'];

    protected function casts(): array
    {
        return [
            'minimum_deposit'        => 'decimal:2',
            'maximum_deposit'        => 'decimal:2',
            'deposit_charge_percent' => 'decimal:2',
            'minimum_withdraw'       => 'decimal:2',
            'maximum_withdraw'       => 'decimal:2',
            'withdraw_charge_percent'=> 'decimal:2',
        ];
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active')->orderBy('sort_order');
    }

    public function deposits(): HasMany
    {
        return $this->hasMany(Deposit::class);
    }

    public function withdrawals(): HasMany
    {
        return $this->hasMany(Withdrawal::class);
    }

    public function photoFile()
    {
        return $this->belongsTo(\App\Models\File::class, 'photo_id');
    }

    public function getPhotoUrlAttribute(): string
    {
        return $this->photoFile ? $this->photoFile->url : asset('images/payment-default.png');
    }

    /**
     * Deposit uchun to'lov miqdorini hisoblash
     */
    public function calcDepositCharge(float $amount): float
    {
        return round($amount * $this->deposit_charge_percent / 100, 2);
    }

    /**
     * Withdraw uchun to'lov miqdorini hisoblash
     */
    public function calcWithdrawCharge(float $amount): float
    {
        return round($amount * $this->withdraw_charge_percent / 100, 2);
    }
}
