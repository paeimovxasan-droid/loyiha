<?php

namespace App\Models\Investment;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Spatie\Translatable\HasTranslations;

class Fund extends Model
{
    use HasTranslations;

    protected $fillable = [
        'name', 'description', 'photo',
        'commission_percent', 'validity_days', 'min_invest',
        'status', 'sort_order',
    ];

    public array $translatable = ['name', 'description'];

    protected function casts(): array
    {
        return [
            'commission_percent' => 'decimal:2',
            'min_invest'         => 'decimal:2',
        ];
    }

    public function scopeActive($query) { return $query->where('status', 'active')->orderBy('sort_order'); }

    public function invests(): HasMany { return $this->hasMany(FundInvest::class); }

    public function getPhotoUrlAttribute(): string
    {
        return $this->photo ? asset('storage/' . $this->photo) : asset('images/fund-default.png');
    }
}
