<?php

namespace App\Models\Investment;

use Illuminate\Database\Eloquent\Model;
use Spatie\Translatable\HasTranslations;

class Rebate extends Model
{
    use HasTranslations;

    protected $fillable = [
        'name',
        'team_commission1', 'team_commission2', 'team_commission3',
        'interest_rate1', 'interest_rate2', 'interest_rate3',
        'status',
    ];

    public array $translatable = ['name'];

    protected function casts(): array
    {
        return [
            'team_commission1' => 'decimal:2',
            'team_commission2' => 'decimal:2',
            'team_commission3' => 'decimal:2',
            'interest_rate1'   => 'decimal:2',
            'interest_rate2'   => 'decimal:2',
            'interest_rate3'   => 'decimal:2',
        ];
    }
}
