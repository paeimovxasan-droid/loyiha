<?php

namespace App\Models\Investment;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FundInvest extends Model
{
    protected $fillable = [
        'user_id', 'fund_id', 'amount', 'expected_profit',
        'started_at', 'expires_at', 'status',
    ];

    protected function casts(): array
    {
        return [
            'amount'          => 'decimal:2',
            'expected_profit' => 'decimal:2',
            'started_at'      => 'date',
            'expires_at'      => 'date',
        ];
    }

    public function scopeActive($query) { return $query->where('status', 'active'); }

    public function user(): BelongsTo { return $this->belongsTo(User::class); }
    public function fund(): BelongsTo { return $this->belongsTo(Fund::class); }

    public function isMatured(): bool { return $this->status === 'matured'; }
}
