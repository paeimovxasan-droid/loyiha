<?php

namespace App\Models\Investment;

use Illuminate\Database\Eloquent\Model;

class ReinvestSetting extends Model
{
    protected $fillable = [
        'amount_limit', 'daily_percent',
        'ref_level1_percent', 'ref_level2_percent', 'ref_level3_percent',
        'ref_level4_percent', 'ref_level5_percent', 'status',
    ];

    public static function active(): static
    {
        return static::where('status', 'active')->firstOrNew([]);
    }
}
