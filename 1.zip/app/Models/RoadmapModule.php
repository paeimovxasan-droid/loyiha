<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class RoadmapModule extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'title',
        'description',
        'icon',
        'status',
        'sort_order',
        'estimated_date',
        'banner_image',
        'progress_percent',
        'votes_count',
    ];

    protected function casts(): array
    {
        return [
            'estimated_date'   => 'date',
            'progress_percent' => 'integer',
            'votes_count'      => 'integer',
            'sort_order'       => 'integer',
        ];
    }

    // ─── Status map ────────────────────────────────────────────────────

    public const STATUS_MAP = [
        'coming_soon' => ['label' => 'Tez kunda',    'color' => '#9CA3AF'],
        'in_progress' => ['label' => 'Ishlanmoqda',  'color' => '#F59E0B'],
        'beta'        => ['label' => 'Beta test',    'color' => '#3B82F6'],
        'released'    => ['label' => 'Tayyor',       'color' => '#10B981'],
    ];

    // ─── Accessors ─────────────────────────────────────────────────────

    public function getStatusLabelAttribute(): string
    {
        return self::STATUS_MAP[$this->status]['label'] ?? $this->status;
    }

    public function getStatusColorAttribute(): string
    {
        return self::STATUS_MAP[$this->status]['color'] ?? '#9CA3AF';
    }

    // ─── Scopes ────────────────────────────────────────────────────────

    public function scopeActive($query)
    {
        return $query->orderBy('sort_order');
    }

    // ─── Relations ─────────────────────────────────────────────────────

    public function votes(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(RoadmapVote::class);
    }

    public function notifications(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(RoadmapNotification::class);
    }
}
