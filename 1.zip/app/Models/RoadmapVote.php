<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RoadmapVote extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'roadmap_module_id',
        'created_at',
    ];

    protected function casts(): array
    {
        return [
            'created_at' => 'datetime',
        ];
    }

    public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function module(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(RoadmapModule::class, 'roadmap_module_id');
    }
}
