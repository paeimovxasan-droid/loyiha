<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RoadmapNotification extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'user_id',
        'roadmap_module_id',
        'notified_at',
        'created_at',
    ];

    protected function casts(): array
    {
        return [
            'notified_at' => 'datetime',
            'created_at'  => 'datetime',
        ];
    }

    // ─── Scopes ────────────────────────────────────────────────────────

    public function scopeUnnotified($query)
    {
        return $query->whereNull('notified_at');
    }

    // ─── Relations ─────────────────────────────────────────────────────

    public function user(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function module(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(RoadmapModule::class, 'roadmap_module_id');
    }
}
