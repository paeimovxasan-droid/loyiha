<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Database\Eloquent\SoftDeletes;
use App\Traits\HasApiTokens;
use Spatie\Permission\Traits\HasRoles;
use App\Models\Traits\HasWallet;
use App\Models\Traits\HasGamification;
use App\Models\Traits\HasMarketplace;
use App\Models\Traits\HasFinance;
use App\Models\Traits\HasEducation;
use App\Models\Traits\HasMedical;
use App\Models\Security\UserDevice;
use App\Models\Security\BehavioralScoreLog;
use App\Models\Security\FraudFlag;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable, SoftDeletes, HasRoles,
        HasWallet, HasGamification, HasMarketplace, HasFinance, HasEducation, HasMedical;

    protected $fillable = [
        'name',
        'email',
        'phone',
        'username',
        'referred_by',
        'avatar',
        'password',
        'balance',
        'locale',
        'status',
        'email_verified_at',
        'kyc_status',
        'kyc_document',
        'kyc_verified_at',
        'frozen_uzs_balance',
        'two_fa_enabled',
        'two_fa_secret',
        'is_leader',
        'telegram_id',
        'telegram_notifications',
        'telegram_first_name',
        'telegram_last_name',
        'telegram_username',
        'telegram_photo_url',
        'kyc_type',
        'kyc_stage',
        'kyc_submitted_at',
        'kyc_rejection_reason',
        'behavioral_score',
        'is_high_risk',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at'  => 'datetime',
            'password'           => 'hashed',
            'balance'            => 'decimal:2',
            'frozen_uzs_balance' => 'decimal:2',
            'behavioral_score'   => 'integer',
            'is_high_risk'       => 'boolean',
            'kyc_submitted_at'   => 'datetime',
            'kyc_verified_at'    => 'datetime',
        ];
    }

    // ─── Scopes ────────────────────────────────────────────────────────────────

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    // ─── Base Relations ────────────────────────────────────────────────────────

    public function referrer(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(User::class, 'referred_by', 'username');
    }

    public function referrals(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(User::class, 'referred_by', 'username');
    }

    public function membership(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(\App\Models\Marketing\UserMembership::class);
    }

    public function shareLink(): \Illuminate\Database\Eloquent\Relations\HasOne
    {
        return $this->hasOne(\App\Models\Marketing\ShareLink::class);
    }

    // ─── Telegram / KYC ───────────────────────────────────────────────────────

    public function faceKycAttempts(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Security\FaceKycAttempt::class);
    }

    public function channelPosts(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\ChannelPost::class, 'created_by');
    }

    // ─── Security / Anti-Fraud ─────────────────────────────────────────────────

    public function devices(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(UserDevice::class);
    }

    public function behavioralScoreLogs(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(BehavioralScoreLog::class);
    }

    public function fraudFlags(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(FraudFlag::class);
    }

    // ─── Influencer ───────────────────────────────────────────────────────────

    public function influencerChannels(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Influencer\InfluencerChannel::class);
    }

    public function influencerSubmissions(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Influencer\InfluencerSubmission::class);
    }

    public function influencerRewards(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Influencer\InfluencerReward::class);
    }

    // ─── Support Tickets ──────────────────────────────────────────────────────

    public function supportTickets(): \Illuminate\Database\Eloquent\Relations\HasMany
    {
        return $this->hasMany(\App\Models\Support\SupportTicket::class);
    }

    // ─── Helpers ───────────────────────────────────────────────────────────────

    public function isAdmin(): bool
    {
        return $this->hasAnyRole(['admin', 'super-admin', 'moderator']);
    }

    public function isBanned(): bool
    {
        return $this->status === 'banned';
    }

    public function getAvatarUrlAttribute(): string
    {
        return $this->avatar
            ? asset('storage/' . $this->avatar)
            : 'https://ui-avatars.com/api/?name=' . urlencode($this->name ?? 'U') . '&color=7F9CF5&background=EBF4FF';
    }
}
