<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Translation extends Model
{
    protected $fillable = ['group', 'key', 'text'];

    protected $casts = ['text' => 'array'];

    /**
     * PostgreSQL da "group" reserved keyword — safe getters
     */
    public function getGroupColumn(): string
    {
        // PostgreSQL needs "group" quoted, but Eloquent handles fillable fine.
        // We use this helper in raw queries only.
        return DB::getDriverName() === 'pgsql' ? '"group"' : '`group`';
    }

    /**
     * Joriy tildagi matnni qaytarish
     */
    public function getTextForLocale(string $locale): string
    {
        $text = $this->text ?? [];
        return $text[$locale]
            ?? $text['uz']
            ?? $text['en']
            ?? $this->key;
    }

    /**
     * Bitta kalitni DB dan olish
     */
    public static function trans(string $group, string $key, ?string $locale = null): string
    {
        $locale = $locale ?? app()->getLocale();
        $row = static::where('group', $group)->where('key', $key)->first();
        if (!$row) return "$group.$key";
        return $row->getTextForLocale($locale);
    }
}
