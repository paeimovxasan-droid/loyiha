<?php

namespace App\Models\Ubi;

use Illuminate\Database\Eloquent\Model;

class UbiSetting extends Model
{
    protected $fillable = ['daily_amount', 'is_active', 'min_level'];

    protected function casts(): array
    {
        return [
            'daily_amount' => 'decimal:4',
            'is_active'    => 'boolean',
            'min_level'    => 'integer',
        ];
    }

    public static function current(): self
    {
        return static::first() ?? static::create([
            'daily_amount' => 1.0000,
            'is_active'    => true,
            'min_level'    => 0,
        ]);
    }
}
