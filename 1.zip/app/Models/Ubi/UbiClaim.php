<?php

namespace App\Models\Ubi;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class UbiClaim extends Model
{
    protected $fillable = ['user_id', 'amount', 'claimed_at'];

    protected function casts(): array
    {
        return [
            'amount'     => 'decimal:4',
            'claimed_at' => 'date',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class);
    }
}
