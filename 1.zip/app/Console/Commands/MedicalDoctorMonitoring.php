<?php

namespace App\Console\Commands;

use App\Services\Medical\QualityControlService;
use Illuminate\Console\Command;

class MedicalDoctorMonitoring extends Command
{
    protected $signature = 'medical:doctor-monitoring';
    protected $description = 'Shifokorlar faoliyatini tekshirish — nofaol shifokorlarni belgilash va sifat nazorati';

    public function handle(): int
    {
        $this->info('Shifokor faoliyat monitoring boshlanmoqda...');

        // Faoliyatsiz shifokorlarni nofaol qilish
        $inactiveCount = QualityControlService::markInactiveDoctors();
        $this->info("Nofaol qilingan shifokorlar: {$inactiveCount}");

        return self::SUCCESS;
    }
}
