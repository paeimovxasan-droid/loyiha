<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;

class TelegramSetWebhookCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'telegram:set-webhook {url? : The Webhook URL (Ngrok or Production HTTPS url)}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Tezda Telegram Webhook ni botga ulash va sozlsh.';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $botToken = config('services.telegram.bot_token');
        
        if (!$botToken) {
            $this->error('Diqqat! Telegram bot token konfiguratsiyasi (.env dagi TELEGRAM_BOT_TOKEN) topilmadi!');
            return Command::FAILURE;
        }

        // Agar url argument sifatida berilmasa, app.url ni ishlatish
        $rawUrl = $this->argument('url') ?: config('app.url');
        
        // URL ga scheme va API postfix ulanganiga ishonch hosil qilish
        $url = rtrim($rawUrl, '/') . '/api/v1/telegram/webhook';
        
        // Agar http:// local yoki ngrok url bo'lsa uni warning qilib beramiz (Telegram faqat HTTPS qabul qiladi)
        if (str_starts_with($url, 'http://') && !str_contains($url, 'ngrok')) {
            $this->warn("Ogohlantirish: Telegram asosan HTTPS url larni qabul qiladi. Siznikida: {$url}");
        }

        $secret = config('services.telegram.webhook_secret');

        $this->info("Ulanayotgan manzil: {$url}");

        $response = Http::post("https://api.telegram.org/bot{$botToken}/setWebhook", [
            'url'                  => $url,
            'secret_token'         => $secret,
            'drop_pending_updates' => true,
        ]);

        if ($response->successful() && $response->json('ok')) {
            $this->info("✅ Webhook muvaffaqiyatli saqlandi!");
            $this->info("Javob: " . $response->json('description'));
            return Command::SUCCESS;
        }

        $this->error("❌ Xatolik yuz berdi: " . $response->json('description'));
        return Command::FAILURE;
    }
}
