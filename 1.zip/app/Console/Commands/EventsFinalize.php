<?php

namespace App\Console\Commands;

use App\Models\Marketing\SeasonalEvent;
use App\Services\Marketing\EventService;
use Illuminate\Console\Command;

class EventsFinalize extends Command
{
    protected $signature = 'events:finalize';

    protected $description = 'Muddati tugagan tadbirlarni yopish va g\'oliblarni aniqlash';

    public function handle(): int
    {
        $events = SeasonalEvent::where('status', 'active')
            ->where('ends_at', '<=', now())
            ->get();

        $count = 0;
        foreach ($events as $event) {
            EventService::finalize($event);
            $this->info("Tadbir #{$event->id} yakunlandi.");
            $count++;
        }

        if ($count === 0) {
            $this->info('Yakunlanishi kerak bo\'lgan tadbir topilmadi.');
        }

        return self::SUCCESS;
    }
}
