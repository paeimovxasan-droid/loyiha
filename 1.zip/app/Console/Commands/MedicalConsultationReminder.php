<?php

namespace App\Console\Commands;

use App\Models\Medical\Consultation;
use App\Services\TelegramBotService;
use Illuminate\Console\Command;

class MedicalConsultationReminder extends Command
{
    protected $signature = 'medical:reminder';
    protected $description = 'Maslahat muddati tugashiga 2 soat qolganida shifokorga eslatma yuborish';

    public function handle(): int
    {
        // 2 soat ichida expire bo'ladigan pending maslahatlar
        $consultations = Consultation::where('status', Consultation::STATUS_PENDING)
            ->whereBetween('expires_at', [now(), now()->addHours(2)])
            ->get();

        $count = 0;
        foreach ($consultations as $consultation) {
            TelegramBotService::notify(
                $consultation->doctor,
                "⏰ Eslatma! Maslahat so'rovi 2 soat ichida muddati tugaydi.\n\n"
                . "👤 Bemor: {$consultation->patient->name}\n"
                . "💰 Narx: {$consultation->price} AIS\n\n"
                . "Iltimos, tezroq javob bering!",
                [[['text' => '📱 Qabul qilish', 'url' => config('app.url') . '/app/medical/consultations/' . $consultation->id]]]
            );
            $count++;
        }

        $this->info("Eslatma yuborildi: {$count} ta shifokorga.");
        return self::SUCCESS;
    }
}
