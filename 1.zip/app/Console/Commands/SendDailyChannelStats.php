<?php

namespace App\Console\Commands;

use App\Services\TelegramChannelService;
use Illuminate\Console\Command;

class SendDailyChannelStats extends Command
{
    protected $signature = 'telegram:daily-stats';
    protected $description = 'Kunlik statistika postini Telegram kanalga yuborish';

    public function handle(): int
    {
        TelegramChannelService::sendDailyStats();
        $this->info('Kunlik statistika posti yuborildi.');
        return self::SUCCESS;
    }
}
