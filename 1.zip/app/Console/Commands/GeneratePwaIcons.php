<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

class GeneratePwaIcons extends Command
{
    protected $signature   = 'pwa:icons {--source= : Logo fayl yo\'li (ixtiyoriy)}';
    protected $description = 'PWA uchun barcha o\'lchamlarda icon\'lar yaratish';

    private array $sizes = [72, 96, 128, 144, 152, 192, 384, 512];

    public function handle(): int
    {
        $outputDir = public_path('images/pwa');

        if (!is_dir($outputDir)) {
            mkdir($outputDir, 0755, true);
        }

        // Logo faylini topish
        $sourcePath = $this->option('source');

        if (!$sourcePath) {
            $candidates = [
                public_path('images/logo.png'),
                public_path('images/logo.svg'),
                storage_path('app/public/logo.png'),
            ];
            foreach ($candidates as $c) {
                if (file_exists($c)) { $sourcePath = $c; break; }
            }
        }

        if ($sourcePath) {
            $this->info("Logo: {$sourcePath}");
        } else {
            $this->warn('Logo topilmadi. Gradient icon yaratiladi.');
        }

        $this->info('PWA icon\'lar yaratilmoqda...');
        $bar = $this->output->createProgressBar(count($this->sizes) + 1);
        $bar->start();

        foreach ($this->sizes as $size) {
            $this->generateIcon($size, $outputDir, $sourcePath);
            $bar->advance();
        }

        // Screenshot placeholder
        $this->generateScreenshot($outputDir);
        $bar->advance();
        $bar->finish();

        $this->newLine(2);
        $this->info('✅ Barcha icon\'lar yaratildi: ' . $outputDir);
        $this->line('');
        $this->line('Keyingi qadam:');
        $this->line('  1. public/images/pwa/ papkasidagi icon\'larni tekshiring');
        $this->line('  2. Agar logo.png mavjud bo\'lsa, u avtomatik ishlatiladi');
        $this->line('  3. Brauzerda F12 → Application → Manifest tekshiring');

        return self::SUCCESS;
    }

    private function generateIcon(int $size, string $dir, ?string $sourcePath): void
    {
        $outputPath = $dir . "/icon-{$size}.png";

        $image = imagecreatetruecolor($size, $size);

        // Gradient background
        for ($y = 0; $y < $size; $y++) {
            $ratio = $y / $size;
            $r = (int)(99  + (139 - 99)  * $ratio);
            $g = (int)(102 + (92  - 102) * $ratio);
            $b = (int)(241 + (246 - 241) * $ratio);
            $color = imagecolorallocate($image, $r, $g, $b);
            imageline($image, 0, $y, $size, $y, $color);
        }

        // Logo overlay
        if ($sourcePath && file_exists($sourcePath)) {
            $ext = strtolower(pathinfo($sourcePath, PATHINFO_EXTENSION));
            $logo = match($ext) {
                'png'  => @imagecreatefrompng($sourcePath),
                'jpg', 'jpeg' => @imagecreatefromjpeg($sourcePath),
                default => null,
            };

            if ($logo) {
                $lw = imagesx($logo);
                $lh = imagesy($logo);
                $padding = (int)($size * 0.12);
                $destSize = $size - ($padding * 2);
                imagecopyresampled($image, $logo, $padding, $padding, 0, 0, $destSize, $destSize, $lw, $lh);
                imagedestroy($logo);
            }
        } else {
            // "A" harfi
            $white = imagecolorallocate($image, 255, 255, 255);
            $textSize = max(1, min(5, (int)($size / 30)));
            $x = (int)($size * 0.35);
            $y = (int)($size * 0.35);
            imagestring($image, $textSize, $x, $y, 'A', $white);
        }

        imagepng($image, $outputPath, 6);
        imagedestroy($image);
    }

    private function generateScreenshot(string $dir): void
    {
        $image = imagecreatetruecolor(390, 844);
        $bg = imagecolorallocate($image, 15, 23, 42);
        imagefill($image, 0, 0, $bg);

        // Gradient header
        for ($y = 0; $y < 120; $y++) {
            $ratio = $y / 120;
            $r = (int)(99  + (139 - 99)  * $ratio);
            $g = (int)(102 + (92  - 102) * $ratio);
            $b = (int)(241 + (246 - 241) * $ratio);
            $color = imagecolorallocate($image, $r, $g, $b);
            imageline($image, 0, $y, 390, $y, $color);
        }

        $white = imagecolorallocate($image, 255, 255, 255);
        imagestring($image, 5, 140, 50, 'AISOQQA', $white);

        imagepng($image, $dir . '/screenshot-mobile.png', 6);
        imagedestroy($image);
    }
}
