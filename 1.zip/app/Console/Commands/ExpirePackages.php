<?php

namespace App\Console\Commands;

use App\Models\Package\Purchase;
use Illuminate\Console\Command;

class ExpirePackages extends Command
{
    protected $signature = 'packages:expire';
    protected $description = 'Muddati tugagan paketlarni expired ga o\'zgartirish';

    public function handle(): int
    {
        $expired = Purchase::where('status', 'active')
            ->where('expires_at', '<', now()->toDateString())
            ->update(['status' => 'expired']);

        $this->info("✅ {$expired} ta paket muddati tugadi.");
        return self::SUCCESS;
    }
}
