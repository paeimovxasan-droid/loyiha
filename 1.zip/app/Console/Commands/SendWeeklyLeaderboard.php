<?php

namespace App\Console\Commands;

use App\Services\TelegramChannelService;
use Illuminate\Console\Command;

class SendWeeklyLeaderboard extends Command
{
    protected $signature = 'telegram:weekly-leaderboard';
    protected $description = 'Haftalik TOP 3 postini Telegram kanalga yuborish';

    public function handle(): int
    {
        TelegramChannelService::sendWeeklyLeaderboard();
        $this->info('Haftalik leaderboard posti yuborildi.');
        return self::SUCCESS;
    }
}
