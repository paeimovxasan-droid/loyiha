<?php

namespace App\Console\Commands;

use App\Models\Game\LuckyDraw;
use App\Models\Game\LuckyDrawTicket;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class LuckyDrawProcess extends Command
{
    protected $signature   = 'lucky-draw:process';
    protected $description = 'Vaqti kelgan Lucky Draw o\'yinlarini avtomatik yakunlash va g\'olib tanlash';

    public function handle(): int
    {
        // Vaqti o'tgan faol o'yinlarni topish
        $draws = LuckyDraw::where('status', 'active')
            ->where('draw_at', '<=', now())
            ->get();

        if ($draws->isEmpty()) {
            $this->line('Yakunlanishi kerak bo\'lgan o\'yin topilmadi.');
            return self::SUCCESS;
        }

        foreach ($draws as $draw) {
            $tickets = LuckyDrawTicket::where('lucky_draw_id', $draw->id)->get();

            if ($tickets->isEmpty()) {
                // Chipta sotilmagan — o'yinni bekor qilish
                $draw->update(['status' => 'completed']);
                $this->warn("O'yin #{$draw->id} — chipta yo'q, bekor qilindi.");
                continue;
            }

            try {
                DB::transaction(function () use ($draw, $tickets) {
                    // Har bir chipta alohida slot
                    $slots = [];
                    foreach ($tickets as $ticket) {
                        for ($i = 0; $i < $ticket->quantity; $i++) {
                            $slots[] = $ticket->user_id;
                        }
                    }

                    $winnerId    = $slots[array_rand($slots)];
                    $winnerPrize = $draw->calcWinnerPrize();

                    // G'olibga mukofot berish
                    $winner = User::lockForUpdate()->find($winnerId);
                    $winner->increment('balance', $winnerPrize);

                    // Tiket belgilash
                    LuckyDrawTicket::where('lucky_draw_id', $draw->id)
                        ->where('user_id', $winnerId)
                        ->first()
                        ?->update(['is_winner' => true, 'prize_won' => $winnerPrize]);

                    // Draw natijasi
                    $draw->update([
                        'status'       => 'completed',
                        'winner_id'    => $winnerId,
                        'winner_prize' => $winnerPrize,
                        'drawn_at'     => now(),
                    ]);

                    // Tranzaksiya
                    $winner->transactions()->create([
                        'amount'      => $winnerPrize,
                        'type'        => 'lucky_draw',
                        'direction'   => 'credit',
                        'status'      => 'completed',
                        'description' => "Lucky Draw g'olibi: {$draw->getTranslation('name', 'uz')}",
                    ]);

                    // Telegram bildirishnoma
                    try {
                        \App\Services\TelegramBotService::notify(
                            $winner,
                            "🎉 Tabriklaymiz! Siz Lucky Draw'da g'olib bo'ldingiz!\n\n" .
                            "🎰 O'yin: {$draw->getTranslation('name', 'uz')}\n" .
                            "💰 Mukofot: " . number_format($winnerPrize, 2) . " UZS\n\n" .
                            "Mukofot balansingizga o'tkazildi! 🚀",
                            [[['text' => '💰 Balansni ko\'rish', 'url' => config('app.url') . '/app/deposit']]]
                        );
                    } catch (\Throwable $e) {
                        Log::warning('LuckyDraw cron notify failed', ['error' => $e->getMessage()]);
                    }
                });

                $this->info("✅ O'yin #{$draw->id} yakunlandi. G'olib: user #{$draw->fresh()->winner_id}");

            } catch (\Throwable $e) {
                Log::error("LuckyDraw process failed for draw #{$draw->id}", ['error' => $e->getMessage()]);
                $this->error("❌ O'yin #{$draw->id} xatolik: " . $e->getMessage());
            }
        }

        return self::SUCCESS;
    }
}
