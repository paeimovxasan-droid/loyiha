<?php

namespace App\Console\Commands;

use App\Models\Exchange\ExchangeTrade;
use App\Models\Exchange\OhlcvCandle;
use Carbon\Carbon;
use Illuminate\Console\Command;

class OhlcvAggregate extends Command
{
    protected $signature = 'ohlcv:aggregate';
    protected $description = 'OHLCV candlestick ma\'lumotlarini hisoblash va yangilash';

    public function handle(): int
    {
        $this->aggregateInterval('1h', now()->subHour()->startOfHour(), now()->startOfHour());

        if (now()->hour === 0) {
            $this->aggregateInterval('1d', now()->subDay()->startOfDay(), now()->startOfDay());
        }

        if (now()->dayOfWeek === Carbon::MONDAY && now()->hour === 0) {
            $this->aggregateInterval('1w', now()->subWeek()->startOfWeek(), now()->startOfWeek());
        }

        if (now()->day === 1 && now()->hour === 0) {
            $this->aggregateInterval('1M', now()->subMonth()->startOfMonth(), now()->startOfMonth());
        }

        $this->info('OHLCV aggregation completed.');
        return self::SUCCESS;
    }

    private function aggregateInterval(string $interval, Carbon $from, Carbon $to): void
    {
        // ->get() o'rniga DB aggregatsiya — xotiraga yuklamasdan
        $stats = ExchangeTrade::whereBetween('created_at', [$from, $to])
            ->selectRaw('
                COUNT(*) as trade_count,
                MIN(price) as low,
                MAX(price) as high,
                SUM(amount) as volume,
                SUM(total) as volume_uzs
            ')
            ->first();

        if (!$stats || $stats->trade_count == 0) {
            return;
        }

        // open va close uchun faqat bitta qiymat kerak — ->value() ishlatamiz
        $open  = (float) ExchangeTrade::whereBetween('created_at', [$from, $to])
            ->orderBy('created_at')->value('price');
        $close = (float) ExchangeTrade::whereBetween('created_at', [$from, $to])
            ->orderByDesc('created_at')->value('price');

        OhlcvCandle::updateOrCreate(
            ['interval' => $interval, 'open_time' => $from],
            [
                'open'        => $open,
                'high'        => (float) $stats->high,
                'low'         => (float) $stats->low,
                'close'       => $close,
                'volume'      => (float) $stats->volume,
                'volume_uzs'  => (float) $stats->volume_uzs,
                'trade_count' => (int) $stats->trade_count,
            ]
        );

        $this->line("  [{$interval}] {$from->toDateTimeString()} — {$stats->trade_count} trades");
    }
}
