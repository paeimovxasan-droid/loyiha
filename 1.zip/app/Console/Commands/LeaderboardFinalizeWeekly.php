<?php

namespace App\Console\Commands;

use App\Models\Marketing\LeaderboardCompetition;
use App\Services\Marketing\LeaderboardService;
use Illuminate\Console\Command;

class LeaderboardFinalizeWeekly extends Command
{
    protected $signature = 'leaderboard:finalize-weekly';

    protected $description = 'Haftalik musobaqani tugatish va mukofot berish';

    public function handle(): int
    {
        $competitions = LeaderboardCompetition::active()
            ->where('period', 'weekly')
            ->where('ends_at', '<=', now())
            ->get();

        foreach ($competitions as $competition) {
            LeaderboardService::finalizeCompetition($competition);
            $this->info("Haftalik musobaqa #{$competition->id} yakunlandi.");
        }

        if ($competitions->isEmpty()) {
            $this->info('Yakunlanishi kerak bo\'lgan haftalik musobaqa topilmadi.');
        }

        return self::SUCCESS;
    }
}
