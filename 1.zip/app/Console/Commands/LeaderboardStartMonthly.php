<?php

namespace App\Console\Commands;

use App\Services\Marketing\LeaderboardService;
use Illuminate\Console\Command;

class LeaderboardStartMonthly extends Command
{
    protected $signature = 'leaderboard:start-monthly';

    protected $description = 'Yangi oylik musobaqa boshlash';

    public function handle(): int
    {
        $competition = LeaderboardService::startCompetition('monthly', 'referral');

        $this->info("Oylik musobaqa boshlandi: #{$competition->id}");

        return self::SUCCESS;
    }
}
