<?php

namespace App\Console\Commands;

use App\Models\Finance\Transaction;
use App\Models\Investment\FundInvest;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ExpireFunds extends Command
{
    protected $signature = 'funds:expire';
    protected $description = 'Muddati tugagan fond investitsiyalarini yakunlash va foydani qaytarish';

    public function handle(): int
    {
        $matured = FundInvest::with(['user', 'fund'])
            ->where('status', 'active')
            ->where('expires_at', '<=', now()->toDateString())
            ->get();

        $processed = 0;

        foreach ($matured as $invest) {
            try {
                DB::transaction(function () use ($invest, &$processed) {
                    // Lock bilan qayta o'qish — parallel run oldini olish
                    $invest = FundInvest::lockForUpdate()->find($invest->id);

                    if (!$invest || $invest->status !== 'active') {
                        return;
                    }

                    $user = User::lockForUpdate()->find($invest->user_id);
                    if (!$user) return;

                    $totalReturn  = (float) $invest->amount + (float) $invest->expected_profit;
                    $balanceBefore = (float) $user->balance;

                    $user->increment('balance', $totalReturn);

                    $invest->update(['status' => 'matured']);

                    Transaction::create([
                        'user_id'              => $user->id,
                        'type'                 => 'fund',
                        'transactionable_type' => FundInvest::class,
                        'transactionable_id'   => $invest->id,
                        'description'          => $invest->fund?->getTranslation('name', 'uz') . ' — investitsiya qaytarildi + foyda',
                        'amount'               => $totalReturn,
                        'balance_before'       => $balanceBefore,
                        'balance_after'        => $balanceBefore + $totalReturn,
                        'direction'            => 'credit',
                        'status'               => 'completed',
                    ]);

                    $processed++;
                });
            } catch (\Throwable $e) {
                Log::error('ExpireFunds xato', [
                    'invest_id' => $invest->id,
                    'error'     => $e->getMessage(),
                ]);
            }
        }

        $this->info("✅ {$processed} ta fond investitsiyasi yakunlandi.");
        return self::SUCCESS;
    }
}
