<?php

namespace App\Console\Commands;

use App\Models\Marketing\LeaderboardCompetition;
use App\Services\Marketing\LeaderboardService;
use Illuminate\Console\Command;

class LeaderboardFinalizeMonthly extends Command
{
    protected $signature = 'leaderboard:finalize-monthly';

    protected $description = 'Oylik musobaqani tugatish va mukofot berish';

    public function handle(): int
    {
        $competitions = LeaderboardCompetition::active()
            ->where('period', 'monthly')
            ->where('ends_at', '<=', now())
            ->get();

        foreach ($competitions as $competition) {
            LeaderboardService::finalizeCompetition($competition);
            $this->info("Oylik musobaqa #{$competition->id} yakunlandi.");
        }

        if ($competitions->isEmpty()) {
            $this->info('Yakunlanishi kerak bo\'lgan oylik musobaqa topilmadi.');
        }

        return self::SUCCESS;
    }
}
