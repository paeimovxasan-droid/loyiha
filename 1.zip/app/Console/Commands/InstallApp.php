<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;

class InstallApp extends Command
{
    protected $signature   = 'app:install {--fresh : Mavjud ma\'lumotlarni o\'chirib qayta o\'rnatish}';
    protected $description = 'AISOQQA platformasini o\'rnatish (migrate + seed + storage:link)';

    public function handle(): int
    {
        $this->newLine();
        $this->line('  <fg=bright-magenta>
   █████╗ ██╗███████╗ ██████╗  ██████╗  ██████╗  █████╗
  ██╔══██╗██║██╔════╝██╔═══██╗██╔═══██╗██╔═══██╗██╔══██╗
  ███████║██║███████╗██║   ██║██║   ██║██║   ██║███████║
  ██╔══██║██║╚════██║██║   ██║██║▄▄ ██║██║▄▄ ██║██╔══██║
  ██║  ██║██║███████║╚██████╔╝╚██████╔╝╚██████╔╝██║  ██║
  ╚═╝  ╚═╝╚═╝╚══════╝ ╚═════╝  ╚══▀▀═╝  ╚══▀▀═╝╚═╝  ╚═╝</>');
        $this->newLine();
        $this->line('  <fg=cyan>AISOQQA Platform Installer</> <fg=gray>v1.0.0</>');
        $this->line('  <fg=gray>aisoqqa.uz</>');
        $this->newLine();

        // ── 1. .env tekshirish ───────────────────────────────────────────────
        $this->step('1/7', '.env fayli tekshirilmoqda...');
        if (!file_exists(base_path('.env'))) {
            if (file_exists(base_path('.env.example'))) {
                copy(base_path('.env.example'), base_path('.env'));
                $this->info('  ✅ .env.example dan .env yaratildi.');
            } else {
                $this->error('  ❌ .env fayli topilmadi!');
                return self::FAILURE;
            }
        } else {
            $this->line('  ✅ .env mavjud.');
        }

        // ── 2. APP_KEY ───────────────────────────────────────────────────────
        $this->step('2/7', 'APP_KEY generatsiya qilinmoqda...');
        if (empty(config('app.key'))) {
            Artisan::call('key:generate', ['--force' => true]);
            $this->line('  ✅ APP_KEY yaratildi.');
        } else {
            $this->line('  ✅ APP_KEY mavjud.');
        }

        // ── 3. DB ulanish tekshirish ─────────────────────────────────────────
        $this->step('3/7', 'Ma\'lumotlar bazasi ulanishi tekshirilmoqda...');
        try {
            DB::connection()->getPdo();
            $this->line('  ✅ DB ulanish muvaffaqiyatli.');
        } catch (\Exception $e) {
            $this->error('  ❌ DB ulanish xatosi: ' . $e->getMessage());
            $this->line('  <fg=yellow>  .env faylida DB_* sozlamalarini to\'g\'rilang.</>');
            return self::FAILURE;
        }

        // ── 4. Migration ─────────────────────────────────────────────────────
        $this->step('4/7', 'Migrationlar ishga tushirilmoqda...');
        if ($this->option('fresh')) {
            if (!$this->confirm('  ⚠️  --fresh: barcha jadvallar o\'chiriladi. Davom etasizmi?')) {
                return self::FAILURE;
            }
            Artisan::call('migrate:fresh', ['--force' => true]);
        } else {
            Artisan::call('migrate', ['--force' => true]);
        }
        $this->line('  ✅ Migrationlar bajarildi.');

        // ── 5. Seed ──────────────────────────────────────────────────────────
        $this->step('5/7', 'Ma\'lumotlar yuklanmoqda (seed)...');
        Artisan::call('db:seed', ['--force' => true]);
        $this->line('  ✅ Seed muvaffaqiyatli bajarildi.');

        // ── 6. Storage link ──────────────────────────────────────────────────
        $this->step('6/7', 'Storage link yaratilmoqda...');
        Artisan::call('storage:link', ['--force' => true]);
        $this->line('  ✅ Storage link yaratildi.');

        // ── 7. Cache ─────────────────────────────────────────────────────────
        $this->step('7/7', 'Cache tozalanmoqda...');
        Artisan::call('config:clear');
        Artisan::call('cache:clear');
        Artisan::call('view:clear');
        $this->line('  ✅ Cache tozalandi.');

        // ── installed marker ─────────────────────────────────────────────────
        file_put_contents(storage_path('installed'), json_encode([
            'installed_at' => now()->toISOString(),
            'version'      => '1.0.0',
        ]));
        $this->line('  ✅ O\'rnatish belgisi yaratildi.');

        // ── Natija ───────────────────────────────────────────────────────────
        $this->newLine();
        $this->line('  <fg=bright-green>🎉 AISOQQA muvaffaqiyatli o\'rnatildi!</>');
        $this->newLine();
        $this->line('  <fg=cyan>Login ma\'lumotlari:</>');
        $this->line('  <fg=gray>┌─────────────────────────────────────────────────────┐</>');
        $this->line('  <fg=gray>│</> Super Admin: <fg=yellow>superadmin@aisoqqa.uz</> | <fg=yellow>Admin@12345</>  <fg=gray>│</>');
        $this->line('  <fg=gray>│</> Admin:       <fg=yellow>admin@aisoqqa.uz</>       | <fg=yellow>Admin@12345</>  <fg=gray>│</>');
        $this->line('  <fg=gray>│</> Test User:   <fg=yellow>user@aisoqqa.uz</>        | <fg=yellow>User@12345</>   <fg=gray>│</>');
        $this->line('  <fg=gray>└─────────────────────────────────────────────────────┘</>');
        $this->newLine();
        $this->line('  <fg=cyan>URL lar:</>');
        $this->line('  Frontend:     <fg=green>http://localhost:8000</>');
        $this->line('  Admin panel:  <fg=green>http://localhost:8000/admin</>');
        $this->newLine();
        $this->line('  Serverni ishga tushirish: <fg=yellow>php artisan serve</>');
        $this->newLine();

        return self::SUCCESS;
    }

    private function step(string $num, string $message): void
    {
        $this->line("  <fg=bright-blue>[{$num}]</> {$message}");
    }
}
