<?php

namespace App\Console\Commands;

use App\Models\Savings\SavingGroup;
use App\Services\Savings\GroupSavingsService;
use Illuminate\Console\Command;

class GroupSavingsProcess extends Command
{
    protected $signature = 'group-savings:process';
    protected $description = 'Jamoaviy jamg\'arma oylik yig\'im va to\'lovlarni amalga oshirish';

    public function handle(): int
    {
        $groups = SavingGroup::where('status', 'active')->get();

        $processed = 0;
        $failed = 0;

        foreach ($groups as $group) {
            try {
                $round = GroupSavingsService::processRound($group);
                if ($round->status === 'completed') {
                    $processed++;
                } else {
                    $failed++;
                }
            } catch (\Exception $e) {
                $this->error("Group #{$group->id}: {$e->getMessage()}");
                $failed++;
            }
        }

        $this->info("Guruhlar: {$processed} muvaffaqiyatli, {$failed} xato");
        return self::SUCCESS;
    }
}
