<?php

namespace App\Console\Commands;

use App\Services\Medical\MedicalService;
use Illuminate\Console\Command;

class MedicalExpireConsultations extends Command
{
    protected $signature = 'medical:expire';
    protected $description = 'Muddati o\'tgan maslahat va uyga chaqirishlarni expire qilish va to\'lovni qaytarish';

    public function handle(): int
    {
        $this->info('Muddati o\'tgan maslahatlar tekshirilmoqda...');

        $expiredConsultations = MedicalService::expireConsultations();
        $this->info("Maslahatlar expire qilindi: {$expiredConsultations}");

        $expiredVisits = MedicalService::expireHomeVisits();
        $this->info("Uyga chaqirishlar expire qilindi: {$expiredVisits}");

        return self::SUCCESS;
    }
}
