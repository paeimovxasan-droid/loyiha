<?php

namespace App\Console\Commands;

use App\Models\Savings\SavingsPlan;
use App\Services\Savings\SavingsService;
use Illuminate\Console\Command;

class SavingsMonthlyProcess extends Command
{
    protected $signature = 'savings:monthly-process';
    protected $description = 'Jamg\'arma oylik to\'lovlarni avtomatik amalga oshirish';

    public function handle(): int
    {
        $plans = SavingsPlan::where('status', 'active')
            ->where('next_payment_date', '<=', now()->toDateString())
            ->get();

        $processed = 0;
        $missed = 0;

        foreach ($plans as $plan) {
            try {
                $payment = SavingsService::processMonthlyPayment($plan);
                if ($payment->status === 'paid') {
                    $processed++;
                } else {
                    $missed++;
                }
            } catch (\Exception $e) {
                $this->error("Plan #{$plan->id}: {$e->getMessage()}");
            }
        }

        $this->info("To'lovlar: {$processed} muvaffaqiyatli, {$missed} missed");
        return self::SUCCESS;
    }
}
