<?php

namespace App\Console\Commands;

use App\Services\Marketing\ChallengeService;
use Illuminate\Console\Command;

class ChallengeExpire extends Command
{
    protected $signature = 'challenge:expire';

    protected $description = 'Muddati o\'tgan invite challenge larni expired holatiga o\'tkazish';

    public function handle(): int
    {
        $count = ChallengeService::expireOverdue();

        $this->info("Expired challenges: {$count}");

        return self::SUCCESS;
    }
}
