<?php

namespace App\Console\Commands;

use App\Models\Savings\SavingsPlan;
use App\Services\Savings\SavingsService;
use Illuminate\Console\Command;

class SavingsFinalize extends Command
{
    protected $signature = 'savings:finalize';
    protected $description = 'Muddati tugagan jamg\'arma rejalarini yakunlash (bonus bilan)';

    public function handle(): int
    {
        $plans = SavingsPlan::where('status', 'active')
            ->whereColumn('paid_months', '>=', 'term_months')
            ->get();

        $finalized = 0;

        foreach ($plans as $plan) {
            try {
                SavingsService::finalizePlan($plan);
                $finalized++;
            } catch (\Exception $e) {
                $this->error("Plan #{$plan->id}: {$e->getMessage()}");
            }
        }

        $this->info("Yakunlangan rejalar: {$finalized}");
        return self::SUCCESS;
    }
}
