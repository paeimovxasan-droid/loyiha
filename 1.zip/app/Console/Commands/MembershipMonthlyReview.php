<?php

namespace App\Console\Commands;

use App\Services\Marketing\MembershipService;
use Illuminate\Console\Command;

class MembershipMonthlyReview extends Command
{
    protected $signature = 'membership:monthly-review';

    protected $description = 'VIP daraja oylik tekshiruv — talablarga mos kelmaydigan foydalanuvchilarni downgrade qilish';

    public function handle(): int
    {
        $count = MembershipService::monthlyReview();

        $this->info("Downgrade qilingan foydalanuvchilar: {$count}");

        return self::SUCCESS;
    }
}
