<?php

namespace App\Console\Commands;

use App\Models\Influencer\InfluencerCampaign;
use Illuminate\Console\Command;

class InfluencerExpireCampaigns extends Command
{
    protected $signature   = 'influencer:expire-campaigns';
    protected $description = 'Tugash sanasi o\'tgan influencer kampaniyalarini completed holatiga o\'tkazish';

    public function handle(): int
    {
        $count = InfluencerCampaign::where('status', InfluencerCampaign::STATUS_ACTIVE)
            ->where('ends_at', '<', now())
            ->update(['status' => InfluencerCampaign::STATUS_COMPLETED]);

        // Byudjeti tugagan active kampaniyalarni ham paused qilish
        $paused = InfluencerCampaign::where('status', InfluencerCampaign::STATUS_ACTIVE)
            ->whereColumn('spent_budget', '>=', 'total_budget')
            ->update(['status' => InfluencerCampaign::STATUS_PAUSED]);

        $this->info("✅ {$count} ta kampaniya completed, {$paused} ta kampaniya paused qilindi.");

        return self::SUCCESS;
    }
}
