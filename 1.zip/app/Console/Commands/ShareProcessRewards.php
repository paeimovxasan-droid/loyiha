<?php

namespace App\Console\Commands;

use App\Models\Marketing\ShareLink;
use App\Services\Marketing\ShareService;
use Illuminate\Console\Command;

class ShareProcessRewards extends Command
{
    protected $signature = 'share:process-rewards';

    protected $description = 'Share-to-earn mukofotlarni hisoblash va berish';

    public function handle(): int
    {
        $shareLinks = ShareLink::whereHas('clicks', function ($query) {
            $query->whereDate('clicked_at', today());
        })->with('user')->get();

        $count = 0;
        foreach ($shareLinks as $shareLink) {
            if ($shareLink->user) {
                ShareService::processRewards($shareLink->user);
                $count++;
            }
        }

        $this->info("Share mukofotlari hisoblandi: {$count} ta foydalanuvchi uchun.");

        return self::SUCCESS;
    }
}
