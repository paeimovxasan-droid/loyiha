<?php

namespace App\Console\Commands;

use App\Services\Marketing\LeaderboardService;
use Illuminate\Console\Command;

class LeaderboardStartWeekly extends Command
{
    protected $signature = 'leaderboard:start-weekly';

    protected $description = 'Yangi haftalik musobaqa boshlash';

    public function handle(): int
    {
        $competition = LeaderboardService::startCompetition('weekly', 'referral');

        $this->info("Haftalik musobaqa boshlandi: #{$competition->id}");

        return self::SUCCESS;
    }
}
