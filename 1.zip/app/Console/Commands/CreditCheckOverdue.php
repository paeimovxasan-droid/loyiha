<?php

namespace App\Console\Commands;

use App\Services\Credit\CreditService;
use Illuminate\Console\Command;

class CreditCheckOverdue extends Command
{
    protected $signature = 'credit:check-overdue';
    protected $description = 'Muddati o\'tgan kreditlarni tekshirish va overdue ga o\'zgartirish';

    public function handle(): int
    {
        $count = CreditService::checkOverdue();
        $this->info("Muddati o'tgan kreditlar: {$count}");
        return self::SUCCESS;
    }
}
