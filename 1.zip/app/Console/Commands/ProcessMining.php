<?php

namespace App\Console\Commands;

use App\Models\Finance\Commission;
use App\Models\Finance\Transaction;
use App\Models\Package\Mining;
use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class ProcessMining extends Command
{
    protected $signature = 'mining:process';
    protected $description = 'Kunlik mining daromadlarini hisoblash va balansga qo\'shish';

    public function handle(): int
    {
        $minings = Mining::with(['user', 'package'])
            ->where('status', 'running')
            ->get();

        $processed = 0;
        $skipped   = 0;

        foreach ($minings as $mining) {
            $user = $mining->user;
            if (!$user || $user->isBanned()) {
                $skipped++;
                continue;
            }

            try {
                $result = DB::transaction(function () use ($mining, $user) {
                    // Mining ni lock bilan qayta o'qish — parallel run oldini olish
                    $mining = Mining::lockForUpdate()->find($mining->id);

                    // Parallel run da allaqachon processed bo'lgan bo'lishi mumkin
                    if (!$mining || $mining->status !== 'running') {
                        return false;
                    }

                    // Muddati tugaganmi tekshirish
                    if ($mining->ended_at && now()->gte($mining->ended_at)) {
                        $mining->update(['status' => 'completed']);
                        $mining->purchase?->update(['status' => 'expired']);
                        return false;
                    }

                    $dailyProfit = (float) $mining->daily_profit;
                    if ($dailyProfit <= 0) {
                        return false;
                    }

                    // User ni lock bilan o'qish — race condition oldini olish
                    $user = User::lockForUpdate()->find($user->id);

                    $balanceBefore = (float) $user->balance;
                    $user->increment('balance', $dailyProfit);
                    $balanceAfter = $balanceBefore + $dailyProfit;

                    $mining->increment('total_earned', $dailyProfit);
                    $mining->increment('completed_hours', 24);

                    Transaction::create([
                        'user_id'              => $user->id,
                        'type'                 => 'mining',
                        'transactionable_type' => Mining::class,
                        'transactionable_id'   => $mining->id,
                        'description'          => $mining->package?->getTranslation('name', 'uz') . ' — kunlik daromad',
                        'amount'               => $dailyProfit,
                        'balance_before'       => $balanceBefore,
                        'balance_after'        => $balanceAfter,
                        'direction'            => 'credit',
                        'status'               => 'completed',
                    ]);

                    // Referral komissiya (transaksiya ichida, lock bilan)
                    $this->processMiningCommissions($user, $mining, $dailyProfit);

                    return true;
                });

                if ($result) {
                    $processed++;
                } else {
                    $skipped++;
                }
            } catch (\Throwable $e) {
                $skipped++;
                Log::error('ProcessMining xato', [
                    'mining_id' => $mining->id,
                    'user_id'   => $user->id,
                    'error'     => $e->getMessage(),
                ]);
            }
        }

        $this->info("✅ {$processed} ta mining daromadi hisoblandi. ⏭ {$skipped} ta o'tkazib yuborildi.");
        return self::SUCCESS;
    }

    private function processMiningCommissions(User $user, Mining $mining, float $dailyProfit): void
    {
        $package = $mining->package;
        if (!$package) return;

        $levels = [
            1 => (float) $package->ref_level1,
            2 => (float) $package->ref_level2,
            3 => (float) $package->ref_level3,
        ];

        $current = $user;

        foreach ($levels as $level => $percent) {
            if ($percent <= 0) continue;

            $referrer = User::where('username', $current->referred_by)->first();
            if (!$referrer || $referrer->isBanned()) break;

            $commissionAmount = round($dailyProfit * $percent / 100, 2);

            if ($commissionAmount > 0) {
                // Referrer ni lock bilan o'qish
                $referrer = User::lockForUpdate()->find($referrer->id);

                Commission::create([
                    'user_id'      => $referrer->id,
                    'from_user_id' => $user->id,
                    'reason'       => 'mining',
                    'level'        => $level,
                    'percent'      => $percent,
                    'amount'       => $commissionAmount,
                    'date'         => now()->toDateString(),
                    'status'       => 'active',
                ]);

                $referrer->increment('balance', $commissionAmount);
            }

            $current = $referrer;
        }
    }
}
