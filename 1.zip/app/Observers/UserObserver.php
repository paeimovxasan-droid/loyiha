<?php

namespace App\Observers;

use App\Models\User;
use App\Models\UserStats;

class UserObserver
{
    public function created(User $user): void
    {
        // Username null bo'lsa avtomatik generatsiya
        if (empty($user->username)) {
            $base     = strtolower(preg_replace('/[^a-z0-9_]/i', '', explode('@', $user->email)[0]));
            $base     = strlen($base) < 3 ? 'user' . $user->id : substr($base, 0, 20);
            $username = $base;
            $counter  = 1;

            while (User::where('username', $username)->where('id', '!=', $user->id)->exists()) {
                $username = $base . $counter++;
            }

            User::where('id', $user->id)->update(['username' => $username]);
        }

        if ($user->referrer_id) {
            $stats = UserStats::firstOrCreate(['user_id' => $user->referrer_id]);
            $stats->increment('referrals_count');
        }
    }

    public function updated(User $user): void
    {
        try {
            if ($user->isDirty('kyc_status') && in_array($user->kyc_status, ['passport_pending', 'face_pending'])) {
                $caption = "🆔 <b>Yangi KYC So'rovi!</b>\n\n" .
                    "👤 <b>Foydalanuvchi:</b> {$user->name} (@{$user->username})\n" .
                    "📝 <b>Status:</b> {$user->kyc_status}\n" .
                    "📅 <b>Vaqt:</b> " . now()->format('H:i:s d.m.Y');

                $buttons = [
                    [
                        ['text' => '✅ Tasdiqlash', 'callback_data' => "approve_kyc_{$user->id}"],
                        ['text' => '❌ Rad etish', 'callback_data' => "reject_kyc_{$user->id}"],
                    ]
                ];

                if ($user->kyc_document) {
                    $path = storage_path('app/' . $user->kyc_document);
                    \App\Services\Telegram\AdminNotificationService::sendPhoto($path, $caption, $buttons);
                } else {
                    \App\Services\Telegram\AdminNotificationService::sendMessage($caption, $buttons);
                }
            }
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('KYC admin notify error: ' . $e->getMessage());
        }
    }
}
