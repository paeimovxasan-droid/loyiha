<?php

namespace App\Observers;

use App\Models\Payment\Withdrawal;
use App\Services\Telegram\AdminNotificationService;

class WithdrawalObserver
{
    public function created(Withdrawal $withdrawal): void
    {
        $user = $withdrawal->user;
        $caption = "💸 <b>Yangi Pul Yechish So'rovi!</b>\n\n" .
            "👤 <b>Foydalanuvchi:</b> {$user->name} (@{$user->username})\n" .
            "💵 <b>Summa:</b> " . number_format($withdrawal->amount) . " UZS\n" .
            "🏦 <b>To'lov usuli:</b> {$withdrawal->method_name}\n" .
            "📅 <b>Vaqt:</b> " . now()->format('H:i:s d.m.Y');

        $buttons = [
            [
                ['text' => '✅ Tasdiqlash', 'callback_data' => "approve_withdrawal_{$withdrawal->id}"],
                ['text' => '❌ Rad etish', 'callback_data' => "reject_withdrawal_{$withdrawal->id}"],
            ]
        ];

        AdminNotificationService::sendMessage($caption, $buttons);
    }
}
