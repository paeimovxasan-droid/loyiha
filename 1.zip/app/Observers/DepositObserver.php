<?php

namespace App\Observers;

use App\Models\Payment\Deposit;
use App\Models\UserStats;

class DepositObserver
{
    public function created(Deposit $deposit): void
    {
        try {
            $user = $deposit->user;
            $caption = "💰 <b>Yangi Depozit So'rovi!</b>\n\n" .
                "👤 <b>Foydalanuvchi:</b> {$user->name} (@{$user->username})\n" .
                "💵 <b>Summa:</b> " . number_format($deposit->amount) . " UZS\n" .
                "🏦 <b>To'lov usuli:</b> {$deposit->method_name}\n" .
                "📅 <b>Vaqt:</b> " . now()->format('H:i:s d.m.Y');

            $buttons = [
                [
                    ['text' => '✅ Tasdiqlash', 'callback_data' => "approve_deposit_{$deposit->id}"],
                    ['text' => '❌ Rad etish', 'callback_data' => "reject_deposit_{$deposit->id}"],
                ]
            ];

            if ($deposit->screenshot) {
                $path = storage_path('app/public/' . $deposit->screenshot);
                \App\Services\Telegram\AdminNotificationService::sendPhoto($path, $caption, $buttons);
            } else {
                \App\Services\Telegram\AdminNotificationService::sendMessage($caption, $buttons);
            }
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Deposit admin notify error: ' . $e->getMessage());
        }
    }

    public function updated(Deposit $deposit): void
    {
        // Agar status 'approved' ga o'zgarsa, statistikani yangilash
        if ($deposit->isDirty('status') && $deposit->status === 'approved') {
            $stats = UserStats::firstOrCreate(['user_id' => $deposit->user_id]);
            $stats->increment('total_deposit_uzs', (float) $deposit->amount);
        }
    }
}
