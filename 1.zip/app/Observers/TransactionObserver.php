<?php

namespace App\Observers;

use App\Models\Finance\Transaction;
use App\Models\UserStats;

class TransactionObserver
{
    public function created(Transaction $transaction): void
    {
        if ($transaction->type === 'mining' && $transaction->direction === 'credit') {
            $stats = UserStats::firstOrCreate(['user_id' => $transaction->user_id]);
            $stats->increment('total_earn_ais', (float) $transaction->amount);
        }
    }
}
