<?php

namespace App\Observers;

use App\Models\Game\UserTask;
use App\Services\Telegram\AdminNotificationService;

class UserTaskObserver
{
    public function created(UserTask $userTask): void
    {
        $user = $userTask->user;
        $task = $userTask->task;
        
        $caption = "🎯 <b>Yangi Vazifa Isboti!</b>\n\n" .
            "👤 <b>Foydalanuvchi:</b> {$user->name} (@{$user->username})\n" .
            "📝 <b>Vazifa:</b> {$task->title}\n" .
            "📅 <b>Vaqt:</b> " . now()->format('H:i:s d.m.Y');

        $buttons = [
            [
                ['text' => '✅ Tasdiqlash', 'callback_data' => "approve_task_{$userTask->id}"],
                ['text' => '❌ Rad etish', 'callback_data' => "reject_task_{$userTask->id}"],
            ]
        ];

        if ($userTask->proof_file) {
            $path = storage_path('app/public/' . $userTask->proof_file);
            AdminNotificationService::sendPhoto($path, $caption, $buttons);
        } else {
            AdminNotificationService::sendMessage($caption, $buttons);
        }
    }
}
