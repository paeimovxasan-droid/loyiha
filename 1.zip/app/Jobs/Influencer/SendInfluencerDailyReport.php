<?php

namespace App\Jobs\Influencer;

use App\Models\Influencer\InfluencerReward;
use App\Models\Influencer\InfluencerSubmission;
use App\Services\TelegramBotService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class SendInfluencerDailyReport implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function handle(): void
    {
        $today = today();

        $newSubmissions      = InfluencerSubmission::whereDate('created_at', $today)->count();
        $approvedSubmissions = InfluencerSubmission::whereDate('reviewed_at', $today)
            ->where('status', InfluencerSubmission::STATUS_APPROVED)->count();
        $rejectedSubmissions = InfluencerSubmission::whereDate('reviewed_at', $today)
            ->where('status', InfluencerSubmission::STATUS_REJECTED)->count();
        $pendingSubmissions  = InfluencerSubmission::where('status', InfluencerSubmission::STATUS_PENDING)->count();
        $spentToday          = InfluencerReward::whereDate('created_at', $today)->sum('amount');

        $message = "📊 Influencer Ad Network — Kunlik Hisobot\n";
        $message .= "📅 " . $today->format('d.m.Y') . "\n\n";
        $message .= "📋 Yangi submissionlar: {$newSubmissions}\n";
        $message .= "✅ Tasdiqlangan: {$approvedSubmissions}\n";
        $message .= "❌ Rad etilgan: {$rejectedSubmissions}\n";
        $message .= "⏳ Kutilayotgan (jami): {$pendingSubmissions}\n";
        $message .= "💰 Bugun sarflangan: " . number_format($spentToday, 2) . " AIS\n";

        try {
            TelegramBotService::notifyAdmin($message);
        } catch (\Throwable $e) {
            Log::warning('SendInfluencerDailyReport failed', ['error' => $e->getMessage()]);
        }
    }
}
