<?php

namespace App\Jobs\Influencer;

use App\Models\Influencer\InfluencerSubmission;
use App\Models\User;
use App\Services\Influencer\InfluencerRewardService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ProcessInfluencerReward implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $timeout = 60;

    public function __construct(
        public readonly int $submissionId
    ) {}

    public function handle(): void
    {
        $submission = InfluencerSubmission::find($this->submissionId);

        if (!$submission || !$submission->isApproved()) {
            Log::warning("ProcessInfluencerReward: submission #{$this->submissionId} topilmadi yoki approved emas.");
            return;
        }

        try {
            InfluencerRewardService::pay($submission);
            Log::info("ProcessInfluencerReward: submission #{$this->submissionId} mukofot berildi.");
        } catch (\Throwable $e) {
            $submission->update(['status' => \App\Models\Influencer\InfluencerSubmission::STATUS_REWARD_FAILED]);
            Log::error("ProcessInfluencerReward: xatolik", [
                'submission_id' => $this->submissionId,
                'error'         => $e->getMessage(),
            ]);
            throw $e;
        }
    }
}
