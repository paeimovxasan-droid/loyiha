<?php

namespace App\Jobs\Influencer;

use App\Models\Influencer\InfluencerSubmission;
use App\Models\User;
use App\Services\Influencer\InfluencerSubmissionService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class BulkApproveSubmissions implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $tries = 3;
    public int $timeout = 300;

    public function __construct(
        public readonly array $submissionIds,
        public readonly int $adminId
    ) {}

    public function handle(): void
    {
        $admin = User::find($this->adminId);
        if (!$admin) return;

        foreach ($this->submissionIds as $id) {
            $submission = InfluencerSubmission::find($id);
            if (!$submission || !$submission->isPending()) continue;

            try {
                InfluencerSubmissionService::approve($submission, $admin);
                Log::info("Bulk approve: submission #{$id} tasdiqlandi.");
            } catch (\Throwable $e) {
                Log::error("Bulk approve: submission #{$id} xatolik", ['error' => $e->getMessage()]);
            }
        }
    }
}
