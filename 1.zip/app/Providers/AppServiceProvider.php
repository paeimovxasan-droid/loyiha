<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}

    public function boot(): void
    {
        // HTTPS majburiy qilish
        if (config('app.env') === 'production') {
            \Illuminate\Support\Facades\URL::forceScheme('https');
        }

        // Observerlarni ro'yxatdan o'tkazish
        \App\Models\User::observe(\App\Observers\UserObserver::class);
        \App\Models\Finance\Transaction::observe(\App\Observers\TransactionObserver::class);
        \App\Models\Payment\Deposit::observe(\App\Observers\DepositObserver::class);

        // Admin Telegram Notifications (Xatolik bo'lsa ham sayt ishlayveradi)
        try {
            \App\Models\Payment\Withdrawal::observe(\App\Observers\WithdrawalObserver::class);
            \App\Models\Game\UserTask::observe(\App\Observers\UserTaskObserver::class);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Admin observer error: ' . $e->getMessage());
        }

        \Illuminate\Support\Facades\View::composer('*', function ($view) {
            // Installer sahifasida DB ga murojaat qilmaymiz
            if (request()->is('install') || request()->is('install/*')) {
                $view->with('global_setting', (object)[
                    'logo_url'    => asset('images/logo.svg'),
                    'favicon_url' => asset('images/favicon.svg'),
                ]);
                $view->with('setting', (object)[
                    'logo_url'    => asset('images/logo.svg'),
                    'favicon_url' => asset('images/favicon.svg'),
                ]);
                return;
            }

            try {
                $setting = \Illuminate\Support\Facades\Cache::remember('app_settings', 300, function () {
                    return \App\Models\Setting::get();
                });
            } catch (\Exception $e) {
                // Xato bo'lganda ham metodlar ishlashi uchun Setting modelidan foydalanamiz
                $setting = new \App\Models\Setting([
                    'site_name'   => config('app.name'),
                    'logo_url'    => asset('images/logo.svg'),
                    'favicon_url' => asset('images/favicon.svg'),
                ]);
            }
            $view->with('global_setting', $setting);
            $view->with('setting', $setting);
        });
    }
}
