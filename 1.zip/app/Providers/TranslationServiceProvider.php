<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Translation\Translator;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;

class TranslationServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        $this->app->extend('translator', function (Translator $translator) {
            // Installer sahifasida tarjimalar kerak emas
            if (request()->is('install') || request()->is('install/*')) {
                return $translator;
            }

            try {
                $rows = Cache::remember('db_translations', 3600, function () {
                    if (!Schema::hasTable('translations')) return collect();
                    return \App\Models\Translation::all()->groupBy('group');
                });
            } catch (\Exception $e) {
                return $translator;
            }

            foreach ($rows as $group => $items) {
                foreach ($items as $item) {
                    foreach (['uz', 'ru', 'en'] as $locale) {
                        $text = $item->text[$locale] ?? null;
                        if ($text !== null) {
                            $lineKey = $group ? "{$group}.{$item->key}" : $item->key;
                            $translator->addLines([$lineKey => $text], $locale);
                        }
                    }
                }
            }

            return $translator;
        });
    }
}
