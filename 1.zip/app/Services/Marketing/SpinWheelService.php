<?php

namespace App\Services\Marketing;

use App\Models\AIS\Wallet;
use App\Models\Game\LuckyDraw;
use App\Models\Game\LuckyDrawTicket;
use App\Models\Level\XpLog;
use App\Models\Marketing\SpinWheelLog;
use App\Models\Marketing\SpinWheelPrize;
use App\Models\User;
use App\Services\XpService;
use Illuminate\Support\Facades\DB;

class SpinWheelService
{
    /**
     * Bugun aylantirish mumkinmi tekshirish
     */
    public static function canSpin(User $user): bool
    {
        return !SpinWheelLog::where('user_id', $user->id)
            ->where('spun_at', today())
            ->exists();
    }

    /**
     * G'ildirakni aylantirish
     *
     * @throws \Exception
     */
    public static function spin(User $user): array
    {
        if (!static::canSpin($user)) {
            throw new \Exception('Bugun allaqachon aylantirgansiz, ertaga qaytib keling.');
        }

        return DB::transaction(function () use ($user) {
            // Qayta tekshirish (race condition oldini olish)
            if (SpinWheelLog::where('user_id', $user->id)->where('spun_at', today())->exists()) {
                throw new \Exception('Bugun allaqachon aylantirgansiz, ertaga qaytib keling.');
            }

            $prize = static::selectPrize();

            // Mukofot turga qarab berish
            static::awardPrize($user, $prize);

            // Logga yozish
            SpinWheelLog::create([
                'user_id'             => $user->id,
                'spin_wheel_prize_id' => $prize->id,
                'prize_type'          => $prize->type,
                'prize_value'         => $prize->value,
                'spun_at'             => today(),
                'created_at'          => now(),
            ]);

            return [
                'prize_type'  => $prize->type,
                'prize_value' => (float) $prize->value,
                'prize_label' => $prize->label,
                'next_spin_at' => today()->addDay()->toDateTimeString(),
            ];
        });
    }

    /**
     * Weighted random algorithm bilan mukofot tanlash
     */
    private static function selectPrize(): SpinWheelPrize
    {
        $prizes = SpinWheelPrize::active()->get();

        if ($prizes->isEmpty()) {
            throw new \Exception('Mukofotlar sozlanmagan.');
        }

        $totalWeight = (int) $prizes->sum('weight');

        // Barcha weightlar 0 bo'lsa — random_int(1, 0) ValueError tashlaydi
        if ($totalWeight <= 0) {
            // Weight sozlanmagan — tasodifiy mukofot qaytaramiz
            return $prizes->random();
        }

        $random = random_int(1, $totalWeight);

        $cumulative = 0;
        foreach ($prizes as $prize) {
            $cumulative += (int) $prize->weight;
            if ($random <= $cumulative) {
                return $prize;
            }
        }

        // Fallback — oxirgi mukofot
        return $prizes->last();
    }

    /**
     * Mukofotni turga qarab berish
     */
    private static function awardPrize(User $user, SpinWheelPrize $prize): void
    {
        match ($prize->type) {
            'ais' => static::awardAis($user, $prize),
            'xp' => static::awardXp($user, $prize),
            'lucky_ticket' => static::awardLuckyTicket($user),
            'nothing' => null, // Hech narsa
            default => null,
        };
    }

    private static function awardAis(User $user, SpinWheelPrize $prize): void
    {
        $wallet = Wallet::firstOrCreate(
            ['user_id' => $user->id],
            ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
        );
        $wallet->increment('balance', $prize->value);
    }

    private static function awardXp(User $user, SpinWheelPrize $prize): void
    {
        XpService::award(
            $user,
            XpLog::ACTION_SPIN_WHEEL,
            (int) $prize->value,
            'Kunlik g\'ildirak mukofoti'
        );
    }

    private static function awardLuckyTicket(User $user): void
    {
        $activeDraw = LuckyDraw::active()->orderBy('draw_at')->first();

        if ($activeDraw) {
            LuckyDrawTicket::create([
                'user_id'       => $user->id,
                'lucky_draw_id' => $activeDraw->id,
                'quantity'      => 1,
                'total_paid'    => 0,
                'is_winner'     => false,
                'prize_won'     => 0,
            ]);
        }
    }
}
