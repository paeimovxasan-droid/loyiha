<?php

namespace App\Services\Marketing;

use App\Models\AIS\Wallet;
use App\Models\Level\XpLog;
use App\Models\Marketing\PromoCode;
use App\Models\Marketing\PromoCodeUse;
use App\Models\User;
use App\Services\WalletService;
use App\Services\XpService;
use Illuminate\Support\Facades\DB;

class PromoService
{
    /**
     * Admin uchun promo-kod yaratish
     */
    public static function create(array $data): PromoCode
    {
        return PromoCode::create([
            'code'           => strtoupper($data['code']),
            'reward_ais'     => $data['reward_ais'] ?? 0,
            'reward_xp'      => $data['reward_xp'] ?? 0,
            'max_uses'       => $data['max_uses'] ?? null,
            'starts_at'      => $data['starts_at'] ?? null,
            'expires_at'     => $data['expires_at'] ?? null,
            'new_users_only' => $data['new_users_only'] ?? false,
            'new_user_hours' => $data['new_user_hours'] ?? 24,
            'status'         => $data['status'] ?? 'active',
        ]);
    }

    /**
     * Promo-kodni tekshirish va ishlatish
     *
     * @throws \Exception
     */
    public static function redeem(User $user, string $code): array
    {
        return DB::transaction(function () use ($user, $code) {
            $promo = PromoCode::where('code', strtoupper(trim($code)))->first();

            // 1. Mavjudlik tekshirish
            if (!$promo || $promo->status !== 'active') {
                throw new \Exception('Promo-kod yaroqsiz yoki muddati o\'tgan.');
            }

            // 2. Muddat tekshirish
            if ($promo->starts_at && $promo->starts_at->isFuture()) {
                throw new \Exception('Promo-kod yaroqsiz yoki muddati o\'tgan.');
            }

            if ($promo->expires_at && $promo->expires_at->isPast()) {
                throw new \Exception('Promo-kod yaroqsiz yoki muddati o\'tgan.');
            }

            // 3. Max uses tekshirish
            if ($promo->max_uses !== null && $promo->used_count >= $promo->max_uses) {
                throw new \Exception('Promo-kod yaroqsiz yoki muddati o\'tgan.');
            }

            // 4. Avval ishlatilganlik tekshirish
            $alreadyUsed = PromoCodeUse::where('promo_code_id', $promo->id)
                ->where('user_id', $user->id)
                ->exists();

            if ($alreadyUsed) {
                throw new \Exception('Siz bu promo-kodni allaqachon ishlatgansiz.');
            }

            // 5. new_users_only tekshirish
            if ($promo->new_users_only) {
                $hours = $promo->new_user_hours ?? 24;
                if ($user->created_at->diffInHours(now()) > $hours) {
                    throw new \Exception('Bu promo-kod faqat yangi foydalanuvchilar uchun.');
                }
            }

            // AIS mukofot berish
            if ($promo->reward_ais > 0) {
                $wallet = Wallet::firstOrCreate(
                    ['user_id' => $user->id],
                    ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
                );
                $wallet->increment('balance', $promo->reward_ais);
            }

            // XP mukofot berish
            if ($promo->reward_xp > 0) {
                XpService::award(
                    $user,
                    XpLog::ACTION_PROMO,
                    $promo->reward_xp,
                    'Promo-kod: ' . $promo->code
                );
            }

            // Tarixga yozish
            PromoCodeUse::create([
                'promo_code_id' => $promo->id,
                'user_id'       => $user->id,
                'reward_ais'    => $promo->reward_ais,
                'reward_xp'     => $promo->reward_xp,
                'created_at'    => now(),
            ]);

            // used_count oshirish
            $promo->increment('used_count');

            return [
                'ais' => (float) $promo->reward_ais,
                'xp'  => (int) $promo->reward_xp,
            ];
        });
    }

    /**
     * Promo-kod statistikasi
     */
    public static function stats(PromoCode $promo): array
    {
        $totalUses = $promo->used_count;
        $remaining = $promo->max_uses !== null
            ? max(0, $promo->max_uses - $promo->used_count)
            : null;
        $totalAisGiven = PromoCodeUse::where('promo_code_id', $promo->id)->sum('reward_ais');

        return [
            'total_uses'      => $totalUses,
            'remaining'       => $remaining,
            'total_ais_given' => (float) $totalAisGiven,
            'users'           => PromoCodeUse::where('promo_code_id', $promo->id)
                ->with('user:id,name,username')
                ->latest('created_at')
                ->get(),
        ];
    }
}
