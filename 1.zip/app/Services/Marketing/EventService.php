<?php

namespace App\Services\Marketing;

use App\Models\AIS\Wallet;
use App\Models\Marketing\LeaderboardEntry;
use App\Models\Marketing\SeasonalEvent;
use App\Models\Marketing\SeasonalEventQuest;
use App\Models\User;
use App\Services\TelegramChannelService;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class EventService
{
    /**
     * Tadbir yaratish (admin)
     */
    public static function create(array $data): SeasonalEvent
    {
        return DB::transaction(function () use ($data) {
            $event = SeasonalEvent::create([
                'name'        => $data['name'],
                'description' => $data['description'] ?? '',
                'banner'      => $data['banner'] ?? null,
                'starts_at'   => $data['starts_at'],
                'ends_at'     => $data['ends_at'],
                'prizes'      => $data['prizes'] ?? [],
                'status'      => $data['status'] ?? 'active',
            ]);

            // Kvestlarni bog'lash
            if (!empty($data['quests'])) {
                foreach ($data['quests'] as $index => $questId) {
                    SeasonalEventQuest::create([
                        'event_id'   => $event->id,
                        'quest_id'   => $questId,
                        'sort_order' => $index + 1,
                        'created_at' => now(),
                    ]);
                }
            }

            return $event->load('quests');
        });
    }

    /**
     * Aktiv tadbirlar
     */
    public static function getActive(): Collection
    {
        return SeasonalEvent::active()
            ->with('quests')
            ->orderBy('ends_at')
            ->get();
    }

    /**
     * Tadbir tugashi va g'oliblarni aniqlash (scheduled)
     */
    public static function finalize(SeasonalEvent $event): void
    {
        DB::transaction(function () use ($event) {
            $event = SeasonalEvent::lockForUpdate()->find($event->id);

            if ($event->status !== 'active') {
                return;
            }

            $event->update(['status' => 'finalized']);

            $prizes = $event->prizes ?? [];

            // Tadbir kvestlarini tugatgan foydalanuvchilarni aniqlash
            // Quest progress asosida g'oliblarni topish
            $questIds = $event->quests()->pluck('quests.id');

            if ($questIds->isEmpty()) {
                return;
            }

            // Eng ko'p kvestni tugatgan foydalanuvchilar
            $topUsers = DB::table('user_quests')
                ->whereIn('quest_id', $questIds)
                ->where('status', 'completed')
                ->select('user_id', DB::raw('COUNT(*) as completed_count'))
                ->groupBy('user_id')
                ->orderByDesc('completed_count')
                ->limit(count($prizes) > 0 ? count($prizes) : 10)
                ->get();

            $winnersText = [];

            foreach ($topUsers as $index => $row) {
                $prizeAis = $prizes[$index]['ais'] ?? 0;

                if ($prizeAis > 0) {
                    $wallet = Wallet::firstOrCreate(
                        ['user_id' => $row->user_id],
                        ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
                    );
                    $wallet->increment('balance', $prizeAis);
                }

                $user = User::find($row->user_id);
                if ($user) {
                    $rank = $index + 1;
                    $emoji = match ($rank) {
                        1 => '🥇', 2 => '🥈', 3 => '🥉', default => "#{$rank}",
                    };
                    $winnersText[] = "{$emoji} <b>{$user->name}</b> — {$row->completed_count} kvest, {$prizeAis} AIS";
                }
            }

            // Telegram kanalga natijalarni yuborish
            if (!empty($winnersText)) {
                $eventName = $event->getTranslation('name', 'uz');
                $text = "🎉 <b>\"{$eventName}\" tadbiri yakunlandi!</b>\n\n";
                $text .= implode("\n", $winnersText);
                $text .= "\n\n🚀 Keyingi tadbirda ishtirok eting!";

                TelegramChannelService::sendPost($text);
            }
        });
    }

    /**
     * Tadbir leaderboard — N+1 oldini olish uchun user larni batch load
     */
    public static function getEventLeaderboard(SeasonalEvent $event): array
    {
        $questIds = $event->quests()->pluck('quests.id');

        if ($questIds->isEmpty()) {
            return [];
        }

        $topUsers = DB::table('user_quests')
            ->whereIn('quest_id', $questIds)
            ->where('status', 'completed')
            ->select('user_id', DB::raw('COUNT(*) as completed_count'))
            ->groupBy('user_id')
            ->orderByDesc('completed_count')
            ->limit(50)
            ->get();

        // Barcha user larni bir so'rovda olish — N+1 oldini olish
        $userIds = $topUsers->pluck('user_id');
        $users   = User::whereIn('id', $userIds)
            ->select('id', 'name', 'username')
            ->get()
            ->keyBy('id');

        $rank = 0;
        return $topUsers->map(function ($row) use (&$rank, $users) {
            $rank++;
            $user = $users->get($row->user_id);
            return [
                'rank'            => $rank,
                'user_id'         => $row->user_id,
                'name'            => $user?->name ?? 'Noma\'lum',
                'completed_count' => $row->completed_count,
            ];
        })->toArray();
    }
}
