<?php

namespace App\Services\Marketing;

use App\Models\AIS\Wallet;
use App\Models\Marketing\ShareClick;
use App\Models\Marketing\ShareLink;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ShareService
{
    /**
     * Foydalanuvchiga unikal ulashish havolasi yaratish yoki mavjudini qaytarish
     */
    public static function getOrCreateLink(User $user): ShareLink
    {
        return ShareLink::firstOrCreate(
            ['user_id' => $user->id],
            [
                'code'             => Str::random(12),
                'total_clicks'     => 0,
                'total_earned_ais' => 0,
            ]
        );
    }

    /**
     * Klikni qayd etish (IP + 24 soat deduplikatsiya)
     *
     * @return bool Klik haqiqiy (unikal) bo'lsa true
     */
    public static function trackClick(string $code, string $ip, string $userAgent): bool
    {
        $shareLink = ShareLink::where('code', $code)->first();

        if (!$shareLink) {
            return false;
        }

        // 24 soat ichida shu IP dan klik bormi tekshirish
        $exists = ShareClick::where('share_link_id', $shareLink->id)
            ->where('ip_address', $ip)
            ->where('clicked_at', '>=', now()->subHours(24))
            ->exists();

        if ($exists) {
            return false;
        }

        ShareClick::create([
            'share_link_id' => $shareLink->id,
            'ip_address'    => $ip,
            'user_agent'    => $userAgent,
            'clicked_at'    => now(),
            'created_at'    => now(),
        ]);

        $shareLink->increment('total_clicks');

        return true;
    }

    /**
     * Mukofot hisoblash va berish
     * Har 10 unikal klik uchun 1 AIS, kuniga max 5 AIS
     */
    public static function processRewards(User $user): void
    {
        $shareLink = ShareLink::where('user_id', $user->id)->first();

        if (!$shareLink) {
            return;
        }

        // Bugungi unikal kliklar soni
        $todayClicks = ShareClick::where('share_link_id', $shareLink->id)
            ->whereDate('clicked_at', today())
            ->count();

        // Har 10 klik uchun 1 AIS, kuniga max 5 AIS
        $maxEarnableToday = min((int) floor($todayClicks / 10), 5);

        if ($maxEarnableToday <= 0) {
            return;
        }

        // Bugun allaqachon berilgan AIS ni hisoblash
        // Bugungi kliklar asosida berilgan AIS ni alohida jadvalda saqlash o'rniga
        // total_earned_ais dan bugungi boshlanishidagi qiymatni ayiramiz
        $alreadyEarnedToday = ShareClick::where('share_link_id', $shareLink->id)
            ->whereDate('clicked_at', today())
            ->where('rewarded', true)
            ->count();

        // Bugun berilishi kerak bo'lgan AIS
        $alreadyAisToday = min((int) floor($alreadyEarnedToday / 10), 5);
        $toAward = $maxEarnableToday - $alreadyAisToday;

        if ($toAward <= 0) {
            return;
        }

        DB::transaction(function () use ($user, $shareLink, $toAward, $todayClicks) {
            $shareLink = ShareLink::lockForUpdate()->find($shareLink->id);

            // Bugungi reward qilinmagan kliklarni reward qilish
            $unrwarded = ShareClick::where('share_link_id', $shareLink->id)
                ->whereDate('clicked_at', today())
                ->where('rewarded', false)
                ->limit($toAward * 10)
                ->pluck('id');

            if ($unrwarded->isNotEmpty()) {
                ShareClick::whereIn('id', $unrwarded)->update(['rewarded' => true]);
            }

            $wallet = Wallet::firstOrCreate(
                ['user_id' => $user->id],
                ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
            );

            $wallet->increment('balance', $toAward);
            $shareLink->increment('total_earned_ais', $toAward);
        });
    }

    /**
     * Statistika: jami kliklar, bugungi kliklar, jami ishlangan AIS, share_link URL
     */
    public static function getStats(User $user): array
    {
        $shareLink = static::getOrCreateLink($user);

        $todayClicks = ShareClick::where('share_link_id', $shareLink->id)
            ->whereDate('clicked_at', today())
            ->count();

        return [
            'share_link'      => url("/api/v1/s/{$shareLink->code}"),
            'total_clicks'    => (int) $shareLink->total_clicks,
            'today_clicks'    => $todayClicks,
            'total_earned_ais' => (float) $shareLink->total_earned_ais,
            'daily_limit'     => 5.0,
        ];
    }
}
