<?php

namespace App\Services\Marketing;

use App\Models\AIS\Wallet;
use App\Models\Game\Quest;
use App\Models\Marketing\BadgeConfig;
use App\Models\Marketing\UserBadge;
use App\Models\Marketing\UserOnboarding;
use App\Models\User;
use App\Services\QuestService;
use Illuminate\Support\Facades\DB;

class OnboardingService
{
    /**
     * Bosqich mukofotlari (step => AIS)
     */
    private const STEP_REWARDS = [
        1 => 5,   // Profil to'ldirish
        2 => 10,  // KYC yuklash
        3 => 15,  // Birinchi depozit
        4 => 20,  // Birinchi paket xarid
        5 => 25,  // Birinchi referral
    ];

    /**
     * Bosqich turlari (step => type)
     */
    private const STEP_TYPES = [
        1 => 'profile',
        2 => 'kyc',
        3 => 'deposit',
        4 => 'purchase',
        5 => 'referral',
    ];

    /** Barcha 5 bosqich tugallanganda bonus AIS */
    private const COMPLETION_BONUS = 25;

    /**
     * Yangi foydalanuvchi uchun onboarding yaratish
     */
    public static function initForUser(User $user): UserOnboarding
    {
        return UserOnboarding::firstOrCreate(
            ['user_id' => $user->id],
            [
                'current_step'     => 1,
                'step_1_completed' => false,
                'step_2_completed' => false,
                'step_3_completed' => false,
                'step_4_completed' => false,
                'step_5_completed' => false,
                'bonus_claimed'    => false,
            ]
        );
    }

    /**
     * Bosqichni tekshirish va mukofot berish
     *
     * @param string $stepType profile|kyc|deposit|purchase|referral
     * @return array|null Mukofot ma'lumotlari yoki null
     */
    public static function checkStep(User $user, string $stepType): ?array
    {
        $onboarding = UserOnboarding::where('user_id', $user->id)->first();

        if (!$onboarding) {
            $onboarding = static::initForUser($user);
        }

        // Allaqachon tugallangan bo'lsa
        if ($onboarding->completed_at) {
            return null;
        }

        // Step type dan step raqamini topish
        $step = array_search($stepType, self::STEP_TYPES);

        if ($step === false) {
            return null;
        }

        $completedField = "step_{$step}_completed";

        // Allaqachon tugallangan bosqich
        if ($onboarding->$completedField) {
            return null;
        }

        // Ketma-ket tartib invarianti: oldingi bosqich tugallangan bo'lishi kerak
        if ($step > 1) {
            $prevField = 'step_' . ($step - 1) . '_completed';
            if (!$onboarding->$prevField) {
                return null;
            }
        }

        // Bosqich shartini tekshirish
        if (!static::isStepCompleted($user, $stepType)) {
            return null;
        }

        $reward = self::STEP_REWARDS[$step];

        return DB::transaction(function () use ($user, $onboarding, $step, $completedField, $reward) {
            $onboarding = UserOnboarding::lockForUpdate()->find($onboarding->id);

            // Qayta tekshirish (race condition)
            if ($onboarding->$completedField) {
                return null;
            }

            $updateData = [
                $completedField                    => true,
                "step_{$step}_completed_at"        => now(),
            ];

            // current_step ni oshirish (agar joriy bosqich bo'lsa)
            if ($onboarding->current_step == $step && $step < 5) {
                $updateData['current_step'] = $step + 1;
            }

            $onboarding->update($updateData);

            // AIS mukofot berish
            $wallet = Wallet::firstOrCreate(
                ['user_id' => $user->id],
                ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
            );
            $wallet->increment('balance', $reward);

            // Quest progress yangilash
            QuestService::updateProgress($user, Quest::REQ_ONBOARDING_DONE);

            $result = [
                'step'       => $step,
                'type'       => self::STEP_TYPES[$step],
                'reward_ais' => $reward,
                'bonus'      => false,
            ];

            // Barcha 5 bosqich tugallanganmi tekshirish
            $onboarding->refresh();
            if (
                $onboarding->step_1_completed &&
                $onboarding->step_2_completed &&
                $onboarding->step_3_completed &&
                $onboarding->step_4_completed &&
                $onboarding->step_5_completed &&
                !$onboarding->bonus_claimed
            ) {
                // 25 AIS bonus
                $wallet->increment('balance', self::COMPLETION_BONUS);

                // "Onboarding Master" badge berish
                static::awardOnboardingBadge($user);

                $onboarding->update([
                    'current_step'  => 5,
                    'bonus_claimed' => true,
                    'completed_at'  => now(),
                ]);

                $result['bonus'] = true;
                $result['bonus_ais'] = self::COMPLETION_BONUS;
            }

            return $result;
        });
    }

    /**
     * Bosqich shartini tekshirish
     */
    private static function isStepCompleted(User $user, string $stepType): bool
    {
        return match ($stepType) {
            'profile'  => !empty($user->phone) && !empty($user->avatar),
            'kyc'      => in_array($user->kyc_status, ['verified', 'passport_pending', 'face_pending']),
            'deposit'  => $user->deposits()->where('status', 'approved')->exists(),
            'purchase' => $user->purchases()->exists(),
            'referral' => $user->referrals()->exists(),
            default    => false,
        };
    }

    /**
     * "Onboarding Master" badge berish
     */
    private static function awardOnboardingBadge(User $user): void
    {
        // "Onboarding Master" badge config ni topish yoki yaratish
        $badgeConfig = BadgeConfig::where('type', 'onboarding_master')->first();

        if (!$badgeConfig) {
            // Agar badge config mavjud bo'lmasa, to'g'ridan-to'g'ri UserBadge yaratish
            // BadgeConfig da onboarding_master turi bo'lmasligi mumkin
            // Shuning uchun mavjud badge tizimidan foydalanish
            return;
        }

        $exists = UserBadge::where('user_id', $user->id)
            ->where('badge_config_id', $badgeConfig->id)
            ->exists();

        if (!$exists) {
            UserBadge::create([
                'user_id'         => $user->id,
                'badge_config_id' => $badgeConfig->id,
                'awarded_at'      => now(),
                'created_at'      => now(),
            ]);
        }
    }

    /**
     * Foydalanuvchi onboarding progressi
     */
    public static function getProgress(User $user): array
    {
        $onboarding = UserOnboarding::where('user_id', $user->id)->first();

        if (!$onboarding) {
            $onboarding = static::initForUser($user);
        }

        $steps = [];
        $totalReward = 0;

        foreach (self::STEP_TYPES as $step => $type) {
            $completedField = "step_{$step}_completed";
            $completedAtField = "step_{$step}_completed_at";
            $completed = (bool) $onboarding->$completedField;
            $reward = self::STEP_REWARDS[$step];

            if ($completed) {
                $totalReward += $reward;
            }

            $steps[] = [
                'step'         => $step,
                'type'         => $type,
                'title'        => static::getStepTitle($type),
                'reward_ais'   => $reward,
                'completed'    => $completed,
                'completed_at' => $onboarding->$completedAtField?->toDateTimeString(),
            ];
        }

        if ($onboarding->bonus_claimed) {
            $totalReward += self::COMPLETION_BONUS;
        }

        return [
            'current_step'  => $onboarding->current_step,
            'steps'         => $steps,
            'total_reward'  => $totalReward,
            'bonus_reward'  => (float) self::COMPLETION_BONUS,
            'bonus_claimed' => (bool) $onboarding->bonus_claimed,
            'completed'     => (bool) $onboarding->completed_at,
        ];
    }

    /**
     * Bosqich sarlavhasi
     */
    private static function getStepTitle(string $type): string
    {
        return match ($type) {
            'profile'  => 'Profilni to\'ldirish',
            'kyc'      => 'KYC hujjat yuklash',
            'deposit'  => 'Birinchi depozit qilish',
            'purchase' => 'Birinchi paket xarid qilish',
            'referral' => 'Birinchi do\'stni taklif qilish',
            default    => '',
        };
    }
}
