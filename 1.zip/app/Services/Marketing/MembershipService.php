<?php

namespace App\Services\Marketing;

use App\Models\AIS\Wallet;
use App\Models\Marketing\MembershipHistory;
use App\Models\Marketing\MembershipTier;
use App\Models\Marketing\UserMembership;
use App\Models\User;
use App\Services\TelegramBotService;
use Illuminate\Support\Facades\DB;

class MembershipService
{
    /**
     * Foydalanuvchining VIP darajasini tekshirish va yangilash
     */
    public static function evaluateAndUpgrade(User $user): ?UserMembership
    {
        $membership = UserMembership::firstOrCreate(
            ['user_id' => $user->id],
            [
                'tier'             => 'free',
                'total_ais_earned' => 0,
                'total_referrals'  => 0,
                'upgraded_at'      => now(),
            ]
        );

        // Foydalanuvchi ko'rsatkichlarini yangilash
        $totalAis = (float) ($user->wallet?->balance ?? 0);
        $totalReferrals = $user->referrals()->count();

        $membership->update([
            'total_ais_earned' => $totalAis,
            'total_referrals'  => $totalReferrals,
        ]);

        // Eng yuqori mos darajani topish
        $bestTier = MembershipTier::where('min_ais_earned', '<=', $totalAis)
            ->where('min_referrals', '<=', $totalReferrals)
            ->orderByDesc('min_ais_earned')
            ->first();

        $newTierName = $bestTier?->tier ?? 'free';
        $oldTierName = $membership->tier;

        if ($newTierName !== $oldTierName) {
            DB::transaction(function () use ($user, $membership, $oldTierName, $newTierName) {
                $membership->update([
                    'tier'        => $newTierName,
                    'upgraded_at' => now(),
                    'grace_until' => null,
                ]);

                MembershipHistory::create([
                    'user_id'    => $user->id,
                    'from_tier'  => $oldTierName,
                    'to_tier'    => $newTierName,
                    'reason'     => 'auto_upgrade',
                    'created_at' => now(),
                ]);

                TelegramBotService::notify(
                    $user,
                    "🎉 VIP darajangiz yangilandi!\n\n"
                    . "📈 {$oldTierName} → <b>{$newTierName}</b>\n"
                    . "🎁 Yangi imtiyozlardan foydalaning!",
                    [[['text' => '👑 VIP imtiyozlarni ko\'rish', 'url' => config('app.url') . '/app/profile']]]
                );
            });
        }

        return $membership->fresh();
    }

    /**
     * Cashback hisoblash va berish
     */
    public static function applyCashback(User $user, float $amount, string $source): ?float
    {
        $membership = UserMembership::where('user_id', $user->id)->first();
        if (!$membership) {
            return null;
        }

        $tierConfig = MembershipTier::where('tier', $membership->tier)->first();
        if (!$tierConfig || $tierConfig->cashback_percent <= 0) {
            return null;
        }

        $cashback = round($amount * $tierConfig->cashback_percent / 100, 4);

        if ($cashback > 0) {
            $wallet = Wallet::firstOrCreate(
                ['user_id' => $user->id],
                ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
            );
            $wallet->increment('balance', $cashback);
        }

        return $cashback;
    }

    /**
     * Komissiya chegirmasi foizini qaytarish
     */
    public static function getFeeDiscount(User $user): float
    {
        $membership = UserMembership::where('user_id', $user->id)->first();
        if (!$membership) {
            return 0;
        }

        $tierConfig = MembershipTier::where('tier', $membership->tier)->first();
        return (float) ($tierConfig?->fee_discount_percent ?? 0);
    }

    /**
     * VIP holati ma'lumotlari — faqat o'qish, DB write yo'q
     */
    public static function getStatus(User $user): array
    {
        // firstOrCreate o'rniga where()->first() — GET da DB write bo'lmasligi kerak
        $membership = UserMembership::where('user_id', $user->id)->first();

        // Membership yo'q bo'lsa — default free tier ma'lumotlari
        $currentTierName = $membership?->tier ?? 'free';

        $currentTier = MembershipTier::where('tier', $currentTierName)->first();

        // Keyingi daraja talablari
        $allTiers = MembershipTier::orderBy('min_ais_earned')->get();
        $currentIndex = $allTiers->search(fn ($t) => $t->tier === $currentTierName);
        $nextTier = $allTiers->get($currentIndex + 1);

        $history = $membership
            ? MembershipHistory::where('user_id', $user->id)
                ->orderByDesc('created_at')
                ->limit(10)
                ->get()
                ->map(fn ($h) => [
                    'from_tier'  => $h->from_tier,
                    'to_tier'    => $h->to_tier,
                    'reason'     => $h->reason,
                    'created_at' => $h->created_at->toDateTimeString(),
                ])
            : collect();

        return [
            'tier'      => $currentTierName,
            'next_tier' => $nextTier ? [
                'tier'          => $nextTier->tier,
                'min_ais'       => (float) $nextTier->min_ais_earned,
                'min_referrals' => $nextTier->min_referrals,
            ] : null,
            'progress'  => [
                'total_ais_earned' => (float) ($membership?->total_ais_earned ?? 0),
                'total_referrals'  => $membership?->total_referrals ?? 0,
            ],
            'benefits'  => $currentTier ? [
                'cashback_percent'     => (float) $currentTier->cashback_percent,
                'fee_discount_percent' => (float) $currentTier->fee_discount_percent,
                'has_special_quests'   => $currentTier->has_special_quests,
                'has_personal_manager' => $currentTier->has_personal_manager,
            ] : null,
            'history'   => $history,
        ];
    }

    /**
     * Oylik downgrade tekshirish
     * grace_until o'tgan va talablarga mos kelmaydigan foydalanuvchilarni bir daraja pastga tushirish
     *
     * @return int Downgrade qilingan foydalanuvchilar soni
     */
    public static function monthlyReview(): int
    {
        $count = 0;

        $memberships = UserMembership::where('tier', '!=', 'free')->get();

        foreach ($memberships as $membership) {
            $user = User::find($membership->user_id);
            if (!$user) {
                continue;
            }

            $tierConfig = MembershipTier::where('tier', $membership->tier)->first();
            if (!$tierConfig) {
                continue;
            }

            $totalAis = (float) ($user->wallet?->balance ?? 0);
            $totalReferrals = $user->referrals()->count();

            // Talablarga mos kelishini tekshirish
            $meetsRequirements = $totalAis >= $tierConfig->min_ais_earned
                && $totalReferrals >= $tierConfig->min_referrals;

            if ($meetsRequirements) {
                // Grace ni tozalash
                if ($membership->grace_until) {
                    $membership->update(['grace_until' => null]);
                }
                continue;
            }

            // Grace davri belgilash yoki downgrade
            if (!$membership->grace_until) {
                // 30 kunlik grace davri berish
                $membership->update(['grace_until' => now()->addDays(30)]);
                continue;
            }

            // Grace davri o'tganmi tekshirish
            if ($membership->grace_until->isFuture()) {
                continue;
            }

            // Bir daraja pastga tushirish
            $allTiers = MembershipTier::orderBy('min_ais_earned')->pluck('tier');
            $currentIndex = $allTiers->search($membership->tier);
            $lowerTier = $currentIndex > 0 ? $allTiers->get($currentIndex - 1) : 'free';

            DB::transaction(function () use ($user, $membership, $lowerTier) {
                $oldTier = $membership->tier;

                $membership->update([
                    'tier'        => $lowerTier,
                    'grace_until' => null,
                ]);

                MembershipHistory::create([
                    'user_id'    => $user->id,
                    'from_tier'  => $oldTier,
                    'to_tier'    => $lowerTier,
                    'reason'     => 'monthly_downgrade',
                    'created_at' => now(),
                ]);

                TelegramBotService::notify(
                    $user,
                    "⚠️ VIP darajangiz pasaydi.\n\n"
                    . "📉 {$oldTier} → {$lowerTier}\n"
                    . "Talablarga javob berib, darajangizni qayta oshiring!",
                    [[['text' => '📊 Profilni ko\'rish', 'url' => config('app.url') . '/app/profile']]]
                );
            });

            $count++;
        }

        return $count;
    }
}
