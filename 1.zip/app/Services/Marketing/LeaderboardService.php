<?php

namespace App\Services\Marketing;

use App\Models\AIS\Wallet;
use App\Models\Marketing\LeaderboardCompetition;
use App\Models\Marketing\LeaderboardEntry;
use App\Models\User;
use App\Services\TelegramChannelService;
use Illuminate\Support\Facades\DB;

class LeaderboardService
{
    /**
     * Yangi musobaqa boshlash (scheduled)
     */
    public static function startCompetition(string $period, string $type): LeaderboardCompetition
    {
        if ($period === 'weekly') {
            $startsAt = now()->startOfWeek();
            $endsAt   = now()->endOfWeek();
        } else {
            $startsAt = now()->startOfMonth();
            $endsAt   = now()->endOfMonth();
        }

        return LeaderboardCompetition::create([
            'period'    => $period,
            'type'      => $type,
            'starts_at' => $startsAt,
            'ends_at'   => $endsAt,
            'status'    => 'active',
            'prizes'    => self::defaultPrizes($period),
        ]);
    }

    /**
     * Musobaqa tugashi va mukofot berish (scheduled)
     */
    public static function finalizeCompetition(LeaderboardCompetition $competition): void
    {
        DB::transaction(function () use ($competition) {
            $competition = LeaderboardCompetition::lockForUpdate()->find($competition->id);

            if ($competition->status !== 'active') {
                return;
            }

            // Qatnashchilarni score bo'yicha tartiblash va rank belgilash
            // with('user') — N+1 oldini olish
            $entries = LeaderboardEntry::where('competition_id', $competition->id)
                ->with('user:id,name')
                ->orderByDesc('score')
                ->get();

            $prizes = $competition->prizes ?? [];
            $winnersText = [];

            foreach ($entries as $index => $entry) {
                $rank     = $index + 1;
                $prizeAis = $prizes[$index]['ais'] ?? 0;

                $entry->update([
                    'rank'      => $rank,
                    'prize_ais' => $prizeAis,
                ]);

                // Mukofot berish
                if ($prizeAis > 0) {
                    $wallet = Wallet::firstOrCreate(
                        ['user_id' => $entry->user_id],
                        ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
                    );
                    $wallet->increment('balance', $prizeAis);

                    // user allaqachon eager load qilingan — qo'shimcha query yo'q
                    $user = $entry->user;
                    if ($user && $rank <= 10) {
                        $winnersText[] = self::rankEmoji($rank) . " <b>{$user->name}</b> — {$entry->score} ball, {$prizeAis} AIS";
                    }
                }
            }

            $competition->update(['status' => 'finalized']);

            // Telegram kanalga g'oliblar ro'yxatini yuborish
            if (!empty($winnersText)) {
                $periodLabel = $competition->period === 'weekly' ? 'Haftalik' : 'Oylik';
                $text = "🏆 <b>{$periodLabel} musobaqa natijalari</b>\n\n";
                $text .= implode("\n", $winnersText);
                $text .= "\n\n🚀 Keyingi musobaqada ishtirok eting!";

                TelegramChannelService::sendPost($text);
            }
        });
    }

    /**
     * Leaderboard olish — TOP N foydalanuvchilar
     */
    public static function getLeaderboard(LeaderboardCompetition $competition, int $limit = 50): array
    {
        // with('user') — N+1 oldini olish (avval har entry uchun alohida User::find chaqirilardi)
        $entries = LeaderboardEntry::where('competition_id', $competition->id)
            ->with('user:id,name,username,avatar')
            ->orderByDesc('score')
            ->limit($limit)
            ->get();

        $rank = 0;
        return $entries->map(function ($entry) use (&$rank) {
            $rank++;
            return [
                'rank'       => $rank,
                'user_id'    => $entry->user_id,
                'name'       => $entry->user?->name ?? 'Noma\'lum',
                'username'   => $entry->user?->username,
                'avatar_url' => $entry->user?->avatar_url,
                'score'      => (float) $entry->score,
            ];
        })->toArray();
    }

    /**
     * Foydalanuvchining musobaqadagi o'rni
     */
    public static function getUserRank(LeaderboardCompetition $competition, User $user): int
    {
        $entry = LeaderboardEntry::where('competition_id', $competition->id)
            ->where('user_id', $user->id)
            ->first();

        if (!$entry) {
            return 0;
        }

        return LeaderboardEntry::where('competition_id', $competition->id)
            ->where('score', '>', $entry->score)
            ->count() + 1;
    }

    /**
     * Foydalanuvchi faoliyatiga qarab ball qo'shish
     */
    public static function updateScore(User $user, string $scoreType, float $points = 1): void
    {
        // Aktiv musobaqalarni topish (tegishli tur bo'yicha)
        $competitions = LeaderboardCompetition::active()
            ->where('type', $scoreType)
            ->where('starts_at', '<=', now())
            ->where('ends_at', '>=', now())
            ->get();

        foreach ($competitions as $competition) {
            $entry = LeaderboardEntry::firstOrCreate(
                [
                    'competition_id' => $competition->id,
                    'user_id'        => $user->id,
                ],
                ['score' => 0, 'rank' => 0, 'prize_ais' => 0]
            );

            $entry->increment('score', $points);
        }
    }

    /**
     * Standart mukofotlar
     */
    private static function defaultPrizes(string $period): array
    {
        if ($period === 'weekly') {
            return [
                ['rank' => 1, 'ais' => 50],
                ['rank' => 2, 'ais' => 30],
                ['rank' => 3, 'ais' => 20],
                ['rank' => 4, 'ais' => 10],
                ['rank' => 5, 'ais' => 5],
            ];
        }

        return [
            ['rank' => 1, 'ais' => 200],
            ['rank' => 2, 'ais' => 100],
            ['rank' => 3, 'ais' => 50],
            ['rank' => 4, 'ais' => 30],
            ['rank' => 5, 'ais' => 20],
        ];
    }

    /**
     * Rank emoji
     */
    private static function rankEmoji(int $rank): string
    {
        return match ($rank) {
            1 => '🥇',
            2 => '🥈',
            3 => '🥉',
            default => "#{$rank}",
        };
    }
}
