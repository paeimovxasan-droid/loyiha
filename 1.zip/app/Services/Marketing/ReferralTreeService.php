<?php

namespace App\Services\Marketing;

use App\Models\Finance\Commission;
use App\Models\User;

class ReferralTreeService
{
    /**
     * 3 darajagacha referral tarmog'ini rekursiv olish
     */
    public static function getTree(User $user, int $maxDepth = 3): array
    {
        return self::buildTree($user, 1, $maxDepth);
    }

    /**
     * Har bir daraja (1, 2, 3) uchun referrallar soni va jami komissiya
     */
    public static function getLevelStats(User $user): array
    {
        $stats = [];

        // 1-daraja
        $level1Refs = User::where('referred_by', $user->username)->pluck('id');
        $stats[] = [
            'level'            => 1,
            'count'            => $level1Refs->count(),
            'total_commission' => (float) Commission::where('user_id', $user->id)
                ->where('level', 1)
                ->sum('amount'),
        ];

        // 2-daraja
        if ($level1Refs->isNotEmpty()) {
            $level1Usernames = User::whereIn('id', $level1Refs)->pluck('username');
            $level2Refs = User::whereIn('referred_by', $level1Usernames)->pluck('id');
            $stats[] = [
                'level'            => 2,
                'count'            => $level2Refs->count(),
                'total_commission' => (float) Commission::where('user_id', $user->id)
                    ->where('level', 2)
                    ->sum('amount'),
            ];

            // 3-daraja
            if ($level2Refs->isNotEmpty()) {
                $level2Usernames = User::whereIn('id', $level2Refs)->pluck('username');
                $level3Count = User::whereIn('referred_by', $level2Usernames)->count();
                $stats[] = [
                    'level'            => 3,
                    'count'            => $level3Count,
                    'total_commission' => (float) Commission::where('user_id', $user->id)
                        ->where('level', 3)
                        ->sum('amount'),
                ];
            } else {
                $stats[] = ['level' => 3, 'count' => 0, 'total_commission' => 0];
            }
        } else {
            $stats[] = ['level' => 2, 'count' => 0, 'total_commission' => 0];
            $stats[] = ['level' => 3, 'count' => 0, 'total_commission' => 0];
        }

        return $stats;
    }

    /**
     * Rekursiv daraxt qurish
     */
    private static function buildTree(User $user, int $currentDepth, int $maxDepth): array
    {
        if ($currentDepth > $maxDepth) {
            return [];
        }

        $referrals = User::where('referred_by', $user->username)
            ->select('id', 'name', 'username', 'created_at', 'status')
            ->get();

        return $referrals->map(function (User $ref) use ($user, $currentDepth, $maxDepth) {
            $commission = (float) Commission::where('user_id', $user->id)
                ->where('from_user_id', $ref->id)
                ->sum('amount');

            $node = [
                'masked_name'   => SocialProofService::maskName($ref->name),
                'level'         => $currentDepth,
                'registered_at' => $ref->created_at->toDateString(),
                'is_active'     => $ref->status === 'active',
                'commission'    => $commission,
            ];

            if ($currentDepth < $maxDepth) {
                $node['children'] = self::buildTree($ref, $currentDepth + 1, $maxDepth);
            }

            return $node;
        })->toArray();
    }
}
