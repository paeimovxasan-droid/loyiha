<?php

namespace App\Services\Marketing;

use App\Models\User;
use Illuminate\Support\Facades\Storage;

class QrService
{
    /**
     * QR-kod generatsiya (PNG, 300x300)
     * Google Charts API orqali fallback
     *
     * @return string Fayl yo'li (storage ichida)
     */
    public static function generate(User $user): string
    {
        $referralLink = self::getReferralLink($user);
        $filename = "qr-codes/ref_{$user->username}.png";

        // Google Charts QR API orqali generatsiya
        $qrUrl = 'https://chart.googleapis.com/chart?'
            . http_build_query([
                'cht'  => 'qr',
                'chs'  => '300x300',
                'chl'  => $referralLink,
                'choe' => 'UTF-8',
            ]);

        try {
            $imageContent = file_get_contents($qrUrl);
            if ($imageContent !== false) {
                Storage::disk('public')->put($filename, $imageContent);
                return $filename;
            }
        } catch (\Exception $e) {
            // Fallback: faqat URL qaytarish
        }

        return $filename;
    }

    /**
     * QR-kod URL ni qaytarish
     */
    public static function getUrl(User $user): string
    {
        $filename = "qr-codes/ref_{$user->username}.png";

        if (!Storage::disk('public')->exists($filename)) {
            self::generate($user);
        }

        return asset('storage/' . $filename);
    }

    /**
     * Referral havola
     */
    private static function getReferralLink(User $user): string
    {
        $botUsername = config('services.telegram.bot_username', 'aisoqqa_bot');
        return "https://t.me/{$botUsername}?start=ref_{$user->username}";
    }
}
