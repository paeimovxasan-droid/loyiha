<?php

namespace App\Services\Marketing;

use App\Models\AIS\Wallet;
use App\Models\Marketing\SocialProofEvent;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class SocialProofService
{
    /**
     * Hodisa qayd etish
     */
    public static function record(string $type, User $user, ?float $amount = null): void
    {
        SocialProofEvent::create([
            'type'        => $type,
            'user_id'     => $user->id,
            'masked_name' => self::maskName($user->name),
            'amount'      => $amount,
            'metadata'    => null,
            'created_at'  => now(),
        ]);
    }

    /**
     * So'nggi hodisalar (24 soat ichida, max 20 ta)
     */
    public static function getRecent(int $limit = 20): Collection
    {
        return SocialProofEvent::where('created_at', '>=', now()->subDay())
            ->orderByDesc('created_at')
            ->limit($limit)
            ->get()
            ->shuffle()
            ->map(fn (SocialProofEvent $event) => [
                'type'        => $event->type,
                'masked_name' => $event->masked_name,
                'amount'      => $event->amount ? (float) $event->amount : null,
                'time_ago'    => $event->created_at->diffForHumans(),
            ]);
    }

    /**
     * Bugungi kunlik statistika
     */
    public static function getDailyStats(): array
    {
        $today = today();

        $newUsers = User::whereDate('created_at', $today)->count();

        $totalAis = (float) DB::table('social_proof_events')
            ->whereDate('created_at', $today)
            ->whereNotNull('amount')
            ->sum('amount');

        $mostActive = DB::table('social_proof_events')
            ->whereDate('created_at', $today)
            ->select('masked_name', DB::raw('COUNT(*) as event_count'))
            ->groupBy('masked_name')
            ->orderByDesc('event_count')
            ->first();

        return [
            'new_users_today'  => $newUsers,
            'total_ais_today'  => $totalAis,
            'most_active_user' => $mostActive?->masked_name ?? null,
        ];
    }

    /**
     * Ism yashirish: "Dilshod" → "Dil***d"
     */
    public static function maskName(string $name): string
    {
        $name = trim($name);
        $length = mb_strlen($name);

        if ($length <= 1) {
            return '***';
        }

        if ($length <= 3) {
            return mb_substr($name, 0, 1) . '***';
        }

        return mb_substr($name, 0, 3) . '***' . mb_substr($name, -1);
    }
}
