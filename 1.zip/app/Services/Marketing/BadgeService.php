<?php

namespace App\Services\Marketing;

use App\Models\AIS\Wallet;
use App\Models\Marketing\BadgeConfig;
use App\Models\Marketing\UserBadge;
use App\Models\User;
use App\Services\Marketing\SocialProofService;
use App\Services\QuestService;
use App\Services\TelegramBotService;
use App\Models\Game\Quest;
use Illuminate\Support\Collection;

class BadgeService
{
    /**
     * Streak asosida badge tekshirish va berish
     * Race condition oldini olish uchun DB::transaction + lockForUpdate
     */
    public static function checkAndAward(User $user, int $streak): ?UserBadge
    {
        // Streak ga mos eng yuqori badge ni topish
        $badgeConfig = BadgeConfig::where('required_streak', '<=', $streak)
            ->orderByDesc('required_streak')
            ->first();

        if (!$badgeConfig) {
            return null;
        }

        // Avval berilganmi tekshirish (tez tekshiruv — transaksiyasiz)
        $exists = UserBadge::where('user_id', $user->id)
            ->where('badge_config_id', $badgeConfig->id)
            ->exists();

        if ($exists) {
            return null;
        }

        return \Illuminate\Support\Facades\DB::transaction(function () use ($user, $badgeConfig, $streak) {
            // Lock bilan qayta tekshirish — race condition oldini olish
            $alreadyExists = UserBadge::where('user_id', $user->id)
                ->where('badge_config_id', $badgeConfig->id)
                ->lockForUpdate()
                ->exists();

            if ($alreadyExists) {
                return null;
            }

            $userBadge = UserBadge::create([
                'user_id'         => $user->id,
                'badge_config_id' => $badgeConfig->id,
                'awarded_at'      => now(),
                'created_at'      => now(),
            ]);

            // AIS mukofot berish
            if ($badgeConfig->reward_ais > 0) {
                $wallet = Wallet::firstOrCreate(
                    ['user_id' => $user->id],
                    ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
                );
                $wallet->increment('balance', $badgeConfig->reward_ais);
            }

            // Telegram bildirishnoma
            $badgeName = $badgeConfig->getTranslation('name', 'uz');
            TelegramBotService::notify(
                $user,
                "🏅 Tabriklaymiz! Siz \"{$badgeName}\" badge oldingiz!\n\n"
                . "🔥 Streak: {$streak} kun\n"
                . "🪙 Mukofot: {$badgeConfig->reward_ais} AIS",
                [[['text' => '🏅 Badge\'larni ko\'rish', 'url' => config('app.url') . '/app/level']]]
            );

            // Quest progress yangilash
            QuestService::updateProgress($user, Quest::REQ_BADGE_EARNED);

            // Social proof — badge olish
            SocialProofService::record('badge_earned', $user, $badgeConfig->reward_ais);

            return $userBadge;
        });
    }

    /**
     * Foydalanuvchining barcha badge larini qaytarish
     */
    public static function getUserBadges(int $userId): Collection
    {
        return UserBadge::where('user_id', $userId)
            ->with('badgeConfig')
            ->orderByDesc('awarded_at')
            ->get();
    }

    /**
     * Barcha badge konfiguratsiyalarini qaytarish
     */
    public static function getBadgeConfig(): array
    {
        return BadgeConfig::orderBy('required_streak')
            ->get()
            ->map(fn (BadgeConfig $config) => [
                'id'              => $config->id,
                'type'            => $config->type,
                'required_streak' => $config->required_streak,
                'reward_ais'      => (float) $config->reward_ais,
                'name'            => $config->name,
                'icon'            => $config->icon,
                'color'           => $config->color,
            ])
            ->toArray();
    }
}
