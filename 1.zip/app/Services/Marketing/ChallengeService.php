<?php

namespace App\Services\Marketing;

use App\Models\AIS\Wallet;
use App\Models\Game\Quest;
use App\Models\Marketing\InviteChallenge;
use App\Models\Marketing\InviteChallengeSettings;
use App\Models\User;
use App\Services\QuestService;
use App\Services\TelegramBotService;
use Illuminate\Support\Facades\DB;

class ChallengeService
{
    /**
     * Yangi challenge boshlash
     *
     * @throws \Exception
     */
    public static function start(User $user): InviteChallenge
    {
        // Aktiv challenge borligini tekshirish
        $activeChallenge = InviteChallenge::where('user_id', $user->id)
            ->active()
            ->first();

        if ($activeChallenge) {
            throw new \Exception('Sizda allaqachon aktiv challenge mavjud.');
        }

        // Sozlamalardan parametrlarni olish
        $settings = InviteChallengeSettings::instance();

        return InviteChallenge::create([
            'user_id'           => $user->id,
            'target_referrals'  => $settings->target_referrals,
            'current_referrals' => 0,
            'reward_ais'        => $settings->reward_ais,
            'starts_at'         => now(),
            'ends_at'           => now()->addDays($settings->duration_days),
            'status'            => 'active',
        ]);
    }

    /**
     * Challenge progressini yangilash (referral qo'shilganda chaqiriladi)
     */
    public static function updateProgress(User $user): void
    {
        $challenge = InviteChallenge::where('user_id', $user->id)
            ->active()
            ->first();

        if (!$challenge) {
            return;
        }

        // Muddati o'tganmi tekshirish
        if ($challenge->ends_at->isPast()) {
            return;
        }

        $settings = InviteChallengeSettings::instance();

        // Kvalifikatsiyalangan referrallarni hisoblash
        // Ro'yxatdan o'tgan + kamida 1 depozit qilgan
        $qualifiedCount = $user->referrals()
            ->where('users.created_at', '>=', $challenge->starts_at)
            ->where('users.created_at', '<=', $challenge->ends_at)
            ->when($settings->min_deposit_required, function ($query) {
                $query->whereHas('deposits', function ($q) {
                    $q->where('status', 'approved');
                });
            })
            ->count();

        // Agar o'zgarish bo'lmasa, qaytish
        if ($qualifiedCount <= $challenge->current_referrals) {
            return;
        }

        $challenge->update(['current_referrals' => $qualifiedCount]);

        // Maqsadga yetdimi tekshirish
        if ($qualifiedCount >= $challenge->target_referrals) {
            DB::transaction(function () use ($user, $challenge) {
                $challenge = InviteChallenge::lockForUpdate()->find($challenge->id);

                if ($challenge->status !== 'active') {
                    return;
                }

                $challenge->update([
                    'status'       => 'completed',
                    'completed_at' => now(),
                ]);

                // AIS mukofot berish
                $wallet = Wallet::firstOrCreate(
                    ['user_id' => $user->id],
                    ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
                );
                $wallet->increment('balance', $challenge->reward_ais);

                // Telegram bildirishnoma
                TelegramBotService::notify(
                    $user,
                    "🎉 Tabriklaymiz! Invite challenge muvaffaqiyatli tugallandi!\n\n"
                    . "👥 Jalb qilingan: {$challenge->target_referrals} ta do'st\n"
                    . "🪙 Mukofot: {$challenge->reward_ais} AIS",
                    [[['text' => '💰 AIS hamyonni ko\'rish', 'url' => config('app.url') . '/app/wallet']]]
                );

                // Quest progress yangilash
                QuestService::updateProgress($user, Quest::REQ_CHALLENGE_DONE);
            });
        }
    }

    /**
     * Muddati o'tgan aktiv challenge larni 'expired' ga o'tkazish
     *
     * @return int Expired qilingan challenge lar soni
     */
    public static function expireOverdue(): int
    {
        $expiredChallenges = InviteChallenge::active()
            ->where('ends_at', '<', now())
            ->get();

        $count = 0;

        foreach ($expiredChallenges as $challenge) {
            $challenge->update(['status' => 'expired']);

            // Foydalanuvchiga bildirishnoma yuborish
            $user = $challenge->user;
            if ($user) {
                TelegramBotService::notify(
                    $user,
                    "⏰ Invite challenge muddati tugadi.\n\n"
                    . "👥 Jalb qilingan: {$challenge->current_referrals}/{$challenge->target_referrals}\n"
                    . "Yangi challenge boshlashingiz mumkin!",
                    [[['text' => '🔄 Yangi challenge boshlash', 'url' => config('app.url') . '/app/referrals']]]
                );
            }

            $count++;
        }

        return $count;
    }

    /**
     * Foydalanuvchining aktiv challenge holati
     */
    public static function getStatus(User $user): ?array
    {
        $challenge = InviteChallenge::where('user_id', $user->id)
            ->active()
            ->first();

        if (!$challenge) {
            return null;
        }

        // Challenge davomida jalb qilingan referrallar ro'yxati
        $settings = InviteChallengeSettings::instance();

        $referrals = $user->referrals()
            ->where('users.created_at', '>=', $challenge->starts_at)
            ->where('users.created_at', '<=', $challenge->ends_at)
            ->when($settings->min_deposit_required, function ($query) {
                $query->whereHas('deposits', function ($q) {
                    $q->where('status', 'approved');
                });
            })
            ->select('users.id', 'users.name', 'users.username', 'users.created_at')
            ->get()
            ->map(fn ($ref) => [
                'name'          => $ref->name,
                'username'      => $ref->username,
                'registered_at' => $ref->created_at->toDateTimeString(),
            ]);

        return [
            'id'                => $challenge->id,
            'target_referrals'  => $challenge->target_referrals,
            'current_referrals' => $challenge->current_referrals,
            'reward_ais'        => (float) $challenge->reward_ais,
            'starts_at'         => $challenge->starts_at->toDateTimeString(),
            'ends_at'           => $challenge->ends_at->toDateTimeString(),
            'status'            => $challenge->status,
            'referrals'         => $referrals,
        ];
    }
}
