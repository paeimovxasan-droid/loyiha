<?php

namespace App\Services;

use App\Models\AIS\Wallet;
use App\Models\Ubi\UbiClaim;
use App\Models\Ubi\UbiSetting;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class UbiService
{
    public static function canClaim(User $user): array
    {
        $setting = UbiSetting::current();

        if (!$setting->is_active) {
            return ['eligible' => false, 'reason' => 'UBI tizimi hozirda faol emas'];
        }

        if ($user->kyc_status !== 'verified') {
            return ['eligible' => false, 'reason' => 'KYC tasdiqlanmagan'];
        }

        // Bugungi check-in tekshirish
        $hasCheckIn = \App\Models\Game\CheckIn::where('user_id', $user->id)
            ->whereDate('created_at', today())->exists();
        if (!$hasCheckIn) {
            return ['eligible' => false, 'reason' => 'Bugungi check-in qilinmagan'];
        }

        // Bugungi claim tekshirish — whereDate ishlatish kerak, where emas
        $alreadyClaimed = UbiClaim::where('user_id', $user->id)
            ->whereDate('claimed_at', today())->exists();
        if ($alreadyClaimed) {
            return ['eligible' => false, 'reason' => 'Bugun allaqachon UBI olindingiz'];
        }

        return ['eligible' => true, 'reason' => 'Barcha shartlar bajarildi'];
    }

    public static function claim(User $user): UbiClaim
    {
        $check = static::canClaim($user);
        if (!$check['eligible']) {
            throw new \Exception($check['reason']);
        }

        return DB::transaction(function () use ($user) {
            // Lock bilan qayta tekshirish — race condition oldini olish
            $alreadyClaimed = UbiClaim::where('user_id', $user->id)
                ->whereDate('claimed_at', today())
                ->lockForUpdate()
                ->exists();

            if ($alreadyClaimed) {
                throw new \Exception('Bugun allaqachon UBI olindingiz.');
            }

            $setting = UbiSetting::current();
            $amount = (float) $setting->daily_amount;

            $wallet = WalletService::createForUser($user);
            $wallet = Wallet::lockForUpdate()->find($wallet->id);
            $wallet->increment('balance', $amount);

            $claim = UbiClaim::create([
                'user_id'    => $user->id,
                'amount'     => $amount,
                'claimed_at' => today(),
            ]);

            XpService::award($user, 'ubi_claim', 5, 'Kunlik UBI: ' . $amount . ' AIS', $claim);

            return $claim;
        });
    }

    public static function getDailyAmount(): float
    {
        return (float) UbiSetting::current()->daily_amount;
    }

    public static function updateSettings(array $data): UbiSetting
    {
        $setting = UbiSetting::current();
        $setting->update($data);
        return $setting->fresh();
    }
}
