<?php

namespace App\Services;

use App\Models\User;
use App\Models\VideoKycCode;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class VideoKycService
{
    /**
     * 6 raqamli tasodifiy kod generatsiya (10 daqiqa TTL)
     * 4 raqam (10000 kombinatsiya) brute force uchun juda kam —
     * 6 raqam (1,000,000 kombinatsiya) xavfsizroq
     */
    public static function generateVerificationCode(User $user): array
    {
        // Avvalgi ishlatilmagan kodlarni bekor qilish
        VideoKycCode::where('user_id', $user->id)
            ->where('used', false)
            ->update(['used' => true]);

        $code = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $expiresAt = now()->addMinutes(10);

        VideoKycCode::create([
            'user_id'    => $user->id,
            'code'       => $code,
            'expires_at' => $expiresAt,
            'used'       => false,
        ]);

        return [
            'code'       => $code,
            'expires_at' => $expiresAt->toIso8601String(),
        ];
    }

    /**
     * Video faylni validatsiya va saqlash
     */
    public static function uploadVideo(User $user, UploadedFile $video): void
    {
        $extension = $video->getClientOriginalExtension() ?: 'mp4';
        $filename  = Str::uuid() . '.' . $extension;
        $path      = $video->storeAs('kyc-videos', $filename, 'public');

        // Oxirgi ishlatilmagan kodni "used" qilish
        VideoKycCode::where('user_id', $user->id)
            ->where('used', false)
            ->where('expires_at', '>', now())
            ->latest()
            ->first()
            ?->update(['used' => true]);

        $user->update([
            'kyc_type'   => 'video',
            'kyc_video'  => $path,
            'kyc_status' => 'video_pending',
        ]);
    }

    /**
     * Kodni tekshirish (muddati o'tmaganligini)
     */
    public static function validateCode(User $user, string $code): bool
    {
        return VideoKycCode::where('user_id', $user->id)
            ->where('code', $code)
            ->where('used', false)
            ->where('expires_at', '>', now())
            ->exists();
    }
}
