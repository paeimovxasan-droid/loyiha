<?php

namespace App\Services\Education;

use App\Models\Education\Certificate;
use App\Models\Education\Course;
use App\Models\Education\CourseProgress;
use App\Models\User;
use Illuminate\Http\Response;
use Illuminate\Support\Str;

class CertificateService
{
    /**
     * Sertifikat yaratish (barcha darslar tugatilganda)
     */
    public static function generate(User $user, Course $course): Certificate
    {
        // Allaqachon sertifikat bormi
        $existing = Certificate::where('user_id', $user->id)
            ->where('course_id', $course->id)
            ->first();

        if ($existing) {
            return $existing;
        }

        // Barcha darslar tugatilganini tekshirish
        $completedCount = CourseProgress::where('user_id', $user->id)
            ->where('course_id', $course->id)
            ->count();

        $remaining = $course->total_lessons - $completedCount;

        if ($remaining > 0) {
            throw new \Exception(
                'Sertifikat olish uchun yana ' . $remaining . ' ta darsni tugatishingiz kerak'
            );
        }

        return Certificate::create([
            'user_id'   => $user->id,
            'course_id' => $course->id,
            'code'      => self::generateUniqueCode(),
            'issued_at' => now(),
        ]);
    }

    /**
     * Sertifikatni kod orqali tekshirish
     */
    public static function verify(string $code): ?Certificate
    {
        return Certificate::with(['user:id,name', 'course:id,title'])
            ->where('code', $code)
            ->first();
    }

    /**
     * Sertifikatni PDF (HTML) formatida qaytarish
     */
    public static function downloadPdf(Certificate $certificate): Response
    {
        $certificate->load(['user:id,name', 'course:id,title']);

        $html = '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Certificate - ' . e($certificate->code) . '</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; background: #f9f9f9; }
        .certificate { border: 3px solid #2563eb; padding: 60px 40px; max-width: 700px; margin: 0 auto; background: #fff; }
        .certificate h1 { color: #2563eb; font-size: 32px; margin-bottom: 10px; }
        .certificate h2 { color: #333; font-size: 22px; margin-bottom: 30px; }
        .certificate .name { font-size: 28px; font-weight: bold; color: #1e40af; margin: 20px 0; }
        .certificate .course { font-size: 20px; color: #555; margin: 10px 0; }
        .certificate .date { font-size: 14px; color: #888; margin-top: 30px; }
        .certificate .code { font-size: 12px; color: #aaa; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="certificate">
        <h1>AISOQQA</h1>
        <h2>Tugatish Sertifikati</h2>
        <p class="name">' . e($certificate->user->name ?? '') . '</p>
        <p class="course">Kurs: ' . e($certificate->course->title ?? '') . '</p>
        <p class="date">Sana: ' . $certificate->issued_at->format('d.m.Y') . '</p>
        <p class="code">Sertifikat kodi: ' . e($certificate->code) . '</p>
    </div>
</body>
</html>';

        return new Response($html, 200, [
            'Content-Type' => 'text/html',
        ]);
    }

    /**
     * Unikal sertifikat kodi generatsiya
     */
    private static function generateUniqueCode(): string
    {
        do {
            $code = strtoupper(Str::random(16));
        } while (Certificate::where('code', $code)->exists());

        return $code;
    }
}
