<?php

namespace App\Services\Education;

use App\Models\AIS\Wallet;
use App\Models\Education\MentorProfile;
use App\Models\Education\MentorSession;
use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Facades\DB;

class MentorService
{
    /**
     * Mentor profili yaratish
     */
    public static function createProfile(User $user, array $data): MentorProfile
    {
        if (($data['hourly_rate'] ?? 0) <= 0) {
            throw new \Exception('Narx musbat bo\'lishi kerak');
        }

        return MentorProfile::updateOrCreate(
            ['user_id' => $user->id],
            [
                'expertise'   => $data['expertise'],
                'bio'         => $data['bio'],
                'hourly_rate' => $data['hourly_rate'],
                'is_active'   => true,
            ]
        );
    }

    /**
     * Mentorlar ro'yxati
     */
    public static function list(array $filters = []): LengthAwarePaginator
    {
        $query = MentorProfile::active()->with('user:id,name,username,avatar');

        if (!empty($filters['expertise'])) {
            $query->where('expertise', $filters['expertise']);
        }

        $perPage = $filters['per_page'] ?? 15;

        return $query->latest()->paginate($perPage);
    }

    /**
     * Mentorlik so'rovi yuborish va to'lov
     */
    public static function requestSession(User $user, MentorProfile $mentor, array $data): MentorSession
    {
        // O'ziga so'rov yuborishni tekshirish
        if ($user->id === $mentor->user_id) {
            throw new \Exception('O\'zingizga mentorlik so\'rovi yubora olmaysiz');
        }

        $hours = (int) ($data['hours'] ?? 1);
        if ($hours <= 0) {
            throw new \Exception('Soatlar soni musbat bo\'lishi kerak');
        }

        return DB::transaction(function () use ($user, $mentor, $data, $hours) {
            $totalAmount = round((float) $mentor->hourly_rate * $hours, 4);
            $mentorShare = round($totalAmount * 0.9, 4);
            $platformFee = round($totalAmount * 0.1, 4);

            $wallet = Wallet::lockForUpdate()->where('user_id', $user->id)->first();

            if (!$wallet) {
                throw new \Exception('Hamyon topilmadi');
            }

            if ($wallet->isFrozen()) {
                throw new \Exception('Hamyoningiz muzlatilgan');
            }

            if (!$wallet->hasEnough($totalAmount)) {
                throw new \Exception(
                    'Balansingizda yetarli mablag\' yo\'q. Kerak: ' . $totalAmount . ' AIS, Mavjud: ' . $wallet->available_balance . ' AIS'
                );
            }

            // Talaba hamyonidan yechish
            $wallet->decrement('balance', $totalAmount);

            // Mentor hamyoniga qo'shish
            $mentorWallet = Wallet::firstOrCreate(
                ['user_id' => $mentor->user_id],
                ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
            );
            $mentorWallet->increment('balance', $mentorShare);

            return MentorSession::create([
                'mentor_profile_id' => $mentor->id,
                'student_id'        => $user->id,
                'hours'             => $hours,
                'total_amount'      => $totalAmount,
                'mentor_share'      => $mentorShare,
                'platform_fee'      => $platformFee,
                'message'           => $data['message'] ?? null,
                'status'            => 'paid',
            ]);
        });
    }

    /**
     * Mentor so'rovni qabul qilish
     */
    public static function acceptSession(MentorSession $session): MentorSession
    {
        if ($session->status !== 'paid') {
            throw new \Exception('Faqat to\'langan so\'rovlarni qabul qilish mumkin');
        }

        $session->update(['status' => 'accepted']);
        return $session->fresh();
    }

    /**
     * Seansni tugatish
     */
    public static function completeSession(MentorSession $session): MentorSession
    {
        if ($session->status !== 'accepted') {
            throw new \Exception('Faqat qabul qilingan seanslarni tugatish mumkin');
        }

        $session->update(['status' => 'completed']);

        // Talabaga XP berish (15 XP)
        $student = User::find($session->student_id);
        if ($student) {
            \App\Services\XpService::award($student, 'mentor_session', 15, 'Mentorlik seansi tugatildi');
        }

        return $session->fresh();
    }
}
