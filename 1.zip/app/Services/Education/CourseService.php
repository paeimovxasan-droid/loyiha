<?php

namespace App\Services\Education;

use App\Models\AIS\Wallet;
use App\Models\Education\Course;
use App\Models\Education\CourseLesson;
use App\Models\Education\CourseProgress;
use App\Models\Education\CoursePurchase;
use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class CourseService
{
    /**
     * Kurs yaratish (draft holatda)
     */
    public static function create(User $user, array $data): Course
    {
        if (($data['price'] ?? 0) <= 0) {
            throw new \Exception('Narx musbat bo\'lishi kerak');
        }

        return Course::create([
            'user_id'     => $user->id,
            'title'       => $data['title'],
            'description' => $data['description'],
            'price'       => $data['price'],
            'category'    => $data['category'],
            'thumbnail'   => $data['thumbnail'] ?? null,
            'status'      => 'draft',
        ]);
    }

    /**
     * Kursga dars qo'shish
     */
    public static function addLesson(Course $course, array $data): CourseLesson
    {
        $url = $data['video_url'] ?? '';
        if (!self::isValidVideoUrl($url)) {
            throw new \Exception('Video URL YouTube yoki Vimeo formatida bo\'lishi kerak');
        }

        if (($data['duration_minutes'] ?? 0) <= 0) {
            throw new \Exception('Dars muddati musbat bo\'lishi kerak');
        }

        $lesson = CourseLesson::create([
            'course_id'        => $course->id,
            'title'            => $data['title'],
            'video_url'        => $url,
            'duration_minutes' => $data['duration_minutes'],
            'sort_order'       => $data['sort_order'] ?? ($course->total_lessons + 1),
        ]);

        $course->increment('total_lessons');
        $course->increment('total_duration', $data['duration_minutes']);

        return $lesson;
    }

    /**
     * Kursni nashr qilish
     */
    public static function publish(Course $course): Course
    {
        if ($course->total_lessons < 1) {
            throw new \Exception('Kursda kamida bitta dars bo\'lishi kerak');
        }

        $course->update(['status' => 'published']);
        return $course->fresh();
    }

    /**
     * Kursni sotib olish (AIS hamyondan)
     */
    public static function purchase(User $user, Course $course): CoursePurchase
    {
        return DB::transaction(function () use ($user, $course) {
            // Qayta sotib olishni tekshirish
            $exists = CoursePurchase::where('user_id', $user->id)
                ->where('course_id', $course->id)
                ->exists();

            if ($exists) {
                throw new \Exception('Siz bu kursni allaqachon sotib olgansiz');
            }

            $wallet = Wallet::lockForUpdate()->where('user_id', $user->id)->first();

            if (!$wallet) {
                throw new \Exception('Hamyon topilmadi');
            }

            if ($wallet->isFrozen()) {
                throw new \Exception('Hamyoningiz muzlatilgan');
            }

            $price = (float) $course->price;

            if (!$wallet->hasEnough($price)) {
                throw new \Exception(
                    'Balansingizda yetarli mablag\' yo\'q. Kerak: ' . $price . ' AIS, Mavjud: ' . $wallet->available_balance . ' AIS'
                );
            }

            $instructorShare = round($price * 0.9, 4);
            $platformFee     = round($price * 0.1, 4);

            // Talaba hamyonidan yechish
            $wallet->decrement('balance', $price);

            // O'qituvchi hamyoniga qo'shish
            $instructorWallet = Wallet::firstOrCreate(
                ['user_id' => $course->user_id],
                ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
            );
            $instructorWallet->increment('balance', $instructorShare);

            return CoursePurchase::create([
                'user_id'          => $user->id,
                'course_id'        => $course->id,
                'amount'           => $price,
                'instructor_share' => $instructorShare,
                'platform_fee'     => $platformFee,
                'created_at'       => now(),
            ]);
        });
    }

    /**
     * Darsni tugatilgan deb belgilash
     */
    public static function completeLesson(User $user, CourseLesson $lesson): CourseProgress
    {
        $course = $lesson->course;

        // Sotib olinganligini tekshirish
        $purchased = CoursePurchase::where('user_id', $user->id)
            ->where('course_id', $course->id)
            ->exists();

        if (!$purchased) {
            throw new \Exception('Avval kursni sotib oling');
        }

        // Allaqachon tugatilganligini tekshirish
        $existing = CourseProgress::where('user_id', $user->id)
            ->where('lesson_id', $lesson->id)
            ->first();

        if ($existing) {
            return $existing;
        }

        $progress = CourseProgress::create([
            'user_id'      => $user->id,
            'course_id'    => $course->id,
            'lesson_id'    => $lesson->id,
            'completed_at' => now(),
        ]);

        // Barcha darslar tugatilganmi tekshirish
        $completedCount = CourseProgress::where('user_id', $user->id)
            ->where('course_id', $course->id)
            ->count();

        if ($completedCount >= $course->total_lessons && $course->total_lessons > 0) {
            self::onCourseCompleted($user, $course);
        }

        return $progress;
    }

    /**
     * Foydalanuvchining kurs progressini olish
     */
    public static function getProgress(User $user, Course $course): array
    {
        $completedCount = CourseProgress::where('user_id', $user->id)
            ->where('course_id', $course->id)
            ->count();

        $totalLessons = $course->total_lessons;
        $percentage   = $totalLessons > 0 ? round(($completedCount / $totalLessons) * 100, 2) : 0;

        $completedLessonIds = CourseProgress::where('user_id', $user->id)
            ->where('course_id', $course->id)
            ->pluck('lesson_id')
            ->toArray();

        return [
            'completed_lessons' => $completedCount,
            'total_lessons'     => $totalLessons,
            'percentage'        => $percentage,
            'completed_ids'     => $completedLessonIds,
        ];
    }

    /**
     * Kurslar ro'yxati (filtrlash + sahifalash)
     */
    public static function list(array $filters = []): LengthAwarePaginator
    {
        $query = Course::published()->with('user:id,name,username,avatar');

        if (!empty($filters['category'])) {
            $query->where('category', $filters['category']);
        }

        if (!empty($filters['search'])) {
            $query->where('title', 'like', '%' . $filters['search'] . '%');
        }

        $perPage = $filters['per_page'] ?? 15;

        return $query->latest()->paginate($perPage);
    }

    /**
     * Foydalanuvchining sotib olgan kurslari
     */
    public static function myPurchases(User $user): Collection
    {
        return CoursePurchase::where('user_id', $user->id)
            ->with('course.user:id,name,username')
            ->latest('created_at')
            ->get();
    }

    /**
     * Kurs tugatilganda chaqiriladi
     */
    private static function onCourseCompleted(User $user, Course $course): void
    {
        // Sertifikat yaratish
        \App\Services\Education\CertificateService::generate($user, $course);

        // XP berish (25 XP)
        \App\Services\XpService::award($user, 'course_complete', 25, 'Kurs tugatildi: ' . $course->title);

        // Quest progress
        \App\Services\QuestService::updateProgress($user, 'course_complete');
    }

    /**
     * YouTube yoki Vimeo URL tekshirish
     */
    public static function isValidVideoUrl(string $url): bool
    {
        $patterns = [
            '#^https?://(www\.)?youtube\.com/watch\?v=[\w-]+#',
            '#^https?://(www\.)?youtu\.be/[\w-]+#',
            '#^https?://(www\.)?youtube\.com/embed/[\w-]+#',
            '#^https?://(www\.)?vimeo\.com/\d+#',
            '#^https?://player\.vimeo\.com/video/\d+#',
        ];

        foreach ($patterns as $pattern) {
            if (preg_match($pattern, $url)) {
                return true;
            }
        }

        return false;
    }
}
