<?php

namespace App\Services;

use App\Models\AIS\AisConversion;
use App\Models\AIS\AisRate;
use App\Models\AIS\AisTransfer;
use App\Models\AIS\Wallet;
use App\Models\Level\UserLevel;
use App\Models\Setting;
use App\Models\User;
use App\Services\Marketing\MembershipService;
use App\Services\XpService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class WalletService
{
    /**
     * Foydalanuvchi uchun hamyon yaratish (ro'yxatdan o'tishda)
     */
    public static function createForUser(User $user): Wallet
    {
        return Wallet::firstOrCreate(
            ['user_id' => $user->id],
            ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
        );
    }

    /**
     * P2P Transfer: sender → receiver (AIS)
     *
     * @throws \Exception
     */
    public static function transfer(
        User $sender,
        string $receiverIdentifier, // wallet_number yoki username
        float $amount,
        ?string $note = null
    ): AisTransfer {
        return DB::transaction(function () use ($sender, $receiverIdentifier, $amount, $note) {
            // Dastlab hamyonlarni qulflanmagan holatda izlaymiz
            $senderWallet = Wallet::where('user_id', $sender->id)->first();
            if (!$senderWallet) {
                throw new \Exception('Hamyoningiz mavjud emas.');
            }

            // Receiver (qabul qiluvchi)ni topish
            $receiverWallet = Wallet::where('wallet_number', $receiverIdentifier)->first()
                ?? Wallet::whereHas('user', fn($q) => $q->where('username', $receiverIdentifier))->first();

            if (!$receiverWallet) {
                throw new \Exception('Qabul qiluvchi topilmadi.');
            }

            if ($receiverWallet->user_id === $sender->id) {
                throw new \Exception('O\'zingizga pul o\'tkaza olmaysiz.');
            }

            // DEADLOCK ning oldini olish uchun ID larni tartiblab (kichikdan kattaga) qulflaymiz (Locking Order)
            $wallet1 = $senderWallet->id < $receiverWallet->id ? $senderWallet : $receiverWallet;
            $wallet2 = $senderWallet->id < $receiverWallet->id ? $receiverWallet : $senderWallet;

            Wallet::where('id', $wallet1->id)->lockForUpdate()->first();
            Wallet::where('id', $wallet2->id)->lockForUpdate()->first();

            // Qulflangandan so'ng hamyonlarning so'nggi holatini qayta olamiz
            $senderWallet = Wallet::find($senderWallet->id);
            $receiverWallet = Wallet::find($receiverWallet->id);

            if ($senderWallet->isFrozen()) {
                throw new \Exception('Hamyoningiz muzlatilgan.');
            }

            // Transfer komissiyasi (level chegirmasi bilan)
            $setting = Setting::get();
            $feePercent = (float) ($setting->transfer_fee_percent ?? 0.5);

            // Level chegirmasi
            $userLevel = UserLevel::where('user_id', $sender->id)->first();
            if ($userLevel) {
                $levelConfig = \App\Models\Level\LevelConfig::getForLevel($userLevel->level);
                if ($levelConfig) {
                    $feePercent = max(0, $feePercent - (float) $levelConfig->transfer_fee_discount);
                }
            }

            // VIP membership fee discount
            $vipDiscount = MembershipService::getFeeDiscount($sender);
            if ($vipDiscount > 0) {
                $feePercent = $feePercent * (1 - $vipDiscount / 100);
            }

            $fee = round($amount * $feePercent / 100, 4);
            $totalDebit = $amount + $fee;

            if (!$senderWallet->hasEnough($totalDebit)) {
                throw new \Exception('Balansingiz yetarli emas. Kerak: ' . $totalDebit . ' AIS');
            }

            // Balanslarni yangilash
            $senderWallet->decrement('balance', $totalDebit);
            $receiverWallet->increment('balance', $amount);

            // Transfer yozuvi — reference aniq beriladi (model boot() ga tayanmaslik)
            $transfer = AisTransfer::create([
                'sender_id'   => $sender->id,
                'receiver_id' => $receiverWallet->user_id,
                'amount'      => $amount,
                'fee'         => $fee,
                'note'        => $note,
                'reference'   => 'TRF-' . strtoupper(Str::random(10)),
                'status'      => 'completed',
            ]);

            // XP berish
            XpService::award($sender, \App\Models\Level\XpLog::ACTION_TRANSFER, 20,
                'P2P transfer: ' . $amount . ' AIS', $transfer);

            // Fraud detection (non-blocking, transaction tashqarisida emas — lekin xato bo'lsa ignore)
            try {
                \App\Services\Security\FraudDetectionService::onTransfer($sender, $transfer);
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('FraudDetection onTransfer failed', ['error' => $e->getMessage()]);
            }

            return $transfer;
        });
    }

    /**
     * UZS → AIS konvertatsiya (foydalanuvchi qo'lda convert qilganda)
     *
     * Fee UZS da hisoblanadi va UZS balansdan yechiladi:
     *   totalUzs = uzsAmount (foydalanuvchi beradi)
     *   feeUzs   = uzsAmount * feePercent / 100
     *   netUzs   = uzsAmount - feeUzs  (kursga solinadigan summa)
     *   aisAmount = netUzs / buy_rate
     */
    public static function depositToWallet(User $user, float $uzsAmount): AisConversion
    {
        return DB::transaction(function () use ($user, $uzsAmount) {
            $user = User::lockForUpdate()->find($user->id);

            if ($user->balance < $uzsAmount) {
                throw new \Exception('UZS balansingiz yetarli emas.');
            }

            $rate       = AisRate::current();
            if (!$rate) {
                throw new \Exception('AIS kursi hozirda mavjud emas. Keyinroq urinib ko\'ring.');
            }
            $setting    = Setting::get();
            $feePercent = (float) ($setting->conversion_fee_percent ?? 1.0);

            // Fee UZS da hisoblanadi
            $feeUzs   = round($uzsAmount * $feePercent / 100, 2);
            $netUzs   = $uzsAmount - $feeUzs;
            $aisAmount = round($netUzs / $rate->buy_rate, 4);

            if ($aisAmount <= 0) {
                throw new \Exception('Konvertatsiya miqdori juda kam.');
            }

            $user->decrement('balance', $uzsAmount);

            $wallet = static::createForUser($user);
            $wallet->increment('balance', $aisAmount);

            $conversion = AisConversion::create([
                'user_id'    => $user->id,
                'rate_id'    => $rate->id,
                'direction'  => 'buy',
                'uzs_amount' => $uzsAmount,
                'ais_amount' => $aisAmount,
                'rate_used'  => $rate->buy_rate,
                'fee'        => $feeUzs,   // Fee UZS da saqlanadi
                'status'     => 'completed',
            ]);

            $xp = max(10, (int) ($uzsAmount / 10000));
            XpService::award($user, \App\Models\Level\XpLog::ACTION_DEPOSIT, $xp,
                'Konvertatsiya: ' . number_format($uzsAmount) . ' UZS → ' . $aisAmount . ' AIS', $conversion);

            return $conversion;
        });
    }

    /**
     * AIS → UZS konvertatsiya (yechib olish uchun)
     *
     * Fee AIS da hisoblanadi va AIS balansdan yechiladi:
     *   totalAis  = aisAmount + feeAis
     *   uzsAmount = aisAmount * sell_rate  (fee siz UZS)
     */
    public static function withdrawFromWallet(User $user, float $aisAmount): AisConversion
    {
        return DB::transaction(function () use ($user, $aisAmount) {
            $user   = User::lockForUpdate()->find($user->id);
            $wallet = Wallet::lockForUpdate()->where('user_id', $user->id)->first();

            if (!$wallet) {
                throw new \Exception('Hamyon topilmadi.');
            }

            $rate       = AisRate::current();
            if (!$rate) {
                throw new \Exception('AIS kursi hozirda mavjud emas. Keyinroq urinib ko\'ring.');
            }
            $setting    = Setting::get();
            $feePercent = (float) ($setting->conversion_fee_percent ?? 1.0);

            // Fee AIS da hisoblanadi
            $feeAis    = round($aisAmount * $feePercent / 100, 4);
            $totalAis  = $aisAmount + $feeAis;

            if (!$wallet->hasEnough($totalAis)) {
                throw new \Exception('Hamyon balansida yetarli AIS yo\'q. Kerak: ' . $totalAis . ' AIS (fee bilan)');
            }

            // Foydalanuvchi fee siz AIS miqdori uchun UZS oladi
            $uzsAmount = round($aisAmount * $rate->sell_rate, 2);

            $wallet->decrement('balance', $totalAis);
            $user->increment('balance', $uzsAmount);

            return AisConversion::create([
                'user_id'    => $user->id,
                'rate_id'    => $rate->id,
                'direction'  => 'sell',
                'uzs_amount' => $uzsAmount,
                'ais_amount' => $aisAmount,
                'rate_used'  => $rate->sell_rate,
                'fee'        => $feeAis,   // Fee AIS da saqlanadi
                'status'     => 'completed',
            ]);
        });
    }
}
