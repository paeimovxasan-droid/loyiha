<?php

namespace App\Services\Telegram;

use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

abstract class BaseHandler
{
    /**
     * Buyruqni qayta ishlash
     */
    abstract public function handle(int|string $chatId, array $params, array $from): void;

    /**
     * Foydalanuvchini Telegram ID orqali topish
     */
    protected function getUser(array $from): ?User
    {
        $telegramId = (string) ($from['id'] ?? '');
        return User::where('telegram_id', $telegramId)->first();
    }

    /**
     * Xabar yuborish
     */
    protected function sendMessage(int|string $chatId, string $text, array $replyMarkup = []): void
    {
        $token = config('services.telegram.bot_token');

        if (!$token) {
            Log::warning('Telegram bot token sozlanmagan');
            return;
        }

        $payload = [
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => 'HTML',
        ];

        if (!empty($replyMarkup)) {
            $payload['reply_markup'] = json_encode($replyMarkup);
        }

        try {
            Http::post("https://api.telegram.org/bot{$token}/sendMessage", $payload);
        } catch (\Exception $e) {
            Log::error('Telegram xabar yuborishda xato: ' . $e->getMessage());
        }
    }
}
