<?php

namespace App\Services\Telegram;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class AdminNotificationService
{
    protected static function getBotToken(): ?string
    {
        return config('services.telegram_admin.bot_token');
    }

    protected static function getGroupId(): ?string
    {
        return config('services.telegram_admin.group_id');
    }

    /**
     * Umumiy xabar yuborish
     */
    public static function sendMessage(string $text, array $inlineButtons = []): bool
    {
        $token = self::getBotToken();
        $chatId = self::getGroupId();

        if (!$token || !$chatId) {
            Log::warning('Admin Telegram Bot sozlanmagan.');
            return false;
        }

        $payload = [
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => 'HTML',
        ];

        if (!empty($inlineButtons)) {
            $payload['reply_markup'] = json_encode(['inline_keyboard' => $inlineButtons]);
        }

        try {
            $response = Http::post("https://api.telegram.org/bot{$token}/sendMessage", $payload);
            return $response->successful();
        } catch (\Exception $e) {
            Log::error('Admin Telegram xabar yuborishda xato: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Rasm (Chek, Passport va h.k.) bilan xabar yuborish
     */
    public static function sendPhoto(string $photoPath, string $caption, array $inlineButtons = []): bool
    {
        $token = self::getBotToken();
        $chatId = self::getGroupId();

        if (!$token || !$chatId) return false;

        $payload = [
            'chat_id'    => $chatId,
            'caption'    => $caption,
            'parse_mode' => 'HTML',
        ];

        if (!empty($inlineButtons)) {
            $payload['reply_markup'] = json_encode(['inline_keyboard' => $inlineButtons]);
        }

        try {
            // Agar photoPath URL bo'lsa
            if (filter_var($photoPath, FILTER_VALIDATE_URL)) {
                $payload['photo'] = $photoPath;
                $response = Http::post("https://api.telegram.org/bot{$token}/sendPhoto", $payload);
            } else {
                // Agar mahalliy fayl bo'lsa
                $response = Http::attach('photo', file_get_contents($photoPath), basename($photoPath))
                    ->post("https://api.telegram.org/bot{$token}/sendPhoto", $payload);
            }
            
            return $response->successful();
        } catch (\Exception $e) {
            Log::error('Admin Telegram rasm yuborishda xato: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Video (Video KYC) bilan xabar yuborish
     */
    public static function sendVideo(string $videoPath, string $caption, array $inlineButtons = []): bool
    {
        $token = self::getBotToken();
        $chatId = self::getGroupId();

        if (!$token || !$chatId) return false;

        $payload = [
            'chat_id'    => $chatId,
            'caption'    => $caption,
            'parse_mode' => 'HTML',
        ];

        if (!empty($inlineButtons)) {
            $payload['reply_markup'] = json_encode(['inline_keyboard' => $inlineButtons]);
        }

        try {
            if (filter_var($videoPath, FILTER_VALIDATE_URL)) {
                $payload['video'] = $videoPath;
                $response = Http::post("https://api.telegram.org/bot{$token}/sendVideo", $payload);
            } else {
                $response = Http::attach('video', file_get_contents($videoPath), basename($videoPath))
                    ->post("https://api.telegram.org/bot{$token}/sendVideo", $payload);
            }
            return $response->successful();
        } catch (\Exception $e) {
            Log::error('Admin Telegram video yuborishda xato: ' . $e->getMessage());
            return false;
        }
    }
}
