<?php

namespace App\Services\Telegram\Handlers;

use App\Models\User;
use App\Services\Marketing\MembershipService;
use App\Services\Telegram\BaseHandler;

class FinancialHandler extends BaseHandler
{
    public function handle(int|string $chatId, array $params, array $from): void
    {
        // Bu handlerda bir nechta buyruq bo'lishi mumkin (balance, vip)
        // Ammo MatchingEngine match kabi mantiqlar orqali chaqiriladi
    }

    public function handleBalance(int|string $chatId, array $from): void
    {
        $user = $this->getUser($from);

        if (!$user) {
            $this->sendMessage($chatId, "❌ Siz hali ro'yxatdan o'tmagansiz. Mini App orqali kiring.");
            return;
        }

        $uzsBalance = number_format($user->balance, 0, '.', ' ');
        $aisBalance = number_format($user->wallet?->balance ?? 0, 4, '.', ' ');

        $text = "💰 Sizning balansingiz:\n\n";
        $text .= "💵 UZS: {$uzsBalance} so'm\n";
        $text .= "🪙 AIS: {$aisBalance} AIS\n\n";
        $text .= "📊 Daraja: {$user->level_title} (Level {$user->level})";

        $this->sendMessage($chatId, $text);
    }

    public function handleVip(int|string $chatId, array $from): void
    {
        $user = $this->getUser($from);

        if (!$user) {
            $this->sendMessage($chatId, "❌ Siz hali ro'yxatdan o'tmagansiz. Mini App orqali kiring.");
            return;
        }

        $status = MembershipService::getStatus($user);

        $text = "👑 VIP daraja ma'lumotlari:\n\n";
        $text .= "🏅 Daraja: <b>" . strtoupper($status['tier']) . "</b>\n";
        $text .= "🪙 Jami AIS: {$status['progress']['total_ais_earned']}\n";
        $text .= "👥 Jami referrallar: {$status['progress']['total_referrals']}\n";

        if ($status['benefits']) {
            $text .= "\n💎 Imtiyozlar:\n";
            $text .= "  • Cashback: {$status['benefits']['cashback_percent']}%\n";
            $text .= "  • Komissiya chegirmasi: {$status['benefits']['fee_discount_percent']}%\n";
        }

        $this->sendMessage($chatId, $text);
    }
}
