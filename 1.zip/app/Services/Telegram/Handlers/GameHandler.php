<?php

namespace App\Services\Telegram\Handlers;

use App\Models\Game\CheckIn;
use App\Models\Game\Quest;
use App\Models\Level\XpLog;
use App\Services\QuestService;
use App\Services\XpService;
use App\Services\Marketing\BadgeService;
use App\Services\Marketing\PromoService;
use App\Services\Marketing\SpinWheelService;
use App\Services\Telegram\BaseHandler;
use Illuminate\Support\Facades\DB;

class GameHandler extends BaseHandler
{
    public function handle(int|string $chatId, array $params, array $from): void {}

    public function handleCheckIn(int|string $chatId, array $from): void
    {
        $user = $this->getUser($from);
        if (!$user) {
            $this->sendMessage($chatId, "❌ Siz hali ro'yxatdan o'tmagansiz. Mini App orqali kiring.");
            return;
        }

        if (CheckIn::todayFor($user->id)) {
            $this->sendMessage($chatId, "⏰ Bugun allaqachon belgiladingiz.");
            return;
        }

        $yesterday = CheckIn::where('user_id', $user->id)->whereDate('checked_at', today()->subDay())->first();
        $streak = $yesterday ? ($yesterday->streak + 1) : 1;
        $reward = $streak >= 30 ? 50.0 : ($streak >= 7 ? 20.0 : 5.0);

        DB::transaction(function () use ($user, $streak, $reward) {
            CheckIn::create(['user_id' => $user->id, 'checked_at' => today(), 'reward' => $reward, 'streak' => $streak]);
            $user->increment('balance', $reward);
        });

        XpService::award($user, XpLog::ACTION_CHECKIN, 10, "Kunlik belgilash");
        BadgeService::checkAndAward($user, $streak);

        $this->sendMessage($chatId, "✅ Kunlik belgilash muvaffaqiyatli!\n💵 +{$reward} UZS\n🔥 Streak: {$streak} kun");
    }

    public function handleSpin(int|string $chatId, array $from): void
    {
        $user = $this->getUser($from);
        if (!$user) {
            $this->sendMessage($chatId, "❌ Ro'yxatdan o'ting.");
            return;
        }

        try {
            $result = SpinWheelService::spin($user);
            $this->sendMessage($chatId, "🎰 G'ildirak: {$result['prize_label']}");
        } catch (\Exception $e) {
            $this->sendMessage($chatId, "❌ " . $e->getMessage());
        }
    }

    public function handlePromo(int|string $chatId, array $params, array $from): void
    {
        $user = $this->getUser($from);
        $code = trim($params['raw'] ?? '');
        if (!$user || empty($code)) {
            $this->sendMessage($chatId, "❌ Xato.");
            return;
        }

        try {
            $result = PromoService::redeem($user, $code);
            $this->sendMessage($chatId, "🎁 Promo ishlatildi!");
        } catch (\Exception $e) {
            $this->sendMessage($chatId, "❌ " . $e->getMessage());
        }
    }
}
