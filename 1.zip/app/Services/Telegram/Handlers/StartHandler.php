<?php

namespace App\Services\Telegram\Handlers;

use App\Models\User;
use App\Models\Game\Quest;
use App\Models\Level\XpLog;
use App\Services\QuestService;
use App\Services\XpService;
use App\Services\Marketing\ChallengeService;
use App\Services\Marketing\LeaderboardService;
use App\Services\Telegram\BaseHandler;

class StartHandler extends BaseHandler
{
    public function handle(int|string $chatId, array $params, array $from): void
    {
        $telegramId = (string) ($from['id'] ?? '');
        $raw = $params['raw'] ?? '';

        // Referral tekshirish
        if (str_starts_with($raw, 'ref_')) {
            $refUsername = substr($raw, 4);
            $user = User::where('telegram_id', $telegramId)->first();
            if ($user && !$user->referred_by && $refUsername !== $user->username) {
                $referrer = User::where('username', $refUsername)->first();
                if ($referrer) {
                    $user->update(['referred_by' => $refUsername]);
                    XpService::award($referrer, XpLog::ACTION_REFERRAL, 0, "Yangi referral: {$user->username}");
                    QuestService::updateProgress($referrer, Quest::REQ_REFERRAL_COUNT);
                    ChallengeService::updateProgress($referrer);
                    LeaderboardService::updateScore($referrer, 'referral');
                }
            }
        }

        $miniappUrl = config('services.telegram.miniapp_url', '');
        $firstName = $from['first_name'] ?? 'Foydalanuvchi';

        $text = "👋 Salom, {$firstName}!\n\n";
        $text .= "🚀 AISOQQA — AIS valyuta va investitsiya platformasiga xush kelibsiz!\n\n";
        $text .= "📱 Mini App orqali barcha funksiyalardan foydalaning:";

        $replyMarkup = [];
        if ($miniappUrl) {
            $replyMarkup = [
                'inline_keyboard' => [[
                    ['text' => '📱 Mini App ochish', 'web_app' => ['url' => $miniappUrl]],
                ]],
            ];
        }

        $this->sendMessage($chatId, $text, $replyMarkup);
    }
}
