<?php

namespace App\Services;

use App\Models\AIS\Wallet;
use App\Models\Game\Quest;
use App\Models\Game\UserQuest;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class QuestService
{
    /**
     * Foydalanuvchi progressini yangilash
     * Har qanday faoliyatdan keyin chaqiriladi
     */
    public static function updateProgress(User $user, string $requirementType, int $increment = 1): void
    {
        $level = $user->userLevel?->level ?? 0;

        // Foydalanuvchiga tegishli aktiv kvestlarni topish
        $quests = Quest::active()
            ->where('requirement_type', $requirementType)
            ->where('min_level', '<=', $level)
            ->get();

        foreach ($quests as $quest) {
            try {
                // updateOrCreate + unique constraint — race condition oldini olish
                $userQuest = UserQuest::where('user_id', $user->id)
                    ->where('quest_id', $quest->id)
                    ->first();

                if (!$userQuest) {
                    $userQuest = UserQuest::create([
                        'user_id'  => $user->id,
                        'quest_id' => $quest->id,
                        'progress' => 0,
                        'status'   => 'in_progress',
                    ]);
                }
            } catch (\Illuminate\Database\QueryException $e) {
                // Unique constraint violation — parallel request yaratgan, qayta o'qish
                $userQuest = UserQuest::where('user_id', $user->id)
                    ->where('quest_id', $quest->id)
                    ->first();

                if (!$userQuest) continue;
            }

            // Allaqachon claim qilingan bo'lsa o'tkazib yuborish
            if ($userQuest->isClaimed()) {
                // Repeatable kvestlar uchun qayta boshlash
                if ($quest->type === 'repeatable') {
                    $userQuest->update(['progress' => 0, 'status' => 'in_progress', 'completed_at' => null]);
                } else {
                    continue;
                }
            }

            if ($userQuest->isCompleted()) continue;

            // Streak tipidagi kvestlar uchun — increment emas, to'g'ridan-to'g'ri qiymat set qilish
            $isAbsoluteValue = in_array($requirementType, [
                Quest::REQ_CHECKIN_STREAK,
                Quest::REQ_LEVEL_REACH,
            ]);

            $newProgress = $isAbsoluteValue ? $increment : ($userQuest->progress + $increment);
            $required    = $quest->requirement_value;

            if ($newProgress >= $required) {
                $userQuest->update([
                    'progress'     => $required,
                    'status'       => 'completed',
                    'completed_at' => now(),
                ]);
            } else {
                $userQuest->update(['progress' => $newProgress]);
            }
        }
    }

    /**
     * Mukofotni olish (claim)
     */
    public static function claim(User $user, UserQuest $userQuest): array
    {
        if (!$userQuest->isCompleted()) {
            throw new \Exception('Kvest hali tugallanmagan.');
        }

        if ($userQuest->isClaimed()) {
            throw new \Exception('Mukofot allaqachon olindi.');
        }

        return DB::transaction(function () use ($user, $userQuest) {
            // Lock bilan qayta o'qish — ikki marta claim oldini olish
            $userQuest = UserQuest::lockForUpdate()->find($userQuest->id);

            if ($userQuest->isClaimed()) {
                throw new \Exception('Mukofot allaqachon olindi.');
            }

            $quest = $userQuest->quest;

            $userQuest->update([
                'status'     => 'claimed',
                'claimed_at' => now(),
            ]);

            $rewards = [];

            // AIS mukofot
            if ($quest->reward_ais > 0) {
                $wallet = Wallet::firstOrCreate(
                    ['user_id' => $user->id],
                    ['wallet_number' => Wallet::generateNumber(), 'balance' => 0]
                );
                $wallet->increment('balance', $quest->reward_ais);
                $rewards['ais'] = $quest->reward_ais;
            }

            // UZS mukofot
            if ($quest->reward_uzs > 0) {
                $user->increment('balance', $quest->reward_uzs);
                $rewards['uzs'] = $quest->reward_uzs;
            }

            // XP mukofot
            if ($quest->reward_xp > 0) {
                \App\Services\XpService::award(
                    $user,
                    'quest',
                    $quest->reward_xp,
                    'Kvest mukofoti: ' . $quest->getTranslation('title', app()->getLocale()),
                );
                $rewards['xp'] = $quest->reward_xp;
            }

            return $rewards;
        });
    }

    /**
     * Foydalanuvchi uchun barcha kvestlarni olish (progress bilan)
     *
     * GET endpointda DB write bo'lmasligi kerak — faqat o'qish.
     * UserQuest yo'q bo'lsa virtual (unsaved) model qaytariladi.
     * Progress hisoblash progressCache orqali N+1 oldini oladi.
     */
    public static function getForUser(User $user): \Illuminate\Support\Collection
    {
        $level = $user->userLevel?->level ?? 0;

        $quests = Quest::active()
            ->where('min_level', '<=', $level)
            ->get();

        $userQuestMap = UserQuest::where('user_id', $user->id)
            ->whereIn('quest_id', $quests->pluck('id'))
            ->get()
            ->keyBy('quest_id');

        // Barcha progress turlarini bir marta hisoblash (N+1 oldini olish)
        $progressCache = [];

        return $quests->map(function ($quest) use ($userQuestMap, $user, &$progressCache) {
            $userQuest = $userQuestMap->get($quest->id);

            if (!$userQuest) {
                // Progress ni cache dan olish — bir xil type uchun qayta query yo'q
                $type = $quest->requirement_type;
                if (!isset($progressCache[$type])) {
                    $progressCache[$type] = static::calcCurrentProgress($user, $type);
                }
                $progress = $progressCache[$type];
                $required = $quest->requirement_value;

                // Virtual (unsaved) model — GET da DB write bo'lmaydi
                $userQuest = new UserQuest([
                    'user_id'  => $user->id,
                    'quest_id' => $quest->id,
                    'progress' => min($progress, $required),
                    'status'   => $progress >= $required ? 'completed' : 'in_progress',
                ]);
            }

            $userQuest->setRelation('quest', $quest);
            return $userQuest;
        });
    }

    /**
     * Joriy progressni hisoblash (DB dan)
     */
    private static function calcCurrentProgress(User $user, ?string $type): int
    {
        return match($type) {
            Quest::REQ_DEPOSIT_COUNT  => $user->deposits()->where('status', 'approved')->count(),
            Quest::REQ_REFERRAL_COUNT => $user->referrals()->count(),
            Quest::REQ_PURCHASE_COUNT => $user->purchases()->count(),
            Quest::REQ_CHECKIN_STREAK => \App\Models\Game\CheckIn::where('user_id', $user->id)->max('streak') ?? 0,
            Quest::REQ_LEVEL_REACH    => $user->userLevel?->level ?? 0,
            Quest::REQ_TRANSFER_COUNT => $user->sentTransfers()->where('status', 'completed')->count(),
            Quest::REQ_TASK_COMPLETE  => \App\Models\Game\UserTask::where('user_id', $user->id)->where('status', 'approved')->count(),
            Quest::REQ_KYC_VERIFY     => $user->kyc_status === 'verified' ? 1 : 0,
            Quest::REQ_PROFILE_FILL   => ($user->phone && $user->avatar) ? 1 : 0,
            Quest::REQ_LUCKY_DRAW     => \App\Models\Game\LuckyDrawTicket::where('user_id', $user->id)->count(),
            Quest::REQ_FUND_INVEST    => $user->fundInvests()->count(),
            Quest::REQ_TOTAL_DEPOSIT  => (int) $user->deposits()->where('status', 'approved')->sum('final_amount'),
            default => 0,
        };
    }
}
