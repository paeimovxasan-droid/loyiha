<?php

namespace App\Services;

use App\Models\Game\Quest;
use App\Models\Level\XpLog;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class TelegramAuthService
{
    /**
     * Telegram initData imzosini HMAC-SHA256 bilan tekshirish
     *
     * @param string $initData  URL-encoded key=value pairs separated by &
     * @return array  Parsed Telegram user data
     * @throws ValidationException
     */
    public static function validateInitData(string $initData): array
    {
        // Parse initData string into key=value pairs
        $params = [];
        foreach (explode('&', $initData) as $pair) {
            $parts = explode('=', $pair, 2);
            if (count($parts) === 2) {
                $params[urldecode($parts[0])] = urldecode($parts[1]);
            }
        }

        // Extract hash
        if (!isset($params['hash'])) {
            throw ValidationException::withMessages([
                'initData' => ['Yaroqsiz Telegram ma\'lumotlari'],
            ]);
        }

        $receivedHash = $params['hash'];
        unset($params['hash']);

        // Sort remaining parameters alphabetically by key
        ksort($params);

        // Create data_check_string by joining sorted params with \n
        $dataCheckString = collect($params)
            ->map(fn($value, $key) => "{$key}={$value}")
            ->implode("\n");

        // Generate secret_key = HMAC-SHA256("WebAppData", bot_token)
        $botToken = config('services.telegram.bot_token');
        $secretKey = hash_hmac('sha256', $botToken, 'WebAppData', true);

        // Generate expected_hash = HMAC-SHA256(data_check_string, secret_key)
        $expectedHash = bin2hex(hash_hmac('sha256', $dataCheckString, $secretKey, true));

        // Compare hashes
        if (!hash_equals($expectedHash, $receivedHash)) {
            throw ValidationException::withMessages([
                'initData' => ['Yaroqsiz Telegram ma\'lumotlari'],
            ]);
        }

        // Check auth_date — reject if older than 24 hours (86400 seconds)
        // Telegram rasmiy hujjatida 24 soat tavsiya qilinadi.
        // 5 daqiqa juda qisqa — sekin internet yoki ilovani ochib qolgan
        // foydalanuvchilar autentifikatsiyadan o'ta olmaydi.
        if (!isset($params['auth_date'])) {
            throw ValidationException::withMessages([
                'initData' => ['Yaroqsiz Telegram ma\'lumotlari'],
            ]);
        }

        $authDate = (int) $params['auth_date'];
        if ($authDate <= 0) {
            throw ValidationException::withMessages([
                'initData' => ['Yaroqsiz Telegram ma\'lumotlari'],
            ]);
        }

        $maxAge = (int) config('services.telegram.auth_max_age', 86400); // default: 24 soat
        if ((time() - $authDate) > $maxAge) {
            throw ValidationException::withMessages([
                'initData' => ['Telegram ma\'lumotlari muddati o\'tgan. Iltimos, ilovani qayta oching.'],
            ]);
        }

        // Parse the user JSON field
        if (!isset($params['user'])) {
            throw ValidationException::withMessages([
                'initData' => ['Yaroqsiz Telegram ma\'lumotlari'],
            ]);
        }

        $telegramUser = json_decode($params['user'], true);

        if (!$telegramUser || !isset($telegramUser['id'])) {
            throw ValidationException::withMessages([
                'initData' => ['Yaroqsiz Telegram ma\'lumotlari'],
            ]);
        }

        return $telegramUser;
    }

    /**
     * Foydalanuvchini topish yoki yaratish va Sanctum token qaytarish
     *
     * @param array $telegramUser  Telegram user data from initData
     * @param string|null $referralCode  Optional referral username
     * @return array  ['user' => User, 'token' => string, 'is_new' => bool]
     */
    public static function authenticateOrRegister(array $telegramUser, ?string $referralCode = null): array
    {
        $user = User::where('telegram_id', $telegramUser['id'])->first();

        if ($user) {
            // Mavjud foydalanuvchi — Telegram profilini yangilash
            $user->update([
                'telegram_first_name' => $telegramUser['first_name'] ?? $user->telegram_first_name,
                'telegram_last_name'  => $telegramUser['last_name'] ?? $user->telegram_last_name,
                'telegram_username'   => $telegramUser['username'] ?? $user->telegram_username,
                'telegram_photo_url'  => $telegramUser['photo_url'] ?? $user->telegram_photo_url,
            ]);

            $token = $user->createToken('telegram-miniapp')->plainTextToken;

            return [
                'user'  => $user,
                'token' => $token,
            ];
        }

        // Yangi foydalanuvchi yaratish — DB transaction + unique constraint
        return \Illuminate\Support\Facades\DB::transaction(function () use ($telegramUser, $referralCode) {
            // Lock — parallel request'da duplicate user oldini olish
            $existing = User::where('telegram_id', $telegramUser['id'])
                ->lockForUpdate()
                ->first();

            if ($existing) {
                $token = $existing->createToken('telegram-miniapp')->plainTextToken;
                return ['user' => $existing, 'token' => $token, 'is_new' => false];
            }

        $firstName = $telegramUser['first_name'] ?? '';
        $lastName  = $telegramUser['last_name'] ?? '';
        $name      = trim("{$firstName} {$lastName}") ?: 'Telegram User';
        $username  = $telegramUser['username'] ?? null;

        if ($username && !User::where('username', $username)->exists()) {
            // Telegram username bo'sh — ishlatamiz
        } elseif (!User::where('username', 'tg_' . $telegramUser['id'])->exists()) {
            $username = 'tg_' . $telegramUser['id'];
        } else {
            $username = 'tg_' . $telegramUser['id'] . '_' . Str::lower(Str::random(4));
        }

        $referredBy = null;
        if ($referralCode) {
            $referrer = User::where('username', strtolower($referralCode))->first();
            if ($referrer) {
                $referredBy = strtolower($referralCode);
            }
        }

        $user = User::create([
            'name'                => $name,
            'username'            => $username,
            'telegram_id'         => $telegramUser['id'],
            'telegram_first_name' => $telegramUser['first_name'] ?? null,
            'telegram_last_name'  => $telegramUser['last_name'] ?? null,
            'telegram_username'   => $telegramUser['username'] ?? null,
            'telegram_photo_url'  => $telegramUser['photo_url'] ?? null,
            'status'              => 'active',
            'locale'              => 'uz',
            'password'            => Hash::make(Str::random(32)),
            'referred_by'         => $referredBy,
        ]);

        $user->assignRole('user');
        WalletService::createForUser($user);
        XpService::award($user, XpLog::ACTION_REGISTER, 50, 'Telegram orqali ro\'yxatdan o\'tish');

        if ($referredBy) {
            $referrer = User::where('username', $referredBy)->first();
            if ($referrer) {
                XpService::award($referrer, XpLog::ACTION_REFERRAL, 20, $user->name . ' ro\'yxatdan o\'tdi');
                QuestService::updateProgress($referrer, Quest::REQ_REFERRAL_COUNT);
            }
        }

        $token = $user->createToken('telegram-miniapp')->plainTextToken;
        \App\Services\Marketing\SocialProofService::record('new_user', $user);

        return ['user' => $user, 'token' => $token, 'is_new' => true];
        });
    }
}
