<?php

namespace App\Services;

use App\Models\Payment\Withdrawal;

class ReceiptImageService
{
    /**
     * Yechim uchun to'lov cheki rasmi generatsiya qilish
     * GD kutubxonasi orqali PNG rasm yaratadi
     *
     * @return string|null Fayl yo'li (temp)
     */
    public static function generateWithdrawalReceipt(Withdrawal $withdrawal): ?string
    {
        if (!extension_loaded('gd')) {
            return null;
        }

        $user = $withdrawal->user;
        $userName = $user ? $user->name : 'Noma\'lum';
        $username = $user?->username ? '(@' . $user->username . ')' : '';

        // Rasm o'lchamlari
        $width = 600;
        $height = 420;

        $img = imagecreatetruecolor($width, $height);

        // Ranglar
        $bgColor = imagecolorallocate($img, 30, 34, 54);       // #1e2236
        $headerBg = imagecolorallocate($img, 79, 70, 229);     // #4f46e5
        $white = imagecolorallocate($img, 241, 245, 249);      // #f1f5f9
        $gray = imagecolorallocate($img, 148, 163, 184);       // #94a3b8
        $green = imagecolorallocate($img, 52, 211, 153);       // #34d399
        $yellow = imagecolorallocate($img, 251, 191, 36);      // #fbbf24
        $border = imagecolorallocate($img, 51, 65, 85);        // #334155
        $darkBg = imagecolorallocate($img, 15, 23, 42);        // #0f172a

        // Fon
        imagefilledrectangle($img, 0, 0, $width, $height, $darkBg);
        imagefilledrectangle($img, 10, 10, $width - 10, $height - 10, $bgColor);

        // Header band
        imagefilledrectangle($img, 10, 10, $width - 10, 60, $headerBg);

        // Header matn
        $headerText = "TO'LOV CHEKI — AISOQQA.UZ";
        $font = 5; // Built-in font
        $textWidth = imagefontwidth($font) * strlen($headerText);
        $x = ($width - $textWidth) / 2;
        imagestring($img, $font, (int)$x, 28, $headerText, $white);

        // Chiziq
        imageline($img, 30, 75, $width - 30, 75, $border);

        // Ma'lumotlar
        $y = 95;
        $lineHeight = 38;
        $labelX = 40;
        $valueX = 220;

        $rows = [
            ['Foydalanuvchi:', $userName . ' ' . $username],
            ['Summa:', number_format($withdrawal->final_amount, 0, '.', ',') . ' UZS'],
            ["To'lov usuli:", $withdrawal->method_name ?? 'Noma\'lum'],
            ['Raqam:', $withdrawal->receiver_number ?? '—'],
            ['Sana:', $withdrawal->created_at->format('d.m.Y H:i')],
            ['Tranzaksiya ID:', '#WD-' . str_pad($withdrawal->id, 5, '0', STR_PAD_LEFT)],
            ['Komissiya:', number_format($withdrawal->charge, 0, '.', ',') . ' UZS'],
        ];

        foreach ($rows as $row) {
            imagestring($img, 3, $labelX, $y, $row[0], $gray);
            imagestring($img, 4, $valueX, $y, $row[1], $white);
            $y += $lineHeight;
        }

        // Pastki chiziq
        imageline($img, 30, $height - 70, $width - 30, $height - 70, $border);

        // Footer
        $footerText = "AISOQQA.UZ — Ishonchli investitsiya platformasi";
        imagestring($img, 3, 40, $height - 55, $footerText, $gray);

        $statusText = "Tasdiqlangan";
        imagestring($img, 4, $width - 140, $height - 35, $statusText, $green);

        // Faylga saqlash
        $tempPath = storage_path('app/temp/receipt_' . $withdrawal->id . '.png');
        $dir = dirname($tempPath);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }

        imagepng($img, $tempPath);
        imagedestroy($img);

        return $tempPath;
    }
}
