<?php

namespace App\Services;

use App\Models\AIS\Wallet;
use App\Models\Crowdfunding\CfDonation;
use App\Models\Crowdfunding\CfExpense;
use App\Models\Crowdfunding\CfProject;
use App\Models\Level\XpLog;
use App\Models\Marketing\BadgeConfig;
use App\Models\Marketing\UserBadge;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class CrowdfundingService
{
    /**
     * Loyiha yaratish (pending statusda)
     */
    public static function createProject(User $user, array $data): CfProject
    {
        return CfProject::create([
            'user_id'     => $user->id,
            'title'       => $data['title'],
            'description' => $data['description'],
            'category'    => $data['category'],
            'goal_amount' => $data['goal_amount'],
            'expires_at'  => $data['expires_at'],
            'status'      => 'pending',
            'collected_amount' => 0,
        ]);
    }

    /**
     * Admin: loyihani tasdiqlash
     */
    public static function approveProject(CfProject $project): CfProject
    {
        $project->update(['status' => 'active']);
        return $project->fresh();
    }

    /**
     * Admin: loyihani rad etish
     */
    public static function rejectProject(CfProject $project, string $reason): CfProject
    {
        $project->update([
            'status'           => 'rejected',
            'rejection_reason' => $reason,
        ]);
        return $project->fresh();
    }

    /**
     * Xayriya qilish (AIS hamyondan yechish + tranzaksiya)
     *
     * @throws \Exception
     */
    public static function donate(User $user, CfProject $project, float $amount): CfDonation
    {
        return DB::transaction(function () use ($user, $project, $amount) {
            // Loyiha aktiv ekanligini tekshirish
            $project = CfProject::lockForUpdate()->find($project->id);

            if ($project->status !== 'active') {
                throw new \Exception('Loyiha hozirda xayriya qabul qilmaydi');
            }

            if ($project->isExpired()) {
                throw new \Exception('Loyiha muddati tugagan');
            }

            // Hamyondan yechish
            $wallet = Wallet::lockForUpdate()->where('user_id', $user->id)->first();

            if (!$wallet || !$wallet->hasEnough($amount)) {
                throw new \Exception('Balansingizda yetarli mablag\' yo\'q');
            }

            $wallet->decrement('balance', $amount);
            $project->increment('collected_amount', $amount);

            $donation = CfDonation::create([
                'user_id'       => $user->id,
                'cf_project_id' => $project->id,
                'amount'        => $amount,
            ]);

            // Maqsadga yetganda funded status
            $project->refresh();
            if ($project->collected_amount >= $project->goal_amount) {
                $project->update(['status' => 'funded']);
            }

            // XP berish (10 XP)
            XpService::award($user, 'crowdfunding_donate', 10,
                'Xayriya: ' . $amount . ' AIS → ' . $project->title, $donation);

            // Badge tekshiruvi
            static::checkBadges($user);

            return $donation;
        });
    }

    /**
     * Badge tekshiruvi: birinchi xayriya → "Xayriyachi", 10 ta turli loyiha → "Saxovatli"
     */
    private static function checkBadges(User $user): void
    {
        $donationCount = CfDonation::where('user_id', $user->id)->count();

        // Birinchi xayriya → "Xayriyachi" badge
        if ($donationCount === 1) {
            $badge = BadgeConfig::where('type', 'xayriyachi')->first();
            if ($badge && !UserBadge::where('user_id', $user->id)->where('badge_config_id', $badge->id)->exists()) {
                UserBadge::create([
                    'user_id'         => $user->id,
                    'badge_config_id' => $badge->id,
                    'awarded_at'      => now(),
                    'created_at'      => now(),
                ]);
            }
        }

        // 10 ta turli loyihaga xayriya → "Saxovatli" badge
        $uniqueProjects = CfDonation::where('user_id', $user->id)
            ->distinct('cf_project_id')
            ->count('cf_project_id');

        if ($uniqueProjects >= 10) {
            $badge = BadgeConfig::where('type', 'saxovatli')->first();
            if ($badge && !UserBadge::where('user_id', $user->id)->where('badge_config_id', $badge->id)->exists()) {
                UserBadge::create([
                    'user_id'         => $user->id,
                    'badge_config_id' => $badge->id,
                    'awarded_at'      => now(),
                    'created_at'      => now(),
                ]);
            }
        }
    }

    /**
     * Admin: xarajat kiritish
     *
     * @throws \Exception
     */
    public static function addExpense(CfProject $project, array $data): CfExpense
    {
        return DB::transaction(function () use ($project, $data) {
            $project = CfProject::lockForUpdate()->find($project->id);

            $totalExpenses = CfExpense::where('cf_project_id', $project->id)->sum('amount');
            $newTotal = $totalExpenses + $data['amount'];

            if ($newTotal > $project->collected_amount) {
                throw new \Exception('Mablag\' yetarli emas');
            }

            return CfExpense::create([
                'cf_project_id' => $project->id,
                'amount'        => $data['amount'],
                'description'   => $data['description'],
                'spent_at'      => $data['spent_at'],
            ]);
        });
    }
}
