<?php

namespace App\Services\Marketplace;

use App\Models\AIS\Wallet;
use App\Models\Level\XpLog;
use App\Models\Marketplace\Gig;
use App\Models\Marketplace\GigDispute;
use App\Models\Marketplace\GigOrder;
use App\Models\Marketplace\GigReview;
use App\Models\Setting;
use App\Models\User;
use App\Services\QuestService;
use App\Services\XpService;
use App\Http\Traits\HandlesFinancialLocks;
use Illuminate\Support\Facades\DB;

class EscrowService
{
    use HandlesFinancialLocks;
    /**
     * Buyurtma yaratish + escrow muzlatish
     */
    public static function createOrder(User $buyer, Gig $gig): GigOrder
    {
        // O'ziga buyurtma berish taqiqi
        if ($gig->user_id === $buyer->id) {
            throw new \Exception('O\'z xizmatingizga buyurtma bera olmaysiz.');
        }

        return DB::transaction(function () use ($buyer, $gig) {
            // Buyer wallet ni lock qilish
            $buyerWallet = Wallet::lockForUpdate()->where('user_id', $buyer->id)->first();

            if (!$buyerWallet) {
                throw new \Exception('Hamyoningiz topilmadi.');
            }

            if ($buyerWallet->isFrozen()) {
                throw new \Exception('Hamyoningiz muzlatilgan.');
            }

            $amount = (float) $gig->price;

            // Available balance tekshiruvi
            if (!$buyerWallet->hasEnough($amount)) {
                throw new \Exception('Balansingiz yetarli emas.');
            }

            // Komissiya foizini sozlamalardan olish
            $setting = Setting::get();
            $commissionRate = (float) ($setting->marketplace_commission_rate ?? 5);
            $commissionRate = max(5, min(10, $commissionRate)); // 5-10% oralig'ida

            $commissionAmount = round($amount * $commissionRate / 100, 4);
            $sellerAmount = round($amount - $commissionAmount, 4);

            // Escrow muzlatish: balance -= amount, frozen_balance += amount
            $buyerWallet->decrement('balance', $amount);
            $buyerWallet->increment('frozen_balance', $amount);

            // Order yaratish
            $order = GigOrder::create([
                'gig_id'            => $gig->id,
                'buyer_id'          => $buyer->id,
                'seller_id'         => $gig->user_id,
                'amount'            => $amount,
                'commission_rate'   => $commissionRate,
                'commission_amount' => $commissionAmount,
                'seller_amount'     => $sellerAmount,
                'status'            => GigOrder::STATUS_PENDING,
            ]);

            // Gig total_orders yangilash
            $gig->increment('total_orders');

            return $order;
        });
    }

    /**
     * Orderni qabul qilish (ijrochi)
     */
    public static function acceptOrder(User $seller, GigOrder $order): GigOrder
    {
        if ($order->seller_id !== $seller->id) {
            throw new \Exception('Sizda bu buyurtmani boshqarish huquqi yo\'q.');
        }

        if ($order->status !== GigOrder::STATUS_PENDING) {
            throw new \Exception('Bu operatsiya joriy holatda mumkin emas.');
        }

        $order->update(['status' => GigOrder::STATUS_IN_PROGRESS]);

        return $order->fresh();
    }

    /**
     * Orderni rad etish (ijrochi) + escrow qaytarish
     */
    public static function rejectOrder(User $seller, GigOrder $order): GigOrder
    {
        if ($order->seller_id !== $seller->id) {
            throw new \Exception('Sizda bu buyurtmani boshqarish huquqi yo\'q.');
        }

        if ($order->status !== GigOrder::STATUS_PENDING) {
            throw new \Exception('Bu operatsiya joriy holatda mumkin emas.');
        }

        return DB::transaction(function () use ($order) {
            // Escrow qaytarish: frozen_balance -= amount, balance += amount
            $buyerWallet = Wallet::lockForUpdate()->where('user_id', $order->buyer_id)->first();
            $buyerWallet->decrement('frozen_balance', (float) $order->amount);
            $buyerWallet->increment('balance', (float) $order->amount);

            $order->update(['status' => GigOrder::STATUS_REJECTED]);

            return $order->fresh();
        });
    }

    /**
     * Ishni topshirish (ijrochi)
     */
    public static function deliverOrder(User $seller, GigOrder $order): GigOrder
    {
        if ($order->seller_id !== $seller->id) {
            throw new \Exception('Sizda bu buyurtmani boshqarish huquqi yo\'q.');
        }

        if ($order->status !== GigOrder::STATUS_IN_PROGRESS) {
            throw new \Exception('Bu operatsiya joriy holatda mumkin emas.');
        }

        $order->update([
            'status'       => GigOrder::STATUS_DELIVERED,
            'delivered_at' => now(),
        ]);

        return $order->fresh();
    }

    /**
     * Ishni qabul qilish (buyurtmachi) + escrow bo'shatish + komissiya
     */
    public static function completeOrder(User $buyer, GigOrder $order): GigOrder
    {
        if ($order->buyer_id !== $buyer->id) {
            throw new \Exception('Sizda bu buyurtmani boshqarish huquqi yo\'q.');
        }

        if ($order->status !== GigOrder::STATUS_DELIVERED) {
            throw new \Exception('Bu operatsiya joriy holatda mumkin emas.');
        }

        return DB::transaction(function () use ($buyer, $order) {
            $amount = (float) $order->amount;
            $sellerAmount = (float) $order->seller_amount;

            // Buyer va Seller walletlarini ID bo'yicha tartiblab qulflash (Deadlock prevention)
            [$buyerWallet, $sellerWallet] = (new self)->lockWalletsInOrder($order->buyer_id, $order->seller_id);

            if (!$buyerWallet) {
                 throw new \Exception('Xaridor hamyoni topilmadi.');
            }

            if (!$sellerWallet) {
                // Seller wallet yo'q bo'lsa yaratish (Lock tartibini buzmaslik uchun ehtiyotkorlik bilan)
                $sellerWallet = Wallet::create([
                    'user_id'       => $order->seller_id,
                    'wallet_number' => Wallet::generateNumber(),
                    'balance'       => 0,
                ]);
                $sellerWallet = Wallet::lockForUpdate()->find($sellerWallet->id);
            }

            // Buyer frozen_balance dan yechish
            $buyerWallet->decrement('frozen_balance', $amount);
            // Seller wallet ga to'lash (komissiya ayirilgan)
            $sellerWallet->increment('balance', $sellerAmount);

            $order->update([
                'status'       => GigOrder::STATUS_COMPLETED,
                'completed_at' => now(),
            ]);

            $order = $order->fresh();

            // XP berish — ijrochiga
            XpService::award(
                User::find($order->seller_id),
                XpLog::ACTION_GIG_COMPLETE,
                50,
                'Gig buyurtma tugallandi: ' . $order->amount . ' AIS',
                $order
            );

            // XP berish — buyurtmachiga
            XpService::award(
                $buyer,
                XpLog::ACTION_GIG_ORDER,
                20,
                'Gig buyurtma berdi: ' . $order->amount . ' AIS',
                $order
            );

            // Quest progress yangilash
            QuestService::updateProgress(User::find($order->seller_id), 'gig_complete');
            QuestService::updateProgress($buyer, 'gig_order');

            return $order;
        });
    }

    /**
     * Dispute ochish
     */
    public static function openDispute(User $user, GigOrder $order, string $reason): GigDispute
    {
        // Buyurtmachi: faqat "delivered" holatda
        // Ijrochi: faqat "in_progress" holatda
        $isBuyer = $order->buyer_id === $user->id;
        $isSeller = $order->seller_id === $user->id;

        if (!$isBuyer && !$isSeller) {
            throw new \Exception('Sizda bu buyurtma uchun nizo ochish huquqi yo\'q.');
        }

        if ($isBuyer && $order->status !== GigOrder::STATUS_DELIVERED) {
            throw new \Exception('Bu operatsiya joriy holatda mumkin emas.');
        }

        if ($isSeller && $order->status !== GigOrder::STATUS_IN_PROGRESS) {
            throw new \Exception('Bu operatsiya joriy holatda mumkin emas.');
        }

        // Mavjud dispute tekshirish
        if ($order->dispute()->where('resolution', GigDispute::RESOLUTION_PENDING)->exists()) {
            throw new \Exception('Bu buyurtma uchun nizo allaqachon ochilgan.');
        }

        return DB::transaction(function () use ($user, $order, $reason) {
            $order->update(['status' => GigOrder::STATUS_DISPUTED]);

            return GigDispute::create([
                'order_id'   => $order->id,
                'opened_by'  => $user->id,
                'reason'     => $reason,
                'resolution' => GigDispute::RESOLUTION_PENDING,
            ]);
        });
    }

    /**
     * Admin dispute hal qilish
     * @param string $resolution 'buyer_wins' | 'seller_wins'
     */
    public static function resolveDispute(GigDispute $dispute, string $resolution, int $adminId, ?string $adminNote = null): GigOrder
    {
        if ($dispute->resolution !== GigDispute::RESOLUTION_PENDING) {
            throw new \Exception('Bu nizo allaqachon hal qilingan.');
        }

        if (!in_array($resolution, [GigDispute::RESOLUTION_BUYER_WINS, GigDispute::RESOLUTION_SELLER_WINS])) {
            throw new \Exception('Noto\'g\'ri qaror turi.');
        }

        return DB::transaction(function () use ($dispute, $resolution, $adminId, $adminNote) {
            $order = GigOrder::lockForUpdate()->find($dispute->order_id);
            $amount = (float) $order->amount;

            if ($resolution === GigDispute::RESOLUTION_BUYER_WINS) {
                // Escrow qaytarish: frozen_balance -= amount, balance += amount
                $buyerWallet = Wallet::lockForUpdate()->where('user_id', $order->buyer_id)->first();
                $buyerWallet->decrement('frozen_balance', $amount);
                $buyerWallet->increment('balance', $amount);

                $order->update(['status' => GigOrder::STATUS_REJECTED]);
            } else {
                // Seller g'alaba: komissiya ayirib ijrochiga to'lash
                $sellerAmount = (float) $order->seller_amount;

                // Buyer va Seller walletlarini ID bo'yicha tartiblab qulflash
                [$buyerWallet, $sellerWallet] = (new self)->lockWalletsInOrder($order->buyer_id, $order->seller_id);

                $buyerWallet->decrement('frozen_balance', $amount);

                if (!$sellerWallet) {
                    $sellerWallet = Wallet::create([
                        'user_id'       => $order->seller_id,
                        'wallet_number' => Wallet::generateNumber(),
                        'balance'       => 0,
                    ]);
                    $sellerWallet = Wallet::lockForUpdate()->find($sellerWallet->id);
                }
                $sellerWallet->increment('balance', $sellerAmount);

                $order->update([
                    'status'       => GigOrder::STATUS_COMPLETED,
                    'completed_at' => now(),
                ]);

                // XP berish
                XpService::award(
                    User::find($order->seller_id),
                    XpLog::ACTION_GIG_COMPLETE,
                    50,
                    'Dispute hal qilindi (ijrochi foydasiga): ' . $order->amount . ' AIS',
                    $order
                );
            }

            $dispute->update([
                'resolution'  => $resolution,
                'resolved_by' => $adminId,
                'resolved_at' => now(),
                'admin_note'  => $adminNote,
            ]);

            return $order->fresh();
        });
    }

    /**
     * Review yaratish
     */
    public static function createReview(User $reviewer, GigOrder $order, int $rating, ?string $comment = null): GigReview
    {
        // Faqat completed orderlar uchun
        if ($order->status !== GigOrder::STATUS_COMPLETED) {
            throw new \Exception('Faqat tugallangan buyurtmalarga baho berish mumkin.');
        }

        // Faqat buyurtmachi review yozishi mumkin
        if ($order->buyer_id !== $reviewer->id) {
            throw new \Exception('Faqat buyurtmachi baho berishi mumkin.');
        }

        // Rating 1-5
        if ($rating < 1 || $rating > 5) {
            throw new \Exception('Reyting 1 dan 5 gacha bo\'lishi kerak.');
        }

        // Takroriy review tekshirish
        if (GigReview::where('order_id', $order->id)->exists()) {
            throw new \Exception('Bu buyurtmaga allaqachon baho berilgan.');
        }

        return DB::transaction(function () use ($reviewer, $order, $rating, $comment) {
            $review = GigReview::create([
                'order_id'    => $order->id,
                'gig_id'      => $order->gig_id,
                'reviewer_id' => $reviewer->id,
                'seller_id'   => $order->seller_id,
                'rating'      => $rating,
                'comment'     => $comment,
            ]);

            // Gig avg_rating va total_reviews yangilash
            GigService::calculateRating($order->gig);

            // XP berish — review yozganga
            XpService::award(
                $reviewer,
                XpLog::ACTION_GIG_REVIEW,
                10,
                'Gig review yozdi',
                $review
            );

            return $review;
        });
    }
}
