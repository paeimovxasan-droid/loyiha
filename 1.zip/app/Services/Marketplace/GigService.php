<?php

namespace App\Services\Marketplace;

use App\Models\Marketplace\Gig;
use App\Models\Marketplace\GigCategory;
use App\Models\Marketplace\GigReview;
use App\Models\User;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

class GigService
{
    /**
     * Gig yaratish
     */
    public static function create(User $user, array $data): Gig
    {
        static::validateGigData($data);

        // Kategoriya mavjudligini tekshirish
        $category = GigCategory::active()->find($data['category_id']);
        if (!$category) {
            throw new \Exception('Kategoriya topilmadi.');
        }

        return Gig::create([
            'user_id'       => $user->id,
            'category_id'   => $data['category_id'],
            'title'         => $data['title'],
            'description'   => $data['description'],
            'price'         => $data['price'],
            'delivery_days' => $data['delivery_days'],
            'status'        => Gig::STATUS_ACTIVE,
        ]);
    }

    /**
     * Gig tahrirlash (faqat egasi)
     */
    public static function update(User $user, Gig $gig, array $data): Gig
    {
        if (!$gig->isOwnedBy($user)) {
            throw new \Exception('Sizda bu gigni tahrirlash huquqi yo\'q.');
        }

        static::validateGigData($data);

        if (isset($data['category_id'])) {
            $category = GigCategory::active()->find($data['category_id']);
            if (!$category) {
                throw new \Exception('Kategoriya topilmadi.');
            }
        }

        $gig->update([
            'category_id'   => $data['category_id'] ?? $gig->category_id,
            'title'         => $data['title'],
            'description'   => $data['description'],
            'price'         => $data['price'],
            'delivery_days' => $data['delivery_days'],
        ]);

        return $gig->fresh();
    }

    /**
     * Gig o'chirish (faqat egasi, active orderlar bo'lmasa)
     */
    public static function delete(User $user, Gig $gig): void
    {
        if (!$gig->isOwnedBy($user)) {
            throw new \Exception('Sizda bu gigni o\'chirish huquqi yo\'q.');
        }

        if ($gig->hasActiveOrders()) {
            throw new \Exception('Faol buyurtmalar mavjud, gigni o\'chirib bo\'lmaydi.');
        }

        $gig->update(['status' => Gig::STATUS_DELETED]);
    }

    /**
     * Giglarni filtrlash, qidiruv, saralash, pagination
     */
    public static function list(array $filters): LengthAwarePaginator
    {
        $query = Gig::active()->with(['user', 'category']);

        // Kategoriya bo'yicha filtrlash
        if (!empty($filters['category_id'])) {
            $query->where('category_id', $filters['category_id']);
        }

        // Qidiruv (sarlavha va tavsif bo'yicha)
        if (!empty($filters['search'])) {
            $search = $filters['search'];
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        // Saralash
        $sortBy = $filters['sort_by'] ?? 'created_at';
        $sortDir = $filters['sort_dir'] ?? 'desc';

        if (in_array($sortBy, ['price', 'avg_rating', 'created_at'])) {
            $query->orderBy($sortBy, $sortDir === 'asc' ? 'asc' : 'desc');
        }

        $perPage = min((int) ($filters['per_page'] ?? 15), 50);

        return $query->paginate($perPage);
    }

    /**
     * Gig o'rtacha reytingini hisoblash va cache yangilash
     */
    public static function calculateRating(Gig $gig): float
    {
        $stats = GigReview::where('gig_id', $gig->id)
            ->selectRaw('AVG(rating) as avg_rating, COUNT(*) as total_reviews')
            ->first();

        $avgRating = round((float) ($stats->avg_rating ?? 0), 2);
        $totalReviews = (int) ($stats->total_reviews ?? 0);

        $gig->update([
            'avg_rating'    => $avgRating,
            'total_reviews' => $totalReviews,
        ]);

        return $avgRating;
    }

    /**
     * Validatsiya
     */
    private static function validateGigData(array $data): void
    {
        if (empty($data['title'])) {
            throw new \Exception('Sarlavha majburiy.');
        }
        if (empty($data['description'])) {
            throw new \Exception('Tavsif majburiy.');
        }
        if (empty($data['price']) || (float) $data['price'] <= 0) {
            throw new \Exception('Narx 0 dan katta bo\'lishi kerak.');
        }
        if (empty($data['category_id'])) {
            throw new \Exception('Kategoriya majburiy.');
        }
        if (empty($data['delivery_days']) || (int) $data['delivery_days'] <= 0) {
            throw new \Exception('Bajarish muddati 0 dan katta bo\'lishi kerak.');
        }
    }
}
