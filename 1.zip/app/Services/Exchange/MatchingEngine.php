<?php

namespace App\Services\Exchange;

use App\Models\AIS\Wallet;
use App\Models\Exchange\ExchangeOrder;
use App\Models\Exchange\ExchangeTrade;
use App\Models\User;
use App\Services\WalletService;
use App\Http\Traits\HandlesFinancialLocks;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class MatchingEngine
{
    use HandlesFinancialLocks;

    /**
     * Buyurtmani order book dagi qarama-qarshi buyurtmalar bilan moslashtirish
     *
     * @return ExchangeTrade[]
     */
    public static function match(ExchangeOrder $order): array
    {
        $trades = [];
        // Xotirani tejash uchun eng yaxshi 50 ta buyurtmani olamiz
        $matchingOrders = static::findMatchingOrders($order, 50);

        foreach ($matchingOrders as $makerOrder) {
            if ($order->remaining_amount <= 0) {
                break;
            }

            $makerOrder = ExchangeOrder::lockForUpdate()->find($makerOrder->id);
            if (!$makerOrder || !in_array($makerOrder->status, ['open', 'partially_filled'])) {
                continue;
            }

            $tradeAmount = min((float) $order->remaining_amount, (float) $makerOrder->remaining_amount);
            $tradePrice = (float) $makerOrder->price;

            if ($tradeAmount <= 0) {
                continue;
            }

            $trade = static::executeTrade($order, $makerOrder, $tradeAmount, $tradePrice);
            $trades[] = $trade;

            $order->refresh();
        }

        return $trades;
    }

    /**
     * Mos keladigan qarama-qarshi buyurtmalarni topish
     */
    private static function findMatchingOrders(ExchangeOrder $order, int $limit = 50): Collection
    {
        $query = ExchangeOrder::active()
            ->where('user_id', '!=', $order->user_id)
            ->where('remaining_amount', '>', 0);

        if ($order->side === 'buy') {
            $query->where('side', 'sell');
            if ($order->type === 'limit') {
                $query->where('price', '<=', $order->price);
            }
            $query->orderBy('price', 'asc')->orderBy('created_at', 'asc');
        } else {
            $query->where('side', 'buy');
            if ($order->type === 'limit') {
                $query->where('price', '>=', $order->price);
            }
            $query->orderBy('price', 'desc')->orderBy('created_at', 'asc');
        }

        return $query->limit($limit)->get();
    }

    /**
     * Ikki buyurtmani moslashtirish va trade yaratish
     */
    private static function executeTrade(
        ExchangeOrder $takerOrder,
        ExchangeOrder $makerOrder,
        float $tradeAmount,
        float $tradePrice
    ): ExchangeTrade {
        $total = round($tradePrice * $tradeAmount, 2);

        $buyOrder  = $takerOrder->side === 'buy' ? $takerOrder : $makerOrder;
        $sellOrder = $takerOrder->side === 'sell' ? $takerOrder : $makerOrder;

        $buyerRole  = $buyOrder->id === $takerOrder->id ? 'taker' : 'maker';
        $sellerRole = $sellOrder->id === $takerOrder->id ? 'taker' : 'maker';

        $buyer  = User::find($buyOrder->user_id);
        $seller = User::find($sellOrder->user_id);

        $buyerFee  = ExchangeService::calculateFee($buyer, $tradeAmount, $buyerRole);
        $sellerFee = ExchangeService::calculateFee($seller, $tradeAmount, $sellerRole);

        $trade = ExchangeTrade::create([
            'buy_order_id'  => $buyOrder->id,
            'sell_order_id' => $sellOrder->id,
            'buyer_id'      => $buyOrder->user_id,
            'seller_id'     => $sellOrder->user_id,
            'price'         => $tradePrice,
            'amount'        => $tradeAmount,
            'total'         => $total,
            'buyer_fee'     => $buyerFee,
            'seller_fee'    => $sellerFee,
            'buyer_role'    => $buyerRole,
            'seller_role'   => $sellerRole,
            'created_at'    => now(),
        ]);

        foreach ([$takerOrder, $makerOrder] as $ord) {
            $newFilled = (float) $ord->filled_amount + $tradeAmount;
            $newRemaining = (float) $ord->amount - $newFilled;

            $oldTotal = (float) $ord->avg_fill_price * (float) $ord->filled_amount;
            $avgPrice = $newFilled > 0 ? round(($oldTotal + $tradePrice * $tradeAmount) / $newFilled, 2) : $tradePrice;

            $fee = ($ord->id === $buyOrder->id) ? $buyerFee : $sellerFee;

            $ord->update([
                'filled_amount'    => $newFilled,
                'remaining_amount' => max(0, $newRemaining),
                'avg_fill_price'   => $avgPrice,
                'total_fee'        => (float) $ord->total_fee + $fee,
                'status'           => $newRemaining <= 0 ? 'filled' : 'partially_filled',
            ]);
        }

        static::settleBalances($trade, $buyOrder, $sellOrder);
        // OhlcvService::updateFromTrade($trade); // Optional: check if exists

        return $trade;
    }

    /**
     * Savdo natijasida balanslarni yangilash
     */
    private static function settleBalances(
        ExchangeTrade $trade,
        ExchangeOrder $buyOrder,
        ExchangeOrder $sellOrder
    ): void {
        [$buyer, $seller] = (new self)->lockInOrder(User::find($trade->buyer_id), User::find($trade->seller_id));
        [$buyerWallet, $sellerWallet] = (new self)->lockWalletsInOrder($trade->buyer_id, $trade->seller_id);

        if (!$buyerWallet) $buyerWallet = WalletService::createForUser($buyer);
        if (!$sellerWallet) $sellerWallet = WalletService::createForUser($seller);

        $tradeTotal = (float) $trade->total;
        $tradeAmount = (float) $trade->amount;

        $buyer->decrement('frozen_uzs_balance', min($tradeTotal, (float) $buyer->frozen_uzs_balance));
        $buyerWallet->increment('balance', $tradeAmount - (float) $trade->buyer_fee);

        $sellerWallet->decrement('frozen_balance', min($tradeAmount, (float) $sellerWallet->frozen_balance));
        $sellerFeeUzs = round((float) $trade->seller_fee * (float) $trade->price, 2);
        $seller->increment('balance', $tradeTotal - $sellerFeeUzs);
    }

    /**
     * Stop buyurtmalarni (Stop-Loss / Take-Profit) faollashtirish
     *
     * Kaskad effekt oldini olish uchun:
     * - Maksimal 10 ta iteratsiya
     * - Har iteratsiyada faqat allaqachon trigger bo'lgan orderlar ishlanadi
     * - Narx o'zgarishi yangi trigger larni keltirib chiqarsa ham, keyingi
     *   iteratsiyada ular ishlanadi (cheksiz loop emas)
     */
    public static function activateStopOrders(float $initialPrice): void
    {
        $processedPrice  = $initialPrice;
        $maxIterations   = 10;   // Kaskad cascade limitini cheklash
        $iteration       = 0;
        $processedIds    = [];   // Bir xil orderni ikki marta ishlamaslik

        while ($iteration < $maxIterations) {
            $iteration++;

            $query = ExchangeOrder::where('status', 'pending_trigger')
                ->where(function ($q) use ($processedPrice) {
                    $q->where(fn($sq) => $sq->where('side', 'sell')->where('stop_price', '>=', $processedPrice))
                      ->orWhere(fn($sq) => $sq->where('side', 'buy')->where('stop_price', '<=', $processedPrice));
                })
                ->orderBy('created_at', 'asc')
                ->limit(20);

            // Allaqachon ishlangan orderlarni o'tkazib yuborish
            if (!empty($processedIds)) {
                $query->whereNotIn('id', $processedIds);
            }

            $triggeredOrders = $query->get();

            if ($triggeredOrders->isEmpty()) {
                break;
            }

            $priceChanged = false;

            foreach ($triggeredOrders as $stopOrder) {
                $processedIds[] = $stopOrder->id;

                DB::transaction(function () use ($stopOrder) {
                    // Lock bilan qayta o'qish — race condition oldini olish
                    $stopOrder = ExchangeOrder::lockForUpdate()->find($stopOrder->id);
                    if (!$stopOrder || $stopOrder->status !== 'pending_trigger') {
                        return;
                    }
                    $stopOrder->update(['status' => 'open']);
                });

                $stopOrder->refresh();
                if ($stopOrder->status !== 'open') {
                    continue;
                }

                $newTrades = static::match($stopOrder);

                if (!empty($newTrades)) {
                    $lastPrice = end($newTrades)->price;
                    // Narx o'zgardimi — keyingi iteratsiyada yangi triggerlar tekshiriladi
                    if ($lastPrice != $processedPrice) {
                        $processedPrice = $lastPrice;
                        $priceChanged   = true;
                    }
                }
            }

            // Narx o'zgarmagan bo'lsa — yangi trigger bo'lmaydi, chiqish
            if (!$priceChanged) {
                break;
            }
        }
    }
}
