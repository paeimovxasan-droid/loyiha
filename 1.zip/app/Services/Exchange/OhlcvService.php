<?php

namespace App\Services\Exchange;

use App\Models\Exchange\ExchangeTrade;
use App\Models\Exchange\OhlcvCandle;
use Carbon\Carbon;
use Illuminate\Support\Collection;

class OhlcvService
{
    private static array $intervals = ['1h', '1d', '1w', '1M'];

    /**
     * Yangi savdo asosida OHLCV yangilash (barcha intervallar uchun)
     */
    public static function updateFromTrade(ExchangeTrade $trade): void
    {
        $tradeTime = $trade->created_at;
        $price     = (float) $trade->price;
        $amount    = (float) $trade->amount;
        $total     = (float) $trade->total;

        foreach (self::$intervals as $interval) {
            $openTime = static::getOpenTime($tradeTime, $interval);

            $candle = OhlcvCandle::where('interval', $interval)
                ->where('open_time', $openTime)
                ->first();

            if ($candle) {
                $candle->update([
                    'high'        => max((float) $candle->high, $price),
                    'low'         => min((float) $candle->low, $price),
                    'close'       => $price,
                    'volume'      => (float) $candle->volume + $amount,
                    'volume_uzs'  => (float) $candle->volume_uzs + $total,
                    'trade_count' => $candle->trade_count + 1,
                ]);
            } else {
                OhlcvCandle::create([
                    'interval'    => $interval,
                    'open_time'   => $openTime,
                    'open'        => $price,
                    'high'        => $price,
                    'low'         => $price,
                    'close'       => $price,
                    'volume'      => $amount,
                    'volume_uzs'  => $total,
                    'trade_count' => 1,
                ]);
            }
        }
    }

    /**
     * OHLCV ma'lumotlarini olish
     */
    public static function getCandles(string $interval, ?Carbon $from = null, ?Carbon $to = null): Collection
    {
        $query = OhlcvCandle::where('interval', $interval)->orderBy('open_time');

        if ($from) {
            $query->where('open_time', '>=', $from);
        }
        if ($to) {
            $query->where('open_time', '<=', $to);
        }

        return $query->get()->map(fn ($c) => [
            'time'   => $c->open_time->toIso8601String(),
            'open'   => (float) $c->open,
            'high'   => (float) $c->high,
            'low'    => (float) $c->low,
            'close'  => (float) $c->close,
            'volume' => (float) $c->volume,
        ]);
    }

    /**
     * Oxirgi savdo narxi
     */
    public static function getLastPrice(): ?float
    {
        $trade = ExchangeTrade::orderByDesc('created_at')->first();
        return $trade ? (float) $trade->price : null;
    }

    /**
     * 24 soatlik statistika — DB aggregatsiya bilan (xotiraga yuklamasdan)
     */
    public static function get24hStats(): array
    {
        $since = now()->subDay();

        // Barcha tradelarni xotiraga yuklamasdan — DB da aggregatsiya
        $stats = ExchangeTrade::where('created_at', '>=', $since)
            ->selectRaw('
                MAX(price) as high,
                MIN(price) as low,
                SUM(amount) as volume_ais,
                SUM(total) as volume_uzs,
                COUNT(*) as trade_count
            ')
            ->first();

        $lastPrice = static::getLastPrice();

        $firstTrade = ExchangeTrade::where('created_at', '>=', $since)
            ->orderBy('created_at')
            ->value('price');

        $changePercent = 0;
        if ($firstTrade && $lastPrice && (float) $firstTrade > 0) {
            $changePercent = round(
                (($lastPrice - (float) $firstTrade) / (float) $firstTrade) * 100,
                2
            );
        }

        return [
            'last_price'     => $lastPrice ?? 0,
            'change_percent' => $changePercent,
            'high'           => $stats->trade_count ? (float) $stats->high : 0,
            'low'            => $stats->trade_count ? (float) $stats->low : 0,
            'volume_ais'     => (float) ($stats->volume_ais ?? 0),
            'volume_uzs'     => (float) ($stats->volume_uzs ?? 0),
        ];
    }

    /**
     * Bozor statistikasi (ticker)
     */
    public static function getTicker(): array
    {
        $stats = static::get24hStats();

        return [
            'last_price'     => $stats['last_price'],
            'best_bid'       => OrderBookService::getBestBid(),
            'best_ask'       => OrderBookService::getBestAsk(),
            'change_24h'     => $stats['change_percent'],
            'high_24h'       => $stats['high'],
            'low_24h'        => $stats['low'],
            'volume_ais_24h' => $stats['volume_ais'],
            'volume_uzs_24h' => $stats['volume_uzs'],
        ];
    }

    /**
     * Interval uchun open_time hisoblash
     */
    private static function getOpenTime(Carbon $time, string $interval): Carbon
    {
        return match ($interval) {
            '1h' => $time->copy()->startOfHour(),
            '1d' => $time->copy()->startOfDay(),
            '1w' => $time->copy()->startOfWeek(),
            '1M' => $time->copy()->startOfMonth(),
            default => $time->copy()->startOfHour(),
        };
    }
}
