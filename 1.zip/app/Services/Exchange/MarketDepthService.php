<?php

namespace App\Services\Exchange;

use App\Models\Exchange\ExchangeOrder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class MarketDepthService
{
    /**
     * Aggregated Order Book (Market Depth) olish
     */
    public static function getDepth(string $symbol = 'AIS/UZS', int $limit = 50): array
    {
        // 1. Bids (Buy orders) - Eng yuqori narxlar birinchi
        $bids = ExchangeOrder::active()
            ->where('side', 'buy')
            ->select('price', DB::raw('SUM(remaining_amount) as total_amount'))
            ->groupBy('price')
            ->orderBy('price', 'desc')
            ->limit($limit)
            ->get();

        // 2. Asks (Sell orders) - Eng past narxlar birinchi
        $asks = ExchangeOrder::active()
            ->where('side', 'sell')
            ->select('price', DB::raw('SUM(remaining_amount) as total_amount'))
            ->groupBy('price')
            ->orderBy('price', 'asc')
            ->limit($limit)
            ->get();

        return [
            'symbol'     => $symbol,
            'bids'       => static::formatDepth($bids),
            'asks'       => static::formatDepth($asks),
            'timestamp'  => now()->toIso8601String(),
        ];
    }

    /**
     * Ma'lumotlarni frontendga mos formatlash
     */
    private static function formatDepth(Collection $collection): array
    {
        return $collection->map(function ($item) {
            return [
                (float) $item->price,
                (float) $item->total_amount,
            ];
        })->values()->toArray();
    }
}
