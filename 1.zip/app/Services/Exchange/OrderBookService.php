<?php

namespace App\Services\Exchange;

use App\Models\Exchange\ExchangeOrder;
use Illuminate\Support\Facades\DB;

class OrderBookService
{
    /**
     * Guruhlangan order book olish (bids + asks)
     */
    public static function getOrderBook(int $depth = 20): array
    {
        $bids = ExchangeOrder::active()
            ->where('side', 'buy')
            ->whereNotNull('price')
            ->select('price', DB::raw('SUM(remaining_amount) as amount'))
            ->groupBy('price')
            ->orderByDesc('price')
            ->limit($depth)
            ->get()
            ->map(fn ($row) => [
                'price'  => (float) $row->price,
                'amount' => (float) $row->amount,
                'total'  => round((float) $row->price * (float) $row->amount, 2),
            ])
            ->values()
            ->toArray();

        $asks = ExchangeOrder::active()
            ->where('side', 'sell')
            ->whereNotNull('price')
            ->select('price', DB::raw('SUM(remaining_amount) as amount'))
            ->groupBy('price')
            ->orderBy('price')
            ->limit($depth)
            ->get()
            ->map(fn ($row) => [
                'price'  => (float) $row->price,
                'amount' => (float) $row->amount,
                'total'  => round((float) $row->price * (float) $row->amount, 2),
            ])
            ->values()
            ->toArray();

        return ['bids' => $bids, 'asks' => $asks];
    }

    /**
     * Eng yaxshi bid narxi
     */
    public static function getBestBid(): ?float
    {
        $order = ExchangeOrder::active()
            ->where('side', 'buy')
            ->whereNotNull('price')
            ->orderByDesc('price')
            ->first();

        return $order ? (float) $order->price : null;
    }

    /**
     * Eng yaxshi ask narxi
     */
    public static function getBestAsk(): ?float
    {
        $order = ExchangeOrder::active()
            ->where('side', 'sell')
            ->whereNotNull('price')
            ->orderBy('price')
            ->first();

        return $order ? (float) $order->price : null;
    }

    /**
     * Spread hisoblash
     */
    public static function getSpread(): ?float
    {
        $bestBid = static::getBestBid();
        $bestAsk = static::getBestAsk();

        if ($bestBid === null || $bestAsk === null) {
            return null;
        }

        return round($bestAsk - $bestBid, 2);
    }
}
