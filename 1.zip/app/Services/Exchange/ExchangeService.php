<?php

namespace App\Services\Exchange;

use App\Models\AIS\Wallet;
use App\Models\Exchange\ExchangeOrder;
use App\Models\Exchange\ExchangeSetting;
use App\Models\User;
use App\Services\Marketing\MembershipService;
use App\Services\WalletService;
use App\Services\XpService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ExchangeService
{
    /**
     * Limit buyurtma yaratish
     */
    public static function placeLimitOrder(User $user, string $side, float $price, float $amount): ExchangeOrder
    {
        if (static::isMaintenanceMode()) {
            throw new \Exception('Birja vaqtincha to\'xtatilgan');
        }

        $wallet = Wallet::where('user_id', $user->id)->first();
        if ($wallet && $wallet->isFrozen()) {
            throw new \Exception('Hamyoningiz muzlatilgan');
        }

        static::validateOrderParams($price, $amount);

        return DB::transaction(function () use ($user, $side, $price, $amount) {
            static::freezeBalance($user, $side, $price, $amount);

            $order = ExchangeOrder::create([
                'user_id'          => $user->id,
                'reference'        => static::generateReference(),
                'type'             => 'limit',
                'side'             => $side,
                'price'            => $price,
                'amount'           => $amount,
                'filled_amount'    => 0,
                'remaining_amount' => $amount,
                'frozen_amount'    => $side === 'buy' ? round($price * $amount, 4) : $amount,
                'status'           => 'open',
            ]);

            $trades = MatchingEngine::match($order);

            $order->refresh();

            // XP berish
            if ($order->filled_amount > 0) {
                $xp = max(10, (int) ($order->filled_amount));
                XpService::award($user, 'exchange_trade', $xp, 'Birja savdosi: ' . $order->filled_amount . ' AIS', $order);
            }

            return $order;
        });
    }

    /**
     * Market buyurtma yaratish
     */
    public static function placeMarketOrder(User $user, string $side, float $amount): ExchangeOrder
    {
        if (static::isMaintenanceMode()) {
            throw new \Exception('Birja vaqtincha to\'xtatilgan');
        }

        $wallet = Wallet::where('user_id', $user->id)->first();
        if ($wallet && $wallet->isFrozen()) {
            throw new \Exception('Hamyoningiz muzlatilgan');
        }

        $minAmount = (float) ExchangeSetting::get('min_order_amount', 1);
        $maxAmount = (float) ExchangeSetting::get('max_order_amount', 100000);
        if ($amount < $minAmount || $amount > $maxAmount) {
            throw new \Exception("Miqdor {$minAmount} dan {$maxAmount} gacha bo'lishi kerak");
        }

        return DB::transaction(function () use ($user, $side, $amount) {
            // $bestAsk faqat buy uchun kerak, sell uchun null
            $bestAsk = null;

            // Market buy uchun: eng yaxshi ask narxini olish va UZS muzlatish
            if ($side === 'buy') {
                $bestAsk = OrderBookService::getBestAsk();
                if (!$bestAsk) {
                    throw new \Exception('Bozorda yetarli likvidlik yo\'q');
                }
                // Eng yuqori narx bilan muzlatish (worst case)
                static::freezeBalance($user, $side, $bestAsk * 1.1, $amount);
            } else {
                static::freezeBalance($user, $side, 0, $amount);
            }

            $frozenAmount = $side === 'buy'
                ? round($bestAsk * 1.1 * $amount, 4)
                : $amount;

            $order = ExchangeOrder::create([
                'user_id'          => $user->id,
                'reference'        => static::generateReference(),
                'type'             => 'market',
                'side'             => $side,
                'price'            => null,
                'amount'           => $amount,
                'filled_amount'    => 0,
                'remaining_amount' => $amount,
                'frozen_amount'    => $frozenAmount,
                'status'           => 'open',
            ]);

            $trades = MatchingEngine::match($order);
            $order->refresh();

            // Bajarilmagan qismni bekor qilish
            if ($order->remaining_amount > 0) {
                static::unfreezeBalance($user, $order, (float) $order->remaining_amount);
                $order->update(['status' => 'cancelled']);
                if ($order->filled_amount > 0 && $order->remaining_amount > 0) {
                    // Partially filled then cancelled
                } elseif ($order->filled_amount == 0) {
                    throw new \Exception('Bozorda yetarli likvidlik yo\'q');
                }
            }

            // XP berish
            if ($order->filled_amount > 0) {
                $xp = max(10, (int) ($order->filled_amount));
                XpService::award($user, 'exchange_trade', $xp, 'Birja savdosi: ' . $order->filled_amount . ' AIS', $order);
            }

            return $order;
        });
    }

    /**
     * Buyurtmani bekor qilish
     */
    public static function cancelOrder(User $user, ExchangeOrder $order): ExchangeOrder
    {
        if ($order->user_id !== $user->id) {
            throw new \Exception('Ruxsat berilmagan');
        }

        if (!in_array($order->status, ['open', 'partially_filled'])) {
            throw new \Exception('Buyurtma bekor qilib bo\'lmaydi');
        }

        return DB::transaction(function () use ($user, $order) {
            $order = ExchangeOrder::lockForUpdate()->find($order->id);

            static::unfreezeBalance($user, $order, (float) $order->remaining_amount);

            $order->update(['status' => 'cancelled']);

            return $order->fresh();
        });
    }

    /**
     * Balans muzlatish
     * BUY: UZS muzlatish (User.balance kamaytirish, User.frozen_uzs_balance oshirish)
     * SELL: AIS muzlatish (Wallet.frozen_balance oshirish)
     */
    private static function freezeBalance(User $user, string $side, float $price, float $amount): void
    {
        if ($side === 'buy') {
            $fee = static::calculateFee($user, $amount, 'taker');
            $totalUzs = round($price * ($amount + $fee), 2);

            $user = User::lockForUpdate()->find($user->id);
            if ($user->available_uzs_balance < $totalUzs) {
                throw new \Exception('Balansingiz yetarli emas');
            }
            $user->decrement('balance', $totalUzs);
            $user->increment('frozen_uzs_balance', $totalUzs);
        } else {
            $wallet = Wallet::lockForUpdate()->where('user_id', $user->id)->first();
            if (!$wallet) {
                $wallet = WalletService::createForUser($user);
                $wallet = Wallet::lockForUpdate()->find($wallet->id);
            }
            if ($wallet->available_balance < $amount) {
                throw new \Exception('AIS balansingiz yetarli emas');
            }
            $wallet->increment('frozen_balance', $amount);
        }
    }

    /**
     * Muzlatilgan balansni bo'shatish
     * BUY: UZS qaytarish (frozen_uzs_balance kamaytirish, balance oshirish)
     * SELL: AIS qaytarish (frozen_balance kamaytirish)
     */
    public static function unfreezeBalance(User $user, ExchangeOrder $order, float $amount): void
    {
        if ($order->side === 'buy') {
            $uzsToReturn = $order->price
                ? round($order->price * $amount, 2)
                : round((float) $order->frozen_amount * ($amount / (float) $order->amount), 2);

            $user = User::lockForUpdate()->find($user->id);
            $uzsToReturn = min($uzsToReturn, (float) $user->frozen_uzs_balance);
            $user->decrement('frozen_uzs_balance', $uzsToReturn);
            $user->increment('balance', $uzsToReturn);
        } else {
            $wallet = Wallet::lockForUpdate()->where('user_id', $user->id)->first();
            if ($wallet) {
                $amount = min($amount, (float) $wallet->frozen_balance);
                $wallet->decrement('frozen_balance', $amount);
            }
        }
    }

    /**
     * Komissiya hisoblash (VIP chegirma bilan)
     */
    public static function calculateFee(User $user, float $amount, string $role = 'taker'): float
    {
        $feeKey = $role === 'maker' ? 'maker_fee_percent' : 'taker_fee_percent';
        $feePercent = (float) ExchangeSetting::get($feeKey, $role === 'maker' ? '0.1' : '0.2');

        // VIP chegirma
        $discount = MembershipService::getFeeDiscount($user);
        if ($discount > 0) {
            $feePercent = $feePercent * (1 - $discount / 100);
        }

        return round($amount * $feePercent / 100, 4);
    }

    /**
     * Birja maintenance rejimini tekshirish
     */
    public static function isMaintenanceMode(): bool
    {
        return ExchangeSetting::get('is_maintenance', 'false') === 'true';
    }

    /**
     * Noyob reference raqam generatsiya (EX-XXXXXXXXXXXX)
     */
    private static function generateReference(): string
    {
        do {
            $ref = 'EX-' . strtoupper(Str::random(12));
        } while (ExchangeOrder::where('reference', $ref)->exists());

        return $ref;
    }

    /**
     * Buyurtma parametrlarini validatsiya
     */
    private static function validateOrderParams(float $price, float $amount): void
    {
        $minAmount = (float) ExchangeSetting::get('min_order_amount', 1);
        $maxAmount = (float) ExchangeSetting::get('max_order_amount', 100000);
        $minPrice  = (float) ExchangeSetting::get('min_order_price', 100);
        $maxPrice  = (float) ExchangeSetting::get('max_order_price', 1000000);

        if ($amount < $minAmount || $amount > $maxAmount) {
            throw new \Exception("Miqdor {$minAmount} dan {$maxAmount} gacha bo'lishi kerak");
        }
        if ($price < $minPrice || $price > $maxPrice) {
            throw new \Exception("Narx {$minPrice} dan {$maxPrice} gacha bo'lishi kerak");
        }
    }
}
