<?php

namespace App\Services\Influencer;

use App\Models\Influencer\InfluencerChannel;
use App\Models\Influencer\InfluencerSetting;
use App\Models\User;
use App\Services\TelegramBotService;

class InfluencerChannelService
{
    /**
     * Publisher yangi kanal qo'shish
     *
     * @throws \Exception
     */
    public static function create(User $user, array $data): InfluencerChannel
    {
        // Ban tekshiruvi
        if ($user->isBanned()) {
            throw new \Exception('Siz ban holatida ekansiz, kanal qo\'sha olmaysiz.', 403);
        }

        $setting = InfluencerSetting::current();

        // Modul yoqilganmi?
        if (!$setting->is_enabled) {
            throw new \Exception('Influencer moduli hozircha o\'chirilgan.', 503);
        }

        // Maksimal kanal soni tekshiruvi
        $channelCount = InfluencerChannel::where('user_id', $user->id)->count();
        if ($channelCount >= $setting->max_channels_per_user) {
            throw new \Exception("Siz maksimal {$setting->max_channels_per_user} ta kanal qo'sha olasiz.");
        }

        // Duplicate URL tekshiruvi
        $exists = InfluencerChannel::where('user_id', $user->id)
            ->where('url', $data['url'])
            ->exists();
        if ($exists) {
            throw new \Exception('Bu URL bilan kanal allaqachon qo\'shilgan.', 409);
        }

        $channel = InfluencerChannel::create([
            'user_id'          => $user->id,
            'type'             => $data['type'],
            'name'             => $data['name'],
            'url'              => $data['url'],
            'subscriber_count' => $data['subscriber_count'] ?? 0,
            'language'         => $data['language'] ?? 'uz',
            'status'           => InfluencerChannel::STATUS_PENDING,
        ]);

        // Admin ga Telegram bildirishnoma
        try {
            TelegramBotService::notifyAdminInfluencerChannel(
                "{$user->name} (@{$user->username})",
                $channel->name,
                $channel->type_label
            );
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Influencer channel notify failed', ['error' => $e->getMessage()]);
        }

        return $channel;
    }

    /**
     * Admin: kanalini tasdiqlash
     */
    public static function approve(InfluencerChannel $channel, User $admin): void
    {
        $channel->update([
            'status'      => InfluencerChannel::STATUS_APPROVED,
            'approved_at' => now(),
            'approved_by' => $admin->id,
            'rejection_reason' => null,
        ]);

        // Publisher ga Telegram bildirishnoma
        try {
            TelegramBotService::notify(
                $channel->user,
                "✅ Kanalingiz tasdiqlandi!\n\n" .
                "📌 Kanal: {$channel->name}\n" .
                "Endi faol kampaniyalarda ishtirok etishingiz mumkin. 🎉",
                [[['text' => '📢 Kampaniyalarni ko\'rish', 'url' => config('app.url') . '/app/influencer/campaigns']]]
            );
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Influencer approve notify failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Admin: kanalini rad etish
     */
    public static function reject(InfluencerChannel $channel, User $admin, string $reason): void
    {
        $channel->update([
            'status'           => InfluencerChannel::STATUS_REJECTED,
            'rejection_reason' => $reason,
            'approved_by'      => $admin->id,
        ]);

        try {
            TelegramBotService::notify(
                $channel->user,
                "❌ Kanalingiz rad etildi.\n\n" .
                "📌 Kanal: {$channel->name}\n" .
                "📝 Sabab: {$reason}\n\n" .
                "Ma'lumotlarni to'g'rilab qayta yuborishingiz mumkin.",
                [[['text' => '📡 Kanallarni ko\'rish', 'url' => config('app.url') . '/app/influencer/channels']]]
            );
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Influencer reject notify failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Admin: kanalini bloklash
     */
    public static function suspend(InfluencerChannel $channel, User $admin): void
    {
        $channel->update([
            'status'      => InfluencerChannel::STATUS_SUSPENDED,
            'approved_by' => $admin->id,
        ]);

        try {
            TelegramBotService::notify(
                $channel->user,
                "⛔ Kanalingiz vaqtincha bloklandi.\n\n" .
                "📌 Kanal: {$channel->name}\n" .
                "Batafsil ma'lumot uchun support bilan bog'laning.",
                [[['text' => '🎫 Support bilan bog\'lanish', 'url' => config('app.url') . '/app/support/create']]]
            );
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::warning('Influencer suspend notify failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Publisher: kanalini o'chirish (faqat pending/rejected)
     *
     * @throws \Exception
     */
    public static function delete(InfluencerChannel $channel, User $user): void
    {
        if ($channel->user_id !== $user->id) {
            throw new \Exception('Bu kanal sizga tegishli emas.', 403);
        }

        if ($channel->isApproved()) {
            throw new \Exception('Tasdiqlangan kanallarni o\'chirib bo\'lmaydi. Faol submissionlar mavjud bo\'lishi mumkin.');
        }

        $channel->delete();
    }
}
