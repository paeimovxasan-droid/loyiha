<?php

namespace App\Services\Influencer;

use App\Models\Influencer\InfluencerSetting;
use App\Models\Influencer\InfluencerSubmission;
use App\Models\User;
use App\Services\TelegramBotService;
use Illuminate\Support\Facades\Cache;

class InfluencerFraudService
{
    /**
     * Publisher bloklangan ekanligini tekshirish (Cache orqali)
     */
    public static function isBlocked(User $user): bool
    {
        return (bool) Cache::get("influencer_blocked_{$user->id}", false);
    }

    /**
     * Kunlik submission limit tekshiruvi
     *
     * @throws \Exception
     */
    public static function checkDailyLimit(User $user): void
    {
        $setting = InfluencerSetting::current();

        $todayCount = InfluencerSubmission::where('user_id', $user->id)
            ->whereDate('created_at', today())
            ->count();

        if ($todayCount >= $setting->max_daily_submissions) {
            throw new \Exception(
                "Kunlik submission limiti ({$setting->max_daily_submissions} ta) to'ldi. Ertaga qayta urinib ko'ring."
            );
        }
    }

    /**
     * Screenshot hash duplicate tekshiruvi
     *
     * @throws \Exception
     */
    public static function checkScreenshotHash(string $hash): void
    {
        $exists = InfluencerSubmission::where('screenshot_hash', $hash)->exists();

        if ($exists) {
            throw new \Exception('Bu screenshot allaqachon boshqa submission uchun ishlatilgan.', 409);
        }
    }

    /**
     * Post URL duplicate tekshiruvi (bir kampaniyada)
     *
     * @throws \Exception
     */
    public static function checkPostUrl(string $url, int $campaignId): void
    {
        $exists = InfluencerSubmission::where('post_url', $url)
            ->where('campaign_id', $campaignId)
            ->exists();

        if ($exists) {
            throw new \Exception('Bu post URL bilan ushbu kampaniyaga allaqachon submission yuborilgan.', 409);
        }
    }

    /**
     * Rad etish soni tekshiruvi — 5 ta rad → 24 soat blok
     */
    public static function checkRejectionCount(User $user): void
    {
        $recentRejections = InfluencerSubmission::where('user_id', $user->id)
            ->where('status', InfluencerSubmission::STATUS_REJECTED)
            ->where('reviewed_at', '>=', now()->subHours(24))
            ->count();

        if ($recentRejections >= 5) {
            Cache::put("influencer_blocked_{$user->id}", true, now()->addHours(24));

            try {
                TelegramBotService::notifyAdmin(
                    "⚠️ Influencer Publisher bloklandi!\n\n" .
                    "👤 Foydalanuvchi: {$user->name} (@{$user->username})\n" .
                    "🆔 ID: {$user->id}\n" .
                    "❌ 24 soat ichida 5 ta submission rad etildi.\n" .
                    "⏰ Blok muddati: 24 soat"
                );
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::warning('Influencer fraud notify failed', ['error' => $e->getMessage()]);
            }
        }
    }

    /**
     * Barcha fraud tekshiruvlarini bir joyda bajarish
     *
     * @throws \Exception
     */
    public static function runAllChecks(User $user, string $postUrl, int $campaignId, ?string $screenshotHash = null): void
    {
        // 1. Blok tekshiruvi
        if (self::isBlocked($user)) {
            throw new \Exception('Siz vaqtincha bloklangansiz. 24 soatdan keyin qayta urinib ko\'ring.', 403);
        }

        // 2. Kunlik limit
        self::checkDailyLimit($user);

        // 3. Post URL duplicate
        self::checkPostUrl($postUrl, $campaignId);

        // 4. Screenshot hash (agar mavjud bo'lsa)
        if ($screenshotHash) {
            self::checkScreenshotHash($screenshotHash);
        }
    }
}
