<?php

namespace App\Services\Influencer;

use App\Models\AIS\Wallet;
use App\Models\Influencer\InfluencerCampaign;
use App\Models\Influencer\InfluencerChannel;
use App\Models\Influencer\InfluencerReward;
use App\Models\Influencer\InfluencerSetting;
use App\Models\Influencer\InfluencerSubmission;
use App\Models\Level\XpLog;
use App\Services\WalletService;
use App\Services\XpService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class InfluencerRewardService
{
    /**
     * Mukofot miqdorini hisoblash
     * final_reward = campaign.reward_amount × channel_type_coefficient
     */
    public static function calculate(InfluencerCampaign $campaign, InfluencerChannel $channel): float
    {
        $setting     = InfluencerSetting::current();
        $coefficient = $setting->getCoefficientForType($channel->type);

        return round((float) $campaign->reward_amount * $coefficient, 4);
    }

    /**
     * Mukofot o'tkazish — DB transaction ichida:
     * 1. Kampaniya byudjetidan yechish
     * 2. Publisher AIS hamyoniga qo'shish
     * 3. XP berish
     * 4. InfluencerReward yozuvi yaratish
     *
     * @throws \Exception
     */
    public static function pay(InfluencerSubmission $submission): InfluencerReward
    {
        return DB::transaction(function () use ($submission) {
            $campaign = InfluencerCampaign::lockForUpdate()->find($submission->campaign_id);
            $channel  = $submission->channel;
            $user     = $submission->user;

            $setting     = InfluencerSetting::current();
            $coefficient = $setting->getCoefficientForType($channel->type);
            $rewardAis   = round((float) $campaign->reward_amount * $coefficient, 4);

            // Byudjet yetarlimi?
            if (!$campaign->hasEnoughBudget($rewardAis)) {
                throw new \Exception("Kampaniya byudjeti yetarli emas. Kerak: {$rewardAis} AIS, qolgan: {$campaign->remaining_budget} AIS");
            }

            // Kampaniya byudjetidan yechish
            $campaign->increment('spent_budget', $rewardAis);

            // Byudjet tugadimi? → paused
            if ($campaign->spent_budget >= $campaign->total_budget) {
                $campaign->update(['status' => InfluencerCampaign::STATUS_PAUSED]);
            }

            // Publisher AIS hamyoniga qo'shish
            $wallet = WalletService::createForUser($user);
            $wallet->increment('balance', $rewardAis);

            // Submission reward_amount ni saqlash
            $submission->update(['reward_amount' => $rewardAis]);

            // InfluencerReward yozuvi
            $reward = InfluencerReward::create([
                'user_id'       => $user->id,
                'submission_id' => $submission->id,
                'campaign_id'   => $campaign->id,
                'channel_id'    => $channel->id,
                'amount'        => $rewardAis,
                'coefficient'   => $coefficient,
                'wallet_tx_id'  => null,
                'created_at'    => now(),
            ]);

            // XP berish (50 XP har bir tasdiqlangan submission uchun)
            try {
                XpService::award(
                    $user,
                    XpLog::ACTION_TASK ?? 'influencer_submission',
                    50,
                    "Influencer submission tasdiqlandi: {$campaign->name}",
                    $submission
                );
            } catch (\Throwable $e) {
                Log::warning('Influencer XP award failed', ['error' => $e->getMessage()]);
            }

            return $reward;
        });
    }
}
