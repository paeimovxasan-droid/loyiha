<?php

namespace App\Services\Influencer;

use App\Models\Influencer\InfluencerCampaign;
use App\Models\Influencer\InfluencerChannel;
use App\Models\Influencer\InfluencerReward;
use App\Models\Influencer\InfluencerSetting;
use App\Models\Influencer\InfluencerSubmission;
use App\Models\User;
use App\Services\TelegramBotService;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

class InfluencerSubmissionService
{
    /**
     * Publisher submission yuborish
     *
     * @throws \Exception
     */
    public static function submit(User $user, array $data, ?UploadedFile $screenshot = null): InfluencerSubmission
    {
        $setting  = InfluencerSetting::current();
        $campaign = InfluencerCampaign::findOrFail($data['campaign_id']);
        $channel  = InfluencerChannel::where('id', $data['channel_id'])
            ->where('user_id', $user->id)
            ->firstOrFail();

        // Modul yoqilganmi?
        if (!$setting->is_enabled) {
            throw new \Exception('Influencer moduli hozircha o\'chirilgan.', 503);
        }

        // Kanal tasdiqlangan bo'lishi kerak
        if (!$channel->isApproved()) {
            throw new \Exception('Faqat tasdiqlangan kanallar orqali submission yuborishingiz mumkin.', 403);
        }

        // Kanal bloklangan bo'lmasligi kerak
        if ($channel->isSuspended()) {
            throw new \Exception('Bu kanal bloklangan.', 403);
        }

        // Kampaniya faolmi?
        if (!$campaign->isActive()) {
            throw new \Exception('Bu kampaniya hozirda faol emas.');
        }

        // Kampaniya byudjeti yetarlimi?
        $rewardAmount = InfluencerRewardService::calculate($campaign, $channel);
        if (!$campaign->hasEnoughBudget($rewardAmount)) {
            throw new \Exception('Kampaniya byudjeti tugagan.');
        }

        // Screenshot majburiymi?
        if ($setting->screenshot_required && !$screenshot) {
            throw new \Exception('Screenshot yuklash majburiy.');
        }

        // Screenshot hash hisoblash
        $screenshotHash = null;
        if ($screenshot) {
            $screenshotHash = md5_file($screenshot->getRealPath());
        }

        // Fraud tekshiruvlari
        InfluencerFraudService::runAllChecks($user, $data['post_url'], $campaign->id, $screenshotHash);

        return DB::transaction(function () use ($user, $data, $campaign, $channel, $screenshot, $screenshotHash, $rewardAmount) {
            // Screenshot saqlash
            $screenshotId = null;
            if ($screenshot) {
                $path = $screenshot->store('influencer/screenshots', 'public');
                $file = \App\Models\File::create([
                    'user_id'   => $user->id,
                    'disk'      => 'public',
                    'path'      => $path,
                    'name'      => $screenshot->getClientOriginalName(),
                    'mime_type' => $screenshot->getMimeType(),
                    'size'      => $screenshot->getSize(),
                ]);
                $screenshotId = $file->id;
            }

            $submission = InfluencerSubmission::create([
                'user_id'         => $user->id,
                'channel_id'      => $channel->id,
                'campaign_id'     => $campaign->id,
                'post_url'        => $data['post_url'],
                'screenshot_id'   => $screenshotId,
                'screenshot_hash' => $screenshotHash,
                'status'          => InfluencerSubmission::STATUS_PENDING,
                'reward_amount'   => $rewardAmount,
            ]);

            // Admin ga bildirishnoma
            try {
                TelegramBotService::notifyAdminInfluencerSubmission(
                    "{$user->name} (@{$user->username})",
                    $campaign->name,
                    $rewardAmount
                );
            } catch (\Throwable $e) {
                Log::warning('Influencer submission notify failed', ['error' => $e->getMessage()]);
            }

            return $submission;
        });
    }

    /**
     * Admin: submission tasdiqlash + mukofot berish
     *
     * @throws \Exception
     */
    public static function approve(InfluencerSubmission $submission, User $admin): InfluencerReward
    {
        if (!$submission->isPending()) {
            throw new \Exception('Faqat kutilayotgan submissionlarni tasdiqlash mumkin.');
        }

        try {
            $reward = DB::transaction(function () use ($submission, $admin) {
                $submission->update([
                    'status'      => InfluencerSubmission::STATUS_APPROVED,
                    'reviewed_at' => now(),
                    'reviewed_by' => $admin->id,
                ]);

                return InfluencerRewardService::pay($submission);
            });

            // Publisher ga Telegram bildirishnoma
            try {
                TelegramBotService::notify(
                    $submission->user,
                    "💰 Submission tasdiqlandi!\n\n" .
                    "📢 Kampaniya: {$submission->campaign->name}\n" .
                    "📌 Kanal: {$submission->channel->name}\n" .
                    "🎁 Mukofot: {$reward->amount} AIS hamyoningizga o'tkazildi!\n\n" .
                    "Davom eting va ko'proq mukofot oling! 🚀",
                    [[['text' => '💰 AIS hamyonni ko\'rish', 'url' => config('app.url') . '/app/wallet']]]
                );
            } catch (\Throwable $e) {
                Log::warning('Influencer approve notify failed', ['error' => $e->getMessage()]);
            }

            return $reward;

        } catch (\Exception $e) {
            // Mukofot o'tkazmasida xatolik
            $submission->update(['status' => InfluencerSubmission::STATUS_REWARD_FAILED]);
            Log::error('Influencer reward payment failed', [
                'submission_id' => $submission->id,
                'error'         => $e->getMessage(),
            ]);
            throw $e;
        }
    }

    /**
     * Admin: submission rad etish
     */
    public static function reject(InfluencerSubmission $submission, User $admin, string $reason): void
    {
        $submission->update([
            'status'           => InfluencerSubmission::STATUS_REJECTED,
            'rejection_reason' => $reason,
            'reviewed_at'      => now(),
            'reviewed_by'      => $admin->id,
        ]);

        // Fraud check — 5 ta rad → blok
        try {
            InfluencerFraudService::checkRejectionCount($submission->user);
        } catch (\Throwable $e) {
            Log::warning('Influencer fraud check failed', ['error' => $e->getMessage()]);
        }

        // Publisher ga Telegram bildirishnoma
        try {
            TelegramBotService::notify(
                $submission->user,
                "❌ Submission rad etildi.\n\n" .
                "📢 Kampaniya: {$submission->campaign->name}\n" .
                "📌 Kanal: {$submission->channel->name}\n" .
                "📝 Sabab: {$reason}\n\n" .
                "Qayta to'g'ri submission yuborishingiz mumkin.",
                [[['text' => '📋 Submissionlarni ko\'rish', 'url' => config('app.url') . '/app/influencer/submissions']]]
            );
        } catch (\Throwable $e) {
            Log::warning('Influencer reject notify failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Admin: ommaviy tasdiqlash (10+ submission → queue)
     */
    public static function bulkApprove(array $ids, User $admin): void
    {
        if (count($ids) > 10) {
            \App\Jobs\Influencer\BulkApproveSubmissions::dispatch($ids, $admin->id);
        } else {
            foreach ($ids as $id) {
                $submission = InfluencerSubmission::find($id);
                if ($submission && $submission->isPending()) {
                    try {
                        self::approve($submission, $admin);
                    } catch (\Throwable $e) {
                        Log::error('Bulk approve failed for submission', [
                            'submission_id' => $id,
                            'error'         => $e->getMessage(),
                        ]);
                    }
                }
            }
        }
    }
}
