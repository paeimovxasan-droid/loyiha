<?php

namespace App\Services;

use App\Models\File;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class FileUploadService
{
    /**
     * Upload an image file, convert it to WebP format, and save the record in the files table.
     *
     * @param UploadedFile $file The uploaded file object
     * @param string $folder The folder inside the storage/app/public directory
     * @return File
     */
    public static function upload(UploadedFile $file, string $folder = 'uploads'): File
    {
        $mimeType = $file->getMimeType();
        $originalName = $file->getClientOriginalName();
        $size = $file->getSize();

        // Check if the uploaded file is an image and can be processed via native PHP image functions
        if (str_starts_with($mimeType, 'image/') && function_exists('imagecreatefromstring')) {
            $imageString = file_get_contents($file->getRealPath());
            $image = @imagecreatefromstring($imageString);
            
            if ($image !== false) {
                // If it's a PNG or GIF, preserve transparency
                imagepalettetotruecolor($image);
                imagealphablending($image, false);
                imagesavealpha($image, true);
                
                // Determine WebP filename
                $filename = Str::uuid() . '.webp';
                $path = $folder . '/' . $filename;
                
                // Save WebP image to output buffer
                ob_start();
                try {
                    imagewebp($image, null, 80);
                    $webpContent = ob_get_clean();
                } catch (\Throwable $e) {
                    ob_end_clean();
                    throw $e;
                }
                
                imagedestroy($image);
                
                // Store the WebP content automatically
                Storage::disk('public')->put($path, $webpContent);
                
                $extension = 'webp';
                $size = strlen($webpContent);
                $mimeType = 'image/webp';
            } else {
                // Fallback: save as original if imagecreatefromstring fails
                $extension = $file->getClientOriginalExtension() ?: 'bin';
                $filename = Str::uuid() . '.' . $extension;
                $path = $file->storeAs($folder, $filename, 'public');
            }
        } else {
            // Non-image file processing
            $extension = $file->getClientOriginalExtension() ?: 'bin';
            $filename = Str::uuid() . '.' . $extension;
            $path = $file->storeAs($folder, $filename, 'public');
        }

        // Save file info to DB
        return File::create([
            'name'      => $originalName,
            'path'      => $path,
            'extension' => $extension,
            'size'      => $size,
            'mime_type' => $mimeType,
        ]);
    }
}
