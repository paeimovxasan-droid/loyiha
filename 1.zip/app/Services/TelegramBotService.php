<?php

namespace App\Services;

use App\Models\TelegramBotLog;
use App\Models\User;
use App\Services\Telegram\Handlers\StartHandler;
use App\Services\Telegram\Handlers\FinancialHandler;
use App\Services\Telegram\Handlers\GameHandler;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class TelegramBotService
{
    /**
     * Webhook so'rovlarini qayta ishlash
     */
    public function handleWebhook(array $update): void
    {
        $message = $update['message'] ?? null;

        if (!$message || empty($message['text'])) {
            return;
        }

        $text = trim($message['text']);
        $from = $message['from'] ?? [];
        $chatId = $message['chat']['id'] ?? null;

        if (!$chatId) {
            return;
        }

        // Buyruqni ajratish
        $parts = explode(' ', $text, 2);
        $command = strtolower($parts[0]);
        $params = $parts[1] ?? '';

        // Log yozish
        TelegramBotLog::create([
            'telegram_id' => (string) ($from['id'] ?? ''),
            'command'     => $command,
            'payload'     => $from,
        ]);

        $this->handleCommand($command, ['raw' => $params], $from, $chatId);
    }

    /**
     * Buyruqlarni dispatcher orqali qayta ishlash
     */
    public function handleCommand(string $command, array $params, array $from, int|string $chatId): void
    {
        switch ($command) {
            case '/start':
                (new StartHandler())->handle($chatId, $params, $from);
                break;

            case '/balance':
                (new FinancialHandler())->handleBalance($chatId, $from);
                break;

            case '/vip':
                (new FinancialHandler())->handleVip($chatId, $from);
                break;

            case '/checkin':
                (new GameHandler())->handleCheckIn($chatId, $from);
                break;

            case '/spin':
                (new GameHandler())->handleSpin($chatId, $from);
                break;

            case '/promo':
                (new GameHandler())->handlePromo($chatId, $params, $from);
                break;

            case '/ref':
                $this->handleRef($chatId, $from);
                break;

            case '/roadmap':
                $this->handleRoadmap($chatId);
                break;

            default:
                $this->handleHelp($chatId);
                break;
        }
    }

    /**
     * Qolgan kichik buyruqlar (vaqtincha shu yerda)
     */
    private function handleRef(int|string $chatId, array $from): void
    {
        $telegramId = (string) ($from['id'] ?? '');
        $user = User::where('telegram_id', $telegramId)->first();

        if (!$user) {
            self::sendMessage($chatId, "❌ Ro'yxatdan o'ting.");
            return;
        }

        $botUsername = config('services.telegram.bot_username', 'aisoqqa_bot');
        $refLink = "https://t.me/{$botUsername}?start=ref_{$user->username}";
        $text = "🔗 Referral havola:\n{$refLink}";

        self::sendMessage($chatId, $text);
    }

    private function handleRoadmap(int|string $chatId): void
    {
        $text = "🗺️ Roadmap Mini App ichida mavjud.";
        self::sendMessage($chatId, $text);
    }

    private function handleHelp(int|string $chatId): void
    {
        $text = "📋 Buyruqlar: /start, /balance, /checkin, /ref, /promo, /spin, /vip, /roadmap";
        self::sendMessage($chatId, $text);
    }

    /**
     * Xabar yuborish — inline keyboard tugmalari bilan
     *
     * $buttons format:
     * [
     *   [['text' => 'Ko\'rish', 'url' => 'https://...']],
     *   [['text' => 'Tasdiqlash', 'callback_data' => 'approve:123'], ['text' => 'Rad etish', 'callback_data' => 'reject:123']],
     * ]
     */
    public static function sendMessage(int|string $chatId, string $text, array $replyMarkup = []): void
    {
        $token = config('services.telegram.bot_token');
        if (!$token) return;

        $payload = [
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => 'HTML',
        ];

        if (!empty($replyMarkup)) {
            $payload['reply_markup'] = json_encode(['inline_keyboard' => $replyMarkup]);
        }

        try {
            Http::timeout(5)->post("https://api.telegram.org/bot{$token}/sendMessage", $payload);
        } catch (\Throwable $e) {
            Log::warning('TelegramBotService::sendMessage failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Foydalanuvchiga xabar + ixtiyoriy tugmalar
     */
    public static function notify(User $user, string $message, array $buttons = []): void
    {
        if ($user->telegram_id) {
            self::sendMessage($user->telegram_id, $message, $buttons);
        }
    }

    /**
     * Admin yopiq guruhga xabar yuborish
     * ADMIN_BOT_TOKEN + ADMIN_GROUP_ID ishlatiladi
     * Fallback: asosiy bot + TELEGRAM_CHANNEL_ID
     */
    public static function notifyAdmin(string $message, array $buttons = []): void
    {
        // 1. Admin bot + yopiq guruh (asosiy variant)
        $adminToken = config('services.telegram_admin.bot_token') ?: env('ADMIN_BOT_TOKEN');
        $groupId = config('services.telegram_admin.group_id') ?: env('ADMIN_GROUP_ID');

        if ($adminToken && $groupId) {
            self::sendMessageWithToken($adminToken, $groupId, $message, $buttons);
            return;
        }

        // 2. Asosiy bot + kanal (fallback)
        $channelId = config('services.telegram.channel_id') ?: env('TELEGRAM_CHANNEL_ID');
        if ($channelId) {
            self::sendMessage($channelId, $message, $buttons);
            return;
        }

        // 3. Super-adminlarga DM (oxirgi variant)
        try {
            $superAdmins = \App\Models\User::role('super-admin')
                ->whereNotNull('telegram_id')
                ->get();
            foreach ($superAdmins as $admin) {
                self::sendMessage($admin->telegram_id, $message, $buttons);
            }
        } catch (\Throwable $e) {
            Log::warning('TelegramBotService::notifyAdmin failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Ma'lum token bilan xabar yuborish (admin bot uchun)
     */
    public static function sendMessageWithToken(string $token, int|string $chatId, string $text, array $replyMarkup = []): void
    {
        if (!$token) return;

        $payload = [
            'chat_id'    => $chatId,
            'text'       => $text,
            'parse_mode' => 'HTML',
        ];

        if (!empty($replyMarkup)) {
            $payload['reply_markup'] = json_encode(['inline_keyboard' => $replyMarkup]);
        }

        try {
            Http::timeout(5)->post("https://api.telegram.org/bot{$token}/sendMessage", $payload);
        } catch (\Throwable $e) {
            Log::warning('TelegramBotService::sendMessageWithToken failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Rasm + matn yuborish (kanalga chek yuborish uchun)
     */
    public static function sendPhotoWithToken(string $token, int|string $chatId, string $photoUrl, string $caption, array $replyMarkup = []): void
    {
        if (!$token) return;

        $payload = [
            'chat_id'    => $chatId,
            'photo'      => $photoUrl,
            'caption'    => $caption,
            'parse_mode' => 'HTML',
        ];

        if (!empty($replyMarkup)) {
            $payload['reply_markup'] = json_encode(['inline_keyboard' => $replyMarkup]);
        }

        try {
            Http::timeout(10)->post("https://api.telegram.org/bot{$token}/sendPhoto", $payload);
        } catch (\Throwable $e) {
            Log::warning('TelegramBotService::sendPhotoWithToken failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Lokal fayldan rasm yuborish (multipart)
     */
    public static function sendPhotoFileWithToken(string $token, int|string $chatId, string $filePath, string $caption): void
    {
        if (!$token || !file_exists($filePath)) return;

        try {
            Http::timeout(15)
                ->attach('photo', file_get_contents($filePath), basename($filePath))
                ->post("https://api.telegram.org/bot{$token}/sendPhoto", [
                    'chat_id'    => $chatId,
                    'caption'    => $caption,
                    'parse_mode' => 'HTML',
                ]);
        } catch (\Throwable $e) {
            Log::warning('TelegramBotService::sendPhotoFileWithToken failed', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Yechim tasdiqlanganda kanalga chek yuborish
     * Rasm (generatsiya qilingan chek) + matn — faqat -1003980015180 kanalga
     */
    public static function sendWithdrawalReceiptToChannel(\App\Models\Payment\Withdrawal $withdrawal): void
    {
        $botToken = env('ADMIN_BOT_TOKEN');
        $channelId = '-1003980015180';

        if (!$botToken) return;

        $user = $withdrawal->user;
        $userName = $user ? $user->name : 'Noma\'lum';
        $username = $user?->username ? '(@' . $user->username . ')' : '';

        // Matn (rasm ostida yoki alohida xabar sifatida)
        $caption = "✅ <b>To'lov tasdiqlandi!</b>\n\n" .
            "👤 {$userName} {$username}\n" .
            "💰 " . number_format($withdrawal->final_amount, 0, '.', ',') . " UZS\n" .
            "🏦 " . ($withdrawal->method_name ?? '') . "\n" .
            "📅 " . $withdrawal->created_at->format('d.m.Y H:i') . "\n\n" .
            "🔗 AISOQQA.UZ";

        // Chek rasmi generatsiya qilish
        $receiptPath = null;
        try {
            $receiptPath = \App\Services\ReceiptImageService::generateWithdrawalReceipt($withdrawal);
        } catch (\Throwable $e) {
            Log::warning('Receipt image generation failed', ['error' => $e->getMessage()]);
        }

        if ($receiptPath && file_exists($receiptPath)) {
            // Rasm + matn yuborish
            self::sendPhotoFileWithToken($botToken, $channelId, $receiptPath, $caption);

            // Temp faylni o'chirish
            @unlink($receiptPath);
        } else {
            // Rasm generatsiya bo'lmasa — faqat matn
            $textReceipt = "┌─────────────────────────────┐\n" .
                "│  🧾 <b>TO'LOV CHEKI — AISOQQA.UZ</b>\n" .
                "├─────────────────────────────┤\n" .
                "│\n" .
                "│  Foydalanuvchi:   <b>{$userName} {$username}</b>\n" .
                "│  Summa:          <b>" . number_format($withdrawal->final_amount, 0, '.', ',') . " UZS</b>\n" .
                "│  To'lov usuli:   <b>" . ($withdrawal->method_name ?? 'Noma\'lum') . "</b>\n" .
                "│  Raqam:          <b>" . ($withdrawal->receiver_number ?? '—') . "</b>\n" .
                "│  Sana:           <b>" . $withdrawal->created_at->format('d.m.Y H:i') . "</b>\n" .
                "│  Tranzaksiya ID: <b>#WD-" . str_pad($withdrawal->id, 5, '0', STR_PAD_LEFT) . "</b>\n" .
                "│  Komissiya:      <b>" . number_format($withdrawal->charge, 0, '.', ',') . " UZS</b>\n" .
                "│\n" .
                "├─────────────────────────────┤\n" .
                "│  AISOQQA.UZ                  ✅ <b>Tasdiqlangan</b>\n" .
                "└─────────────────────────────┘";

            self::sendMessageWithToken($botToken, $channelId, $textReceipt . "\n\n" . $caption);
        }
    }

    /**
     * Support ticket bildirishnomasi — admin uchun
     */
    public static function notifyAdminNewTicket(string $ticketNumber, string $subject, string $userName, int $ticketId): void
    {
        $appUrl = config('app.url');
        $message =
            "🎫 <b>Yangi support ticket!</b>\n\n" .
            "🔢 #{$ticketNumber}\n" .
            "👤 {$userName}\n" .
            "📌 {$subject}";

        $buttons = [[
            ['text' => '👁 Ko\'rish', 'url' => "{$appUrl}/admin/support/{$ticketId}"],
        ]];

        self::notifyAdmin($message, $buttons);
    }

    /**
     * Support ticket javob bildirishnomasi — foydalanuvchi uchun
     */
    public static function notifyUserTicketReply(User $user, string $ticketNumber, string $subject, string $preview, int $ticketId): void
    {
        $appUrl = config('app.url');
        $message =
            "📩 <b>Ticketingizga javob keldi!</b>\n\n" .
            "🔢 #{$ticketNumber}\n" .
            "📌 {$subject}\n\n" .
            "💬 " . mb_substr($preview, 0, 200);

        $buttons = [[
            ['text' => '💬 Javobni ko\'rish', 'url' => "{$appUrl}/app/support/{$ticketId}"],
        ]];

        self::notify($user, $message, $buttons);
    }

    /**
     * Depozit bildirishnomasi — admin uchun
     */
    public static function notifyAdminNewDeposit(string $userName, float $amount, int $depositId): void
    {
        $appUrl = config('app.url');
        $message =
            "💰 <b>Yangi depozit so'rovi!</b>\n\n" .
            "👤 {$userName}\n" .
            "💵 " . number_format($amount, 2) . " UZS";

        $buttons = [[
            ['text' => '✅ Ko\'rish', 'url' => "{$appUrl}/admin/deposits/{$depositId}"],
        ]];

        self::notifyAdmin($message, $buttons);
    }

    /**
     * Yechim bildirishnomasi — admin uchun
     */
    public static function notifyAdminNewWithdrawal(string $userName, float $amount, int $withdrawalId): void
    {
        $appUrl = config('app.url');
        $message =
            "💸 <b>Yangi yechim so'rovi!</b>\n\n" .
            "👤 {$userName}\n" .
            "💵 " . number_format($amount, 2) . " UZS";

        $buttons = [[
            ['text' => '👁 Ko\'rish', 'url' => "{$appUrl}/admin/withdrawals/{$withdrawalId}"],
        ]];

        self::notifyAdmin($message, $buttons);
    }

    /**
     * KYC bildirishnomasi — admin uchun
     */
    public static function notifyAdminKyc(string $userName, int $userId, string $type = 'passport'): void
    {
        $appUrl = config('app.url');
        $emoji  = $type === 'face' ? '🤳' : '🪪';
        $label  = $type === 'face' ? 'Face ID' : 'Pasport';

        $message =
            "{$emoji} <b>Yangi KYC so'rovi ({$label})!</b>\n\n" .
            "👤 {$userName}";

        $url = $type === 'face'
            ? "{$appUrl}/admin/kyc/face"
            : "{$appUrl}/admin/kyc/passport/{$userId}";

        $buttons = [[
            ['text' => '👁 Ko\'rib chiqish', 'url' => $url],
        ]];

        self::notifyAdmin($message, $buttons);
    }

    /**
     * Influencer kanal bildirishnomasi — admin uchun
     */
    public static function notifyAdminInfluencerChannel(string $userName, string $channelName, string $channelType): void
    {
        $appUrl  = config('app.url');
        $message =
            "📢 <b>Yangi influencer kanal!</b>\n\n" .
            "👤 {$userName}\n" .
            "📌 {$channelName}\n" .
            "🔗 {$channelType}";

        $buttons = [[
            ['text' => '👁 Ko\'rish', 'url' => "{$appUrl}/admin/influencer/channels"],
        ]];

        self::notifyAdmin($message, $buttons);
    }

    /**
     * Influencer submission bildirishnomasi — admin uchun
     */
    public static function notifyAdminInfluencerSubmission(string $userName, string $campaignName, float $rewardAmount): void
    {
        $appUrl  = config('app.url');
        $message =
            "📋 <b>Yangi influencer submission!</b>\n\n" .
            "👤 {$userName}\n" .
            "📢 {$campaignName}\n" .
            "💰 " . number_format($rewardAmount, 2) . " AIS";

        $buttons = [[
            ['text' => '👁 Ko\'rib chiqish', 'url' => "{$appUrl}/admin/influencer/submissions"],
        ]];

        self::notifyAdmin($message, $buttons);
    }
}
