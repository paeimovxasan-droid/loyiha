<?php

namespace App\Services;

use App\Models\User;
use App\Models\Payment\Deposit;
use App\Models\Game\UserQuest;
use App\Models\Level\UserLevel;
use Illuminate\Support\Facades\DB;

/**
 * Withdrawal Scoring Service
 * 
 * Foydalanuvchi pul yechish uchun 100 balli shkalada kamida 20 ball yig'ishi kerak.
 * 
 * Ball taqsimoti:
 * ┌────────────────────────────────────────────────────────────────┐
 * │ Mezon                              │ Max ball │ Tafsilot       │
 * ├────────────────────────────────────┼──────────┼────────────────┤
 * │ 1. Yangi depozit (so'nggi 7 kun)  │   25     │ Har depozit +5 │
 * │ 2. Kvestlar bajarilgani           │   20     │ 10+ kvest = 20 │
 * │ 3. Referral taklif qilgani        │   15     │ Har ref +3     │
 * │ 4. Referallar depozit qilgani     │   20     │ 20%+ = max     │
 * │ 5. Shaxsiy level (XP)             │   10     │ Lv5+ = max     │
 * │ 6. Referallar faolligi            │   10     │ Lv3+ ref bonus │
 * │ JAMI                              │  100     │                │
 * ├────────────────────────────────────┼──────────┼────────────────┤
 * │ JARIMA: Nofaol referallar         │  -30     │ Lv3 dan past   │
 * └────────────────────────────────────────────────────────────────┘
 * 
 * Minimal yechish balli: 20
 */
class WithdrawalScoringService
{
    /** Minimal ball — yechish uchun */
    public const MIN_SCORE = 20;

    /** Ball taqsimoti */
    private const MAX_DEPOSIT_SCORE = 25;
    private const MAX_QUEST_SCORE = 20;
    private const MAX_REFERRAL_INVITE_SCORE = 15;
    private const MAX_REFERRAL_DEPOSIT_SCORE = 20;
    private const MAX_LEVEL_SCORE = 10;
    private const MAX_REFERRAL_ACTIVITY_SCORE = 10;
    private const MAX_INACTIVE_PENALTY = -30;

    /**
     * Foydalanuvchining yechish skoringini hisoblash
     * 
     * @return array ['score' => int, 'details' => [...], 'can_withdraw' => bool, 'message' => string]
     */
    public static function calculate(User $user): array
    {
        $details = [];

        // 1. Yangi depozit (so'nggi 7 kunda tasdiqlangan depozitlar)
        $recentDeposits = Deposit::where('user_id', $user->id)
            ->where('status', 'approved')
            ->where('created_at', '>=', now()->subDays(7))
            ->count();

        $depositScore = min(self::MAX_DEPOSIT_SCORE, $recentDeposits * 5);
        $details['recent_deposits'] = [
            'score' => $depositScore,
            'max' => self::MAX_DEPOSIT_SCORE,
            'count' => $recentDeposits,
            'label' => "Yangi depozitlar (7 kun): {$recentDeposits} ta",
            'hint' => $depositScore < self::MAX_DEPOSIT_SCORE
                ? 'Yangi depozit qiling — har biri +5 ball'
                : null,
        ];

        // 2. Kvestlar bajarilgani (approved)
        $completedQuests = UserQuest::where('user_id', $user->id)
            ->where('status', 'completed')
            ->count();

        $questScore = min(self::MAX_QUEST_SCORE, (int) ($completedQuests / 10 * self::MAX_QUEST_SCORE));
        // 10+ kvest = max ball
        if ($completedQuests >= 10) {
            $questScore = self::MAX_QUEST_SCORE;
        }
        $details['quests'] = [
            'score' => $questScore,
            'max' => self::MAX_QUEST_SCORE,
            'count' => $completedQuests,
            'label' => "Bajarilgan kvestlar: {$completedQuests}/10",
            'hint' => $completedQuests < 10
                ? 'Kamida 10 ta kvest bajaring'
                : null,
        ];

        // 3. Referral taklif qilgani
        $totalReferrals = $user->referrals()->count();
        $referralInviteScore = min(self::MAX_REFERRAL_INVITE_SCORE, $totalReferrals * 3);
        $details['referral_invites'] = [
            'score' => $referralInviteScore,
            'max' => self::MAX_REFERRAL_INVITE_SCORE,
            'count' => $totalReferrals,
            'label' => "Taklif qilingan referallar: {$totalReferrals} ta",
            'hint' => $referralInviteScore < self::MAX_REFERRAL_INVITE_SCORE
                ? "Do'stlarni taklif qiling — har biri +3 ball"
                : null,
        ];

        // 4. Referallarning depozit qilganlari (20% = max ball)
        $referralsWithDeposit = 0;
        if ($totalReferrals > 0) {
            $referralIds = $user->referrals()->pluck('id');
            $referralsWithDeposit = Deposit::whereIn('user_id', $referralIds)
                ->where('status', 'approved')
                ->distinct('user_id')
                ->count('user_id');

            $depositPercent = ($referralsWithDeposit / $totalReferrals) * 100;
        } else {
            $depositPercent = 0;
        }

        // 20% yoki undan ko'p = max ball
        $referralDepositScore = min(
            self::MAX_REFERRAL_DEPOSIT_SCORE,
            (int) ($depositPercent / 20 * self::MAX_REFERRAL_DEPOSIT_SCORE)
        );
        $details['referral_deposits'] = [
            'score' => $referralDepositScore,
            'max' => self::MAX_REFERRAL_DEPOSIT_SCORE,
            'count' => $referralsWithDeposit,
            'percent' => round($depositPercent, 1),
            'label' => "Referallar depozit qilgani: {$referralsWithDeposit}/{$totalReferrals} (" . round($depositPercent) . "%)",
            'hint' => $depositPercent < 20
                ? "Referallaringizning kamida 20% depozit qilishi kerak"
                : null,
        ];

        // 5. Shaxsiy level
        $userLevel = $user->userLevel?->level ?? 0;
        $levelScore = min(self::MAX_LEVEL_SCORE, $userLevel * 2); // Lv5 = max
        $details['personal_level'] = [
            'score' => $levelScore,
            'max' => self::MAX_LEVEL_SCORE,
            'level' => $userLevel,
            'label' => "Shaxsiy daraja: Level {$userLevel}",
            'hint' => $userLevel < 5
                ? "Level 5 ga yeting — to'liq ball olasiz"
                : null,
        ];

        // 6. Referallar faolligi (Level 3+ referallar bonusi)
        $activeReferrals = 0;
        $inactiveReferrals = 0;
        if ($totalReferrals > 0) {
            $referralIds = $user->referrals()->pluck('id');

            $activeReferrals = UserLevel::whereIn('user_id', $referralIds)
                ->where('level', '>=', 3)
                ->count();

            $inactiveReferrals = $totalReferrals - $activeReferrals;
        }

        $activityPercent = $totalReferrals > 0
            ? ($activeReferrals / $totalReferrals) * 100
            : 0;

        $referralActivityScore = min(
            self::MAX_REFERRAL_ACTIVITY_SCORE,
            (int) ($activityPercent / 50 * self::MAX_REFERRAL_ACTIVITY_SCORE) // 50%+ = max
        );
        $details['referral_activity'] = [
            'score' => $referralActivityScore,
            'max' => self::MAX_REFERRAL_ACTIVITY_SCORE,
            'active' => $activeReferrals,
            'inactive' => $inactiveReferrals,
            'label' => "Faol referallar (Lv3+): {$activeReferrals}/{$totalReferrals}",
            'hint' => $activityPercent < 50
                ? "Referallaringizni Level 3 ga yetishga undang"
                : null,
        ];

        // JARIMA: Nofaol referallar (Lv3 dan past)
        $penalty = 0;
        if ($totalReferrals > 0 && $inactiveReferrals > 0) {
            $inactivePercent = ($inactiveReferrals / $totalReferrals) * 100;
            // 50%+ nofaol = max jarima (-30)
            // Har 10% nofaol = -6 ball
            $penalty = min(30, (int) ($inactivePercent / 50 * 30));
            $penalty = -$penalty;
        }
        $details['inactive_penalty'] = [
            'score' => $penalty,
            'max' => self::MAX_INACTIVE_PENALTY,
            'inactive_count' => $inactiveReferrals,
            'label' => "Nofaol referallar jarimasi: {$inactiveReferrals} ta (Lv3 dan past)",
            'hint' => $penalty < 0
                ? "Referallaringizga ustozlik qiling — ularni faollashtiring!"
                : null,
        ];

        // Jami ball
        $totalScore = $depositScore + $questScore + $referralInviteScore
            + $referralDepositScore + $levelScore + $referralActivityScore + $penalty;

        $totalScore = max(0, min(100, $totalScore));

        $canWithdraw = $totalScore >= self::MIN_SCORE;

        // Xabar
        $message = $canWithdraw
            ? null
            : self::buildMessage($totalScore, $details);

        return [
            'score' => $totalScore,
            'min_score' => self::MIN_SCORE,
            'can_withdraw' => $canWithdraw,
            'message' => $message,
            'details' => $details,
        ];
    }

    /**
     * Yechish mumkin emasligini tushuntiruvchi xabar
     */
    private static function buildMessage(int $score, array $details): string
    {
        $needed = self::MIN_SCORE - $score;
        $msg = "Yechish uchun kamida " . self::MIN_SCORE . " ball kerak. Sizda: {$score} ball (yana {$needed} ball yig'ing).\n\n";
        $msg .= "Ball oshirish yo'llari:\n";

        $hints = [];
        foreach ($details as $detail) {
            if (!empty($detail['hint']) && $detail['score'] < ($detail['max'] ?? 999)) {
                $hints[] = "• " . $detail['hint'];
            }
        }

        return $msg . implode("\n", array_slice($hints, 0, 4));
    }

    /**
     * Tez tekshiruv — yechish mumkinmi?
     */
    public static function canWithdraw(User $user): bool
    {
        return self::calculate($user)['can_withdraw'];
    }

    /**
     * Faqat ball qaytarish
     */
    public static function getScore(User $user): int
    {
        return self::calculate($user)['score'];
    }
}
