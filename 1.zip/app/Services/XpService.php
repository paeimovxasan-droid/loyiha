<?php

namespace App\Services;

use App\Models\Level\UserLevel;
use App\Models\Level\XpLog;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;

class XpService
{
    /**
     * Foydalanuvchiga XP berish va darajani yangilash
     *
     * @param User $user
     * @param string $action  XpLog::ACTION_* konstantalaridan biri
     * @param int $xp         Beriluvchi XP (0 = action config dan oladi)
     * @param string|null $description
     * @param Model|null $model  Polymorphic model
     * @return array ['xp' => int, 'leveled_up' => bool, 'new_level' => int]
     */
    public static function award(
        User $user,
        string $action,
        int $xp = 0,
        ?string $description = null,
        ?Model $model = null
    ): array {
        // XP miqdorini action config dan olish (agar berilmagan bo'lsa)
        if ($xp <= 0) {
            $config = \App\Models\Level\XpLog::getActionXp($action);
            $xp = $config ?? 0;
        }

        if ($xp <= 0) return ['xp' => 0, 'leveled_up' => false, 'new_level' => 0];

        return \Illuminate\Support\Facades\DB::transaction(function () use ($user, $action, $xp, $description, $model) {
            // XP log yozish
            $log = XpLog::create([
                'user_id'     => $user->id,
                'action'      => $action,
                'xp'          => $xp,
                'description' => $description,
                'xpable_type' => $model ? get_class($model) : null,
                'xpable_id'   => $model?->id,
            ]);

            // UserLevel olish yoki yaratish (lock bilan)
            $userLevel = UserLevel::lockForUpdate()->where('user_id', $user->id)->first();

            if (!$userLevel) {
                $userLevel = UserLevel::create([
                    'user_id'       => $user->id,
                    'level'         => 0,
                    'total_xp'      => 0,
                    'current_xp'    => 0,
                    'next_level_xp' => 100,
                    'title'         => 'Newcomer',
                    'badge_color'   => '#64748b',
                ]);
            }

            $oldLevel = $userLevel->level;
            $newTotalXp = $userLevel->total_xp + $xp;
            $newLevel = UserLevel::calcLevel($newTotalXp);
            $newLevel = min(99, $newLevel);

            [$title, $color] = UserLevel::getTitleAndColor($newLevel);

            $userLevel->update([
                'total_xp'      => $newTotalXp,
                'level'         => $newLevel,
                'current_xp'    => UserLevel::currentLevelXp($newTotalXp, $newLevel),
                'next_level_xp' => UserLevel::xpForLevel($newLevel),
                'title'         => $title,
                'badge_color'   => $color,
            ]);

            $leveledUp = $newLevel > $oldLevel;

            // Level o'zgarganda quest progress yangilash
            if ($leveledUp) {
                \App\Services\QuestService::updateProgress($user, \App\Models\Game\Quest::REQ_LEVEL_REACH, $newLevel);

                // Telegram bildirishnoma
                \App\Services\TelegramBotService::notify(
                    $user,
                    "🎉 Tabriklaymiz! Siz {$newLevel}-darajaga ko'tarildingiz!\n\n" .
                    "🏅 Unvon: <b>{$title}</b>",
                    [[['text' => '⚡ Darajamni ko\'rish', 'url' => config('app.url') . '/app/level']]]
                );

                // Social proof — daraja oshishi
                \App\Services\Marketing\SocialProofService::record('level_up', $user, $newLevel);
            }

            return [
                'xp'        => $xp,
                'leveled_up'=> $leveledUp,
                'old_level' => $oldLevel,
                'new_level' => $newLevel,
                'title'     => $title,
            ];
        });
    }

    /**
     * Foydalanuvchi darajasini qayta hisoblash (barcha XP log asosida)
     */
    public static function recalculate(User $user): void
    {
        \Illuminate\Support\Facades\DB::transaction(function () use ($user) {
            $totalXp = XpLog::where('user_id', $user->id)->sum('xp');
            $level = UserLevel::calcLevel($totalXp);
            [$title, $color] = UserLevel::getTitleAndColor($level);

            UserLevel::updateOrCreate(
                ['user_id' => $user->id],
                [
                    'level'         => $level,
                    'total_xp'      => $totalXp,
                    'current_xp'    => UserLevel::currentLevelXp($totalXp, $level),
                    'next_level_xp' => UserLevel::xpForLevel($level),
                    'title'         => $title,
                    'badge_color'   => $color,
                ]
            );
        });
    }
}
