<?php

namespace App\Services\Medical;

use App\Models\Medical\Consultation;
use App\Models\Medical\DoctorProfile;
use App\Models\Medical\MedicalComplaint;
use App\Models\Medical\MedicalSetting;
use App\Services\TelegramBotService;
use Illuminate\Support\Facades\Log;

class QualityControlService
{
    /**
     * Shifokor reytingini qayta hisoblash
     */
    public static function recalculateRating(DoctorProfile $doctor): float
    {
        $avg = $doctor->reviews()->avg('rating') ?? 0;
        $count = $doctor->reviews()->count();

        $doctor->update([
            'rating'        => round($avg, 2),
            'reviews_count' => $count,
        ]);

        return round($avg, 2);
    }

    /**
     * Avtomatik suspend tekshiruvi
     * Qaytaradi: true agar suspend qilingan bo'lsa
     */
    public static function checkAutoSuspend(DoctorProfile $doctor): bool
    {
        if ($doctor->status !== DoctorProfile::STATUS_APPROVED) {
            return false;
        }

        $autoSuspendRating = (float) MedicalSetting::getValue('auto_suspend_rating', 2.0);
        $autoSuspendComplaints = (int) MedicalSetting::getValue('auto_suspend_complaints', 3);
        $autoSuspendExpired = (int) MedicalSetting::getValue('auto_suspend_expired', 5);

        // 1. Reyting juda past
        if ($doctor->rating > 0 && $doctor->rating < $autoSuspendRating) {
            self::suspendDoctor($doctor, "Reyting {$autoSuspendRating} dan past ({$doctor->rating})");
            return true;
        }

        // 2. Asosli shikoyatlar soni
        $justifiedComplaints = MedicalComplaint::where('doctor_id', $doctor->user_id)
            ->where('is_justified', true)
            ->count();

        if ($justifiedComplaints >= $autoSuspendComplaints) {
            self::suspendDoctor($doctor, "{$justifiedComplaints} ta asosli shikoyat");
            return true;
        }

        // 3. Ketma-ket muddati o'tgan maslahatlar
        $consecutiveExpired = Consultation::where('doctor_id', $doctor->user_id)
            ->where('status', Consultation::STATUS_EXPIRED)
            ->latest()
            ->limit($autoSuspendExpired)
            ->count();

        if ($consecutiveExpired >= $autoSuspendExpired) {
            self::suspendDoctor($doctor, "{$consecutiveExpired} ta ketma-ket muddati o'tgan maslahat");
            return true;
        }

        // Ogohlantirish (reyting 3.0 dan past)
        $warningRating = (float) MedicalSetting::getValue('warning_rating', 3.0);
        if ($doctor->rating > 0 && $doctor->rating < $warningRating && $doctor->rating >= $autoSuspendRating) {
            TelegramBotService::notify(
                $doctor->user,
                "⚠️ Reytingingiz {$doctor->rating} ga tushdi.\n"
                . "Sifatni oshiring, aks holda profilingiz to'xtatilishi mumkin."
            );
        }

        return false;
    }

    /**
     * 30 kun faoliyatsiz shifokorlarni nofaol qilish
     */
    public static function markInactiveDoctors(): int
    {
        $inactivityDays = (int) MedicalSetting::getValue('inactivity_days', 30);
        $threshold = now()->subDays($inactivityDays);

        $inactiveDoctors = DoctorProfile::where('status', DoctorProfile::STATUS_APPROVED)
            ->where(function ($q) use ($threshold) {
                $q->where('last_active_at', '<', $threshold)
                  ->orWhereNull('last_active_at');
            })
            ->whereDoesntHave('consultations', function ($q) use ($threshold) {
                $q->where('created_at', '>=', $threshold);
            })
            ->get();

        $count = 0;
        foreach ($inactiveDoctors as $doctor) {
            $doctor->update(['status' => DoctorProfile::STATUS_INACTIVE]);
            TelegramBotService::notify(
                $doctor->user,
                "💤 {$inactivityDays} kun faoliyatsiz bo'lgansiz.\n"
                . "Profilingiz nofaol holatga o'tkazildi.\n"
                . "Platformaga kirib faollashtirishingiz mumkin."
            );
            $count++;
        }

        return $count;
    }

    /**
     * Shifokorni qayta faollashtirish
     */
    public static function reactivate(DoctorProfile $doctor): void
    {
        $autoSuspendRating = (float) MedicalSetting::getValue('auto_suspend_rating', 2.0);
        $newRating = $doctor->rating < $autoSuspendRating ? 3.0 : $doctor->rating;

        $doctor->update([
            'status' => DoctorProfile::STATUS_APPROVED,
            'rating' => $newRating,
        ]);

        TelegramBotService::notify(
            $doctor->user,
            "✅ Profilingiz qayta faollashtirildi!\nReytingingiz: {$newRating}"
        );
    }

    /**
     * Shifokorni suspend qilish
     */
    private static function suspendDoctor(DoctorProfile $doctor, string $reason): void
    {
        $doctor->update(['status' => DoctorProfile::STATUS_SUSPENDED]);

        TelegramBotService::notify(
            $doctor->user,
            "🚫 Profilingiz to'xtatildi.\n📋 Sabab: {$reason}\n\nAdmin bilan bog'laning."
        );

        TelegramBotService::notifyAdmin(
            "🚫 Shifokor avtomatik to'xtatildi\n"
            . "👨‍⚕️ {$doctor->user->name}\n"
            . "📋 Sabab: {$reason}"
        );

        Log::info('Doctor auto-suspended', [
            'doctor_id' => $doctor->id,
            'user_id'   => $doctor->user_id,
            'reason'    => $reason,
        ]);
    }
}
