<?php

namespace App\Services\Medical;

use App\Models\AIS\Wallet;
use App\Models\Finance\Transaction;
use App\Models\Medical\MedicalSetting;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class EscrowService
{
    /**
     * Bemorning AIS balansidan summani muzlatish
     *
     * @throws \Exception Balans yetarli bo'lmasa
     */
    public static function freeze(User $patient, float $amount, Model $reference): void
    {
        $wallet = Wallet::where('user_id', $patient->id)->lockForUpdate()->first();

        if (!$wallet || !$wallet->hasEnough($amount)) {
            throw new \Exception('Balansingiz yetarli emas. Kamida ' . $amount . ' AIS kerak.');
        }

        $wallet->decrement('balance', $amount);
        $wallet->increment('frozen_balance', $amount);

        Transaction::create([
            'user_id'              => $patient->id,
            'type'                 => 'medical_escrow_freeze',
            'transactionable_type' => get_class($reference),
            'transactionable_id'   => $reference->id,
            'amount'               => $amount,
            'balance_before'       => $wallet->balance + $amount,
            'balance_after'        => $wallet->balance,
            'direction'            => 'debit',
            'status'               => 'completed',
            'description'          => 'Tibbiy xizmat uchun to\'lov muzlatildi (escrow)',
        ]);
    }

    /**
     * Muzlatilgan summani shifokorga o'tkazish (komissiya chiqarilgan)
     *
     * @return array ['doctor_share' => float, 'platform_fee' => float]
     */
    public static function release(User $patient, User $doctor, float $amount, float $commissionPercent, Model $reference): array
    {
        $platformFee = round($amount * $commissionPercent / 100, 4);
        $doctorShare = $amount - $platformFee;

        // Bemor frozen kamaytirish
        $patientWallet = Wallet::where('user_id', $patient->id)->lockForUpdate()->first();
        $patientWallet->decrement('frozen_balance', $amount);

        // Shifokor hamyoniga to'lov
        $doctorWallet = Wallet::where('user_id', $doctor->id)->lockForUpdate()->first();
        if (!$doctorWallet) {
            $doctorWallet = \App\Services\WalletService::createForUser($doctor);
            $doctorWallet = Wallet::where('user_id', $doctor->id)->lockForUpdate()->first();
        }
        $doctorWallet->increment('balance', $doctorShare);

        // Tranzaksiya — shifokor daromadi
        Transaction::create([
            'user_id'              => $doctor->id,
            'type'                 => 'medical_earning',
            'transactionable_type' => get_class($reference),
            'transactionable_id'   => $reference->id,
            'amount'               => $doctorShare,
            'balance_before'       => $doctorWallet->balance - $doctorShare,
            'balance_after'        => $doctorWallet->balance,
            'direction'            => 'credit',
            'status'               => 'completed',
            'description'          => "Tibbiy xizmat daromadi ({$commissionPercent}% komissiya chiqarilgan)",
        ]);

        return [
            'doctor_share' => $doctorShare,
            'platform_fee' => $platformFee,
        ];
    }

    /**
     * Muzlatilgan summani bemorga qaytarish
     */
    public static function refund(User $patient, float $amount, Model $reference, string $reason = 'To\'lov qaytarildi'): void
    {
        $wallet = Wallet::where('user_id', $patient->id)->lockForUpdate()->first();
        $wallet->decrement('frozen_balance', $amount);
        $wallet->increment('balance', $amount);

        Transaction::create([
            'user_id'              => $patient->id,
            'type'                 => 'medical_refund',
            'transactionable_type' => get_class($reference),
            'transactionable_id'   => $reference->id,
            'amount'               => $amount,
            'balance_before'       => $wallet->balance - $amount,
            'balance_after'        => $wallet->balance,
            'direction'            => 'credit',
            'status'               => 'completed',
            'description'          => $reason,
        ]);
    }

    /**
     * Joriy komissiya foizini olish
     */
    public static function getCommissionPercent(): float
    {
        return (float) MedicalSetting::getValue('commission_percent', 20);
    }
}
