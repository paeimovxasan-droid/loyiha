<?php

namespace App\Services\Medical;

use App\Models\Medical\MedicalReferral;
use App\Models\Medical\Prescription;

class MedicalPdfService
{
    /**
     * Retsept PDF generatsiya qilish
     * Qaytaradi: HTML string (PDF ga aylantirish uchun)
     */
    public static function prescriptionHtml(Prescription $prescription): string
    {
        $prescription->load(['doctor', 'patient', 'items', 'consultation.doctorProfile']);

        $doctorName = $prescription->doctor->name ?? 'Noma\'lum';
        $patientName = $prescription->patient->name ?? 'Noma\'lum';
        $specialty = $prescription->consultation->doctorProfile->specialty ?? '';
        $workplace = $prescription->consultation->doctorProfile->workplace ?? '';
        $date = $prescription->created_at->format('d.m.Y');

        $itemsHtml = '';
        foreach ($prescription->items as $i => $item) {
            $itemsHtml .= "
            <tr>
                <td style='padding:8px; border-bottom:1px solid #e2e8f0;'>" . ($i + 1) . "</td>
                <td style='padding:8px; border-bottom:1px solid #e2e8f0; font-weight:600;'>{$item->medicine_name}</td>
                <td style='padding:8px; border-bottom:1px solid #e2e8f0;'>{$item->dosage}</td>
                <td style='padding:8px; border-bottom:1px solid #e2e8f0;'>{$item->frequency}</td>
                <td style='padding:8px; border-bottom:1px solid #e2e8f0;'>{$item->duration}</td>
                <td style='padding:8px; border-bottom:1px solid #e2e8f0;'>{$item->instructions}</td>
            </tr>";
        }

        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: DejaVu Sans, sans-serif; font-size: 12px; color: #1e293b; }
                .header { text-align: center; border-bottom: 2px solid #4f46e5; padding-bottom: 15px; margin-bottom: 20px; }
                .header h1 { color: #4f46e5; font-size: 18px; margin: 0; }
                .info { display: flex; justify-content: space-between; margin-bottom: 20px; }
                .info-block { margin-bottom: 10px; }
                .info-label { color: #64748b; font-size: 10px; text-transform: uppercase; }
                .info-value { font-weight: 600; font-size: 13px; }
                table { width: 100%; border-collapse: collapse; margin-top: 15px; }
                th { background: #f1f5f9; padding: 10px 8px; text-align: left; font-size: 11px; text-transform: uppercase; color: #475569; }
                .notes { margin-top: 20px; padding: 12px; background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0; }
                .footer { margin-top: 30px; text-align: center; color: #94a3b8; font-size: 10px; }
            </style>
        </head>
        <body>
            <div class='header'>
                <h1>📋 RETSEPT</h1>
                <p style='color:#64748b; margin:5px 0 0;'>AISOQQA Tibbiyot Xizmatlari</p>
            </div>

            <div>
                <div class='info-block'>
                    <span class='info-label'>Shifokor:</span>
                    <span class='info-value'>{$doctorName}</span>
                    <span style='color:#64748b;'> — " . ucfirst($specialty) . "</span>
                </div>
                <div class='info-block'>
                    <span class='info-label'>Ish joyi:</span>
                    <span class='info-value'>{$workplace}</span>
                </div>
                <div class='info-block'>
                    <span class='info-label'>Bemor:</span>
                    <span class='info-value'>{$patientName}</span>
                </div>
                <div class='info-block'>
                    <span class='info-label'>Sana:</span>
                    <span class='info-value'>{$date}</span>
                </div>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Dori nomi</th>
                        <th>Doza</th>
                        <th>Qabul tartibi</th>
                        <th>Muddat</th>
                        <th>Ko'rsatma</th>
                    </tr>
                </thead>
                <tbody>
                    {$itemsHtml}
                </tbody>
            </table>

            " . ($prescription->notes ? "<div class='notes'><strong>Qo'shimcha ko'rsatmalar:</strong><br>{$prescription->notes}</div>" : "") . "

            <div class='footer'>
                <p>Bu retsept AISOQQA platformasi orqali yaratilgan</p>
                <p>Retsept ID: #{$prescription->id} | Sana: {$date}</p>
            </div>
        </body>
        </html>";
    }

    /**
     * Analiz yo'llanma PDF generatsiya qilish
     */
    public static function referralHtml(MedicalReferral $referral): string
    {
        $referral->load(['doctor', 'patient', 'consultation.doctorProfile']);

        $doctorName = $referral->doctor->name ?? 'Noma\'lum';
        $patientName = $referral->patient->name ?? 'Noma\'lum';
        $specialty = $referral->consultation->doctorProfile->specialty ?? '';
        $workplace = $referral->consultation->doctorProfile->workplace ?? '';
        $date = $referral->created_at->format('d.m.Y');

        return "
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset='UTF-8'>
            <style>
                body { font-family: DejaVu Sans, sans-serif; font-size: 12px; color: #1e293b; }
                .header { text-align: center; border-bottom: 2px solid #0891b2; padding-bottom: 15px; margin-bottom: 20px; }
                .header h1 { color: #0891b2; font-size: 18px; margin: 0; }
                .info-block { margin-bottom: 10px; }
                .info-label { color: #64748b; font-size: 10px; text-transform: uppercase; }
                .info-value { font-weight: 600; font-size: 13px; }
                .analysis-box { margin-top: 20px; padding: 20px; background: #f0fdfa; border: 2px solid #99f6e4; border-radius: 12px; }
                .analysis-title { font-size: 16px; font-weight: 700; color: #0f766e; margin-bottom: 10px; }
                .footer { margin-top: 30px; text-align: center; color: #94a3b8; font-size: 10px; }
            </style>
        </head>
        <body>
            <div class='header'>
                <h1>🔬 ANALIZ YO'LLANMA</h1>
                <p style='color:#64748b; margin:5px 0 0;'>AISOQQA Tibbiyot Xizmatlari</p>
            </div>

            <div>
                <div class='info-block'>
                    <span class='info-label'>Shifokor:</span>
                    <span class='info-value'>{$doctorName}</span>
                    <span style='color:#64748b;'> — " . ucfirst($specialty) . "</span>
                </div>
                <div class='info-block'>
                    <span class='info-label'>Ish joyi:</span>
                    <span class='info-value'>{$workplace}</span>
                </div>
                <div class='info-block'>
                    <span class='info-label'>Bemor:</span>
                    <span class='info-value'>{$patientName}</span>
                </div>
                <div class='info-block'>
                    <span class='info-label'>Sana:</span>
                    <span class='info-value'>{$date}</span>
                </div>
            </div>

            <div class='analysis-box'>
                <div class='analysis-title'>📋 {$referral->analysis_type}</div>
                " . ($referral->laboratory ? "<p><strong>Laboratoriya:</strong> {$referral->laboratory}</p>" : "") . "
                " . ($referral->instructions ? "<p style='margin-top:10px;'><strong>Ko'rsatmalar:</strong><br>{$referral->instructions}</p>" : "") . "
            </div>

            <div class='footer'>
                <p>Bu yo'llanma AISOQQA platformasi orqali yaratilgan</p>
                <p>Yo'llanma ID: #{$referral->id} | Sana: {$date}</p>
            </div>
        </body>
        </html>";
    }
}
