<?php

namespace App\Services\Medical;

use App\Models\AIS\Wallet;
use App\Models\Finance\Transaction;
use App\Models\Medical\Consultation;
use App\Models\Medical\DoctorProfile;
use App\Models\Medical\DoctorReview;
use App\Models\Medical\HomeVisit;
use App\Models\Medical\MedicalComplaint;
use App\Models\Medical\MedicalSetting;
use App\Models\Medical\MedicineOrder;
use App\Models\Setting;
use App\Models\User;
use App\Services\TelegramBotService;
use App\Services\XpService;
use Illuminate\Support\Facades\DB;

class MedicalService
{
    /**
     * Maslahat boshlash — Escrow muzlatish
     */
    public static function startConsultation(User $patient, DoctorProfile $doctorProfile): Consultation
    {
        return DB::transaction(function () use ($patient, $doctorProfile) {
            $price = $doctorProfile->consultation_price;

            // Bemor hamyonini qulflash
            $wallet = Wallet::where('user_id', $patient->id)->lockForUpdate()->first();

            if (!$wallet || !$wallet->hasEnough($price)) {
                throw new \Exception('Balansingiz yetarli emas. Kamida ' . $price . ' AIS kerak.');
            }

            // Escrow — muzlatish
            $wallet->decrement('balance', $price);
            $wallet->increment('frozen_balance', $price);

            // Komissiya hisoblash
            $setting = Setting::get();
            $commissionRate = (float) ($setting->medical_commission_percent ?? 20);

            // Maslahat yaratish
            $consultation = Consultation::create([
                'patient_id'        => $patient->id,
                'doctor_id'         => $doctorProfile->user_id,
                'doctor_profile_id' => $doctorProfile->id,
                'price'             => $price,
                'escrow_amount'     => $price,
                'commission_rate'   => $commissionRate,
                'status'            => Consultation::STATUS_PENDING,
                'expires_at'        => now()->addHours(24),
            ]);

            // Tranzaksiya qayd etish
            Transaction::create([
                'user_id'              => $patient->id,
                'type'                 => 'medical_consultation',
                'transactionable_type' => Consultation::class,
                'transactionable_id'   => $consultation->id,
                'amount'               => $price,
                'balance_before'       => $wallet->balance + $price,
                'balance_after'        => $wallet->balance,
                'direction'            => 'debit',
                'status'               => 'completed',
                'description'          => 'Tibbiy maslahat uchun to\'lov (escrow)',
            ]);

            // Shifokorga bildirishnoma
            $doctor = $doctorProfile->user;
            TelegramBotService::notify(
                $doctor,
                "🏥 Yangi maslahat so'rovi keldi!\n\n"
                . "👤 Bemor: {$patient->name}\n"
                . "💰 Narx: {$price} AIS\n\n"
                . "24 soat ichida javob bering.",
                [[['text' => '📱 Platformaga kirish', 'url' => config('app.url') . '/app/doctor/consultations']]]
            );

            return $consultation;
        });
    }

    /**
     * Shifokor maslahatni qabul qiladi
     */
    public static function acceptConsultation(Consultation $consultation): Consultation
    {
        if (!$consultation->isPending()) {
            throw new \Exception('Bu maslahat allaqachon qabul qilingan yoki muddati o\'tgan.');
        }

        $consultation->update([
            'status'      => Consultation::STATUS_ACTIVE,
            'accepted_at' => now(),
        ]);

        // Bemorga bildirishnoma
        TelegramBotService::notify(
            $consultation->patient,
            "✅ Shifokor maslahat so'rovingizni qabul qildi!\n\n"
            . "👨‍⚕️ {$consultation->doctor->name}\n"
            . "Endi chat orqali muloqot qilishingiz mumkin.",
            [[['text' => '💬 Chatga o\'tish', 'url' => config('app.url') . '/app/consultations/' . $consultation->id]]]
        );

        return $consultation;
    }

    /**
     * Maslahatni tugatish — Escrow dan shifokorga to'lov
     */
    public static function completeConsultation(Consultation $consultation): Consultation
    {
        if (!$consultation->isActive()) {
            throw new \Exception('Faqat faol maslahatni tugatish mumkin.');
        }

        return DB::transaction(function () use ($consultation) {
            $consultation = Consultation::lockForUpdate()->find($consultation->id);

            $escrow = $consultation->escrow_amount;
            $commissionRate = $consultation->commission_rate;
            $commission = round($escrow * $commissionRate / 100, 4);
            $doctorEarning = $escrow - $commission;

            // Bemor hamyonidan frozen_balance kamaytirish
            $patientWallet = Wallet::where('user_id', $consultation->patient_id)->lockForUpdate()->first();
            $patientWallet->decrement('frozen_balance', $escrow);

            // Shifokor hamyoniga to'lov
            $doctorWallet = Wallet::where('user_id', $consultation->doctor_id)->lockForUpdate()->first();
            if (!$doctorWallet) {
                $doctorWallet = \App\Services\WalletService::createForUser($consultation->doctor);
                $doctorWallet = Wallet::where('user_id', $consultation->doctor_id)->lockForUpdate()->first();
            }
            $doctorWallet->increment('balance', $doctorEarning);

            // Maslahatni yangilash
            $consultation->update([
                'status'            => Consultation::STATUS_COMPLETED,
                'completed_at'      => now(),
                'commission_amount' => $commission,
                'doctor_earning'    => $doctorEarning,
            ]);

            // Shifokor profil statistikasini yangilash
            $consultation->doctorProfile->increment('consultations_count');

            // Tranzaksiya — shifokor daromadi
            Transaction::create([
                'user_id'              => $consultation->doctor_id,
                'type'                 => 'medical_earning',
                'transactionable_type' => Consultation::class,
                'transactionable_id'   => $consultation->id,
                'amount'               => $doctorEarning,
                'balance_before'       => $doctorWallet->balance - $doctorEarning,
                'balance_after'        => $doctorWallet->balance,
                'direction'            => 'credit',
                'status'               => 'completed',
                'description'          => "Maslahat daromadi ({$commissionRate}% komissiya chiqarilgan)",
            ]);

            // XP berish
            XpService::award($consultation->patient, 'medical_consultation', 30, 'Tibbiy maslahat oldi', $consultation);
            XpService::award($consultation->doctor, 'medical_consultation_given', 50, 'Tibbiy maslahat berdi', $consultation);

            // Shifokorga bildirishnoma
            TelegramBotService::notify(
                $consultation->doctor,
                "💰 Maslahat uchun {$doctorEarning} AIS hisobingizga o'tkazildi!\n"
                . "📊 Komissiya: {$commission} AIS ({$commissionRate}%)"
            );

            return $consultation;
        });
    }

    /**
     * Maslahatni bekor qilish (bemor tomonidan, shifokor hali javob bermagan)
     */
    public static function cancelConsultation(Consultation $consultation, User $cancelledBy): Consultation
    {
        if (!$consultation->canCancel()) {
            throw new \Exception('Bu maslahatni bekor qilib bo\'lmaydi.');
        }

        return DB::transaction(function () use ($consultation, $cancelledBy) {
            $consultation = Consultation::lockForUpdate()->find($consultation->id);
            $escrow = $consultation->escrow_amount;

            // Escrow dan bemorga qaytarish
            $patientWallet = Wallet::where('user_id', $consultation->patient_id)->lockForUpdate()->first();
            $patientWallet->decrement('frozen_balance', $escrow);
            $patientWallet->increment('balance', $escrow);

            $consultation->update([
                'status' => Consultation::STATUS_CANCELLED,
            ]);

            // Tranzaksiya — refund
            Transaction::create([
                'user_id'              => $consultation->patient_id,
                'type'                 => 'medical_refund',
                'transactionable_type' => Consultation::class,
                'transactionable_id'   => $consultation->id,
                'amount'               => $escrow,
                'balance_before'       => $patientWallet->balance - $escrow,
                'balance_after'        => $patientWallet->balance,
                'direction'            => 'credit',
                'status'               => 'completed',
                'description'          => 'Maslahat bekor qilindi — to\'lov qaytarildi',
            ]);

            return $consultation;
        });
    }

    /**
     * Muddati o'tgan maslahatlarni expire qilish (scheduled job)
     */
    public static function expireConsultations(): int
    {
        $expired = Consultation::where('status', Consultation::STATUS_PENDING)
            ->where('expires_at', '<', now())
            ->get();

        $count = 0;
        foreach ($expired as $consultation) {
            try {
                DB::transaction(function () use ($consultation) {
                    $consultation = Consultation::lockForUpdate()->find($consultation->id);
                    if ($consultation->status !== Consultation::STATUS_PENDING) return;

                    $escrow = $consultation->escrow_amount;

                    // Refund
                    $patientWallet = Wallet::where('user_id', $consultation->patient_id)->lockForUpdate()->first();
                    $patientWallet->decrement('frozen_balance', $escrow);
                    $patientWallet->increment('balance', $escrow);

                    $consultation->update(['status' => Consultation::STATUS_EXPIRED]);

                    Transaction::create([
                        'user_id'              => $consultation->patient_id,
                        'type'                 => 'medical_refund',
                        'transactionable_type' => Consultation::class,
                        'transactionable_id'   => $consultation->id,
                        'amount'               => $escrow,
                        'balance_before'       => $patientWallet->balance - $escrow,
                        'balance_after'        => $patientWallet->balance,
                        'direction'            => 'credit',
                        'status'               => 'completed',
                        'description'          => 'Maslahat muddati o\'tdi — to\'lov qaytarildi',
                    ]);

                    // Bemorga bildirishnoma
                    TelegramBotService::notify(
                        $consultation->patient,
                        "⏰ Shifokor 24 soat ichida javob bermadi.\n"
                        . "💰 {$escrow} AIS hisobingizga qaytarildi."
                    );
                });
                $count++;
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::error('Medical expire failed', [
                    'consultation_id' => $consultation->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return $count;
    }

    /**
     * Uyga chaqirish — Escrow muzlatish
     */
    public static function createHomeVisit(User $patient, DoctorProfile $doctorProfile, string $address, ?string $symptoms = null): HomeVisit
    {
        return DB::transaction(function () use ($patient, $doctorProfile, $address, $symptoms) {
            $price = $doctorProfile->home_visit_price;

            if ($price <= 0) {
                throw new \Exception('Bu shifokor uyga chaqirish xizmatini taqdim etmaydi.');
            }

            $wallet = Wallet::where('user_id', $patient->id)->lockForUpdate()->first();

            if (!$wallet || !$wallet->hasEnough($price)) {
                throw new \Exception('Balansingiz yetarli emas. Kamida ' . $price . ' AIS kerak.');
            }

            // Escrow
            $wallet->decrement('balance', $price);
            $wallet->increment('frozen_balance', $price);

            $setting = Setting::get();
            $commissionRate = (float) ($setting->medical_commission_percent ?? 20);

            $homeVisit = HomeVisit::create([
                'patient_id'        => $patient->id,
                'doctor_id'         => $doctorProfile->user_id,
                'doctor_profile_id' => $doctorProfile->id,
                'address'           => $address,
                'symptoms'          => $symptoms,
                'price'             => $price,
                'escrow_amount'     => $price,
                'commission_rate'   => $commissionRate,
                'status'            => HomeVisit::STATUS_PENDING,
                'expires_at'        => now()->addHours(2),
            ]);

            // Tranzaksiya
            Transaction::create([
                'user_id'              => $patient->id,
                'type'                 => 'medical_home_visit',
                'transactionable_type' => HomeVisit::class,
                'transactionable_id'   => $homeVisit->id,
                'amount'               => $price,
                'balance_before'       => $wallet->balance + $price,
                'balance_after'        => $wallet->balance,
                'direction'            => 'debit',
                'status'               => 'completed',
                'description'          => 'Uyga chaqirish uchun to\'lov (escrow)',
            ]);

            // Shifokorga bildirishnoma
            TelegramBotService::notify(
                $doctorProfile->user,
                "🏠 Uyga chaqirish so'rovi!\n\n"
                . "👤 Bemor: {$patient->name}\n"
                . "📍 Manzil: {$address}\n"
                . "💰 Narx: {$price} AIS\n\n"
                . "2 soat ichida qabul qiling.",
                [[['text' => '📱 Platformaga kirish', 'url' => config('app.url') . '/app/doctor/home-visits']]]
            );

            return $homeVisit;
        });
    }

    /**
     * Uyga chaqirishni tugatish — to'lov
     */
    public static function completeHomeVisit(HomeVisit $homeVisit): HomeVisit
    {
        return DB::transaction(function () use ($homeVisit) {
            $homeVisit = HomeVisit::lockForUpdate()->find($homeVisit->id);

            if (!in_array($homeVisit->status, [HomeVisit::STATUS_ACCEPTED, HomeVisit::STATUS_ON_THE_WAY])) {
                throw new \Exception('Faqat qabul qilingan yoki yo\'ldagi so\'rovni tugatish mumkin.');
            }

            $escrow = $homeVisit->escrow_amount;
            $commissionRate = $homeVisit->commission_rate;
            $commission = round($escrow * $commissionRate / 100, 4);
            $doctorEarning = $escrow - $commission;

            // Bemor frozen kamaytirish
            $patientWallet = Wallet::where('user_id', $homeVisit->patient_id)->lockForUpdate()->first();
            $patientWallet->decrement('frozen_balance', $escrow);

            // Shifokorga to'lov
            $doctorWallet = Wallet::where('user_id', $homeVisit->doctor_id)->lockForUpdate()->first();
            if (!$doctorWallet) {
                $doctorWallet = \App\Services\WalletService::createForUser($homeVisit->doctor);
                $doctorWallet = Wallet::where('user_id', $homeVisit->doctor_id)->lockForUpdate()->first();
            }
            $doctorWallet->increment('balance', $doctorEarning);

            $homeVisit->update([
                'status'            => HomeVisit::STATUS_COMPLETED,
                'completed_at'      => now(),
                'commission_amount' => $commission,
                'doctor_earning'    => $doctorEarning,
            ]);

            Transaction::create([
                'user_id'              => $homeVisit->doctor_id,
                'type'                 => 'medical_earning',
                'transactionable_type' => HomeVisit::class,
                'transactionable_id'   => $homeVisit->id,
                'amount'               => $doctorEarning,
                'balance_before'       => $doctorWallet->balance - $doctorEarning,
                'balance_after'        => $doctorWallet->balance,
                'direction'            => 'credit',
                'status'               => 'completed',
                'description'          => "Uyga chaqirish daromadi ({$commissionRate}% komissiya chiqarilgan)",
            ]);

            TelegramBotService::notify(
                $homeVisit->doctor,
                "💰 Uyga chaqirish uchun {$doctorEarning} AIS hisobingizga o'tkazildi!"
            );

            return $homeVisit;
        });
    }

    /**
     * Muddati o'tgan uyga chaqirishlarni expire qilish
     */
    public static function expireHomeVisits(): int
    {
        $expired = HomeVisit::where('status', HomeVisit::STATUS_PENDING)
            ->where('expires_at', '<', now())
            ->get();

        $count = 0;
        foreach ($expired as $visit) {
            try {
                DB::transaction(function () use ($visit) {
                    $visit = HomeVisit::lockForUpdate()->find($visit->id);
                    if ($visit->status !== HomeVisit::STATUS_PENDING) return;

                    $escrow = $visit->escrow_amount;
                    $patientWallet = Wallet::where('user_id', $visit->patient_id)->lockForUpdate()->first();
                    $patientWallet->decrement('frozen_balance', $escrow);
                    $patientWallet->increment('balance', $escrow);

                    $visit->update(['status' => HomeVisit::STATUS_CANCELLED]);

                    Transaction::create([
                        'user_id'              => $visit->patient_id,
                        'type'                 => 'medical_refund',
                        'transactionable_type' => HomeVisit::class,
                        'transactionable_id'   => $visit->id,
                        'amount'               => $escrow,
                        'balance_before'       => $patientWallet->balance - $escrow,
                        'balance_after'        => $patientWallet->balance,
                        'direction'            => 'credit',
                        'status'               => 'completed',
                        'description'          => 'Uyga chaqirish muddati o\'tdi — to\'lov qaytarildi',
                    ]);

                    TelegramBotService::notify(
                        $visit->patient,
                        "⏰ Shifokor 2 soat ichida so'rovni qabul qilmadi.\n"
                        . "💰 {$escrow} AIS hisobingizga qaytarildi."
                    );
                });
                $count++;
            } catch (\Throwable $e) {
                \Illuminate\Support\Facades\Log::error('HomeVisit expire failed', [
                    'home_visit_id' => $visit->id,
                    'error' => $e->getMessage(),
                ]);
            }
        }

        return $count;
    }

    /**
     * Sharh qo'shish va reyting yangilash
     */
    public static function addReview(Consultation $consultation, User $patient, int $rating, ?string $comment = null): DoctorReview
    {
        if (!$consultation->isCompleted()) {
            throw new \Exception('Faqat tugallangan maslahatga sharh qoldirish mumkin.');
        }

        if ($consultation->patient_id !== $patient->id) {
            throw new \Exception('Siz bu maslahatning bemorisi emassiz.');
        }

        if ($consultation->review) {
            throw new \Exception('Siz allaqachon sharh qoldirgansiz.');
        }

        $review = DoctorReview::create([
            'consultation_id'   => $consultation->id,
            'patient_id'        => $patient->id,
            'doctor_id'         => $consultation->doctor_id,
            'doctor_profile_id' => $consultation->doctor_profile_id,
            'rating'            => $rating,
            'comment'           => $comment,
        ]);

        // Reytingni qayta hisoblash
        $consultation->doctorProfile->recalculateRating();

        // XP berish
        XpService::award($patient, 'medical_review', 10, 'Shifokorga sharh qoldirdi', $review);

        // Sifat nazorati — reyting pastga tushsa ogohlantirish
        self::checkDoctorQuality($consultation->doctorProfile);

        return $review;
    }

    /**
     * Shikoyat yuborish
     */
    public static function submitComplaint(Consultation $consultation, User $patient, string $type, string $message): MedicalComplaint
    {
        if ($consultation->patient_id !== $patient->id) {
            throw new \Exception('Siz bu maslahatning bemorisi emassiz.');
        }

        if ($consultation->complaint) {
            throw new \Exception('Siz allaqachon shikoyat yuborgansiz.');
        }

        $complaint = MedicalComplaint::create([
            'consultation_id' => $consultation->id,
            'patient_id'      => $patient->id,
            'doctor_id'       => $consultation->doctor_id,
            'type'            => $type,
            'message'         => $message,
            'status'          => MedicalComplaint::STATUS_PENDING,
        ]);

        // Adminga bildirishnoma
        TelegramBotService::notifyAdmin(
            "⚠️ Yangi tibbiy shikoyat!\n\n"
            . "👤 Bemor: {$patient->name}\n"
            . "👨‍⚕️ Shifokor: {$consultation->doctor->name}\n"
            . "📋 Tur: {$type}\n"
            . "💬 {$message}"
        );

        return $complaint;
    }

    /**
     * Shifokor sifat nazorati
     */
    public static function checkDoctorQuality(DoctorProfile $profile): void
    {
        $profile->refresh();

        // Reyting 2.0 dan past — suspend
        if ($profile->rating > 0 && $profile->rating < 2.0 && $profile->status === DoctorProfile::STATUS_APPROVED) {
            $profile->update(['status' => DoctorProfile::STATUS_SUSPENDED]);
            TelegramBotService::notify(
                $profile->user,
                "🚫 Reytingingiz 2.0 dan pastga tushdi. Profilingiz to'xtatildi.\n"
                . "Admin bilan bog'laning."
            );
            TelegramBotService::notifyAdmin(
                "🚫 Shifokor avtomatik to'xtatildi (reyting < 2.0)\n"
                . "👨‍⚕️ {$profile->user->name} — Reyting: {$profile->rating}"
            );
        }
        // Reyting 3.0 dan past — ogohlantirish
        elseif ($profile->rating > 0 && $profile->rating < 3.0 && $profile->status === DoctorProfile::STATUS_APPROVED) {
            TelegramBotService::notify(
                $profile->user,
                "⚠️ Reytingingiz {$profile->rating} ga tushdi.\n"
                . "Sifatni oshiring, aks holda profilingiz to'xtatilishi mumkin."
            );
        }
    }
}
