<?php

namespace App\Services;

use App\Models\AIS\Wallet;
use App\Models\Lending\Loan;
use App\Models\Lending\LoanOffer;
use App\Models\Lending\LoanPayment;
use App\Models\User;
use App\Services\WalletService;
use App\Services\XpService;
use Illuminate\Support\Facades\DB;

class LendingService
{
    public static function createOffer(User $lender, array $data): LoanOffer
    {
        return DB::transaction(function () use ($lender, $data) {
            $amount = (float) $data['amount'];

            // Escrow: hamyondan yechish
            $wallet = Wallet::lockForUpdate()->where('user_id', $lender->id)->first();
            if (!$wallet || !$wallet->hasEnough($amount)) {
                throw new \Exception('Balansingizda yetarli mablag\' yo\'q');
            }

            $wallet->decrement('balance', $amount);

            $offer = LoanOffer::create([
                'lender_id'     => $lender->id,
                'amount'        => $amount,
                'interest_rate' => $data['interest_rate'],
                'duration_days' => $data['duration_days'],
                'description'   => $data['description'] ?? null,
                'status'        => 'active',
            ]);

            XpService::award($lender, 'loan_offer', 10, 'Qarz taklifi: ' . $amount . ' AIS', $offer);

            return $offer;
        });
    }

    public static function acceptOffer(User $borrower, LoanOffer $offer): Loan
    {
        return DB::transaction(function () use ($borrower, $offer) {
            $offer = LoanOffer::lockForUpdate()->find($offer->id);

            if (!$offer->isActive()) {
                throw new \Exception('Bu taklif aktiv emas');
            }

            if ($offer->lender_id === $borrower->id) {
                throw new \Exception('O\'z taklifingizni qabul qila olmaysiz');
            }

            $amount = (float) $offer->amount;
            $totalDue = round($amount * (1 + (float) $offer->interest_rate / 100), 4);

            // Escrow dan qarz oluvchiga
            $borrowerWallet = WalletService::createForUser($borrower);
            $borrowerWallet = Wallet::lockForUpdate()->find($borrowerWallet->id);
            $borrowerWallet->increment('balance', $amount);

            $offer->update(['status' => 'taken']);

            return Loan::create([
                'loan_offer_id' => $offer->id,
                'lender_id'     => $offer->lender_id,
                'borrower_id'   => $borrower->id,
                'amount'        => $amount,
                'interest_rate' => $offer->interest_rate,
                'total_due'     => $totalDue,
                'total_paid'    => 0,
                'status'        => 'active',
                'due_date'      => now()->addDays($offer->duration_days)->toDateString(),
            ]);
        });
    }

    public static function makePayment(User $borrower, Loan $loan, float $amount): LoanPayment
    {
        return DB::transaction(function () use ($borrower, $loan, $amount) {
            $loan = Loan::lockForUpdate()->find($loan->id);

            if ($loan->status !== 'active') {
                throw new \Exception('Bu qarz aktiv emas');
            }

            if ($loan->borrower_id !== $borrower->id) {
                throw new \Exception('Bu sizning qarzingiz emas');
            }

            $remaining = $loan->remaining;
            $payAmount = min($amount, $remaining);

            $borrowerWallet = Wallet::lockForUpdate()->where('user_id', $borrower->id)->first();
            if (!$borrowerWallet || !$borrowerWallet->hasEnough($payAmount)) {
                throw new \Exception('Balansingizda yetarli mablag\' yo\'q');
            }

            $borrowerWallet->decrement('balance', $payAmount);

            // Qarz beruvchiga to'lov
            $lenderWallet = Wallet::lockForUpdate()->where('user_id', $loan->lender_id)->first();
            if (!$lenderWallet) {
                // Hamyon yo'q bo'lsa — yaratib to'laymiz
                $lenderWallet = WalletService::createForUser(\App\Models\User::find($loan->lender_id));
                $lenderWallet = Wallet::lockForUpdate()->find($lenderWallet->id);
            }
            $lenderWallet->increment('balance', $payAmount);

            $loan->increment('total_paid', $payAmount);

            $payment = LoanPayment::create([
                'loan_id' => $loan->id,
                'amount'  => $payAmount,
            ]);

            // Qarz to'liq to'landimi
            $loan->refresh();
            if ((float) $loan->total_paid >= (float) $loan->total_due) {
                $loan->update(['status' => 'completed']);
            }

            XpService::award($borrower, 'loan_payment', 5, 'Qarz to\'lovi: ' . $payAmount . ' AIS', $payment);

            return $payment;
        });
    }

    public static function cancelOffer(LoanOffer $offer): LoanOffer
    {
        return DB::transaction(function () use ($offer) {
            $offer = LoanOffer::lockForUpdate()->find($offer->id);

            if (!$offer->isActive()) {
                throw new \Exception('Bu taklif aktiv emas');
            }

            // Escrow dan qaytarish
            $lenderWallet = Wallet::lockForUpdate()->where('user_id', $offer->lender_id)->first();
            if ($lenderWallet) {
                $lenderWallet->increment('balance', $offer->amount);
            }

            $offer->update(['status' => 'cancelled']);
            return $offer->fresh();
        });
    }
}
