<?php

namespace App\Services;

use App\Models\AdNetwork\Ad;
use App\Models\AdNetwork\AdCampaign;
use App\Models\AdNetwork\AdView;
use App\Models\AIS\Wallet;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class AdService
{
    public static function createCampaign(User $user, array $data): AdCampaign
    {
        return DB::transaction(function () use ($user, $data) {
            $budget = (float) $data['budget'];

            $wallet = Wallet::lockForUpdate()->where('user_id', $user->id)->first();
            if (!$wallet || !$wallet->hasEnough($budget)) {
                throw new \Exception('Balansingizda yetarli mablag\' yo\'q');
            }

            $wallet->decrement('balance', $budget);

            return AdCampaign::create([
                'user_id'       => $user->id,
                'name'          => $data['name'],
                'budget'        => $budget,
                'cost_per_view' => $data['cost_per_view'],
                'status'        => 'active',
            ]);
        });
    }

    public static function createAd(AdCampaign $campaign, array $data): Ad
    {
        return Ad::create([
            'ad_campaign_id' => $campaign->id,
            'title'          => $data['title'],
            'description'    => $data['description'],
            'image_url'      => $data['image_url'] ?? null,
            'target_url'     => $data['target_url'] ?? null,
            'status'         => 'active',
        ]);
    }

    public static function watchAd(User $user, Ad $ad): AdView
    {
        return DB::transaction(function () use ($user, $ad) {
            // Kunlik tekshirish
            $alreadyViewed = AdView::where('ad_id', $ad->id)
                ->where('user_id', $user->id)
                ->whereDate('viewed_at', today())
                ->exists();

            if ($alreadyViewed) {
                throw new \Exception('Bu reklamani bugun allaqachon ko\'rgansiz');
            }

            $campaign = AdCampaign::lockForUpdate()->find($ad->ad_campaign_id);

            if ($campaign->status !== 'active') {
                throw new \Exception('Kampaniya faol emas');
            }

            $costPerView = (float) $campaign->cost_per_view;

            if ($campaign->remaining_budget < $costPerView) {
                $campaign->update(['status' => 'completed']);
                throw new \Exception('Kampaniya byudjeti tugagan');
            }

            $campaign->increment('spent', $costPerView);

            // Foydalanuvchiga to'lov
            $wallet = WalletService::createForUser($user);
            $wallet = Wallet::lockForUpdate()->find($wallet->id);
            $wallet->increment('balance', $costPerView);

            $view = AdView::create([
                'ad_id'     => $ad->id,
                'user_id'   => $user->id,
                'earned'    => $costPerView,
                'viewed_at' => now(),
            ]);

            // Byudjet tugadimi tekshirish
            $campaign->refresh();
            if ($campaign->remaining_budget < $costPerView) {
                $campaign->update(['status' => 'completed']);
            }

            XpService::award($user, 'ad_watch', 5, 'Reklama ko\'rish', $view);

            return $view;
        });
    }

    public static function getAvailableAds(User $user)
    {
        $viewedToday = AdView::where('user_id', $user->id)
            ->whereDate('viewed_at', today())
            ->pluck('ad_id');

        return Ad::where('status', 'active')
            ->whereNotIn('id', $viewedToday)
            ->whereHas('campaign', fn($q) => $q->where('status', 'active'))
            ->with('campaign:id,name,cost_per_view')
            ->get();
    }
}
