<?php

namespace App\Services;

use App\Models\RoadmapModule;
use App\Models\RoadmapNotification;
use App\Models\RoadmapVote;
use App\Models\User;
use App\Models\Level\XpLog;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class RoadmapService
{
    /**
     * Barcha faol modullarni olish (ixtiyoriy status filter)
     */
    public static function getModules(?string $status = null, ?int $userId = null): Collection
    {
        $query = RoadmapModule::active();

        if ($status) {
            $query->where('status', $status);
        }

        $modules = $query->get();

        // User-specific flags
        $votedIds = [];
        $subscribedIds = [];

        if ($userId) {
            $votedIds = RoadmapVote::where('user_id', $userId)
                ->pluck('roadmap_module_id')
                ->flip()
                ->toArray();

            $subscribedIds = RoadmapNotification::where('user_id', $userId)
                ->pluck('roadmap_module_id')
                ->flip()
                ->toArray();
        }

        if ($modules->isEmpty() && !$status) {
            // Fallback data if DB is empty (Professional Roadmap)
            return collect([
                ['id' => 101, 'title' => 'Exchange v2 (Spot Trading)', 'description' => 'Birja tizimini yanada tezlashtirish, limit va market orderlar.', 'icon' => '📈', 'status' => 'in_progress', 'status_label' => 'Ishlanmoqda', 'status_color' => '#3B82F6', 'estimated_date' => '2026-05-15', 'progress_percent' => 65, 'votes_count' => 1250, 'user_voted' => false, 'user_subscribed' => false],
                ['id' => 102, 'title' => 'Global Card (VISA/MC)', 'description' => 'AIS hamyonini plastik kartalarga ulash.', 'icon' => '💳', 'status' => 'coming_soon', 'status_label' => 'Tez kunda', 'status_color' => '#64748b', 'estimated_date' => '2026-07-01', 'progress_percent' => 10, 'votes_count' => 840, 'user_voted' => false, 'user_subscribed' => false],
                ['id' => 103, 'title' => 'AI Analytics Bot', 'description' => 'Sun\'iy intellekt orqali moliya tahlili.', 'icon' => '🤖', 'status' => 'beta', 'status_label' => 'Beta Test', 'status_color' => '#8B5CF6', 'estimated_date' => '2026-04-30', 'progress_percent' => 90, 'votes_count' => 2100, 'user_voted' => false, 'user_subscribed' => false],
            ]);
        }

        return $modules->map(function (RoadmapModule $m) use ($votedIds, $subscribedIds) {
            return [
                'id'               => $m->id,
                'title'            => $m->title,
                'description'      => $m->description,
                'icon'             => $m->icon,
                'status'           => $m->status,
                'status_label'     => $m->status_label,
                'status_color'     => $m->status_color,
                'estimated_date'   => $m->estimated_date?->format('Y-m-d'),
                'progress_percent' => $m->progress_percent,
                'votes_count'      => $m->votes_count,
                'user_voted'       => isset($votedIds[$m->id]),
                'user_subscribed'  => isset($subscribedIds[$m->id]),
            ];
        });
    }

    /**
     * Ovoz berish/bekor qilish (toggle)
     */
    public static function toggleVote(User $user, int $moduleId): array
    {
        $module = RoadmapModule::findOrFail($moduleId);

        return DB::transaction(function () use ($user, $module) {
            $existing = RoadmapVote::where('user_id', $user->id)
                ->where('roadmap_module_id', $module->id)
                ->first();

            if ($existing) {
                $existing->delete();
                $module->decrement('votes_count');

                return [
                    'voted'       => false,
                    'votes_count' => max(0, $module->fresh()->votes_count),
                ];
            }

            // Birinchi ovoz — XP berish (XpLog orqali tekshirish)
            $xpAlreadyAwarded = XpLog::where('user_id', $user->id)
                ->where('action', 'roadmap_vote')
                ->where('description', "Roadmap ovoz: {$module->title}")
                ->exists();

            RoadmapVote::create([
                'user_id'           => $user->id,
                'roadmap_module_id' => $module->id,
                'created_at'        => now(),
            ]);
            $module->increment('votes_count');

            if (!$xpAlreadyAwarded) {
                XpService::award($user, 'roadmap_vote', 5, "Roadmap ovoz: {$module->title}");
            }

            return [
                'voted'       => true,
                'votes_count' => $module->fresh()->votes_count,
            ];
        });
    }

    /**
     * Bildirishnoma obunasi toggle
     */
    public static function toggleNotify(User $user, int $moduleId): array
    {
        $module = RoadmapModule::findOrFail($moduleId);

        $existing = RoadmapNotification::where('user_id', $user->id)
            ->where('roadmap_module_id', $module->id)
            ->first();

        if ($existing) {
            $existing->delete();
            return ['subscribed' => false];
        }

        RoadmapNotification::create([
            'user_id'           => $user->id,
            'roadmap_module_id' => $module->id,
            'created_at'        => now(),
        ]);

        return ['subscribed' => true];
    }

    /**
     * Holat o'zgarganda bildirishnoma va kanal post
     */
    public static function onStatusChange(RoadmapModule $module, string $oldStatus, string $newStatus): void
    {
        $miniappUrl = config('services.telegram.miniapp_url', '');

        // Kanal post
        if ($newStatus === 'released') {
            $text = "🚀 <b>Yangi modul: {$module->title} tayyor!</b>\n\n";
            $text .= $module->description . "\n\n";
            $text .= "📱 Mini App orqali sinab ko'ring!";

            $buttons = [];
            if ($miniappUrl) {
                $buttons = [['text' => '📱 Mini App', 'web_app' => ['url' => $miniappUrl]]];
            }

            TelegramChannelService::sendPost($text, $module->banner_image, $buttons);

            // Obunachilarga bildirishnoma
            $subscribers = RoadmapNotification::where('roadmap_module_id', $module->id)
                ->unnotified()
                ->with('user')
                ->get();

            foreach ($subscribers as $sub) {
                if ($sub->user) {
                    TelegramBotService::notify(
                        $sub->user,
                        "🚀 {$module->title} tayyor! Siz obuna bo'lgan modul chiqdi. Mini App orqali sinab ko'ring!",
                        [[['text' => '🗺️ Roadmapni ko\'rish', 'url' => config('app.url') . '/app/roadmap']]]
                    );
                }
                $sub->update(['notified_at' => now()]);
            }
        } elseif ($newStatus === 'beta') {
            $text = "🧪 <b>{$module->title} beta testga chiqdi!</b>\n\n";
            $text .= $module->description . "\n\n";
            $text .= "📱 Mini App orqali sinab ko'ring!";

            $buttons = [];
            if ($miniappUrl) {
                $buttons = [['text' => '📱 Mini App', 'web_app' => ['url' => $miniappUrl]]];
            }

            TelegramChannelService::sendPost($text, $module->banner_image, $buttons);
        }
    }

    /**
     * TOP N modullarni olish (bot uchun)
     */
    public static function getTopModules(int $limit = 5): Collection
    {
        $modules = RoadmapModule::active()
            ->orderByDesc('votes_count')
            ->limit($limit)
            ->get();

        if ($modules->isEmpty()) {
            return collect([
                (object)['title' => 'AI Analytics Bot', 'status' => 'beta', 'votes_count' => 2100],
                (object)['title' => 'Exchange v2', 'status' => 'in_progress', 'votes_count' => 1250],
            ]);
        }

        return $modules;
    }
}
