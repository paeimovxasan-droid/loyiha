<?php

namespace App\Services;

use App\Models\AIS\Wallet;
use App\Models\GigEconomy\GigApplication;
use App\Models\GigEconomy\GigListing;
use App\Models\GigEconomy\GigRating;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class GigEconomyService
{
    public static function createListing(User $user, array $data): GigListing
    {
        return GigListing::create([
            'user_id'     => $user->id,
            'title'       => $data['title'],
            'description' => $data['description'],
            'category'    => $data['category'],
            'location'    => $data['location'],
            'price'       => $data['price'],
            'work_date'   => $data['work_date'],
            'status'      => 'open',
        ]);
    }

    public static function apply(User $worker, GigListing $listing): GigApplication
    {
        if (!$listing->isOpen()) {
            throw new \Exception('Bu ish e\'loni yopilgan');
        }

        if ($listing->user_id === $worker->id) {
            throw new \Exception('O\'z e\'loningizga ariza bera olmaysiz');
        }

        $exists = GigApplication::where('gig_listing_id', $listing->id)
            ->where('user_id', $worker->id)->exists();
        if ($exists) {
            throw new \Exception('Siz allaqachon ariza bergansiz');
        }

        return GigApplication::create([
            'gig_listing_id' => $listing->id,
            'user_id'        => $worker->id,
            'status'         => 'pending',
        ]);
    }

    public static function acceptApplication(GigApplication $application): GigApplication
    {
        return DB::transaction(function () use ($application) {
            $listing = GigListing::lockForUpdate()->find($application->gig_listing_id);

            if (!$listing->isOpen()) {
                throw new \Exception('Bu ish allaqachon band');
            }

            $application->update(['status' => 'accepted']);
            $listing->update(['status' => 'in_progress']);

            // Boshqa arizalarni rad etish
            GigApplication::where('gig_listing_id', $listing->id)
                ->where('id', '!=', $application->id)
                ->update(['status' => 'rejected']);

            return $application->fresh();
        });
    }

    public static function completeListing(GigListing $listing): GigListing
    {
        return DB::transaction(function () use ($listing) {
            $listing = GigListing::lockForUpdate()->find($listing->id);

            if ($listing->status !== 'in_progress') {
                throw new \Exception('Ish hali boshlanmagan yoki allaqachon yakunlangan');
            }

            $accepted = $listing->acceptedApplication;
            if (!$accepted) {
                throw new \Exception('Qabul qilingan ishchi topilmadi');
            }

            // Ish beruvchidan ishchiga to'lov
            $employerWallet = Wallet::lockForUpdate()->where('user_id', $listing->user_id)->first();
            if (!$employerWallet || !$employerWallet->hasEnough((float) $listing->price)) {
                throw new \Exception('Balansingizda yetarli mablag\' yo\'q');
            }

            $workerWallet = Wallet::lockForUpdate()->where('user_id', $accepted->user_id)->first();

            $employerWallet->decrement('balance', $listing->price);
            if ($workerWallet) {
                $workerWallet->increment('balance', $listing->price);
            }

            $listing->update(['status' => 'completed']);

            // XP berish
            $employer = User::find($listing->user_id);
            $worker = User::find($accepted->user_id);
            if ($employer) XpService::award($employer, 'gig_complete', 10, 'Gig yakunlandi', $listing);
            if ($worker) XpService::award($worker, 'gig_complete', 10, 'Gig yakunlandi', $listing);

            return $listing->fresh();
        });
    }

    public static function rate(User $user, GigListing $listing, int $rating, ?string $comment): GigRating
    {
        if ($listing->status !== 'completed') {
            throw new \Exception('Faqat yakunlangan ishlarga baho berish mumkin');
        }

        $accepted = $listing->acceptedApplication;
        if (!$accepted) {
            throw new \Exception('Ishchi topilmadi');
        }

        // Rater kim — ish beruvchi yoki ishchi
        if ($user->id === $listing->user_id) {
            $ratedUserId = $accepted->user_id;
        } elseif ($user->id === $accepted->user_id) {
            $ratedUserId = $listing->user_id;
        } else {
            throw new \Exception('Siz bu ishga baho bera olmaysiz');
        }

        $exists = GigRating::where('gig_listing_id', $listing->id)
            ->where('rater_id', $user->id)->exists();
        if ($exists) {
            throw new \Exception('Siz allaqachon baho bergansiz');
        }

        $gigRating = GigRating::create([
            'gig_listing_id' => $listing->id,
            'rater_id'       => $user->id,
            'rated_user_id'  => $ratedUserId,
            'rating'         => $rating,
            'comment'        => $comment,
        ]);

        XpService::award($user, 'gig_rate', 5, 'Gig reyting', $gigRating);

        return $gigRating;
    }
}
