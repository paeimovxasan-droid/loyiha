<?php

namespace App\Services;

use App\Models\AgroMarket\AgroListing;
use App\Models\AgroMarket\AgroOrder;
use App\Models\AIS\Wallet;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class AgroService
{
    public static function createListing(User $user, array $data): AgroListing
    {
        $listing = AgroListing::create([
            'user_id'        => $user->id,
            'title'          => $data['title'],
            'description'    => $data['description'] ?? null,
            'category'       => $data['category'],
            'quantity'       => $data['quantity'],
            'price_per_unit' => $data['price_per_unit'],
            'location'       => $data['location'],
            'status'         => 'active',
            'is_forward'     => $data['is_forward'] ?? false,
            'delivery_date'  => $data['delivery_date'] ?? null,
        ]);

        XpService::award($user, 'agro_listing', 5, 'Agro e\'lon: ' . $listing->title, $listing);

        return $listing;
    }

    public static function placeOrder(User $buyer, AgroListing $listing, array $data): AgroOrder
    {
        return DB::transaction(function () use ($buyer, $listing, $data) {
            $listing = AgroListing::lockForUpdate()->find($listing->id);

            if (!$listing->isActive()) {
                throw new \Exception('E\'lon aktiv emas');
            }

            $quantity = $data['quantity'];
            $totalPrice = round($quantity * (float) $listing->price_per_unit, 4);

            $wallet = Wallet::lockForUpdate()->where('user_id', $buyer->id)->first();
            if (!$wallet || !$wallet->hasEnough($totalPrice)) {
                throw new \Exception('Balansingizda yetarli mablag\' yo\'q');
            }

            $wallet->decrement('balance', $totalPrice);

            $order = AgroOrder::create([
                'buyer_id'        => $buyer->id,
                'seller_id'       => $listing->user_id,
                'agro_listing_id' => $listing->id,
                'quantity'        => $quantity,
                'total_price'     => $totalPrice,
                'status'          => 'pending',
                'is_forward'      => $data['is_forward'] ?? $listing->is_forward,
                'delivery_date'   => $data['delivery_date'] ?? $listing->delivery_date,
            ]);

            return $order;
        });
    }

    public static function confirmOrder(AgroOrder $order): AgroOrder
    {
        return DB::transaction(function () use ($order) {
            $order = AgroOrder::lockForUpdate()->find($order->id);

            if ($order->status !== 'pending') {
                throw new \Exception('Buyurtma tasdiqlanishi mumkin emas');
            }

            $sellerWallet = Wallet::lockForUpdate()->where('user_id', $order->seller_id)->first();
            if ($sellerWallet) {
                $sellerWallet->increment('balance', $order->total_price);
            }

            $order->update(['status' => 'completed']);

            $buyer = User::find($order->buyer_id);
            $seller = User::find($order->seller_id);
            if ($buyer) XpService::award($buyer, 'agro_order', 10, 'Agro buyurtma yakunlandi', $order);
            if ($seller) XpService::award($seller, 'agro_sale', 10, 'Agro sotish yakunlandi', $order);

            return $order->fresh();
        });
    }

    public static function cancelOrder(AgroOrder $order): AgroOrder
    {
        return DB::transaction(function () use ($order) {
            $order = AgroOrder::lockForUpdate()->find($order->id);

            if ($order->status !== 'pending') {
                throw new \Exception('Buyurtma bekor qilinishi mumkin emas');
            }

            $buyerWallet = Wallet::lockForUpdate()->where('user_id', $order->buyer_id)->first();
            if ($buyerWallet) {
                $buyerWallet->increment('balance', $order->total_price);
            }

            $order->update(['status' => 'cancelled']);
            return $order->fresh();
        });
    }
}
