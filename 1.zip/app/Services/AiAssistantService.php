<?php

namespace App\Services;

use App\Models\AiAssistant\AiConversation;
use App\Models\AiAssistant\AiMessage;
use App\Models\AiAssistant\FaqEntry;
use App\Models\User;

class AiAssistantService
{
    public static function askQuestion(User $user, string $question): AiMessage
    {
        // Suhbat olish yoki yaratish
        $conversation = AiConversation::where('user_id', $user->id)
            ->latest()->first();

        if (!$conversation) {
            $conversation = AiConversation::create([
                'user_id' => $user->id,
                'title'   => mb_substr($question, 0, 50),
            ]);
        }

        // Foydalanuvchi xabarini saqlash
        AiMessage::create([
            'ai_conversation_id' => $conversation->id,
            'role'               => 'user',
            'content'            => $question,
        ]);

        // FAQ dan javob topish
        $faq = static::findFaqAnswer($question);
        $answer = $faq
            ? $faq->answer
            : 'Kechirasiz, savolingizga javob topilmadi. Iltimos, boshqacha so\'rang.';

        $message = AiMessage::create([
            'ai_conversation_id' => $conversation->id,
            'role'               => 'assistant',
            'content'            => $answer,
            'faq_entry_id'       => $faq?->id,
        ]);

        XpService::award($user, 'ai_ask', 5, 'AI savol', $message);

        return $message;
    }

    public static function findFaqAnswer(string $question): ?FaqEntry
    {
        $question = mb_strtolower($question);

        // Kalit so'zlar bo'yicha qidirish
        $faqs = FaqEntry::active()->get();

        $bestMatch = null;
        $bestScore = 0;

        foreach ($faqs as $faq) {
            $score = 0;
            $keywords = array_filter(explode(',', $faq->keywords ?? ''));

            foreach ($keywords as $keyword) {
                if (str_contains($question, mb_strtolower(trim($keyword)))) {
                    $score += 2;
                }
            }

            // Savol matnida qidirish
            if (str_contains($question, mb_strtolower($faq->question))) {
                $score += 5;
            }

            if ($score > $bestScore) {
                $bestScore = $score;
                $bestMatch = $faq;
            }
        }

        return $bestScore > 0 ? $bestMatch : null;
    }

    public static function getConversations(User $user)
    {
        return AiConversation::where('user_id', $user->id)
            ->withCount('messages')
            ->latest()
            ->get();
    }

    public static function getFinancialAdvice(User $user): array
    {
        $wallet = $user->wallet;
        $balance = $wallet ? (float) $wallet->balance : 0;

        $tips = [];
        if ($balance < 10) {
            $tips[] = 'Balansingiz past. Kunlik UBI va reklama ko\'rish orqali AIS ishlang.';
        }
        if ($balance > 1000) {
            $tips[] = 'Balansingiz yaxshi. Tokenizatsiya yoki P2P lending orqali investitsiya qiling.';
        }
        $tips[] = 'Har kuni check-in qiling va XP yig\'ing.';

        return ['balance' => $balance, 'tips' => $tips];
    }
}
