<?php

namespace App\Services;

use App\Models\AIS\Wallet;
use App\Models\Tokenization\Asset;
use App\Models\Tokenization\AssetToken;
use App\Models\Tokenization\TokenPurchase;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class TokenizationService
{
    public static function createAsset(array $data): Asset
    {
        $totalTokens = (int) $data['total_tokens'];
        $totalValue = (float) $data['total_value'];
        $tokenPrice = round($totalValue / $totalTokens, 4);

        return Asset::create([
            'name'             => $data['name'],
            'description'      => $data['description'],
            'total_value'      => $totalValue,
            'total_tokens'     => $totalTokens,
            'available_tokens' => $totalTokens,
            'token_price'      => $tokenPrice,
            'status'           => 'active',
        ]);
    }

    public static function purchaseTokens(User $user, Asset $asset, int $quantity): TokenPurchase
    {
        return DB::transaction(function () use ($user, $asset, $quantity) {
            $asset = Asset::lockForUpdate()->find($asset->id);

            if ($asset->status !== 'active') {
                throw new \Exception('Bu aktiv sotuvda emas');
            }

            if ($asset->available_tokens < $quantity) {
                throw new \Exception('Yetarli token mavjud emas. Qolgan: ' . $asset->available_tokens);
            }

            $totalPrice = round($quantity * (float) $asset->token_price, 4);

            $wallet = Wallet::lockForUpdate()->where('user_id', $user->id)->first();
            if (!$wallet || !$wallet->hasEnough($totalPrice)) {
                throw new \Exception('Balansingizda yetarli mablag\' yo\'q');
            }

            $wallet->decrement('balance', $totalPrice);
            $asset->decrement('available_tokens', $quantity);

            // Token egasini yangilash
            $assetToken = AssetToken::where('asset_id', $asset->id)
                ->where('user_id', $user->id)->first();

            if ($assetToken) {
                $assetToken->increment('quantity', $quantity);
            } else {
                AssetToken::create([
                    'asset_id' => $asset->id,
                    'user_id'  => $user->id,
                    'quantity'  => $quantity,
                ]);
            }

            $purchase = TokenPurchase::create([
                'user_id'     => $user->id,
                'asset_id'    => $asset->id,
                'quantity'    => $quantity,
                'total_price' => $totalPrice,
            ]);

            // Sold out tekshirish
            $asset->refresh();
            if ($asset->available_tokens <= 0) {
                $asset->update(['status' => 'sold_out']);
            }

            XpService::award($user, 'token_purchase', 10, 'Token sotib olish: ' . $quantity . ' dona', $purchase);

            return $purchase;
        });
    }

    public static function getUserPortfolio(User $user)
    {
        return AssetToken::where('user_id', $user->id)
            ->with('asset:id,name,token_price,status')
            ->get()
            ->map(fn($t) => [
                'asset_id'    => $t->asset_id,
                'asset_name'  => $t->asset?->name,
                'quantity'    => $t->quantity,
                'token_price' => (float) $t->asset?->token_price,
                'total_value' => round($t->quantity * (float) $t->asset?->token_price, 4),
            ]);
    }
}
