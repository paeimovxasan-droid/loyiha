<?php

namespace App\Services\Security;

class TwoFactorService
{
    /**
     * Yangi maxfiy kalit (Secret Key) generatsiya qilish
     */
    public static function generateSecret(int $length = 16): string
    {
        $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $secret = '';
        for ($i = 0; $i < $length; $i++) {
            $secret .= $characters[random_int(0, 31)];
        }
        return $secret;
    }

    /**
     * Kodni tekshirish (Verify OTP)
     */
    public static function verify(string $secret, string $code, int $window = 1): bool
    {
        $currentTime = floor(time() / 30);
        
        for ($i = -$window; $i <= $window; $i++) {
            if (static::calculateCode($secret, $currentTime + $i) === $code) {
                return true;
            }
        }

        return false;
    }

    /**
     * QR Code uchun URL generatsiya qilish
     */
    public static function getQrCodeUrl(string $userEmail, string $secret): string
    {
        $issuer = rawurlencode(config('app.name', 'AISOQQA'));
        $user = rawurlencode($userEmail);
        return "otpauth://totp/{$issuer}:{$user}?secret={$secret}&issuer={$issuer}";
    }

    /**
     * TOTP kodini hisoblash (Internal)
     */
    private static function calculateCode(string $secret, int $timeSlice): string
    {
        $secretKey = static::base32Decode($secret);
        
        // Time slice to binary
        $time = pack('N*', 0) . pack('N*', $timeSlice);
        
        // HMAC-SHA1 hash
        $hash = hash_hmac('sha1', $time, $secretKey, true);
        
        // Dynamic truncation
        $offset = ord(substr($hash, -1)) & 0x0F;
        $hashPart = substr($hash, $offset, 4);
        
        // Binary to integer
        $value = unpack('N', $hashPart)[1];
        $value = $value & 0x7FFFFFFF;
        
        $code = $value % 1000000;
        return str_pad((string)$code, 6, '0', STR_PAD_LEFT);
    }

    /**
     * Base32 decoding logic
     */
    private static function base32Decode(string $base32): string
    {
        $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $base32 = strtoupper($base32);
        $buffer = 0;
        $bufferLength = 0;
        $result = '';

        for ($i = 0; $i < strlen($base32); $i++) {
            $char = $base32[$i];
            $position = strpos($alphabet, $char);
            
            if ($position === false) continue;

            $buffer = ($buffer << 5) | $position;
            $bufferLength += 5;

            if ($bufferLength >= 8) {
                $bufferLength -= 8;
                $result .= chr(($buffer >> $bufferLength) & 0xFF);
            }
        }

        return $result;
    }
}
