<?php

namespace App\Services\Security;

use App\Models\Security\AuditLog;
use App\Models\Security\IpCheck;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class VpnDetectionService
{
    /**
     * IP manzilni tekshirish (cache-first, fail-open)
     */
    public static function check(string $ip): object
    {
        // 1. Whitelist tekshiruvi
        if (static::isWhitelisted($ip)) {
            return (object) [
                'is_vpn'   => false,
                'is_proxy' => false,
                'country'  => null,
                'source'   => 'manual',
            ];
        }

        // 2. Keshdan qidirish (muddati o'tmagan yozuv)
        $cached = IpCheck::where('ip_address', $ip)
            ->where('expires_at', '>', now())
            ->first();

        if ($cached) {
            return (object) [
                'is_vpn'   => $cached->is_vpn,
                'is_proxy' => $cached->is_proxy,
                'country'  => $cached->country,
                'source'   => $cached->source,
            ];
        }

        // 3. Tashqi API chaqiruvi
        try {
            $apiKey = env('IPQS_API_KEY');
            $response = Http::timeout(5)
                ->get("https://ipqualityscore.com/api/json/ip/{$apiKey}/{$ip}");

            $data = $response->json();

            $isVpn   = (bool) ($data['vpn']   ?? false);
            $isProxy = (bool) ($data['proxy']  ?? false);
            $country = $data['country_code']   ?? null;

            IpCheck::updateOrCreate(
                ['ip_address' => $ip],
                [
                    'is_vpn'       => $isVpn,
                    'is_proxy'     => $isProxy,
                    'country'      => $country,
                    'source'       => 'ipqualityscore',
                    'raw_response' => $data,
                    'checked_at'   => now(),
                    'expires_at'   => now()->addHours(24),
                ]
            );

            return (object) [
                'is_vpn'   => $isVpn,
                'is_proxy' => $isProxy,
                'country'  => $country,
                'source'   => 'ipqualityscore',
            ];
        } catch (\Exception $e) {
            // 4. Fail-open: xato bo'lsa bloklamaymiz
            IpCheck::updateOrCreate(
                ['ip_address' => $ip],
                [
                    'is_vpn'     => false,
                    'is_proxy'   => false,
                    'country'    => null,
                    'source'     => 'failed',
                    'checked_at' => now(),
                    'expires_at' => now()->addHours(24),
                ]
            );

            try {
                AuditLog::create([
                    'action'     => 'vpn_check_failed',
                    'user_id'    => null,
                    'ip_address' => $ip,
                    'payload'    => ['error' => $e->getMessage()],
                ]);
            } catch (\Exception) {
                Log::warning('vpn_check_failed: ' . $e->getMessage(), ['ip' => $ip]);
            }

            return (object) [
                'is_vpn'   => false,
                'is_proxy' => false,
                'country'  => null,
                'source'   => 'failed',
            ];
        }
    }

    /**
     * IP manzil whitelist da borligini tekshirish
     */
    public static function isWhitelisted(string $ip): bool
    {
        $whitelist = config('anti-fraud.vpn_whitelist', []);

        return in_array($ip, array_filter($whitelist));
    }
}
