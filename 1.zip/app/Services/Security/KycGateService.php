<?php

namespace App\Services\Security;

use App\Models\Finance\Commission;
use App\Models\Security\AuditLog;
use App\Models\Security\UserDevice;
use App\Models\User;
use Illuminate\Support\Facades\Log;

class KycGateService
{
    /**
     * Referral komissiyasini qayta ishlash.
     * KYC holati va IP tekshiruvlari asosida komissiyani to'laydi yoki pending_kyc sifatida saqlaydi.
     *
     * Requirements: 4.1, 4.2, 4.3, 4.4
     */
    public static function processReferralCommission(User $referrer, User $referred, float $amount): void
    {
        // 1. Idempotence check: bu referred user uchun komissiya allaqachon mavjudmi?
        $exists = Commission::where('user_id', $referrer->id)
            ->where('from_user_id', $referred->id)
            ->whereIn('reason', ['referral', 'deposit'])
            ->exists();

        if ($exists) {
            return;
        }

        // 2. Same-IP check: referrer va referred bir xil IP dan ro'yxatdan o'tganmi?
        $referrerIps = UserDevice::where('user_id', $referrer->id)
            ->where('event_type', 'register')
            ->pluck('ip_address')
            ->toArray();

        $referredIps = UserDevice::where('user_id', $referred->id)
            ->where('event_type', 'register')
            ->pluck('ip_address')
            ->toArray();

        $sharedIps = array_intersect($referrerIps, $referredIps);

        if (!empty($sharedIps)) {
            try {
                AuditLog::critical('referral_same_ip_blocked', $referrer, [
                    'referrer_id'  => $referrer->id,
                    'referred_id'  => $referred->id,
                    'shared_ips'   => array_values($sharedIps),
                    'amount'       => $amount,
                ]);
            } catch (\Throwable $e) {
                Log::warning('KycGateService: AuditLog yozishda xato (same_ip_blocked)', [
                    'error'       => $e->getMessage(),
                    'referrer_id' => $referrer->id,
                    'referred_id' => $referred->id,
                ]);
            }

            return; // Komissiyani bloklash
        }

        // 3. KYC tekshiruvi: ikkala tomon ham verified emasmi?
        $referrerVerified = $referrer->kyc_status === 'verified';
        $referredVerified = $referred->kyc_status === 'verified';

        if (!$referrerVerified || !$referredVerified) {
            Commission::create([
                'user_id'      => $referrer->id,
                'from_user_id' => $referred->id,
                'reason'       => 'referral',
                'amount'       => $amount,
                'status'       => 'pending_kyc',
                'date'         => now()->toDateString(),
            ]);

            return;
        }

        // 4. Ikkala tomon ham verified — komissiyani to'lash
        $referrer->increment('balance', $amount);

        Commission::create([
            'user_id'      => $referrer->id,
            'from_user_id' => $referred->id,
            'reason'       => 'referral',
            'amount'       => $amount,
            'status'       => 'active',
            'date'         => now()->toDateString(),
        ]);

        try {
            AuditLog::log('referral_commission_paid', $referrer, [
                'referrer_id' => $referrer->id,
                'referred_id' => $referred->id,
                'amount'      => $amount,
            ]);
        } catch (\Throwable $e) {
            Log::warning('KycGateService: AuditLog yozishda xato (commission_paid)', [
                'error'       => $e->getMessage(),
                'referrer_id' => $referrer->id,
            ]);
        }
    }

    /**
     * Foydalanuvchining pending_kyc komissiyalarini chiqarish.
     * KYC tasdiqlanganda chaqiriladi.
     *
     * Requirements: 4.1, 4.2
     */
    public static function releasePendingCommissions(User $user): void
    {
        $pendingCommissions = Commission::where('user_id', $user->id)
            ->where('status', 'pending_kyc')
            ->get();

        foreach ($pendingCommissions as $commission) {
            \Illuminate\Support\Facades\DB::transaction(function () use ($user, $commission) {
                // Lock bilan qayta tekshirish — double-pay oldini olish
                $commission = Commission::lockForUpdate()->find($commission->id);

                if (!$commission || $commission->status !== 'pending_kyc') {
                    return; // Allaqachon qayta ishlangan
                }

                $commission->update(['status' => 'active']);

                $lockedUser = \App\Models\User::lockForUpdate()->find($user->id);
                $lockedUser->increment('balance', $commission->amount);

                try {
                    AuditLog::log('referral_commission_released', $user, [
                        'commission_id' => $commission->id,
                        'amount'        => $commission->amount,
                        'from_user_id'  => $commission->from_user_id,
                    ]);
                } catch (\Throwable $e) {
                    Log::warning('KycGateService: AuditLog yozishda xato (commission_released)', [
                        'error'         => $e->getMessage(),
                        'commission_id' => $commission->id,
                        'user_id'       => $user->id,
                    ]);
                }
            });
        }
    }
}
