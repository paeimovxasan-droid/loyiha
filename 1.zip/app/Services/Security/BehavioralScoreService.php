<?php

namespace App\Services\Security;

use App\Models\Security\BehavioralScoreLog;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class BehavioralScoreService
{
    public static function adjust(User $user, int $delta, string $reason): void
    {
        \Illuminate\Support\Facades\DB::transaction(function () use ($user, $delta, $reason) {
            // Lock bilan — parallel request'da score noto'g'ri hisoblashini oldini olish
            $user = User::lockForUpdate()->find($user->id);

            $oldScore = $user->behavioral_score;
            $newScore = max(0, min(100, $oldScore + $delta));

            $threshold = config('anti-fraud.fraud_thresholds.high_risk_score_threshold', 20);

            $user->update([
                'behavioral_score' => $newScore,
                'is_high_risk'     => $newScore < $threshold,
            ]);

            BehavioralScoreLog::create([
                'user_id'     => $user->id,
                'delta'       => $delta,
                'reason'      => $reason,
                'score_after' => $newScore,
            ]);

            try {
                \App\Models\Security\AuditLog::create([
                    'action'      => 'behavioral_score_changed',
                    'user_id'     => $user->id,
                    'target_id'   => $user->id,
                    'target_type' => User::class,
                    'payload'     => [
                        'description' => "Score: {$oldScore} → {$newScore} ({$reason})",
                        'delta'       => $delta,
                        'reason'      => $reason,
                    ],
                    'ip_address'  => request()->ip(),
                    'user_agent'  => request()->userAgent(),
                ]);
            } catch (\Throwable $e) {
                Log::warning('BehavioralScoreService: AuditLog yozishda xato', [
                    'user_id' => $user->id,
                    'error'   => $e->getMessage(),
                ]);
            }
        });
    }

    public static function getScore(User $user): int
    {
        return $user->behavioral_score;
    }

    public static function checkBotCheckin(User $user): bool
    {
        $days      = config('anti-fraud.fraud_thresholds.bot_checkin_days', 7);
        $tolerance = config('anti-fraud.fraud_thresholds.bot_checkin_tolerance_minutes', 5);

        $checkIns = DB::table('check_ins')
            ->where('user_id', $user->id)
            ->where('created_at', '>=', now()->subDays($days))
            ->orderBy('created_at')
            ->pluck('created_at');

        if ($checkIns->count() < 7) {
            return false;
        }

        $first        = \Carbon\Carbon::parse($checkIns->first());
        $firstMinutes = $first->hour * 60 + $first->minute;

        foreach ($checkIns->skip(1) as $raw) {
            $time    = \Carbon\Carbon::parse($raw);
            $minutes = $time->hour * 60 + $time->minute;
            $diff    = abs($minutes - $firstMinutes);
            $diff    = min($diff, 1440 - $diff);

            if ($diff > $tolerance) {
                return false;
            }
        }

        return true;
    }
}
