<?php

namespace App\Services\Security;

use App\Models\Security\FaceKycAttempt;
use App\Models\User;
use App\Services\QuestService;
use App\Services\TelegramBotService;
use App\Services\XpService;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use App\Models\Game\Quest;
use App\Models\Level\XpLog;

class FaceKycService
{
    /**
     * Liveness challenge generatsiya
     *
     * Foydalanuvchi kamera oldida bajarishi kerak bo'lgan harakatlar ketma-ketligi.
     * Frontend (face-api.js) bu harakatlarni real-time tekshiradi.
     *
     * @return array{session_id: string, steps: array}
     */
    public static function generateChallenge(): array
    {
        // Mumkin bo'lgan harakatlar
        $allActions = ['turn_left', 'turn_right', 'blink', 'smile', 'nod'];

        // 2-3 ta tasodifiy harakat tanlash
        $count = random_int(2, 3);
        $shuffled = $allActions;
        shuffle($shuffled);
        $steps = array_slice($shuffled, 0, $count);

        return [
            'session_id' => Str::uuid()->toString(),
            'steps'      => $steps,
        ];
    }

    /**
     * KYC submission'ni qayta ishlash:
     *  1. Rasmlarni saqlash
     *  2. Attempt'ni yangilash
     *  3. Auto-approve yoki admin review'ga yuborish
     *
     * @return array{auto_approved: bool}
     */
    public static function processSubmission(
        User $user,
        FaceKycAttempt $attempt,
        UploadedFile $selfie,
        UploadedFile $documentFront,
        ?UploadedFile $documentBack,
        string $documentType,
        float $livenessScore
    ): array {
        // Rasmlarni saqlash
        $selfiePath        = static::saveKycImage($selfie, 'kyc/selfies', $user->id);
        $docFrontPath      = static::saveKycImage($documentFront, 'kyc/documents', $user->id);
        $docBackPath       = $documentBack
            ? static::saveKycImage($documentBack, 'kyc/documents', $user->id)
            : null;

        // Attempt'ni yangilash
        $attempt->update([
            'status'          => 'submitted',
            'selfie_path'     => $selfiePath,
            'doc_front_path'  => $docFrontPath,
            'doc_back_path'   => $docBackPath,
            'document_type'   => $documentType,
            'liveness_score'  => $livenessScore,
            'submitted_at'    => now(),
        ]);

        // User'ni face_pending holatga o'tkazish
        $user->update([
            'kyc_type'   => 'face_id',
            'kyc_stage'  => 'face_id',
            'kyc_status' => 'face_pending',
            'kyc_document' => $docFrontPath,
            'kyc_rejection_reason' => null,
        ]);

        // Liveness score juda yuqori bo'lsa (0.95+) — auto approve
        // Odatda bu faqat test muhitida yoki juda ishonchli natijalar uchun
        $autoApprove = $livenessScore >= 0.95
            && config('kyc.auto_approve_threshold', false);

        if ($autoApprove) {
            static::approveUser($user, $attempt);
            return ['auto_approved' => true];
        }

        // Admin review'ga yuborish — Telegram bildirishnoma
        try {
            TelegramBotService::notify(
                $user,
                "📋 <b>KYC so'rovingiz qabul qilindi!</b>\n\n"
                . "🪪 Hujjat turi: " . ($documentType === 'passport' ? 'Pasport' : 'ID karta') . "\n"
                . "🤳 Liveness: " . round($livenessScore * 100) . "%\n"
                . "⏳ 24 soat ichida natija bildiriladi.",
                [[['text' => '📋 KYC holatini ko\'rish', 'url' => config('app.url') . '/app/kyc']]]
            );
        } catch (\Throwable $e) {
            Log::warning('FaceKYC notify failed', ['user_id' => $user->id]);
        }

        return ['auto_approved' => false];
    }

    /**
     * Admin tomonidan Pasport tasdiqlash (1-bosqich)
     */
    public static function approvePassport(User $user): void
    {
        $user->update([
            'kyc_status' => 'passport_verified',
            'kyc_stage'  => 'face_id',
            'kyc_rejection_reason' => null,
        ]);

        try {
            TelegramBotService::notify(
                $user,
                "✅ <b>Pasportingiz tasdiqlandi!</b>\n\n"
                . "🪪 Endi Face ID bosqichini o'ting.\n"
                . "📱 KYC sahifasiga o'tib, yuz identifikatsiyasini boshlang.",
                [[['text' => '🤳 Face ID boshlash', 'url' => config('app.url') . '/app/kyc']]]
            );
        } catch (\Throwable $e) {
            Log::warning('FaceKYC approvePassport notify failed', ['user_id' => $user->id]);
        }
    }

    /**
     * Admin tomonidan Pasport rad etish (1-bosqich)
     */
    public static function rejectPassport(User $user, string $reason): void
    {
        $user->update([
            'kyc_status'           => 'rejected',
            'kyc_rejection_reason' => $reason,
            'kyc_document'         => null,
        ]);

        try {
            TelegramBotService::notify(
                $user,
                "❌ <b>Pasportingiz rad etildi.</b>\n\n"
                . "📝 Sabab: {$reason}\n\n"
                . "Iltimos, to'g'ri hujjat bilan qaytadan urinib ko'ring.",
                [[['text' => '🔄 Qayta yuborish', 'url' => config('app.url') . '/app/kyc']]]
            );
        } catch (\Throwable $e) {
            Log::warning('FaceKYC rejectPassport notify failed', ['user_id' => $user->id]);
        }
    }

    /**
     * Admin tomonidan KYC tasdiqlash (Face ID — 2-bosqich)
     */
    public static function approveUser(User $user, ?FaceKycAttempt $attempt = null): void
    {
        $user->update([
            'kyc_status'      => 'verified',
            'kyc_type'        => 'face_id',
            'kyc_stage'       => 'face_id',
            'kyc_verified_at' => now(),
            'kyc_rejection_reason' => null,
        ]);

        if ($attempt) {
            $attempt->update(['status' => 'approved']);
        }

        // XP berish
        try {
            XpService::award($user, XpLog::ACTION_KYC, 50, 'Face ID KYC tasdiqlandi');
            QuestService::updateProgress($user, Quest::REQ_KYC_VERIFY);
            BehavioralScoreService::adjust($user, 30, 'kyc_approved');
            KycGateService::releasePendingCommissions($user);

            TelegramBotService::notify(
                $user,
                "✅ <b>KYC tasdiqlandi!</b>\n\n"
                . "🤳 Yuz orqali identifikatsiya muvaffaqiyatli o'tdi.\n"
                . "🎁 +50 XP berildi.\n"
                . "💰 Endi depozit va yechib olish imkoniyatiga egasiz!",
                [[['text' => '💰 Depozit qilish', 'url' => config('app.url') . '/app/deposit']]]
            );
        } catch (\Throwable $e) {
            Log::warning('FaceKYC post-approve actions failed', [
                'user_id' => $user->id,
                'error'   => $e->getMessage(),
            ]);
        }
    }

    /**
     * Admin tomonidan KYC rad etish
     */
    public static function rejectUser(User $user, string $reason, ?FaceKycAttempt $attempt = null): void
    {
        $user->update([
            'kyc_status'           => 'rejected',
            'kyc_rejection_reason' => $reason,
            'kyc_document'         => null,
        ]);

        if ($attempt) {
            $attempt->update([
                'status'      => 'rejected',
                'fail_reason' => $reason,
            ]);
        }

        try {
            TelegramBotService::notify(
                $user,
                "❌ <b>KYC rad etildi.</b>\n\n"
                . "📝 Sabab: {$reason}\n\n"
                . "Iltimos, qaytadan urinib ko'ring.",
                [[['text' => '🔄 Qayta urinish', 'url' => config('app.url') . '/app/kyc']]]
            );
        } catch (\Throwable $e) {
            Log::warning('FaceKYC reject notify failed', ['user_id' => $user->id]);
        }
    }

    /**
     * KYC rasmini xavfsiz saqlash (public static — controller'lardan chaqirish uchun)
     */
    public static function saveKycImagePublic(UploadedFile $file, string $folder, int $userId): string
    {
        return static::saveKycImage($file, $folder, $userId);
    }

    /**
     * KYC rasmini xavfsiz saqlash
     * - UUID fayl nomi (original nom saqlanmaydi)
     * - private disk (public URL yo'q)
     */
    private static function saveKycImage(UploadedFile $file, string $folder, int $userId): string
    {
        $extension = 'webp';
        $filename  = $userId . '_' . Str::uuid() . '.' . $extension;

        // WebP ga convert qilish (GD bilan)
        if (function_exists('imagecreatefromstring')) {
            $imageData = file_get_contents($file->getRealPath());
            $image = @imagecreatefromstring($imageData);

            if ($image !== false) {
                imagepalettetotruecolor($image);
                imagealphablending($image, false);
                imagesavealpha($image, true);

                ob_start();
                imagewebp($image, null, 85);
                $webpContent = ob_get_clean();
                imagedestroy($image);

                $path = $folder . '/' . $filename;
                // KYC rasmlari private disk'da saqlanadi (public emas!)
                Storage::disk('local')->put($path, $webpContent);
                return $path;
            }
        }

        // Fallback: original format
        $ext      = $file->getClientOriginalExtension() ?: 'jpg';
        $filename = $userId . '_' . Str::uuid() . '.' . $ext;
        $path     = $folder . '/' . $filename;
        Storage::disk('local')->put($path, file_get_contents($file->getRealPath()));
        return $path;
    }

    /**
     * Admin uchun KYC rasmini vaqtincha URL olish (signed URL)
     * 30 daqiqa amal qiladi
     */
    public static function getTemporaryImageUrl(string $path): string
    {
        // Local disk uchun base64 encode qilib qaytarish
        if (Storage::disk('local')->exists($path)) {
            $content  = Storage::disk('local')->get($path);
            $mimeType = 'image/webp';
            return 'data:' . $mimeType . ';base64,' . base64_encode($content);
        }
        return '';
    }
}
