<?php

namespace App\Services\Security;

use App\Models\AIS\AisTransfer;
use App\Models\Payment\Deposit;
use App\Models\Payment\Withdrawal;
use App\Models\Security\AuditLog;
use App\Models\Security\FraudFlag;
use App\Models\Security\UserDevice;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class FraudDetectionService
{
    /**
     * Ro'yxatdan o'tishda chaqiriladi
     */
    public static function onRegister(User $user, Request $request): void
    {
        // 1. Device yozuvini saqlash
        UserDevice::create([
            'user_id'          => $user->id,
            'ip_address'       => $request->ip(),
            'fingerprint_hash' => $request->input('fingerprint_hash'),
            'user_agent'       => $request->userAgent(),
            'event_type'       => 'register',
        ]);

        // 2. VPN/Proxy tekshiruvi
        $vpn = VpnDetectionService::check($request->ip());

        if ($vpn->is_vpn || $vpn->is_proxy) {
            static::flagUser($user, "VPN/Proxy orqali ro'yxatdan o'tish");
        }

        // 3. Bir IP dan ko'p akkaunt tekshiruvi
        $count = UserDevice::where('ip_address', $request->ip())
            ->where('event_type', 'register')
            ->distinct('user_id')
            ->count('user_id');

        $maxAccounts = config('anti-fraud.fraud_thresholds.max_accounts_per_ip', 3);

        if ($count >= $maxAccounts) {
            $userIds = UserDevice::where('ip_address', $request->ip())
                ->where('event_type', 'register')
                ->distinct()
                ->pluck('user_id');

            foreach ($userIds as $uid) {
                $flaggedUser = User::find($uid);
                if ($flaggedUser) {
                    static::flagUser($flaggedUser, "Bir IP dan ko'p akkaunt: " . $request->ip());
                }
            }
        }
    }

    /**
     * Depozitda chaqiriladi
     */
    public static function onDeposit(User $user, $deposit, Request $request): void
    {
        // 1. VPN/Proxy tekshiruvi
        $vpn = VpnDetectionService::check($request->ip());

        if ($vpn->is_vpn || $vpn->is_proxy) {
            $deposit->update(['is_suspicious' => true]);
        }

        // 2. Yangi foydalanuvchi katta depozit tekshiruvi
        $newUserHours = config('anti-fraud.fraud_thresholds.new_user_hours', 24);
        $largeDeposit = config('anti-fraud.fraud_thresholds.new_user_large_deposit_uzs', 100000);

        $isNewUser    = $user->created_at->diffInHours(now()) < $newUserHours;
        $isLargeDeposit = $deposit->amount > $largeDeposit;

        if ($isNewUser && $isLargeDeposit) {
            $deposit->update(['is_suspicious' => true]);
            static::flagUser($user, 'Yangi foydalanuvchi katta depozit');
        }
    }

    /**
     * Transfer amalga oshirilganda chaqiriladi
     */
    public static function onTransfer(User $user, $transfer): void
    {
        // 1. 24 soatlik transfer soni tekshiruvi
        $transferCount = AisTransfer::where('sender_id', $user->id)
            ->where('created_at', '>=', now()->subHours(24))
            ->count();

        $maxTransfers = config('anti-fraud.fraud_thresholds.max_transfers_per_day', 10);

        if ($transferCount >= $maxTransfers) {
            static::flagUser($user, "24 soatda ko'p transfer");
        }

        // 2. Aylanma transfer tekshiruvi (A→B, B→A)
        $circular = AisTransfer::where('sender_id', $transfer->receiver_id)
            ->where('receiver_id', $user->id)
            ->where('created_at', '>=', now()->subHours(24))
            ->exists();

        if ($circular) {
            static::flagUser($user, 'Aylanma transfer aniqlandi');
            BehavioralScoreService::adjust($user, -20, 'circular_transfer');
        }
    }

    /**
     * Foydalanuvchini fraud flag bilan belgilash
     */
    public static function flagUser(User $user, string $reason): FraudFlag
    {
        $flag = FraudFlag::create([
            'user_id'    => $user->id,
            'reason'     => $reason,
            'flagged_by' => 'system',
        ]);

        try {
            AuditLog::critical('fraud_flag_created', $user, [
                'flag_id' => $flag->id,
                'reason'  => $reason,
            ]);
        } catch (\Throwable $e) {
            Log::warning('FraudDetectionService: AuditLog yozishda xato (flagUser)', [
                'user_id' => $user->id,
                'reason'  => $reason,
                'error'   => $e->getMessage(),
            ]);
        }

        return $flag;
    }

    /**
     * Fraud flagni olib tashlash (admin)
     */
    public static function unflagUser(User $user, int $flagId): void
    {
        FraudFlag::where('id', $flagId)
            ->where('user_id', $user->id)
            ->update([
                'resolved_at' => now(),
                'resolved_by' => auth()->id(),
            ]);

        try {
            AuditLog::log('fraud_flag_resolved', $user, [
                'flag_id' => $flagId,
            ]);
        } catch (\Throwable $e) {
            Log::warning('FraudDetectionService: AuditLog yozishda xato (unflagUser)', [
                'user_id' => $user->id,
                'flag_id' => $flagId,
                'error'   => $e->getMessage(),
            ]);
        }
    }

    /**
     * Foydalanuvchini ban qilish (admin)
     */
    public static function banUser(User $user): void
    {
        \Illuminate\Support\Facades\DB::transaction(function () use ($user) {
            $user = User::lockForUpdate()->find($user->id);
            $user->update(['status' => 'banned']);

            // Kutilayotgan depozitlarni bekor qilish
            Deposit::where('user_id', $user->id)
                ->where('status', 'pending')
                ->update(['status' => 'cancelled']);

            // Kutilayotgan yechib olishlarni bekor qilish + pulni qaytarish
            $pendingWithdrawals = Withdrawal::where('user_id', $user->id)
                ->where('status', 'pending')
                ->get();

            foreach ($pendingWithdrawals as $withdrawal) {
                $withdrawal->update(['status' => 'failed', 'feedback' => 'Hisob bloklandi']);

                // Pul allaqachon balansdan yechilgan — qaytarish kerak
                $user->increment('balance', $withdrawal->amount);

                // Transaction yozuvi
                $user->transactions()->create([
                    'type'                 => 'withdraw',
                    'transactionable_type' => Withdrawal::class,
                    'transactionable_id'   => $withdrawal->id,
                    'amount'               => $withdrawal->amount,
                    'balance_before'       => $user->balance - $withdrawal->amount,
                    'balance_after'        => $user->balance,
                    'direction'            => 'credit',
                    'status'               => 'reversed',
                    'description'          => 'Hisob bloklandi — yechim bekor qilindi',
                ]);
            }
        });

        try {
            AuditLog::critical('user_banned', $user, [
                'banned_by' => auth()->id(),
            ]);
        } catch (\Throwable $e) {
            Log::warning('FraudDetectionService: AuditLog yozishda xato (banUser)', [
                'user_id' => $user->id,
                'error'   => $e->getMessage(),
            ]);
        }
    }
}
