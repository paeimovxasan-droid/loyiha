<?php

namespace App\Services\Catalog;

use App\Models\AIS\Wallet;
use App\Models\Catalog\CatalogOrder;
use App\Models\Catalog\CatalogReview;
use App\Models\Catalog\Product;
use App\Models\Catalog\Shop;
use App\Models\Level\XpLog;
use App\Models\User;
use App\Services\XpService;
use Illuminate\Support\Facades\DB;

class CatalogOrderService
{
    /**
     * Buyurtma berish: balans tekshiruvi, o'z do'konidan taqiqlash, to'lov yechish
     */
    public static function placeOrder(User $buyer, Product $product): CatalogOrder
    {
        return DB::transaction(function () use ($buyer, $product) {
            $shop = $product->shop;

            // O'z do'konidan buyurtma taqiqlash
            if ($shop->user_id === $buyer->id) {
                throw new \Exception('O\'z do\'koningizdan buyurtma bera olmaysiz.');
            }

            $amount = (float) $product->price;

            // Xaridor hamyonini tekshirish
            $buyerWallet = Wallet::lockForUpdate()->where('user_id', $buyer->id)->first();

            if (!$buyerWallet || !$buyerWallet->hasEnough($amount)) {
                throw new \Exception('Balansingiz yetarli emas.');
            }

            // To'lovni yechish
            $buyerWallet->decrement('balance', $amount);

            // Cashback hisoblash
            $cashbackAmount = round($amount * (float) $shop->cashback_percent / 100, 4);

            return CatalogOrder::create([
                'product_id'      => $product->id,
                'shop_id'         => $shop->id,
                'buyer_id'        => $buyer->id,
                'seller_id'       => $shop->user_id,
                'amount'          => $amount,
                'cashback_amount' => $cashbackAmount,
                'status'          => CatalogOrder::STATUS_PENDING,
            ]);
        });
    }

    /**
     * Buyurtmani tasdiqlash: pending → confirmed
     */
    public static function confirmOrder(CatalogOrder $order, User $shopOwner): CatalogOrder
    {
        if ($order->seller_id !== $shopOwner->id) {
            throw new \Exception('Sizga ruxsat berilmagan.');
        }

        if ($order->status !== CatalogOrder::STATUS_PENDING) {
            throw new \Exception('Buyurtma holati noto\'g\'ri.');
        }

        $order->update(['status' => CatalogOrder::STATUS_CONFIRMED]);
        return $order->fresh();
    }

    /**
     * Yetkazib berish: confirmed → delivered
     */
    public static function deliverOrder(CatalogOrder $order, User $shopOwner): CatalogOrder
    {
        if ($order->seller_id !== $shopOwner->id) {
            throw new \Exception('Sizga ruxsat berilmagan.');
        }

        if ($order->status !== CatalogOrder::STATUS_CONFIRMED) {
            throw new \Exception('Buyurtma holati noto\'g\'ri.');
        }

        $order->update(['status' => CatalogOrder::STATUS_DELIVERED]);
        return $order->fresh();
    }

    /**
     * Buyurtmani yakunlash: delivered → completed
     * 90% sotuvchiga, 10% platforma, cashback xaridorga
     */
    public static function completeOrder(CatalogOrder $order, User $buyer): CatalogOrder
    {
        return DB::transaction(function () use ($order, $buyer) {
            if ($order->buyer_id !== $buyer->id) {
                throw new \Exception('Sizga ruxsat berilmagan.');
            }

            if ($order->status !== CatalogOrder::STATUS_DELIVERED) {
                throw new \Exception('Buyurtma holati noto\'g\'ri.');
            }

            $amount = (float) $order->amount;
            $platformFeePercent = (float) config('catalog.platform_fee_percent', 10);
            $platformFee = round($amount * $platformFeePercent / 100, 4);
            $sellerAmount = round($amount - $platformFee, 4);

            // Sotuvchiga to'lov
            $sellerWallet = Wallet::lockForUpdate()->where('user_id', $order->seller_id)->first();
            if ($sellerWallet) {
                $sellerWallet->increment('balance', $sellerAmount);
            }

            // Cashback xaridorga
            $cashbackAmount = (float) $order->cashback_amount;
            if ($cashbackAmount > 0) {
                $buyerWallet = Wallet::lockForUpdate()->where('user_id', $buyer->id)->first();
                if ($buyerWallet) {
                    $buyerWallet->increment('balance', $cashbackAmount);
                }
            }

            $order->update([
                'status'       => CatalogOrder::STATUS_COMPLETED,
                'completed_at' => now(),
            ]);

            // XP berish — xaridorga
            XpService::award($buyer, XpLog::ACTION_CATALOG_ORDER, 10,
                'Buyurtma yakunlandi #' . $order->id, $order);

            return $order->fresh();
        });
    }

    /**
     * Sharh qoldirish: faqat completed, bitta sharh, avg_rating yangilash
     */
    public static function leaveReview(CatalogOrder $order, User $reviewer, array $data): CatalogReview
    {
        return DB::transaction(function () use ($order, $reviewer, $data) {
            if ($order->buyer_id !== $reviewer->id) {
                throw new \Exception('Sizga ruxsat berilmagan.');
            }

            if ($order->status !== CatalogOrder::STATUS_COMPLETED) {
                throw new \Exception('Faqat yakunlangan buyurtmaga sharh.');
            }

            // Bitta sharh tekshiruvi
            if (CatalogReview::where('order_id', $order->id)->exists()) {
                throw new \Exception('Bu buyurtmaga allaqachon sharh berilgan.');
            }

            $rating = (int) $data['rating'];
            if ($rating < 1 || $rating > 5) {
                throw new \Exception('Baho 1-5 oraliqda bo\'lishi kerak.');
            }

            $review = CatalogReview::create([
                'order_id'    => $order->id,
                'shop_id'     => $order->shop_id,
                'reviewer_id' => $reviewer->id,
                'rating'      => $rating,
                'comment'     => $data['comment'] ?? null,
            ]);

            // O'rtacha reytingni yangilash
            $shop = Shop::find($order->shop_id);
            $avgRating = CatalogReview::where('shop_id', $shop->id)->avg('rating');
            $totalReviews = CatalogReview::where('shop_id', $shop->id)->count();

            $shop->update([
                'avg_rating'    => round($avgRating, 2),
                'total_reviews' => $totalReviews,
            ]);

            // XP berish — sharhchi
            XpService::award($reviewer, XpLog::ACTION_CATALOG_REVIEW, 5,
                'Sharh qoldirish: do\'kon #' . $shop->id, $review);

            return $review;
        });
    }
}
