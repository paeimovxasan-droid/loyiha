<?php

namespace App\Services\Catalog;

use App\Models\AIS\Wallet;
use App\Models\Catalog\Product;
use App\Models\Catalog\Shop;
use App\Models\Level\XpLog;
use App\Models\User;
use App\Services\XpService;
use Illuminate\Support\Facades\DB;

class ShopService
{
    /**
     * Do'kon yaratish: unique tekshiruv, to'lov yechish, XP berish
     */
    public static function createShop(User $user, array $data): Shop
    {
        return DB::transaction(function () use ($user, $data) {
            // Foydalanuvchida allaqachon do'kon bormi?
            if (Shop::where('user_id', $user->id)->exists()) {
                throw new \Exception('Sizda allaqachon do\'kon mavjud.');
            }

            $registrationFee = (float) config('catalog.shop_registration_fee', 10);

            // Hamyon balansini tekshirish
            $wallet = Wallet::lockForUpdate()->where('user_id', $user->id)->first();

            if (!$wallet || !$wallet->hasEnough($registrationFee)) {
                throw new \Exception('Balansingiz yetarli emas.');
            }

            // To'lovni yechish
            $wallet->decrement('balance', $registrationFee);

            // Cashback validatsiyasi
            $cashbackPercent = $data['cashback_percent'] ?? 1.0;
            if ($cashbackPercent < 1 || $cashbackPercent > 5) {
                throw new \Exception('Cashback 1-5% oraliqda bo\'lishi kerak.');
            }

            // Do'kon yaratish
            $shop = Shop::create([
                'user_id'          => $user->id,
                'name'             => $data['name'],
                'description'      => $data['description'] ?? null,
                'category'         => $data['category'],
                'address'          => $data['address'],
                'phone'            => $data['phone'],
                'image'            => $data['image'] ?? null,
                'cashback_percent' => $cashbackPercent,
                'status'           => Shop::STATUS_ACTIVE,
            ]);

            // XP berish
            XpService::award($user, XpLog::ACTION_CATALOG_SHOP, 20,
                'Do\'kon ochish: ' . $shop->name, $shop);

            return $shop;
        });
    }

    /**
     * Do'kon ma'lumotlarini yangilash
     */
    public static function updateShop(Shop $shop, array $data): Shop
    {
        // Cashback validatsiyasi
        if (isset($data['cashback_percent'])) {
            $cashbackPercent = (float) $data['cashback_percent'];
            if ($cashbackPercent < 1 || $cashbackPercent > 5) {
                throw new \Exception('Cashback 1-5% oraliqda bo\'lishi kerak.');
            }
        }

        $shop->update(array_filter([
            'name'             => $data['name'] ?? null,
            'description'      => $data['description'] ?? null,
            'category'         => $data['category'] ?? null,
            'address'          => $data['address'] ?? null,
            'phone'            => $data['phone'] ?? null,
            'image'            => $data['image'] ?? null,
            'cashback_percent' => $data['cashback_percent'] ?? null,
        ], fn($v) => $v !== null));

        return $shop->fresh();
    }

    /**
     * Mahsulot qo'shish
     */
    public static function addProduct(Shop $shop, array $data): Product
    {
        $price = (float) ($data['price'] ?? 0);
        if ($price <= 0) {
            throw new \Exception('Narx musbat bo\'lishi kerak.');
        }

        return Product::create([
            'shop_id'     => $shop->id,
            'name'        => $data['name'],
            'description' => $data['description'] ?? null,
            'price'       => $price,
            'image'       => $data['image'] ?? null,
            'status'      => Product::STATUS_ACTIVE,
        ]);
    }

    /**
     * Mahsulot yangilash (egasi tekshiruvi controller da)
     */
    public static function updateProduct(Product $product, array $data): Product
    {
        if (isset($data['price'])) {
            $price = (float) $data['price'];
            if ($price <= 0) {
                throw new \Exception('Narx musbat bo\'lishi kerak.');
            }
        }

        $product->update(array_filter([
            'name'        => $data['name'] ?? null,
            'description' => $data['description'] ?? null,
            'price'       => $data['price'] ?? null,
            'image'       => $data['image'] ?? null,
            'status'      => $data['status'] ?? null,
        ], fn($v) => $v !== null));

        return $product->fresh();
    }

    /**
     * Mahsulot o'chirish (soft: inactive ga o'tkazish)
     */
    public static function deleteProduct(Product $product): void
    {
        $product->update(['status' => Product::STATUS_INACTIVE]);
    }
}
