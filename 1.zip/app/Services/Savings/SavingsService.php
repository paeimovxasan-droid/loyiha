<?php

namespace App\Services\Savings;

use App\Models\Finance\Transaction;
use App\Models\Level\XpLog;
use App\Models\Savings\SavingsPayment;
use App\Models\Savings\SavingsPlan;
use App\Models\User;
use App\Services\XpService;
use Illuminate\Support\Facades\DB;

class SavingsService
{
    /**
     * Jamg'arma rejasi yaratish
     *
     * @throws \Exception
     */
    public static function createPlan(User $user, int $termMonths, float $monthlyAmount, string $currency = 'UZS'): SavingsPlan
    {
        if (!in_array($termMonths, [3, 6, 12])) {
            throw new \Exception('Muddat faqat 3, 6 yoki 12 oy bo\'lishi mumkin.');
        }

        if ($monthlyAmount <= 0) {
            throw new \Exception('Oylik miqdor 0 dan katta bo\'lishi kerak.');
        }

        if (!in_array($currency, ['UZS', 'AIS'])) {
            throw new \Exception('Valyuta faqat UZS yoki AIS bo\'lishi mumkin.');
        }

        // Bonus foizini muddat asosida hisoblash
        $bonusRate = match ($termMonths) {
            3  => 5.0,
            6  => 10.0,
            12 => 15.0,
        };

        return SavingsPlan::create([
            'user_id'          => $user->id,
            'term_months'      => $termMonths,
            'monthly_amount'   => $monthlyAmount,
            'currency'         => $currency,
            'bonus_rate'       => $bonusRate,
            'total_saved'      => 0,
            'paid_months'      => 0,
            'status'           => 'active',
            'next_payment_date' => now()->addMonth()->startOfDay()->toDateString(),
        ]);
    }

    /**
     * Oylik to'lovni amalga oshirish
     *
     * @throws \Exception
     */
    public static function processMonthlyPayment(SavingsPlan $plan): SavingsPayment
    {
        if (!$plan->isActive()) {
            throw new \Exception('Bu reja faol emas.');
        }

        return DB::transaction(function () use ($plan) {
            $plan = SavingsPlan::lockForUpdate()->find($plan->id);
            $user = $plan->user;
            $amount = (float) $plan->monthly_amount;
            $currency = $plan->currency;
            $monthNumber = $plan->paid_months + 1;

            if ($currency === 'UZS') {
                $user = User::lockForUpdate()->find($user->id);
                if ((float) $user->balance < $amount) {
                    // Missed payment
                    return SavingsPayment::create([
                        'savings_plan_id' => $plan->id,
                        'user_id'         => $user->id,
                        'amount'          => $amount,
                        'currency'        => $currency,
                        'month_number'    => $monthNumber,
                        'status'          => 'missed',
                    ]);
                }
                $balanceBefore = (float) $user->balance;
                $user->decrement('balance', $amount);
                $user->refresh();
                $balanceAfter = (float) $user->balance;
            } else {
                $wallet = \App\Models\AIS\Wallet::lockForUpdate()
                    ->where('user_id', $user->id)->first();
                if (!$wallet || !$wallet->hasEnough($amount)) {
                    return SavingsPayment::create([
                        'savings_plan_id' => $plan->id,
                        'user_id'         => $user->id,
                        'amount'          => $amount,
                        'currency'        => $currency,
                        'month_number'    => $monthNumber,
                        'status'          => 'missed',
                    ]);
                }
                $balanceBefore = (float) $wallet->balance;
                $wallet->decrement('balance', $amount);
                $wallet->refresh();
                $balanceAfter = (float) $wallet->balance;
            }

            $plan->increment('paid_months');
            $plan->increment('total_saved', $amount);
            $plan->update([
                'next_payment_date' => now()->addMonth()->startOfDay()->toDateString(),
            ]);

            $payment = SavingsPayment::create([
                'savings_plan_id' => $plan->id,
                'user_id'         => $user->id,
                'amount'          => $amount,
                'currency'        => $currency,
                'month_number'    => $monthNumber,
                'status'          => 'paid',
            ]);

            // Transaction yozuvi
            Transaction::create([
                'user_id'              => $user->id,
                'type'                 => Transaction::TYPE_SAVINGS,
                'transactionable_type' => SavingsPayment::class,
                'transactionable_id'   => $payment->id,
                'amount'               => $amount,
                'balance_before'       => $balanceBefore,
                'balance_after'        => $balanceAfter,
                'direction'            => 'debit',
                'status'               => 'completed',
                'description'          => "Jamg'arma oylik to'lov: {$amount} {$currency} ({$monthNumber}-oy)",
            ]);

            return $payment;
        });
    }

    /**
     * Muddat tugashi — bonus bilan qaytarish
     *
     * @throws \Exception
     */
    public static function finalizePlan(SavingsPlan $plan): void
    {
        if (!$plan->isActive()) {
            throw new \Exception('Bu reja faol emas.');
        }

        if (!$plan->isCompleted()) {
            throw new \Exception('Reja hali tugallanmagan.');
        }

        DB::transaction(function () use ($plan) {
            $plan = SavingsPlan::lockForUpdate()->find($plan->id);
            $user = $plan->user;
            $totalSaved = (float) $plan->total_saved;
            $bonus = round($totalSaved * (float) $plan->bonus_rate / 100, 2);
            $totalReturn = $totalSaved + $bonus;
            $currency = $plan->currency;

            if ($currency === 'UZS') {
                $user = User::lockForUpdate()->find($user->id);
                $balanceBefore = (float) $user->balance;
                $user->increment('balance', $totalReturn);
                $user->refresh();
                $balanceAfter = (float) $user->balance;
            } else {
                $wallet = \App\Models\AIS\Wallet::lockForUpdate()
                    ->where('user_id', $user->id)->first();

                if (!$wallet) {
                    throw new \Exception('AIS hamyon topilmadi. Jamg\'arma yakunlanmadi.');
                }

                $balanceBefore = (float) $wallet->balance;
                $wallet->increment('balance', $totalReturn);
                $wallet->refresh();
                $balanceAfter = (float) $wallet->balance;
            }

            $plan->update(['status' => 'completed']);

            // Transaction yozuvi
            Transaction::create([
                'user_id'              => $user->id,
                'type'                 => Transaction::TYPE_SAVINGS,
                'transactionable_type' => SavingsPlan::class,
                'transactionable_id'   => $plan->id,
                'amount'               => $totalReturn,
                'balance_before'       => $balanceBefore,
                'balance_after'        => $balanceAfter,
                'direction'            => 'credit',
                'status'               => 'completed',
                'description'          => "Jamg'arma tugadi: {$totalSaved} + bonus {$bonus} = {$totalReturn} {$currency}",
            ]);

            // XP berish
            XpService::award($user, XpLog::ACTION_SAVINGS_COMPLETE, 0,
                'Jamg\'arma tugallandi: ' . $totalReturn . ' ' . $currency, $plan);
        });
    }

    /**
     * Muddatidan oldin yechish (bonussiz)
     *
     * @throws \Exception
     */
    public static function cancelPlan(SavingsPlan $plan): void
    {
        if (!$plan->isActive()) {
            throw new \Exception('Bu reja faol emas.');
        }

        DB::transaction(function () use ($plan) {
            $plan = SavingsPlan::lockForUpdate()->find($plan->id);
            $user = $plan->user;
            $totalSaved = (float) $plan->total_saved;
            $currency = $plan->currency;

            if ($totalSaved > 0) {
                if ($currency === 'UZS') {
                    $user = User::lockForUpdate()->find($user->id);
                    $balanceBefore = (float) $user->balance;
                    $user->increment('balance', $totalSaved);
                    $user->refresh();
                    $balanceAfter = (float) $user->balance;
                } else {
                    $wallet = \App\Models\AIS\Wallet::lockForUpdate()
                        ->where('user_id', $user->id)->first();

                    if (!$wallet) {
                        throw new \Exception('AIS hamyon topilmadi. Jamg\'arma bekor qilinmadi.');
                    }

                    $balanceBefore = (float) $wallet->balance;
                    $wallet->increment('balance', $totalSaved);
                    $wallet->refresh();
                    $balanceAfter = (float) $wallet->balance;
                }

                // Transaction yozuvi
                Transaction::create([
                    'user_id'              => $user->id,
                    'type'                 => Transaction::TYPE_SAVINGS,
                    'transactionable_type' => SavingsPlan::class,
                    'transactionable_id'   => $plan->id,
                    'amount'               => $totalSaved,
                    'balance_before'       => $balanceBefore,
                    'balance_after'        => $balanceAfter,
                    'direction'            => 'credit',
                    'status'               => 'completed',
                    'description'          => "Jamg'arma bekor qilindi: {$totalSaved} {$currency} qaytarildi (bonussiz)",
                ]);
            }

            $plan->update(['status' => 'cancelled']);
        });
    }
}
