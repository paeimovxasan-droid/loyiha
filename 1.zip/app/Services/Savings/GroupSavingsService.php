<?php

namespace App\Services\Savings;

use App\Models\Finance\Transaction;
use App\Models\Savings\SavingGroup;
use App\Models\Savings\SavingGroupMember;
use App\Models\Savings\SavingGroupRound;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class GroupSavingsService
{
    /**
     * Guruh yaratish
     *
     * @throws \Exception
     */
    public static function createGroup(
        User $admin,
        string $name,
        int $maxMembers,
        float $monthlyAmount,
        string $currency = 'UZS'
    ): SavingGroup {
        if ($maxMembers < 5 || $maxMembers > 20) {
            throw new \Exception('A\'zolar soni 5 dan 20 gacha bo\'lishi kerak.');
        }

        if ($monthlyAmount <= 0) {
            throw new \Exception('Oylik miqdor 0 dan katta bo\'lishi kerak.');
        }

        if (!in_array($currency, ['UZS', 'AIS'])) {
            throw new \Exception('Valyuta faqat UZS yoki AIS bo\'lishi mumkin.');
        }

        return DB::transaction(function () use ($admin, $name, $maxMembers, $monthlyAmount, $currency) {
            $group = SavingGroup::create([
                'admin_id'       => $admin->id,
                'name'           => $name,
                'max_members'    => $maxMembers,
                'monthly_amount' => $monthlyAmount,
                'currency'       => $currency,
                'current_round'  => 0,
                'status'         => 'pending',
            ]);

            // Yaratuvchini admin va birinchi a'zo sifatida qo'shish
            SavingGroupMember::create([
                'saving_group_id' => $group->id,
                'user_id'         => $admin->id,
                'status'          => 'active',
                'joined_at'       => now(),
            ]);

            return $group;
        });
    }

    /**
     * Guruhga qo'shilish so'rovi
     *
     * @throws \Exception
     */
    public static function joinRequest(User $user, SavingGroup $group): SavingGroupMember
    {
        // Guruh to'liq tekshirish
        $activeCount = $group->members()->whereIn('status', ['active', 'pending'])->count();
        if ($activeCount >= $group->max_members) {
            throw new \Exception('Guruh to\'liq.');
        }

        // Allaqachon a'zo tekshirish
        $existing = SavingGroupMember::where('saving_group_id', $group->id)
            ->where('user_id', $user->id)
            ->first();

        if ($existing) {
            throw new \Exception('Siz allaqachon bu guruhda a\'zosiz yoki so\'rov yuborgansiz.');
        }

        return SavingGroupMember::create([
            'saving_group_id' => $group->id,
            'user_id'         => $user->id,
            'status'          => 'pending',
        ]);
    }

    /**
     * So'rovni tasdiqlash (faqat admin)
     *
     * @throws \Exception
     */
    public static function approveJoin(SavingGroup $group, SavingGroupMember $member): void
    {
        if ($member->saving_group_id !== $group->id) {
            throw new \Exception('Bu a\'zo bu guruhga tegishli emas.');
        }

        if (!$member->isPending()) {
            throw new \Exception('Bu so\'rov allaqachon ko\'rib chiqilgan.');
        }

        // Guruh to'liq tekshirish
        $activeCount = $group->activeMembers()->count();
        if ($activeCount >= $group->max_members) {
            throw new \Exception('Guruh to\'liq.');
        }

        $member->update([
            'status'    => 'active',
            'joined_at' => now(),
        ]);
    }

    /**
     * Navbat belgilash (guruh to'lganda)
     */
    public static function assignRounds(SavingGroup $group): void
    {
        $members = $group->activeMembers()->get()->shuffle();

        $order = 1;
        foreach ($members as $member) {
            $member->update(['round_order' => $order]);
            $order++;
        }

        $group->update([
            'status'     => 'active',
            'started_at' => now(),
        ]);
    }

    /**
     * Oylik yig'im va to'lov
     *
     * @throws \Exception
     */
    public static function processRound(SavingGroup $group): SavingGroupRound
    {
        if (!$group->isActive()) {
            throw new \Exception('Guruh faol emas.');
        }

        $nextRound = $group->current_round + 1;
        $activeMembers = $group->activeMembers()->get();
        $totalMembers = $activeMembers->count();

        if ($totalMembers === 0) {
            throw new \Exception('Guruhda faol a\'zolar yo\'q.');
        }

        // Navbatdagi oluvchini topish
        $recipient = $group->activeMembers()
            ->where('round_order', $nextRound)
            ->first();

        if (!$recipient) {
            // Barcha roundlar tugagan
            $group->update(['status' => 'completed']);
            throw new \Exception('Barcha davrlar tugallangan.');
        }

        return DB::transaction(function () use ($group, $nextRound, $activeMembers, $recipient) {
            $monthlyAmount = (float) $group->monthly_amount;
            $currency = $group->currency;
            $totalCollected = 0;
            $hasDefault = false;

            // Barcha a'zolardan to'lov yig'ish
            foreach ($activeMembers as $member) {
                $memberUser = User::lockForUpdate()->find($member->user_id);

                if ($currency === 'UZS') {
                    if ((float) $memberUser->balance < $monthlyAmount) {
                        $member->update(['status' => 'defaulted']);
                        $hasDefault = true;
                        continue;
                    }
                    $balanceBefore = (float) $memberUser->balance;
                    $memberUser->decrement('balance', $monthlyAmount);
                    $memberUser->refresh();
                    $balanceAfter = (float) $memberUser->balance;
                } else {
                    $wallet = \App\Models\AIS\Wallet::lockForUpdate()
                        ->where('user_id', $memberUser->id)->first();
                    if (!$wallet || !$wallet->hasEnough($monthlyAmount)) {
                        $member->update(['status' => 'defaulted']);
                        $hasDefault = true;
                        continue;
                    }
                    $balanceBefore = (float) $wallet->balance;
                    $wallet->decrement('balance', $monthlyAmount);
                    $wallet->refresh();
                    $balanceAfter = (float) $wallet->balance;
                }

                $totalCollected += $monthlyAmount;

                // Transaction yozuvi — har bir a'zo uchun debit
                Transaction::create([
                    'user_id'              => $memberUser->id,
                    'type'                 => Transaction::TYPE_GROUP_SAVINGS,
                    'transactionable_type' => SavingGroup::class,
                    'transactionable_id'   => $group->id,
                    'amount'               => $monthlyAmount,
                    'balance_before'       => $balanceBefore,
                    'balance_after'        => $balanceAfter,
                    'direction'            => 'debit',
                    'status'               => 'completed',
                    'description'          => "Jamoaviy jamg'arma to'lov: {$monthlyAmount} {$currency} (davr {$nextRound})",
                ]);
            }

            if ($hasDefault) {
                $round = SavingGroupRound::create([
                    'saving_group_id' => $group->id,
                    'recipient_id'    => $recipient->user_id,
                    'round_number'    => $nextRound,
                    'total_collected'  => $totalCollected,
                    'status'          => 'failed',
                ]);

                $group->update(['status' => 'suspended']);
                return $round;
            }

            // Navbatdagi a'zoga to'liq summa o'tkazish
            $recipientUser = User::lockForUpdate()->find($recipient->user_id);

            if ($currency === 'UZS') {
                $balanceBefore = (float) $recipientUser->balance;
                $recipientUser->increment('balance', $totalCollected);
                $recipientUser->refresh();
                $balanceAfter = (float) $recipientUser->balance;
            } else {
                $wallet = \App\Models\AIS\Wallet::lockForUpdate()
                    ->where('user_id', $recipientUser->id)->first();

                if (!$wallet) {
                    throw new \Exception("Oluvchi (user #{$recipientUser->id}) AIS hamyoni topilmadi.");
                }

                $balanceBefore = (float) $wallet->balance;
                $wallet->increment('balance', $totalCollected);
                $wallet->refresh();
                $balanceAfter = (float) $wallet->balance;
            }

            // Transaction yozuvi — oluvchi uchun credit
            Transaction::create([
                'user_id'              => $recipientUser->id,
                'type'                 => Transaction::TYPE_GROUP_SAVINGS,
                'transactionable_type' => SavingGroup::class,
                'transactionable_id'   => $group->id,
                'amount'               => $totalCollected,
                'balance_before'       => $balanceBefore,
                'balance_after'        => $balanceAfter,
                'direction'            => 'credit',
                'status'               => 'completed',
                'description'          => "Jamoaviy jamg'arma olish: {$totalCollected} {$currency} (davr {$nextRound})",
            ]);

            $round = SavingGroupRound::create([
                'saving_group_id' => $group->id,
                'recipient_id'    => $recipient->user_id,
                'round_number'    => $nextRound,
                'total_collected'  => $totalCollected,
                'status'          => 'completed',
                'completed_at'    => now(),
            ]);

            $group->update(['current_round' => $nextRound]);

            // Barcha roundlar tugadimi tekshirish
            $totalRounds = $group->activeMembers()->count();
            if ($nextRound >= $totalRounds) {
                $group->update(['status' => 'completed']);
                $group->activeMembers()->update(['status' => 'completed']);
            }

            return $round;
        });
    }
}
