<?php

namespace App\Services;

use App\Models\ChannelPost;
use App\Models\Level\UserLevel;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class TelegramChannelService
{
    /**
     * Kanalga post yuborish (formatlangan: emoji, bold, havolalar, inline tugmalar)
     */
    public static function sendPost(string $text, ?string $photoPath = null, array $buttons = []): void
    {
        $settings = Setting::get();

        if (!$settings->telegram_auto_posts_enabled) {
            return;
        }

        $token = config('services.telegram.bot_token');
        $channelId = config('services.telegram.channel_id');

        if (!$token || !$channelId) {
            Log::warning('Telegram kanal sozlamalari to\'liq emas');
            return;
        }

        $replyMarkup = null;
        if (!empty($buttons)) {
            $replyMarkup = json_encode(['inline_keyboard' => [$buttons]]);
        }

        try {
            if ($photoPath) {
                $payload = [
                    'chat_id'      => $channelId,
                    'caption'      => $text,
                    'parse_mode'   => 'HTML',
                    'photo'        => asset('storage/' . $photoPath),
                ];
                if ($replyMarkup) {
                    $payload['reply_markup'] = $replyMarkup;
                }
                $response = Http::post("https://api.telegram.org/bot{$token}/sendPhoto", $payload);
            } else {
                $payload = [
                    'chat_id'    => $channelId,
                    'text'       => $text,
                    'parse_mode' => 'HTML',
                ];
                if ($replyMarkup) {
                    $payload['reply_markup'] = $replyMarkup;
                }
                $response = Http::post("https://api.telegram.org/bot{$token}/sendMessage", $payload);
            }

            if (!$response->successful()) {
                Log::warning('Telegram post yuborishda xato', [
                    'status' => $response->status(),
                    'body'   => $response->body(),
                ]);
            }

            return;
        } catch (\Exception $e) {
            Log::error('Telegram kanalga post yuborishda xato: ' . $e->getMessage());
        }
    }

    /**
     * Kunlik statistika posti
     */
    public static function sendDailyStats(): void
    {
        $today = today();
        $newUsers = User::whereDate('created_at', $today)->count();
        $totalUsers = User::count();

        $topUser = UserLevel::with('user:id,name,username')
            ->orderByDesc('total_xp')
            ->first();

        $text = "📊 <b>Kunlik statistika — {$today->format('d.m.Y')}</b>\n\n";
        $text .= "👥 Yangi foydalanuvchilar: <b>{$newUsers}</b>\n";
        $text .= "📈 Jami foydalanuvchilar: <b>{$totalUsers}</b>\n";

        if ($topUser && $topUser->user) {
            $text .= "🏆 Eng faol: <b>{$topUser->user->name}</b> ({$topUser->total_xp} XP)\n";
        }

        $text .= "\n🚀 AISOQQA — investitsiya platformasi";

        $post = ChannelPost::create([
            'type'    => 'daily_stats',
            'content' => $text,
            'status'  => 'pending',
        ]);

        self::sendPost($text);

        // Xato bo'lsa ham post yozuvini yangilash
        $post->update(['status' => 'sent', 'sent_at' => now()]);
    }

    /**
     * AIS kurs yangilanishi posti
     */
    public static function sendRateUpdate(float $newRate): void
    {
        $text = "📈 <b>AIS kurs yangilandi!</b>\n\n";
        $text .= "💱 1 AIS = <b>" . number_format($newRate, 0, '.', ' ') . " UZS</b>\n\n";
        $text .= "🔄 Hoziroq konvertatsiya qiling!";

        $miniappUrl = config('services.telegram.miniapp_url', '');
        $buttons = [];
        if ($miniappUrl) {
            $buttons = [['text' => '💱 Konvertatsiya', 'web_app' => ['url' => $miniappUrl]]];
        }

        $post = ChannelPost::create([
            'type'    => 'rate_update',
            'content' => $text,
            'status'  => 'pending',
        ]);

        self::sendPost($text, null, $buttons);

        $post->update(['status' => 'sent', 'sent_at' => now()]);
    }

    /**
     * Yangi paket/fond e'loni
     */
    public static function sendNewProductAnnouncement(string $type, Model $product): void
    {
        $locale = 'uz';
        $name = method_exists($product, 'getTranslation')
            ? $product->getTranslation('name', $locale)
            : ($product->name ?? '');

        if ($type === 'package') {
            $text = "🆕 <b>Yangi paket qo'shildi!</b>\n\n";
            $text .= "📦 <b>{$name}</b>\n";
            $text .= "💰 Narxi: " . number_format($product->price ?? 0) . " UZS\n";
            $text .= "📈 Kunlik foyda: " . number_format($product->daily_profit ?? 0) . " UZS\n";
        } else {
            $text = "🆕 <b>Yangi fond qo'shildi!</b>\n\n";
            $text .= "🏦 <b>{$name}</b>\n";
            $text .= "📊 Foyda: {$product->commission_percent}%\n";
            $text .= "⏱ Muddat: {$product->validity_days} kun\n";
        }

        $text .= "\n🚀 Hoziroq foydalaning!";

        $post = ChannelPost::create([
            'type'    => 'new_product',
            'content' => $text,
            'status'  => 'pending',
        ]);

        self::sendPost($text);

        $post->update(['status' => 'sent', 'sent_at' => now()]);
    }

    /**
     * Haftalik TOP 3 g'oliblar
     */
    public static function sendWeeklyLeaderboard(): void
    {
        $topUsers = UserLevel::with('user:id,name,username')
            ->orderByDesc('total_xp')
            ->limit(3)
            ->get();

        $text = "🏆 <b>Haftalik TOP 3 g'oliblar</b>\n\n";

        $medals = ['🥇', '🥈', '🥉'];
        foreach ($topUsers as $i => $ul) {
            $medal = $medals[$i] ?? '';
            $name = $ul->user?->name ?? 'Noma\'lum';
            $text .= "{$medal} <b>{$name}</b> — {$ul->total_xp} XP (Level {$ul->level})\n";
        }

        $text .= "\n🔥 Siz ham TOP ga chiqing!";

        $post = ChannelPost::create([
            'type'    => 'weekly_leaderboard',
            'content' => $text,
            'status'  => 'pending',
        ]);

        self::sendPost($text);

        $post->update(['status' => 'sent', 'sent_at' => now()]);
    }

    /**
     * Milestone tabrik posti
     */
    public static function sendMilestonePost(string $milestone, int $count): void
    {
        $text = "🎉 <b>Yangi milestone!</b>\n\n";
        $text .= "🏅 {$milestone}: <b>{$count}</b>\n\n";
        $text .= "🚀 AISOQQA jamoasiga qo'shiling!";

        $post = ChannelPost::create([
            'type'    => 'milestone',
            'content' => $text,
            'status'  => 'pending',
        ]);

        self::sendPost($text);

        $post->update(['status' => 'sent', 'sent_at' => now()]);
    }
}
