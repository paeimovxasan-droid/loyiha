<?php

namespace App\Services\Credit;

use App\Models\Credit\Credit;
use App\Models\Credit\CreditPayment;
use App\Models\Finance\Transaction;
use App\Models\Level\XpLog;
use App\Models\User;
use App\Services\XpService;
use Illuminate\Support\Facades\DB;

class CreditService
{
    /**
     * Kredit reytingini hisoblash (0-100)
     *
     * @return array{score: int, max_amount: float, rates: array}
     */
    public static function calculateRating(User $user): array
    {
        // KYC tasdiqlanmagan — score=0
        if ($user->kyc_status !== 'verified') {
            return [
                'score'      => 0,
                'max_amount' => 0,
                'rates'      => [],
            ];
        }

        $score = 0;

        // 1. Level ball (max 30)
        $level = $user->level; // accessor from User model
        $score += min(30, $level * 2);

        // 2. KYC approved = 20 ball
        $score += 20;

        // 3. Platformadagi faollik kunlari (max 25)
        $daysSinceRegistration = (int) $user->created_at?->diffInDays(now());
        $score += min(25, (int) ($daysSinceRegistration / 7));

        // 4. Kredit tarixi (max 25)
        $paidCredits = Credit::where('user_id', $user->id)->where('status', 'paid')->count();
        $overdueCredits = Credit::where('user_id', $user->id)->where('status', 'overdue')->count();
        $historyScore = min(25, $paidCredits * 10) - ($overdueCredits * 15);
        $score += max(0, $historyScore);

        $score = min(100, max(0, $score));

        // Max amount va rates hisoblash
        $maxAmount = match (true) {
            $score >= 80 => 500000,
            $score >= 60 => 300000,
            $score >= 40 => 150000,
            $score >= 20 => 50000,
            default      => 10000,
        };

        $rates = self::getRatesForScore($score);

        return [
            'score'      => $score,
            'max_amount' => $maxAmount,
            'rates'      => $rates,
        ];
    }

    /**
     * Foiz stavkalarini reyting asosida hisoblash
     */
    private static function getRatesForScore(int $score): array
    {
        // Yuqori reyting = past foiz
        $baseRate = match (true) {
            $score >= 80 => 1.0,
            $score >= 60 => 2.0,
            $score >= 40 => 3.0,
            $score >= 20 => 4.0,
            default      => 5.0,
        };

        return [
            ['term_days' => 7,  'rate' => $baseRate],
            ['term_days' => 14, 'rate' => $baseRate + 0.5],
            ['term_days' => 30, 'rate' => $baseRate + 1.0],
        ];
    }

    /**
     * Kredit berish
     *
     * @throws \Exception
     */
    public static function issue(User $user, float $amount, int $termDays, string $currency = 'UZS'): Credit
    {
        // Validatsiya
        if (!in_array($termDays, [7, 14, 30])) {
            throw new \Exception('Muddat faqat 7, 14 yoki 30 kun bo\'lishi mumkin.');
        }

        if ($amount < 10000 || $amount > 500000) {
            throw new \Exception('Kredit miqdori 10,000 dan 500,000 gacha bo\'lishi kerak.');
        }

        if (!in_array($currency, ['UZS', 'AIS'])) {
            throw new \Exception('Valyuta faqat UZS yoki AIS bo\'lishi mumkin.');
        }

        // Kredit reyting tekshirish
        $rating = self::calculateRating($user);

        if ($rating['score'] === 0) {
            throw new \Exception('KYC tasdiqlanmagan. Kredit olish uchun KYC ni tasdiqlang.');
        }

        if ($amount > $rating['max_amount']) {
            throw new \Exception("Maksimal kredit miqdori: {$rating['max_amount']}. Reyting: {$rating['score']}");
        }

        return DB::transaction(function () use ($user, $amount, $termDays, $currency, $rating) {
            // Faol kredit tekshirish
            $activeCredit = Credit::where('user_id', $user->id)
                ->where('status', 'active')
                ->lockForUpdate()
                ->first();

            if ($activeCredit) {
                throw new \Exception('Sizda faol kredit mavjud. Avval uni qaytaring.');
            }

            // Foiz stavkani topish
            $rate = collect($rating['rates'])->firstWhere('term_days', $termDays);
            $interestRate = $rate ? $rate['rate'] : 5.0;
            $interestAmount = round($amount * $interestRate / 100, 2);

            $issuedAt = now();
            $dueDate = $issuedAt->copy()->addDays($termDays);

            // Balansga o'tkazish
            $user = User::lockForUpdate()->find($user->id);

            if ($currency === 'UZS') {
                $balanceBefore = (float) $user->balance;
                $user->increment('balance', $amount);
                $user->refresh();
                $balanceAfter = (float) $user->balance;
            } else {
                $wallet = \App\Models\AIS\Wallet::lockForUpdate()
                    ->where('user_id', $user->id)->first();
                if (!$wallet) {
                    throw new \Exception('AIS hamyon topilmadi.');
                }
                $balanceBefore = (float) $wallet->balance;
                $wallet->increment('balance', $amount);
                $wallet->refresh();
                $balanceAfter = (float) $wallet->balance;
            }

            $credit = Credit::create([
                'user_id'         => $user->id,
                'amount'          => $amount,
                'currency'        => $currency,
                'interest_rate'   => $interestRate,
                'interest_amount' => $interestAmount,
                'term_days'       => $termDays,
                'credit_score'    => $rating['score'],
                'status'          => 'active',
                'issued_at'       => $issuedAt,
                'due_date'        => $dueDate,
            ]);

            // Transaction yozuvi
            Transaction::create([
                'user_id'              => $user->id,
                'type'                 => Transaction::TYPE_CREDIT,
                'transactionable_type' => Credit::class,
                'transactionable_id'   => $credit->id,
                'amount'               => $amount,
                'balance_before'       => $balanceBefore,
                'balance_after'        => $balanceAfter,
                'direction'            => 'credit',
                'status'               => 'completed',
                'description'          => "Kredit berildi: {$amount} {$currency}, {$termDays} kun",
            ]);

            return $credit;
        });
    }

    /**
     * Kredit qaytarish
     *
     * @throws \Exception
     */
    public static function repay(User $user, Credit $credit): CreditPayment
    {
        if ($credit->user_id !== $user->id) {
            throw new \Exception('Bu kredit sizga tegishli emas.');
        }

        if (!in_array($credit->status, ['active', 'overdue'])) {
            throw new \Exception('Bu kredit qaytarilishi mumkin emas.');
        }

        $totalRepay = (float) $credit->amount + (float) $credit->interest_amount;

        return DB::transaction(function () use ($user, $credit, $totalRepay) {
            $currency = $credit->currency;

            if ($currency === 'UZS') {
                $user = User::lockForUpdate()->find($user->id);
                if ((float) $user->balance < $totalRepay) {
                    throw new \Exception('Balansingiz yetarli emas. Kerak: ' . $totalRepay . ' UZS');
                }
                $balanceBefore = (float) $user->balance;
                $user->decrement('balance', $totalRepay);
                $user->refresh();
                $balanceAfter = (float) $user->balance;
            } else {
                $wallet = \App\Models\AIS\Wallet::lockForUpdate()
                    ->where('user_id', $user->id)->first();
                if (!$wallet || !$wallet->hasEnough($totalRepay)) {
                    throw new \Exception('AIS balansingiz yetarli emas. Kerak: ' . $totalRepay . ' AIS');
                }
                $balanceBefore = (float) $wallet->balance;
                $wallet->decrement('balance', $totalRepay);
                $wallet->refresh();
                $balanceAfter = (float) $wallet->balance;
            }

            $credit = Credit::lockForUpdate()->find($credit->id);
            $credit->update([
                'status'  => 'paid',
                'paid_at' => now(),
            ]);

            $payment = CreditPayment::create([
                'credit_id' => $credit->id,
                'user_id'   => $user->id,
                'amount'    => $totalRepay,
                'principal' => $credit->amount,
                'interest'  => $credit->interest_amount,
                'currency'  => $currency,
            ]);

            // Transaction yozuvi
            Transaction::create([
                'user_id'              => $user->id,
                'type'                 => Transaction::TYPE_CREDIT,
                'transactionable_type' => CreditPayment::class,
                'transactionable_id'   => $payment->id,
                'amount'               => $totalRepay,
                'balance_before'       => $balanceBefore,
                'balance_after'        => $balanceAfter,
                'direction'            => 'debit',
                'status'               => 'completed',
                'description'          => "Kredit qaytarildi: {$totalRepay} {$currency}",
            ]);

            // XP berish
            XpService::award($user, XpLog::ACTION_CREDIT_REPAY, 0,
                'Kredit qaytarish: ' . $totalRepay . ' ' . $currency, $payment);

            return $payment;
        });
    }

    /**
     * Muddati o'tgan kreditlarni tekshirish
     * lockForUpdate — parallel cron run da race condition oldini oladi
     *
     * @return int O'zgartirilgan kreditlar soni
     */
    public static function checkOverdue(): int
    {
        $overdueCredits = Credit::where('status', 'active')
            ->where('due_date', '<', now())
            ->get();

        $count = 0;

        foreach ($overdueCredits as $credit) {
            DB::transaction(function () use ($credit, &$count) {
                // Lock bilan qayta o'qish — parallel run da ikki marta o'zgartirishni bloklash
                $credit = Credit::lockForUpdate()->find($credit->id);

                if (!$credit || $credit->status !== 'active') {
                    return;
                }

                if ($credit->due_date->isFuture()) {
                    return;
                }

                $credit->update(['status' => 'overdue']);
                $count++;
            });
        }

        return $count;
    }
}
