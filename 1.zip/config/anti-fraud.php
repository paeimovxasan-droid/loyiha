<?php

return [
    'vpn_whitelist' => explode(',', env('VPN_WHITELIST_IPS', '')),

    'fraud_thresholds' => [
        'max_accounts_per_ip'          => 3,
        'max_transfers_per_day'        => 10,
        'new_user_large_deposit_uzs'   => 100000,
        'new_user_hours'               => 24,
        'withdrawal_cooldown_days'     => 1,
        'bot_checkin_days'             => 7,
        'bot_checkin_tolerance_minutes'=> 5,
        'high_risk_score_threshold'    => 20,
    ],
];
