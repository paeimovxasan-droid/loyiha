<?php

return [

    /*
    |--------------------------------------------------------------------------
    | KYC Auto-Approve Threshold
    |--------------------------------------------------------------------------
    |
    | Liveness score 0.95 va undan yuqori bo'lsa, admin ko'rib chiqmasdan
    | avtomatik tasdiqlash. Production'da false qilib qo'ying.
    |
    */
    'auto_approve_threshold' => env('KYC_AUTO_APPROVE', false),

    /*
    |--------------------------------------------------------------------------
    | KYC Rate Limiting
    |--------------------------------------------------------------------------
    |
    | Bir soat ichida maksimal Face ID urinishlari soni.
    |
    */
    'max_attempts_per_hour' => env('KYC_MAX_ATTEMPTS_PER_HOUR', 3),

    /*
    |--------------------------------------------------------------------------
    | KYC Session TTL (daqiqalarda)
    |--------------------------------------------------------------------------
    */
    'session_ttl_minutes' => env('KYC_SESSION_TTL', 10),

    /*
    |--------------------------------------------------------------------------
    | Minimum Liveness Score
    |--------------------------------------------------------------------------
    */
    'min_liveness_score' => env('KYC_MIN_LIVENESS_SCORE', 0.70),

];
