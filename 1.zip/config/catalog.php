<?php

return [
    'shop_registration_fee' => env('CATALOG_SHOP_FEE', 10),
    'platform_fee_percent'  => env('CATALOG_PLATFORM_FEE', 10),
];
