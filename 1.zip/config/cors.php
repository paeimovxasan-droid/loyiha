<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Cross-Origin Resource Sharing (CORS) Configuration
    |--------------------------------------------------------------------------
    |
    | CORS faqat API marshrutlariga qo'llaniladi. Telegram Mini App va
    | aisoqqa.uz domenlariga ruxsat beriladi.
    |
    */

    'paths' => ['*'],

    'allowed_methods' => ['*'],

    'allowed_origins' => array_merge(
        array_filter(
            array_map('trim', explode(',', env('CORS_ALLOWED_ORIGINS', 'https://aisoqqa.uz')))
        ),
        [
            'https://web.telegram.org',
            'https://webk.telegram.org',
            'https://webz.telegram.org',
        ]
    ),

    'allowed_origins_patterns' => [
        'https://*.telegram.org',
        'https://*.t.me',
    ],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    'supports_credentials' => true,

];
