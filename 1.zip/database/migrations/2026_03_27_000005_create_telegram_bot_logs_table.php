<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Telegram bot so'rovlar logi jadvali
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('telegram_bot_logs', function (Blueprint $table) {
            $table->id();
            $table->string('telegram_id')->index();
            $table->string('command');
            $table->json('payload')->nullable();
            $table->timestamp('created_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('telegram_bot_logs');
    }
};
