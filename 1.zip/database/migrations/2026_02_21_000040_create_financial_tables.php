<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Foydalanuvchi moliyaviy hisobi (ledger - barcha moliyaviy harakatlar)
        Schema::create('transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('type', 50)->comment('deposit, withdraw, mining, commission, bonus, lucky_draw, fund');
            $table->nullableMorphs('transactionable');   // polymorphic relation
            $table->string('description', 255)->nullable();
            $table->decimal('amount', 15, 2)->default(0)->comment('Positive = credit, Negative = debit');
            $table->decimal('balance_before', 15, 2)->default(0);
            $table->decimal('balance_after', 15, 2)->default(0);
            $table->enum('direction', ['credit', 'debit']);
            $table->enum('status', ['pending', 'completed', 'failed', 'reversed'])->default('completed');
            $table->timestamps();

            $table->index(['user_id', 'type']);
            $table->index('created_at');
        });

        // Referral komissiyalar (har bir darajadan tushadigan)
        Schema::create('commissions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete()
                ->comment('Who receives the commission');
            $table->foreignId('from_user_id')->constrained('users')->cascadeOnDelete()
                ->comment('Who triggered the commission');
            $table->string('reason', 100)->comment('purchase, mining, deposit');
            $table->tinyInteger('level')->unsigned()->comment('1=direct, 2=second, 3=third...');
            $table->decimal('percent', 8, 2)->default(0)->comment('Commission %');
            $table->decimal('amount', 15, 2)->default(0)->comment('Commission amount');
            $table->date('date')->nullable();
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();

            $table->index(['user_id', 'level']);
        });

        // Bonuslar (admin tomonidan belgilanadigan maxsus bonuslar)
        Schema::create('bonuses', function (Blueprint $table) {
            $table->id();
            $table->json('name')->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->string('code', 50)->unique();
            $table->integer('required_services')->default(0)->comment('Required service count to unlock');
            $table->decimal('amount', 15, 2)->default(0)->comment('Bonus amount');
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();
        });

        // Foydalanuvchiga berilgan bonuslar
        Schema::create('bonus_ledgers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('bonus_id')->constrained('bonuses')->cascadeOnDelete();
            $table->decimal('amount', 15, 2)->default(0);
            $table->enum('status', ['pending', 'paid'])->default('pending');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('bonus_ledgers');
        Schema::dropIfExists('bonuses');
        Schema::dropIfExists('commissions');
        Schema::dropIfExists('transactions');
    }
};
