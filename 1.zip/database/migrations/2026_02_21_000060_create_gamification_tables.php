<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Kunlik belgilash (check-in)
        Schema::create('check_ins', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->date('checked_at')->nullable();
            $table->decimal('reward', 15, 2)->default(0)->comment('Daily checkin reward');
            $table->integer('streak')->default(1)->comment('Consecutive days');
            $table->timestamps();

            $table->unique(['user_id', 'checked_at']);
        });

        // Omad o'yini (Lucky Draw)
        Schema::create('lucky_draws', function (Blueprint $table) {
            $table->id();
            $table->json('name')->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->decimal('entry_fee', 15, 2)->default(0)->comment('Ticket price');
            $table->decimal('prize_amount', 15, 2)->default(0)->comment('Prize Pool');
            $table->integer('max_tickets')->default(0)->comment('0 = unlimited');
            $table->timestamp('draw_at')->nullable()->comment('Draw date/time');
            $table->enum('status', ['upcoming', 'active', 'completed'])->default('active');
            $table->timestamps();
        });

        // Lucky Draw ticket xaridlari
        Schema::create('lucky_draw_tickets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('lucky_draw_id')->constrained('lucky_draws')->cascadeOnDelete();
            $table->integer('quantity')->default(1);
            $table->decimal('total_paid', 15, 2)->default(0);
            $table->boolean('is_winner')->default(false);
            $table->decimal('prize_won', 15, 2)->default(0);
            $table->timestamps();
        });

        // Topshiriqlar (Tasks)
        Schema::create('tasks', function (Blueprint $table) {
            $table->id();
            $table->json('title')->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->json('description')->nullable()->comment('Translatable description');
            $table->string('link')->nullable()->comment('Task URL (YouTube, Telegram...)');
            $table->string('platform', 30)->nullable()->comment('youtube, telegram, instagram...');
            $table->decimal('reward', 15, 2)->default(0)->comment('Task reward');
            $table->integer('required_package_level')->default(0)->comment('Minimum package required');
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // Foydalanuvchi bajargan topshiriqlar
        Schema::create('user_tasks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('task_id')->constrained('tasks')->cascadeOnDelete();
            $table->string('proof')->nullable()->comment('Screenshot or URL proof');
            $table->enum('status', ['pending', 'approved', 'rejected'])->default('pending');
            $table->timestamps();

            $table->unique(['user_id', 'task_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_tasks');
        Schema::dropIfExists('tasks');
        Schema::dropIfExists('lucky_draw_tickets');
        Schema::dropIfExists('lucky_draws');
        Schema::dropIfExists('check_ins');
    }
};
