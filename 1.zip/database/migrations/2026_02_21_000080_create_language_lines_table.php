<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // UI tarjimalari: buttonlar, labellar, xatolik xabarlari, menyu va boshqalar
        Schema::create('language_lines', function (Blueprint $table) {
            $table->id();

            // Guruh: auth, buttons, validation, errors, navigation, messages, dashboard...
            $table->string('group', 60)->index()->comment('Namespace: auth, buttons, errors...');

            // Kalit: login, submit, required, password_min, welcome...
            $table->string('key', 120)->comment('Translation key. e.g. login, submit_button');

            // Tarjima matni har bir til uchun JSON
            // {"uz": "Kirish", "ru": "Войти", "en": "Login"}
            $table->jsonb('text')->comment('{"uz":"...", "ru":"...", "en":"..."}');

            $table->timestamps();

            // Group + Key kombinatsiyasi unique bo'lishi kerak
            $table->unique(['group', 'key']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('language_lines');
    }
};
