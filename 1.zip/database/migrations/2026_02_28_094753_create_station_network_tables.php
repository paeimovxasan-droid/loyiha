<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // 1. Zaryadlash stansiyalari (Zaryadlash uchun ob'ektlar)
        Schema::create('stations', function (Blueprint $table) {
            $table->id();
            $table->json('name')->comment('Stansiya nomi: {"uz":"...", "ru":"...", "en":"..."}');
            $table->json('address')->nullable()->comment('To\'liq manzil');
            $table->json('district')->nullable()->comment('Tuman');
            $table->decimal('latitude', 10, 8)->nullable();
            $table->decimal('longitude', 11, 8)->nullable();
            $table->integer('capacity_kw')->default(0)->comment('Umumiy quvvati kW');
            
            // Narxlanish
            $table->decimal('price_per_kw', 10, 2)->default(0)->comment('1 kVt uchun narx');
            $table->decimal('old_price_per_kw', 10, 2)->nullable()->comment('Eski narx (chegirma uchun)');
            
            // Holati
            $table->enum('status', ['active', 'inactive', 'maintenance'])->default('active');
            $table->boolean('has_discount')->default(false);
            $table->decimal('rating', 3, 2)->default(5.00);
            
            $table->timestamps();
        });

        // 2. Sevimlilar (Foydalanuvchi -> Stansiyalar)
        Schema::create('station_favorites', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('station_id')->constrained('stations')->cascadeOnDelete();
            $table->timestamps();
            
            $table->unique(['user_id', 'station_id']);
        });

        // 3. Foydalanuvchi elektromobillari
        Schema::create('electric_vehicles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('brand')->nullable()->comment('Tesla, BYD...');
            $table->string('model')->nullable()->comment('Model 3, Song Plus...');
            $table->string('license_plate', 50)->nullable()->comment('Davlat raqami');
            $table->integer('battery_capacity_kwh')->nullable()->comment('Batareya sig\'imi');
            $table->string('connector_type', 50)->nullable()->comment('GB/T, Type 2, CCS...');
            $table->boolean('is_default')->default(false);
            $table->timestamps();
        });

        // 4. Zaryadlash sessiyalari (tarix va joriylar)
        Schema::create('charging_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('station_id')->constrained('stations')->cascadeOnDelete();
            $table->foreignId('vehicle_id')->nullable()->constrained('electric_vehicles')->nullOnDelete();
            
            $table->timestamp('started_at')->nullable();
            $table->timestamp('ended_at')->nullable();
            
            $table->decimal('consumed_kw', 10, 2)->default(0)->comment('Sarflangan quvvat');
            $table->decimal('total_amount', 15, 2)->default(0)->comment('To\'lov summasi');
            
            $table->enum('status', ['active', 'completed', 'cancelled', 'failed'])->default('active');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('charging_sessions');
        Schema::dropIfExists('electric_vehicles');
        Schema::dropIfExists('station_favorites');
        Schema::dropIfExists('stations');
    }
};
