<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Quest (Kvestlar) tizimi
 * Foydalanuvchilar kvestlarni bajarib AIS va XP ishlaydi
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Kvestlar ─────────────────────────────────────────────────────────
        Schema::create('quests', function (Blueprint $table) {
            $table->id();
            $table->json('title')->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->json('description')->nullable();
            $table->string('icon', 10)->default('🎯')->comment('Emoji icon');
            $table->string('category', 50)->default('general')
                ->comment('general, social, investment, referral, daily');
            $table->enum('type', ['one_time', 'daily', 'weekly', 'repeatable'])
                ->default('one_time');

            // Talablar
            $table->string('requirement_type', 60)->nullable()
                ->comment('deposit_count, referral_count, purchase_count, checkin_streak, level_reach, transfer_count, task_complete...');
            $table->integer('requirement_value')->default(1)
                ->comment('Nechta/qancha bo\'lishi kerak');

            // Mukofot
            $table->decimal('reward_ais', 15, 4)->default(0)->comment('AIS mukofot');
            $table->decimal('reward_uzs', 15, 2)->default(0)->comment('UZS mukofot');
            $table->integer('reward_xp')->default(0)->comment('XP mukofot');
            $table->string('reward_badge', 50)->nullable()->comment('Maxsus badge');

            // Sozlamalar
            $table->integer('sort_order')->default(0);
            $table->integer('min_level')->default(0)->comment('Minimal daraja');
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamp('expires_at')->nullable()->comment('Muddatli kvestlar uchun');
            $table->timestamps();
        });

        // ── Foydalanuvchi kvestlari ───────────────────────────────────────────
        Schema::create('user_quests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('quest_id')->constrained('quests')->cascadeOnDelete();
            $table->integer('progress')->default(0)->comment('Joriy progress');
            $table->enum('status', ['in_progress', 'completed', 'claimed'])
                ->default('in_progress');
            $table->timestamp('completed_at')->nullable();
            $table->timestamp('claimed_at')->nullable();
            $table->timestamps();

            $table->unique(['user_id', 'quest_id']);
            $table->index(['user_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_quests');
        Schema::dropIfExists('quests');
    }
};
