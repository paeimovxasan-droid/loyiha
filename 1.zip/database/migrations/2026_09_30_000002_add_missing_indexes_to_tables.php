<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Barcha jadvallardagi katta masshtablash uchun yetishmayotgan index'lar.
     */
    public function up(): void
    {
        if (Schema::hasTable('users')) {
            Schema::table('users', function (Blueprint $table) {
                $table->index('status');
                $table->index('referred_by');
                // Telegram ID tezkor qidiruv uchun kerak bo'ladi (MiniApp login)
                if (Schema::hasColumn('users', 'telegram_id')) {
                    $table->index('telegram_id');
                }
            });
        }

        if (Schema::hasTable('ais_conversions')) {
            Schema::table('ais_conversions', function (Blueprint $table) {
                $table->index('status');
                $table->index('direction');
                $table->index('created_at');
            });
        }

        // Boshqa jadvallar uchun kelajakda (qaysi joyiga ehtiyoj tushsa) indekslar shu yerga yoziladi
    }

    public function down(): void
    {
        if (Schema::hasTable('users')) {
            Schema::table('users', function (Blueprint $table) {
                $table->dropIndex(['status']);
                $table->dropIndex(['referred_by']);
                if (Schema::hasColumn('users', 'telegram_id')) {
                    $table->dropIndex(['telegram_id']);
                }
            });
        }

        if (Schema::hasTable('ais_conversions')) {
            Schema::table('ais_conversions', function (Blueprint $table) {
                $table->dropIndex(['status']);
                $table->dropIndex(['direction']);
                $table->dropIndex(['created_at']);
            });
        }
    }
};
