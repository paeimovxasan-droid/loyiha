<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Settings jadvaliga Telegram bot va kanal sozlamalarini qo'shish
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            $table->string('telegram_bot_token')->nullable()->after('site_domain');
            $table->string('telegram_bot_username')->nullable()->after('telegram_bot_token');
            $table->string('telegram_channel_id')->nullable()->after('telegram_bot_username');
            $table->string('telegram_miniapp_url')->nullable()->after('telegram_channel_id');
            $table->boolean('telegram_auto_posts_enabled')->default(true)->after('telegram_miniapp_url');
            $table->string('telegram_webhook_secret')->nullable()->after('telegram_auto_posts_enabled');
        });
    }

    public function down(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            $table->dropColumn([
                'telegram_bot_token',
                'telegram_bot_username',
                'telegram_channel_id',
                'telegram_miniapp_url',
                'telegram_auto_posts_enabled',
                'telegram_webhook_secret',
            ]);
        });
    }
};
