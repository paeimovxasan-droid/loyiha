<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Video KYC tasdiqlash kodlari jadvali
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('video_kyc_codes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('code', 4);
            $table->dateTime('expires_at');
            $table->boolean('used')->default(false);
            $table->timestamps();

            $table->index('user_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('video_kyc_codes');
    }
};
