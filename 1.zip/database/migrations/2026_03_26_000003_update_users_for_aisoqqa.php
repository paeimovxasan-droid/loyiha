<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Users jadvaliga AISOQQA uchun qo'shimcha maydonlar
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // KYC
            $table->enum('kyc_status', ['none', 'pending', 'verified', 'rejected'])->default('none')->after('status');
            $table->string('kyc_document')->nullable()->after('kyc_status')->comment('Passport/ID fayl');
            $table->timestamp('kyc_verified_at')->nullable()->after('kyc_document');

            // 2FA
            $table->boolean('two_fa_enabled')->default(false)->after('kyc_verified_at');
            $table->string('two_fa_secret')->nullable()->after('two_fa_enabled');

            // Lider paneli
            $table->boolean('is_leader')->default(false)->after('two_fa_secret')->comment('Lider sifatida belgilangan');

            // Telegram
            $table->string('telegram_id')->nullable()->after('is_leader');
            $table->boolean('telegram_notifications')->default(false)->after('telegram_id');
        });

        // Settings jadvaliga AIS konfiguratsiyasi
        Schema::table('settings', function (Blueprint $table) {
            $table->string('site_currency', 10)->default('AIS')->after('currency');
            $table->decimal('ais_to_uzs_rate', 15, 2)->default(1000)->after('site_currency')->comment('1 AIS = ? UZS');
            $table->decimal('transfer_fee_percent', 5, 2)->default(0.5)->after('ais_to_uzs_rate')->comment('P2P transfer komissiyasi %');
            $table->decimal('conversion_fee_percent', 5, 2)->default(1.0)->after('transfer_fee_percent')->comment('Konvertatsiya komissiyasi %');
            $table->string('site_domain')->nullable()->after('site_currency');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'kyc_status', 'kyc_document', 'kyc_verified_at',
                'two_fa_enabled', 'two_fa_secret',
                'is_leader', 'telegram_id', 'telegram_notifications',
            ]);
        });

        Schema::table('settings', function (Blueprint $table) {
            $table->dropColumn([
                'site_currency', 'ais_to_uzs_rate',
                'transfer_fee_percent', 'conversion_fee_percent', 'site_domain',
            ]);
        });
    }
};
