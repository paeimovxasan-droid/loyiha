<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('user_onboardings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->unique()->constrained('users')->cascadeOnDelete();
            $table->integer('current_step')->default(1);
            $table->boolean('step_1_completed')->default(false);
            $table->timestamp('step_1_completed_at')->nullable();
            $table->boolean('step_2_completed')->default(false);
            $table->timestamp('step_2_completed_at')->nullable();
            $table->boolean('step_3_completed')->default(false);
            $table->timestamp('step_3_completed_at')->nullable();
            $table->boolean('step_4_completed')->default(false);
            $table->timestamp('step_4_completed_at')->nullable();
            $table->boolean('step_5_completed')->default(false);
            $table->timestamp('step_5_completed_at')->nullable();
            $table->boolean('bonus_claimed')->default(false);
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_onboardings');
    }
};
