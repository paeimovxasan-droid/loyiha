<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('seasonal_events', function (Blueprint $table) {
            $table->id();
            $table->json('name')->comment('Translatable: uz, ru, en');
            $table->json('description')->nullable()->comment('Translatable: uz, ru, en');
            $table->string('banner')->nullable();
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();
            $table->json('prizes')->comment('[{rank: 1, ais: 200}, ...]');
            $table->enum('status', ['draft', 'active', 'finalized'])->default('draft');
            $table->timestamps();
        });

        Schema::create('seasonal_event_quests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('event_id')->constrained('seasonal_events')->cascadeOnDelete();
            $table->foreignId('quest_id')->constrained('quests')->cascadeOnDelete();
            $table->integer('sort_order')->default(0);
            $table->timestamp('created_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('seasonal_event_quests');
        Schema::dropIfExists('seasonal_events');
    }
};
