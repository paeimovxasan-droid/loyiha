<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('assets', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description');
            $table->decimal('total_value', 16, 4);
            $table->integer('total_tokens');
            $table->integer('available_tokens');
            $table->decimal('token_price', 16, 4);
            $table->enum('status', ['active', 'sold_out', 'closed'])->default('active');
            $table->timestamps();

            $table->index(['status']);
        });

        Schema::create('asset_tokens', function (Blueprint $table) {
            $table->id();
            $table->foreignId('asset_id')->constrained('assets')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->integer('quantity');
            $table->timestamps();

            $table->unique(['asset_id', 'user_id']);
        });

        Schema::create('token_purchases', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('asset_id')->constrained('assets')->cascadeOnDelete();
            $table->integer('quantity');
            $table->decimal('total_price', 16, 4);
            $table->timestamps();

            $table->index(['user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('token_purchases');
        Schema::dropIfExists('asset_tokens');
        Schema::dropIfExists('assets');
    }
};
