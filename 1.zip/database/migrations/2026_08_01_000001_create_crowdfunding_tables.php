<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('cf_projects', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('title');
            $table->text('description');
            $table->enum('category', ['kocha_tamiri', 'maktab_jihozlash', 'kasb_orgatish']);
            $table->decimal('goal_amount', 16, 4);
            $table->decimal('collected_amount', 16, 4)->default(0);
            $table->enum('status', ['pending', 'active', 'rejected', 'funded', 'expired'])->default('pending');
            $table->text('rejection_reason')->nullable();
            $table->dateTime('expires_at');
            $table->timestamps();

            $table->index(['status']);
            $table->index(['category']);
        });

        Schema::create('cf_donations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('cf_project_id')->constrained('cf_projects')->cascadeOnDelete();
            $table->decimal('amount', 16, 4);
            $table->timestamps();

            $table->index(['cf_project_id']);
            $table->index(['user_id']);
        });

        Schema::create('cf_expenses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('cf_project_id')->constrained('cf_projects')->cascadeOnDelete();
            $table->decimal('amount', 16, 4);
            $table->string('description');
            $table->date('spent_at')->nullable();
            $table->timestamps();

            $table->index(['cf_project_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('cf_expenses');
        Schema::dropIfExists('cf_donations');
        Schema::dropIfExists('cf_projects');
    }
};
