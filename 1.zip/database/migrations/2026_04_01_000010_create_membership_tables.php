<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('membership_tiers', function (Blueprint $table) {
            $table->id();
            $table->enum('tier', ['free', 'silver', 'gold', 'platinum'])->unique();
            $table->decimal('min_ais_earned', 12, 4)->default(0);
            $table->integer('min_referrals')->default(0);
            $table->decimal('cashback_percent', 5, 2)->default(0);
            $table->decimal('fee_discount_percent', 5, 2)->default(0);
            $table->boolean('has_special_quests')->default(false);
            $table->boolean('has_personal_manager')->default(false);
            $table->timestamps();
        });

        Schema::create('user_memberships', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->unique()->constrained('users')->cascadeOnDelete();
            $table->enum('tier', ['free', 'silver', 'gold', 'platinum'])->default('free');
            $table->decimal('total_ais_earned', 12, 4)->default(0);
            $table->integer('total_referrals')->default(0);
            $table->timestamp('upgraded_at')->nullable();
            $table->timestamp('grace_until')->nullable();
            $table->timestamps();
        });

        Schema::create('membership_history', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('from_tier');
            $table->string('to_tier');
            $table->enum('reason', ['upgrade', 'downgrade', 'manual']);
            $table->timestamp('created_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('membership_history');
        Schema::dropIfExists('user_memberships');
        Schema::dropIfExists('membership_tiers');
    }
};
