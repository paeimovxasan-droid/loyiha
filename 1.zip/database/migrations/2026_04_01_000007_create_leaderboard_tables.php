<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('leaderboard_competitions', function (Blueprint $table) {
            $table->id();
            $table->enum('period', ['weekly', 'monthly']);
            $table->enum('type', ['referral', 'ais_earned', 'xp']);
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();
            $table->enum('status', ['active', 'finalized'])->default('active');
            $table->json('prizes')->comment('[{rank: 1, ais: 50}, ...]');
            $table->timestamps();
        });

        Schema::create('leaderboard_entries', function (Blueprint $table) {
            $table->id();
            $table->foreignId('competition_id')->constrained('leaderboard_competitions')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->decimal('score', 12, 4)->default(0);
            $table->integer('rank')->nullable();
            $table->decimal('prize_ais', 10, 4)->nullable();
            $table->timestamps();

            $table->unique(['competition_id', 'user_id']);
            $table->index(['competition_id', 'score']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('leaderboard_entries');
        Schema::dropIfExists('leaderboard_competitions');
    }
};
