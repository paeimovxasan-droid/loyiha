<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Telegram kanal postlari tarixi jadvali
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('channel_posts', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['daily_stats', 'rate_update', 'new_product', 'weekly_leaderboard', 'milestone', 'custom']);
            $table->text('content');
            $table->string('photo')->nullable();
            $table->string('telegram_message_id')->nullable();
            $table->dateTime('sent_at')->nullable();
            $table->enum('status', ['pending', 'sent', 'failed'])->default('pending');
            $table->foreignId('created_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('channel_posts');
    }
};
