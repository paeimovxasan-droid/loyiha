<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Investitsiya fondlari
        Schema::create('funds', function (Blueprint $table) {
            $table->id();
            $table->json('name')->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->json('description')->nullable()->comment('Translatable description');
            $table->decimal('commission_percent', 8, 2)->comment('Profit %');
            $table->integer('validity_days')->comment('Fund validity in days');
            $table->decimal('min_invest', 15, 2)->default(0)->comment('Minimum investment');
            $table->string('photo')->nullable();
            $table->enum('status', ['upcoming', 'active', 'closed'])->default('active');
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // Foydalanuvchi fond investitsiyalari
        Schema::create('fund_invests', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('fund_id')->constrained('funds')->cascadeOnDelete();
            $table->decimal('amount', 15, 2)->default(0)->comment('Invested amount');
            $table->decimal('expected_profit', 15, 2)->default(0);
            $table->date('started_at')->nullable();
            $table->date('expires_at')->nullable();
            $table->enum('status', ['active', 'matured', 'cancelled'])->default('active');
            $table->timestamps();
        });

        // Qayta investitsiya sozlamalari (Improvments)
        Schema::create('reinvest_settings', function (Blueprint $table) {
            $table->id();
            $table->decimal('amount_limit', 15, 2)->default(0)->comment('Balance limit for reinvestment');
            $table->integer('daily_percent')->default(1)->comment('Base daily profit %');
            $table->integer('ref_level1_percent')->default(1);
            $table->integer('ref_level2_percent')->default(1);
            $table->integer('ref_level3_percent')->default(1);
            $table->integer('ref_level4_percent')->default(1);
            $table->integer('ref_level5_percent')->default(1);
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();
        });

        // Rebate (ikkilamchi komissiya tuzilmasi)
        Schema::create('rebates', function (Blueprint $table) {
            $table->id();
            $table->json('name')->nullable()->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->decimal('team_commission1', 8, 2)->default(0)->comment('Team Level 1 %');
            $table->decimal('team_commission2', 8, 2)->default(0)->comment('Team Level 2 %');
            $table->decimal('team_commission3', 8, 2)->default(0)->comment('Team Level 3 %');
            $table->decimal('interest_rate1', 8, 2)->default(0)->comment('Interest Level 1 %');
            $table->decimal('interest_rate2', 8, 2)->default(0)->comment('Interest Level 2 %');
            $table->decimal('interest_rate3', 8, 2)->default(0)->comment('Interest Level 3 %');
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('rebates');
        Schema::dropIfExists('reinvest_settings');
        Schema::dropIfExists('fund_invests');
        Schema::dropIfExists('funds');
    }
};
