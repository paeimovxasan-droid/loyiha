<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('share_links', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->unique()->constrained('users')->cascadeOnDelete();
            $table->string('code', 12)->unique();
            $table->integer('total_clicks')->default(0);
            $table->decimal('total_earned_ais', 10, 4)->default(0);
            $table->timestamps();
        });

        Schema::create('share_clicks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('share_link_id')->constrained('share_links')->cascadeOnDelete();
            $table->string('ip_address', 45);
            $table->string('user_agent')->nullable();
            $table->timestamp('clicked_at')->nullable();
            $table->timestamp('created_at')->nullable();

            $table->index(['share_link_id', 'ip_address', 'clicked_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('share_clicks');
        Schema::dropIfExists('share_links');
    }
};
