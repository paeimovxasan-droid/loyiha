<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('roadmap_modules', function (Blueprint $table) {
            $table->id();
            $table->string('title', 255);
            $table->text('description');
            $table->string('icon', 255)->nullable();
            $table->enum('status', ['coming_soon', 'in_progress', 'beta', 'released'])->default('coming_soon');
            $table->integer('sort_order')->default(0);
            $table->date('estimated_date')->nullable();
            $table->string('banner_image', 255)->nullable();
            $table->unsignedTinyInteger('progress_percent')->nullable();
            $table->unsignedInteger('votes_count')->default(0);
            $table->timestamps();
            $table->softDeletes();

            $table->index('status', 'idx_status');
            $table->index('sort_order', 'idx_sort_order');
        });

        Schema::create('roadmap_votes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('roadmap_module_id')->constrained('roadmap_modules')->cascadeOnDelete();
            $table->timestamp('created_at')->nullable();

            $table->unique(['user_id', 'roadmap_module_id'], 'uniq_user_module');
        });

        Schema::create('roadmap_notifications', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('roadmap_module_id')->constrained('roadmap_modules')->cascadeOnDelete();
            $table->timestamp('notified_at')->nullable();
            $table->timestamp('created_at')->nullable();

            $table->unique(['user_id', 'roadmap_module_id'], 'uniq_user_module_notify');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('roadmap_notifications');
        Schema::dropIfExists('roadmap_votes');
        Schema::dropIfExists('roadmap_modules');
    }
};
