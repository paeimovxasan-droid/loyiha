<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Paketlar (investitsiya rejalari)
        Schema::create('packages', function (Blueprint $table) {
            $table->id();
            $table->json('name')->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->string('photo')->nullable();
            $table->decimal('price', 15, 2)->comment('Minimum investment amount');
            $table->uuid('code')->unique()->comment('Unique package code');
            $table->integer('validity_days')->comment('Package validity in days');
            $table->decimal('daily_profit_percent', 8, 2)->default(0)->comment('Daily profit %');
            $table->decimal('total_profit_percent', 8, 2)->default(0)->comment('Total profit % over validity');
            $table->decimal('sponsor_income', 8, 2)->default(0)->comment('Sponsor bonus %');
            // Referral commissions per level
            $table->decimal('ref_level1', 8, 2)->default(0)->comment('Level 1 referral %');
            $table->decimal('ref_level2', 8, 2)->default(0)->comment('Level 2 referral %');
            $table->decimal('ref_level3', 8, 2)->default(0)->comment('Level 3 referral %');
            $table->boolean('is_default')->default(false)->comment('Default free package');
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // Foydalanuvchi package xaridlari
        Schema::create('purchases', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('package_id')->constrained('packages')->cascadeOnDelete();
            $table->decimal('amount', 15, 2)->default(0)->comment('Paid amount');
            $table->date('started_at')->nullable()->comment('Package start date');
            $table->date('expires_at')->nullable()->comment('Package expiry date');
            $table->text('note')->nullable();
            $table->enum('status', ['pending', 'active', 'expired', 'cancelled'])->default('pending');
            $table->timestamps();
        });

        // Mining (paket ishlash jarayoni)
        Schema::create('minings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('package_id')->constrained('packages')->cascadeOnDelete();
            $table->foreignId('purchase_id')->constrained('purchases')->cascadeOnDelete();
            $table->timestamp('started_at')->nullable();
            $table->timestamp('ended_at')->nullable();
            $table->integer('total_hours')->default(0)->comment('Total validity in hours');
            $table->integer('completed_hours')->default(0)->comment('Hours completed');
            $table->decimal('hourly_profit', 15, 4)->default(0)->comment('Profit per hour');
            $table->decimal('daily_profit', 15, 2)->default(0)->comment('Profit per day');
            $table->decimal('total_earned', 15, 2)->default(0)->comment('Total earned so far');
            $table->enum('status', ['running', 'paused', 'completed', 'cancelled'])->default('running');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('minings');
        Schema::dropIfExists('purchases');
        Schema::dropIfExists('packages');
    }
};
