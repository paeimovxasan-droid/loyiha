<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            $table->dropColumn(['logo', 'favicon']);
            $table->foreignId('logo_id')->nullable()->constrained('files')->nullOnDelete();
            $table->foreignId('favicon_id')->nullable()->constrained('files')->nullOnDelete();
        });

        Schema::table('payment_methods', function (Blueprint $table) {
            $table->dropColumn('photo');
            $table->foreignId('photo_id')->nullable()->constrained('files')->nullOnDelete();
        });

        Schema::table('packages', function (Blueprint $table) {
            $table->dropColumn('photo');
            $table->foreignId('photo_id')->nullable()->constrained('files')->nullOnDelete();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('settings', function (Blueprint $table) {
            $table->dropForeign(['logo_id']);
            $table->dropForeign(['favicon_id']);
            $table->dropColumn(['logo_id', 'favicon_id']);
            $table->string('logo')->nullable();
            $table->string('favicon')->nullable();
        });

        Schema::table('payment_methods', function (Blueprint $table) {
            $table->dropForeign(['photo_id']);
            $table->dropColumn('photo_id');
            $table->string('photo')->nullable();
        });

        Schema::table('packages', function (Blueprint $table) {
            $table->dropForeign(['photo_id']);
            $table->dropColumn('photo_id');
            $table->string('photo')->nullable();
        });
    }
};
