<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('spin_wheel_prizes', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['ais', 'xp', 'lucky_ticket', 'nothing']);
            $table->decimal('value', 10, 4)->default(0);
            $table->json('label')->comment('Translatable: uz, ru, en');
            $table->integer('weight')->default(1)->comment('Probability weight');
            $table->string('color', 7)->default('#3b82f6');
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();
        });

        Schema::create('spin_wheel_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('spin_wheel_prize_id')->constrained('spin_wheel_prizes')->cascadeOnDelete();
            $table->string('prize_type');
            $table->decimal('prize_value', 10, 4)->default(0);
            $table->date('spun_at')->nullable();
            $table->timestamp('created_at')->nullable();

            $table->index(['user_id', 'spun_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('spin_wheel_logs');
        Schema::dropIfExists('spin_wheel_prizes');
    }
};
