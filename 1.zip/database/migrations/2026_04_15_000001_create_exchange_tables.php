<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // exchange_orders
        Schema::create('exchange_orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('reference', 16)->unique();
            $table->enum('type', ['limit', 'market']);
            $table->enum('side', ['buy', 'sell']);
            $table->decimal('price', 15, 2)->nullable();
            $table->decimal('amount', 15, 4);
            $table->decimal('filled_amount', 15, 4)->default(0);
            $table->decimal('remaining_amount', 15, 4);
            $table->decimal('avg_fill_price', 15, 2)->nullable();
            $table->decimal('total_fee', 15, 4)->default(0);
            $table->decimal('frozen_amount', 15, 4)->default(0);
            $table->enum('status', ['open', 'partially_filled', 'filled', 'cancelled'])->default('open');
            $table->timestamps();

            $table->index(['user_id', 'status']);
            $table->index(['side', 'status', 'price', 'created_at']);
            $table->index(['status', 'created_at']);
        });

        // exchange_trades
        Schema::create('exchange_trades', function (Blueprint $table) {
            $table->id();
            $table->foreignId('buy_order_id')->constrained('exchange_orders')->cascadeOnDelete();
            $table->foreignId('sell_order_id')->constrained('exchange_orders')->cascadeOnDelete();
            $table->foreignId('buyer_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('seller_id')->constrained('users')->cascadeOnDelete();
            $table->decimal('price', 15, 2);
            $table->decimal('amount', 15, 4);
            $table->decimal('total', 15, 2);
            $table->decimal('buyer_fee', 15, 4);
            $table->decimal('seller_fee', 15, 4);
            $table->enum('buyer_role', ['maker', 'taker']);
            $table->enum('seller_role', ['maker', 'taker']);
            $table->timestamp('created_at')->useCurrent();

            $table->index(['buyer_id', 'created_at']);
            $table->index(['seller_id', 'created_at']);
            $table->index('created_at');
        });

        // exchange_settings
        Schema::create('exchange_settings', function (Blueprint $table) {
            $table->id();
            $table->string('key', 50)->unique();
            $table->string('value');
            $table->timestamp('updated_at')->nullable();
        });

        // ohlcv_candles
        Schema::create('ohlcv_candles', function (Blueprint $table) {
            $table->id();
            $table->enum('interval', ['1h', '1d', '1w', '1M']);
            $table->dateTime('open_time');
            $table->decimal('open', 15, 2);
            $table->decimal('high', 15, 2);
            $table->decimal('low', 15, 2);
            $table->decimal('close', 15, 2);
            $table->decimal('volume', 20, 4);
            $table->decimal('volume_uzs', 20, 2);
            $table->integer('trade_count')->default(0);
            $table->timestamps();

            $table->unique(['interval', 'open_time']);
            $table->index(['interval', 'open_time']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ohlcv_candles');
        Schema::dropIfExists('exchange_trades');
        Schema::dropIfExists('exchange_orders');
        Schema::dropIfExists('exchange_settings');
    }
};
