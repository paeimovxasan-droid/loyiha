<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('invite_challenges', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->integer('target_referrals')->default(7);
            $table->integer('current_referrals')->default(0);
            $table->decimal('reward_ais', 10, 4)->default(100);
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();
            $table->enum('status', ['active', 'completed', 'failed', 'expired'])->default('active');
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();
        });

        Schema::create('invite_challenge_settings', function (Blueprint $table) {
            $table->id();
            $table->integer('duration_days')->default(7);
            $table->integer('target_referrals')->default(7);
            $table->decimal('reward_ais', 10, 4)->default(100);
            $table->boolean('min_deposit_required')->default(true);
            $table->timestamp('updated_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('invite_challenge_settings');
        Schema::dropIfExists('invite_challenges');
    }
};
