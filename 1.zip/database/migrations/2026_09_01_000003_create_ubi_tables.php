<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ubi_settings', function (Blueprint $table) {
            $table->id();
            $table->decimal('daily_amount', 16, 4)->default(1.0000);
            $table->boolean('is_active')->default(true);
            $table->integer('min_level')->default(0);
            $table->timestamps();
        });

        Schema::create('ubi_claims', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->decimal('amount', 16, 4);
            $table->date('claimed_at')->nullable();
            $table->timestamps();

            $table->unique(['user_id', 'claimed_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ubi_claims');
        Schema::dropIfExists('ubi_settings');
    }
};
