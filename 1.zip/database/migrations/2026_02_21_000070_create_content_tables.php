<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // Kontentni boshqarish - Bannerlar
        Schema::create('banners', function (Blueprint $table) {
            $table->id();
            $table->string('image');
            $table->string('link')->nullable();
            $table->string('position', 30)->default('home_top')->comment('home_top, home_mid, sidebar...');
            $table->integer('sort_order')->default(0);
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();
        });

        // Sayt bo'limlari (Sections) - eski jadvallar birlashtirildi
        Schema::create('page_sections', function (Blueprint $table) {
            $table->id();
            $table->string('section_key', 50)->comment('hero, about, features, how_it_works, testimonials...');
            $table->string('page', 30)->default('home')->comment('home, about, contact...');
            $table->json('title')->nullable()->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->json('subtitle')->nullable();
            $table->json('content')->nullable()->comment('Rich text content - translatable');
            $table->string('image')->nullable();
            $table->string('button_text')->nullable()->comment('CTA button text');
            $table->string('button_link')->nullable();
            $table->json('extra_data')->nullable()->comment('Additional metadata as JSON');
            $table->integer('sort_order')->default(0);
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();

            $table->unique(['section_key', 'page']);
        });

        // VIP Sliderlar
        Schema::create('sliders', function (Blueprint $table) {
            $table->id();
            $table->json('title')->nullable()->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->json('subtitle')->nullable();
            $table->string('image');
            $table->string('link')->nullable();
            $table->string('position', 30)->default('vip')->comment('vip, home, notice...');
            $table->integer('sort_order')->default(0);
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();
        });

        // E'lonlar/Xabarlar
        Schema::create('notices', function (Blueprint $table) {
            $table->id();
            $table->json('title')->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->json('content')->nullable()->comment('Translatable notice body');
            $table->string('type', 20)->default('info')->comment('info, warning, success, danger');
            $table->boolean('is_popup')->default(false)->comment('Show as popup on homepage?');
            $table->timestamp('published_at')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();
        });

        // Ikonalar (icons JSON dan bitta jadval - flexible)
        Schema::create('icon_settings', function (Blueprint $table) {
            $table->id();
            $table->string('key', 60)->unique()->comment('recharge, withdraw, invitation, team...');
            $table->string('icon_path')->comment('Image path or base64');
            $table->string('label')->nullable();
            $table->json('meta')->nullable()->comment('Banner images, labels etc');
            $table->timestamps();
        });

        // Ko'p so'raladigan savollar (FAQ)
        Schema::create('faqs', function (Blueprint $table) {
            $table->id();
            $table->json('question')->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->json('answer')->comment('Translatable answer');
            $table->string('category', 50)->nullable()->comment('general, payment, account...');
            $table->integer('sort_order')->default(0);
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('faqs');
        Schema::dropIfExists('icon_settings');
        Schema::dropIfExists('notices');
        Schema::dropIfExists('sliders');
        Schema::dropIfExists('page_sections');
        Schema::dropIfExists('banners');
    }
};
