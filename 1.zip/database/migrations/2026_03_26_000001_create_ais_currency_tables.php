<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * AIS — AISOQQA ichki valyuta tizimi
 * 1 AIS = X UZS (kurs admin tomonidan belgilanadi)
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── AIS kurs tarixi ──────────────────────────────────────────────────
        Schema::create('ais_rates', function (Blueprint $table) {
            $table->id();
            $table->decimal('rate_uzs', 15, 2)->comment('1 AIS = ? UZS');
            $table->decimal('buy_rate', 15, 2)->comment('UZS → AIS (foydalanuvchi sotib oladi)');
            $table->decimal('sell_rate', 15, 2)->comment('AIS → UZS (foydalanuvchi sotadi)');
            $table->foreignId('set_by')->nullable()->constrained('users')->nullOnDelete();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Hamyon (Wallet) ──────────────────────────────────────────────────
        Schema::create('wallets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->unique()->constrained('users')->cascadeOnDelete();
            $table->string('wallet_number', 20)->unique()->comment('AIS-XXXX-XXXX-XXXX');
            $table->decimal('balance', 20, 4)->default(0)->comment('AIS balance');
            $table->decimal('frozen_balance', 20, 4)->default(0)->comment('Muzlatilgan AIS');
            $table->boolean('is_frozen')->default(false);
            $table->timestamps();
        });

        // ── Virtual karta ────────────────────────────────────────────────────
        Schema::create('virtual_cards', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('wallet_id')->constrained('wallets')->cascadeOnDelete();
            $table->string('card_number', 19)->unique()->comment('XXXX XXXX XXXX XXXX');
            $table->string('card_holder')->comment('Karta egasi ismi');
            $table->string('expiry_month', 2);
            $table->string('expiry_year', 4);
            $table->string('cvv_hash')->comment('Hashed CVV');
            $table->decimal('daily_limit', 20, 4)->default(10000)->comment('Kunlik limit (AIS)');
            $table->decimal('monthly_limit', 20, 4)->default(100000)->comment('Oylik limit (AIS)');
            $table->enum('status', ['active', 'frozen', 'expired', 'cancelled'])->default('active');
            $table->timestamps();
        });

        // ── P2P Transfer (AIS → AIS) ─────────────────────────────────────────
        Schema::create('ais_transfers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('sender_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('receiver_id')->constrained('users')->cascadeOnDelete();
            $table->decimal('amount', 20, 4)->comment('AIS miqdori');
            $table->decimal('fee', 20, 4)->default(0)->comment('Transfer komissiyasi (AIS)');
            $table->string('note', 255)->nullable()->comment('Izoh');
            $table->string('reference', 32)->unique()->comment('Unikal transfer ID');
            $table->enum('status', ['pending', 'completed', 'failed', 'reversed'])->default('completed');
            $table->timestamps();

            $table->index(['sender_id', 'created_at']);
            $table->index(['receiver_id', 'created_at']);
        });

        // ── AIS konvertatsiya (UZS ↔ AIS) ───────────────────────────────────
        Schema::create('ais_conversions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('rate_id')->constrained('ais_rates')->cascadeOnDelete();
            $table->enum('direction', ['buy', 'sell'])->comment('buy=UZS→AIS, sell=AIS→UZS');
            $table->decimal('uzs_amount', 20, 2)->comment('UZS miqdori');
            $table->decimal('ais_amount', 20, 4)->comment('AIS miqdori');
            $table->decimal('rate_used', 15, 2)->comment('Ishlatilgan kurs');
            $table->decimal('fee', 20, 4)->default(0)->comment('Konvertatsiya komissiyasi');
            $table->enum('status', ['completed', 'failed'])->default('completed');
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ais_conversions');
        Schema::dropIfExists('ais_transfers');
        Schema::dropIfExists('virtual_cards');
        Schema::dropIfExists('wallets');
        Schema::dropIfExists('ais_rates');
    }
};
