<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // courses
        Schema::create('courses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('title', 255);
            $table->text('description');
            $table->decimal('price', 12, 4);
            $table->string('category', 100);
            $table->string('thumbnail')->nullable();
            $table->enum('status', ['draft', 'published'])->default('draft');
            $table->integer('total_lessons')->default(0);
            $table->integer('total_duration')->default(0);
            $table->timestamps();

            $table->index('category');
            $table->index('status');
            $table->index('user_id');
        });

        // course_lessons
        Schema::create('course_lessons', function (Blueprint $table) {
            $table->id();
            $table->foreignId('course_id')->constrained('courses')->cascadeOnDelete();
            $table->string('title', 255);
            $table->string('video_url', 500);
            $table->integer('duration_minutes');
            $table->integer('sort_order');
            $table->timestamps();

            $table->index(['course_id', 'sort_order']);
        });

        // course_purchases
        Schema::create('course_purchases', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('course_id')->constrained('courses')->cascadeOnDelete();
            $table->decimal('amount', 12, 4);
            $table->decimal('instructor_share', 12, 4);
            $table->decimal('platform_fee', 12, 4);
            $table->timestamp('created_at')->useCurrent();

            $table->unique(['user_id', 'course_id']);
        });

        // course_progress
        Schema::create('course_progress', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('course_id')->constrained('courses')->cascadeOnDelete();
            $table->foreignId('lesson_id')->constrained('course_lessons')->cascadeOnDelete();
            $table->timestamp('completed_at')->useCurrent();

            $table->unique(['user_id', 'lesson_id']);
            $table->index(['user_id', 'course_id']);
        });

        // certificates
        Schema::create('certificates', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('course_id')->constrained('courses')->cascadeOnDelete();
            $table->string('code', 32)->unique();
            $table->timestamp('issued_at')->useCurrent();
            $table->timestamps();

            $table->unique(['user_id', 'course_id']);
        });

        // mentor_profiles
        Schema::create('mentor_profiles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->unique()->constrained('users')->cascadeOnDelete();
            $table->string('expertise', 255);
            $table->text('bio');
            $table->decimal('hourly_rate', 12, 4);
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index('expertise');
            $table->index('is_active');
        });

        // mentor_sessions
        Schema::create('mentor_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('mentor_profile_id')->constrained('mentor_profiles')->cascadeOnDelete();
            $table->foreignId('student_id')->constrained('users')->cascadeOnDelete();
            $table->integer('hours');
            $table->decimal('total_amount', 12, 4);
            $table->decimal('mentor_share', 12, 4);
            $table->decimal('platform_fee', 12, 4);
            $table->text('message')->nullable();
            $table->enum('status', ['paid', 'accepted', 'completed', 'cancelled'])->default('paid');
            $table->timestamps();

            $table->index('mentor_profile_id');
            $table->index('student_id');
            $table->index('status');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('mentor_sessions');
        Schema::dropIfExists('mentor_profiles');
        Schema::dropIfExists('certificates');
        Schema::dropIfExists('course_progress');
        Schema::dropIfExists('course_purchases');
        Schema::dropIfExists('course_lessons');
        Schema::dropIfExists('courses');
    }
};
