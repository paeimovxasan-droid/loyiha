<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('translations', function (Blueprint $table) {
            $table->id();
            $table->string('group')->nullable()->index(); // 'errors', 'auth', 'buttons', 'messages' ...
            $table->string('key');                        // 'login_failed', 'save', 'success' ...
            $table->json('text');                         // {"uz": "...", "ru": "...", "en": "..."}
            $table->timestamps();

            $table->unique(['group', 'key']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('translations');
    }
};
