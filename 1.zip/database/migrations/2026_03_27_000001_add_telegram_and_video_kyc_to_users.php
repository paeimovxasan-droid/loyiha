<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Users jadvaliga Telegram profil va Video KYC maydonlarini qo'shish
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Telegram profil ma'lumotlari
            $table->string('telegram_first_name')->nullable()->after('telegram_notifications');
            $table->string('telegram_last_name')->nullable()->after('telegram_first_name');
            $table->string('telegram_username')->nullable()->after('telegram_last_name');
            $table->string('telegram_photo_url')->nullable()->after('telegram_username');

            // Video KYC maydonlari
            $table->enum('kyc_type', ['photo', 'video'])->nullable()->after('kyc_verified_at');
            $table->string('kyc_video')->nullable()->after('kyc_type');
            $table->text('kyc_rejection_reason')->nullable()->after('kyc_video');
        });

        // kyc_status enumiga 'video_pending' qo'shish
        DB::statement("ALTER TABLE users MODIFY COLUMN kyc_status ENUM('none','pending','video_pending','verified','rejected') DEFAULT 'none'");
    }

    public function down(): void
    {
        // kyc_status enumini asl holatiga qaytarish
        DB::statement("ALTER TABLE users MODIFY COLUMN kyc_status ENUM('none','pending','verified','rejected') DEFAULT 'none'");

        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'telegram_first_name',
                'telegram_last_name',
                'telegram_username',
                'telegram_photo_url',
                'kyc_type',
                'kyc_video',
                'kyc_rejection_reason',
            ]);
        });
    }
};
