<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('loan_offers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('lender_id')->constrained('users')->cascadeOnDelete();
            $table->decimal('amount', 16, 4);
            $table->decimal('interest_rate', 5, 2);
            $table->integer('duration_days');
            $table->text('description')->nullable();
            $table->enum('status', ['active', 'taken', 'cancelled', 'expired'])->default('active');
            $table->timestamps();

            $table->index(['status']);
        });

        Schema::create('loans', function (Blueprint $table) {
            $table->id();
            $table->foreignId('loan_offer_id')->constrained('loan_offers')->cascadeOnDelete();
            $table->foreignId('lender_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('borrower_id')->constrained('users')->cascadeOnDelete();
            $table->decimal('amount', 16, 4);
            $table->decimal('interest_rate', 5, 2);
            $table->decimal('total_due', 16, 4);
            $table->decimal('total_paid', 16, 4)->default(0);
            $table->enum('status', ['active', 'completed', 'defaulted'])->default('active');
            $table->date('due_date')->nullable();
            $table->timestamps();

            $table->index(['borrower_id', 'status']);
            $table->index(['lender_id', 'status']);
        });

        Schema::create('loan_payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('loan_id')->constrained('loans')->cascadeOnDelete();
            $table->decimal('amount', 16, 4);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('loan_payments');
        Schema::dropIfExists('loans');
        Schema::dropIfExists('loan_offers');
    }
};
