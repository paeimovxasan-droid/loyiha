<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // gig_categories
        Schema::create('gig_categories', function (Blueprint $table) {
            $table->id();
            $table->json('name')->comment('Translatable: uz, ru, en');
            $table->string('slug')->unique();
            $table->string('icon')->nullable();
            $table->integer('sort_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // gigs
        Schema::create('gigs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('category_id')->constrained('gig_categories')->cascadeOnDelete();
            $table->string('title', 255);
            $table->text('description');
            $table->decimal('price', 16, 4);
            $table->integer('delivery_days');
            $table->enum('status', ['active', 'paused', 'deleted'])->default('active');
            $table->decimal('avg_rating', 3, 2)->default(0);
            $table->integer('total_reviews')->default(0);
            $table->integer('total_orders')->default(0);
            $table->timestamps();

            $table->index('user_id');
            $table->index(['category_id', 'status']);
            $table->index(['status', 'avg_rating']);
            $table->fullText('title');
        });

        // gig_orders
        Schema::create('gig_orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('gig_id')->constrained('gigs')->cascadeOnDelete();
            $table->foreignId('buyer_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('seller_id')->constrained('users')->cascadeOnDelete();
            $table->decimal('amount', 16, 4);
            $table->decimal('commission_rate', 5, 2);
            $table->decimal('commission_amount', 16, 4);
            $table->decimal('seller_amount', 16, 4);
            $table->enum('status', ['pending', 'in_progress', 'delivered', 'completed', 'rejected', 'disputed'])->default('pending');
            $table->timestamp('delivered_at')->nullable();
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();

            $table->index(['buyer_id', 'status']);
            $table->index(['seller_id', 'status']);
            $table->index('gig_id');
        });

        // gig_reviews
        Schema::create('gig_reviews', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->unique()->constrained('gig_orders')->cascadeOnDelete();
            $table->foreignId('gig_id')->constrained('gigs')->cascadeOnDelete();
            $table->foreignId('reviewer_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('seller_id')->constrained('users')->cascadeOnDelete();
            $table->tinyInteger('rating');
            $table->text('comment')->nullable();
            $table->timestamps();

            $table->index(['gig_id', 'rating']);
            $table->index('seller_id');
        });

        // gig_disputes
        Schema::create('gig_disputes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('gig_orders')->cascadeOnDelete();
            $table->foreignId('opened_by')->constrained('users')->cascadeOnDelete();
            $table->text('reason');
            $table->enum('resolution', ['pending', 'buyer_wins', 'seller_wins'])->nullable();
            $table->foreignId('resolved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('resolved_at')->nullable();
            $table->text('admin_note')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('gig_disputes');
        Schema::dropIfExists('gig_reviews');
        Schema::dropIfExists('gig_orders');
        Schema::dropIfExists('gigs');
        Schema::dropIfExists('gig_categories');
    }
};
