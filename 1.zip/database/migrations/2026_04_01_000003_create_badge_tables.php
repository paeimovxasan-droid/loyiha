<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('badge_configs', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['bronze', 'silver', 'gold', 'diamond']);
            $table->integer('required_streak');
            $table->decimal('reward_ais', 10, 4)->default(0);
            $table->json('name')->comment('Translatable: uz, ru, en');
            $table->string('icon')->nullable();
            $table->string('color', 7);
            $table->timestamps();
        });

        Schema::create('user_badges', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('badge_config_id')->constrained('badge_configs')->cascadeOnDelete();
            $table->timestamp('awarded_at')->nullable();
            $table->timestamp('created_at')->nullable();

            $table->unique(['user_id', 'badge_config_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('user_badges');
        Schema::dropIfExists('badge_configs');
    }
};
