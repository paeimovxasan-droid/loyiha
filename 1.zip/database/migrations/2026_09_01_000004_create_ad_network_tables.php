<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ad_campaigns', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('name');
            $table->decimal('budget', 16, 4);
            $table->decimal('spent', 16, 4)->default(0);
            $table->decimal('cost_per_view', 16, 4);
            $table->enum('status', ['active', 'paused', 'completed'])->default('active');
            $table->timestamps();

            $table->index(['status']);
        });

        Schema::create('ads', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ad_campaign_id')->constrained('ad_campaigns')->cascadeOnDelete();
            $table->string('title');
            $table->text('description');
            $table->string('image_url')->nullable();
            $table->string('target_url')->nullable();
            $table->enum('status', ['active', 'paused'])->default('active');
            $table->timestamps();

            $table->index(['status']);
        });

        Schema::create('ad_views', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ad_id')->constrained('ads')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->decimal('earned', 16, 4);
            $table->dateTime('viewed_at');
            $table->timestamps();

            $table->index(['ad_id', 'user_id', 'viewed_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ad_views');
        Schema::dropIfExists('ads');
        Schema::dropIfExists('ad_campaigns');
    }
};
