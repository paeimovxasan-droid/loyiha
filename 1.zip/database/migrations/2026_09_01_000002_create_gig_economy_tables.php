<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('gig_listings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('title');
            $table->text('description');
            $table->enum('category', ['yuk_tashish', 'tozalash', 'qurilish', 'kuryer']);
            $table->string('location');
            $table->decimal('price', 16, 4);
            $table->date('work_date')->nullable();
            $table->enum('status', ['open', 'in_progress', 'completed', 'cancelled'])->default('open');
            $table->timestamps();

            $table->index(['status', 'category']);
            $table->index(['location']);
        });

        Schema::create('gig_applications', function (Blueprint $table) {
            $table->id();
            $table->foreignId('gig_listing_id')->constrained('gig_listings')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->enum('status', ['pending', 'accepted', 'rejected'])->default('pending');
            $table->timestamps();

            $table->unique(['gig_listing_id', 'user_id']);
        });

        Schema::create('gig_ratings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('gig_listing_id')->constrained('gig_listings')->cascadeOnDelete();
            $table->foreignId('rater_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('rated_user_id')->constrained('users')->cascadeOnDelete();
            $table->tinyInteger('rating');
            $table->text('comment')->nullable();
            $table->timestamps();

            $table->unique(['gig_listing_id', 'rater_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('gig_ratings');
        Schema::dropIfExists('gig_applications');
        Schema::dropIfExists('gig_listings');
    }
};
