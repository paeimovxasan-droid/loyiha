<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Level / XP tizimi
 * Level = floor(sqrt(total_xp / 100))
 * Level 0 = 0 XP ... Level 99 = 980,100 XP
 */
return new class extends Migration
{
    public function up(): void
    {
        // ── Foydalanuvchi XP va daraja ───────────────────────────────────────
        Schema::create('user_levels', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->unique()->constrained('users')->cascadeOnDelete();
            $table->integer('level')->default(0)->comment('Joriy daraja (0–99)');
            $table->bigInteger('total_xp')->default(0)->comment('Jami to\'plangan XP');
            $table->bigInteger('current_xp')->default(0)->comment('Joriy darajadagi XP');
            $table->bigInteger('next_level_xp')->default(100)->comment('Keyingi daraja uchun kerakli XP');
            $table->string('title')->default('Yangi')->comment('Unvon: Yangi, Faol, Ustoz...');
            $table->string('badge_color', 20)->default('#6366f1')->comment('Badge rangi');
            $table->timestamps();
        });

        // ── XP tarixi (qaysi faoliyatdan qancha XP olindi) ──────────────────
        Schema::create('xp_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('action', 60)->comment('register, checkin, deposit, purchase, referral, transfer, task, kyc...');
            $table->integer('xp')->comment('Berilgan XP miqdori');
            $table->string('description', 255)->nullable();
            $table->nullableMorphs('xpable'); // polymorphic — qaysi model sabab bo'ldi
            $table->timestamps();

            $table->index(['user_id', 'action']);
            $table->index('created_at');
        });

        // ── Daraja konfiguratsiyasi (admin o'zgartira oladi) ─────────────────
        Schema::create('level_configs', function (Blueprint $table) {
            $table->id();
            $table->integer('level')->unique()->comment('0–99');
            $table->string('title')->comment('Unvon nomi');
            $table->string('title_uz')->nullable();
            $table->string('title_ru')->nullable();
            $table->string('title_en')->nullable();
            $table->string('badge_color', 20)->default('#6366f1');
            $table->string('badge_icon', 10)->default('🌱')->comment('Emoji yoki icon');
            $table->bigInteger('xp_required')->comment('Bu darajaga yetish uchun jami XP');
            // Har daraja beruvchi bonuslar
            $table->decimal('ref_bonus_percent', 5, 2)->default(0)->comment('Qo\'shimcha referral %');
            $table->decimal('cashback_percent', 5, 2)->default(0)->comment('AIS cashback %');
            $table->decimal('daily_mining_bonus', 5, 2)->default(0)->comment('Qo\'shimcha mining %');
            $table->decimal('transfer_fee_discount', 5, 2)->default(0)->comment('Transfer komissiya chegirmasi %');
            $table->boolean('virtual_card_unlocked')->default(false)->comment('Virtual karta ochiladi');
            $table->boolean('p2p_unlocked')->default(false)->comment('P2P transfer ochiladi');
            $table->timestamps();
        });

        // ── XP manbalari konfiguratsiyasi ────────────────────────────────────
        Schema::create('xp_actions', function (Blueprint $table) {
            $table->id();
            $table->string('action', 60)->unique();
            $table->string('label');
            $table->integer('xp_amount')->comment('Beriluvchi XP');
            $table->boolean('is_repeatable')->default(true)->comment('Bir necha marta bajarish mumkinmi');
            $table->integer('cooldown_hours')->default(0)->comment('0 = cheklovsiz');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('xp_actions');
        Schema::dropIfExists('level_configs');
        Schema::dropIfExists('xp_logs');
        Schema::dropIfExists('user_levels');
    }
};
