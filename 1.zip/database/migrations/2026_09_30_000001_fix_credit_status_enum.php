<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('credits')) {
            DB::statement("ALTER TABLE credits MODIFY COLUMN status ENUM('pending','active','paid','overdue','cancelled') DEFAULT 'pending'");
        }
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE credits MODIFY COLUMN status ENUM('active','paid','overdue','cancelled') DEFAULT 'active'");
    }
};
