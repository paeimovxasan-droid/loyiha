<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // To'lov usullari (Payme, Click, Visa, USDT va h.k.)
        Schema::create('payment_methods', function (Blueprint $table) {
            $table->id();
            $table->json('name')->comment('{"uz":"...", "ru":"...", "en":"..."}');
            $table->string('slug', 50)->unique()->comment('payme, click, visa, usdt...');
            $table->string('photo')->nullable();
            $table->string('number', 32)->nullable()->comment('Card or wallet number');
            $table->decimal('minimum_deposit', 15, 2)->default(0);
            $table->decimal('maximum_deposit', 15, 2)->default(0);
            $table->decimal('deposit_charge_percent', 8, 2)->default(0)->comment('Deposit fee %');
            $table->decimal('minimum_withdraw', 15, 2)->default(0);
            $table->decimal('maximum_withdraw', 15, 2)->default(0);
            $table->decimal('withdraw_charge_percent', 8, 2)->default(0)->comment('Withdraw fee %');
            $table->enum('status', ['active', 'inactive'])->default('active');
            $table->integer('sort_order')->default(0);
            $table->timestamps();
        });

        // To'lov tarixi (deposit so'rovlari)
        Schema::create('deposits', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('payment_method_id')->nullable()->constrained('payment_methods')->nullOnDelete();
            $table->string('method_name')->nullable();
            $table->string('method_number')->nullable();
            $table->string('order_id')->unique();
            $table->string('transaction_id')->nullable();
            $table->string('sender_number')->nullable()->comment('User wallet/card number');
            $table->decimal('amount', 15, 2)->default(0);
            $table->decimal('charge', 15, 2)->default(0)->comment('Fee amount');
            $table->decimal('final_amount', 15, 2)->default(0)->comment('Net amount after charge');
            $table->text('feedback')->nullable()->comment('Admin note');
            $table->string('screenshot')->nullable()->comment('Payment proof image');
            $table->enum('status', ['pending', 'approved', 'rejected'])->default('pending');
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();
        });

        // Pul yechish tarixi
        Schema::create('withdrawals', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('payment_method_id')->nullable()->constrained('payment_methods')->nullOnDelete();
            $table->string('method_name')->nullable();
            $table->string('receiver_number', 50)->comment('User wallet/card number');
            $table->decimal('amount', 15, 2)->default(0);
            $table->decimal('charge', 15, 2)->default(0);
            $table->decimal('final_amount', 15, 2)->default(0);
            $table->text('feedback')->nullable()->comment('Admin note / Reject reason');
            $table->enum('status', ['pending', 'approved', 'rejected'])->default('pending');
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('withdrawals');
        Schema::dropIfExists('deposits');
        Schema::dropIfExists('payment_methods');
    }
};
