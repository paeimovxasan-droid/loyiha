<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('social_proof_events', function (Blueprint $table) {
            $table->id();
            $table->enum('type', ['ais_earned', 'level_up', 'new_user', 'package_buy', 'badge_earned']);
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('masked_name');
            $table->decimal('amount', 10, 4)->nullable();
            $table->json('metadata')->nullable();
            $table->timestamp('created_at')->nullable();

            $table->index('created_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('social_proof_events');
    }
};
