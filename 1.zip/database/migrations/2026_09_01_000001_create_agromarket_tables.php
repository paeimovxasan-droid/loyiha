<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('agro_listings', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('title');
            $table->text('description')->nullable();
            $table->enum('category', ['bugdoy', 'paxta', 'sabzavot', 'meva']);
            $table->decimal('quantity', 12, 2);
            $table->decimal('price_per_unit', 16, 4);
            $table->string('location');
            $table->enum('status', ['active', 'inactive', 'sold'])->default('active');
            $table->boolean('is_forward')->default(false);
            $table->date('delivery_date')->nullable();
            $table->timestamps();

            $table->index(['status', 'category']);
            $table->index(['location']);
        });

        Schema::create('agro_orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('buyer_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('seller_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('agro_listing_id')->constrained('agro_listings')->cascadeOnDelete();
            $table->decimal('quantity', 12, 2);
            $table->decimal('total_price', 16, 4);
            $table->enum('status', ['pending', 'confirmed', 'completed', 'cancelled'])->default('pending');
            $table->boolean('is_forward')->default(false);
            $table->date('delivery_date')->nullable();
            $table->timestamps();

            $table->index(['buyer_id', 'status']);
            $table->index(['seller_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('agro_orders');
        Schema::dropIfExists('agro_listings');
    }
};
