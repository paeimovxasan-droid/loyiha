<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // ── Credits ──────────────────────────────────────────────────────
        Schema::create('credits', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->decimal('amount', 15, 2);
            $table->enum('currency', ['UZS', 'AIS'])->default('UZS');
            $table->decimal('interest_rate', 5, 2);
            $table->decimal('interest_amount', 15, 2);
            $table->integer('term_days');
            $table->integer('credit_score')->default(0);
            $table->enum('status', ['pending', 'active', 'paid', 'overdue', 'cancelled'])->default('pending');
            $table->timestamp('issued_at')->useCurrent();
            $table->timestamp('due_date')->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'status']);
            $table->index('due_date');
        });

        // ── Credit Payments ──────────────────────────────────────────────
        Schema::create('credit_payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('credit_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->decimal('amount', 15, 2);
            $table->decimal('principal', 15, 2);
            $table->decimal('interest', 15, 2);
            $table->enum('currency', ['UZS', 'AIS'])->default('UZS');
            $table->timestamps();
        });

        // ── Savings Plans ────────────────────────────────────────────────
        Schema::create('savings_plans', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->integer('term_months');
            $table->decimal('monthly_amount', 15, 2);
            $table->enum('currency', ['UZS', 'AIS'])->default('UZS');
            $table->decimal('bonus_rate', 5, 2)->default(0);
            $table->decimal('total_saved', 15, 2)->default(0);
            $table->integer('paid_months')->default(0);
            $table->enum('status', ['active', 'completed', 'cancelled'])->default('active');
            $table->date('next_payment_date')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'status']);
        });

        // ── Savings Payments ─────────────────────────────────────────────
        Schema::create('savings_payments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('savings_plan_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->decimal('amount', 15, 2);
            $table->enum('currency', ['UZS', 'AIS'])->default('UZS');
            $table->integer('month_number');
            $table->enum('status', ['paid', 'missed'])->default('paid');
            $table->timestamps();
        });

        // ── Saving Groups ────────────────────────────────────────────────
        Schema::create('saving_groups', function (Blueprint $table) {
            $table->id();
            $table->foreignId('admin_id')->constrained('users')->cascadeOnDelete();
            $table->string('name');
            $table->integer('max_members');
            $table->decimal('monthly_amount', 15, 2);
            $table->enum('currency', ['UZS', 'AIS'])->default('UZS');
            $table->integer('current_round')->default(0);
            $table->enum('status', ['pending', 'active', 'completed', 'suspended'])->default('pending');
            $table->timestamp('started_at')->nullable();
            $table->timestamps();

            $table->index('status');
        });

        // ── Saving Group Members ─────────────────────────────────────────
        Schema::create('saving_group_members', function (Blueprint $table) {
            $table->id();
            $table->foreignId('saving_group_id')->constrained()->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->integer('round_order')->nullable();
            $table->enum('status', ['pending', 'active', 'defaulted', 'completed'])->default('pending');
            $table->timestamp('joined_at')->nullable();
            $table->timestamps();

            $table->unique(['saving_group_id', 'user_id']);
        });

        // ── Saving Group Rounds ──────────────────────────────────────────
        Schema::create('saving_group_rounds', function (Blueprint $table) {
            $table->id();
            $table->foreignId('saving_group_id')->constrained()->cascadeOnDelete();
            $table->foreignId('recipient_id')->constrained('users')->cascadeOnDelete();
            $table->integer('round_number');
            $table->decimal('total_collected', 15, 2)->default(0);
            $table->enum('status', ['pending', 'collecting', 'completed', 'failed'])->default('pending');
            $table->timestamp('completed_at')->nullable();
            $table->timestamps();

            $table->index(['saving_group_id', 'round_number']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('saving_group_rounds');
        Schema::dropIfExists('saving_group_members');
        Schema::dropIfExists('saving_groups');
        Schema::dropIfExists('savings_payments');
        Schema::dropIfExists('savings_plans');
        Schema::dropIfExists('credit_payments');
        Schema::dropIfExists('credits');
    }
};
