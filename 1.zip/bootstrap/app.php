<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Support\Facades\RateLimiter;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        api: __DIR__ . '/../routes/api.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
        then: function () {
            // Admin va Install marshrutlarini web middleware bilan guruhlash
            \Illuminate\Support\Facades\Route::middleware('web')
                ->group(base_path('routes/admin.php'));

            \Illuminate\Support\Facades\Route::middleware('web')
                ->group(base_path('routes/install.php'));

            // API rate limiterlari (Production uchun kengaytirilgan)
            RateLimiter::for('api', function (\Illuminate\Http\Request $request) {
                return Limit::perMinute(300)->by($request->user()?->id ?: $request->ip());
            });

            RateLimiter::for('auth-api', function (\Illuminate\Http\Request $request) {
                return Limit::perMinute(30)->by($request->ip());
            });

            RateLimiter::for('financial-api', function (\Illuminate\Http\Request $request) {
                return Limit::perMinute(20)->by($request->user()?->id ?: $request->ip());
            });
        },
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // Middleware aliaslarini o'rnatish
        $middleware->alias([
            'admin' => \App\Http\Middleware\AdminMiddleware::class,
            'set.locale' => \App\Http\Middleware\SetLocale::class,
            'installed' => \App\Http\Middleware\CheckInstalled::class,
            'telegram.auth' => \App\Http\Middleware\Api\TelegramAuthMiddleware::class,
            'set.locale.api' => \App\Http\Middleware\Api\SetLocaleApi::class,
            'force.json' => \App\Http\Middleware\Api\ForceJsonResponse::class,
            'auth:sanctum' => \App\Http\Middleware\Api\SimpleTokenAuth::class,
            'kyc.required' => \App\Http\Middleware\KycRequiredMiddleware::class,
        ]);

        // Web guruhiga middleware qo'shish
        $middleware->appendToGroup('web', [
            \App\Http\Middleware\CheckInstalled::class,
            \App\Http\Middleware\SetLocale::class,
        ]);

        // Mehmonlarni va foydalanuvchilarni yo'naltirish
        $middleware->redirectGuestsTo(fn() => route('login'));
        $middleware->redirectUsersTo(fn() => route('app.dashboard'));

        // Ishtirokchilar va proksilarga ishonish (Trust Proxies)
        $middleware->trustProxies(at: '*');

        // Telegram Mini App uchun CSRF xavfsizligidan mustasno yo'llar
        $middleware->validateCsrfTokens(except: [
            'api/*',
            'app',
            'app/*',
            'bot/*',
            'telegram/*',
            'login',
            'register',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();
