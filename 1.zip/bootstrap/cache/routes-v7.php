<?php

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/api/v1/auth/telegram' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ryihFgAAULS06G5m',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/telegram/webhook' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OauSvxFCUB717ozZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/telegram/admin-webhook' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HuvmhXHmUzrf35LN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q8ZBDVf7Pc5W9HKL',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/wallet' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JjpwWyUZO2boI9Ns',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/wallet/transfer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::u0kKy9vxA1y0UgVZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/wallet/convert' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OiRGG8exYORvBWPr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/wallet/card' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::meCT67JqwTNeiZDN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/packages' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::18OckZ8UaMElyBSK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/deposits' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::j0NMh2BCNtD6wnzN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vFTGxYBTbIrS15sx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/withdrawals' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3AkMieSaeoLvdTuz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xKCpaAlJjIAkeaBX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/withdrawals/scoring' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1Chgns7nYhdcIcjt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/level' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1NgmivgV2xvr2XyA',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/level/xp-history' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::acDISJgJYmFJ9hAu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/level/leaderboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xutp4D7Uroep420p',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/level/milestones' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::270guoj7TY4JggGK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/quests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZL3z4xRhsFqOEn7R',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/quests/stats' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Bae9pUdT2mv0kwUD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/tasks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WJtYKDoMdEV3ML0M',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/checkin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZZZV1AOr5u3aDZF1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/lucky-draw' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JzSOKUCYVzNSRDfV',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/funds' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qRBG4B9I3onGdVXS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/kyc/status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QXVdB2Yhx1MpaLez',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/kyc/passport' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ONQW6f27Aum40ctU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/kyc/face/start' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0tunFI56ALu8eIso',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/kyc/face/submit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YJ9H6ZVToAOQLCEg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/kyc/face/status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lnSpkNMqQ8OXCh4g',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/referrals' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BJj6rrcGgaItz654',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/transactions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gubCBBhHsYadRrRl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/credits/rating' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::68v9cQoHLc89v0eF',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/credits' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LkeJPRNnTvCyalnM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MfUWqgHs87O65TSs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/savings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5vZP1UwOrS9JAZTX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uDJgWZNE905PNhSO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/saving-groups' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N3JjKs6Ceddo5IuA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jfO7CCzBg5s4BwjP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L1eZS5Bb01nDLi0l',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yPHj8KR1QCr3nRmB',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/security/2fa' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XyJZit8MfIgOp621',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/security/2fa/enable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ccZoIUf7LUwzGSwA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/security/2fa/disable' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::v7HGW1qDG83IIbGR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/promo/redeem' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WFfHkazbvVNZ42V8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/spin-wheel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GQC4FK12zNz98DKR',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/spin-wheel/spin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qmYtdF1bEMJytR8W',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/badges' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fUhpR4ne3YzAFLf2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/share' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vtKCi1wjGEh10TCC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/invite-challenge' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::U2YyEfpwtCl5wRCS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/invite-challenge/start' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VHj2DTyvJLmyb2ct',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/onboarding' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s2TsUIBroVNX9Zxz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/competitions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::noJUitws583GVABM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/competitions/history' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::K0EEVLP5SgrLTbXd',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/events' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ipxJEw1jzkYYITnD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/social-proof' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::b7wWBqRa4qGgQSGg',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/qr-referral' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::irdiwc3QJUBZoTFX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/qr-referral/download' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jBoq97TZweJwML59',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/referral-tree' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wZupFFgzJpy7HRkh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/vip' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::agWs047tvNYyGDKq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/roadmap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jTWDEUuLvY752dJ6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/marketplace/categories' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y0yCplG6BYiwn7Nk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/marketplace/gigs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::plxRNiHcufPFyFq0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FdpkROqqbbwuhFMX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/marketplace/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ci5dGotNow95AzUe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OKndhWTXwrGUljdr',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/exchange/order-book' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::o8Qd8ABpEWc67pWB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/exchange/ticker' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sSSl9eEDe6e6o8WK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/exchange/trades/recent' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jfcp9Fc9TiPljppo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/exchange/candles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nPvR51VA1twHaSgM',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/exchange/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JTPNIGtIDCAUUCPv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/exchange/trades/my' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sCyVB2yAAlRADSh8',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/catalog/shops' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DPZmzvD0HHbLOBrU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8fresx61K79flZKJ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/catalog/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CAsbsd6X1z4GBnWO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/catalog/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lfZt8OgqkGUZsalr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IHqI4ORfDsTu4Wzt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/courses' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OTpD1TxDTBnudJJ4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RboZmYLaWs8gJ9FN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/courses/my-purchases' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::v9lYjX1W4fJ3eqso',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/certificates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XVvlHjkdLflLQGhp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/mentors' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QNaFKIMVkNHuk4Zp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/mentors/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4tOD2qbvzDWm6euE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/mentor-sessions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lY6ioncoCXOnnKts',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/crowdfunding/projects' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4k09hVDIJCaP9us0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QsoJzjlhmOnjohEN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/agromarket/listings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::op38d7TLJ0Jf2X5l',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XMQ9EThbTKLmNmRI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/agromarket/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::l2m4IOSDcx4sg3yq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LoW4uPI6V3WpTvNw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/gig-economy/listings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d9QTYHLoHfBLoLGx',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::njvhk2DbrUPTvJPj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/gig-economy/my-listings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dLiAA8USKzONfCCk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/gig-economy/my-applications' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8b5TduJg689mixe5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/ubi/status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Hunl0voDrYggUawE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/ubi/claim' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FCrwsYaMupN85Oqn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/ubi/history' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3RSDAgvgrENdMuYH',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/ubi/stats' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dF994wLjeH94cpL2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/ads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T8gyxpIRRi85vaFT',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/ads/campaigns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eWf5l2jknolhH2Zk',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DS01ZxvvgD9cdFeD',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/lending/offers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J0OzF5PizynrKi9j',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BihsasoLVkPPyY8w',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/lending/loans' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sp52DdLXg0N4HjVW',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/tokens/assets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cJRozT8AV69WjbsI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/tokens/portfolio' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NEVx37Upo4U5PjqP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/ai-assistant/ask' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AztG5HBLtajeTkVt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/ai-assistant/conversations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IjhF0QwdMDdi5wn1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/ai-assistant/faq' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jx3rspuVtSGQd5DP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/ai-assistant/advice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dTKwnDtEGBLgahER',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/medical/specialties' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ieZNKOP9870RaN2f',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/medical/doctors' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xrFdogtv8qZz7GHC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/medical/doctor-profile/me' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5EcPDw4miLBWipVE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/medical/doctor-profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Rpcj1xO1VuBrbBWl',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EjQpsy8IppbsUojl',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/medical/doctor-profile/toggle-online' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hqsrHVzuucsCDkFj',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/medical/doctor/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gnVgl7jquYSQ5a03',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/medical/consultations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::p3UfCaXjXVINeU9F',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dxVtzZn48T0AwlXi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/medical/medicines' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NFP0Wqb60WZlK3rz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/medical/medicine-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DtqhixHbIumo2ip0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::w1UYhoi6yuu4vXUq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/v1/medical/home-visits' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dLH3voyOQsaDGnyl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hbffomkW9MuXx1ZX',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/up' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3gRVYfe8S8klv5KX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'home',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/presentation' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'presentation',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/offline' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'offline',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manifest.json' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'pwa.manifest',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'login.post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/register' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'register.post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.forgot',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'password.send',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reset-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/terms' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.terms',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/privacy' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.privacy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/ais-rules' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.ais-rules',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/deposit-withdraw' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.deposit-withdraw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/risk-disclaimer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.risk-disclaimer',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/referral' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.referral',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/kyc' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.kyc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/cookies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.cookies',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/refund' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.refund',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/legal/anti-fraud' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'legal.anti-fraud',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/profile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.profile',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.profile.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/profile/password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.profile.password',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/packages' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.packages',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/deposit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.deposit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.deposit.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/withdraw' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.withdraw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.withdraw.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/referrals' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.referrals',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/transactions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.transactions',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/checkin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.checkin',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/wallet' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.wallet',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/wallet/transfer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.wallet.transfer',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/wallet/convert' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.wallet.convert',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/wallet/card/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.wallet.card.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/wallet/card' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.wallet.card.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/level' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.level',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/leaderboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.leaderboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/spin-wheel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.spin_wheel',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/spin-wheel/spin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.spin_wheel.spin',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/lucky-draw' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.lucky_draw',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/tasks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.tasks',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/funds' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.funds',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/kyc' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.kyc',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/kyc/passport' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.kyc.passport',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/kyc/face/start' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.kyc.face.start',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/kyc/face/submit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.kyc.face.submit',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/quests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.quests',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/roadmap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.roadmap',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/crowdfunding/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.crowdfunding.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/crowdfunding' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.crowdfunding.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.crowdfunding',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/exchange' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.exchange',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/exchange/order' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.exchange.order',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/marketplace' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.marketplace',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/education/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.education.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/education' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.education.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.education',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/catalog/shop/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.catalog.shop.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/catalog/shop' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.catalog.shop.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/catalog/product/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.catalog.product.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/catalog/product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.catalog.product.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/catalog' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.catalog',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/credit' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.credit',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/credit/apply' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.credit.apply',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/savings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.savings',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/savings/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.savings.create',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/gig/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.gig.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/gig' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.gig.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.gig',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/agromarket/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.agromarket.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/agromarket' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.agromarket.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.agromarket',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/lending/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.lending.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/lending' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.lending.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.lending',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/ai-assistant' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.ai',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.ai.send',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/influencer' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.influencer.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/influencer/channels' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.influencer.channels',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.influencer.channels.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/influencer/campaigns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.influencer.campaigns',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/influencer/submissions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.influencer.submissions',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.influencer.submissions.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/support' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.support.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'app.support.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/support/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.support.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/medical' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.medical.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/medical/doctors' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.medical.doctors',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/medical/consultations/start' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.medical.consultations.start',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/medical/consultations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.medical.consultations',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/medical/medicine-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.medical.medicine-orders',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/medical/doctor/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.medical.doctor.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/medical/doctor/dashboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.medical.doctor.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.login.post',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/upload' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.upload',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/users/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/admins' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.admins.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.admins.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/admins/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.admins.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roles.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roles.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/roles/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roles.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/deposits' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.deposits.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/withdrawals' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.withdrawals.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/packages' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.packages.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.packages.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/packages/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.packages.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/stations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.stations.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.stations.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/stations/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.stations.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/payment-methods' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment_methods.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment_methods.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/payment-methods/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment_methods.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.settings.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/translations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.translations.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.translations.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/translations/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.translations.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ais/rate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ais.rate',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ais.rate.update',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ais/wallets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ais.wallets',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ais/transfers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ais.transfers',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/leaders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leaders.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/levels' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.levels.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/levels/leaderboard' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.levels.leaderboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/kyc/passport' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.kyc.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/kyc/face' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.kyc.face.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/tasks' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.tasks.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.tasks.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/tasks/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.tasks.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/quests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quests.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quests.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/quests/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quests.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/lucky-draw' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lucky-draw.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lucky-draw.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/lucky-draw/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lucky-draw.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/lucky-draw-results' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lucky-draw.results',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/funds' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.funds.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.funds.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/funds/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.funds.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/channel-posts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.channel-posts.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.channel-posts.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/channel-posts/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.channel-posts.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/roadmap' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roadmap.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roadmap.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/roadmap/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roadmap.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/exchange/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.exchange.settings.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.exchange.settings.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/exchange/stats' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.exchange.stats',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/exchange/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.exchange.orders',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/exchange/trades' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.exchange.trades',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/marketing/promo-codes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.promo-codes.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.promo-codes.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/marketing/spin-wheel/prizes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.spin-wheel.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.spin-wheel.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.spin-wheel.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/marketing/competitions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.competitions.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/marketing/competitions/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.competitions.settings',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/marketing/events' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.events.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.events.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/marketing/vip/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.vip.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.vip.settings',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/marketing/invite-challenge/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.invite-challenge.settings',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.invite-challenge.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/crowdfunding' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.crowdfunding.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ubi/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ubi.settings',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ubi.settings.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ubi/claims' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ubi.claims',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/tokens/assets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.tokens.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.tokens.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/faq' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.faq.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.faq.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ai-assistant/faq' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ai.faq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ai.faq.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ai-assistant/conversations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ai.conversations',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/agromarket/listings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.agromarket.listings',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/agromarket/orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.agromarket.orders',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/gig-economy/listings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.gig-economy.listings',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/gig-economy/applications' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.gig-economy.applications',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ad-network/campaigns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ad-network.campaigns',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/ad-network/ads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ad-network.ads',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/influencer/channels' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.channels.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/influencer/campaigns' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.campaigns.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.campaigns.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/influencer/campaigns/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.campaigns.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/influencer/submissions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.submissions.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/influencer/submissions/bulk-approve' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.submissions.bulk-approve',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/influencer/stats' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.stats',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/influencer/rewards' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.rewards.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/influencer/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.settings.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.settings.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/lending/loans' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lending.loans',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/lending/offers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lending.offers',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/marketplace' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketplace.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketplace.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/marketplace/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketplace.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/credits' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.credits.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/savings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.savings.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/education' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.education.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/catalog/shops' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.catalog.shops',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/catalog/products' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.catalog.products',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/fraud' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.fraud.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/fraud/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.fraud.users',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/fraud/transactions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.fraud.transactions',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/fraud/audit-logs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.fraud.audit-logs',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/support' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.support.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/medical' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/medical/doctors' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.doctors',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/medical/consultations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.consultations',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/medical/medicine-orders' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.medicine-orders',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/medical/home-visits' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.home-visits',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/medical/complaints' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.complaints',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/medical/medicines' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.medicines',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.medicines.store',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/medical/financial-report' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.financial-report',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/admin/medical/settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.settings',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.settings.update',
          ),
          1 => NULL,
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/run-update' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e1fTHwFL3p1BQxuQ',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/install' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'install.welcome',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/install/database' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'install.database',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'install.database.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/install/site' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'install.site',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'install.site.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/install/admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'install.admin',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'install.admin.save',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/install/process' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'install.process',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/install/run' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'install.run',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/install/complete' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'install.complete',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/a(?|p(?|i/v1/(?|packages/([^/]++)/buy(*:45)|quests/([^/]++)/claim(*:73)|t(?|asks/([^/]++)/submit(*:104)|okens/assets/([^/]++)(?|(*:136)|/purchase(*:153)))|l(?|ucky\\-draw/([^/]++)/buy(*:190)|ending/(?|offers/([^/]++)/(?|accept(*:233)|cancel(*:247))|loans/([^/]++)(?|(*:273)|/pay(*:285))))|funds/([^/]++)/invest(*:317)|c(?|r(?|edits/([^/]++)/repay(*:353)|owdfunding/projects/([^/]++)(?|(*:392)|/donate(*:407)))|atalog/(?|shops/([^/]++)(?|(*:444)|/products(*:461))|products/([^/]++)(?|(*:490))|orders/([^/]++)/(?|co(?|nfirm(*:528)|mplete(*:542))|deliver(*:558)|review(*:572)))|ertificates/(?|verify/([^/]++)(*:612)|([^/]++)/download(*:637))|ourses/(?|([^/]++)(?|(*:667)|/(?|lessons(*:686)|pu(?|blish(*:704)|rchase(*:718))))|lessons/([^/]++)/complete(*:754)))|s(?|aving(?|s/([^/]++)(?|(*:789)|/cancel(*:804))|\\-groups/([^/]++)(?|(*:833)|/(?|join(*:849)|approve/([^/]++)(*:873))))|/([^/]++)(*:893))|e(?|vents/([^/]++)(*:920)|xchange/orders/(?|([^/]++)(*:954)|open(*:966)|history(*:981)))|r(?|eferral\\-tree/level/([^/]++)(*:1023)|oadmap/([^/]++)/(?|vote(*:1055)|notify(*:1070)))|m(?|arketplace/(?|gigs/([^/]++)(?|(*:1115))|orders/([^/]++)(?|(*:1143)|/(?|accept(*:1162)|re(?|ject(*:1180)|view(*:1193))|d(?|eliver(*:1213)|ispute(*:1228))|complete(*:1246)))|disputes/([^/]++)/resolve(*:1282)|sellers/([^/]++)(*:1307))|e(?|ntor(?|s/([^/]++)/request(*:1346)|\\-sessions/([^/]++)/(?|accept(*:1384)|complete(*:1401)))|dical/(?|doctors/([^/]++)(*:1437)|consultations/([^/]++)(?|(*:1471)|/(?|accept(*:1490)|c(?|ompl(?|ete(*:1513)|aint(*:1526))|ancel(*:1541))|messages(*:1559)|re(?|view(*:1577)|ferrals(*:1593))|prescriptions(*:1616)))|medicine\\-orders/([^/]++)/cancel(*:1659)|home\\-visits/([^/]++)/(?|accept(*:1699)|on\\-the\\-way(*:1720)|complete(*:1737)))))|a(?|gromarket/(?|listings/([^/]++)(?|(*:1787))|orders/([^/]++)/c(?|onfirm(*:1823)|ancel(*:1837)))|ds/(?|campaigns/([^/]++)(?|(*:1875)|/ads(*:1888))|([^/]++)/watch(*:1912))|i\\-assistant/conversations/([^/]++)(*:1957))|gig\\-economy/(?|listings/([^/]++)(?|(*:2003)|/(?|apply(*:2021)|complete(*:2038)|rate(*:2051)))|applications/([^/]++)/accept(*:2090)))|p/(?|packages/([^/]++)/buy(*:2127)|wallet/card/([^/]++)/freeze(*:2163)|l(?|ucky\\-draw/([^/]++)/buy(*:2199)|ending/([^/]++)/borrow(*:2230))|tasks/([^/]++)/submit(*:2261)|funds/([^/]++)/invest(*:2291)|quests/([^/]++)/claim(*:2321)|roadmap/([^/]++)/vote(*:2351)|crowdfunding/([^/]++)/donate(*:2388)|influencer/channels/([^/]++)(*:2425)|support/([^/]++)(?|(*:2453)|/(?|reply(*:2471)|close(*:2485)))|medical/(?|doctors/([^/]++)(*:2523)|consultations/([^/]++)(*:2554))))|dmin/(?|users/([^/]++)(?|/(?|edit(*:2599)|ba(?|n(*:2614)|lance(*:2628)))|(*:2639))|a(?|d(?|mins/([^/]++)(?|/(?|edit(*:2681)|ban(*:2693)|role(*:2706))|(*:2716))|\\-network/campaigns/([^/]++)(?|/edit(*:2762)|(*:2771)))|i\\-assistant/faq/([^/]++)(?|(*:2810))|gromarket/listings/([^/]++)(?|/edit(*:2855)|(*:2864)))|ro(?|les/([^/]++)(?|/(?|edit(*:2903)|permissions(*:2923))|(*:2933))|admap/([^/]++)(?|/edit(*:2965)|(*:2974)))|deposits/([^/]++)(?|(*:3005)|/(?|approve(*:3025)|reject(*:3040)))|withdrawals/([^/]++)(?|(*:3074)|/(?|approve(*:3094)|reject(*:3109)))|pa(?|ckages/([^/]++)(?|/edit(*:3148)|(*:3157))|yment\\-methods/([^/]++)(?|/edit(*:3198)|(*:3207)))|s(?|tations/([^/]++)(?|/edit(*:3246)|(*:3255))|avings/([^/]++)(?|/edit(*:3288)|(*:3297))|upport/([^/]++)(?|(*:3325)|/reply(*:3340)|(*:3349)))|t(?|ranslations/(?|([^/]++)(?|/edit(*:3395)|(*:3404))|clear\\-cache(*:3426))|asks/([^/]++)(?|/(?|edit(*:3460)|approve(*:3476)|reject(*:3491))|(*:3501))|okens/assets/([^/]++)(*:3532))|l(?|e(?|aders/([^/]++)/t(?|oggle(*:3574)|ree(*:3586))|nding/loans/([^/]++)(?|/edit(*:3624)|(*:3633)))|ucky\\-draw/([^/]++)(?|/(?|edit(*:3674)|draw(*:3687))|(*:3697)))|kyc/(?|passport/([^/]++)(?|(*:3735)|/(?|approve(*:3755)|reject(*:3770)))|face/([^/]++)(?|(*:3797)|/(?|approve(*:3817)|reject(*:3832))))|quests/([^/]++)(?|/edit(*:3867)|(*:3876))|f(?|unds/([^/]++)(?|/edit(*:3911)|(*:3920))|aq/([^/]++)(?|(*:3944))|raud/users/([^/]++)(?|(*:3976)|/(?|ban(*:3992)|unban(*:4006)|flags/([^/]++)(*:4029))))|m(?|arket(?|ing/(?|promo\\-codes/([^/]++)(?|(*:4084)|/stats(*:4099))|spin\\-wheel/prizes/([^/]++)(?|(*:4139))|events/([^/]++)(?|(*:4167)))|place/([^/]++)(?|/edit(*:4200)|(*:4209)))|edical/(?|doctors/([^/]++)(?|(*:4249)|/(?|approve(*:4269)|re(?|ject(*:4287)|activate(*:4304))|suspend(*:4321)))|co(?|nsultations/([^/]++)(*:4357)|mplaints/([^/]++)/review(*:4390))|medicine(?|\\-orders/([^/]++)/status(*:4435)|s/([^/]++)(?|(*:4457)))))|c(?|r(?|owdfunding/([^/]++)/(?|approve(*:4508)|reject(*:4523)|expenses(?|(*:4543)))|edits/([^/]++)(?|/edit(*:4576)|(*:4585)))|atalog/(?|shops/([^/]++)(?|/edit(*:4628)|(*:4637))|products/([^/]++)(?|/edit(*:4672)|(*:4681))))|gig\\-economy/listings/([^/]++)(?|/edit(*:4731)|(*:4740))|influencer/(?|c(?|hannels/([^/]++)/(?|approve(*:4795)|reject(*:4810)|suspend(*:4826))|ampaigns/([^/]++)(?|/edit(*:4861)|(*:4870)))|submissions/([^/]++)/(?|approve(*:4912)|reject(*:4927)))|education/([^/]++)(?|/edit(*:4964)|(*:4973))))|/re(?|gister/([^/]++)(*:5006)|set\\-password/([^/]++)(*:5037))|/locale/([^/]++)(*:5063)|/storage/(.*)(?|(*:5088)))/?$}sDu',
    ),
    3 => 
    array (
      45 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ruROBiDTsXaJ5UmM',
          ),
          1 => 
          array (
            0 => 'package',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      73 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wW3L5dhyeorwXOFg',
          ),
          1 => 
          array (
            0 => 'userQuest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      104 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jDFo5GDipFy3RQPb',
          ),
          1 => 
          array (
            0 => 'task',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      136 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::DYGKBMpDEojzyECh',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      153 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FfPoJpQAUq67vG2n',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      190 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lnuXZ29WOKe2DV35',
          ),
          1 => 
          array (
            0 => 'draw',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      233 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UzceQXKDmpvJiiXa',
          ),
          1 => 
          array (
            0 => 'offer',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      247 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::coCm6wPeUagghGdO',
          ),
          1 => 
          array (
            0 => 'offer',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      273 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5ZMxmmJojyJT8WM2',
          ),
          1 => 
          array (
            0 => 'loan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      285 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Jrgkkzd7tc9O5DBU',
          ),
          1 => 
          array (
            0 => 'loan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      317 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XCOY1mUQradH8sGJ',
          ),
          1 => 
          array (
            0 => 'fund',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      353 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZgNeMUb3RXTzwxRa',
          ),
          1 => 
          array (
            0 => 'credit',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      392 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lS8XqJl52ZZbddmd',
          ),
          1 => 
          array (
            0 => 'project',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      407 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H8LZ2TDFvucKUlD6',
          ),
          1 => 
          array (
            0 => 'project',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      444 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a2und98mWPBZvyaa',
          ),
          1 => 
          array (
            0 => 'shop',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::3t8BMJ3oQoVDH7GY',
          ),
          1 => 
          array (
            0 => 'shop',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      461 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kKrHXZOLUsHeLWaw',
          ),
          1 => 
          array (
            0 => 'shop',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gi4SX7rDFJIbwU4e',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xUFP2cBscRA1SM7r',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      528 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e5NY3QshLjjTcbKc',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      542 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gr74ci8El0jI4ADi',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      558 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5767XPZfYOEe0ADP',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      572 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IvVK92UPSAv20VX0',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      612 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CLJNLdhukbC4L2yc',
          ),
          1 => 
          array (
            0 => 'code',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      637 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L01CXSpblFFPYIS9',
          ),
          1 => 
          array (
            0 => 'certificate',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      667 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e5XmQdhkoFWJQ9uw',
          ),
          1 => 
          array (
            0 => 'course',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      686 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IX9zegup8OgaQXbL',
          ),
          1 => 
          array (
            0 => 'course',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      704 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lIbiBGHQL7Oe7Cna',
          ),
          1 => 
          array (
            0 => 'course',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      718 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Vn9zLfs9k8wCXfy7',
          ),
          1 => 
          array (
            0 => 'course',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      754 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uvAOIml7V8a5IfBk',
          ),
          1 => 
          array (
            0 => 'lesson',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      789 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P3Ra1foPc5iXVC9B',
          ),
          1 => 
          array (
            0 => 'plan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      804 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WdgEChsok1cX9f2F',
          ),
          1 => 
          array (
            0 => 'plan',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      833 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eiVDgeEPxpAomu4o',
          ),
          1 => 
          array (
            0 => 'savingGroup',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      849 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TGtr4jttqECIR3jI',
          ),
          1 => 
          array (
            0 => 'savingGroup',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      873 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kBoFnCe1xmz4syIX',
          ),
          1 => 
          array (
            0 => 'savingGroup',
            1 => 'member',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      893 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WOvzEzB6kWB2ZX5L',
          ),
          1 => 
          array (
            0 => 'code',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      920 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R4WKou89c3kYjGWL',
          ),
          1 => 
          array (
            0 => 'event',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      954 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Zs43RLhNNlKiEXUl',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      966 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lCIzZc4K6X5fvLCo',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      981 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZRQpUJv6omg4kqrK',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1023 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8BV0ql8mEuB8UaYE',
          ),
          1 => 
          array (
            0 => 'level',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1055 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hwNhk9OCKvjdFA6B',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1070 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8UPK0Y16u6pxrbM6',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1115 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0PcVhyeFMwVq5qvV',
          ),
          1 => 
          array (
            0 => 'gig',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9LvndSWphgVmjbpN',
          ),
          1 => 
          array (
            0 => 'gig',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => 
          array (
            '_route' => 'generated::B138wAV17JwHVtwE',
          ),
          1 => 
          array (
            0 => 'gig',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1143 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::r8pYMm5JnCHWmjty',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1162 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NhcCSkmrv5taNLps',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1180 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0yo11M4s4dbLOYgS',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1193 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bzm2jmSX1NDrPFiW',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1213 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xBMXb8fry7NgMnQu',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1228 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::33nlzjTmosdK558a',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1246 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::izqVkJhEgD686FCX',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1282 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::N4ZtjWgq5sYpEQwj',
          ),
          1 => 
          array (
            0 => 'dispute',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1307 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qBhoKbq58NHr3s8D',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1346 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Drab9mdYi0ayZ0lq',
          ),
          1 => 
          array (
            0 => 'mentor',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1384 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::daZSS5fRTBoS46ct',
          ),
          1 => 
          array (
            0 => 'session',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1401 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pDMUdKpABHXRlTKJ',
          ),
          1 => 
          array (
            0 => 'session',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1437 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::77WTrPIkV0Ampjsv',
          ),
          1 => 
          array (
            0 => 'doctorProfile',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1471 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AFJzXMsx6FovBFyY',
          ),
          1 => 
          array (
            0 => 'consultation',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1490 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jjCXaYoy0Hv7vwPL',
          ),
          1 => 
          array (
            0 => 'consultation',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1513 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jWa6HToC5PayyuJZ',
          ),
          1 => 
          array (
            0 => 'consultation',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1526 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::k5n9btvMshF8CSdD',
          ),
          1 => 
          array (
            0 => 'consultation',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1541 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gFlLyA3ZAL9kHuYR',
          ),
          1 => 
          array (
            0 => 'consultation',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1559 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0ar8CymyyYhtjqNq',
          ),
          1 => 
          array (
            0 => 'consultation',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1577 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FwgfsakyXESnZ3Xb',
          ),
          1 => 
          array (
            0 => 'consultation',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1593 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nlURXvF74Hkr7wMf',
          ),
          1 => 
          array (
            0 => 'consultation',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1616 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::86fnzhsndXRrcC2x',
          ),
          1 => 
          array (
            0 => 'consultation',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1659 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IQoMQSzSqHL8DwWZ',
          ),
          1 => 
          array (
            0 => 'medicineOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1699 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BeXLeIdaalEO762s',
          ),
          1 => 
          array (
            0 => 'homeVisit',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1720 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rtr92sEPnzx3yXQC',
          ),
          1 => 
          array (
            0 => 'homeVisit',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1737 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oZpFuqqtMfAYdvsK',
          ),
          1 => 
          array (
            0 => 'homeVisit',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1787 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EDNTSr7tMIC3AwNa',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bjxCh37e76i14TsW',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1823 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yAHHvN2JT8ayy1by',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1837 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::sQzmoFMR5fbIbsz7',
          ),
          1 => 
          array (
            0 => 'order',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1875 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vfV3ivSjQccU9UIO',
          ),
          1 => 
          array (
            0 => 'campaign',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      1888 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::L3a5ZI3kOZfGdPd1',
          ),
          1 => 
          array (
            0 => 'campaign',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1912 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0PJsFSnBEjY2rSvK',
          ),
          1 => 
          array (
            0 => 'ad',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      1957 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aJiMUUrt5whOoaz4',
          ),
          1 => 
          array (
            0 => 'conversation',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2003 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VvmvAJJ2i1NiGu6r',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2021 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oZ8mmDUpIAveg2qg',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2038 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H4T5F5D3WKnX0xui',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2051 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SXzoA3dorurmHahF',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2090 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nwPqM0lT7VWTWEMm',
          ),
          1 => 
          array (
            0 => 'application',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2127 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.packages.buy',
          ),
          1 => 
          array (
            0 => 'package',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2163 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.wallet.card.freeze',
          ),
          1 => 
          array (
            0 => 'card',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2199 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.lucky_draw.buy',
          ),
          1 => 
          array (
            0 => 'draw',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2230 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.lending.borrow',
          ),
          1 => 
          array (
            0 => 'offer',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2261 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.tasks.submit',
          ),
          1 => 
          array (
            0 => 'task',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2291 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.funds.invest',
          ),
          1 => 
          array (
            0 => 'fund',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2321 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.quests.claim',
          ),
          1 => 
          array (
            0 => 'userQuest',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2351 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.roadmap.vote',
          ),
          1 => 
          array (
            0 => 'module',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2388 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.crowdfunding.donate',
          ),
          1 => 
          array (
            0 => 'project',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2425 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.influencer.channels.destroy',
          ),
          1 => 
          array (
            0 => 'channel',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2453 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.support.show',
          ),
          1 => 
          array (
            0 => 'ticket',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2471 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.support.reply',
          ),
          1 => 
          array (
            0 => 'ticket',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2485 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.support.close',
          ),
          1 => 
          array (
            0 => 'ticket',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2523 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.medical.doctors.show',
          ),
          1 => 
          array (
            0 => 'doctorProfile',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2554 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'app.medical.consultation',
          ),
          1 => 
          array (
            0 => 'consultation',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2599 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.edit',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2614 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.ban',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2628 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.balance',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2639 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.update',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.users.destroy',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2681 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.admins.edit',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2693 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.admins.ban',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2706 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.admins.role',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2716 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.admins.update',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.admins.destroy',
          ),
          1 => 
          array (
            0 => 'admin',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2762 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ad-network.campaigns.edit',
          ),
          1 => 
          array (
            0 => 'campaign',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2771 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ad-network.campaigns.update',
          ),
          1 => 
          array (
            0 => 'campaign',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2810 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ai.faq.update',
          ),
          1 => 
          array (
            0 => 'faq',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.ai.faq.destroy',
          ),
          1 => 
          array (
            0 => 'faq',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2855 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.agromarket.listings.edit',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2864 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.agromarket.listings.update',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.agromarket.listings.destroy',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2903 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roles.edit',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2923 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roles.permissions',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2933 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roles.update',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roles.destroy',
          ),
          1 => 
          array (
            0 => 'role',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      2965 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roadmap.edit',
          ),
          1 => 
          array (
            0 => 'roadmap',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      2974 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roadmap.update',
          ),
          1 => 
          array (
            0 => 'roadmap',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.roadmap.destroy',
          ),
          1 => 
          array (
            0 => 'roadmap',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3005 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.deposits.show',
          ),
          1 => 
          array (
            0 => 'deposit',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3025 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.deposits.approve',
          ),
          1 => 
          array (
            0 => 'deposit',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3040 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.deposits.reject',
          ),
          1 => 
          array (
            0 => 'deposit',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3074 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.withdrawals.show',
          ),
          1 => 
          array (
            0 => 'withdrawal',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3094 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.withdrawals.approve',
          ),
          1 => 
          array (
            0 => 'withdrawal',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3109 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.withdrawals.reject',
          ),
          1 => 
          array (
            0 => 'withdrawal',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3148 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.packages.edit',
          ),
          1 => 
          array (
            0 => 'package',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3157 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.packages.update',
          ),
          1 => 
          array (
            0 => 'package',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.packages.destroy',
          ),
          1 => 
          array (
            0 => 'package',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3198 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment_methods.edit',
          ),
          1 => 
          array (
            0 => 'payment_method',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3207 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment_methods.update',
          ),
          1 => 
          array (
            0 => 'payment_method',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.payment_methods.destroy',
          ),
          1 => 
          array (
            0 => 'payment_method',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3246 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.stations.edit',
          ),
          1 => 
          array (
            0 => 'station',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3255 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.stations.update',
          ),
          1 => 
          array (
            0 => 'station',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.stations.destroy',
          ),
          1 => 
          array (
            0 => 'station',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3288 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.savings.edit',
          ),
          1 => 
          array (
            0 => 'saving',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3297 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.savings.update',
          ),
          1 => 
          array (
            0 => 'saving',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3325 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.support.show',
          ),
          1 => 
          array (
            0 => 'ticket',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3340 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.support.reply',
          ),
          1 => 
          array (
            0 => 'ticket',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3349 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.support.update',
          ),
          1 => 
          array (
            0 => 'ticket',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3395 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.translations.edit',
          ),
          1 => 
          array (
            0 => 'translation',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3404 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.translations.update',
          ),
          1 => 
          array (
            0 => 'translation',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.translations.destroy',
          ),
          1 => 
          array (
            0 => 'translation',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3426 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.translations.clear-cache',
          ),
          1 => 
          array (
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3460 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.tasks.edit',
          ),
          1 => 
          array (
            0 => 'task',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3476 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.tasks.approve',
          ),
          1 => 
          array (
            0 => 'userTask',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3491 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.tasks.reject',
          ),
          1 => 
          array (
            0 => 'userTask',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3501 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.tasks.update',
          ),
          1 => 
          array (
            0 => 'task',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.tasks.destroy',
          ),
          1 => 
          array (
            0 => 'task',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3532 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.tokens.update',
          ),
          1 => 
          array (
            0 => 'asset',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3574 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leaders.toggle',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3586 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.leaders.tree',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3624 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lending.loans.edit',
          ),
          1 => 
          array (
            0 => 'loan',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3633 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lending.loans.update',
          ),
          1 => 
          array (
            0 => 'loan',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3674 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lucky-draw.edit',
          ),
          1 => 
          array (
            0 => 'lucky_draw',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3687 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lucky-draw.draw',
          ),
          1 => 
          array (
            0 => 'luckyDraw',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3697 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lucky-draw.update',
          ),
          1 => 
          array (
            0 => 'lucky_draw',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.lucky-draw.destroy',
          ),
          1 => 
          array (
            0 => 'lucky_draw',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3735 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.kyc.show',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3755 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.kyc.approve',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3770 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.kyc.reject',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3797 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.kyc.face.show',
          ),
          1 => 
          array (
            0 => 'attempt',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3817 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.kyc.face.approve',
          ),
          1 => 
          array (
            0 => 'attempt',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3832 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.kyc.face.reject',
          ),
          1 => 
          array (
            0 => 'attempt',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3867 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quests.edit',
          ),
          1 => 
          array (
            0 => 'quest',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3876 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quests.update',
          ),
          1 => 
          array (
            0 => 'quest',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.quests.destroy',
          ),
          1 => 
          array (
            0 => 'quest',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3911 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.funds.edit',
          ),
          1 => 
          array (
            0 => 'fund',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      3920 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.funds.update',
          ),
          1 => 
          array (
            0 => 'fund',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.funds.destroy',
          ),
          1 => 
          array (
            0 => 'fund',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3944 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.faq.update',
          ),
          1 => 
          array (
            0 => 'faq',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.faq.destroy',
          ),
          1 => 
          array (
            0 => 'faq',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3976 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.fraud.user-detail',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      3992 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.fraud.ban',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4006 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.fraud.unban',
          ),
          1 => 
          array (
            0 => 'user',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4029 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.fraud.flag.remove',
          ),
          1 => 
          array (
            0 => 'user',
            1 => 'flag',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4084 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.promo-codes.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.promo-codes.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4099 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.promo-codes.stats',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4139 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.spin-wheel.prize.update',
          ),
          1 => 
          array (
            0 => 'prize',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.spin-wheel.prize.destroy',
          ),
          1 => 
          array (
            0 => 'prize',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4167 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.events.update',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketing.events.destroy',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4200 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketplace.edit',
          ),
          1 => 
          array (
            0 => 'marketplace',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4209 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketplace.update',
          ),
          1 => 
          array (
            0 => 'marketplace',
          ),
          2 => 
          array (
            'PUT' => 0,
            'PATCH' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.marketplace.destroy',
          ),
          1 => 
          array (
            0 => 'marketplace',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.doctors.show',
          ),
          1 => 
          array (
            0 => 'doctorProfile',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4269 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.doctors.approve',
          ),
          1 => 
          array (
            0 => 'doctorProfile',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4287 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.doctors.reject',
          ),
          1 => 
          array (
            0 => 'doctorProfile',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4304 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.doctors.reactivate',
          ),
          1 => 
          array (
            0 => 'doctorProfile',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4321 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.doctors.suspend',
          ),
          1 => 
          array (
            0 => 'doctorProfile',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4357 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.consultations.show',
          ),
          1 => 
          array (
            0 => 'consultation',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4390 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.complaints.review',
          ),
          1 => 
          array (
            0 => 'complaint',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4435 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.medicine-orders.status',
          ),
          1 => 
          array (
            0 => 'medicineOrder',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4457 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.medicines.update',
          ),
          1 => 
          array (
            0 => 'medicine',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.medical.medicines.destroy',
          ),
          1 => 
          array (
            0 => 'medicine',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4508 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.crowdfunding.approve',
          ),
          1 => 
          array (
            0 => 'project',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4523 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.crowdfunding.reject',
          ),
          1 => 
          array (
            0 => 'project',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4543 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.crowdfunding.expenses.store',
          ),
          1 => 
          array (
            0 => 'project',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.crowdfunding.expenses.index',
          ),
          1 => 
          array (
            0 => 'project',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4576 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.credits.edit',
          ),
          1 => 
          array (
            0 => 'credit',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4585 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.credits.update',
          ),
          1 => 
          array (
            0 => 'credit',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4628 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.catalog.shops.edit',
          ),
          1 => 
          array (
            0 => 'shop',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4637 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.catalog.shops.update',
          ),
          1 => 
          array (
            0 => 'shop',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4672 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.catalog.products.edit',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4681 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.catalog.products.update',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.catalog.products.destroy',
          ),
          1 => 
          array (
            0 => 'product',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4731 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.gig-economy.listings.edit',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4740 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.gig-economy.listings.update',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.gig-economy.listings.destroy',
          ),
          1 => 
          array (
            0 => 'listing',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4795 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.channels.approve',
          ),
          1 => 
          array (
            0 => 'channel',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4810 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.channels.reject',
          ),
          1 => 
          array (
            0 => 'channel',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4826 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.channels.suspend',
          ),
          1 => 
          array (
            0 => 'channel',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4861 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.campaigns.edit',
          ),
          1 => 
          array (
            0 => 'campaign',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4870 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.campaigns.update',
          ),
          1 => 
          array (
            0 => 'campaign',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.campaigns.destroy',
          ),
          1 => 
          array (
            0 => 'campaign',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      4912 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.submissions.approve',
          ),
          1 => 
          array (
            0 => 'submission',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4927 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.influencer.submissions.reject',
          ),
          1 => 
          array (
            0 => 'submission',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4964 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.education.edit',
          ),
          1 => 
          array (
            0 => 'education',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      4973 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'admin.education.update',
          ),
          1 => 
          array (
            0 => 'education',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'admin.education.destroy',
          ),
          1 => 
          array (
            0 => 'education',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5006 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'register.ref',
          ),
          1 => 
          array (
            0 => 'ref',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5037 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'password.reset',
          ),
          1 => 
          array (
            0 => 'token',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5063 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'locale.switch',
          ),
          1 => 
          array (
            0 => 'lang',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      5088 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => 
          array (
            '_route' => 'storage.local.upload',
          ),
          1 => 
          array (
            0 => 'path',
          ),
          2 => 
          array (
            'PUT' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        2 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'generated::ryihFgAAULS06G5m' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/auth/telegram',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'throttle:auth-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AuthController@telegramAuth',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AuthController@telegramAuth',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ryihFgAAULS06G5m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OauSvxFCUB717ozZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/telegram/webhook',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\TelegramBotController@webhook',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\TelegramBotController@webhook',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::OauSvxFCUB717ozZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HuvmhXHmUzrf35LN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/telegram/admin-webhook',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\AdminTelegramController@handle',
        'controller' => 'App\\Http\\Controllers\\Api\\AdminTelegramController@handle',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::HuvmhXHmUzrf35LN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Q8ZBDVf7Pc5W9HKL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\DashboardController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::Q8ZBDVf7Pc5W9HKL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JjpwWyUZO2boI9Ns' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/wallet',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\WalletController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\WalletController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/wallet',
        'where' => 
        array (
        ),
        'as' => 'generated::JjpwWyUZO2boI9Ns',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::u0kKy9vxA1y0UgVZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/wallet/transfer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\WalletController@transfer',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\WalletController@transfer',
        'namespace' => NULL,
        'prefix' => 'api/v1/wallet',
        'where' => 
        array (
        ),
        'as' => 'generated::u0kKy9vxA1y0UgVZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OiRGG8exYORvBWPr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/wallet/convert',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\WalletController@convert',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\WalletController@convert',
        'namespace' => NULL,
        'prefix' => 'api/v1/wallet',
        'where' => 
        array (
        ),
        'as' => 'generated::OiRGG8exYORvBWPr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::meCT67JqwTNeiZDN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/wallet/card',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\WalletController@createCard',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\WalletController@createCard',
        'namespace' => NULL,
        'prefix' => 'api/v1/wallet',
        'where' => 
        array (
        ),
        'as' => 'generated::meCT67JqwTNeiZDN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::18OckZ8UaMElyBSK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/packages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\PackageController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\PackageController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::18OckZ8UaMElyBSK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ruROBiDTsXaJ5UmM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/packages/{package}/buy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\PackageController@buy',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\PackageController@buy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ruROBiDTsXaJ5UmM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::j0NMh2BCNtD6wnzN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/deposits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\DepositController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\DepositController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::j0NMh2BCNtD6wnzN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vFTGxYBTbIrS15sx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/deposits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\DepositController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\DepositController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::vFTGxYBTbIrS15sx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3AkMieSaeoLvdTuz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/withdrawals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\WithdrawalController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\WithdrawalController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::3AkMieSaeoLvdTuz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1Chgns7nYhdcIcjt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/withdrawals/scoring',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\WithdrawalController@scoring',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\WithdrawalController@scoring',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::1Chgns7nYhdcIcjt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xKCpaAlJjIAkeaBX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/withdrawals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\WithdrawalController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\WithdrawalController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::xKCpaAlJjIAkeaBX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1NgmivgV2xvr2XyA' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/level',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LevelController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LevelController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::1NgmivgV2xvr2XyA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::acDISJgJYmFJ9hAu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/level/xp-history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LevelController@xpHistory',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LevelController@xpHistory',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::acDISJgJYmFJ9hAu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xutp4D7Uroep420p' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/level/leaderboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LevelController@leaderboard',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LevelController@leaderboard',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::xutp4D7Uroep420p',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::270guoj7TY4JggGK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/level/milestones',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LevelController@milestones',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LevelController@milestones',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::270guoj7TY4JggGK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZL3z4xRhsFqOEn7R' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/quests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\QuestController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\QuestController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ZL3z4xRhsFqOEn7R',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wW3L5dhyeorwXOFg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/quests/{userQuest}/claim',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\QuestController@claim',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\QuestController@claim',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::wW3L5dhyeorwXOFg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Bae9pUdT2mv0kwUD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/quests/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\QuestController@stats',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\QuestController@stats',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::Bae9pUdT2mv0kwUD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WJtYKDoMdEV3ML0M' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/tasks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\TaskController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\TaskController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::WJtYKDoMdEV3ML0M',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jDFo5GDipFy3RQPb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/tasks/{task}/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\TaskController@submit',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\TaskController@submit',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::jDFo5GDipFy3RQPb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZZZV1AOr5u3aDZF1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/checkin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CheckInController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CheckInController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ZZZV1AOr5u3aDZF1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JzSOKUCYVzNSRDfV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/lucky-draw',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LuckyDrawController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LuckyDrawController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::JzSOKUCYVzNSRDfV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lnuXZ29WOKe2DV35' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/lucky-draw/{draw}/buy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LuckyDrawController@buy',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LuckyDrawController@buy',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::lnuXZ29WOKe2DV35',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qRBG4B9I3onGdVXS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/funds',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\FundController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\FundController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::qRBG4B9I3onGdVXS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XCOY1mUQradH8sGJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/funds/{fund}/invest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\FundController@invest',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\FundController@invest',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::XCOY1mUQradH8sGJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QXVdB2Yhx1MpaLez' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/kyc/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\KycController@status',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\KycController@status',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::QXVdB2Yhx1MpaLez',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ONQW6f27Aum40ctU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/kyc/passport',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:3,60',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\KycController@submitPassport',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\KycController@submitPassport',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ONQW6f27Aum40ctU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0tunFI56ALu8eIso' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/kyc/face/start',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\FaceKycController@start',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\FaceKycController@start',
        'namespace' => NULL,
        'prefix' => 'api/v1/kyc/face',
        'where' => 
        array (
        ),
        'as' => 'generated::0tunFI56ALu8eIso',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YJ9H6ZVToAOQLCEg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/kyc/face/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:3,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\FaceKycController@submit',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\FaceKycController@submit',
        'namespace' => NULL,
        'prefix' => 'api/v1/kyc/face',
        'where' => 
        array (
        ),
        'as' => 'generated::YJ9H6ZVToAOQLCEg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lnSpkNMqQ8OXCh4g' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/kyc/face/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\FaceKycController@status',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\FaceKycController@status',
        'namespace' => NULL,
        'prefix' => 'api/v1/kyc/face',
        'where' => 
        array (
        ),
        'as' => 'generated::lnSpkNMqQ8OXCh4g',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BJj6rrcGgaItz654' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/referrals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ReferralController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ReferralController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::BJj6rrcGgaItz654',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gubCBBhHsYadRrRl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/transactions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\TransactionController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\TransactionController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::gubCBBhHsYadRrRl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::68v9cQoHLc89v0eF' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/credits/rating',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CreditController@rating',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CreditController@rating',
        'namespace' => NULL,
        'prefix' => 'api/v1/credits',
        'where' => 
        array (
        ),
        'as' => 'generated::68v9cQoHLc89v0eF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LkeJPRNnTvCyalnM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/credits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CreditController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CreditController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/credits',
        'where' => 
        array (
        ),
        'as' => 'generated::LkeJPRNnTvCyalnM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MfUWqgHs87O65TSs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/credits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CreditController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CreditController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/credits',
        'where' => 
        array (
        ),
        'as' => 'generated::MfUWqgHs87O65TSs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZgNeMUb3RXTzwxRa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/credits/{credit}/repay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CreditController@repay',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CreditController@repay',
        'namespace' => NULL,
        'prefix' => 'api/v1/credits',
        'where' => 
        array (
        ),
        'as' => 'generated::ZgNeMUb3RXTzwxRa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5vZP1UwOrS9JAZTX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/savings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SavingsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SavingsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/savings',
        'where' => 
        array (
        ),
        'as' => 'generated::5vZP1UwOrS9JAZTX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uDJgWZNE905PNhSO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/savings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SavingsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SavingsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/savings',
        'where' => 
        array (
        ),
        'as' => 'generated::uDJgWZNE905PNhSO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::P3Ra1foPc5iXVC9B' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/savings/{plan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SavingsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SavingsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/savings',
        'where' => 
        array (
        ),
        'as' => 'generated::P3Ra1foPc5iXVC9B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WdgEChsok1cX9f2F' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/savings/{plan}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SavingsController@cancel',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SavingsController@cancel',
        'namespace' => NULL,
        'prefix' => 'api/v1/savings',
        'where' => 
        array (
        ),
        'as' => 'generated::WdgEChsok1cX9f2F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::N3JjKs6Ceddo5IuA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/saving-groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GroupSavingsController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GroupSavingsController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/saving-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::N3JjKs6Ceddo5IuA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jfO7CCzBg5s4BwjP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/saving-groups',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GroupSavingsController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GroupSavingsController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/saving-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::jfO7CCzBg5s4BwjP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eiVDgeEPxpAomu4o' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/saving-groups/{savingGroup}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GroupSavingsController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GroupSavingsController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/saving-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::eiVDgeEPxpAomu4o',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TGtr4jttqECIR3jI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/saving-groups/{savingGroup}/join',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GroupSavingsController@join',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GroupSavingsController@join',
        'namespace' => NULL,
        'prefix' => 'api/v1/saving-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::TGtr4jttqECIR3jI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kBoFnCe1xmz4syIX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/saving-groups/{savingGroup}/approve/{member}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GroupSavingsController@approve',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GroupSavingsController@approve',
        'namespace' => NULL,
        'prefix' => 'api/v1/saving-groups',
        'where' => 
        array (
        ),
        'as' => 'generated::kBoFnCe1xmz4syIX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::L1eZS5Bb01nDLi0l' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ProfileController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ProfileController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::L1eZS5Bb01nDLi0l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yPHj8KR1QCr3nRmB' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ProfileController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::yPHj8KR1QCr3nRmB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XyJZit8MfIgOp621' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/security/2fa',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SecurityController@getTwoFactorStatus',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SecurityController@getTwoFactorStatus',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::XyJZit8MfIgOp621',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ccZoIUf7LUwzGSwA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/security/2fa/enable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SecurityController@enableTwoFactor',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SecurityController@enableTwoFactor',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ccZoIUf7LUwzGSwA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::v7HGW1qDG83IIbGR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/security/2fa/disable',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SecurityController@disableTwoFactor',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SecurityController@disableTwoFactor',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::v7HGW1qDG83IIbGR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WFfHkazbvVNZ42V8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/promo/redeem',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\PromoCodeController@redeem',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\PromoCodeController@redeem',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::WFfHkazbvVNZ42V8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GQC4FK12zNz98DKR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/spin-wheel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SpinWheelController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SpinWheelController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::GQC4FK12zNz98DKR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qmYtdF1bEMJytR8W' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/spin-wheel/spin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:3,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SpinWheelController@spin',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SpinWheelController@spin',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::qmYtdF1bEMJytR8W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fUhpR4ne3YzAFLf2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/badges',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\BadgeController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\BadgeController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::fUhpR4ne3YzAFLf2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vtKCi1wjGEh10TCC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/share',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ShareController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ShareController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::vtKCi1wjGEh10TCC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::U2YyEfpwtCl5wRCS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/invite-challenge',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\InviteChallengeController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\InviteChallengeController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::U2YyEfpwtCl5wRCS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VHj2DTyvJLmyb2ct' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/invite-challenge/start',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:3,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\InviteChallengeController@start',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\InviteChallengeController@start',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::VHj2DTyvJLmyb2ct',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::s2TsUIBroVNX9Zxz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/onboarding',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\OnboardingController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\OnboardingController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::s2TsUIBroVNX9Zxz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::noJUitws583GVABM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/competitions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LeaderboardChallengeController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LeaderboardChallengeController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::noJUitws583GVABM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::K0EEVLP5SgrLTbXd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/competitions/history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LeaderboardChallengeController@history',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LeaderboardChallengeController@history',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::K0EEVLP5SgrLTbXd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ipxJEw1jzkYYITnD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/events',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SeasonalEventController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SeasonalEventController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::ipxJEw1jzkYYITnD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::R4WKou89c3kYjGWL' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/events/{event}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SeasonalEventController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SeasonalEventController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::R4WKou89c3kYjGWL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::b7wWBqRa4qGgQSGg' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/social-proof',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\SocialProofController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\SocialProofController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::b7wWBqRa4qGgQSGg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::irdiwc3QJUBZoTFX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/qr-referral',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\QrReferralController@generate',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\QrReferralController@generate',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::irdiwc3QJUBZoTFX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jBoq97TZweJwML59' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/qr-referral/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\QrReferralController@download',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\QrReferralController@download',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::jBoq97TZweJwML59',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wZupFFgzJpy7HRkh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/referral-tree',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ReferralTreeController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ReferralTreeController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::wZupFFgzJpy7HRkh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8BV0ql8mEuB8UaYE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/referral-tree/level/{level}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ReferralTreeController@level',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ReferralTreeController@level',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::8BV0ql8mEuB8UaYE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::agWs047tvNYyGDKq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/vip',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\VipMembershipController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\VipMembershipController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::agWs047tvNYyGDKq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jTWDEUuLvY752dJ6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/roadmap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\RoadmapController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\RoadmapController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::jTWDEUuLvY752dJ6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hwNhk9OCKvjdFA6B' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/roadmap/{id}/vote',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\RoadmapController@vote',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\RoadmapController@vote',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::hwNhk9OCKvjdFA6B',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8UPK0Y16u6pxrbM6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/roadmap/{id}/notify',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\RoadmapController@notify',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\RoadmapController@notify',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::8UPK0Y16u6pxrbM6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::y0yCplG6BYiwn7Nk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/marketplace/categories',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@categories',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@categories',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::y0yCplG6BYiwn7Nk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::plxRNiHcufPFyFq0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/marketplace/gigs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@gigIndex',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@gigIndex',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::plxRNiHcufPFyFq0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0PcVhyeFMwVq5qvV' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/marketplace/gigs/{gig}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@gigShow',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@gigShow',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::0PcVhyeFMwVq5qvV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FdpkROqqbbwuhFMX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/marketplace/gigs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@gigStore',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@gigStore',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::FdpkROqqbbwuhFMX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9LvndSWphgVmjbpN' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/marketplace/gigs/{gig}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@gigUpdate',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@gigUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::9LvndSWphgVmjbpN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::B138wAV17JwHVtwE' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/marketplace/gigs/{gig}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@gigDestroy',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@gigDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::B138wAV17JwHVtwE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ci5dGotNow95AzUe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/marketplace/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderStore',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderStore',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::ci5dGotNow95AzUe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OKndhWTXwrGUljdr' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/marketplace/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderIndex',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderIndex',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::OKndhWTXwrGUljdr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::r8pYMm5JnCHWmjty' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/marketplace/orders/{order}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderShow',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderShow',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::r8pYMm5JnCHWmjty',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NhcCSkmrv5taNLps' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/marketplace/orders/{order}/accept',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderAccept',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderAccept',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::NhcCSkmrv5taNLps',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0yo11M4s4dbLOYgS' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/marketplace/orders/{order}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderReject',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderReject',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::0yo11M4s4dbLOYgS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xBMXb8fry7NgMnQu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/marketplace/orders/{order}/deliver',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderDeliver',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderDeliver',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::xBMXb8fry7NgMnQu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::izqVkJhEgD686FCX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/marketplace/orders/{order}/complete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderComplete',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@orderComplete',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::izqVkJhEgD686FCX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::33nlzjTmosdK558a' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/marketplace/orders/{order}/dispute',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@disputeStore',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@disputeStore',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::33nlzjTmosdK558a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::N4ZtjWgq5sYpEQwj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/marketplace/disputes/{dispute}/resolve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@disputeResolve',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@disputeResolve',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::N4ZtjWgq5sYpEQwj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bzm2jmSX1NDrPFiW' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/marketplace/orders/{order}/review',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@reviewStore',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@reviewStore',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::bzm2jmSX1NDrPFiW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qBhoKbq58NHr3s8D' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/marketplace/sellers/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@sellerProfile',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MarketplaceController@sellerProfile',
        'namespace' => NULL,
        'prefix' => 'api/v1/marketplace',
        'where' => 
        array (
        ),
        'as' => 'generated::qBhoKbq58NHr3s8D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::o8Qd8ABpEWc67pWB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/exchange/order-book',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@orderBook',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@orderBook',
        'namespace' => NULL,
        'prefix' => 'api/v1/exchange',
        'where' => 
        array (
        ),
        'as' => 'generated::o8Qd8ABpEWc67pWB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sSSl9eEDe6e6o8WK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/exchange/ticker',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@ticker',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@ticker',
        'namespace' => NULL,
        'prefix' => 'api/v1/exchange',
        'where' => 
        array (
        ),
        'as' => 'generated::sSSl9eEDe6e6o8WK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Jfcp9Fc9TiPljppo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/exchange/trades/recent',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@recentTrades',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@recentTrades',
        'namespace' => NULL,
        'prefix' => 'api/v1/exchange',
        'where' => 
        array (
        ),
        'as' => 'generated::Jfcp9Fc9TiPljppo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nPvR51VA1twHaSgM' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/exchange/candles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@candles',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@candles',
        'namespace' => NULL,
        'prefix' => 'api/v1/exchange',
        'where' => 
        array (
        ),
        'as' => 'generated::nPvR51VA1twHaSgM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JTPNIGtIDCAUUCPv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/exchange/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@placeOrder',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@placeOrder',
        'namespace' => NULL,
        'prefix' => 'api/v1/exchange',
        'where' => 
        array (
        ),
        'as' => 'generated::JTPNIGtIDCAUUCPv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Zs43RLhNNlKiEXUl' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/exchange/orders/{order}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@cancelOrder',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@cancelOrder',
        'namespace' => NULL,
        'prefix' => 'api/v1/exchange',
        'where' => 
        array (
        ),
        'as' => 'generated::Zs43RLhNNlKiEXUl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lCIzZc4K6X5fvLCo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/exchange/orders/open',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@myOpenOrders',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@myOpenOrders',
        'namespace' => NULL,
        'prefix' => 'api/v1/exchange',
        'where' => 
        array (
        ),
        'as' => 'generated::lCIzZc4K6X5fvLCo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZRQpUJv6omg4kqrK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/exchange/orders/history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@myOrderHistory',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@myOrderHistory',
        'namespace' => NULL,
        'prefix' => 'api/v1/exchange',
        'where' => 
        array (
        ),
        'as' => 'generated::ZRQpUJv6omg4kqrK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sCyVB2yAAlRADSh8' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/exchange/trades/my',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@myTrades',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ExchangeController@myTrades',
        'namespace' => NULL,
        'prefix' => 'api/v1/exchange',
        'where' => 
        array (
        ),
        'as' => 'generated::sCyVB2yAAlRADSh8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DPZmzvD0HHbLOBrU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/catalog/shops',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@shopStore',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@shopStore',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::DPZmzvD0HHbLOBrU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a2und98mWPBZvyaa' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/catalog/shops/{shop}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@shopUpdate',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@shopUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::a2und98mWPBZvyaa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8fresx61K79flZKJ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/shops',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@shopIndex',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@shopIndex',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::8fresx61K79flZKJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3t8BMJ3oQoVDH7GY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/shops/{shop}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@shopShow',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@shopShow',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::3t8BMJ3oQoVDH7GY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kKrHXZOLUsHeLWaw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/catalog/shops/{shop}/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@productStore',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@productStore',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::kKrHXZOLUsHeLWaw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gi4SX7rDFJIbwU4e' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/catalog/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@productUpdate',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@productUpdate',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::gi4SX7rDFJIbwU4e',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xUFP2cBscRA1SM7r' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'api/v1/catalog/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@productDestroy',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@productDestroy',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::xUFP2cBscRA1SM7r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CAsbsd6X1z4GBnWO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@productIndex',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@productIndex',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::CAsbsd6X1z4GBnWO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lfZt8OgqkGUZsalr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/catalog/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@orderStore',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@orderStore',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::lfZt8OgqkGUZsalr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IHqI4ORfDsTu4Wzt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/catalog/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@orderIndex',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@orderIndex',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::IHqI4ORfDsTu4Wzt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e5NY3QshLjjTcbKc' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/catalog/orders/{order}/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@orderConfirm',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@orderConfirm',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::e5NY3QshLjjTcbKc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5767XPZfYOEe0ADP' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/catalog/orders/{order}/deliver',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@orderDeliver',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@orderDeliver',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::5767XPZfYOEe0ADP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gr74ci8El0jI4ADi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/catalog/orders/{order}/complete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@orderComplete',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@orderComplete',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::gr74ci8El0jI4ADi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IvVK92UPSAv20VX0' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/catalog/orders/{order}/review',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@reviewStore',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CatalogController@reviewStore',
        'namespace' => NULL,
        'prefix' => 'api/v1/catalog',
        'where' => 
        array (
        ),
        'as' => 'generated::IvVK92UPSAv20VX0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CLJNLdhukbC4L2yc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/certificates/verify/{code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CertificateController@verify',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CertificateController@verify',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::CLJNLdhukbC4L2yc',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OTpD1TxDTBnudJJ4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/courses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::OTpD1TxDTBnudJJ4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::v9lYjX1W4fJ3eqso' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/courses/my-purchases',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@myPurchases',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@myPurchases',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::v9lYjX1W4fJ3eqso',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e5XmQdhkoFWJQ9uw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/courses/{course}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::e5XmQdhkoFWJQ9uw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RboZmYLaWs8gJ9FN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/courses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::RboZmYLaWs8gJ9FN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IX9zegup8OgaQXbL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/courses/{course}/lessons',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@addLesson',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@addLesson',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::IX9zegup8OgaQXbL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lIbiBGHQL7Oe7Cna' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/courses/{course}/publish',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@publish',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@publish',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::lIbiBGHQL7Oe7Cna',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Vn9zLfs9k8wCXfy7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/courses/{course}/purchase',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@purchase',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::Vn9zLfs9k8wCXfy7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uvAOIml7V8a5IfBk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/courses/lessons/{lesson}/complete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@completeLesson',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CourseController@completeLesson',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::uvAOIml7V8a5IfBk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XVvlHjkdLflLQGhp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/certificates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CertificateController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CertificateController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::XVvlHjkdLflLQGhp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::L01CXSpblFFPYIS9' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/certificates/{certificate}/download',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CertificateController@download',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CertificateController@download',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::L01CXSpblFFPYIS9',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QNaFKIMVkNHuk4Zp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/mentors',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::QNaFKIMVkNHuk4Zp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4tOD2qbvzDWm6euE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/mentors/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@createProfile',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@createProfile',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::4tOD2qbvzDWm6euE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Drab9mdYi0ayZ0lq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/mentors/{mentor}/request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@requestSession',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@requestSession',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::Drab9mdYi0ayZ0lq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::daZSS5fRTBoS46ct' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/mentor-sessions/{session}/accept',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@acceptSession',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@acceptSession',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::daZSS5fRTBoS46ct',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pDMUdKpABHXRlTKJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/mentor-sessions/{session}/complete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@completeSession',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@completeSession',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::pDMUdKpABHXRlTKJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lY6ioncoCXOnnKts' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/mentor-sessions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@mySessions',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\MentorController@mySessions',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::lY6ioncoCXOnnKts',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4k09hVDIJCaP9us0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/crowdfunding/projects',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CrowdfundingController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CrowdfundingController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/crowdfunding',
        'where' => 
        array (
        ),
        'as' => 'generated::4k09hVDIJCaP9us0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lS8XqJl52ZZbddmd' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/crowdfunding/projects/{project}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CrowdfundingController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CrowdfundingController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/crowdfunding',
        'where' => 
        array (
        ),
        'as' => 'generated::lS8XqJl52ZZbddmd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QsoJzjlhmOnjohEN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/crowdfunding/projects',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CrowdfundingController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CrowdfundingController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/crowdfunding',
        'where' => 
        array (
        ),
        'as' => 'generated::QsoJzjlhmOnjohEN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H8LZ2TDFvucKUlD6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/crowdfunding/projects/{project}/donate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\CrowdfundingController@donate',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\CrowdfundingController@donate',
        'namespace' => NULL,
        'prefix' => 'api/v1/crowdfunding',
        'where' => 
        array (
        ),
        'as' => 'generated::H8LZ2TDFvucKUlD6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::op38d7TLJ0Jf2X5l' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/agromarket/listings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@listings',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@listings',
        'namespace' => NULL,
        'prefix' => 'api/v1/agromarket',
        'where' => 
        array (
        ),
        'as' => 'generated::op38d7TLJ0Jf2X5l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EDNTSr7tMIC3AwNa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/agromarket/listings/{listing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@showListing',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@showListing',
        'namespace' => NULL,
        'prefix' => 'api/v1/agromarket',
        'where' => 
        array (
        ),
        'as' => 'generated::EDNTSr7tMIC3AwNa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XMQ9EThbTKLmNmRI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/agromarket/listings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@storeListing',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@storeListing',
        'namespace' => NULL,
        'prefix' => 'api/v1/agromarket',
        'where' => 
        array (
        ),
        'as' => 'generated::XMQ9EThbTKLmNmRI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bjxCh37e76i14TsW' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/agromarket/listings/{listing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@updateListing',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@updateListing',
        'namespace' => NULL,
        'prefix' => 'api/v1/agromarket',
        'where' => 
        array (
        ),
        'as' => 'generated::bjxCh37e76i14TsW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::l2m4IOSDcx4sg3yq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/agromarket/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@placeOrder',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@placeOrder',
        'namespace' => NULL,
        'prefix' => 'api/v1/agromarket',
        'where' => 
        array (
        ),
        'as' => 'generated::l2m4IOSDcx4sg3yq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LoW4uPI6V3WpTvNw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/agromarket/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@orders',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@orders',
        'namespace' => NULL,
        'prefix' => 'api/v1/agromarket',
        'where' => 
        array (
        ),
        'as' => 'generated::LoW4uPI6V3WpTvNw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yAHHvN2JT8ayy1by' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/agromarket/orders/{order}/confirm',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@confirmOrder',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@confirmOrder',
        'namespace' => NULL,
        'prefix' => 'api/v1/agromarket',
        'where' => 
        array (
        ),
        'as' => 'generated::yAHHvN2JT8ayy1by',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sQzmoFMR5fbIbsz7' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/agromarket/orders/{order}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@cancelOrder',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AgroMarketController@cancelOrder',
        'namespace' => NULL,
        'prefix' => 'api/v1/agromarket',
        'where' => 
        array (
        ),
        'as' => 'generated::sQzmoFMR5fbIbsz7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d9QTYHLoHfBLoLGx' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/gig-economy/listings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@listings',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@listings',
        'namespace' => NULL,
        'prefix' => 'api/v1/gig-economy',
        'where' => 
        array (
        ),
        'as' => 'generated::d9QTYHLoHfBLoLGx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VvmvAJJ2i1NiGu6r' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/gig-economy/listings/{listing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@showListing',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@showListing',
        'namespace' => NULL,
        'prefix' => 'api/v1/gig-economy',
        'where' => 
        array (
        ),
        'as' => 'generated::VvmvAJJ2i1NiGu6r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::njvhk2DbrUPTvJPj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/gig-economy/listings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@storeListing',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@storeListing',
        'namespace' => NULL,
        'prefix' => 'api/v1/gig-economy',
        'where' => 
        array (
        ),
        'as' => 'generated::njvhk2DbrUPTvJPj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oZ8mmDUpIAveg2qg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/gig-economy/listings/{listing}/apply',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@apply',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@apply',
        'namespace' => NULL,
        'prefix' => 'api/v1/gig-economy',
        'where' => 
        array (
        ),
        'as' => 'generated::oZ8mmDUpIAveg2qg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nwPqM0lT7VWTWEMm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/gig-economy/applications/{application}/accept',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@acceptApplication',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@acceptApplication',
        'namespace' => NULL,
        'prefix' => 'api/v1/gig-economy',
        'where' => 
        array (
        ),
        'as' => 'generated::nwPqM0lT7VWTWEMm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H4T5F5D3WKnX0xui' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/gig-economy/listings/{listing}/complete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@completeListing',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@completeListing',
        'namespace' => NULL,
        'prefix' => 'api/v1/gig-economy',
        'where' => 
        array (
        ),
        'as' => 'generated::H4T5F5D3WKnX0xui',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SXzoA3dorurmHahF' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/gig-economy/listings/{listing}/rate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@rate',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@rate',
        'namespace' => NULL,
        'prefix' => 'api/v1/gig-economy',
        'where' => 
        array (
        ),
        'as' => 'generated::SXzoA3dorurmHahF',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dLiAA8USKzONfCCk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/gig-economy/my-listings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@myListings',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@myListings',
        'namespace' => NULL,
        'prefix' => 'api/v1/gig-economy',
        'where' => 
        array (
        ),
        'as' => 'generated::dLiAA8USKzONfCCk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8b5TduJg689mixe5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/gig-economy/my-applications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@myApplications',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\GigEconomyController@myApplications',
        'namespace' => NULL,
        'prefix' => 'api/v1/gig-economy',
        'where' => 
        array (
        ),
        'as' => 'generated::8b5TduJg689mixe5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Hunl0voDrYggUawE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/ubi/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\UbiController@status',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\UbiController@status',
        'namespace' => NULL,
        'prefix' => 'api/v1/ubi',
        'where' => 
        array (
        ),
        'as' => 'generated::Hunl0voDrYggUawE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FCrwsYaMupN85Oqn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/ubi/claim',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:3,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\UbiController@claim',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\UbiController@claim',
        'namespace' => NULL,
        'prefix' => 'api/v1/ubi',
        'where' => 
        array (
        ),
        'as' => 'generated::FCrwsYaMupN85Oqn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3RSDAgvgrENdMuYH' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/ubi/history',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\UbiController@history',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\UbiController@history',
        'namespace' => NULL,
        'prefix' => 'api/v1/ubi',
        'where' => 
        array (
        ),
        'as' => 'generated::3RSDAgvgrENdMuYH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dF994wLjeH94cpL2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/ubi/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\UbiController@stats',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\UbiController@stats',
        'namespace' => NULL,
        'prefix' => 'api/v1/ubi',
        'where' => 
        array (
        ),
        'as' => 'generated::dF994wLjeH94cpL2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::T8gyxpIRRi85vaFT' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/ads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AdController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AdController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/ads',
        'where' => 
        array (
        ),
        'as' => 'generated::T8gyxpIRRi85vaFT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eWf5l2jknolhH2Zk' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/ads/campaigns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AdController@createCampaign',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AdController@createCampaign',
        'namespace' => NULL,
        'prefix' => 'api/v1/ads',
        'where' => 
        array (
        ),
        'as' => 'generated::eWf5l2jknolhH2Zk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DS01ZxvvgD9cdFeD' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/ads/campaigns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AdController@myCampaigns',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AdController@myCampaigns',
        'namespace' => NULL,
        'prefix' => 'api/v1/ads',
        'where' => 
        array (
        ),
        'as' => 'generated::DS01ZxvvgD9cdFeD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vfV3ivSjQccU9UIO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/ads/campaigns/{campaign}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AdController@showCampaign',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AdController@showCampaign',
        'namespace' => NULL,
        'prefix' => 'api/v1/ads',
        'where' => 
        array (
        ),
        'as' => 'generated::vfV3ivSjQccU9UIO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::L3a5ZI3kOZfGdPd1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/ads/campaigns/{campaign}/ads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AdController@createAd',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AdController@createAd',
        'namespace' => NULL,
        'prefix' => 'api/v1/ads',
        'where' => 
        array (
        ),
        'as' => 'generated::L3a5ZI3kOZfGdPd1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0PJsFSnBEjY2rSvK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/ads/{ad}/watch',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AdController@watchAd',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AdController@watchAd',
        'namespace' => NULL,
        'prefix' => 'api/v1/ads',
        'where' => 
        array (
        ),
        'as' => 'generated::0PJsFSnBEjY2rSvK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J0OzF5PizynrKi9j' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/lending/offers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@offers',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@offers',
        'namespace' => NULL,
        'prefix' => 'api/v1/lending',
        'where' => 
        array (
        ),
        'as' => 'generated::J0OzF5PizynrKi9j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BihsasoLVkPPyY8w' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/lending/offers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@createOffer',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@createOffer',
        'namespace' => NULL,
        'prefix' => 'api/v1/lending',
        'where' => 
        array (
        ),
        'as' => 'generated::BihsasoLVkPPyY8w',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UzceQXKDmpvJiiXa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/lending/offers/{offer}/accept',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@acceptOffer',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@acceptOffer',
        'namespace' => NULL,
        'prefix' => 'api/v1/lending',
        'where' => 
        array (
        ),
        'as' => 'generated::UzceQXKDmpvJiiXa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::coCm6wPeUagghGdO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/lending/offers/{offer}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@cancelOffer',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@cancelOffer',
        'namespace' => NULL,
        'prefix' => 'api/v1/lending',
        'where' => 
        array (
        ),
        'as' => 'generated::coCm6wPeUagghGdO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::sp52DdLXg0N4HjVW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/lending/loans',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@loans',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@loans',
        'namespace' => NULL,
        'prefix' => 'api/v1/lending',
        'where' => 
        array (
        ),
        'as' => 'generated::sp52DdLXg0N4HjVW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5ZMxmmJojyJT8WM2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/lending/loans/{loan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@showLoan',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@showLoan',
        'namespace' => NULL,
        'prefix' => 'api/v1/lending',
        'where' => 
        array (
        ),
        'as' => 'generated::5ZMxmmJojyJT8WM2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Jrgkkzd7tc9O5DBU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/lending/loans/{loan}/pay',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@makePayment',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\LendingController@makePayment',
        'namespace' => NULL,
        'prefix' => 'api/v1/lending',
        'where' => 
        array (
        ),
        'as' => 'generated::Jrgkkzd7tc9O5DBU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cJRozT8AV69WjbsI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/tokens/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\TokenController@assets',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\TokenController@assets',
        'namespace' => NULL,
        'prefix' => 'api/v1/tokens',
        'where' => 
        array (
        ),
        'as' => 'generated::cJRozT8AV69WjbsI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DYGKBMpDEojzyECh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/tokens/assets/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\TokenController@showAsset',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\TokenController@showAsset',
        'namespace' => NULL,
        'prefix' => 'api/v1/tokens',
        'where' => 
        array (
        ),
        'as' => 'generated::DYGKBMpDEojzyECh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FfPoJpQAUq67vG2n' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/tokens/assets/{asset}/purchase',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
          5 => 'throttle:financial-api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\TokenController@purchase',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\TokenController@purchase',
        'namespace' => NULL,
        'prefix' => 'api/v1/tokens',
        'where' => 
        array (
        ),
        'as' => 'generated::FfPoJpQAUq67vG2n',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NEVx37Upo4U5PjqP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/tokens/portfolio',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\TokenController@portfolio',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\TokenController@portfolio',
        'namespace' => NULL,
        'prefix' => 'api/v1/tokens',
        'where' => 
        array (
        ),
        'as' => 'generated::NEVx37Upo4U5PjqP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AztG5HBLtajeTkVt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/ai-assistant/ask',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AiAssistantController@ask',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AiAssistantController@ask',
        'namespace' => NULL,
        'prefix' => 'api/v1/ai-assistant',
        'where' => 
        array (
        ),
        'as' => 'generated::AztG5HBLtajeTkVt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IjhF0QwdMDdi5wn1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/ai-assistant/conversations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AiAssistantController@conversations',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AiAssistantController@conversations',
        'namespace' => NULL,
        'prefix' => 'api/v1/ai-assistant',
        'where' => 
        array (
        ),
        'as' => 'generated::IjhF0QwdMDdi5wn1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aJiMUUrt5whOoaz4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/ai-assistant/conversations/{conversation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AiAssistantController@showConversation',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AiAssistantController@showConversation',
        'namespace' => NULL,
        'prefix' => 'api/v1/ai-assistant',
        'where' => 
        array (
        ),
        'as' => 'generated::aJiMUUrt5whOoaz4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Jx3rspuVtSGQd5DP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/ai-assistant/faq',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AiAssistantController@faq',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AiAssistantController@faq',
        'namespace' => NULL,
        'prefix' => 'api/v1/ai-assistant',
        'where' => 
        array (
        ),
        'as' => 'generated::Jx3rspuVtSGQd5DP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dTKwnDtEGBLgahER' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/ai-assistant/advice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'telegram.auth',
          3 => 'set.locale.api',
          4 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\AiAssistantController@advice',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\AiAssistantController@advice',
        'namespace' => NULL,
        'prefix' => 'api/v1/ai-assistant',
        'where' => 
        array (
        ),
        'as' => 'generated::dTKwnDtEGBLgahER',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ieZNKOP9870RaN2f' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/medical/specialties',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@specialties',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@specialties',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::ieZNKOP9870RaN2f',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xrFdogtv8qZz7GHC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/medical/doctors',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::xrFdogtv8qZz7GHC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::77WTrPIkV0Ampjsv' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/medical/doctors/{doctorProfile}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::77WTrPIkV0Ampjsv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5EcPDw4miLBWipVE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/medical/doctor-profile/me',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@me',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@me',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::5EcPDw4miLBWipVE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Rpcj1xO1VuBrbBWl' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/doctor-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::Rpcj1xO1VuBrbBWl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EjQpsy8IppbsUojl' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'api/v1/medical/doctor-profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@update',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@update',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::EjQpsy8IppbsUojl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hqsrHVzuucsCDkFj' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/doctor-profile/toggle-online',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@toggleOnline',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorProfileController@toggleOnline',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::hqsrHVzuucsCDkFj',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gnVgl7jquYSQ5a03' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/medical/doctor/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorDashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\DoctorDashboardController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::gnVgl7jquYSQ5a03',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::p3UfCaXjXVINeU9F' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/medical/consultations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::p3UfCaXjXVINeU9F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dxVtzZn48T0AwlXi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/consultations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::dxVtzZn48T0AwlXi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AFJzXMsx6FovBFyY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/medical/consultations/{consultation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@show',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@show',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::AFJzXMsx6FovBFyY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jjCXaYoy0Hv7vwPL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/consultations/{consultation}/accept',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@accept',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@accept',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::jjCXaYoy0Hv7vwPL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jWa6HToC5PayyuJZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/consultations/{consultation}/complete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@complete',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@complete',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::jWa6HToC5PayyuJZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gFlLyA3ZAL9kHuYR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/consultations/{consultation}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@cancel',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@cancel',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::gFlLyA3ZAL9kHuYR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0ar8CymyyYhtjqNq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/consultations/{consultation}/messages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@sendMessage',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@sendMessage',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::0ar8CymyyYhtjqNq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FwgfsakyXESnZ3Xb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/consultations/{consultation}/review',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@review',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@review',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::FwgfsakyXESnZ3Xb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::k5n9btvMshF8CSdD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/consultations/{consultation}/complaint',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@complaint',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\ConsultationController@complaint',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::k5n9btvMshF8CSdD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::86fnzhsndXRrcC2x' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/consultations/{consultation}/prescriptions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\PrescriptionController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\PrescriptionController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::86fnzhsndXRrcC2x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NFP0Wqb60WZlK3rz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/medical/medicines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\PrescriptionController@medicines',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\PrescriptionController@medicines',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::NFP0Wqb60WZlK3rz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nlURXvF74Hkr7wMf' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/consultations/{consultation}/referrals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\MedicalReferralController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\MedicalReferralController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::nlURXvF74Hkr7wMf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::DtqhixHbIumo2ip0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/medical/medicine-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\MedicineOrderController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\MedicineOrderController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::DtqhixHbIumo2ip0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::w1UYhoi6yuu4vXUq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/medicine-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\MedicineOrderController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\MedicineOrderController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::w1UYhoi6yuu4vXUq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IQoMQSzSqHL8DwWZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/medicine-orders/{medicineOrder}/cancel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\MedicineOrderController@cancel',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\MedicineOrderController@cancel',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::IQoMQSzSqHL8DwWZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dLH3voyOQsaDGnyl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/medical/home-visits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\HomeVisitController@index',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\HomeVisitController@index',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::dLH3voyOQsaDGnyl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hbffomkW9MuXx1ZX' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/home-visits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\HomeVisitController@store',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\HomeVisitController@store',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::hbffomkW9MuXx1ZX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BeXLeIdaalEO762s' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/home-visits/{homeVisit}/accept',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\HomeVisitController@accept',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\HomeVisitController@accept',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::BeXLeIdaalEO762s',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rtr92sEPnzx3yXQC' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/home-visits/{homeVisit}/on-the-way',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\HomeVisitController@onTheWay',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\HomeVisitController@onTheWay',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::rtr92sEPnzx3yXQC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oZpFuqqtMfAYdvsK' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'api/v1/medical/home-visits/{homeVisit}/complete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
          2 => 'force.json',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\HomeVisitController@complete',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\Medical\\HomeVisitController@complete',
        'namespace' => NULL,
        'prefix' => 'api/v1/medical',
        'where' => 
        array (
        ),
        'as' => 'generated::oZpFuqqtMfAYdvsK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WOvzEzB6kWB2ZX5L' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/v1/s/{code}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
        ),
        'uses' => 'App\\Http\\Controllers\\Api\\V1\\ShareController@track',
        'controller' => 'App\\Http\\Controllers\\Api\\V1\\ShareController@track',
        'namespace' => NULL,
        'prefix' => 'api/v1',
        'where' => 
        array (
        ),
        'as' => 'generated::WOvzEzB6kWB2ZX5L',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::3gRVYfe8S8klv5KX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'up',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:836:"function () {
                    $exception = null;

                    try {
                        \\Illuminate\\Support\\Facades\\Event::dispatch(new \\Illuminate\\Foundation\\Events\\DiagnosingHealth);
                    } catch (\\Throwable $e) {
                        if (app()->hasDebugModeEnabled()) {
                            throw $e;
                        }

                        report($e);

                        $exception = $e->getMessage();
                    }

                    return response(\\Illuminate\\Support\\Facades\\View::file(\'/var/www/69abbde93330e/data/www/aisoqqa.uz/vendor/laravel/framework/src/Illuminate/Foundation/Configuration\'.\'/../resources/health-up.blade.php\', [
                        \'exception\' => $exception,
                    ]), status: $exception ? 500 : 200);
                }";s:5:"scope";s:54:"Illuminate\\Foundation\\Configuration\\ApplicationBuilder";s:4:"this";N;s:4:"self";s:32:"0000000000000ff20000000000000000";}}',
        'as' => 'generated::3gRVYfe8S8klv5KX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'home' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\HomeController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\HomeController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'home',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'presentation' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'presentation',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:42:"function () {
    return \\redirect(\'/\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000f360000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'presentation',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'offline' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'offline',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:56:"function () {
    return \\view(\'front.pages.offline\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000f1b0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'offline',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'pwa.manifest' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'manifest.json',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:2514:"function () {
    $setting = \\App\\Models\\Setting::get();
    $siteName = $setting->getTranslation(\'site_name\', \'uz\') ?: \\config(\'app.name\');
    $siteDesc = $setting->getTranslation(\'site_description\', \'uz\') ?: \'Investitsiya va moliyaviy platforma\';

    $manifest = [
        \'name\'             => $siteName,
        \'short_name\'       => \\mb_substr($siteName, 0, 12),
        \'description\'      => $siteDesc,
        \'start_url\'        => \'/app\',
        \'scope\'            => \'/\',
        \'display\'          => \'standalone\',
        \'orientation\'      => \'portrait\',
        \'background_color\' => \'#0f172a\',
        \'theme_color\'      => \'#6366f1\',
        \'lang\'             => \'uz\',
        \'categories\'       => [\'finance\', \'business\'],
        \'icons\'            => [
            [\'src\' => \'/images/pwa/icon-72.png\',  \'sizes\' => \'72x72\',   \'type\' => \'image/png\', \'purpose\' => \'any maskable\'],
            [\'src\' => \'/images/pwa/icon-96.png\',  \'sizes\' => \'96x96\',   \'type\' => \'image/png\', \'purpose\' => \'any maskable\'],
            [\'src\' => \'/images/pwa/icon-128.png\', \'sizes\' => \'128x128\', \'type\' => \'image/png\', \'purpose\' => \'any maskable\'],
            [\'src\' => \'/images/pwa/icon-144.png\', \'sizes\' => \'144x144\', \'type\' => \'image/png\', \'purpose\' => \'any maskable\'],
            [\'src\' => \'/images/pwa/icon-152.png\', \'sizes\' => \'152x152\', \'type\' => \'image/png\', \'purpose\' => \'any maskable\'],
            [\'src\' => \'/images/pwa/icon-192.png\', \'sizes\' => \'192x192\', \'type\' => \'image/png\', \'purpose\' => \'any maskable\'],
            [\'src\' => \'/images/pwa/icon-384.png\', \'sizes\' => \'384x384\', \'type\' => \'image/png\', \'purpose\' => \'any maskable\'],
            [\'src\' => \'/images/pwa/icon-512.png\', \'sizes\' => \'512x512\', \'type\' => \'image/png\', \'purpose\' => \'any maskable\'],
        ],
        \'shortcuts\' => [
            [\'name\' => \'Depozit\', \'short_name\' => \'Depozit\', \'url\' => \'/app/deposit\', \'icons\' => [[\'src\' => \'/images/pwa/icon-96.png\', \'sizes\' => \'96x96\']]],
            [\'name\' => \'Wallet\',  \'short_name\' => \'Wallet\',  \'url\' => \'/app/wallet\',  \'icons\' => [[\'src\' => \'/images/pwa/icon-96.png\', \'sizes\' => \'96x96\']]],
            [\'name\' => \'Paketlar\',\'short_name\' => \'Paketlar\',\'url\' => \'/app/packages\',\'icons\' => [[\'src\' => \'/images/pwa/icon-96.png\', \'sizes\' => \'96x96\']]],
        ],
        \'prefer_related_applications\' => false,
    ];

    return \\response()->json($manifest)
        ->header(\'Content-Type\', \'application/manifest+json\')
        ->header(\'Cache-Control\', \'public, max-age=3600\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000f190000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'pwa.manifest',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\AuthController@showLogin',
        'controller' => 'App\\Http\\Controllers\\Front\\AuthController@showLogin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'login.post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Front\\AuthController@login',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'login.post',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\AuthController@showRegister',
        'controller' => 'App\\Http\\Controllers\\Front\\AuthController@showRegister',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register.post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'register',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\AuthController@register',
        'controller' => 'App\\Http\\Controllers\\Front\\AuthController@register',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register.post',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'register.ref' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'register/{ref}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\AuthController@showRegister',
        'controller' => 'App\\Http\\Controllers\\Front\\AuthController@showRegister',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'register.ref',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.forgot' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\PasswordResetController@showForgot',
        'controller' => 'App\\Http\\Controllers\\Front\\PasswordResetController@showForgot',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.forgot',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.send' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
          2 => 'throttle:60,1',
          3 => 'throttle:3,60',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\PasswordResetController@sendResetLink',
        'controller' => 'App\\Http\\Controllers\\Front\\PasswordResetController@sendResetLink',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.send',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.reset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reset-password/{token}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
          2 => 'throttle:60,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\PasswordResetController@showReset',
        'controller' => 'App\\Http\\Controllers\\Front\\PasswordResetController@showReset',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.reset',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'password.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reset-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
          2 => 'throttle:60,1',
          3 => 'throttle:5,60',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\PasswordResetController@reset',
        'controller' => 'App\\Http\\Controllers\\Front\\PasswordResetController@reset',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'password.update',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\Front\\AuthController@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'logout',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.terms' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/terms',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:83:"fn() => \\view(\'front.pages.legal.terms\', [\'setting\' => \\App\\Models\\Setting::get()])";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000f0b0000000000000000";}}',
        'as' => 'legal.terms',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.privacy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/privacy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:85:"fn() => \\view(\'front.pages.legal.privacy\', [\'setting\' => \\App\\Models\\Setting::get()])";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000f090000000000000000";}}',
        'as' => 'legal.privacy',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.ais-rules' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/ais-rules',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:87:"fn() => \\view(\'front.pages.legal.ais-rules\', [\'setting\' => \\App\\Models\\Setting::get()])";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000f070000000000000000";}}',
        'as' => 'legal.ais-rules',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.deposit-withdraw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/deposit-withdraw',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:94:"fn() => \\view(\'front.pages.legal.deposit-withdraw\', [\'setting\' => \\App\\Models\\Setting::get()])";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000f050000000000000000";}}',
        'as' => 'legal.deposit-withdraw',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.risk-disclaimer' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/risk-disclaimer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:93:"fn() => \\view(\'front.pages.legal.risk-disclaimer\', [\'setting\' => \\App\\Models\\Setting::get()])";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000f030000000000000000";}}',
        'as' => 'legal.risk-disclaimer',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.referral' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/referral',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:86:"fn() => \\view(\'front.pages.legal.referral\', [\'setting\' => \\App\\Models\\Setting::get()])";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000f010000000000000000";}}',
        'as' => 'legal.referral',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.kyc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/kyc',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:81:"fn() => \\view(\'front.pages.legal.kyc\', [\'setting\' => \\App\\Models\\Setting::get()])";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000eff0000000000000000";}}',
        'as' => 'legal.kyc',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.cookies' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/cookies',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:85:"fn() => \\view(\'front.pages.legal.cookies\', [\'setting\' => \\App\\Models\\Setting::get()])";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000efd0000000000000000";}}',
        'as' => 'legal.cookies',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.refund' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/refund',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:84:"fn() => \\view(\'front.pages.legal.refund\', [\'setting\' => \\App\\Models\\Setting::get()])";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000efb0000000000000000";}}',
        'as' => 'legal.refund',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'legal.anti-fraud' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'legal/anti-fraud',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:88:"fn() => \\view(\'front.pages.legal.anti-fraud\', [\'setting\' => \\App\\Models\\Setting::get()])";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000ef90000000000000000";}}',
        'as' => 'legal.anti-fraud',
        'namespace' => NULL,
        'prefix' => '/legal',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\DashboardController@index',
        'as' => 'app.dashboard',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.profile' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\DashboardController@profile',
        'controller' => 'App\\Http\\Controllers\\Front\\DashboardController@profile',
        'as' => 'app.profile',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.profile.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'app/profile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\DashboardController@updateProfile',
        'controller' => 'App\\Http\\Controllers\\Front\\DashboardController@updateProfile',
        'as' => 'app.profile.update',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.profile.password' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'app/profile/password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\DashboardController@updatePassword',
        'controller' => 'App\\Http\\Controllers\\Front\\DashboardController@updatePassword',
        'as' => 'app.profile.password',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.packages' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/packages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\PackageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\PackageController@index',
        'as' => 'app.packages',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.packages.buy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/packages/{package}/buy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:30,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\PackageController@buy',
        'controller' => 'App\\Http\\Controllers\\Front\\PackageController@buy',
        'as' => 'app.packages.buy',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.deposit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/deposit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\DepositController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\DepositController@index',
        'as' => 'app.deposit',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.deposit.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/deposit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:10,1',
          4 => 'kyc.required',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\DepositController@store',
        'controller' => 'App\\Http\\Controllers\\Front\\DepositController@store',
        'as' => 'app.deposit.store',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.withdraw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/withdraw',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\WithdrawalController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\WithdrawalController@index',
        'as' => 'app.withdraw',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.withdraw.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/withdraw',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:20,1',
          4 => 'kyc.required',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\WithdrawalController@store',
        'controller' => 'App\\Http\\Controllers\\Front\\WithdrawalController@store',
        'as' => 'app.withdraw.store',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.referrals' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/referrals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\ReferralController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\ReferralController@index',
        'as' => 'app.referrals',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.transactions' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/transactions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\TransactionController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\TransactionController@index',
        'as' => 'app.transactions',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.checkin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/checkin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CheckInController@store',
        'controller' => 'App\\Http\\Controllers\\Front\\CheckInController@store',
        'as' => 'app.checkin',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.wallet' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/wallet',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\WalletController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\WalletController@index',
        'as' => 'app.wallet',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.wallet.transfer' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/wallet/transfer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:5,5',
          4 => 'kyc.required',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\WalletController@transfer',
        'controller' => 'App\\Http\\Controllers\\Front\\WalletController@transfer',
        'as' => 'app.wallet.transfer',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.wallet.convert' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/wallet/convert',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\WalletController@convert',
        'controller' => 'App\\Http\\Controllers\\Front\\WalletController@convert',
        'as' => 'app.wallet.convert',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.wallet.card.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/wallet/card/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\WalletController@createCard',
        'controller' => 'App\\Http\\Controllers\\Front\\WalletController@createCard',
        'as' => 'app.wallet.card.create',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.wallet.card.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/wallet/card',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\WalletController@storeCard',
        'controller' => 'App\\Http\\Controllers\\Front\\WalletController@storeCard',
        'as' => 'app.wallet.card.store',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.wallet.card.freeze' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/wallet/card/{card}/freeze',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\WalletController@freezeCard',
        'controller' => 'App\\Http\\Controllers\\Front\\WalletController@freezeCard',
        'as' => 'app.wallet.card.freeze',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.level' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/level',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\LevelController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\LevelController@index',
        'as' => 'app.level',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.leaderboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/leaderboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\LevelController@leaderboard',
        'controller' => 'App\\Http\\Controllers\\Front\\LevelController@leaderboard',
        'as' => 'app.leaderboard',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.spin_wheel' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/spin-wheel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\SpinWheelController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\SpinWheelController@index',
        'as' => 'app.spin_wheel',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.spin_wheel.spin' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/spin-wheel/spin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:3,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\SpinWheelController@spin',
        'controller' => 'App\\Http\\Controllers\\Front\\SpinWheelController@spin',
        'as' => 'app.spin_wheel.spin',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.lucky_draw' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/lucky-draw',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\LuckyDrawController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\LuckyDrawController@index',
        'as' => 'app.lucky_draw',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.lucky_draw.buy' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/lucky-draw/{draw}/buy',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\LuckyDrawController@buy',
        'controller' => 'App\\Http\\Controllers\\Front\\LuckyDrawController@buy',
        'as' => 'app.lucky_draw.buy',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.tasks' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/tasks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\TaskController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\TaskController@index',
        'as' => 'app.tasks',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.tasks.submit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/tasks/{task}/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\TaskController@submit',
        'controller' => 'App\\Http\\Controllers\\Front\\TaskController@submit',
        'as' => 'app.tasks.submit',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.funds' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/funds',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\FundController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\FundController@index',
        'as' => 'app.funds',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.funds.invest' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/funds/{fund}/invest',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\FundController@invest',
        'controller' => 'App\\Http\\Controllers\\Front\\FundController@invest',
        'as' => 'app.funds.invest',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.kyc' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/kyc',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\KycController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\KycController@index',
        'as' => 'app.kyc',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.kyc.passport' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/kyc/passport',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:3,60',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\KycController@submitPassport',
        'controller' => 'App\\Http\\Controllers\\Front\\KycController@submitPassport',
        'as' => 'app.kyc.passport',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.kyc.face.start' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/kyc/face/start',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\KycController@startFaceId',
        'controller' => 'App\\Http\\Controllers\\Front\\KycController@startFaceId',
        'as' => 'app.kyc.face.start',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.kyc.face.submit' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/kyc/face/submit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:3,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\KycController@submitFaceId',
        'controller' => 'App\\Http\\Controllers\\Front\\KycController@submitFaceId',
        'as' => 'app.kyc.face.submit',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.quests' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/quests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\QuestController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\QuestController@index',
        'as' => 'app.quests',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.quests.claim' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/quests/{userQuest}/claim',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\QuestController@claim',
        'controller' => 'App\\Http\\Controllers\\Front\\QuestController@claim',
        'as' => 'app.quests.claim',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.roadmap' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/roadmap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\RoadmapPageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\RoadmapPageController@index',
        'as' => 'app.roadmap',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.roadmap.vote' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/roadmap/{module}/vote',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\RoadmapPageController@vote',
        'controller' => 'App\\Http\\Controllers\\Front\\RoadmapPageController@vote',
        'as' => 'app.roadmap.vote',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.crowdfunding.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/crowdfunding/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CrowdfundingPageController@create',
        'controller' => 'App\\Http\\Controllers\\Front\\CrowdfundingPageController@create',
        'as' => 'app.crowdfunding.create',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.crowdfunding.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/crowdfunding',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CrowdfundingPageController@store',
        'controller' => 'App\\Http\\Controllers\\Front\\CrowdfundingPageController@store',
        'as' => 'app.crowdfunding.store',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.crowdfunding' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/crowdfunding',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CrowdfundingPageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\CrowdfundingPageController@index',
        'as' => 'app.crowdfunding',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.crowdfunding.donate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/crowdfunding/{project}/donate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CrowdfundingPageController@donate',
        'controller' => 'App\\Http\\Controllers\\Front\\CrowdfundingPageController@donate',
        'as' => 'app.crowdfunding.donate',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.exchange' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/exchange',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\ExchangePageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\ExchangePageController@index',
        'as' => 'app.exchange',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.exchange.order' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/exchange/order',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\ExchangePageController@order',
        'controller' => 'App\\Http\\Controllers\\Front\\ExchangePageController@order',
        'as' => 'app.exchange.order',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.marketplace' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/marketplace',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\MarketplacePageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\MarketplacePageController@index',
        'as' => 'app.marketplace',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.education.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/education/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\EducationPageController@create',
        'controller' => 'App\\Http\\Controllers\\Front\\EducationPageController@create',
        'as' => 'app.education.create',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.education.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/education',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\EducationPageController@store',
        'controller' => 'App\\Http\\Controllers\\Front\\EducationPageController@store',
        'as' => 'app.education.store',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.education' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/education',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\EducationPageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\EducationPageController@index',
        'as' => 'app.education',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.catalog.shop.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/catalog/shop/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CatalogPageController@createShop',
        'controller' => 'App\\Http\\Controllers\\Front\\CatalogPageController@createShop',
        'as' => 'app.catalog.shop.create',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.catalog.shop.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/catalog/shop',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CatalogPageController@storeShop',
        'controller' => 'App\\Http\\Controllers\\Front\\CatalogPageController@storeShop',
        'as' => 'app.catalog.shop.store',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.catalog.product.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/catalog/product/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CatalogPageController@createProduct',
        'controller' => 'App\\Http\\Controllers\\Front\\CatalogPageController@createProduct',
        'as' => 'app.catalog.product.create',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.catalog.product.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/catalog/product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CatalogPageController@storeProduct',
        'controller' => 'App\\Http\\Controllers\\Front\\CatalogPageController@storeProduct',
        'as' => 'app.catalog.product.store',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.catalog' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/catalog',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CatalogPageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\CatalogPageController@index',
        'as' => 'app.catalog',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.credit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/credit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CreditPageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\CreditPageController@index',
        'as' => 'app.credit',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.credit.apply' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/credit/apply',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:3,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\CreditPageController@apply',
        'controller' => 'App\\Http\\Controllers\\Front\\CreditPageController@apply',
        'as' => 'app.credit.apply',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.savings' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/savings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\SavingsPageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\SavingsPageController@index',
        'as' => 'app.savings',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.savings.create' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/savings/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:3,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\SavingsPageController@create',
        'controller' => 'App\\Http\\Controllers\\Front\\SavingsPageController@create',
        'as' => 'app.savings.create',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.gig.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/gig/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\GigPageController@create',
        'controller' => 'App\\Http\\Controllers\\Front\\GigPageController@create',
        'as' => 'app.gig.create',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.gig.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/gig',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\GigPageController@store',
        'controller' => 'App\\Http\\Controllers\\Front\\GigPageController@store',
        'as' => 'app.gig.store',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.gig' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/gig',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\GigPageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\GigPageController@index',
        'as' => 'app.gig',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.agromarket.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/agromarket/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\AgroMarketPageController@create',
        'controller' => 'App\\Http\\Controllers\\Front\\AgroMarketPageController@create',
        'as' => 'app.agromarket.create',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.agromarket.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/agromarket',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\AgroMarketPageController@store',
        'controller' => 'App\\Http\\Controllers\\Front\\AgroMarketPageController@store',
        'as' => 'app.agromarket.store',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.agromarket' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/agromarket',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\AgroMarketPageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\AgroMarketPageController@index',
        'as' => 'app.agromarket',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.lending.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/lending/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\LendingPageController@createOffer',
        'controller' => 'App\\Http\\Controllers\\Front\\LendingPageController@createOffer',
        'as' => 'app.lending.create',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.lending.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/lending',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\LendingPageController@storeOffer',
        'controller' => 'App\\Http\\Controllers\\Front\\LendingPageController@storeOffer',
        'as' => 'app.lending.store',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.lending.borrow' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/lending/{offer}/borrow',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\LendingPageController@borrow',
        'controller' => 'App\\Http\\Controllers\\Front\\LendingPageController@borrow',
        'as' => 'app.lending.borrow',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.lending' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/lending',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\LendingPageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\LendingPageController@index',
        'as' => 'app.lending',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.ai' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/ai-assistant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\AiAssistantController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\AiAssistantController@index',
        'as' => 'app.ai',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.ai.send' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/ai-assistant',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\AiAssistantController@send',
        'controller' => 'App\\Http\\Controllers\\Front\\AiAssistantController@send',
        'as' => 'app.ai.send',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.influencer.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/influencer',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerDashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerDashboardController@index',
        'as' => 'app.influencer.dashboard',
        'namespace' => NULL,
        'prefix' => 'app/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.influencer.channels' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/influencer/channels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerChannelController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerChannelController@index',
        'as' => 'app.influencer.channels',
        'namespace' => NULL,
        'prefix' => 'app/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.influencer.channels.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/influencer/channels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerChannelController@store',
        'controller' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerChannelController@store',
        'as' => 'app.influencer.channels.store',
        'namespace' => NULL,
        'prefix' => 'app/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.influencer.channels.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'app/influencer/channels/{channel}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerChannelController@destroy',
        'controller' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerChannelController@destroy',
        'as' => 'app.influencer.channels.destroy',
        'namespace' => NULL,
        'prefix' => 'app/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.influencer.campaigns' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/influencer/campaigns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerCampaignController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerCampaignController@index',
        'as' => 'app.influencer.campaigns',
        'namespace' => NULL,
        'prefix' => 'app/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.influencer.submissions' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/influencer/submissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerSubmissionController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerSubmissionController@index',
        'as' => 'app.influencer.submissions',
        'namespace' => NULL,
        'prefix' => 'app/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.influencer.submissions.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/influencer/submissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerSubmissionController@store',
        'controller' => 'App\\Http\\Controllers\\Front\\Influencer\\InfluencerSubmissionController@store',
        'as' => 'app.influencer.submissions.store',
        'namespace' => NULL,
        'prefix' => 'app/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.support.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\SupportTicketController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\SupportTicketController@index',
        'as' => 'app.support.index',
        'namespace' => NULL,
        'prefix' => 'app/support',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.support.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/support/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\SupportTicketController@create',
        'controller' => 'App\\Http\\Controllers\\Front\\SupportTicketController@create',
        'as' => 'app.support.create',
        'namespace' => NULL,
        'prefix' => 'app/support',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.support.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\SupportTicketController@store',
        'controller' => 'App\\Http\\Controllers\\Front\\SupportTicketController@store',
        'as' => 'app.support.store',
        'namespace' => NULL,
        'prefix' => 'app/support',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.support.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/support/{ticket}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\SupportTicketController@show',
        'controller' => 'App\\Http\\Controllers\\Front\\SupportTicketController@show',
        'as' => 'app.support.show',
        'namespace' => NULL,
        'prefix' => 'app/support',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.support.reply' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/support/{ticket}/reply',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:10,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\SupportTicketController@reply',
        'controller' => 'App\\Http\\Controllers\\Front\\SupportTicketController@reply',
        'as' => 'app.support.reply',
        'namespace' => NULL,
        'prefix' => 'app/support',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.support.close' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/support/{ticket}/close',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\SupportTicketController@close',
        'controller' => 'App\\Http\\Controllers\\Front\\SupportTicketController@close',
        'as' => 'app.support.close',
        'namespace' => NULL,
        'prefix' => 'app/support',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.medical.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/medical',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\MedicalPageController@index',
        'controller' => 'App\\Http\\Controllers\\Front\\MedicalPageController@index',
        'as' => 'app.medical.index',
        'namespace' => NULL,
        'prefix' => 'app/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.medical.doctors' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/medical/doctors',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\MedicalPageController@doctors',
        'controller' => 'App\\Http\\Controllers\\Front\\MedicalPageController@doctors',
        'as' => 'app.medical.doctors',
        'namespace' => NULL,
        'prefix' => 'app/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.medical.doctors.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/medical/doctors/{doctorProfile}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\MedicalPageController@doctorShow',
        'controller' => 'App\\Http\\Controllers\\Front\\MedicalPageController@doctorShow',
        'as' => 'app.medical.doctors.show',
        'namespace' => NULL,
        'prefix' => 'app/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.medical.consultations.start' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'app/medical/consultations/start',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
          3 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\MedicalPageController@startConsultation',
        'controller' => 'App\\Http\\Controllers\\Front\\MedicalPageController@startConsultation',
        'as' => 'app.medical.consultations.start',
        'namespace' => NULL,
        'prefix' => 'app/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.medical.consultations' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/medical/consultations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\MedicalPageController@consultations',
        'controller' => 'App\\Http\\Controllers\\Front\\MedicalPageController@consultations',
        'as' => 'app.medical.consultations',
        'namespace' => NULL,
        'prefix' => 'app/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.medical.consultation' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/medical/consultations/{consultation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\MedicalPageController@consultation',
        'controller' => 'App\\Http\\Controllers\\Front\\MedicalPageController@consultation',
        'as' => 'app.medical.consultation',
        'namespace' => NULL,
        'prefix' => 'app/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.medical.medicine-orders' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/medical/medicine-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\MedicalPageController@medicineOrders',
        'controller' => 'App\\Http\\Controllers\\Front\\MedicalPageController@medicineOrders',
        'as' => 'app.medical.medicine-orders',
        'namespace' => NULL,
        'prefix' => 'app/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.medical.doctor.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/medical/doctor/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\MedicalPageController@doctorProfileCreate',
        'controller' => 'App\\Http\\Controllers\\Front\\MedicalPageController@doctorProfileCreate',
        'as' => 'app.medical.doctor.create',
        'namespace' => NULL,
        'prefix' => 'app/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'app.medical.doctor.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/medical/doctor/dashboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'App\\Http\\Middleware\\Front\\AuthMiddleware',
          2 => 'App\\Http\\Middleware\\Front\\RequireFirstDeposit',
        ),
        'uses' => 'App\\Http\\Controllers\\Front\\MedicalPageController@doctorDashboard',
        'controller' => 'App\\Http\\Controllers\\Front\\MedicalPageController@doctorDashboard',
        'as' => 'app.medical.doctor.dashboard',
        'namespace' => NULL,
        'prefix' => 'app/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AuthController@showLogin',
        'controller' => 'App\\Http\\Controllers\\Admin\\AuthController@showLogin',
        'as' => 'admin.login',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.login.post' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'throttle:5,1',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AuthController@login',
        'controller' => 'App\\Http\\Controllers\\Admin\\AuthController@login',
        'as' => 'admin.login.post',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AuthController@logout',
        'controller' => 'App\\Http\\Controllers\\Admin\\AuthController@logout',
        'as' => 'admin.logout',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DashboardController@index',
        'as' => 'admin.dashboard',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.upload' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/upload',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FileUploadController@upload',
        'controller' => 'App\\Http\\Controllers\\Admin\\FileUploadController@upload',
        'as' => 'admin.upload',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:users.view',
        ),
        'as' => 'admin.users.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/users/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:users.view',
        ),
        'as' => 'admin.users.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:users.view',
        ),
        'as' => 'admin.users.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/users/{user}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:users.view',
        ),
        'as' => 'admin.users.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:users.view',
        ),
        'as' => 'admin.users.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:users.view',
        ),
        'as' => 'admin.users.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.ban' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/users/{user}/ban',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:users.view',
          4 => 'can:users.ban',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@ban',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@ban',
        'as' => 'admin.users.ban',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.users.balance' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/users/{user}/balance',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:users.view',
          4 => 'can:users.balance-adjust',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UserController@adjustBalance',
        'controller' => 'App\\Http\\Controllers\\Admin\\UserController@adjustBalance',
        'as' => 'admin.users.balance',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.admins.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/admins',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:admins.view',
        ),
        'as' => 'admin.admins.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUserController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUserController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.admins.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/admins/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:admins.view',
        ),
        'as' => 'admin.admins.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUserController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUserController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.admins.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/admins',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:admins.view',
        ),
        'as' => 'admin.admins.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUserController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUserController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.admins.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/admins/{admin}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:admins.view',
        ),
        'as' => 'admin.admins.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUserController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUserController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.admins.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/admins/{admin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:admins.view',
        ),
        'as' => 'admin.admins.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUserController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUserController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.admins.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/admins/{admin}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:admins.view',
        ),
        'as' => 'admin.admins.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUserController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUserController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.admins.ban' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/admins/{admin}/ban',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:admins.view',
          4 => 'can:admins.ban',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUserController@ban',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUserController@ban',
        'as' => 'admin.admins.ban',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.admins.role' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/admins/{admin}/role',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:admins.view',
          4 => 'can:roles.assign',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdminUserController@assignRole',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdminUserController@assignRole',
        'as' => 'admin.admins.role',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roles.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:roles.view',
        ),
        'as' => 'admin.roles.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roles.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/roles/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:roles.view',
        ),
        'as' => 'admin.roles.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roles.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/roles',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:roles.view',
        ),
        'as' => 'admin.roles.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roles.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/roles/{role}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:roles.view',
        ),
        'as' => 'admin.roles.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roles.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/roles/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:roles.view',
        ),
        'as' => 'admin.roles.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roles.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/roles/{role}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:roles.view',
        ),
        'as' => 'admin.roles.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roles.permissions' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/roles/{role}/permissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:roles.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\RoleController@syncPermissions',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoleController@syncPermissions',
        'as' => 'admin.roles.permissions',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.deposits.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/deposits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:deposits.view',
        ),
        'as' => 'admin.deposits.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\DepositController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\DepositController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.deposits.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/deposits/{deposit}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:deposits.view',
        ),
        'as' => 'admin.deposits.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\DepositController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\DepositController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.deposits.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/deposits/{deposit}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:deposits.view',
          4 => 'can:deposits.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DepositController@approve',
        'controller' => 'App\\Http\\Controllers\\Admin\\DepositController@approve',
        'as' => 'admin.deposits.approve',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.deposits.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/deposits/{deposit}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:deposits.view',
          4 => 'can:deposits.reject',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\DepositController@reject',
        'controller' => 'App\\Http\\Controllers\\Admin\\DepositController@reject',
        'as' => 'admin.deposits.reject',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.withdrawals.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/withdrawals',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:withdrawals.view',
        ),
        'as' => 'admin.withdrawals.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\WithdrawalController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\WithdrawalController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.withdrawals.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/withdrawals/{withdrawal}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:withdrawals.view',
        ),
        'as' => 'admin.withdrawals.show',
        'uses' => 'App\\Http\\Controllers\\Admin\\WithdrawalController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\WithdrawalController@show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.withdrawals.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/withdrawals/{withdrawal}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:withdrawals.view',
          4 => 'can:withdrawals.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\WithdrawalController@approve',
        'controller' => 'App\\Http\\Controllers\\Admin\\WithdrawalController@approve',
        'as' => 'admin.withdrawals.approve',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.withdrawals.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/withdrawals/{withdrawal}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:withdrawals.view',
          4 => 'can:withdrawals.reject',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\WithdrawalController@reject',
        'controller' => 'App\\Http\\Controllers\\Admin\\WithdrawalController@reject',
        'as' => 'admin.withdrawals.reject',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.packages.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/packages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:packages.view',
        ),
        'as' => 'admin.packages.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\PackageController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\PackageController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.packages.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/packages/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:packages.view',
        ),
        'as' => 'admin.packages.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\PackageController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\PackageController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.packages.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/packages',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:packages.view',
        ),
        'as' => 'admin.packages.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\PackageController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\PackageController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.packages.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/packages/{package}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:packages.view',
        ),
        'as' => 'admin.packages.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\PackageController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\PackageController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.packages.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/packages/{package}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:packages.view',
        ),
        'as' => 'admin.packages.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\PackageController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\PackageController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.packages.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/packages/{package}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:packages.view',
        ),
        'as' => 'admin.packages.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\PackageController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\PackageController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.stations.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:stations.view',
        ),
        'as' => 'admin.stations.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\StationController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\StationController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.stations.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stations/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:stations.view',
        ),
        'as' => 'admin.stations.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\StationController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\StationController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.stations.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/stations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:stations.view',
        ),
        'as' => 'admin.stations.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\StationController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\StationController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.stations.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/stations/{station}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:stations.view',
        ),
        'as' => 'admin.stations.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\StationController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\StationController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.stations.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/stations/{station}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:stations.view',
        ),
        'as' => 'admin.stations.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\StationController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\StationController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.stations.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/stations/{station}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:stations.view',
        ),
        'as' => 'admin.stations.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\StationController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\StationController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment_methods.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/payment-methods',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:payment-methods.view',
        ),
        'as' => 'admin.payment_methods.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment_methods.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/payment-methods/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:payment-methods.view',
        ),
        'as' => 'admin.payment_methods.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment_methods.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/payment-methods',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:payment-methods.view',
        ),
        'as' => 'admin.payment_methods.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment_methods.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/payment-methods/{payment_method}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:payment-methods.view',
        ),
        'as' => 'admin.payment_methods.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment_methods.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/payment-methods/{payment_method}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:payment-methods.view',
        ),
        'as' => 'admin.payment_methods.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.payment_methods.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/payment-methods/{payment_method}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:payment-methods.view',
        ),
        'as' => 'admin.payment_methods.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\PaymentMethodController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@index',
        'as' => 'admin.settings.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.settings.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
          4 => 'can:settings.edit',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SettingController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\SettingController@update',
        'as' => 'admin.settings.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.translations.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/translations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'as' => 'admin.translations.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\TranslationController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\TranslationController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.translations.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/translations/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'as' => 'admin.translations.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\TranslationController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\TranslationController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.translations.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/translations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'as' => 'admin.translations.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\TranslationController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\TranslationController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.translations.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/translations/{translation}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'as' => 'admin.translations.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\TranslationController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\TranslationController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.translations.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/translations/{translation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'as' => 'admin.translations.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\TranslationController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\TranslationController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.translations.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/translations/{translation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'as' => 'admin.translations.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\TranslationController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\TranslationController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.translations.clear-cache' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/translations/clear-cache',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TranslationController@clearCache',
        'controller' => 'App\\Http\\Controllers\\Admin\\TranslationController@clearCache',
        'as' => 'admin.translations.clear-cache',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ais.rate' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ais/rate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AisController@rate',
        'controller' => 'App\\Http\\Controllers\\Admin\\AisController@rate',
        'as' => 'admin.ais.rate',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ais.rate.update' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/ais/rate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AisController@updateRate',
        'controller' => 'App\\Http\\Controllers\\Admin\\AisController@updateRate',
        'as' => 'admin.ais.rate.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ais.wallets' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ais/wallets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AisController@wallets',
        'controller' => 'App\\Http\\Controllers\\Admin\\AisController@wallets',
        'as' => 'admin.ais.wallets',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ais.transfers' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ais/transfers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AisController@transfers',
        'controller' => 'App\\Http\\Controllers\\Admin\\AisController@transfers',
        'as' => 'admin.ais.transfers',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leaders.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/leaders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:leaders.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\LeaderController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\LeaderController@index',
        'as' => 'admin.leaders.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leaders.toggle' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/leaders/{user}/toggle',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:leaders.view',
          4 => 'can:leaders.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\LeaderController@toggle',
        'controller' => 'App\\Http\\Controllers\\Admin\\LeaderController@toggle',
        'as' => 'admin.leaders.toggle',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.leaders.tree' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/leaders/{user}/tree',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:leaders.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\LeaderController@tree',
        'controller' => 'App\\Http\\Controllers\\Admin\\LeaderController@tree',
        'as' => 'admin.leaders.tree',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.levels.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/levels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\LevelAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\LevelAdminController@index',
        'as' => 'admin.levels.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.levels.leaderboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/levels/leaderboard',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\LevelAdminController@leaderboard',
        'controller' => 'App\\Http\\Controllers\\Admin\\LevelAdminController@leaderboard',
        'as' => 'admin.levels.leaderboard',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.kyc.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/kyc/passport',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:kyc.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\KycController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\KycController@index',
        'as' => 'admin.kyc.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.kyc.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/kyc/passport/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:kyc.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\KycController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\KycController@show',
        'as' => 'admin.kyc.show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.kyc.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/kyc/passport/{user}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:kyc.view',
          4 => 'can:kyc.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\KycController@approve',
        'controller' => 'App\\Http\\Controllers\\Admin\\KycController@approve',
        'as' => 'admin.kyc.approve',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.kyc.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/kyc/passport/{user}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:kyc.view',
          4 => 'can:kyc.reject',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\KycController@reject',
        'controller' => 'App\\Http\\Controllers\\Admin\\KycController@reject',
        'as' => 'admin.kyc.reject',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.kyc.face.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/kyc/face',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:kyc.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FaceKycController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaceKycController@index',
        'as' => 'admin.kyc.face.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.kyc.face.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/kyc/face/{attempt}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:kyc.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FaceKycController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaceKycController@show',
        'as' => 'admin.kyc.face.show',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.kyc.face.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/kyc/face/{attempt}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:kyc.view',
          4 => 'can:kyc.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FaceKycController@approve',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaceKycController@approve',
        'as' => 'admin.kyc.face.approve',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.kyc.face.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/kyc/face/{attempt}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:kyc.view',
          4 => 'can:kyc.reject',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FaceKycController@reject',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaceKycController@reject',
        'as' => 'admin.kyc.face.reject',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.tasks.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/tasks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@index',
        'as' => 'admin.tasks.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.tasks.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/tasks/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@create',
        'as' => 'admin.tasks.create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.tasks.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/tasks',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@store',
        'as' => 'admin.tasks.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.tasks.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/tasks/{task}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@edit',
        'as' => 'admin.tasks.edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.tasks.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/tasks/{task}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@update',
        'as' => 'admin.tasks.update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.tasks.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/tasks/{task}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@destroy',
        'as' => 'admin.tasks.destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.tasks.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/tasks/{userTask}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@approve',
        'controller' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@approve',
        'as' => 'admin.tasks.approve',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.tasks.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/tasks/{userTask}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@reject',
        'controller' => 'App\\Http\\Controllers\\Admin\\TaskAdminController@reject',
        'as' => 'admin.tasks.reject',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quests.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/quests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'as' => 'admin.quests.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quests.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/quests/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'as' => 'admin.quests.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quests.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/quests',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'as' => 'admin.quests.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quests.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/quests/{quest}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'as' => 'admin.quests.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quests.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/quests/{quest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'as' => 'admin.quests.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.quests.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/quests/{quest}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:tasks.view',
        ),
        'as' => 'admin.quests.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\QuestAdminController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lucky-draw.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/lucky-draw',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lucky-draws.view',
        ),
        'as' => 'admin.lucky-draw.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lucky-draw.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/lucky-draw/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lucky-draws.view',
        ),
        'as' => 'admin.lucky-draw.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lucky-draw.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/lucky-draw',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lucky-draws.view',
        ),
        'as' => 'admin.lucky-draw.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lucky-draw.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/lucky-draw/{lucky_draw}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lucky-draws.view',
        ),
        'as' => 'admin.lucky-draw.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lucky-draw.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/lucky-draw/{lucky_draw}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lucky-draws.view',
        ),
        'as' => 'admin.lucky-draw.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lucky-draw.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/lucky-draw/{lucky_draw}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lucky-draws.view',
        ),
        'as' => 'admin.lucky-draw.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lucky-draw.draw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/lucky-draw/{luckyDraw}/draw',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lucky-draws.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@draw',
        'controller' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@draw',
        'as' => 'admin.lucky-draw.draw',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lucky-draw.results' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/lucky-draw-results',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lucky-draws.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@results',
        'controller' => 'App\\Http\\Controllers\\Admin\\LuckyDrawAdminController@results',
        'as' => 'admin.lucky-draw.results',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.funds.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/funds',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:funds.view',
        ),
        'as' => 'admin.funds.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\FundAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\FundAdminController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.funds.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/funds/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:funds.view',
        ),
        'as' => 'admin.funds.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\FundAdminController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\FundAdminController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.funds.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/funds',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:funds.view',
        ),
        'as' => 'admin.funds.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\FundAdminController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\FundAdminController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.funds.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/funds/{fund}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:funds.view',
        ),
        'as' => 'admin.funds.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\FundAdminController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\FundAdminController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.funds.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/funds/{fund}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:funds.view',
        ),
        'as' => 'admin.funds.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\FundAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\FundAdminController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.funds.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/funds/{fund}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:funds.view',
        ),
        'as' => 'admin.funds.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\FundAdminController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\FundAdminController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.channel-posts.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/channel-posts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ChannelPostController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ChannelPostController@index',
        'as' => 'admin.channel-posts.index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.channel-posts.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/channel-posts/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ChannelPostController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\ChannelPostController@create',
        'as' => 'admin.channel-posts.create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.channel-posts.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/channel-posts',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ChannelPostController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\ChannelPostController@store',
        'as' => 'admin.channel-posts.store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roadmap.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/roadmap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'as' => 'admin.roadmap.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoadmapController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoadmapController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roadmap.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/roadmap/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'as' => 'admin.roadmap.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoadmapController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoadmapController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roadmap.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/roadmap',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'as' => 'admin.roadmap.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoadmapController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoadmapController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roadmap.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/roadmap/{roadmap}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'as' => 'admin.roadmap.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoadmapController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoadmapController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roadmap.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/roadmap/{roadmap}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'as' => 'admin.roadmap.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoadmapController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoadmapController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.roadmap.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/roadmap/{roadmap}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'as' => 'admin.roadmap.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\RoadmapController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\RoadmapController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.exchange.settings.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/exchange/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ExchangeSettingController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\ExchangeSettingController@index',
        'as' => 'admin.exchange.settings.index',
        'namespace' => NULL,
        'prefix' => 'admin/exchange',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.exchange.settings.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/exchange/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ExchangeSettingController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\ExchangeSettingController@update',
        'as' => 'admin.exchange.settings.update',
        'namespace' => NULL,
        'prefix' => 'admin/exchange',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.exchange.stats' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/exchange/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ExchangeSettingController@stats',
        'controller' => 'App\\Http\\Controllers\\Admin\\ExchangeSettingController@stats',
        'as' => 'admin.exchange.stats',
        'namespace' => NULL,
        'prefix' => 'admin/exchange',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.exchange.orders' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/exchange/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ExchangeSettingController@orders',
        'controller' => 'App\\Http\\Controllers\\Admin\\ExchangeSettingController@orders',
        'as' => 'admin.exchange.orders',
        'namespace' => NULL,
        'prefix' => 'admin/exchange',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.exchange.trades' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/exchange/trades',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\ExchangeSettingController@trades',
        'controller' => 'App\\Http\\Controllers\\Admin\\ExchangeSettingController@trades',
        'as' => 'admin.exchange.trades',
        'namespace' => NULL,
        'prefix' => 'admin/exchange',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.promo-codes.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/marketing/promo-codes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\PromoCodeController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\PromoCodeController@index',
        'as' => 'admin.marketing.promo-codes.index',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.promo-codes.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/marketing/promo-codes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.promo-codes.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\PromoCodeController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\PromoCodeController@store',
        'as' => 'admin.marketing.promo-codes.store',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.promo-codes.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/marketing/promo-codes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.promo-codes.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\PromoCodeController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\PromoCodeController@update',
        'as' => 'admin.marketing.promo-codes.update',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.promo-codes.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/marketing/promo-codes/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.promo-codes.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\PromoCodeController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\PromoCodeController@destroy',
        'as' => 'admin.marketing.promo-codes.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.promo-codes.stats' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/marketing/promo-codes/{id}/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\PromoCodeController@stats',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\PromoCodeController@stats',
        'as' => 'admin.marketing.promo-codes.stats',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.spin-wheel.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/marketing/spin-wheel/prizes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\SpinWheelController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\SpinWheelController@index',
        'as' => 'admin.marketing.spin-wheel.index',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.spin-wheel.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/marketing/spin-wheel/prizes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.spin-wheel.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\SpinWheelController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\SpinWheelController@store',
        'as' => 'admin.marketing.spin-wheel.store',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.spin-wheel.prize.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/marketing/spin-wheel/prizes/{prize}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.spin-wheel.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\SpinWheelController@updatePrize',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\SpinWheelController@updatePrize',
        'as' => 'admin.marketing.spin-wheel.prize.update',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.spin-wheel.prize.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/marketing/spin-wheel/prizes/{prize}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.spin-wheel.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\SpinWheelController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\SpinWheelController@destroy',
        'as' => 'admin.marketing.spin-wheel.prize.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.spin-wheel.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/marketing/spin-wheel/prizes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.spin-wheel.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\SpinWheelController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\SpinWheelController@update',
        'as' => 'admin.marketing.spin-wheel.update',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.competitions.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/marketing/competitions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\LeaderboardController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\LeaderboardController@index',
        'as' => 'admin.marketing.competitions.index',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.competitions.settings' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/marketing/competitions/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.competitions.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\LeaderboardController@settings',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\LeaderboardController@settings',
        'as' => 'admin.marketing.competitions.settings',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.events.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/marketing/events',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\SeasonalEventController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\SeasonalEventController@index',
        'as' => 'admin.marketing.events.index',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.events.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/marketing/events',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.events.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\SeasonalEventController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\SeasonalEventController@store',
        'as' => 'admin.marketing.events.store',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.events.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/marketing/events/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.events.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\SeasonalEventController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\SeasonalEventController@update',
        'as' => 'admin.marketing.events.update',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.events.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/marketing/events/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.events.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\SeasonalEventController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\SeasonalEventController@destroy',
        'as' => 'admin.marketing.events.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.vip.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/marketing/vip/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\VipController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\VipController@index',
        'as' => 'admin.marketing.vip.index',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.vip.settings' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/marketing/vip/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.vip.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\VipController@settings',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\VipController@settings',
        'as' => 'admin.marketing.vip.settings',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.invite-challenge.settings' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/marketing/invite-challenge/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\InviteChallengeController@settings',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\InviteChallengeController@settings',
        'as' => 'admin.marketing.invite-challenge.settings',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketing.invite-challenge.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/marketing/invite-challenge/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketing.promo-codes.view',
          4 => 'can:marketing.invite-challenge.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Marketing\\InviteChallengeController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Marketing\\InviteChallengeController@update',
        'as' => 'admin.marketing.invite-challenge.update',
        'namespace' => NULL,
        'prefix' => 'admin/marketing',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.crowdfunding.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/crowdfunding',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:crowdfunding.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CrowdfundingAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CrowdfundingAdminController@index',
        'as' => 'admin.crowdfunding.index',
        'namespace' => NULL,
        'prefix' => 'admin/crowdfunding',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.crowdfunding.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/crowdfunding/{project}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:crowdfunding.view',
          4 => 'can:crowdfunding.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CrowdfundingAdminController@approve',
        'controller' => 'App\\Http\\Controllers\\Admin\\CrowdfundingAdminController@approve',
        'as' => 'admin.crowdfunding.approve',
        'namespace' => NULL,
        'prefix' => 'admin/crowdfunding',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.crowdfunding.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/crowdfunding/{project}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:crowdfunding.view',
          4 => 'can:crowdfunding.reject',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CrowdfundingAdminController@reject',
        'controller' => 'App\\Http\\Controllers\\Admin\\CrowdfundingAdminController@reject',
        'as' => 'admin.crowdfunding.reject',
        'namespace' => NULL,
        'prefix' => 'admin/crowdfunding',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.crowdfunding.expenses.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/crowdfunding/{project}/expenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:crowdfunding.view',
          4 => 'can:crowdfunding.expenses',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CrowdfundingAdminController@addExpense',
        'controller' => 'App\\Http\\Controllers\\Admin\\CrowdfundingAdminController@addExpense',
        'as' => 'admin.crowdfunding.expenses.store',
        'namespace' => NULL,
        'prefix' => 'admin/crowdfunding',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.crowdfunding.expenses.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/crowdfunding/{project}/expenses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:crowdfunding.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CrowdfundingAdminController@expenses',
        'controller' => 'App\\Http\\Controllers\\Admin\\CrowdfundingAdminController@expenses',
        'as' => 'admin.crowdfunding.expenses.index',
        'namespace' => NULL,
        'prefix' => 'admin/crowdfunding',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ubi.settings' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ubi/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UbiAdminController@settings',
        'controller' => 'App\\Http\\Controllers\\Admin\\UbiAdminController@settings',
        'as' => 'admin.ubi.settings',
        'namespace' => NULL,
        'prefix' => 'admin/ubi',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ubi.settings.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/ubi/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UbiAdminController@updateSettings',
        'controller' => 'App\\Http\\Controllers\\Admin\\UbiAdminController@updateSettings',
        'as' => 'admin.ubi.settings.update',
        'namespace' => NULL,
        'prefix' => 'admin/ubi',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ubi.claims' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ubi/claims',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\UbiAdminController@claims',
        'controller' => 'App\\Http\\Controllers\\Admin\\UbiAdminController@claims',
        'as' => 'admin.ubi.claims',
        'namespace' => NULL,
        'prefix' => 'admin/ubi',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.tokens.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/tokens/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TokenAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\TokenAdminController@index',
        'as' => 'admin.tokens.index',
        'namespace' => NULL,
        'prefix' => 'admin/tokens',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.tokens.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/tokens/assets',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TokenAdminController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\TokenAdminController@store',
        'as' => 'admin.tokens.store',
        'namespace' => NULL,
        'prefix' => 'admin/tokens',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.tokens.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/tokens/assets/{asset}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\TokenAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\TokenAdminController@update',
        'as' => 'admin.tokens.update',
        'namespace' => NULL,
        'prefix' => 'admin/tokens',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.faq.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/faq',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FaqAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaqAdminController@index',
        'as' => 'admin.faq.index',
        'namespace' => NULL,
        'prefix' => 'admin/faq',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.faq.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/faq',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FaqAdminController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaqAdminController@store',
        'as' => 'admin.faq.store',
        'namespace' => NULL,
        'prefix' => 'admin/faq',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.faq.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/faq/{faq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FaqAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaqAdminController@update',
        'as' => 'admin.faq.update',
        'namespace' => NULL,
        'prefix' => 'admin/faq',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.faq.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/faq/{faq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FaqAdminController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\FaqAdminController@destroy',
        'as' => 'admin.faq.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/faq',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ai.faq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ai-assistant/faq',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AiAssistantAdminController@faq',
        'controller' => 'App\\Http\\Controllers\\Admin\\AiAssistantAdminController@faq',
        'as' => 'admin.ai.faq',
        'namespace' => NULL,
        'prefix' => 'admin/ai-assistant',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ai.faq.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/ai-assistant/faq',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AiAssistantAdminController@storeFaq',
        'controller' => 'App\\Http\\Controllers\\Admin\\AiAssistantAdminController@storeFaq',
        'as' => 'admin.ai.faq.store',
        'namespace' => NULL,
        'prefix' => 'admin/ai-assistant',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ai.faq.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/ai-assistant/faq/{faq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AiAssistantAdminController@updateFaq',
        'controller' => 'App\\Http\\Controllers\\Admin\\AiAssistantAdminController@updateFaq',
        'as' => 'admin.ai.faq.update',
        'namespace' => NULL,
        'prefix' => 'admin/ai-assistant',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ai.faq.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/ai-assistant/faq/{faq}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AiAssistantAdminController@destroyFaq',
        'controller' => 'App\\Http\\Controllers\\Admin\\AiAssistantAdminController@destroyFaq',
        'as' => 'admin.ai.faq.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/ai-assistant',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ai.conversations' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ai-assistant/conversations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:settings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AiAssistantAdminController@conversations',
        'controller' => 'App\\Http\\Controllers\\Admin\\AiAssistantAdminController@conversations',
        'as' => 'admin.ai.conversations',
        'namespace' => NULL,
        'prefix' => 'admin/ai-assistant',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.agromarket.listings' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/agromarket/listings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:agromarket.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AgroMarketAdminController@listings',
        'controller' => 'App\\Http\\Controllers\\Admin\\AgroMarketAdminController@listings',
        'as' => 'admin.agromarket.listings',
        'namespace' => NULL,
        'prefix' => 'admin/agromarket',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.agromarket.orders' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/agromarket/orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:agromarket.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AgroMarketAdminController@orders',
        'controller' => 'App\\Http\\Controllers\\Admin\\AgroMarketAdminController@orders',
        'as' => 'admin.agromarket.orders',
        'namespace' => NULL,
        'prefix' => 'admin/agromarket',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.agromarket.listings.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/agromarket/listings/{listing}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:agromarket.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AgroMarketAdminController@editListing',
        'controller' => 'App\\Http\\Controllers\\Admin\\AgroMarketAdminController@editListing',
        'as' => 'admin.agromarket.listings.edit',
        'namespace' => NULL,
        'prefix' => 'admin/agromarket',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.agromarket.listings.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/agromarket/listings/{listing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:agromarket.view',
          4 => 'can:agromarket.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AgroMarketAdminController@updateListing',
        'controller' => 'App\\Http\\Controllers\\Admin\\AgroMarketAdminController@updateListing',
        'as' => 'admin.agromarket.listings.update',
        'namespace' => NULL,
        'prefix' => 'admin/agromarket',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.agromarket.listings.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/agromarket/listings/{listing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:agromarket.view',
          4 => 'can:agromarket.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AgroMarketAdminController@destroyListing',
        'controller' => 'App\\Http\\Controllers\\Admin\\AgroMarketAdminController@destroyListing',
        'as' => 'admin.agromarket.listings.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/agromarket',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.gig-economy.listings' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/gig-economy/listings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:gig-economy.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\GigEconomyAdminController@listings',
        'controller' => 'App\\Http\\Controllers\\Admin\\GigEconomyAdminController@listings',
        'as' => 'admin.gig-economy.listings',
        'namespace' => NULL,
        'prefix' => 'admin/gig-economy',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.gig-economy.applications' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/gig-economy/applications',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:gig-economy.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\GigEconomyAdminController@applications',
        'controller' => 'App\\Http\\Controllers\\Admin\\GigEconomyAdminController@applications',
        'as' => 'admin.gig-economy.applications',
        'namespace' => NULL,
        'prefix' => 'admin/gig-economy',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.gig-economy.listings.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/gig-economy/listings/{listing}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:gig-economy.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\GigEconomyAdminController@editListing',
        'controller' => 'App\\Http\\Controllers\\Admin\\GigEconomyAdminController@editListing',
        'as' => 'admin.gig-economy.listings.edit',
        'namespace' => NULL,
        'prefix' => 'admin/gig-economy',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.gig-economy.listings.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/gig-economy/listings/{listing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:gig-economy.view',
          4 => 'can:gig-economy.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\GigEconomyAdminController@updateListing',
        'controller' => 'App\\Http\\Controllers\\Admin\\GigEconomyAdminController@updateListing',
        'as' => 'admin.gig-economy.listings.update',
        'namespace' => NULL,
        'prefix' => 'admin/gig-economy',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.gig-economy.listings.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/gig-economy/listings/{listing}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:gig-economy.view',
          4 => 'can:gig-economy.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\GigEconomyAdminController@destroyListing',
        'controller' => 'App\\Http\\Controllers\\Admin\\GigEconomyAdminController@destroyListing',
        'as' => 'admin.gig-economy.listings.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/gig-economy',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ad-network.campaigns' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ad-network/campaigns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:ad-network.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdNetworkAdminController@campaigns',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdNetworkAdminController@campaigns',
        'as' => 'admin.ad-network.campaigns',
        'namespace' => NULL,
        'prefix' => 'admin/ad-network',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ad-network.ads' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ad-network/ads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:ad-network.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdNetworkAdminController@ads',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdNetworkAdminController@ads',
        'as' => 'admin.ad-network.ads',
        'namespace' => NULL,
        'prefix' => 'admin/ad-network',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ad-network.campaigns.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/ad-network/campaigns/{campaign}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:ad-network.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdNetworkAdminController@editCampaign',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdNetworkAdminController@editCampaign',
        'as' => 'admin.ad-network.campaigns.edit',
        'namespace' => NULL,
        'prefix' => 'admin/ad-network',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.ad-network.campaigns.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/ad-network/campaigns/{campaign}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:ad-network.view',
          4 => 'can:ad-network.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\AdNetworkAdminController@updateCampaign',
        'controller' => 'App\\Http\\Controllers\\Admin\\AdNetworkAdminController@updateCampaign',
        'as' => 'admin.ad-network.campaigns.update',
        'namespace' => NULL,
        'prefix' => 'admin/ad-network',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.channels.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/influencer/channels',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerChannelAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerChannelAdminController@index',
        'as' => 'admin.influencer.channels.index',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.channels.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/influencer/channels/{channel}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.channels.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerChannelAdminController@approve',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerChannelAdminController@approve',
        'as' => 'admin.influencer.channels.approve',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.channels.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/influencer/channels/{channel}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.channels.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerChannelAdminController@reject',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerChannelAdminController@reject',
        'as' => 'admin.influencer.channels.reject',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.channels.suspend' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/influencer/channels/{channel}/suspend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.channels.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerChannelAdminController@suspend',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerChannelAdminController@suspend',
        'as' => 'admin.influencer.channels.suspend',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.campaigns.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/influencer/campaigns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.campaigns.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@index',
        'as' => 'admin.influencer.campaigns.index',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.campaigns.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/influencer/campaigns/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.campaigns.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@create',
        'as' => 'admin.influencer.campaigns.create',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.campaigns.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/influencer/campaigns',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.campaigns.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@store',
        'as' => 'admin.influencer.campaigns.store',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.campaigns.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/influencer/campaigns/{campaign}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.campaigns.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@edit',
        'as' => 'admin.influencer.campaigns.edit',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.campaigns.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/influencer/campaigns/{campaign}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.campaigns.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@update',
        'as' => 'admin.influencer.campaigns.update',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.campaigns.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/influencer/campaigns/{campaign}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.campaigns.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerCampaignAdminController@destroy',
        'as' => 'admin.influencer.campaigns.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.submissions.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/influencer/submissions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.submissions.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSubmissionAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSubmissionAdminController@index',
        'as' => 'admin.influencer.submissions.index',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.submissions.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/influencer/submissions/{submission}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.submissions.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSubmissionAdminController@approve',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSubmissionAdminController@approve',
        'as' => 'admin.influencer.submissions.approve',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.submissions.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/influencer/submissions/{submission}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.submissions.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSubmissionAdminController@reject',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSubmissionAdminController@reject',
        'as' => 'admin.influencer.submissions.reject',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.submissions.bulk-approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/influencer/submissions/bulk-approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.submissions.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSubmissionAdminController@bulkApprove',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSubmissionAdminController@bulkApprove',
        'as' => 'admin.influencer.submissions.bulk-approve',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.stats' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/influencer/stats',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSubmissionAdminController@stats',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSubmissionAdminController@stats',
        'as' => 'admin.influencer.stats',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.rewards.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/influencer/rewards',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.rewards.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerRewardAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerRewardAdminController@index',
        'as' => 'admin.influencer.rewards.index',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.settings.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/influencer/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.settings.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSettingAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSettingAdminController@index',
        'as' => 'admin.influencer.settings.index',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.influencer.settings.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/influencer/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:influencer.channels.view',
          4 => 'can:influencer.settings.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSettingAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\Influencer\\InfluencerSettingAdminController@update',
        'as' => 'admin.influencer.settings.update',
        'namespace' => NULL,
        'prefix' => 'admin/influencer',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lending.loans' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/lending/loans',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lending.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\LendingAdminController@loans',
        'controller' => 'App\\Http\\Controllers\\Admin\\LendingAdminController@loans',
        'as' => 'admin.lending.loans',
        'namespace' => NULL,
        'prefix' => 'admin/lending',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lending.offers' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/lending/offers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lending.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\LendingAdminController@offers',
        'controller' => 'App\\Http\\Controllers\\Admin\\LendingAdminController@offers',
        'as' => 'admin.lending.offers',
        'namespace' => NULL,
        'prefix' => 'admin/lending',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lending.loans.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/lending/loans/{loan}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lending.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\LendingAdminController@editLoan',
        'controller' => 'App\\Http\\Controllers\\Admin\\LendingAdminController@editLoan',
        'as' => 'admin.lending.loans.edit',
        'namespace' => NULL,
        'prefix' => 'admin/lending',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.lending.loans.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/lending/loans/{loan}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:lending.view',
          4 => 'can:lending.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\LendingAdminController@updateLoan',
        'controller' => 'App\\Http\\Controllers\\Admin\\LendingAdminController@updateLoan',
        'as' => 'admin.lending.loans.update',
        'namespace' => NULL,
        'prefix' => 'admin/lending',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketplace.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/marketplace',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketplace.view',
        ),
        'as' => 'admin.marketplace.index',
        'uses' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@index',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketplace.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/marketplace/create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketplace.view',
        ),
        'as' => 'admin.marketplace.create',
        'uses' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@create',
        'controller' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@create',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketplace.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/marketplace',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketplace.view',
        ),
        'as' => 'admin.marketplace.store',
        'uses' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@store',
        'controller' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@store',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketplace.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/marketplace/{marketplace}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketplace.view',
        ),
        'as' => 'admin.marketplace.edit',
        'uses' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@edit',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketplace.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
        1 => 'PATCH',
      ),
      'uri' => 'admin/marketplace/{marketplace}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketplace.view',
        ),
        'as' => 'admin.marketplace.update',
        'uses' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@update',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.marketplace.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/marketplace/{marketplace}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:marketplace.view',
        ),
        'as' => 'admin.marketplace.destroy',
        'uses' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\MarketplaceAdminController@destroy',
        'namespace' => NULL,
        'prefix' => '/admin',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.credits.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/credits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:credits.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CreditAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\CreditAdminController@index',
        'as' => 'admin.credits.index',
        'namespace' => NULL,
        'prefix' => 'admin/credits',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.credits.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/credits/{credit}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:credits.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CreditAdminController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\CreditAdminController@edit',
        'as' => 'admin.credits.edit',
        'namespace' => NULL,
        'prefix' => 'admin/credits',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.credits.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/credits/{credit}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:credits.view',
          4 => 'can:credits.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CreditAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\CreditAdminController@update',
        'as' => 'admin.credits.update',
        'namespace' => NULL,
        'prefix' => 'admin/credits',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.savings.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/savings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:savings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SavingsAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\SavingsAdminController@index',
        'as' => 'admin.savings.index',
        'namespace' => NULL,
        'prefix' => 'admin/savings',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.savings.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/savings/{saving}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:savings.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SavingsAdminController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\SavingsAdminController@edit',
        'as' => 'admin.savings.edit',
        'namespace' => NULL,
        'prefix' => 'admin/savings',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.savings.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/savings/{saving}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:savings.view',
          4 => 'can:savings.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SavingsAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\SavingsAdminController@update',
        'as' => 'admin.savings.update',
        'namespace' => NULL,
        'prefix' => 'admin/savings',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.education.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/education',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:education.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EducationAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\EducationAdminController@index',
        'as' => 'admin.education.index',
        'namespace' => NULL,
        'prefix' => 'admin/education',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.education.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/education/{education}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:education.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EducationAdminController@edit',
        'controller' => 'App\\Http\\Controllers\\Admin\\EducationAdminController@edit',
        'as' => 'admin.education.edit',
        'namespace' => NULL,
        'prefix' => 'admin/education',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.education.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/education/{education}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:education.view',
          4 => 'can:education.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EducationAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\EducationAdminController@update',
        'as' => 'admin.education.update',
        'namespace' => NULL,
        'prefix' => 'admin/education',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.education.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/education/{education}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:education.view',
          4 => 'can:education.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\EducationAdminController@destroy',
        'controller' => 'App\\Http\\Controllers\\Admin\\EducationAdminController@destroy',
        'as' => 'admin.education.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/education',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.catalog.shops' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/catalog/shops',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:catalog.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@shops',
        'controller' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@shops',
        'as' => 'admin.catalog.shops',
        'namespace' => NULL,
        'prefix' => 'admin/catalog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.catalog.shops.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/catalog/shops/{shop}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:catalog.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@editShop',
        'controller' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@editShop',
        'as' => 'admin.catalog.shops.edit',
        'namespace' => NULL,
        'prefix' => 'admin/catalog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.catalog.shops.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/catalog/shops/{shop}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:catalog.view',
          4 => 'can:catalog.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@updateShop',
        'controller' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@updateShop',
        'as' => 'admin.catalog.shops.update',
        'namespace' => NULL,
        'prefix' => 'admin/catalog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.catalog.products' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/catalog/products',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:catalog.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@products',
        'controller' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@products',
        'as' => 'admin.catalog.products',
        'namespace' => NULL,
        'prefix' => 'admin/catalog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.catalog.products.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/catalog/products/{product}/edit',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:catalog.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@editProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@editProduct',
        'as' => 'admin.catalog.products.edit',
        'namespace' => NULL,
        'prefix' => 'admin/catalog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.catalog.products.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/catalog/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:catalog.view',
          4 => 'can:catalog.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@updateProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@updateProduct',
        'as' => 'admin.catalog.products.update',
        'namespace' => NULL,
        'prefix' => 'admin/catalog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.catalog.products.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/catalog/products/{product}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:catalog.view',
          4 => 'can:catalog.manage',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@destroyProduct',
        'controller' => 'App\\Http\\Controllers\\Admin\\CatalogAdminController@destroyProduct',
        'as' => 'admin.catalog.products.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/catalog',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.fraud.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/fraud',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:fraud.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@index',
        'as' => 'admin.fraud.index',
        'namespace' => NULL,
        'prefix' => 'admin/fraud',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.fraud.users' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/fraud/users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:fraud.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@users',
        'controller' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@users',
        'as' => 'admin.fraud.users',
        'namespace' => NULL,
        'prefix' => 'admin/fraud',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.fraud.transactions' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/fraud/transactions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:fraud.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@transactions',
        'controller' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@transactions',
        'as' => 'admin.fraud.transactions',
        'namespace' => NULL,
        'prefix' => 'admin/fraud',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.fraud.user-detail' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/fraud/users/{user}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:fraud.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@userDetail',
        'controller' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@userDetail',
        'as' => 'admin.fraud.user-detail',
        'namespace' => NULL,
        'prefix' => 'admin/fraud',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.fraud.ban' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/fraud/users/{user}/ban',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:fraud.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@banUser',
        'controller' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@banUser',
        'as' => 'admin.fraud.ban',
        'namespace' => NULL,
        'prefix' => 'admin/fraud',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.fraud.unban' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/fraud/users/{user}/unban',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:fraud.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@unbanUser',
        'controller' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@unbanUser',
        'as' => 'admin.fraud.unban',
        'namespace' => NULL,
        'prefix' => 'admin/fraud',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.fraud.flag.remove' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/fraud/users/{user}/flags/{flag}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:fraud.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@removeFraudFlag',
        'controller' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@removeFraudFlag',
        'as' => 'admin.fraud.flag.remove',
        'namespace' => NULL,
        'prefix' => 'admin/fraud',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.fraud.audit-logs' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/fraud/audit-logs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:fraud.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@auditLogs',
        'controller' => 'App\\Http\\Controllers\\Admin\\FraudDashboardController@auditLogs',
        'as' => 'admin.fraud.audit-logs',
        'namespace' => NULL,
        'prefix' => 'admin/fraud',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.support.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/support',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupportTicketAdminController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupportTicketAdminController@index',
        'as' => 'admin.support.index',
        'namespace' => NULL,
        'prefix' => 'admin/support',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.support.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/support/{ticket}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupportTicketAdminController@show',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupportTicketAdminController@show',
        'as' => 'admin.support.show',
        'namespace' => NULL,
        'prefix' => 'admin/support',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.support.reply' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/support/{ticket}/reply',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupportTicketAdminController@reply',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupportTicketAdminController@reply',
        'as' => 'admin.support.reply',
        'namespace' => NULL,
        'prefix' => 'admin/support',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.support.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/support/{ticket}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\SupportTicketAdminController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\SupportTicketAdminController@update',
        'as' => 'admin.support.update',
        'namespace' => NULL,
        'prefix' => 'admin/support',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/medical',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@dashboard',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@dashboard',
        'as' => 'admin.medical.dashboard',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.doctors' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/medical/doctors',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctors',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctors',
        'as' => 'admin.medical.doctors',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.doctors.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/medical/doctors/{doctorProfile}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctorShow',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctorShow',
        'as' => 'admin.medical.doctors.show',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.doctors.approve' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/medical/doctors/{doctorProfile}/approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
          4 => 'can:medical.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctorApprove',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctorApprove',
        'as' => 'admin.medical.doctors.approve',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.doctors.reject' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/medical/doctors/{doctorProfile}/reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
          4 => 'can:medical.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctorReject',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctorReject',
        'as' => 'admin.medical.doctors.reject',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.doctors.suspend' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/medical/doctors/{doctorProfile}/suspend',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
          4 => 'can:medical.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctorSuspend',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctorSuspend',
        'as' => 'admin.medical.doctors.suspend',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.doctors.reactivate' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/medical/doctors/{doctorProfile}/reactivate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
          4 => 'can:medical.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctorReactivate',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@doctorReactivate',
        'as' => 'admin.medical.doctors.reactivate',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.consultations' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/medical/consultations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@consultations',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@consultations',
        'as' => 'admin.medical.consultations',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.consultations.show' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/medical/consultations/{consultation}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@consultationShow',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@consultationShow',
        'as' => 'admin.medical.consultations.show',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.medicine-orders' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/medical/medicine-orders',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicineOrders',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicineOrders',
        'as' => 'admin.medical.medicine-orders',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.medicine-orders.status' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/medical/medicine-orders/{medicineOrder}/status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
          4 => 'can:medical.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicineOrderUpdateStatus',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicineOrderUpdateStatus',
        'as' => 'admin.medical.medicine-orders.status',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.home-visits' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/medical/home-visits',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@homeVisits',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@homeVisits',
        'as' => 'admin.medical.home-visits',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.complaints' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/medical/complaints',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@complaints',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@complaints',
        'as' => 'admin.medical.complaints',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.complaints.review' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/medical/complaints/{complaint}/review',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
          4 => 'can:medical.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@complaintReview',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@complaintReview',
        'as' => 'admin.medical.complaints.review',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.medicines' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/medical/medicines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicines',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicines',
        'as' => 'admin.medical.medicines',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.medicines.store' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'admin/medical/medicines',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
          4 => 'can:medical.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicineStore',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicineStore',
        'as' => 'admin.medical.medicines.store',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.medicines.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/medical/medicines/{medicine}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
          4 => 'can:medical.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicineUpdate',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicineUpdate',
        'as' => 'admin.medical.medicines.update',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.medicines.destroy' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'admin/medical/medicines/{medicine}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
          4 => 'can:medical.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicineDelete',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@medicineDelete',
        'as' => 'admin.medical.medicines.destroy',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.financial-report' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/medical/financial-report',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalController@financialReport',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalController@financialReport',
        'as' => 'admin.medical.financial-report',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.settings' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'admin/medical/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalSettingController@index',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalSettingController@index',
        'as' => 'admin.medical.settings',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'admin.medical.settings.update' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'admin/medical/settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'auth',
          2 => 'admin',
          3 => 'can:medical.view',
          4 => 'can:medical.approve',
        ),
        'uses' => 'App\\Http\\Controllers\\Admin\\MedicalSettingController@update',
        'controller' => 'App\\Http\\Controllers\\Admin\\MedicalSettingController@update',
        'as' => 'admin.medical.settings.update',
        'namespace' => NULL,
        'prefix' => 'admin/medical',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'locale.switch' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'locale/{lang}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:162:"function ($lang) {
    $supported = [\'uz\', \'ru\', \'en\'];
    if (\\in_array($lang, $supported)) {
        \\session([\'locale\' => $lang]);
    }
    return \\back();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000f0c0000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'locale.switch',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e1fTHwFL3p1BQxuQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'run-update',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:1055:"function () {
    $output = [];
    try {
        \\Artisan::call(\'migrate\', [\'--force\' => true]);
        $output[] = \'✅ Migratsiya: \' . \\Artisan::output();

        \\Artisan::call(\'db:seed\', [\'--class\' => \'Database\\\\Seeders\\\\TranslationSeeder\', \'--force\' => true]);
        $output[] = \'✅ Tarjimalar yuklandi\';

        // user roli yaratish
        \\Spatie\\Permission\\Models\\Role::firstOrCreate([\'name\' => \'user\', \'guard_name\' => \'web\']);
        \\Spatie\\Permission\\Models\\Role::firstOrCreate([\'name\' => \'super-admin\', \'guard_name\' => \'web\']);
        $output[] = \'✅ Rollar yaratildi\';

        \\Artisan::call(\'cache:clear\');
        \\Artisan::call(\'view:clear\');
        $output[] = \'✅ Cache tozalandi\';

        return \'<pre style="font-size:16px;padding:20px;">\' . \\implode("\\n", $output) . "\\n\\n🎉 Yangilanish muvaffaqiyatli!</pre>";
    } catch (\\Throwable $e) {
        return \'<pre style="color:red;font-size:16px;padding:20px;">❌ Xato: \' . $e->getMessage() . "\\n\\n" . \\implode("\\n", $output) . \'</pre>\';
    }
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000e980000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::e1fTHwFL3p1BQxuQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'install.welcome' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'install',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\InstallerController@welcome',
        'controller' => 'App\\Http\\Controllers\\InstallerController@welcome',
        'as' => 'install.welcome',
        'namespace' => NULL,
        'prefix' => '/install',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'install.database' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'install/database',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\InstallerController@database',
        'controller' => 'App\\Http\\Controllers\\InstallerController@database',
        'as' => 'install.database',
        'namespace' => NULL,
        'prefix' => '/install',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'install.database.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'install/database',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\InstallerController@databaseSave',
        'controller' => 'App\\Http\\Controllers\\InstallerController@databaseSave',
        'as' => 'install.database.save',
        'namespace' => NULL,
        'prefix' => '/install',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'install.site' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'install/site',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\InstallerController@site',
        'controller' => 'App\\Http\\Controllers\\InstallerController@site',
        'as' => 'install.site',
        'namespace' => NULL,
        'prefix' => '/install',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'install.site.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'install/site',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\InstallerController@siteSave',
        'controller' => 'App\\Http\\Controllers\\InstallerController@siteSave',
        'as' => 'install.site.save',
        'namespace' => NULL,
        'prefix' => '/install',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'install.admin' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'install/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\InstallerController@admin',
        'controller' => 'App\\Http\\Controllers\\InstallerController@admin',
        'as' => 'install.admin',
        'namespace' => NULL,
        'prefix' => '/install',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'install.admin.save' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'install/admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\InstallerController@adminSave',
        'controller' => 'App\\Http\\Controllers\\InstallerController@adminSave',
        'as' => 'install.admin.save',
        'namespace' => NULL,
        'prefix' => '/install',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'install.process' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'install/process',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\InstallerController@process',
        'controller' => 'App\\Http\\Controllers\\InstallerController@process',
        'as' => 'install.process',
        'namespace' => NULL,
        'prefix' => '/install',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'install.run' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'install/run',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\InstallerController@run',
        'controller' => 'App\\Http\\Controllers\\InstallerController@run',
        'as' => 'install.run',
        'namespace' => NULL,
        'prefix' => '/install',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'install.complete' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'install/complete',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\InstallerController@complete',
        'controller' => 'App\\Http\\Controllers\\InstallerController@complete',
        'as' => 'install.complete',
        'namespace' => NULL,
        'prefix' => '/install',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:62:"/var/www/69abbde93330e/data/www/aisoqqa.uz/storage/app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:1;}s:8:"function";s:323:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ServeFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000010380000000000000000";}}',
        'as' => 'storage.local',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'storage.local.upload' => 
    array (
      'methods' => 
      array (
        0 => 'PUT',
      ),
      'uri' => 'storage/{path}',
      'action' => 
      array (
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:3:{s:4:"disk";s:5:"local";s:6:"config";a:5:{s:6:"driver";s:5:"local";s:4:"root";s:62:"/var/www/69abbde93330e/data/www/aisoqqa.uz/storage/app/private";s:5:"serve";b:1;s:5:"throw";b:0;s:6:"report";b:0;}s:12:"isProduction";b:1;}s:8:"function";s:325:"function (\\Illuminate\\Http\\Request $request, string $path) use ($disk, $config, $isProduction) {
                    return (new \\Illuminate\\Filesystem\\ReceiveFile(
                        $disk,
                        $config,
                        $isProduction
                    ))($request, $path);
                }";s:5:"scope";s:47:"Illuminate\\Filesystem\\FilesystemServiceProvider";s:4:"this";N;s:4:"self";s:32:"000000000000103a0000000000000000";}}',
        'as' => 'storage.local.upload',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'path' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
