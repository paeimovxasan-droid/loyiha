# 💎 TORTINMANG — Investitsiya Platformasi

> PHP 8.0+ · MySQL 8.0 · Telegram Mini App · Shared Hosting

---

## 🚀 Tez o'rnatish (install.php)

### 1. Fayllarni hostingga yuklang
Barcha `tortinmang/` papkasini hosting document root ga yuklang:
```
tortinmang/ → public_html/  (yoki app.tortinmang.uz papkasi)
```

### 2. Install wizard ni oching

Brauzerda:
```
https://app.tortinmang.uz/install.php
```

**Kirish kaliti:** `tortinmang_install_YYYYMMDD`  
(masalan bugun: `tortinmang_install_20260731`)

### 3. Wizard 6 qadamdan iborat:

| Qadam | Nima qiladi |
|-------|-------------|
| 1 | PHP, kengaytmalar, papka huquqlarini tekshiradi |
| 2 | MySQL bazasini yaratadi va schema import qiladi |
| 3 | `config.php` ni to'ldiradi (bot token, karta, kanal...) |
| 4 | Telegram webhook ni avtomatik o'rnatadi |
| 5 | Admin login va parolni sozlaydi |
| 6 | Natijalar va keyingi qadamlar |

### 4. Wizard tugagach darhol o'chiring:
```
install.php ni o'chiring (FTP yoki File Manager orqali)
```

---

## ⚙️ Qo'lda o'rnatish (agar wizard ishlamasa)

### MySQL baza
```sql
CREATE DATABASE tortinmang_db CHARACTER SET utf8mb4;
```
Keyin `database/schema.sql` import qiling.

### config.php
```php
'db' => ['host'=>'localhost', 'name'=>'tortinmang_db', 'user'=>'...', 'pass'=>'...'],
'telegram' => ['bot_token'=>'...', 'bot_username'=>'tortinmang_bot', 'channel_id'=>'@tortinmang_app'],
'finance'  => ['deposit_card_uzcard'=>'8600 XXXX XXXX XXXX', 'card_holder'=>'Ism'],
```

### Webhook
```
https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://app.tortinmang.uz/bot/webhook.php
```

### BotFather
```
/setmenubutton → Web App → https://app.tortinmang.uz/miniapp/ → 🚀 Tortinmang
```

### Cron (kunlik daromad)
```
5 0 * * * php /home/user/app.tortinmang.uz/jobs/DailyProfit.php
```

---

## 📁 Tuzilma

```
tortinmang/
├── install.php          ← O'rnatish wizardi (ishlatib o'chiring!)
├── config.php           ← Konfiguratsiya
├── bootstrap.php        ← Autoloader
├── .htaccess            ← Xavfsizlik + routing
│
├── api/v1/              ← API endpointlar
│   ├── auth.php         ← Telegram auth + kanal tekshiruv
│   ├── wallet.php       ← Balans, depozit, yechish, bonus
│   ├── invest.php       ← Paketlar, investitsiyalar
│   ├── referral.php     ← Referal tizimi
│   ├── tasks.php        ← Vazifalar
│   ├── lottery.php      ← Lotereya
│   ├── vip.php          ← VIP a'zolik
│   ├── promo.php        ← Promo kodlar
│   ├── achievements.php ← Yutuqlar
│   ├── leaderboard.php  ← Reyting
│   ├── feed.php         ← To'lov lenti
│   └── notify.php       ← Yangiliklar
│
├── core/                ← Framework
│   ├── Auth.php         ← Telegram HMAC validatsiya
│   ├── DB.php           ← PDO wrapper
│   ├── Config.php       ← Konfiguratsiya
│   ├── TelegramBot.php  ← Bot API
│   ├── RateLimiter.php  ← So'rov cheklash
│   └── ...
│
├── models/              ← Ma'lumotlar modellari
│   ├── User.php
│   ├── Investment.php
│   ├── Transaction.php
│   └── Referral.php
│
├── miniapp/             ← Telegram Mini App
│   ├── index.html       ← Asosiy sahifa
│   └── js/app.js        ← ~55KB, barcha funksiyalar
│
├── admin/               ← Admin panel
│   └── index.php        ← To'liq admin boshqaruv paneli
│
├── bot/webhook.php      ← Telegram bot handler
├── jobs/DailyProfit.php ← Cron: kunlik daromad
└── database/
    ├── schema.sql        ← Asosiy schema + seed data
    └── update_v4.sql     ← Mavjud baza uchun yangilanish
```

---

## 🔐 Admin panel

```
URL:   https://app.tortinmang.uz/admin/
Login: admin
Parol: install.php Step 5 da belgilangan
```

**Sahifalar:** Dashboard · Depozitlar · Yechishlar · Foydalanuvchilar · Investitsiyalar · Paketlar · Promo · Yangiliklar · Broadcast · Sozlamalar · Parol

---

## 📡 API endpointlar

| Endpoint | Amallar |
|----------|---------|
| `auth.php` | Auth + kanal tekshiruv |
| `wallet.php` | `balance, deposit_info, deposit_create, withdraw_create, daily_bonus, deposit_history, withdraw_history` |
| `invest.php` | `packages, create, my_investments, stats` |
| `referral.php` | `stats, history, tree` |
| `tasks.php` | `list, complete` |
| `lottery.php` | `status, spin` |
| `vip.php` | `tiers, my_status, purchase` |
| `promo.php` | `redeem, check` |
| `achievements.php` | `list, claim` |
| `leaderboard.php` | `top_earners, top_referrals, weekly, my_rank` |
| `feed.php` | `list, stats` |
| `notify.php` | Yangiliklar |
| `channel.php` | Kanal a'zolik tekshiruv |

---

## 🔑 Xavfsizlik eslatmalari

- `install.php` → ishlatilgandan so'ng **o'chiring**
- `admin/reset_admin.php` → vaqtincha fayl, ishlatib **o'chiring**
- `api/v1/debug.php` → `.htaccess` da bloklangan (debug vaqtida ochiq)
- Admin parolini **darhol o'zgartiring**
- `config.php` → FTP ga yopiq bo'lishi kerak

---

## ⚠️ Mavjud bazani yangilash (v4)

Agar baza allaqachon o'rnatilgan bo'lsa:
```sql
-- phpMyAdmin → SQL tab:
source database/update_v4.sql
```
