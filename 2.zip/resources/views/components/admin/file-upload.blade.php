@php
$uid = 'fu_' . uniqid();
@endphp

@props([
    'name'       => 'photo_id',
    'folder'     => 'uploads',
    'currentUrl' => null,
    'currentId'  => null,
    'label'      => 'Rasm',
    'accept'     => 'image/*',
])

{{-- Hidden ID field --}}
<input type="hidden" name="{{ $name }}" id="{{ $uid }}_id" value="{{ $currentId }}">

<div class="file-upload-widget" id="{{ $uid }}"
     data-folder="{{ $folder }}"
     data-upload-url="{{ route('admin.upload') }}">

    {{-- Label --}}
    <span style="display: block; font-size: 12px; font-weight: 600; color: var(--text-secondary); margin-bottom: 8px;">{{ $label }}</span>

    {{-- Preview --}}
    <div id="{{ $uid }}_preview"
         style="display: {{ $currentUrl ? 'block' : 'none' }}; position: relative; border-radius: 10px; overflow: hidden; border: 1px solid var(--border); margin-bottom: 8px;">
        <img id="{{ $uid }}_img"
             src="{{ $currentUrl ?? '' }}"
             alt="preview"
             style="width: 100%; max-height: 200px; object-fit: cover; display: block;"
             onerror="this.onerror=null; this.src=''; resetUpload('{{ $uid }}')">
        <button type="button"
                onclick="resetUpload('{{ $uid }}')"
                style="position: absolute; top: 8px; right: 8px; width: 28px; height: 28px; border-radius: 50%;
                       background: rgba(239,68,68,.9); border: none; color: #fff; cursor: pointer; display: flex;
                       align-items: center; justify-content: center; font-size: 12px;">
            <i class="fa fa-times"></i>
        </button>
    </div>

    {{-- Upload zone --}}
    <div id="{{ $uid }}_zone"
         style="display: {{ $currentUrl ? 'none' : 'block' }};">
        <label id="{{ $uid }}_label"
               style="display: flex; flex-direction: column; align-items: center; justify-content: center;
                      border: 2px dashed var(--border); border-radius: 10px; padding: 24px 16px;
                      text-align: center; cursor: pointer; transition: all .2s; position: relative;"
               onmouseenter="this.style.borderColor='var(--primary-light)'"
               onmouseleave="this.style.borderColor='var(--border)'">

            {{-- Spinner --}}
            <div id="{{ $uid }}_spinner"
                 style="display: none; position: absolute; inset: 0; background: rgba(0,0,0,.3);
                        border-radius: 10px; align-items: center; justify-content: center; z-index: 10;">
                <i class="fa fa-spinner fa-spin" style="font-size: 24px; color: var(--primary-light);"></i>
            </div>

            <i class="fa fa-cloud-arrow-up" style="font-size: 28px; color: var(--text-muted); margin-bottom: 8px;"></i>
            <span style="font-size: 13px; font-weight: 500; color: var(--text-primary);">Rasm yuklash</span>
            <span style="font-size: 11px; color: var(--text-muted); margin-top: 4px;">PNG, JPG, WEBP — max 10MB</span>

            <input type="file"
                   accept="{{ $accept }}"
                   style="display: none;"
                   id="{{ $uid }}_input"
                   onchange="handleFileUpload('{{ $uid }}', this)">
        </label>

        <p id="{{ $uid }}_error" style="display: none; margin-top: 6px; font-size: 12px; color: var(--danger);"></p>
    </div>
</div>
