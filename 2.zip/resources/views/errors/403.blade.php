<!doctype html>
<html lang="uz">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

    <title>Xatolik 403 - Taqiqlangan</title>
    <link rel="icon" type="image/png" href="{{ asset('admin_assets/images/favicon.png') }}">

    <link rel="stylesheet" href="{{ asset('admin_assets/css/app.css') }}">
    <script src="{{ asset('admin_assets/js/app.js') }}" defer></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
    <script>
      localStorage.getItem("_x_darkMode_on") === "true" && document.documentElement.classList.add("dark");
    </script>
  </head>
  <body x-data="" class="is-header-blur" x-bind="$store.global.documentBody">
    <div class="app-preloader fixed z-50 grid h-full w-full place-content-center bg-slate-50 dark:bg-navy-900">
      <div class="app-preloader-inner relative inline-block size-48"></div>
    </div>

    <div id="root" class="min-h-100vh flex grow bg-slate-50 dark:bg-navy-900" x-cloak>
      <main class="grid w-full grow grid-cols-1 place-items-center">
        <div class="max-w-md p-6 text-center">
          <div class="w-full">
            <img class="w-full" src="{{ asset('admin_assets/images/illustrations/error-401.svg') }}" alt="image">
          </div>
          <p class="pt-4 text-7xl font-bold text-primary dark:text-accent">
            403
          </p>
          <p class="pt-4 text-xl font-semibold text-slate-800 dark:text-navy-50">
            Sizda ruxsat yo'q
          </p>
          <p class="pt-2 text-slate-500 dark:text-navy-200">
            Kechirasiz, ammo ushbu sahifaga kirish yoki siz xohlagan harakatni bajarish uchun sizda yetarli ruxsat va huquqlar mavjud emas.
          </p>

          <a href="{{ url('/') }}" class="btn mt-8 h-11 bg-primary text-base font-medium text-white hover:bg-primary-focus hover:shadow-lg hover:shadow-primary/50 focus:bg-primary-focus focus:shadow-lg focus:shadow-primary/50 active:bg-primary-focus/90 dark:bg-accent dark:hover:bg-accent-focus dark:hover:shadow-accent/50 dark:focus:bg-accent-focus dark:focus:shadow-accent/50 dark:active:bg-accent/90">
            Bosh sahifaga qaytish
          </a>
        </div>
      </main>
    </div>

    <div id="x-teleport-target"></div>
    <script>
      window.addEventListener("DOMContentLoaded", () => Alpine.start());
    </script>
  </body>
</html>
