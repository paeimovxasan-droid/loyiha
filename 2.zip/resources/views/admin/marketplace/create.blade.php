@extends('admin.layouts.app')
@section('title', 'Yangi Gig yaratish')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.marketplace.index') }}">Marketplace</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Yangi Gig</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.marketplace.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> Orqaga
    </a>
@endsection

@section('content')

@if($errors->any())
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: rgba(239,68,68,.08); border: 1px solid rgba(239,68,68,.2); color: var(--danger);">
    <ul style="margin: 0; padding-left: 20px;">
        @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
    </ul>
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">🏪 Yangi Gig yaratish</h3>
    </div>
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.marketplace.store') }}">
            @csrf
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label">Sarlavha</label>
                    <input type="text" name="title" value="{{ old('title') }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Narx (AIS)</label>
                    <input type="number" step="0.01" name="price" value="{{ old('price') }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Holat</label>
                    <select name="status" class="form-control">
                        <option value="pending" {{ old('status') == 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="active" {{ old('status') == 'active' ? 'selected' : '' }}>Active</option>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Foydalanuvchi ID</label>
                    <input type="number" name="user_id" value="{{ old('user_id') }}" required class="form-control">
                </div>
                <div class="form-group" style="grid-column: span 2;">
                    <label class="form-label">Tavsif</label>
                    <textarea name="description" rows="4" class="form-control">{{ old('description') }}</textarea>
                </div>
            </div>
            <div style="margin-top: 20px; display: flex; justify-content: flex-end;">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save" style="margin-right: 4px;"></i> Saqlash
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
