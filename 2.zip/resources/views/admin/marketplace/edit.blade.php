@extends('admin.layouts.app')
@section('title', 'Gig tahrirlash')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.marketplace.index') }}">Marketplace</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Tahrirlash #{{ $gig->id }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.marketplace.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> Orqaga
    </a>
@endsection

@section('content')
@if($errors->any())
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid rgba(var(--danger-rgb), 0.3); color: var(--danger); margin-bottom: 16px;">
    <ul style="list-style: disc; padding-left: 20px; margin: 0;">
        @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
    </ul>
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">🏪 Gig tahrirlash #{{ $gig->id }}</h3>
    </div>
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.marketplace.update', $gig) }}">
            @csrf
            @method('PUT')
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label">Foydalanuvchi</label>
                    <input type="text" value="{{ $gig->user->name ?? '—' }}" disabled class="form-control" style="opacity: 0.7;">
                </div>
                <div class="form-group">
                    <label class="form-label">Sarlavha</label>
                    <input type="text" name="title" value="{{ old('title', $gig->title) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Narx (AIS)</label>
                    <input type="number" step="0.01" name="price" value="{{ old('price', $gig->price) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Holat</label>
                    <select name="status" class="form-control">
                        @foreach(['active','pending','paused','rejected'] as $s)
                        <option value="{{ $s }}" {{ old('status', $gig->status) == $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group" style="grid-column: span 2;">
                    <label class="form-label">Tavsif</label>
                    <textarea name="description" rows="4" class="form-control">{{ old('description', $gig->description) }}</textarea>
                </div>
            </div>
            <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
                <button type="submit" class="btn btn-primary btn-sm">Yangilash</button>
            </div>
        </form>
    </div>
</div>
@endsection
