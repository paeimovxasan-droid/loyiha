@extends('admin.layouts.app')
@section('title', 'Marketplace')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Marketplace</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.marketplace.create') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-plus"></i> Yangi qo'shish
    </a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid rgba(var(--success-rgb), 0.3); color: var(--success); margin-bottom: 16px;">
    {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">🏪 Marketplace (Freelance)</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Foydalanuvchi</th>
                        <th>Sarlavha</th>
                        <th style="text-align: center;">Narx</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($gigs as $gig)
                    <tr>
                        <td style="color: var(--text-muted);">#{{ $gig->id }}</td>
                        <td style="color: var(--text-primary);">{{ $gig->user->name ?? '—' }}</td>
                        <td style="color: var(--text-primary);">{{ $gig->title ?? '—' }}</td>
                        <td style="text-align: center; font-weight: 600; color: var(--text-primary);">{{ number_format($gig->price ?? 0, 2) }} AIS</td>
                        <td style="text-align: center;">
                            @if(($gig->status ?? '') == 'active')
                                <span class="badge badge-success">Active</span>
                            @elseif(($gig->status ?? '') == 'pending')
                                <span class="badge badge-warning">Pending</span>
                            @elseif(($gig->status ?? '') == 'paused')
                                <span class="badge badge-info">Paused</span>
                            @elseif(($gig->status ?? '') == 'rejected')
                                <span class="badge badge-danger">Rejected</span>
                            @else
                                <span class="badge badge-warning">{{ ucfirst($gig->status ?? 'pending') }}</span>
                            @endif
                        </td>
                        <td style="text-align: center; color: var(--text-muted); font-size: 12px;">{{ $gig->created_at->format('d.m.Y') }}</td>
                        <td style="text-align: center;">
                            <div style="display: flex; align-items: center; justify-content: center; gap: 4px;">
                                <a href="{{ route('admin.marketplace.edit', $gig) }}" class="btn btn-outline btn-sm" title="Tahrirlash">
                                    <i class="fa fa-pen"></i>
                                </a>
                                <form method="POST" action="{{ route('admin.marketplace.destroy', $gig) }}" style="display: inline;">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('O\'chirishni tasdiqlaysizmi?')" title="O'chirish">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            <i class="fa fa-store" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Gig topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $gigs->withQueryString()->links() }}
        </div>
    </div>
</div>
@endsection
