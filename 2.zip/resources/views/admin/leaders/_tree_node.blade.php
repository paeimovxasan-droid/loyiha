@foreach($nodes as $node)
@php
    $ref = $node['user'];
    $ul  = $ref->userLevel;
    $colors = ['#6366f1','#06b6d4','#10b981'];
    $color  = $colors[min($depth - 1, 2)];
@endphp
<div style="margin-left:{{ ($depth - 1) * 24 }}px; margin-top:8px;">
    <div style="display:flex; align-items:center; gap:2px; margin-bottom:4px;">
        <div style="width:{{ ($depth - 1) * 24 }}px; display:flex; align-items:center; justify-content:flex-end; padding-right:8px;">
            @if($depth > 1)
            <div style="width:16px; height:1px; background:{{ $color }}44;"></div>
            @endif
        </div>
    </div>
    <div class="flex items-center gap-3 p-2.5 rounded-xl border"
         style="border-color:{{ $color }}22; background:{{ $color }}08;">
        <img src="{{ $ref->avatar_url }}" class="w-8 h-8 rounded-lg object-cover flex-shrink-0">
        <div class="flex-1 min-w-0">
            <div class="text-sm font-medium text-slate-700 dark:text-navy-100 truncate">{{ $ref->name }}</div>
            <div class="text-xs text-slate-400">{{ $ref->username ?? '—' }}</div>
        </div>
        <div class="text-right flex-shrink-0">
            @if($ul)
            <span class="text-xs font-bold px-2 py-0.5 rounded-lg"
                  style="background:{{ $ul->badge_color }}22; color:{{ $ul->badge_color }};">
                Lv.{{ $ul->level }}
            </span>
            @endif
            <div class="text-xs text-slate-400 mt-0.5">{{ $ref->status }}</div>
        </div>
    </div>

    @if(!empty($node['children']))
        @include('admin.leaders._tree_node', ['nodes' => $node['children'], 'depth' => $depth + 1])
    @endif
</div>
@endforeach
