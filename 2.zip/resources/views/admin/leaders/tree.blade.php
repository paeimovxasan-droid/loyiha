@extends('admin.layouts.app')
@section('title', $user->name . ' — Referral daraxti')

@section('breadcrumb')
    <a href="{{ route('admin.leaders.index') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Referral daraxti</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.leaders.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> Orqaga
    </a>
@endsection

@section('content')
{{-- Statistika --}}
<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 20px;">
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--text-primary);">{{ $stats['level1_count'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">1-daraja</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--info);">{{ $stats['level2_count'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">2-daraja</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--success);">{{ $stats['total_team'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Jami jamoa</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--warning);">Lv.{{ $stats['user_level'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">{{ number_format($stats['total_xp']) }} XP</div>
    </div>
</div>

{{-- Daraxt --}}
<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">🌳 {{ $user->name }} — Referral daraxti</h3>
    </div>
    <div class="admin-card-body">
        {{-- Root --}}
        <div style="display: flex; align-items: center; gap: 12px; padding: 12px; border-radius: 8px; background: var(--primary-light); border: 1px solid var(--border); margin-bottom: 16px;">
            <img src="{{ $user->avatar_url }}" style="width: 40px; height: 40px; border-radius: 8px; object-fit: cover;">
            <div>
                <div style="font-weight: 600; color: var(--text-primary);">{{ $user->name }}</div>
                <div style="font-size: 12px; color: var(--text-muted);">{{ $user->username ?? '—' }} · Lv.{{ $stats['user_level'] }}</div>
            </div>
            @if($user->is_leader)
            <span class="badge badge-warning" style="margin-left: auto;">
                <i class="fa fa-crown"></i> Lider
            </span>
            @endif
        </div>

        @include('admin.leaders._tree_node', ['nodes' => $tree, 'depth' => 1])
    </div>
</div>
@endsection
