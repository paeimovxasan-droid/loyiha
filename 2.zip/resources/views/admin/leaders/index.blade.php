@extends('admin.layouts.app')
@section('title', 'Lider Paneli')

@section('breadcrumb')
    <a href="{{ route('admin.leaders.index') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Liderlar</span>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 16px;">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif

{{-- Statistika --}}
<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 20px;">
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--text-primary);">{{ $stats['total_leaders'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Liderlar</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--text-primary);">{{ number_format($stats['total_users']) }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Jami foydalanuvchi</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--warning);">{{ $stats['top_level'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Eng yuqori level</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--success);">{{ number_format($stats['total_xp']) }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Jami XP</div>
    </div>
</div>

{{-- Filter --}}
<div style="margin-bottom: 16px;">
    <form method="GET" style="display: flex; gap: 8px;">
        <input type="text" name="search" value="{{ request('search') }}"
               placeholder="Ism, username, email..."
               class="form-control" style="flex: 1;">
        <select name="filter" class="form-control" style="width: auto;">
            <option value="">Barchasi</option>
            <option value="leaders" {{ request('filter') === 'leaders' ? 'selected' : '' }}>Faqat liderlar</option>
            <option value="top_xp" {{ request('filter') === 'top_xp' ? 'selected' : '' }}>XP bo'yicha</option>
        </select>
        <button type="submit" class="btn btn-primary btn-sm">
            <i class="fa fa-search"></i>
        </button>
    </form>
</div>

{{-- Jadval --}}
<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Foydalanuvchi</th>
                        <th style="text-align: center;">Level</th>
                        <th style="text-align: center;">XP</th>
                        <th style="text-align: center;">Referrallar</th>
                        <th style="text-align: center;">Xaridlar</th>
                        <th style="text-align: center;">Lider</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($users as $user)
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <img src="{{ $user->avatar_url }}" style="width: 36px; height: 36px; border-radius: 8px; object-fit: cover;">
                                <div>
                                    <div style="font-weight: 500; color: var(--text-primary);">{{ $user->name }}</div>
                                    <div style="font-size: 12px; color: var(--text-muted);">{{ $user->username ? '@'.$user->username : '—' }}</div>
                                </div>
                            </div>
                        </td>
                        <td style="text-align: center;">
                            @php $ul = $user->userLevel; @endphp
                            @if($ul)
                            <span class="badge" style="background: {{ $ul->badge_color }}22; color: {{ $ul->badge_color }}; font-weight: 700;">
                                Lv.{{ $ul->level }}
                            </span>
                            @else
                            <span style="color: var(--text-muted); font-size: 12px;">Lv.0</span>
                            @endif
                        </td>
                        <td style="text-align: center; font-weight: 600; color: var(--text-secondary);">
                            {{ number_format($ul?->total_xp ?? 0) }}
                        </td>
                        <td style="text-align: center;">{{ $user->referrals_count }}</td>
                        <td style="text-align: center;">{{ $user->purchases_count }}</td>
                        <td style="text-align: center;">
                            @if($user->is_leader)
                            <span class="badge badge-warning">
                                <i class="fa fa-crown"></i> Lider
                            </span>
                            @else
                            <span style="color: var(--text-muted);">—</span>
                            @endif
                        </td>
                        <td style="text-align: center;">
                            <div style="display: flex; align-items: center; justify-content: center; gap: 6px;">
                                <a href="{{ route('admin.leaders.tree', $user) }}" class="btn btn-primary btn-sm">
                                    <i class="fa fa-sitemap"></i>
                                </a>
                                <form method="POST" action="{{ route('admin.leaders.toggle', $user) }}" style="display: inline;">
                                    @csrf
                                    <button type="submit" class="btn {{ $user->is_leader ? 'btn-danger' : 'btn-success' }} btn-sm">
                                        <i class="fa fa-{{ $user->is_leader ? 'minus' : 'crown' }}"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="fa fa-users" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Foydalanuvchi topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($users->hasPages())
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $users->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
