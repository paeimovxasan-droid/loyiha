@extends('admin.layouts.app')

@section('title', __('nav.admins'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('nav.admins') }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.admins.create') }}" class="btn btn-primary">
        <i class="fa fa-plus" style="margin-right: 6px;"></i> {{ __('buttons.add_new') }}
    </a>
@endsection

@section('content')
    {{-- Filters --}}
    <div class="admin-card" style="padding: 16px 24px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between;">
        <h3 style="font-size: 15px; font-weight: 600; color: var(--text-primary);">{{ __('admins.list') }}</h3>
        <div style="display: flex; align-items: center; gap: 12px;">
            <form action="{{ route('admin.admins.index') }}" method="GET" style="display: flex; align-items: center; gap: 8px;">
                <input name="search" value="{{ request('search') }}" class="form-control" style="width: 200px; height: 36px; font-size: 13px;" placeholder="{{ __('buttons.search') }}..." type="text">
                <select name="status" onchange="this.form.submit()" class="form-control" style="width: 140px; height: 36px; font-size: 13px;">
                    <option value="">{{ __('table.status') }}</option>
                    <option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>{{ __('status.active') }}</option>
                    <option value="banned" {{ request('status') === 'banned' ? 'selected' : '' }}>{{ __('status.banned') }}</option>
                </select>
                @if(request()->anyFilled(['search', 'status']))
                    <a href="{{ route('admin.admins.index') }}" class="btn btn-outline" style="height: 36px; padding: 0 12px; font-size: 13px;" title="{{ __('buttons.clear') }}">
                        <i class="fa fa-times"></i>
                    </a>
                @endif
            </form>
        </div>
    </div>

    {{-- Table --}}
    <div class="admin-card" style="overflow: hidden;">
        <div style="overflow-x: auto;">
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: var(--bg-card); border-bottom: 1px solid var(--border);">
                        <th style="padding: 12px 20px; text-align: left; font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--text-muted);">{{ __('common.user') }}</th>
                        <th style="padding: 12px 20px; text-align: left; font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--text-muted);">{{ __('table.role') }}</th>
                        <th style="padding: 12px 20px; text-align: left; font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--text-muted);">{{ __('table.contact') }}</th>
                        <th style="padding: 12px 20px; text-align: left; font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--text-muted);">{{ __('table.balance') }}</th>
                        <th style="padding: 12px 20px; text-align: left; font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--text-muted);">{{ __('table.status') }}</th>
                        <th style="padding: 12px 20px; text-align: right; font-size: 12px; font-weight: 600; text-transform: uppercase; color: var(--text-muted);">{{ __('table.actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($admins as $admin)
                        <tr style="border-bottom: 1px solid var(--border);">
                            <td style="padding: 12px 20px;">
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <img src="{{ $admin->avatar_url }}" alt="avatar" style="width: 40px; height: 40px; border-radius: 50%; object-fit: cover;">
                                    <div>
                                        <p style="font-weight: 500; color: var(--text-primary); margin: 0;">{{ $admin->name }}</p>
                                        <p style="font-size: 12px; color: var(--text-muted); margin: 2px 0 0;">{{ '@' . $admin->username }}</p>
                                    </div>
                                </div>
                            </td>
                            <td style="padding: 12px 20px;">
                                @foreach($admin->roles as $role)
                                    <span style="display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 12px; font-weight: 500; background: var(--primary-light); color: white;">{{ $role->name }}</span>
                                @endforeach
                            </td>
                            <td style="padding: 12px 20px;">
                                <p style="font-size: 13px; font-weight: 500; color: var(--text-primary); margin: 0;">{{ $admin->email }}</p>
                                <p style="font-size: 12px; color: var(--text-muted); margin: 2px 0 0;">{{ $admin->phone ?? '-' }}</p>
                            </td>
                            <td style="padding: 12px 20px; font-weight: 600; color: var(--text-primary);">
                                ${{ number_format($admin->balance ?? 0, 2) }}
                            </td>
                            <td style="padding: 12px 20px;">
                                @if($admin->status === 'active')
                                    <span style="display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 12px; font-weight: 500; background: var(--success); color: white;">{{ __('status.active') }}</span>
                                @else
                                    <span style="display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 12px; font-weight: 500; background: var(--danger); color: white;">{{ __('status.banned') }}</span>
                                @endif
                            </td>
                            <td style="padding: 12px 20px; text-align: right;">
                                <div style="display: flex; align-items: center; justify-content: flex-end; gap: 8px;">
                                    <a href="{{ route('admin.admins.edit', $admin) }}" title="{{ __('buttons.edit') }}" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; color: var(--primary-light); transition: background 0.2s;" onmouseover="this.style.background='rgba(99,102,241,0.1)'" onmouseout="this.style.background='transparent'">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    @can('users.ban')
                                    <form method="POST" action="{{ route('admin.admins.ban', $admin) }}" onsubmit="return confirm('{{ addslashes(__('messages.confirm_action')) }}');">
                                        @csrf
                                        <button type="submit" title="{{ $admin->status === 'active' ? __('buttons.ban') : __('buttons.unban') }}" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; border: none; background: transparent; cursor: pointer; color: {{ $admin->status === 'active' ? 'var(--warning)' : 'var(--success)' }};" onmouseover="this.style.background='rgba(0,0,0,0.05)'" onmouseout="this.style.background='transparent'">
                                            <i class="fa {{ $admin->status === 'active' ? 'fa-ban' : 'fa-check' }}"></i>
                                        </button>
                                    </form>
                                    @endcan

                                    <form method="POST" action="{{ route('admin.admins.destroy', $admin) }}" onsubmit="return confirm('{{ addslashes(__('messages.confirm_action')) }}');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" title="{{ __('buttons.delete') }}" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; border: none; background: transparent; cursor: pointer; color: var(--danger);" onmouseover="this.style.background='rgba(239,68,68,0.1)'" onmouseout="this.style.background='transparent'">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    </form>

                                    {{-- More actions dropdown --}}
                                    <div style="position: relative; display: inline-block;">
                                        <button onclick="toggleDropdown(this)" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; border: none; background: transparent; cursor: pointer; color: var(--text-muted);" onmouseover="this.style.background='rgba(0,0,0,0.05)'" onmouseout="this.style.background='transparent'">
                                            <i class="fa fa-ellipsis-v"></i>
                                        </button>
                                        <div class="action-dropdown" style="display: none; position: absolute; right: 0; top: 100%; z-index: 50; min-width: 160px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); padding: 4px 0;">
                                            @can('roles.assign')
                                            <button type="button" onclick="openRoleModal({{ $admin->id }}, '{{ $admin->roles->first()?->name ?? '' }}')" style="display: block; width: 100%; text-align: left; padding: 8px 16px; border: none; background: none; cursor: pointer; font-size: 13px; color: var(--text-primary);" onmouseover="this.style.background='rgba(0,0,0,0.04)'" onmouseout="this.style.background='none'">
                                                <i class="fa fa-user-tag" style="margin-right: 8px; color: var(--text-muted);"></i> {{ __('admins.change_role') }}
                                            </button>
                                            @endcan
                                            @can('users.balance-adjust')
                                            <button type="button" onclick="openBalanceModal({{ $admin->id }}, {{ $admin->balance }})" style="display: block; width: 100%; text-align: left; padding: 8px 16px; border: none; background: none; cursor: pointer; font-size: 13px; color: var(--text-primary);" onmouseover="this.style.background='rgba(0,0,0,0.04)'" onmouseout="this.style.background='none'">
                                                <i class="fa fa-wallet" style="margin-right: 8px; color: var(--text-muted);"></i> {{ __('admins.edit_balance') }}
                                            </button>
                                            @endcan
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" style="text-align: center; padding: 40px 20px; color: var(--text-muted);">{{ __('admins.not_found') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($admins->hasPages())
            <div style="display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; border-top: 1px solid var(--border);">
                <span style="font-size: 13px; color: var(--text-muted);">
                    {{ __('admins.total_records', ['total' => $admins->total(), 'first' => $admins->firstItem() ?? 0, 'last' => $admins->lastItem() ?? 0]) }}
                </span>
                <div style="display: flex; gap: 4px;">
                    @if ($admins->onFirstPage())
                        <span style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--border); color: var(--text-muted); cursor: not-allowed;">
                            <i class="fa fa-chevron-left" style="font-size: 11px;"></i>
                        </span>
                    @else
                        <a href="{{ $admins->previousPageUrl() }}" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--border); color: var(--text-primary); text-decoration: none;">
                            <i class="fa fa-chevron-left" style="font-size: 11px;"></i>
                        </a>
                    @endif

                    @foreach ($admins->links()->elements[0] as $page => $url)
                        @if ($page == $admins->currentPage())
                            <span style="min-width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--primary-light); color: white; font-size: 13px; font-weight: 500; padding: 0 8px;">{{ $page }}</span>
                        @else
                            <a href="{{ $url }}" style="min-width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--border); color: var(--text-primary); text-decoration: none; font-size: 13px; padding: 0 8px;">{{ $page }}</a>
                        @endif
                    @endforeach

                    @if ($admins->hasMorePages())
                        <a href="{{ $admins->nextPageUrl() }}" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--border); color: var(--text-primary); text-decoration: none;">
                            <i class="fa fa-chevron-right" style="font-size: 11px;"></i>
                        </a>
                    @else
                        <span style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center; border-radius: 6px; background: var(--border); color: var(--text-muted); cursor: not-allowed;">
                            <i class="fa fa-chevron-right" style="font-size: 11px;"></i>
                        </span>
                    @endif
                </div>
            </div>
        @endif
    </div>

    {{-- Role Modal --}}
    @can('roles.assign')
    <div id="roleModal" style="display: none; position: fixed; inset: 0; z-index: 1000; align-items: center; justify-content: center; background: rgba(0,0,0,0.5);">
        <div style="background: var(--bg-card); border-radius: 12px; padding: 24px; width: 100%; max-width: 400px; box-shadow: 0 20px 60px rgba(0,0,0,0.2);">
            <h3 style="font-size: 16px; font-weight: 600; color: var(--text-primary); margin-bottom: 16px;">{{ __('admins.change_role') }}</h3>
            <form id="roleForm" method="POST">
                @csrf
                <div class="form-group">
                    <label class="form-label">{{ __('admins.roles_label') }}</label>
                    <select name="role" id="roleSelect" class="form-control">
                        @foreach($roles as $role)
                            <option value="{{ $role->name }}">{{ $role->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div style="display: flex; justify-content: flex-end; gap: 8px; margin-top: 20px;">
                    <button type="button" onclick="closeRoleModal()" class="btn btn-outline">{{ __('buttons.cancel') }}</button>
                    <button type="submit" class="btn btn-primary">{{ __('buttons.save') }}</button>
                </div>
            </form>
        </div>
    </div>
    @endcan

    {{-- Balance Modal --}}
    @can('users.balance-adjust')
    <div id="balanceModal" style="display: none; position: fixed; inset: 0; z-index: 1000; align-items: center; justify-content: center; background: rgba(0,0,0,0.5);">
        <div style="background: var(--bg-card); border-radius: 12px; padding: 24px; width: 100%; max-width: 400px; box-shadow: 0 20px 60px rgba(0,0,0,0.2);">
            <h3 style="font-size: 16px; font-weight: 600; color: var(--text-primary); margin-bottom: 8px;">{{ __('admins.edit_balance') }}</h3>
            <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 16px;">{{ __('admins.current_balance') }} <strong id="currentBalanceDisplay" style="color: var(--primary-light);">$0.00</strong></p>
            <form id="balanceForm" method="POST">
                @csrf
                <div class="form-group" style="margin-bottom: 12px;">
                    <div style="display: flex; gap: 16px;">
                        <label style="display: flex; align-items: center; gap: 6px; cursor: pointer;">
                            <input type="radio" name="action" value="add" checked style="accent-color: var(--primary-light);">
                            <span style="font-size: 13px; color: var(--text-primary);">{{ __('admins.add') }}</span>
                        </label>
                        <label style="display: flex; align-items: center; gap: 6px; cursor: pointer;">
                            <input type="radio" name="action" value="subtract" style="accent-color: var(--danger);">
                            <span style="font-size: 13px; color: var(--text-primary);">{{ __('admins.subtract') }}</span>
                        </label>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">{{ __('admins.amount_usd') }}</label>
                    <input name="amount" type="number" step="0.01" min="0.01" required class="form-control" placeholder="{{ __('admins.amount_example') }}">
                </div>
                <div style="display: flex; justify-content: flex-end; gap: 8px; margin-top: 20px;">
                    <button type="button" onclick="closeBalanceModal()" class="btn btn-outline">{{ __('buttons.cancel') }}</button>
                    <button type="submit" class="btn btn-primary">{{ __('buttons.approve') }}</button>
                </div>
            </form>
        </div>
    </div>
    @endcan

    <script>
        // Dropdown toggle
        function toggleDropdown(btn) {
            const dropdown = btn.nextElementSibling;
            const isVisible = dropdown.style.display === 'block';

            // Close all other dropdowns
            document.querySelectorAll('.action-dropdown').forEach(d => d.style.display = 'none');

            dropdown.style.display = isVisible ? 'none' : 'block';
        }

        // Close dropdowns on outside click
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.action-dropdown') && !e.target.closest('[onclick*="toggleDropdown"]')) {
                document.querySelectorAll('.action-dropdown').forEach(d => d.style.display = 'none');
            }
        });

        // Role Modal
        function openRoleModal(userId, currentRole) {
            document.querySelectorAll('.action-dropdown').forEach(d => d.style.display = 'none');
            const modal = document.getElementById('roleModal');
            const form = document.getElementById('roleForm');
            const select = document.getElementById('roleSelect');

            form.action = '/admin/admins/' + userId + '/role';
            if (currentRole) {
                select.value = currentRole;
            }
            modal.style.display = 'flex';
        }

        function closeRoleModal() {
            document.getElementById('roleModal').style.display = 'none';
        }

        // Balance Modal
        function openBalanceModal(userId, balance) {
            document.querySelectorAll('.action-dropdown').forEach(d => d.style.display = 'none');
            const modal = document.getElementById('balanceModal');
            const form = document.getElementById('balanceForm');
            const display = document.getElementById('currentBalanceDisplay');

            form.action = '/admin/users/' + userId + '/balance';
            display.textContent = '$' + parseFloat(balance).toFixed(2);
            modal.style.display = 'flex';
        }

        function closeBalanceModal() {
            document.getElementById('balanceModal').style.display = 'none';
        }

        // Close modals on backdrop click
        document.querySelectorAll('#roleModal, #balanceModal').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) {
                    this.style.display = 'none';
                }
            });
        });
    </script>
@endsection
