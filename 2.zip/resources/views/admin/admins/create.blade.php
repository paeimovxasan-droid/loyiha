@extends('admin.layouts.app')

@section('title', __('admins.add_title'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.admins.index') }}">{{ __('nav.admins') }}</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('buttons.add_new') }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.admins.index') }}" class="btn btn-outline">{{ __('buttons.cancel') }}</a>
    <button type="submit" form="adminCreateForm" class="btn btn-primary">{{ __('buttons.save') }}</button>
@endsection

@section('content')
    <form id="adminCreateForm" action="{{ route('admin.admins.store') }}" method="POST">
        @csrf

        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
            {{-- Left Column --}}
            <div style="display: flex; flex-direction: column; gap: 24px;">
                {{-- Personal Info --}}
                <div class="admin-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 20px;">{{ __('admins.personal_info') }}</h3>

                    <div class="form-group">
                        <label class="form-label">{{ __('admins.fullname') }} <span style="color: var(--danger);">*</span></label>
                        <input name="name" type="text" value="{{ old('name') }}" required class="form-control @error('name') is-invalid @enderror" placeholder="{{ __('admins.fullname_placeholder') }}">
                        @error('name') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                        <div class="form-group">
                            <label class="form-label">{{ __('admins.username') }} <span style="color: var(--danger);">*</span></label>
                            <input name="username" type="text" value="{{ old('username') }}" required class="form-control @error('username') is-invalid @enderror" placeholder="username">
                            @error('username') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group">
                            <label class="form-label">{{ __('admins.phone') }}</label>
                            <input name="phone" type="text" value="{{ old('phone') }}" class="form-control @error('phone') is-invalid @enderror" placeholder="+998901234567">
                            @error('phone') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>

                {{-- Login Info --}}
                <div class="admin-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 20px;">{{ __('admins.login_info') }}</h3>

                    <div class="form-group">
                        <label class="form-label">{{ __('admins.email') }} <span style="color: var(--danger);">*</span></label>
                        <input name="email" type="email" value="{{ old('email') }}" required class="form-control @error('email') is-invalid @enderror" placeholder="email@example.com">
                        @error('email') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                    </div>

                    <div class="form-group">
                        <label class="form-label">{{ __('admins.password') }} <span style="color: var(--danger);">*</span></label>
                        <input name="password" type="password" required class="form-control @error('password') is-invalid @enderror" placeholder="{{ __('admins.password_placeholder') }}">
                        @error('password') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>

            {{-- Right Column - Role & Status --}}
            <div>
                <div class="admin-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 20px;">{{ __('settings.title') }}</h3>

                    <div class="form-group">
                        <label class="form-label">{{ __('admins.role') }} <span style="color: var(--danger);">*</span></label>
                        <select name="role" required class="form-control @error('role') is-invalid @enderror">
                            <option value="">{{ __('admins.role_select') }}</option>
                            @foreach($roles as $role)
                                <option value="{{ $role->name }}" {{ old('role') === $role->name ? 'selected' : '' }}>{{ $role->name }}</option>
                            @endforeach
                        </select>
                        @error('role') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                    </div>

                    <div class="form-group">
                        <label class="form-label">{{ __('admins.status') }} <span style="color: var(--danger);">*</span></label>
                        <select name="status" required class="form-control @error('status') is-invalid @enderror">
                            <option value="active" {{ old('status') === 'active' ? 'selected' : '' }}>{{ __('status.active') }}</option>
                            <option value="banned" {{ old('status') === 'banned' ? 'selected' : '' }}>{{ __('status.banned') }}</option>
                        </select>
                        @error('status') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection
