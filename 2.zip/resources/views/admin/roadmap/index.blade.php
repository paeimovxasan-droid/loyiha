@extends('admin.layouts.app')
@section('title', 'Roadmap')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Roadmap</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.roadmap.create') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-plus" style="margin-right: 4px;"></i> Yangi modul
    </a>
@endsection

@section('content')

@if(session('success'))
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid rgba(var(--success-rgb), 0.3); color: var(--success);">
    <i class="fa fa-check-circle" style="margin-right: 8px;"></i> {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Modul</th>
                    <th style="text-align: center;">Holat</th>
                    <th style="text-align: center;">Ovozlar</th>
                    <th style="text-align: center;">Progress</th>
                    <th style="text-align: center;">Sana</th>
                    <th style="text-align: center;">Tartib</th>
                    <th style="text-align: center;">Amallar</th>
                </tr>
            </thead>
            <tbody>
                @forelse($modules as $module)
                <tr>
                    <td>
                        <div style="display: flex; align-items: center; gap: 12px;">
                            <div style="font-size: 24px;">{{ $module->icon }}</div>
                            <div>
                                <div style="font-weight: 500; color: var(--text-primary);">{{ $module->title }}</div>
                                <div style="font-size: 12px; color: var(--text-muted); max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ Str::limit($module->description, 60) }}</div>
                            </div>
                        </div>
                    </td>
                    <td style="text-align: center;">
                        <span class="badge" style="background-color: {{ $module->status_color }}; color: #fff;">
                            {{ $module->status_label }}
                        </span>
                    </td>
                    <td style="text-align: center; font-weight: 600;">{{ $module->votes_count }}</td>
                    <td style="text-align: center;">{{ $module->progress_percent !== null ? $module->progress_percent . '%' : '—' }}</td>
                    <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $module->estimated_date?->format('d.m.Y') ?? '—' }}</td>
                    <td style="text-align: center;">{{ $module->sort_order }}</td>
                    <td style="text-align: center;">
                        <div style="display: flex; align-items: center; justify-content: center; gap: 8px;">
                            <a href="{{ route('admin.roadmap.edit', $module) }}" class="btn btn-outline btn-sm">
                                <i class="fa fa-pen"></i>
                            </a>
                            <form method="POST" action="{{ route('admin.roadmap.destroy', $module) }}">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('O\'chirishni tasdiqlaysizmi?')">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <i class="fa fa-map" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                        Modul topilmadi
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
