@extends('admin.layouts.app')
@section('title', 'Modulni tahrirlash')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.roadmap.index') }}">Roadmap</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Tahrirlash</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.roadmap.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left" style="margin-right: 4px;"></i> Orqaga
    </a>
@endsection

@section('content')

@if($errors->any())
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid rgba(var(--danger-rgb), 0.3); color: var(--danger);">
    <i class="fa fa-exclamation-circle" style="margin-right: 8px;"></i> {{ $errors->first() }}
</div>
@endif

<form method="POST" action="{{ route('admin.roadmap.update', $module) }}">
    @csrf @method('PUT')
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        {{-- Asosiy --}}
        <div class="admin-card">
            <div class="admin-card-header">Asosiy</div>
            <div class="admin-card-body">
                <div class="form-group">
                    <label class="form-label">Nomi <span style="color: var(--danger);">*</span></label>
                    <input type="text" name="title" value="{{ old('title', $module->title) }}" required maxlength="255" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Tavsif <span style="color: var(--danger);">*</span></label>
                    <textarea name="description" rows="3" required class="form-control">{{ old('description', $module->description) }}</textarea>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div class="form-group">
                        <label class="form-label">Icon (emoji)</label>
                        <input type="text" name="icon" value="{{ old('icon', $module->icon) }}" maxlength="255" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tartib <span style="color: var(--danger);">*</span></label>
                        <input type="number" name="sort_order" value="{{ old('sort_order', $module->sort_order) }}" min="0" required class="form-control">
                    </div>
                </div>
            </div>
        </div>

        {{-- Holat va Progress --}}
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <div class="admin-card">
                <div class="admin-card-header">Holat va Progress</div>
                <div class="admin-card-body">
                    <div class="form-group">
                        <label class="form-label">Holat <span style="color: var(--danger);">*</span></label>
                        <select name="status" required class="form-control">
                            @foreach(['coming_soon'=>'Tez kunda','in_progress'=>'Ishlanmoqda','beta'=>'Beta test','released'=>'Tayyor'] as $val => $label)
                            <option value="{{ $val }}" {{ old('status', $module->status) === $val ? 'selected' : '' }}>{{ $label }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Progress (%)</label>
                        <input type="number" name="progress_percent" value="{{ old('progress_percent', $module->progress_percent) }}" min="0" max="100" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Taxminiy sana</label>
                        <input type="date" name="estimated_date" value="{{ old('estimated_date', $module->estimated_date?->format('Y-m-d')) }}" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Banner rasm (URL)</label>
                        <input type="text" name="banner_image" value="{{ old('banner_image', $module->banner_image) }}" maxlength="255" class="form-control">
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-sm" style="width: 100%; padding: 10px;">
                <i class="fa fa-save" style="margin-right: 4px;"></i> Saqlash
            </button>
        </div>
    </div>
</form>
@endsection
