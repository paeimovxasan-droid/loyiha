@extends('admin.layouts.app')
@section('title', 'Xarajatlar — ' . $project->title)

@section('breadcrumb')
    <a href="{{ route('admin.crowdfunding.index') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Xarajatlar</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.crowdfunding.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> Orqaga
    </a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 16px;">
    {{ session('success') }}
</div>
@endif

<div style="margin-bottom: 16px;">
    <h2 style="font-size: 18px; font-weight: 600; color: var(--text-primary);">📋 {{ $project->title }} — Xarajatlar</h2>
    <p style="font-size: 13px; color: var(--text-muted); margin-top: 4px;">Yig'ilgan: {{ number_format($project->raised_amount, 2) }} / {{ number_format($project->goal_amount, 2) }} AIS</p>
</div>

<div style="display: grid; grid-template-columns: 1fr; gap: 20px;">
    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
        {{-- Xarajatlar jadvali --}}
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">Xarajatlar ro'yxati</h3>
            </div>
            <div class="admin-card-body" style="padding: 0;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Tavsif</th>
                            <th style="text-align: center;">Summa</th>
                            <th style="text-align: center;">Sana</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($expenses as $expense)
                        <tr>
                            <td style="color: var(--text-primary);">{{ $expense->description }}</td>
                            <td style="text-align: center; font-weight: 600; color: var(--danger);">-{{ number_format($expense->amount, 2) }} AIS</td>
                            <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $expense->spent_at->format('d.m.Y') }}</td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="3" style="text-align: center; padding: 32px; color: var(--text-muted);">Xarajat topilmadi</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
                <div style="padding: 12px 16px;">{{ $expenses->links() }}</div>
            </div>
        </div>

        {{-- Xarajat qo'shish formasi --}}
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">Xarajat qo'shish</h3>
            </div>
            <div class="admin-card-body">
                <form method="POST" action="{{ route('admin.crowdfunding.expenses.store', $project) }}">
                    @csrf
                    <div class="form-group">
                        <label class="form-label">Summa (AIS)</label>
                        <input type="number" step="0.01" name="amount" required class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tavsif</label>
                        <input type="text" name="description" required class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Sana</label>
                        <input type="date" name="spent_at" value="{{ date('Y-m-d') }}" required class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary" style="width: 100%;">Qo'shish</button>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection
