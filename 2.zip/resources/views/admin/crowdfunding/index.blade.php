@extends('admin.layouts.app')
@section('title', 'Crowdfunding')

@section('breadcrumb')
<span>Boshqaruv</span>
<i class="fa fa-chevron-right" style="font-size: 10px; color: var(--text-muted);"></i>
<span style="color: var(--text-primary);">Crowdfunding</span>
@endsection

@section('content')
<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem;">
    <h2 style="font-size: 1.25rem; font-weight: 600; color: var(--text-primary);">🤝 Crowdfunding Loyihalar</h2>
</div>

@if(session('success'))
<div style="margin-bottom: 1rem; padding: 0.75rem 1rem; border-radius: 8px; border: 1px solid var(--success); background: color-mix(in srgb, var(--success) 10%, transparent); color: var(--success);">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif
@if(session('error'))
<div style="margin-bottom: 1rem; padding: 0.75rem 1rem; border-radius: 8px; border: 1px solid var(--danger); background: color-mix(in srgb, var(--danger) 10%, transparent); color: var(--danger);">
    <i class="fa fa-times-circle"></i> {{ session('error') }}
</div>
@endif

<div style="display: flex; gap: 0.5rem; margin-bottom: 1rem; flex-wrap: wrap;">
    <a href="{{ route('admin.crowdfunding.index') }}" class="btn btn-sm {{ !request('status') ? 'btn-primary' : 'btn-outline' }}">Hammasi</a>
    <a href="{{ route('admin.crowdfunding.index', ['status'=>'pending']) }}" class="btn btn-sm {{ request('status')=='pending' ? 'btn-primary' : 'btn-outline' }}">Kutilmoqda</a>
    <a href="{{ route('admin.crowdfunding.index', ['status'=>'active']) }}" class="btn btn-sm {{ request('status')=='active' ? 'btn-primary' : 'btn-outline' }}">Faol</a>
    <a href="{{ route('admin.crowdfunding.index', ['status'=>'funded']) }}" class="btn btn-sm {{ request('status')=='funded' ? 'btn-primary' : 'btn-outline' }}">Moliyalashtirilgan</a>
</div>

<div class="admin-card" style="overflow: hidden;">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th style="text-align: left;">Loyiha</th>
                    <th style="text-align: left;">Muallif</th>
                    <th style="text-align: center;">Maqsad</th>
                    <th style="text-align: center;">Yig'ilgan</th>
                    <th style="text-align: center;">Holat</th>
                    <th style="text-align: center;">Sana</th>
                    <th style="text-align: center;">Amallar</th>
                </tr>
            </thead>
            <tbody>
                @forelse($projects as $project)
                <tr>
                    <td style="font-weight: 500; color: var(--text-primary);">{{ $project->title }}</td>
                    <td style="color: var(--text-muted);">{{ $project->user->name ?? '—' }}</td>
                    <td style="text-align: center; font-weight: 600;">{{ number_format($project->goal_amount, 2) }} AIS</td>
                    <td style="text-align: center;">{{ number_format($project->raised_amount, 2) }} AIS</td>
                    <td style="text-align: center;">
                        @if($project->status == 'pending')
                            <span class="badge badge-warning">Pending</span>
                        @elseif($project->status == 'active')
                            <span class="badge badge-success">Active</span>
                        @elseif($project->status == 'funded')
                            <span class="badge badge-info">Funded</span>
                        @elseif($project->status == 'rejected')
                            <span class="badge badge-danger">Rejected</span>
                        @else
                            <span class="badge badge-secondary">{{ ucfirst($project->status) }}</span>
                        @endif
                    </td>
                    <td style="text-align: center; font-size: 0.75rem; color: var(--text-muted);">{{ $project->created_at->format('d.m.Y') }}</td>
                    <td style="text-align: center;">
                        <div style="display: flex; align-items: center; justify-content: center; gap: 0.25rem;">
                            @if($project->status == 'pending')
                            <form method="POST" action="{{ route('admin.crowdfunding.approve', $project) }}" style="display: inline;">
                                @csrf
                                <button type="submit" class="btn btn-primary btn-sm" title="Tasdiqlash">
                                    <i class="fa fa-check"></i>
                                </button>
                            </form>
                            <form method="POST" action="{{ route('admin.crowdfunding.reject', $project) }}" style="display: inline;" id="reject-form-{{ $project->id }}">
                                @csrf
                                <input type="hidden" name="reason" value="Admin tomonidan rad etildi">
                                <button type="button" class="btn btn-danger btn-sm" title="Rad etish" onclick="confirmReject({{ $project->id }})">
                                    <i class="fa fa-times"></i>
                                </button>
                            </form>
                            @endif
                            <a href="{{ route('admin.crowdfunding.expenses.index', $project) }}" class="btn btn-outline btn-sm" title="Xarajatlar">
                                <i class="fa fa-receipt"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align: center; padding: 2.5rem 1rem; color: var(--text-muted);">
                        <i class="fa fa-hand-holding-heart" style="font-size: 1.5rem; opacity: 0.3; display: block; margin-bottom: 0.5rem;"></i>
                        Loyiha topilmadi
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div style="padding: 0.75rem 1rem; border-top: 1px solid var(--border);">
        {{ $projects->withQueryString()->links() }}
    </div>
</div>
@endsection

@push('scripts')
<script>
function confirmReject(projectId) {
    if (confirm('Rad etish sababini kiriting')) {
        var form = document.getElementById('reject-form-' + projectId);
        var reason = form.querySelector('input[name="reason"]');
        if (reason.value.length > 0) {
            form.submit();
        }
    }
}
</script>
@endpush
