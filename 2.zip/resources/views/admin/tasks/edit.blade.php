@extends('admin.layouts.app')

@section('title', 'Topshiriqni tahrirlash')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.tasks.index') }}">Topshiriqlar</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Tahrirlash</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.tasks.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> Orqaga
    </a>
@endsection

@section('content')

@if($errors->any())
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(239,68,68,.1); border: 1px solid rgba(239,68,68,.3); color: var(--danger); font-size: 13px; margin-bottom: 16px;">
    <i class="fa fa-exclamation-circle" style="margin-right: 6px;"></i> {{ $errors->first() }}
</div>
@endif

<form method="POST" action="{{ route('admin.tasks.update', $task) }}">
    @csrf @method('PUT')
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        {{-- Title & Description --}}
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary);">Sarlavha va tavsif</h3>
            </div>
            <div class="admin-card-body">
                <div class="form-group">
                    <label class="form-label">Nomi (UZ) *</label>
                    <input type="text" name="title[uz]" value="{{ old('title.uz', $task->getTranslation('title', 'uz')) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Nomi (RU)</label>
                    <input type="text" name="title[ru]" value="{{ old('title.ru', $task->getTranslation('title', 'ru')) }}" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Nomi (EN)</label>
                    <input type="text" name="title[en]" value="{{ old('title.en', $task->getTranslation('title', 'en')) }}" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Tavsif (UZ)</label>
                    <textarea name="description[uz]" rows="2" class="form-control" style="resize: vertical;">{{ old('description.uz', $task->getTranslation('description', 'uz')) }}</textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Tavsif (RU)</label>
                    <textarea name="description[ru]" rows="2" class="form-control" style="resize: vertical;">{{ old('description.ru', $task->getTranslation('description', 'ru')) }}</textarea>
                </div>
            </div>
        </div>

        {{-- Settings --}}
        <div style="display: flex; flex-direction: column; gap: 20px;">
            <div class="admin-card">
                <div class="admin-card-header">
                    <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary);">Sozlamalar</h3>
                </div>
                <div class="admin-card-body">
                    <div class="form-group">
                        <label class="form-label">Havola (URL)</label>
                        <input type="url" name="link" value="{{ old('link', $task->link) }}" class="form-control">
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                        <div class="form-group">
                            <label class="form-label">Platforma</label>
                            <select name="platform" class="form-control">
                                <option value="">Tanlang</option>
                                @foreach(['telegram','instagram','youtube','facebook','other'] as $p)
                                <option value="{{ $p }}" {{ old('platform', $task->platform) === $p ? 'selected' : '' }}>{{ ucfirst($p) }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Mukofot (UZS) *</label>
                            <input type="number" name="reward" value="{{ old('reward', $task->reward) }}" min="0" step="0.01" required class="form-control">
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                        <div class="form-group">
                            <label class="form-label">Paket darajasi *</label>
                            <input type="number" name="required_package_level" value="{{ old('required_package_level', $task->required_package_level) }}" min="0" required class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Tartib *</label>
                            <input type="number" name="sort_order" value="{{ old('sort_order', $task->sort_order) }}" min="0" required class="form-control">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Holat *</label>
                        <select name="status" required class="form-control">
                            <option value="active" {{ old('status', $task->status) === 'active' ? 'selected' : '' }}>Faol</option>
                            <option value="inactive" {{ old('status', $task->status) === 'inactive' ? 'selected' : '' }}>Nofaol</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%; padding: 10px;">
                <i class="fa fa-save" style="margin-right: 4px;"></i> Saqlash
            </button>
        </div>
    </div>
</form>

@endsection
