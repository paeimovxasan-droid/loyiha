@extends('admin.layouts.app')

@section('title', 'Topshiriqlar Boshqaruvi')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Topshiriqlar</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.tasks.create') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-plus"></i> Yangi topshiriq
    </a>
@endsection

@section('content')

@if(session('success'))
<div style="display: flex; align-items: center; gap: 8px; padding: 12px 16px; border-radius: 10px; margin-bottom: 16px; background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.2); color: var(--success); font-size: 13px;">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif

{{-- Statistics --}}
<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px;">
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--primary-light);">{{ $stats['total_tasks'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Jami topshiriqlar</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--warning);">{{ $stats['pending'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Kutilmoqda</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--success);">{{ $stats['approved'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Tasdiqlangan</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--danger);">{{ $stats['rejected'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Rad etilgan</div>
    </div>
</div>

{{-- Tasks List --}}
<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
    <h2 style="font-size: 18px; font-weight: 700; color: var(--text-primary);">📦 Topshiriqlar</h2>
</div>

<div class="admin-card" style="margin-bottom: 24px;">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Nomi</th>
                    <th style="text-align: center;">Platforma</th>
                    <th style="text-align: center;">Mukofot</th>
                    <th style="text-align: center;">Daraja</th>
                    <th style="text-align: center;">Holat</th>
                    <th style="text-align: center;">Amallar</th>
                </tr>
            </thead>
            <tbody>
                @forelse($tasks as $task)
                <tr>
                    <td>
                        <div style="font-size: 13px; font-weight: 600; color: var(--text-primary);">{{ $task->getTranslation('title', 'uz') }}</div>
                        @if($task->link)
                        <a href="{{ $task->link }}" target="_blank" style="font-size: 11px; color: var(--primary-light); text-decoration: none;">{{ Str::limit($task->link, 30) }}</a>
                        @endif
                    </td>
                    <td style="text-align: center; font-size: 12px; color: var(--text-secondary);">{{ $task->platform ?? '—' }}</td>
                    <td style="text-align: center;">
                        <span style="font-size: 13px; font-weight: 700; color: var(--success);">{{ number_format($task->reward) }} UZS</span>
                    </td>
                    <td style="text-align: center; font-size: 12px; color: var(--text-secondary);">{{ $task->required_package_level }}</td>
                    <td style="text-align: center;">
                        @if($task->status === 'active')
                        <span class="badge badge-success">Faol</span>
                        @else
                        <span class="badge badge-warning">Nofaol</span>
                        @endif
                    </td>
                    <td style="text-align: center;">
                        <div style="display: flex; align-items: center; justify-content: center; gap: 4px;">
                            <a href="{{ route('admin.tasks.edit', $task) }}" class="btn btn-outline btn-sm" title="Tahrirlash">
                                <i class="fa fa-pen"></i>
                            </a>
                            <form method="POST" action="{{ route('admin.tasks.destroy', $task) }}" style="margin: 0;"
                                  onsubmit="return confirm('O\'chirishni tasdiqlaysizmi?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                        <i class="fa fa-list-check" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                        Topshiriq yo'q
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

{{-- Submissions Section --}}
<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; flex-wrap: wrap; gap: 10px;">
    <h2 style="font-size: 18px; font-weight: 700; color: var(--text-primary);">📨 Foydalanuvchi yuborishlari</h2>
    <form method="GET" style="display: flex; gap: 8px; align-items: center;">
        <select name="status" onchange="this.form.submit()" class="form-control" style="width: 140px; padding: 7px 12px; font-size: 12px;">
            <option value="">Barchasi</option>
            <option value="pending"  {{ request('status') === 'pending'  ? 'selected' : '' }}>Kutilmoqda</option>
            <option value="approved" {{ request('status') === 'approved' ? 'selected' : '' }}>Tasdiqlangan</option>
            <option value="rejected" {{ request('status') === 'rejected' ? 'selected' : '' }}>Rad etilgan</option>
        </select>
        @if(request('status'))
        <a href="{{ route('admin.tasks.index') }}" class="btn btn-outline btn-sm"><i class="fa fa-times"></i></a>
        @endif
    </form>
</div>

<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Foydalanuvchi</th>
                    <th>Topshiriq</th>
                    <th>Isbot</th>
                    <th style="text-align: center;">Holat</th>
                    <th style="text-align: center;">Sana</th>
                    <th style="text-align: center;">Amallar</th>
                </tr>
            </thead>
            <tbody>
                @forelse($submissions as $ut)
                <tr>
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <img src="{{ $ut->user?->avatar_url }}" alt=""
                                 style="width: 32px; height: 32px; border-radius: 8px; object-fit: cover; border: 1px solid var(--border);">
                            <div>
                                <div style="font-size: 13px; font-weight: 600; color: var(--text-primary);">{{ $ut->user?->name }}</div>
                                <div style="font-size: 11px; color: var(--text-muted);">{{ $ut->user?->username ?? '—' }}</div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div style="font-size: 13px; font-weight: 500; color: var(--text-primary);">
                            {{ $ut->task?->getTranslation('title', app()->getLocale()) }}
                        </div>
                        <div style="font-size: 11px; color: var(--success);">+{{ $ut->task?->reward }} UZS</div>
                    </td>
                    <td>
                        @if($ut->proof)
                            @if(filter_var($ut->proof, FILTER_VALIDATE_URL))
                            <a href="{{ $ut->proof }}" target="_blank" style="font-size: 12px; color: var(--primary-light); text-decoration: none; display: block; max-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                <i class="fa fa-link"></i> {{ $ut->proof }}
                            </a>
                            @else
                            <span style="font-size: 12px; color: var(--text-secondary);">{{ Str::limit($ut->proof, 40) }}</span>
                            @endif
                        @else
                        <span style="font-size: 12px; color: var(--text-muted);">—</span>
                        @endif
                    </td>
                    <td style="text-align: center;">
                        @if($ut->status === 'pending')
                        <span class="badge badge-warning">Kutilmoqda</span>
                        @elseif($ut->status === 'approved')
                        <span class="badge badge-success">Tasdiqlandi</span>
                        @else
                        <span class="badge badge-danger">Rad etildi</span>
                        @endif
                    </td>
                    <td style="text-align: center;">
                        <span style="font-size: 12px; color: var(--text-muted);">{{ $ut->created_at->format('d.m.Y H:i') }}</span>
                    </td>
                    <td style="text-align: center;">
                        @if($ut->status === 'pending')
                        <div style="display: flex; align-items: center; justify-content: center; gap: 4px;">
                            <form method="POST" action="{{ route('admin.tasks.approve', $ut) }}" style="margin: 0;">
                                @csrf
                                <button type="submit" class="btn btn-sm btn-success" title="Tasdiqlash">
                                    <i class="fa fa-check"></i>
                                </button>
                            </form>
                            <form method="POST" action="{{ route('admin.tasks.reject', $ut) }}" style="margin: 0;">
                                @csrf
                                <button type="submit" class="btn btn-danger btn-sm" title="Rad etish">
                                    <i class="fa fa-times"></i>
                                </button>
                            </form>
                        </div>
                        @else
                        <span style="font-size: 12px; color: var(--text-muted);">—</span>
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                        <i class="fa fa-list-check" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                        Topshiriq topilmadi
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($submissions->hasPages())
    <div style="padding: 14px 20px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: center;">
        <div class="pagination">
            @if(!$submissions->onFirstPage())
            <a href="{{ $submissions->previousPageUrl() }}"><i class="fa fa-chevron-left" style="font-size: 10px;"></i></a>
            @endif
            @foreach($submissions->getUrlRange(max(1, $submissions->currentPage()-2), min($submissions->lastPage(), $submissions->currentPage()+2)) as $page => $url)
                @if($page == $submissions->currentPage())
                <span class="active"><span>{{ $page }}</span></span>
                @else
                <a href="{{ $url }}">{{ $page }}</a>
                @endif
            @endforeach
            @if($submissions->hasMorePages())
            <a href="{{ $submissions->nextPageUrl() }}"><i class="fa fa-chevron-right" style="font-size: 10px;"></i></a>
            @endif
        </div>
    </div>
    @endif
</div>

@endsection
