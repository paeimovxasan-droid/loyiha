@extends('admin.layouts.app')
@section('title', 'Katalog — Do\'konlar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Do'konlar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.catalog.products') }}" class="btn btn-primary btn-sm">
    <i class="fa fa-box"></i> Mahsulotlar
</a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: color-mix(in srgb, var(--success) 10%, transparent); border: 1px solid color-mix(in srgb, var(--success) 30%, transparent); color: var(--success);">
    {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">Do'konlar ro'yxati</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Egasi</th>
                        <th>Do'kon nomi</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($shops as $shop)
                    <tr>
                        <td style="color: var(--text-muted);">#{{ $shop->id }}</td>
                        <td style="color: var(--text-primary);">{{ $shop->user->name ?? '—' }}</td>
                        <td style="color: var(--text-primary); font-weight: 500;">{{ $shop->name ?? '—' }}</td>
                        <td style="text-align: center;">
                            @php
                                $statusClass = match($shop->status ?? 'pending') {
                                    'active' => 'badge-success',
                                    'pending' => 'badge-warning',
                                    'suspended' => 'badge-danger',
                                    default => 'badge-info'
                                };
                            @endphp
                            <span class="badge {{ $statusClass }}">{{ ucfirst($shop->status ?? 'pending') }}</span>
                        </td>
                        <td style="text-align: center; color: var(--text-muted); font-size: 13px;">{{ $shop->created_at->format('d.m.Y') }}</td>
                        <td style="text-align: center;">
                            <a href="{{ route('admin.catalog.shops.edit', $shop) }}" class="btn btn-primary btn-sm">
                                <i class="fa fa-pen"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            <i class="fa fa-shopping-bag" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Do'kon topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($shops->hasPages())
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $shops->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
