@extends('admin.layouts.app')
@section('title', 'Katalog — Mahsulotlar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Mahsulotlar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.catalog.shops') }}" class="btn btn-outline btn-sm">
    <i class="fa fa-store"></i> Do'konlar
</a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: color-mix(in srgb, var(--success) 10%, transparent); border: 1px solid color-mix(in srgb, var(--success) 30%, transparent); color: var(--success);">
    {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">Mahsulotlar ro'yxati</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Do'kon</th>
                        <th>Nomi</th>
                        <th style="text-align: center;">Narx</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($products as $product)
                    <tr>
                        <td style="color: var(--text-muted);">#{{ $product->id }}</td>
                        <td style="color: var(--text-secondary);">{{ $product->shop->name ?? '—' }}</td>
                        <td style="color: var(--text-primary); font-weight: 500;">{{ $product->name ?? '—' }}</td>
                        <td style="text-align: center; font-weight: 600; color: var(--text-primary);">{{ number_format($product->price ?? 0, 2) }} AIS</td>
                        <td style="text-align: center;">
                            @php
                                $statusClass = match($product->status ?? 'active') {
                                    'active' => 'badge-success',
                                    'pending' => 'badge-warning',
                                    'out_of_stock' => 'badge-danger',
                                    default => 'badge-info'
                                };
                            @endphp
                            <span class="badge {{ $statusClass }}">{{ ucfirst($product->status ?? 'active') }}</span>
                        </td>
                        <td style="text-align: center; color: var(--text-muted); font-size: 13px;">{{ $product->created_at->format('d.m.Y') }}</td>
                        <td style="text-align: center;">
                            <div style="display: flex; align-items: center; justify-content: center; gap: 4px;">
                                <a href="{{ route('admin.catalog.products.edit', $product) }}" class="btn btn-primary btn-sm">
                                    <i class="fa fa-pen"></i>
                                </a>
                                <form method="POST" action="{{ route('admin.catalog.products.destroy', $product) }}" style="display: inline;">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('O\'chirishni tasdiqlaysizmi?')">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            <i class="fa fa-box" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Mahsulot topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($products->hasPages())
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $products->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
