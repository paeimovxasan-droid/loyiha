@extends('admin.layouts.app')
@section('title', 'Fondlar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Fondlar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.funds.create') }}" class="btn btn-primary btn-sm">
    <i class="fa fa-plus"></i> Yangi fond
</a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="text-align: left;">Nomi</th>
                        <th style="text-align: center;">Foyda %</th>
                        <th style="text-align: center;">Muddat</th>
                        <th style="text-align: center;">Min invest</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($funds as $fund)
                    <tr>
                        <td style="font-weight: 500; color: var(--text-primary);">{{ $fund->getTranslation('name', 'uz') }}</td>
                        <td style="text-align: center; color: var(--success); font-weight: 600;">{{ $fund->commission_percent }}%</td>
                        <td style="text-align: center;">{{ $fund->validity_days }} kun</td>
                        <td style="text-align: center;">{{ number_format($fund->min_invest) }} UZS</td>
                        <td style="text-align: center;">
                            @if($fund->status === 'active')
                            <span class="badge badge-success">Faol</span>
                            @else
                            <span class="badge badge-warning">Nofaol</span>
                            @endif
                        </td>
                        <td style="text-align: center;">
                            <div style="display: flex; align-items: center; justify-content: center; gap: 8px;">
                                <a href="{{ route('admin.funds.edit', $fund) }}" class="btn btn-outline btn-sm">
                                    <i class="fa fa-pen"></i>
                                </a>
                                <form method="POST" action="{{ route('admin.funds.destroy', $fund) }}">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('O\'chirishni tasdiqlaysizmi?')">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">Fond topilmadi</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    @if($funds->hasPages())
    <div class="pagination" style="padding: 12px 16px; border-top: 1px solid var(--border);">{{ $funds->links() }}</div>
    @endif
</div>
@endsection
