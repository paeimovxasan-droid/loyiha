@extends('admin.layouts.app')
@section('title', 'Fond tahrirlash')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.funds.index') }}">Fondlar</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Tahrirlash</span>
@endsection

@section('content')
@if($errors->any())
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid var(--danger); color: var(--danger); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <i class="fa fa-exclamation-circle"></i> {{ $errors->first() }}
</div>
@endif

<form method="POST" action="{{ route('admin.funds.update', $fund) }}">
    @csrf @method('PUT')
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
        <div class="admin-card">
            <div class="admin-card-header">Ma'lumotlar</div>
            <div class="admin-card-body">
                <div class="form-group">
                    <label class="form-label">Nomi (UZ) *</label>
                    <input type="text" name="name[uz]" value="{{ old('name.uz', $fund->getTranslation('name', 'uz')) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Nomi (RU)</label>
                    <input type="text" name="name[ru]" value="{{ old('name.ru', $fund->getTranslation('name', 'ru')) }}" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Tavsif (UZ)</label>
                    <textarea name="description[uz]" rows="3" class="form-control">{{ old('description.uz', $fund->getTranslation('description', 'uz')) }}</textarea>
                </div>
            </div>
        </div>

        <div>
            <div class="admin-card" style="margin-bottom: 16px;">
                <div class="admin-card-header">Sozlamalar</div>
                <div class="admin-card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                        <div class="form-group">
                            <label class="form-label">Foyda % *</label>
                            <input type="number" name="commission_percent" value="{{ old('commission_percent', $fund->commission_percent) }}" min="0" max="100" step="0.01" required class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Muddat (kun) *</label>
                            <input type="number" name="validity_days" value="{{ old('validity_days', $fund->validity_days) }}" min="1" required class="form-control">
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                        <div class="form-group">
                            <label class="form-label">Min invest *</label>
                            <input type="number" name="min_invest" value="{{ old('min_invest', $fund->min_invest) }}" min="0" step="0.01" required class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Tartib *</label>
                            <input type="number" name="sort_order" value="{{ old('sort_order', $fund->sort_order) }}" min="0" required class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Holat *</label>
                        <select name="status" required class="form-control">
                            <option value="active" {{ old('status', $fund->status) === 'active' ? 'selected' : '' }}>Faol</option>
                            <option value="inactive" {{ old('status', $fund->status) === 'inactive' ? 'selected' : '' }}>Nofaol</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%;">
                <i class="fa fa-save"></i> Saqlash
            </button>
        </div>
    </div>
</form>
@endsection
