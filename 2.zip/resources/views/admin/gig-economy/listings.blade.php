@extends('admin.layouts.app')
@section('title', 'Gig Economy E\'lonlar')

@section('breadcrumb')
    <a href="{{ route('admin.gig-economy.listings') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Gig E'lonlar</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.gig-economy.applications') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-file-alt"></i> Arizalar
    </a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 16px;">
    {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">💼 Gig Economy E'lonlar</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Sarlavha</th>
                        <th>Muallif</th>
                        <th style="text-align: center;">Byudjet</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($listings as $listing)
                    <tr>
                        <td style="font-weight: 500; color: var(--text-primary);">{{ $listing->title ?? '#'.$listing->id }}</td>
                        <td style="color: var(--text-secondary);">{{ $listing->user->name ?? '—' }}</td>
                        <td style="text-align: center; font-weight: 600;">{{ number_format($listing->budget ?? 0, 2) }} AIS</td>
                        <td style="text-align: center;">
                            @if(($listing->status ?? 'open') == 'open')
                                <span class="badge badge-success">Open</span>
                            @else
                                <span class="badge badge-info">{{ ucfirst($listing->status ?? 'open') }}</span>
                            @endif
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $listing->created_at->format('d.m.Y') }}</td>
                        <td style="text-align: center;">
                            <div style="display: flex; align-items: center; justify-content: center; gap: 6px;">
                                <a href="{{ route('admin.gig-economy.listings.edit', $listing) }}" class="btn btn-primary btn-sm">
                                    <i class="fa fa-pen"></i>
                                </a>
                                <form method="POST" action="{{ route('admin.gig-economy.listings.destroy', $listing) }}" style="display: inline;">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-danger btn-sm" onclick="return confirm('O\'chirishni tasdiqlaysizmi?')">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="fa fa-briefcase" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            E'lon topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 12px 16px;">{{ $listings->withQueryString()->links() }}</div>
    </div>
</div>
@endsection
