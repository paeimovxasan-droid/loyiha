@extends('admin.layouts.app')
@section('title', 'Gig Economy e\'lon tahrirlash')

@section('breadcrumb')
    <a href="{{ route('admin.gig-economy.listings') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">E'lon tahrirlash</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.gig-economy.listings') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> Orqaga
    </a>
@endsection

@section('content')
@if($errors->any())
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid var(--danger); color: var(--danger); margin-bottom: 16px;">
    <ul style="list-style: disc; padding-left: 20px;">
        @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
    </ul>
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">💼 E'lon tahrirlash #{{ $listing->id }}</h3>
    </div>
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.gig-economy.listings.update', $listing) }}">
            @csrf
            @method('PUT')
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label">Muallif</label>
                    <input type="text" value="{{ $listing->user->name ?? '—' }}" disabled class="form-control" style="background: var(--primary-light);">
                </div>
                <div class="form-group">
                    <label class="form-label">Sarlavha</label>
                    <input type="text" name="title" value="{{ old('title', $listing->title) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Byudjet (AIS)</label>
                    <input type="number" step="0.01" name="budget" value="{{ old('budget', $listing->budget) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Holat</label>
                    <select name="status" class="form-control">
                        @foreach(['open','in_progress','completed','cancelled'] as $s)
                        <option value="{{ $s }}" {{ old('status', $listing->status) == $s ? 'selected' : '' }}>{{ ucfirst(str_replace('_', ' ', $s)) }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group" style="grid-column: span 2;">
                    <label class="form-label">Tavsif</label>
                    <textarea name="description" rows="4" class="form-control">{{ old('description', $listing->description) }}</textarea>
                </div>
            </div>
            <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
                <button type="submit" class="btn btn-primary">Yangilash</button>
            </div>
        </form>
    </div>
</div>
@endsection
