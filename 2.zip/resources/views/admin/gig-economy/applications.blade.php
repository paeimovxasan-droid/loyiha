@extends('admin.layouts.app')
@section('title', 'Gig Arizalar')

@section('breadcrumb')
    <a href="{{ route('admin.gig-economy.listings') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Gig Arizalar</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.gig-economy.listings') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> E'lonlar
    </a>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">📋 Gig Arizalar</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>E'lon</th>
                        <th>Ariza beruvchi</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($applications as $app)
                    <tr>
                        <td style="color: var(--text-primary);">{{ $app->gig->title ?? '#'.$app->gig_listing_id }}</td>
                        <td style="color: var(--text-secondary);">{{ $app->user->name ?? '—' }}</td>
                        <td style="text-align: center;">
                            @if($app->status == 'pending')
                                <span class="badge badge-warning">Pending</span>
                            @elseif($app->status == 'accepted')
                                <span class="badge badge-success">Accepted</span>
                            @elseif($app->status == 'rejected')
                                <span class="badge badge-danger">Rejected</span>
                            @else
                                <span class="badge badge-info">{{ ucfirst($app->status) }}</span>
                            @endif
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $app->created_at->format('d.m.Y') }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" style="text-align: center; padding: 40px; color: var(--text-muted);">Ariza topilmadi</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 12px 16px;">{{ $applications->withQueryString()->links() }}</div>
    </div>
</div>
@endsection
