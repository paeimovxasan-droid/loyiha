@extends('admin.layouts.app')
@section('title', 'Kurs tahrirlash')

@section('breadcrumb')
<span>Boshqaruv</span>
<i class="fa fa-chevron-right" style="font-size: 10px; color: var(--text-muted);"></i>
<a href="{{ route('admin.education.index') }}" style="color: var(--text-muted); text-decoration: none;">Ta'lim kurslari</a>
<i class="fa fa-chevron-right" style="font-size: 10px; color: var(--text-muted);"></i>
<span style="color: var(--text-primary);">Tahrirlash #{{ $course->id }}</span>
@endsection

@section('content')
<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem;">
    <h2 style="font-size: 1.25rem; font-weight: 600; color: var(--text-primary);">🎓 Kurs tahrirlash #{{ $course->id }}</h2>
    <a href="{{ route('admin.education.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> Orqaga
    </a>
</div>

@if($errors->any())
<div style="margin-bottom: 1rem; padding: 0.75rem 1rem; border-radius: 8px; border: 1px solid var(--danger); background: color-mix(in srgb, var(--danger) 10%, transparent); color: var(--danger);">
    <ul style="list-style: disc; padding-left: 1.25rem; margin: 0;">
        @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
    </ul>
</div>
@endif

<div class="admin-card" style="padding: 1.5rem;">
    <form method="POST" action="{{ route('admin.education.update', $course) }}">
        @csrf
        @method('PUT')

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
            <div class="form-group">
                <label class="form-label">Muallif</label>
                <input type="text" value="{{ $course->user->name ?? '—' }}" disabled class="form-control" style="opacity: 0.7;">
            </div>
            <div class="form-group">
                <label class="form-label">Sarlavha</label>
                <input type="text" name="title" value="{{ old('title', $course->title) }}" required class="form-control">
            </div>
            <div class="form-group">
                <label class="form-label">Narx (AIS)</label>
                <input type="number" step="0.01" name="price" value="{{ old('price', $course->price) }}" required class="form-control">
            </div>
            <div class="form-group">
                <label class="form-label">Holat</label>
                <select name="status" class="form-control">
                    @foreach(['draft','published','archived'] as $s)
                    <option value="{{ $s }}" {{ old('status', $course->status) == $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group" style="grid-column: span 2;">
                <label class="form-label">Tavsif</label>
                <textarea name="description" rows="4" class="form-control">{{ old('description', $course->description) }}</textarea>
            </div>
        </div>

        <div style="margin-top: 1.5rem; display: flex; justify-content: flex-end;">
            <button type="submit" class="btn btn-primary">Yangilash</button>
        </div>
    </form>
</div>
@endsection
