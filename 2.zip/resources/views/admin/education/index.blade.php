@extends('admin.layouts.app')
@section('title', 'Ta\'lim kurslari')

@section('breadcrumb')
<span>Boshqaruv</span>
<i class="fa fa-chevron-right" style="font-size: 10px; color: var(--text-muted);"></i>
<span style="color: var(--text-primary);">Ta'lim kurslari</span>
@endsection

@section('content')
<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 1.5rem;">
    <h2 style="font-size: 1.25rem; font-weight: 600; color: var(--text-primary);">🎓 Ta'lim kurslari</h2>
</div>

@if(session('success'))
<div style="margin-bottom: 1rem; padding: 0.75rem 1rem; border-radius: 8px; border: 1px solid var(--success); background: color-mix(in srgb, var(--success) 10%, transparent); color: var(--success);">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif

<div class="admin-card" style="overflow: hidden;">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th style="text-align: left;">ID</th>
                    <th style="text-align: left;">Muallif</th>
                    <th style="text-align: left;">Sarlavha</th>
                    <th style="text-align: center;">Narx</th>
                    <th style="text-align: center;">Darslar</th>
                    <th style="text-align: center;">Holat</th>
                    <th style="text-align: center;">Sana</th>
                    <th style="text-align: center;">Amallar</th>
                </tr>
            </thead>
            <tbody>
                @forelse($courses as $course)
                <tr>
                    <td style="color: var(--text-muted);">#{{ $course->id }}</td>
                    <td style="color: var(--text-primary);">{{ $course->user->name ?? '—' }}</td>
                    <td style="color: var(--text-primary);">{{ $course->title ?? '—' }}</td>
                    <td style="text-align: center; font-weight: 600;">{{ number_format($course->price ?? 0, 2) }} AIS</td>
                    <td style="text-align: center;">{{ $course->lessons_count ?? $course->lessons()->count() }}</td>
                    <td style="text-align: center;">
                        @if(($course->status ?? '') == 'active' || ($course->status ?? '') == 'published')
                            <span class="badge badge-success">{{ ucfirst($course->status) }}</span>
                        @elseif(($course->status ?? '') == 'pending')
                            <span class="badge badge-warning">Pending</span>
                        @elseif(($course->status ?? '') == 'draft')
                            <span class="badge badge-info">Draft</span>
                        @elseif(($course->status ?? '') == 'rejected')
                            <span class="badge badge-danger">Rejected</span>
                        @else
                            <span class="badge badge-secondary">{{ ucfirst($course->status ?? 'draft') }}</span>
                        @endif
                    </td>
                    <td style="text-align: center; font-size: 0.75rem; color: var(--text-muted);">{{ $course->created_at->format('d.m.Y') }}</td>
                    <td style="text-align: center;">
                        <div style="display: flex; align-items: center; justify-content: center; gap: 0.25rem;">
                            <a href="{{ route('admin.education.edit', $course) }}" class="btn btn-primary btn-sm" title="Tahrirlash">
                                <i class="fa fa-pen"></i>
                            </a>
                            <form method="POST" action="{{ route('admin.education.destroy', $course) }}" style="display: inline;" id="delete-form-{{ $course->id }}">
                                @csrf
                                @method('DELETE')
                                <button type="button" class="btn btn-danger btn-sm" title="O'chirish" onclick="confirmDelete({{ $course->id }})">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="8" style="text-align: center; padding: 2.5rem 1rem; color: var(--text-muted);">
                        <i class="fa fa-graduation-cap" style="font-size: 1.5rem; opacity: 0.3; display: block; margin-bottom: 0.5rem;"></i>
                        Kurs topilmadi
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div style="padding: 0.75rem 1rem; border-top: 1px solid var(--border);">
        {{ $courses->withQueryString()->links() }}
    </div>
</div>
@endsection

@push('scripts')
<script>
function confirmDelete(courseId) {
    if (confirm('O\'chirishni tasdiqlaysizmi?')) {
        document.getElementById('delete-form-' + courseId).submit();
    }
}
</script>
@endpush
