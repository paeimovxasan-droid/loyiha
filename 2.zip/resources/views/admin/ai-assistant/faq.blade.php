@extends('admin.layouts.app')
@section('title', 'AI Yordamchi — FAQ')
@section('content')
<div class="flex items-center justify-between py-5">
    <h2 class="text-xl font-medium text-slate-800 dark:text-navy-50">🤖 AI Yordamchi — FAQ bazasi</h2>
    <a href="{{ route('admin.ai.conversations') }}" class="btn bg-info/10 text-info hover:bg-info/20 px-4 text-sm">
        <i class="fa fa-comments mr-1"></i> Suhbatlar
    </a>
</div>

@if(session('success'))
<div class="alert mb-4 flex rounded-lg border border-success/30 bg-success/10 px-4 py-4 text-success">{{ session('success') }}</div>
@endif

{{-- Yangi FAQ qo'shish --}}
<div class="card p-5 mb-5">
    <h3 class="text-base font-semibold text-slate-700 dark:text-navy-100 mb-4">Yangi FAQ qo'shish</h3>
    <form method="POST" action="{{ route('admin.ai.faq.store') }}">
        @csrf
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <label class="block">
                <span class="text-sm text-slate-600 dark:text-navy-200">Savol *</span>
                <input type="text" name="question" required class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
            </label>
            <div class="grid grid-cols-2 gap-3">
                <label class="block">
                    <span class="text-sm text-slate-600 dark:text-navy-200">Kategoriya</span>
                    <input type="text" name="category" placeholder="umumiy" class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                </label>
                <label class="block">
                    <span class="text-sm text-slate-600 dark:text-navy-200">Kalit so'zlar</span>
                    <input type="text" name="keywords" placeholder="paket,narx,foyda" class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                </label>
            </div>
        </div>
        <label class="block mb-4">
            <span class="text-sm text-slate-600 dark:text-navy-200">Javob *</span>
            <textarea name="answer" rows="3" required class="form-textarea mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450"></textarea>
        </label>
        <button type="submit" class="btn bg-primary text-white hover:bg-primary-focus px-6">Qo'shish</button>
    </form>
</div>

{{-- FAQ ro'yxati --}}
<div class="card">
    <div class="px-4 py-3 border-b border-slate-200 dark:border-navy-500">
        <span class="font-medium text-slate-700 dark:text-navy-100">Jami: {{ $faqs->total() }} ta FAQ</span>
    </div>
    @forelse($faqs as $faq)
    <div class="px-4 py-4 border-b border-slate-100 dark:border-navy-600" x-data="{ editing: false }">
        <div x-show="!editing" class="flex items-start justify-between gap-4">
            <div class="flex-1">
                <div class="flex items-center gap-2 mb-1">
                    <span class="badge rounded-full {{ $faq->is_active ? 'bg-success/10 text-success' : 'bg-error/10 text-error' }} text-xs px-2">
                        {{ $faq->is_active ? 'Faol' : 'Nofaol' }}
                    </span>
                    @if($faq->category)
                    <span class="badge rounded-full bg-info/10 text-info text-xs px-2">{{ $faq->category }}</span>
                    @endif
                </div>
                <p class="font-medium text-slate-700 dark:text-navy-100">{{ $faq->question }}</p>
                <p class="text-sm text-slate-500 dark:text-navy-300 mt-1">{{ Str::limit($faq->answer, 200) }}</p>
                @if($faq->keywords)
                <p class="text-xs text-slate-400 mt-1">Kalit: {{ $faq->keywords }}</p>
                @endif
            </div>
            <div class="flex gap-1 flex-shrink-0">
                <button @click="editing = true" class="btn size-8 p-0 text-info hover:bg-info/10 rounded-full"><i class="fa fa-pen text-xs"></i></button>
                <form method="POST" action="{{ route('admin.ai.faq.destroy', $faq) }}">
                    @csrf @method('DELETE')
                    <button type="submit" class="btn size-8 p-0 text-error hover:bg-error/10 rounded-full" onclick="return confirm('Ochirilsinmi?')"><i class="fa fa-trash text-xs"></i></button>
                </form>
            </div>
        </div>
        {{-- Edit form --}}
        <form x-show="editing" style="display:none" method="POST" action="{{ route('admin.ai.faq.update', $faq) }}">
            @csrf @method('PUT')
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                <input type="text" name="question" value="{{ $faq->question }}" required class="form-input rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450 text-sm">
                <div class="grid grid-cols-2 gap-2">
                    <input type="text" name="category" value="{{ $faq->category }}" placeholder="Kategoriya" class="form-input rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450 text-sm">
                    <input type="text" name="keywords" value="{{ $faq->keywords }}" placeholder="Kalit sozlar" class="form-input rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450 text-sm">
                </div>
            </div>
            <textarea name="answer" rows="3" required class="form-textarea w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450 text-sm mb-3">{{ $faq->answer }}</textarea>
            <div class="flex items-center gap-3">
                <label class="inline-flex items-center gap-2">
                    <input type="hidden" name="is_active" value="0">
                    <input type="checkbox" name="is_active" value="1" {{ $faq->is_active ? 'checked' : '' }} class="form-checkbox is-basic h-4 w-4 rounded border-slate-400/70 checked:border-primary checked:bg-primary">
                    <span class="text-sm">Faol</span>
                </label>
                <button type="submit" class="btn bg-primary text-white text-sm px-4 py-1.5">Saqlash</button>
                <button type="button" @click="editing = false" class="btn border border-slate-300 text-sm px-4 py-1.5">Bekor</button>
            </div>
        </form>
    </div>
    @empty
    <div class="p-8 text-center text-slate-400">FAQ bazasi bosh. Yuqoridagi formadan qoshing.</div>
    @endforelse
    <div class="px-4 py-3">{{ $faqs->links() }}</div>
</div>
@endsection
