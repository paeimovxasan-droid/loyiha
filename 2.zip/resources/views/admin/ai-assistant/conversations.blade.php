@extends('admin.layouts.app')
@section('title', 'AI Yordamchi — Suhbatlar')
@section('content')
<div class="flex items-center justify-between py-5">
    <h2 class="text-xl font-medium text-slate-800 dark:text-navy-50">💬 Foydalanuvchi suhbatlari</h2>
    <a href="{{ route('admin.ai.faq') }}" class="btn bg-primary/10 text-primary hover:bg-primary/20 px-4 text-sm">
        <i class="fa fa-book mr-1"></i> FAQ bazasi
    </a>
</div>
<div class="card">
    <table class="is-hoverable w-full text-left">
        <thead>
            <tr class="border-b border-slate-200 dark:border-navy-500">
                <th class="px-4 py-3 text-sm font-semibold text-slate-800 dark:text-navy-100">ID</th>
                <th class="px-4 py-3 text-sm font-semibold text-slate-800 dark:text-navy-100">Foydalanuvchi</th>
                <th class="px-4 py-3 text-sm font-semibold text-slate-800 dark:text-navy-100">Xabarlar</th>
                <th class="px-4 py-3 text-sm font-semibold text-slate-800 dark:text-navy-100">Sana</th>
            </tr>
        </thead>
        <tbody>
            @forelse($conversations as $c)
            <tr class="border-b border-slate-100 dark:border-navy-600">
                <td class="px-4 py-3 text-sm">#{{ $c->id }}</td>
                <td class="px-4 py-3 text-sm font-medium text-slate-700 dark:text-navy-100">
                    {{ $c->user->name ?? '—' }}
                    <span class="text-xs text-slate-400">{{ '@' . ($c->user->username ?? '') }}</span>
                </td>
                <td class="px-4 py-3 text-sm">
                    <span class="badge rounded-full bg-info/10 text-info px-2">{{ $c->messages_count }}</span>
                </td>
                <td class="px-4 py-3 text-xs text-slate-400">{{ $c->created_at->format('d.m.Y H:i') }}</td>
            </tr>
            @empty
            <tr><td colspan="4" class="text-center py-8 text-slate-400">Suhbatlar yoq</td></tr>
            @endforelse
        </tbody>
    </table>
    <div class="px-4 py-3">{{ $conversations->links() }}</div>
</div>
@endsection
