@extends('admin.layouts.app')
@section('title', 'AIS Hamyonlar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">AIS Hamyonlar</span>
@endsection

@section('header-actions')
<span style="font-size: 13px; color: var(--text-muted);">
    Jami muomalada: <strong style="color: var(--info);">{{ number_format($totalAis, 4) }} AIS</strong>
</span>
@endsection

@section('content')
<div class="admin-card" style="margin-bottom: 16px;">
    <div class="admin-card-body" style="padding: 12px 16px;">
        <form method="GET" style="display: flex; gap: 8px;">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Hamyon raqami, ism, username..." class="form-control" style="flex: 1;">
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fa fa-search"></i>
            </button>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">Hamyonlar ro'yxati</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Foydalanuvchi</th>
                        <th>Hamyon raqami</th>
                        <th style="text-align: right;">Balans (AIS)</th>
                        <th style="text-align: right;">Muzlatilgan</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Yaratilgan</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($wallets as $wallet)
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <img src="{{ $wallet->user?->avatar_url }}" style="width: 32px; height: 32px; border-radius: 6px; object-fit: cover;">
                                <div>
                                    <div style="font-weight: 500; color: var(--text-primary);">{{ $wallet->user?->name }}</div>
                                    <div style="font-size: 11px; color: var(--text-muted);">{{ $wallet->user?->username ?? '—' }}</div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <code style="font-size: 11px; background: var(--primary-light); padding: 2px 8px; border-radius: 4px; color: var(--info);">
                                {{ $wallet->wallet_number }}
                            </code>
                        </td>
                        <td style="text-align: right; font-weight: 600; color: var(--text-primary);">
                            {{ number_format($wallet->balance ?? 0, 4) }}
                        </td>
                        <td style="text-align: right; color: var(--text-muted);">
                            {{ $wallet->frozen_balance > 0 ? number_format($wallet->frozen_balance, 4) : '—' }}
                        </td>
                        <td style="text-align: center;">
                            @if($wallet->is_frozen)
                            <span class="badge badge-danger">
                                <i class="fa fa-snowflake"></i> Muzlatilgan
                            </span>
                            @else
                            <span class="badge badge-success">Faol</span>
                            @endif
                        </td>
                        <td style="text-align: center; color: var(--text-muted); font-size: 12px;">
                            {{ $wallet->created_at->format('d.m.Y') }}
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            <i class="fa fa-wallet" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Hamyon topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($wallets->hasPages())
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $wallets->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
