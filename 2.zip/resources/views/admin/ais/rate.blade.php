@extends('admin.layouts.app')
@section('title', 'AIS Kurs Boshqaruvi')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">AIS Kurs Boshqaruvi</span>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: color-mix(in srgb, var(--success) 10%, transparent); border: 1px solid color-mix(in srgb, var(--success) 30%, transparent); color: var(--success);">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px; margin-bottom: 24px;">
    <div class="admin-card">
        <div class="admin-card-body">
            <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 4px;">Joriy kurs</div>
            <div style="font-size: 24px; font-weight: 700; color: var(--text-primary);">
                {{ number_format($current->rate_uzs, 0) }} UZS
            </div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">1 AIS = ? UZS</div>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body">
            <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 4px;">Sotib olish kursi (UZS→AIS)</div>
            <div style="font-size: 24px; font-weight: 700; color: var(--info);">
                {{ number_format($current->buy_rate, 0) }} UZS
            </div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Foydalanuvchi to'laydi</div>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body">
            <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 4px;">Sotish kursi (AIS→UZS)</div>
            <div style="font-size: 24px; font-weight: 700; color: var(--success);">
                {{ number_format($current->sell_rate, 0) }} UZS
            </div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Foydalanuvchi oladi</div>
        </div>
    </div>
</div>

{{-- Spread ko'rsatgich --}}
@php
    $spread = $current->buy_rate > 0
        ? round((($current->buy_rate - $current->sell_rate) / $current->buy_rate) * 100, 2)
        : 0;
    $spreadUzs = $current->buy_rate - $current->sell_rate;
@endphp
<div class="admin-card" style="margin-bottom: 24px; border: 1px solid var(--warning);">
    <div class="admin-card-body">
        <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
            <div>
                <div style="font-size: 14px; font-weight: 600; color: var(--warning);">💰 Konvertatsiya Spread (Platforma Daromadi)</div>
                <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Har 1 AIS konvertatsiyadan platforma oladigan farq</div>
            </div>
            <div style="text-align: right;">
                <div style="font-size: 24px; font-weight: 700; color: var(--warning);">{{ $spread }}%</div>
                <div style="font-size: 13px; color: var(--text-muted);">{{ number_format($spreadUzs, 0) }} UZS / AIS</div>
            </div>
        </div>
        <div style="margin-top: 12px; font-size: 12px; color: var(--text-muted);">
            Misol: 1,000,000 UZS konvertatsiya → platforma <strong>{{ number_format(1000000 * $spread / 100, 0) }} UZS</strong> daromad oladi
        </div>
    </div>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 16px;">
    {{-- Kursni yangilash --}}
    <div class="admin-card">
        <div class="admin-card-header">
            <h3 style="color: var(--text-primary); font-weight: 600;">Kursni yangilash</h3>
        </div>
        <div class="admin-card-body">
            <form method="POST" action="{{ route('admin.ais.rate.update') }}">
                @csrf
                <div class="form-group">
                    <label class="form-label">1 AIS = ? UZS (asosiy kurs)</label>
                    <input type="number" name="rate_uzs" value="{{ $current->rate_uzs }}" min="1" step="1" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Sotib olish kursi (UZS → AIS)</label>
                    <input type="number" name="buy_rate" value="{{ $current->buy_rate }}" min="1" step="1" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Sotish kursi (AIS → UZS)</label>
                    <input type="number" name="sell_rate" value="{{ $current->sell_rate }}" min="1" step="1" required class="form-control">
                </div>
                <button type="submit" class="btn btn-primary btn-sm" style="width: 100%;">
                    <i class="fa fa-save"></i> Kursni saqlash
                </button>
            </form>
        </div>
    </div>

    {{-- Kurs tarixi --}}
    <div class="admin-card">
        <div class="admin-card-header">
            <h3 style="color: var(--text-primary); font-weight: 600;">Kurs tarixi</h3>
        </div>
        <div class="admin-card-body">
            <div style="display: flex; flex-direction: column; gap: 8px;">
                @foreach($history as $h)
                <div style="display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; border-radius: 8px; {{ $h->is_active ? 'background: var(--primary-light); border: 1px solid color-mix(in srgb, var(--info) 20%, transparent);' : 'background: var(--bg-card); border: 1px solid var(--border);' }}">
                    <div>
                        <span style="font-size: 14px; font-weight: 600; color: {{ $h->is_active ? 'var(--info)' : 'var(--text-primary)' }};">
                            {{ number_format($h->rate_uzs, 0) }} UZS
                        </span>
                        @if($h->is_active)
                        <span class="badge badge-success" style="margin-left: 8px;">Aktiv</span>
                        @endif
                    </div>
                    <span style="font-size: 12px; color: var(--text-muted);">{{ $h->created_at->format('d.m.Y H:i') }}</span>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
@endsection
