@extends('admin.layouts.app')
@section('title', 'AIS O\'tkazmalar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">AIS O'tkazmalar</span>
@endsection

@section('header-actions')
<span style="font-size: 13px; color: var(--text-muted);">
    Jami hajm: <strong style="color: var(--info);">{{ number_format($totalVolume, 4) }} AIS</strong>
</span>
@endsection

@section('content')
<div class="admin-card" style="margin-bottom: 16px;">
    <div class="admin-card-body" style="padding: 12px 16px;">
        <form method="GET" style="display: flex; gap: 8px;">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="Reference, username..." class="form-control" style="flex: 1;">
            <button type="submit" class="btn btn-primary btn-sm">
                <i class="fa fa-search"></i>
            </button>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">O'tkazmalar ro'yxati</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Reference</th>
                        <th>Jo'natuvchi</th>
                        <th>Qabul qiluvchi</th>
                        <th style="text-align: right;">Miqdor (AIS)</th>
                        <th style="text-align: right;">Komissiya</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($transfers as $t)
                    <tr>
                        <td>
                            <code style="font-size: 11px; background: var(--primary-light); padding: 2px 8px; border-radius: 4px; color: var(--text-secondary);">
                                {{ $t->reference }}
                            </code>
                        </td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <img src="{{ $t->sender?->avatar_url }}" style="width: 28px; height: 28px; border-radius: 6px; object-fit: cover;">
                                <div>
                                    <div style="font-size: 13px; font-weight: 500; color: var(--text-primary);">{{ $t->sender?->name }}</div>
                                    <div style="font-size: 11px; color: var(--text-muted);">{{ $t->sender?->username ?? '—' }}</div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <img src="{{ $t->receiver?->avatar_url }}" style="width: 28px; height: 28px; border-radius: 6px; object-fit: cover;">
                                <div>
                                    <div style="font-size: 13px; font-weight: 500; color: var(--text-primary);">{{ $t->receiver?->name }}</div>
                                    <div style="font-size: 11px; color: var(--text-muted);">{{ $t->receiver?->username ?? '—' }}</div>
                                </div>
                            </div>
                        </td>
                        <td style="text-align: right; font-weight: 600; color: var(--text-primary);">
                            {{ number_format($t->amount, 4) }}
                        </td>
                        <td style="text-align: right; color: var(--text-muted); font-size: 12px;">
                            {{ $t->fee > 0 ? number_format($t->fee, 4) : '—' }}
                        </td>
                        <td style="text-align: center;">
                            @php
                                $statusMap = [
                                    'completed' => 'badge-success',
                                    'pending'   => 'badge-warning',
                                    'failed'    => 'badge-danger',
                                    'reversed'  => 'badge-info',
                                ];
                                $labelMap = [
                                    'completed' => 'Bajarildi',
                                    'pending'   => 'Kutilmoqda',
                                    'failed'    => 'Xato',
                                    'reversed'  => 'Qaytarildi',
                                ];
                                $cls = $statusMap[$t->status] ?? 'badge-info';
                                $label = $labelMap[$t->status] ?? $t->status;
                            @endphp
                            <span class="badge {{ $cls }}">{{ $label }}</span>
                        </td>
                        <td style="text-align: center; color: var(--text-muted); font-size: 12px;">
                            {{ $t->created_at->format('d.m.Y H:i') }}
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            <i class="fa fa-paper-plane" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            O'tkazma topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($transfers->hasPages())
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $transfers->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
