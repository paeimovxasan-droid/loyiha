@extends('admin.layouts.app')
@section('title', 'Reklamalar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Reklamalar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.ad-network.campaigns') }}" class="btn btn-outline btn-sm">
    <i class="fa fa-arrow-left"></i> Kampaniyalar
</a>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">Reklamalar ro'yxati</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Kampaniya</th>
                        <th style="text-align: center;">Turi</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($ads as $ad)
                    <tr>
                        <td style="color: var(--text-muted);">#{{ $ad->id }}</td>
                        <td style="color: var(--text-primary);">{{ $ad->campaign->name ?? '#'.$ad->campaign_id }}</td>
                        <td style="text-align: center;">
                            <span class="badge badge-info">{{ ucfirst($ad->type ?? 'banner') }}</span>
                        </td>
                        <td style="text-align: center;">
                            <span class="badge {{ ($ad->status ?? 'active') == 'active' ? 'badge-success' : 'badge-warning' }}">
                                {{ ucfirst($ad->status ?? 'active') }}
                            </span>
                        </td>
                        <td style="text-align: center; color: var(--text-muted); font-size: 13px;">
                            {{ $ad->created_at->format('d.m.Y') }}
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            Reklama topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($ads->hasPages())
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $ads->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
