@extends('admin.layouts.app')
@section('title', 'Kampaniya tahrirlash')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.ad-network.campaigns') }}">Kampaniyalar</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Tahrirlash #{{ $campaign->id }}</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.ad-network.campaigns') }}" class="btn btn-outline btn-sm">
    <i class="fa fa-arrow-left"></i> Orqaga
</a>
@endsection

@section('content')
@if($errors->any())
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: color-mix(in srgb, var(--danger) 10%, transparent); border: 1px solid color-mix(in srgb, var(--danger) 30%, transparent); color: var(--danger);">
    <ul style="margin: 0; padding-left: 20px;">
        @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
    </ul>
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">Kampaniya tahrirlash</h3>
    </div>
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.ad-network.campaigns.update', $campaign) }}">
            @csrf
            @method('PUT')
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 16px;">
                <div class="form-group">
                    <label class="form-label">Reklama beruvchi</label>
                    <input type="text" value="{{ $campaign->user->name ?? '—' }}" disabled class="form-control" style="background: var(--primary-light);">
                </div>
                <div class="form-group">
                    <label class="form-label">Nomi</label>
                    <input type="text" name="name" value="{{ old('name', $campaign->name) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Byudjet (AIS)</label>
                    <input type="number" step="0.01" name="budget" value="{{ old('budget', $campaign->budget) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Holat</label>
                    <select name="status" class="form-control">
                        @foreach(['active','paused','completed'] as $s)
                        <option value="{{ $s }}" {{ old('status', $campaign->status) == $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
                <button type="submit" class="btn btn-primary btn-sm">Yangilash</button>
            </div>
        </form>
    </div>
</div>
@endsection
