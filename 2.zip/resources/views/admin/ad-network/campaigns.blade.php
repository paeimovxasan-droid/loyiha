@extends('admin.layouts.app')
@section('title', 'Reklama Kampaniyalari')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Reklama Kampaniyalari</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.ad-network.ads') }}" class="btn btn-primary btn-sm">
    <i class="fa fa-image"></i> Reklamalar
</a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: color-mix(in srgb, var(--success) 10%, transparent); border: 1px solid color-mix(in srgb, var(--success) 30%, transparent); color: var(--success);">
    {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">Kampaniyalar ro'yxati</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Nomi</th>
                        <th>Reklama beruvchi</th>
                        <th style="text-align: center;">Byudjet</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($campaigns as $campaign)
                    <tr>
                        <td style="color: var(--text-primary); font-weight: 500;">{{ $campaign->name ?? '#'.$campaign->id }}</td>
                        <td style="color: var(--text-secondary);">{{ $campaign->user->name ?? '—' }}</td>
                        <td style="text-align: center; font-weight: 600; color: var(--text-primary);">{{ number_format($campaign->budget ?? 0, 2) }} AIS</td>
                        <td style="text-align: center;">
                            <span class="badge {{ ($campaign->status ?? 'active') == 'active' ? 'badge-success' : 'badge-warning' }}">
                                {{ ucfirst($campaign->status ?? 'active') }}
                            </span>
                        </td>
                        <td style="text-align: center; color: var(--text-muted); font-size: 13px;">{{ $campaign->created_at->format('d.m.Y') }}</td>
                        <td style="text-align: center;">
                            <a href="{{ route('admin.ad-network.campaigns.edit', $campaign) }}" class="btn btn-primary btn-sm">
                                <i class="fa fa-pen"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            <i class="fa fa-ad" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Kampaniya topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($campaigns->hasPages())
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $campaigns->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
