@extends('admin.layouts.app')
@section('title', 'Kanal Postlari')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Kanal Postlari</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.channel-posts.create') }}" class="btn btn-primary btn-sm">
    <i class="fa fa-plus"></i> Yangi e'lon
</a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="text-align: left;">Mazmun</th>
                        <th style="text-align: center;">Turi</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Muallif</th>
                        <th style="text-align: center;">Yuborilgan</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($posts as $post)
                    <tr>
                        <td style="color: var(--text-primary); max-width: 400px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ Str::limit($post->content, 80) }}</td>
                        <td style="text-align: center;">
                            <span class="badge badge-info">{{ ucfirst($post->type) }}</span>
                        </td>
                        <td style="text-align: center;">
                            @if($post->status == 'sent')
                            <span class="badge badge-success">{{ ucfirst($post->status) }}</span>
                            @else
                            <span class="badge badge-warning">{{ ucfirst($post->status) }}</span>
                            @endif
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $post->creator->name ?? '—' }}</td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $post->sent_at?->format('d.m.Y H:i') ?? '—' }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            <i class="fa fa-paper-plane" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Post topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    <div class="pagination" style="padding: 12px 16px; border-top: 1px solid var(--border);">{{ $posts->links() }}</div>
</div>
@endsection
