@extends('admin.layouts.app')
@section('title', 'Yangi E\'lon')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.channel-posts.index') }}">Kanal Postlari</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Yangi e'lon</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.channel-posts.index') }}" class="btn btn-outline btn-sm">
    <i class="fa fa-arrow-left"></i> Orqaga
</a>
@endsection

@section('content')
@if($errors->any())
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid var(--danger); color: var(--danger); margin-bottom: 16px;">
    @foreach($errors->all() as $error) <p style="margin: 0;">{{ $error }}</p> @endforeach
</div>
@endif

<div class="admin-card" style="max-width: 640px;">
    <div class="admin-card-header">Yangi Kanal E'loni</div>
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.channel-posts.store') }}" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label class="form-label">Mazmun</label>
                <textarea name="content" rows="6" required class="form-control" placeholder="E'lon matnini kiriting...">{{ old('content') }}</textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Rasm (ixtiyoriy)</label>
                <input type="file" name="photo" accept="image/*" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary" style="margin-top: 8px;">
                <i class="fa fa-paper-plane"></i> Yuborish
            </button>
        </form>
    </div>
</div>
@endsection
