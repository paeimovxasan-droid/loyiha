@extends('admin.layouts.app')
@section('title', 'Support Tickets')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Support Tickets</span>
@endsection

@section('content')

{{-- Statistika --}}
<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-bottom: 20px;">
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--danger);">{{ $stats['open'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Yangi / Qayta ochildi</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--warning);">{{ $stats['in_progress'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Ko'rib chiqilmoqda</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--success);">{{ $stats['answered'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Javob berildi</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--text-secondary);">{{ $stats['closed_today'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Bugun yopildi</div>
    </div>
</div>

{{-- Filtrlar --}}
<div class="admin-card" style="padding: 16px; margin-bottom: 16px;">
    <form method="GET" style="display: flex; flex-wrap: wrap; gap: 12px; align-items: center;">
        <select name="status" class="form-control" style="width: 160px;">
            <option value="">Barcha holat</option>
            @foreach($statuses as $key => $s)
            <option value="{{ $key }}" @selected(request('status')==$key)>{{ $s['label'] }}</option>
            @endforeach
        </select>
        <select name="category" class="form-control" style="width: 176px;">
            <option value="">Barcha kategoriya</option>
            @foreach($categories as $key => $label)
            <option value="{{ $key }}" @selected(request('category')==$key)>{{ $label }}</option>
            @endforeach
        </select>
        <select name="priority" class="form-control" style="width: 144px;">
            <option value="">Barcha prioritet</option>
            @foreach($priorities as $key => $p)
            <option value="{{ $key }}" @selected(request('priority')==$key)>{{ $p['label'] }}</option>
            @endforeach
        </select>
        <input type="text" name="search" value="{{ request('search') }}"
               placeholder="Ticket raqami, mavzu, foydalanuvchi..."
               class="form-control" style="width: 224px;">
        <button type="submit" class="btn btn-primary btn-sm">Qidirish</button>
        <a href="{{ route('admin.support.index') }}" class="btn btn-outline btn-sm">Tozalash</a>
    </form>
</div>

@if(session('success'))
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid rgba(var(--success-rgb), 0.3); color: var(--success);">
    <i class="fa fa-check-circle" style="margin-right: 8px;"></i> {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Ticket</th>
                    <th>Foydalanuvchi</th>
                    <th>Kategoriya</th>
                    <th>Prioritet</th>
                    <th>Holat</th>
                    <th>Oxirgi xabar</th>
                    <th>Amal</th>
                </tr>
            </thead>
            <tbody>
                @forelse($tickets as $ticket)
                @php
                    $unread = $ticket->messages()->where('is_admin_reply', false)->where('is_read', false)->count();
                @endphp
                <tr style="{{ $unread > 0 ? 'background: var(--primary-light);' : '' }}">
                    <td>
                        <div style="font-family: monospace; font-size: 12px; color: var(--text-muted);">#{{ $ticket->ticket_number }}</div>
                        <div style="font-size: 14px; font-weight: 500; color: var(--text-primary); margin-top: 2px;">
                            {{ Str::limit($ticket->subject, 35) }}
                        </div>
                        @if($unread > 0)
                        <span class="badge badge-danger" style="font-size: 11px;">{{ $unread }} yangi</span>
                        @endif
                    </td>
                    <td>
                        <div style="font-size: 14px; font-weight: 500;">{{ $ticket->user->name }}</div>
                        <div style="font-size: 12px; color: var(--text-muted);">{{ $ticket->user->username }}</div>
                    </td>
                    <td style="font-size: 14px;">{{ $ticket->category_label }}</td>
                    <td>
                        <span style="font-size: 12px; font-weight: 600; color: {{ $ticket->priority_color }};">
                            {{ $ticket->priority_label }}
                        </span>
                    </td>
                    <td>{!! $ticket->status_badge !!}</td>
                    <td style="font-size: 12px; color: var(--text-muted);">
                        {{ $ticket->last_reply_at?->diffForHumans() ?? $ticket->created_at->diffForHumans() }}
                    </td>
                    <td>
                        <a href="{{ route('admin.support.show', $ticket) }}" class="btn btn-primary btn-sm">
                            Ko'rish
                        </a>
                    </td>
                </tr>
                @empty
                <tr><td colspan="7" style="text-align: center; padding: 40px; color: var(--text-muted);">Ticket topilmadi</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="pagination" style="padding: 16px;">{{ $tickets->links() }}</div>
</div>
@endsection
