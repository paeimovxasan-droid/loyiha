@extends('admin.layouts.app')
@section('title', 'Ticket #' . $ticket->ticket_number)

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.support.index') }}">Support Tickets</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">#{{ $ticket->ticket_number }}</span>
@endsection

@section('header-actions')
    {!! $ticket->status_badge !!}
@endsection

@section('content')

@if(session('success'))
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid rgba(var(--success-rgb), 0.3); color: var(--success);">
    <i class="fa fa-check-circle" style="margin-right: 8px;"></i> {{ session('success') }}
</div>
@endif

<div style="display: grid; grid-template-columns: 1fr; gap: 20px;">
    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">

        {{-- Xabarlar --}}
        <div>
            <div class="admin-card" style="padding: 20px; margin-bottom: 16px; max-height: 600px; overflow-y: auto;" id="messages-container">
                <div style="display: flex; flex-direction: column; gap: 16px;">
                    @foreach($messages as $msg)
                    @php $isAdmin = $msg->is_admin_reply; @endphp
                    <div style="display: flex; {{ $isAdmin ? '' : 'flex-direction: row-reverse;' }} gap: 12px; align-items: flex-end;">
                        <img src="{{ $msg->user?->avatar_url ?? 'https://ui-avatars.com/api/?name=U&color=7F9CF5&background=EBF4FF' }}"
                             style="width: 36px; height: 36px; border-radius: 12px; flex-shrink: 0; object-fit: cover; border: 2px solid {{ $isAdmin ? 'var(--info)' : 'var(--success)' }};">
                        <div style="max-width: 80%;">
                            <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 4px; {{ $isAdmin ? '' : 'text-align: right;' }}">
                                {{ $isAdmin ? '🛡️ ' . ($msg->user?->name ?? 'Admin') : ($msg->user?->name ?? 'Foydalanuvchi') }}
                                · {{ $msg->created_at->format('d.m H:i') }}
                            </div>
                            <div style="border-radius: 12px; padding: 12px; {{ $isAdmin ? 'background: var(--primary-light); border: 1px solid var(--border);' : 'background: var(--bg-card); border: 1px solid var(--border);' }}">
                                <p style="font-size: 14px; color: var(--text-primary); white-space: pre-wrap; margin: 0;">{{ $msg->message }}</p>
                                @if($msg->attachment_url)
                                <a href="{{ $msg->attachment_url }}" target="_blank"
                                   style="display: inline-flex; align-items: center; gap: 4px; margin-top: 8px; font-size: 12px; color: var(--info); text-decoration: none;">
                                    <i class="fa fa-paperclip"></i> Fayl ko'rish
                                </a>
                                @endif
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
            </div>

            {{-- Javob formasi --}}
            @if($ticket->isOpen())
            <div class="admin-card" style="padding: 20px;">
                <h3 style="font-weight: 600; color: var(--text-primary); margin-bottom: 12px;">Javob yozish</h3>
                <form method="POST" action="{{ route('admin.support.reply', $ticket) }}" enctype="multipart/form-data">
                    @csrf
                    <textarea name="message" rows="4" class="form-control" style="width: 100%; margin-bottom: 12px;"
                              placeholder="Javobingizni yozing..." required></textarea>
                    <div style="display: flex; align-items: center; gap: 12px; flex-wrap: wrap;">
                        <input type="file" name="attachment" class="form-control" style="flex: 1;"
                               accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
                        <select name="status" class="form-control" style="width: 176px;">
                            <option value="answered">Javob berildi</option>
                            <option value="in_progress">Ko'rib chiqilmoqda</option>
                            <option value="closed">Yopish</option>
                        </select>
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="fa fa-paper-plane" style="margin-right: 4px;"></i> Yuborish
                        </button>
                    </div>
                </form>
            </div>
            @else
            <div class="admin-card" style="padding: 20px; text-align: center; color: var(--text-muted);">
                <i class="fa fa-lock" style="font-size: 24px; display: block; opacity: 0.4; margin-bottom: 8px;"></i>
                Ticket yopilgan
            </div>
            @endif
        </div>

        {{-- Ticket ma'lumotlari --}}
        <div style="display: flex; flex-direction: column; gap: 16px;">
            {{-- Foydalanuvchi --}}
            <div class="admin-card" style="padding: 16px;">
                <h3 style="font-weight: 600; color: var(--text-primary); margin-bottom: 12px; font-size: 14px;">👤 Foydalanuvchi</h3>
                @if($ticket->user)
                <div style="display: flex; align-items: center; gap: 12px;">
                    <img src="{{ $ticket->user->avatar_url }}" style="width: 40px; height: 40px; border-radius: 12px; object-fit: cover;">
                    <div>
                        <div style="font-weight: 500; font-size: 14px;">{{ $ticket->user->name }}</div>
                        <div style="font-size: 12px; color: var(--text-muted);">{{ $ticket->user->username }}</div>
                    </div>
                </div>
                <div style="margin-top: 12px; font-size: 12px; color: var(--text-secondary); display: flex; flex-direction: column; gap: 4px;">
                    <div>📧 {{ $ticket->user->email }}</div>
                    <div>📅 Ro'yxat: {{ $ticket->user->created_at->format('d.m.Y') }}</div>
                    <div>🎫 Jami ticket: {{ $ticket->user->supportTickets()->count() }}</div>
                </div>
                <a href="{{ route('admin.users.edit', $ticket->user) }}" class="btn btn-outline btn-sm" style="width: 100%; margin-top: 12px; text-align: center;">
                    Profilni ko'rish
                </a>
                @else
                <div style="font-size: 14px; color: var(--text-muted);">Foydalanuvchi o'chirilgan</div>
                @endif
            </div>

            {{-- Ticket sozlamalari --}}
            <div class="admin-card" style="padding: 16px;">
                <h3 style="font-weight: 600; color: var(--text-primary); margin-bottom: 12px; font-size: 14px;">⚙️ Sozlamalar</h3>
                <form method="POST" action="{{ route('admin.support.update', $ticket) }}">
                    @csrf @method('PUT')
                    <div class="form-group">
                        <label class="form-label">Prioritet</label>
                        <select name="priority" class="form-control">
                            @foreach($priorities as $key => $p)
                            <option value="{{ $key }}" @selected($ticket->priority === $key)>{{ $p['label'] }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Mas'ul admin</label>
                        <select name="assigned_to" class="form-control">
                            <option value="">Belgilanmagan</option>
                            @foreach($admins as $admin)
                            <option value="{{ $admin->id }}" @selected($ticket->assigned_to === $admin->id)>{{ $admin->name }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Holat</label>
                        <select name="status" class="form-control">
                            <option value="open" @selected($ticket->status==='open')>Yangi</option>
                            <option value="in_progress" @selected($ticket->status==='in_progress')>Ko'rib chiqilmoqda</option>
                            <option value="answered" @selected($ticket->status==='answered')>Javob berildi</option>
                            <option value="closed" @selected($ticket->status==='closed')>Yopildi</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-outline btn-sm" style="width: 100%;">
                        Saqlash
                    </button>
                </form>
            </div>

            {{-- Ticket info --}}
            <div class="admin-card" style="padding: 16px; font-size: 12px; color: var(--text-secondary); display: flex; flex-direction: column; gap: 8px;">
                <div>🏷️ Kategoriya: <strong>{{ $ticket->category_label }}</strong></div>
                <div>📅 Yaratildi: {{ $ticket->created_at->format('d.m.Y H:i') }}</div>
                <div>💬 Xabarlar: {{ $ticket->messages()->count() }}</div>
                @if($ticket->assigned_to)
                <div>👤 Mas'ul: {{ $ticket->assignedTo->name }}</div>
                @endif
                @if($ticket->closed_at)
                <div>🔒 Yopildi: {{ $ticket->closed_at->format('d.m.Y H:i') }}</div>
                @endif
            </div>
        </div>

    </div>
</div>

<script>
    // Xabarlar pastiga scroll
    var container = document.getElementById('messages-container');
    if (container) container.scrollTop = container.scrollHeight;
</script>
@endsection
