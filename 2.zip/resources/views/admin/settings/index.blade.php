@extends('admin.layouts.app')

@section('title', __('settings.title'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('settings.title') }}</span>
@endsection

@section('header-actions')
    <button type="submit" form="settingsForm" class="btn btn-primary btn-sm">
        <i class="fa fa-save"></i> {{ __('buttons.save') }}
    </button>
@endsection

@section('content')

<form id="settingsForm" action="{{ route('admin.settings.update') }}" method="POST" enctype="multipart/form-data">
    @csrf
    @method('PUT')

    <div style="display: grid; grid-template-columns: 1fr; gap: 20px;">
        {{-- Left Column: System Info --}}
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
            <div>
                {{-- Site Name with Tabs --}}
                <div class="admin-card" style="margin-bottom: 20px;">
                    <div style="padding: 20px;">
                        <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 16px;">{{ __('settings.system_info') }}</h3>

                        {{-- Language Tabs --}}
                        <div style="margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 20px;">
                            <div style="display: flex; gap: 8px; margin-bottom: 16px; border-bottom: 1px solid var(--border);">
                                <button type="button" class="tab-btn active" onclick="switchTab('uz')" id="tab-uz"
                                        style="padding: 8px 16px; font-size: 13px; font-weight: 600; border: none; background: none; cursor: pointer; border-bottom: 2px solid var(--primary-light); color: var(--primary-light);">
                                    {{ __('payment_methods.uzbek') }}
                                </button>
                                <button type="button" class="tab-btn" onclick="switchTab('ru')" id="tab-ru"
                                        style="padding: 8px 16px; font-size: 13px; font-weight: 600; border: none; background: none; cursor: pointer; border-bottom: 2px solid transparent; color: var(--text-muted);">
                                    {{ __('payment_methods.russian') }}
                                </button>
                                <button type="button" class="tab-btn" onclick="switchTab('en')" id="tab-en"
                                        style="padding: 8px 16px; font-size: 13px; font-weight: 600; border: none; background: none; cursor: pointer; border-bottom: 2px solid transparent; color: var(--text-muted);">
                                    {{ __('payment_methods.english') }}
                                </button>
                            </div>

                            <div id="panel-uz">
                                <div class="form-group">
                                    <label class="form-label">{{ __('settings.site_name') }} (UZ) <span style="color: var(--danger);">*</span></label>
                                    <input name="site_name[uz]" type="text" value="{{ old('site_name.uz', $setting->getTranslation('site_name', 'uz', false) ?? '') }}" required class="form-control">
                                </div>
                            </div>

                            <div id="panel-ru" style="display: none;">
                                <div class="form-group">
                                    <label class="form-label">{{ __('settings.site_name') }} (RU)</label>
                                    <input name="site_name[ru]" type="text" value="{{ old('site_name.ru', $setting->getTranslation('site_name', 'ru', false) ?? '') }}" class="form-control">
                                </div>
                            </div>

                            <div id="panel-en" style="display: none;">
                                <div class="form-group">
                                    <label class="form-label">{{ __('settings.site_name') }} (EN)</label>
                                    <input name="site_name[en]" type="text" value="{{ old('site_name.en', $setting->getTranslation('site_name', 'en', false) ?? '') }}" class="form-control">
                                </div>
                            </div>
                        </div>

                        {{-- Contact Info --}}
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                            <div class="form-group">
                                <label class="form-label">{{ __('settings.contact_phone') }}</label>
                                <input name="contact_phone" type="text" value="{{ old('contact_phone', $setting->contact_phone) }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label">{{ __('settings.contact_email') }}</label>
                                <input name="contact_email" type="email" value="{{ old('contact_email', $setting->contact_email) }}" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Social Media --}}
                <div class="admin-card" style="margin-bottom: 20px;">
                    <div style="padding: 20px;">
                        <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 16px;">{{ __('settings.social_media') }}</h3>
                        <div style="display: grid; gap: 14px;">
                            <div class="form-group">
                                <label class="form-label"><i class="fa-brands fa-telegram" style="color: var(--primary-light);"></i> Telegram kanal</label>
                                <input name="telegram" type="text" value="{{ old('telegram', $setting->telegram) }}" placeholder="@aisoqqa_uz" class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label"><i class="fa fa-robot" style="color: var(--primary-light);"></i> Telegram bot username</label>
                                <input name="telegram_bot_username" type="text" value="{{ old('telegram_bot_username', $setting->telegram_bot_username ?? '') }}" placeholder="@aisoqqauzbot" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Branding --}}
                <div class="admin-card">
                    <div style="padding: 20px;">
                        <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 16px;">{{ __('settings.branding') }}</h3>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                            <div>
                                <x-admin.file-upload
                                    name="logo_id"
                                    folder="settings"
                                    :label="__('settings.logo')"
                                    :current-url="$setting->logo_url"
                                    :current-id="$setting->logo_id"
                                />
                                @error('logo_id') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                            </div>
                            <div>
                                <x-admin.file-upload
                                    name="favicon_id"
                                    folder="settings"
                                    :label="__('settings.favicon')"
                                    :current-url="$setting->favicon_url"
                                    :current-id="$setting->favicon_id"
                                />
                                @error('favicon_id') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {{-- Right Column: Financial Settings --}}
            <div>
                {{-- Deposit Settings --}}
                <div class="admin-card" style="margin-bottom: 20px;">
                    <div style="padding: 20px;">
                        <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 16px;">{{ __('settings.financial_deposit') }}</h3>
                        <div style="display: grid; gap: 14px;">
                            <div class="form-group">
                                <label class="form-label">{{ __('settings.currency') }} <span style="color: var(--danger);">*</span></label>
                                <input name="currency" type="text" value="{{ old('currency', $setting->currency) }}" required class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label">{{ __('settings.min_deposit') }} <span style="color: var(--danger);">*</span></label>
                                <input name="min_deposit" type="number" step="0.01" value="{{ old('min_deposit', $setting->min_deposit) }}" required class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label">{{ __('settings.max_deposit') }} <span style="color: var(--danger);">*</span></label>
                                <input name="max_deposit" type="number" step="0.01" value="{{ old('max_deposit', $setting->max_deposit) }}" required class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Withdraw Settings --}}
                <div class="admin-card" style="margin-bottom: 20px;">
                    <div style="padding: 20px;">
                        <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 16px;">{{ __('settings.financial_withdraw') }}</h3>
                        <div style="display: grid; gap: 14px;">
                            <div class="form-group">
                                <label class="form-label">{{ __('settings.min_withdraw') }} <span style="color: var(--danger);">*</span></label>
                                <input name="min_withdraw" type="number" step="0.01" value="{{ old('min_withdraw', $setting->min_withdraw) }}" required class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label">{{ __('settings.max_withdraw') }} <span style="color: var(--danger);">*</span></label>
                                <input name="max_withdraw" type="number" step="0.01" value="{{ old('max_withdraw', $setting->max_withdraw) }}" required class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Revenue Settings --}}
                <div class="admin-card" style="margin-bottom: 20px;">
                    <div style="padding: 20px;">
                        <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 16px;">💰 Daromad Sozlamalari</h3>
                        <div style="display: grid; gap: 14px;">
                            <div class="form-group">
                                <label class="form-label">Yechim global komissiyasi (%)</label>
                                <input name="withdrawal_fee_percent" type="number" step="0.01" min="0" max="20"
                                       value="{{ old('withdrawal_fee_percent', $setting->withdrawal_fee_percent ?? 1.00) }}" class="form-control">
                                <span style="font-size: 11px; color: var(--text-muted); margin-top: 4px; display: block;">Masalan: 1.00 = har 100,000 UZS yechimdan 1,000 UZS komissiya</span>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Lucky Draw platforma ulushi (%)</label>
                                <input name="lucky_draw_rake_percent" type="number" step="0.01" min="0" max="90"
                                       value="{{ old('lucky_draw_rake_percent', $setting->lucky_draw_rake_percent ?? 25.00) }}" class="form-control">
                                <span style="font-size: 11px; color: var(--text-muted); margin-top: 4px; display: block;">Masalan: 25 = prize pool ning 25% platforma daromadi, 75% g'olibga</span>
                            </div>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <input type="hidden" name="require_first_deposit" value="0">
                                <input type="checkbox" name="require_first_deposit" value="1"
                                       {{ ($setting->require_first_deposit ?? false) ? 'checked' : '' }}
                                       style="accent-color: var(--primary-light);">
                                <div>
                                    <span style="font-size: 13px; font-weight: 600; color: var(--text-primary);">Birinchi depozit majburiy</span>
                                    <span style="font-size: 11px; color: var(--text-muted); display: block;">Yoqilsa — depozit qilmagan foydalanuvchilar dashboard'ga kira olmaydi</span>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Minimal birinchi depozit (UZS)</label>
                                <input name="first_deposit_min_amount" type="number" step="1000" min="0"
                                       value="{{ old('first_deposit_min_amount', $setting->first_deposit_min_amount ?? 50000) }}" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                {{-- VIP Membership Prices --}}
                <div class="admin-card">
                    <div style="padding: 20px;">
                        <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 16px;">👑 VIP Membership Narxlari (UZS/oy)</h3>
                        <div style="display: grid; gap: 14px;">
                            <div class="form-group">
                                <label class="form-label">🥈 Silver narxi</label>
                                <input name="vip_silver_price" type="number" step="1000" min="0"
                                       value="{{ old('vip_silver_price', $setting->vip_silver_price ?? 50000) }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label">🥇 Gold narxi</label>
                                <input name="vip_gold_price" type="number" step="1000" min="0"
                                       value="{{ old('vip_gold_price', $setting->vip_gold_price ?? 150000) }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label">💎 Platinum narxi</label>
                                <input name="vip_platinum_price" type="number" step="1000" min="0"
                                       value="{{ old('vip_platinum_price', $setting->vip_platinum_price ?? 500000) }}" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
function switchTab(lang) {
    // Hide all panels
    document.getElementById('panel-uz').style.display = 'none';
    document.getElementById('panel-ru').style.display = 'none';
    document.getElementById('panel-en').style.display = 'none';

    // Reset all tabs
    document.getElementById('tab-uz').style.borderBottomColor = 'transparent';
    document.getElementById('tab-uz').style.color = 'var(--text-muted)';
    document.getElementById('tab-ru').style.borderBottomColor = 'transparent';
    document.getElementById('tab-ru').style.color = 'var(--text-muted)';
    document.getElementById('tab-en').style.borderBottomColor = 'transparent';
    document.getElementById('tab-en').style.color = 'var(--text-muted)';

    // Show selected panel and activate tab
    document.getElementById('panel-' + lang).style.display = 'block';
    document.getElementById('tab-' + lang).style.borderBottomColor = 'var(--primary-light)';
    document.getElementById('tab-' + lang).style.color = 'var(--primary-light)';
}
</script>

@endsection
