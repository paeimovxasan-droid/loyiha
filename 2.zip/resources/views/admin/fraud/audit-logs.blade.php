@extends('admin.layouts.app')
@section('title', 'Audit Logs')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.fraud.index') }}">Fraud</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Audit Logs</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.fraud.index') }}" class="btn btn-outline btn-sm"><i class="fa fa-arrow-left"></i> Dashboard</a>
@endsection

@section('content')
{{-- Filter --}}
<div class="admin-card" style="margin-bottom: 16px;">
    <div class="admin-card-body">
        <form method="GET" style="display: flex; flex-wrap: wrap; gap: 8px; align-items: center;">
            <input type="text" name="action" value="{{ request('action') }}"
                   placeholder="Action (masalan: kyc_approved)"
                   class="form-control" style="width: 200px;">
            <input type="number" name="user_id" value="{{ request('user_id') }}"
                   placeholder="User ID"
                   class="form-control" style="width: 120px;">
            <input type="date" name="date_from" value="{{ request('date_from') }}"
                   class="form-control" style="width: auto;">
            <input type="date" name="date_to" value="{{ request('date_to') }}"
                   class="form-control" style="width: auto;">
            <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-search"></i></button>
            <a href="{{ route('admin.fraud.audit-logs') }}" class="btn btn-outline btn-sm"><i class="fa fa-times"></i></a>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Foydalanuvchi</th>
                        <th>Action</th>
                        <th style="text-align: center;">IP</th>
                        <th style="text-align: center;">Sana</th>
                        <th style="text-align: center;">Payload</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($logs as $log)
                    <tr>
                        <td>
                            @if($log->user)
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <img src="{{ $log->user->avatar_url }}" style="width: 28px; height: 28px; border-radius: 8px; object-fit: cover;">
                                <div>
                                    <div style="font-size: 12px; font-weight: 500; color: var(--text-primary);">{{ $log->user->name }}</div>
                                    <div style="font-size: 11px; color: var(--text-muted);">ID: {{ $log->user_id }}</div>
                                </div>
                            </div>
                            @else
                            <span style="font-size: 12px; color: var(--text-muted);">System / ID: {{ $log->user_id ?? '—' }}</span>
                            @endif
                        </td>
                        <td>
                            @if(str_contains($log->action, 'banned') || str_contains($log->action, 'fraud') || str_contains($log->action, 'blocked'))
                            <span class="badge badge-danger" style="font-family: monospace;">{{ $log->action }}</span>
                            @elseif(str_contains($log->action, 'approved') || str_contains($log->action, 'verified'))
                            <span class="badge badge-success" style="font-family: monospace;">{{ $log->action }}</span>
                            @else
                            <span class="badge badge-info" style="font-family: monospace;">{{ $log->action }}</span>
                            @endif
                        </td>
                        <td style="text-align: center; font-family: monospace; font-size: 12px; color: var(--text-muted);">
                            {{ $log->ip_address ?? '—' }}
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">
                            {{ $log->created_at->format('d.m.Y H:i:s') }}
                        </td>
                        <td style="text-align: center;">
                            @if($log->payload)
                            <button onclick="var el = this.nextElementSibling; el.style.display = el.style.display === 'none' ? 'block' : 'none';"
                                    class="btn btn-outline btn-sm" style="padding: 2px 8px;">
                                <i class="fa fa-code"></i>
                            </button>
                            <pre style="display: none; margin-top: 4px; font-size: 11px; background: var(--bg-card); border: 1px solid var(--border); border-radius: 6px; padding: 8px; text-align: left; max-width: 300px; overflow: auto;">{{ json_encode($log->payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) }}</pre>
                            @else
                            <span style="color: var(--text-muted);">—</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="fa fa-list" style="font-size: 28px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Audit log topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($logs->hasPages())
        <div class="pagination" style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $logs->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
