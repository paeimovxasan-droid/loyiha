@extends('admin.layouts.app')
@section('title', 'Shubhali Tranzaksiyalar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.fraud.index') }}">Fraud</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Shubhali Depozitlar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.fraud.index') }}" class="btn btn-outline btn-sm"><i class="fa fa-arrow-left"></i> Dashboard</a>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Foydalanuvchi</th>
                        <th style="text-align: center;">Summa</th>
                        <th style="text-align: center;">To'lov usuli</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($deposits as $deposit)
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <img src="{{ $deposit->user?->avatar_url }}" style="width: 36px; height: 36px; border-radius: 10px; object-fit: cover; flex-shrink: 0;">
                                <div>
                                    <div style="font-weight: 500; color: var(--text-primary);">{{ $deposit->user?->name ?? 'N/A' }}</div>
                                    <div style="font-size: 12px; color: var(--text-muted);">{{ $deposit->user?->email }}</div>
                                </div>
                            </div>
                        </td>
                        <td style="text-align: center; font-weight: 600; color: var(--warning);">
                            {{ number_format($deposit->amount) }} UZS
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">
                            {{ $deposit->method_name }}
                        </td>
                        <td style="text-align: center;">
                            @if($deposit->status === 'pending')
                            <span class="badge badge-warning">Kutilmoqda</span>
                            @elseif($deposit->status === 'approved')
                            <span class="badge badge-success">Tasdiqlangan</span>
                            @else
                            <span class="badge badge-danger">Rad etilgan</span>
                            @endif
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">
                            {{ $deposit->created_at->format('d.m.Y H:i') }}
                        </td>
                        <td style="text-align: center;">
                            @if($deposit->user)
                            <a href="{{ route('admin.fraud.user-detail', $deposit->user) }}" class="btn btn-primary btn-sm" style="padding: 4px 10px;">
                                <i class="fa fa-user"></i> Profil
                            </a>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="fa fa-check-circle" style="font-size: 28px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Shubhali depozit topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($deposits->hasPages())
        <div class="pagination" style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $deposits->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
