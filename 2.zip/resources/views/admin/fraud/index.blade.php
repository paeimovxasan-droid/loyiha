@extends('admin.layouts.app')
@section('title', 'Fraud Dashboard')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Fraud Dashboard</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.fraud.audit-logs') }}" class="btn btn-outline btn-sm"><i class="fa fa-list"></i> Audit Logs</a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 20px;">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif

{{-- Statistika kartalar --}}
<div style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 16px; margin-bottom: 24px;">
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <div style="font-size: 24px; font-weight: 700; color: var(--danger);">{{ $stats['today_flags'] }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Bugungi flaglar</div>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <div style="font-size: 24px; font-weight: 700; color: var(--warning);">{{ $stats['total_flags'] }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Aktiv flaglar</div>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <div style="font-size: 24px; font-weight: 700; color: var(--danger);">{{ $stats['high_risk'] }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">High Risk</div>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <div style="font-size: 24px; font-weight: 700; color: var(--text-secondary);">{{ $stats['blocked_ips'] }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">VPN/Proxy IP</div>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <div style="font-size: 24px; font-weight: 700; color: var(--warning);">{{ $stats['pending_kyc'] }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">KYC kutmoqda</div>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <div style="font-size: 24px; font-weight: 700; color: var(--danger);">{{ $stats['banned_users'] }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Banned</div>
        </div>
    </div>
</div>

<div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px;">
    {{-- So'nggi fraud flaglar --}}
    <div class="admin-card">
        <div class="admin-card-header" style="display: flex; align-items: center; justify-content: space-between;">
            <h3 style="margin: 0; color: var(--text-primary);">🚩 So'nggi Fraud Flaglar</h3>
            <a href="{{ route('admin.fraud.users') }}" style="font-size: 12px; color: var(--primary-light); text-decoration: none;">Barchasi →</a>
        </div>
        <div class="admin-card-body" style="padding: 0;">
            @forelse($recentFlags as $flag)
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-bottom: 1px solid var(--border);">
                <img src="{{ $flag->user?->avatar_url }}" style="width: 32px; height: 32px; border-radius: 8px; object-fit: cover; flex-shrink: 0;">
                <div style="flex: 1; min-width: 0;">
                    <div style="font-size: 14px; font-weight: 500; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        {{ $flag->user?->name ?? 'N/A' }}
                    </div>
                    <div style="font-size: 12px; color: var(--text-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{{ $flag->reason }}</div>
                </div>
                <div style="font-size: 12px; color: var(--text-muted); flex-shrink: 0;">
                    {{ $flag->created_at->diffForHumans() }}
                </div>
            </div>
            @empty
            <div style="padding: 32px; text-align: center; color: var(--text-muted); font-size: 14px;">
                <i class="fa fa-shield-halved" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                Fraud flag yo'q
            </div>
            @endforelse
        </div>
    </div>

    {{-- Shubhali depozitlar --}}
    <div class="admin-card">
        <div class="admin-card-header" style="display: flex; align-items: center; justify-content: space-between;">
            <h3 style="margin: 0; color: var(--text-primary);">⚠️ Shubhali Depozitlar</h3>
            <a href="{{ route('admin.fraud.transactions') }}" style="font-size: 12px; color: var(--primary-light); text-decoration: none;">Barchasi →</a>
        </div>
        <div class="admin-card-body" style="padding: 0;">
            @forelse($recentSuspicious as $deposit)
            <div style="display: flex; align-items: center; gap: 12px; padding: 12px 16px; border-bottom: 1px solid var(--border);">
                <div style="width: 32px; height: 32px; border-radius: 8px; background: rgba(var(--warning-rgb), 0.15); display: flex; align-items: center; justify-content: center; flex-shrink: 0;">
                    <i class="fa fa-triangle-exclamation" style="color: var(--warning); font-size: 14px;"></i>
                </div>
                <div style="flex: 1; min-width: 0;">
                    <div style="font-size: 14px; font-weight: 500; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                        {{ $deposit->user?->name ?? 'N/A' }}
                    </div>
                    <div style="font-size: 12px; color: var(--text-muted);">{{ number_format($deposit->amount) }} UZS</div>
                </div>
                <div style="font-size: 12px; color: var(--text-muted); flex-shrink: 0;">
                    {{ $deposit->created_at->diffForHumans() }}
                </div>
            </div>
            @empty
            <div style="padding: 32px; text-align: center; color: var(--text-muted); font-size: 14px;">
                <i class="fa fa-check-circle" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                Shubhali depozit yo'q
            </div>
            @endforelse
        </div>
    </div>
</div>
@endsection
