@extends('admin.layouts.app')
@section('title', 'Fraud Foydalanuvchilar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.fraud.index') }}">Fraud</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Foydalanuvchilar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.fraud.index') }}" class="btn btn-outline btn-sm"><i class="fa fa-arrow-left"></i> Dashboard</a>
@endsection

@section('content')
{{-- Filter --}}
<div class="admin-card" style="margin-bottom: 16px;">
    <div class="admin-card-body">
        <form method="GET" style="display: flex; gap: 8px; align-items: center;">
            <input type="text" name="search" value="{{ request('search') }}"
                   placeholder="Ism, email, username..."
                   class="form-control" style="flex: 1;">
            <select name="risk" class="form-control" style="width: 160px;">
                <option value="">Barcha risk</option>
                <option value="high" {{ request('risk') === 'high' ? 'selected' : '' }}>High Risk</option>
                <option value="normal" {{ request('risk') === 'normal' ? 'selected' : '' }}>Normal</option>
            </select>
            <button type="submit" class="btn btn-primary btn-sm"><i class="fa fa-search"></i></button>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Foydalanuvchi</th>
                        <th style="text-align: center;">Score</th>
                        <th style="text-align: center;">Flaglar</th>
                        <th style="text-align: center;">IP</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($users as $user)
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <img src="{{ $user->avatar_url }}" style="width: 36px; height: 36px; border-radius: 10px; object-fit: cover; flex-shrink: 0;">
                                <div>
                                    <div style="font-weight: 500; color: var(--text-primary);">{{ $user->name }}</div>
                                    <div style="font-size: 12px; color: var(--text-muted);">{{ $user->email }}</div>
                                </div>
                            </div>
                        </td>
                        <td style="text-align: center;">
                            <span style="font-weight: 700; font-size: 14px; color: {{ $user->behavioral_score < 20 ? 'var(--danger)' : ($user->behavioral_score < 50 ? 'var(--warning)' : 'var(--success)') }};">
                                {{ $user->behavioral_score }}
                            </span>
                            @if($user->is_high_risk)
                            <span class="badge badge-danger" style="margin-left: 4px;">HIGH RISK</span>
                            @endif
                        </td>
                        <td style="text-align: center;">
                            <span class="badge badge-danger">
                                {{ $user->fraudFlags->whereNull('resolved_at')->count() }} aktiv
                            </span>
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">
                            {{ $user->devices->where('event_type', 'register')->first()?->ip_address ?? '—' }}
                        </td>
                        <td style="text-align: center;">
                            @if($user->status === 'banned')
                            <span class="badge badge-danger">Banned</span>
                            @else
                            <span class="badge badge-success">Aktiv</span>
                            @endif
                        </td>
                        <td style="text-align: center;">
                            <div style="display: flex; align-items: center; justify-content: center; gap: 4px;">
                                <a href="{{ route('admin.fraud.user-detail', $user) }}" class="btn btn-primary btn-sm" style="padding: 4px 8px;">
                                    <i class="fa fa-eye"></i>
                                </a>
                                @if($user->status !== 'banned')
                                <form method="POST" action="{{ route('admin.fraud.ban', $user) }}" onsubmit="return confirm('Ban qilasizmi?')">
                                    @csrf
                                    <button type="submit" class="btn btn-danger btn-sm" style="padding: 4px 8px;">
                                        <i class="fa fa-ban"></i>
                                    </button>
                                </form>
                                @else
                                <form method="POST" action="{{ route('admin.fraud.unban', $user) }}">
                                    @csrf
                                    <button type="submit" class="btn btn-success btn-sm" style="padding: 4px 8px;">
                                        <i class="fa fa-unlock"></i>
                                    </button>
                                </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="fa fa-shield-halved" style="font-size: 28px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Fraud flagged foydalanuvchi topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($users->hasPages())
        <div class="pagination" style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $users->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
