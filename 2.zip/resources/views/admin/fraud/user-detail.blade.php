@extends('admin.layouts.app')
@section('title', 'Fraud — ' . $user->name)

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.fraud.index') }}">Fraud</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.fraud.users') }}">Foydalanuvchilar</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">{{ $user->name }}</span>
@endsection

@section('header-actions')
@if($user->status !== 'banned')
<form method="POST" action="{{ route('admin.fraud.ban', $user) }}" onsubmit="return confirm('Ban qilasizmi?')">
    @csrf
    <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-ban"></i> Ban</button>
</form>
@else
<form method="POST" action="{{ route('admin.fraud.unban', $user) }}">
    @csrf
    <button type="submit" class="btn btn-success btn-sm"><i class="fa fa-unlock"></i> Unban</button>
</form>
@endif
@endsection

@section('content')
{{-- Foydalanuvchi ma'lumotlari --}}
<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px;">
    <div class="admin-card">
        <div class="admin-card-body">
            <div style="display: flex; align-items: center; gap: 12px;">
                <img src="{{ $user->avatar_url }}" style="width: 48px; height: 48px; border-radius: 10px; object-fit: cover;">
                <div>
                    <div style="font-weight: 600; color: var(--text-primary);">{{ $user->name }}</div>
                    <div style="font-size: 12px; color: var(--text-muted);">{{ $user->email }}</div>
                    <div style="font-size: 12px; color: var(--text-muted);">{{ $user->username ?? '—' }}</div>
                </div>
            </div>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <div style="font-size: 32px; font-weight: 700; color: {{ $user->behavioral_score < 20 ? 'var(--danger)' : ($user->behavioral_score < 50 ? 'var(--warning)' : 'var(--success)') }};">
                {{ $user->behavioral_score }}
            </div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Behavioral Score</div>
            @if($user->is_high_risk)
            <span class="badge badge-danger" style="margin-top: 8px;">HIGH RISK</span>
            @endif
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <div style="font-size: 32px; font-weight: 700; color: {{ $user->status === 'banned' ? 'var(--danger)' : 'var(--success)' }};">
                {{ $user->status === 'banned' ? '🚫' : '✅' }}
            </div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">{{ ucfirst($user->status) }}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">KYC: {{ $user->kyc_status }}</div>
        </div>
    </div>
</div>

{{-- Tablar --}}
<div id="fraud-tabs">
    <div style="display: flex; gap: 4px; margin-bottom: 16px; border-bottom: 1px solid var(--border);">
        <button class="tab-btn active" data-tab="flags" style="padding: 8px 16px; font-size: 14px; font-weight: 500; border: none; background: none; cursor: pointer; border-bottom: 2px solid transparent; color: var(--text-muted);">
            🚩 Fraud Flaglar <span style="margin-left: 4px; font-size: 12px; opacity: 0.7;">({{ count($fraudFlags) }})</span>
        </button>
        <button class="tab-btn" data-tab="devices" style="padding: 8px 16px; font-size: 14px; font-weight: 500; border: none; background: none; cursor: pointer; border-bottom: 2px solid transparent; color: var(--text-muted);">
            📱 Qurilmalar <span style="margin-left: 4px; font-size: 12px; opacity: 0.7;">({{ count($devices) }})</span>
        </button>
        <button class="tab-btn" data-tab="score" style="padding: 8px 16px; font-size: 14px; font-weight: 500; border: none; background: none; cursor: pointer; border-bottom: 2px solid transparent; color: var(--text-muted);">
            📊 Score Logs <span style="margin-left: 4px; font-size: 12px; opacity: 0.7;">({{ count($scoreLogs) }})</span>
        </button>
        <button class="tab-btn" data-tab="related" style="padding: 8px 16px; font-size: 14px; font-weight: 500; border: none; background: none; cursor: pointer; border-bottom: 2px solid transparent; color: var(--text-muted);">
            👥 Bog'liq Akkauntlar <span style="margin-left: 4px; font-size: 12px; opacity: 0.7;">({{ count($relatedAccounts) }})</span>
        </button>
    </div>

    {{-- Fraud Flaglar --}}
    <div class="tab-content" id="tab-flags">
        <div class="admin-card">
            <div class="admin-card-body" style="padding: 0;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Sabab</th>
                            <th style="text-align: center;">Kim tomonidan</th>
                            <th style="text-align: center;">Sana</th>
                            <th style="text-align: center;">Holat</th>
                            <th style="text-align: center;">Amal</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($fraudFlags as $flag)
                        <tr>
                            <td style="color: var(--text-primary);">{{ $flag->reason }}</td>
                            <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $flag->flagged_by }}</td>
                            <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $flag->created_at->format('d.m.Y H:i') }}</td>
                            <td style="text-align: center;">
                                @if($flag->isResolved())
                                <span class="badge badge-success">Hal qilindi</span>
                                @else
                                <span class="badge badge-danger">Aktiv</span>
                                @endif
                            </td>
                            <td style="text-align: center;">
                                @if(!$flag->isResolved())
                                <form method="POST" action="{{ route('admin.fraud.flag.remove', [$user, $flag]) }}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-success btn-sm" style="padding: 4px 8px;">
                                        <i class="fa fa-check"></i> Hal qilish
                                    </button>
                                </form>
                                @endif
                            </td>
                        </tr>
                        @empty
                        <tr><td colspan="5" style="text-align: center; padding: 32px; color: var(--text-muted);">Flag yo'q</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    {{-- Qurilmalar --}}
    <div class="tab-content" id="tab-devices" style="display: none;">
        <div class="admin-card">
            <div class="admin-card-body" style="padding: 0;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>IP Manzil</th>
                            <th style="text-align: center;">Hodisa</th>
                            <th>User Agent</th>
                            <th style="text-align: center;">Sana</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($devices as $device)
                        <tr>
                            <td style="font-family: monospace; font-size: 12px; color: var(--text-primary);">{{ $device->ip_address }}</td>
                            <td style="text-align: center;">
                                <span class="badge {{ $device->event_type === 'register' ? 'badge-info' : 'badge-warning' }}">
                                    {{ $device->event_type }}
                                </span>
                            </td>
                            <td style="font-size: 12px; color: var(--text-muted); max-width: 250px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">{{ $device->user_agent }}</td>
                            <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $device->created_at->format('d.m.Y H:i') }}</td>
                        </tr>
                        @empty
                        <tr><td colspan="4" style="text-align: center; padding: 32px; color: var(--text-muted);">Qurilma ma'lumoti yo'q</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    {{-- Score Logs --}}
    <div class="tab-content" id="tab-score" style="display: none;">
        <div class="admin-card">
            <div class="admin-card-body" style="padding: 0;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Sabab</th>
                            <th style="text-align: center;">Delta</th>
                            <th style="text-align: center;">Score</th>
                            <th style="text-align: center;">Sana</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($scoreLogs as $log)
                        <tr>
                            <td style="color: var(--text-primary);">{{ $log->reason }}</td>
                            <td style="text-align: center; font-weight: 700; color: {{ $log->delta > 0 ? 'var(--success)' : 'var(--danger)' }};">
                                {{ $log->delta > 0 ? '+' : '' }}{{ $log->delta }}
                            </td>
                            <td style="text-align: center; font-weight: 600; color: var(--text-secondary);">{{ $log->score_after }}</td>
                            <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $log->created_at->format('d.m.Y H:i') }}</td>
                        </tr>
                        @empty
                        <tr><td colspan="4" style="text-align: center; padding: 32px; color: var(--text-muted);">Score log yo'q</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    {{-- Bog'liq akkauntlar --}}
    <div class="tab-content" id="tab-related" style="display: none;">
        <div class="admin-card">
            <div class="admin-card-body" style="padding: 0;">
                @if($relatedAccounts->isEmpty())
                <div style="padding: 40px; text-align: center; color: var(--text-muted);">
                    <i class="fa fa-users" style="font-size: 28px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                    Bir xil IP dan boshqa akkaunt topilmadi
                </div>
                @else
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>Foydalanuvchi</th>
                            <th style="text-align: center;">Holat</th>
                            <th style="text-align: center;">Amal</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($relatedAccounts as $related)
                        <tr>
                            <td>
                                <div style="display: flex; align-items: center; gap: 12px;">
                                    <img src="{{ $related->avatar_url }}" style="width: 32px; height: 32px; border-radius: 8px; object-fit: cover;">
                                    <div>
                                        <div style="font-weight: 500; color: var(--text-primary);">{{ $related->name }}</div>
                                        <div style="font-size: 12px; color: var(--text-muted);">{{ $related->email }}</div>
                                    </div>
                                </div>
                            </td>
                            <td style="text-align: center;">
                                <span class="badge {{ $related->status === 'banned' ? 'badge-danger' : 'badge-success' }}">
                                    {{ $related->status }}
                                </span>
                            </td>
                            <td style="text-align: center;">
                                <a href="{{ route('admin.fraud.user-detail', $related) }}" class="btn btn-primary btn-sm" style="padding: 4px 10px;">
                                    <i class="fa fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                @endif
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var tabBtns = document.querySelectorAll('.tab-btn');
    var tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            var target = this.getAttribute('data-tab');

            tabBtns.forEach(function(b) {
                b.classList.remove('active');
                b.style.borderBottomColor = 'transparent';
                b.style.color = 'var(--text-muted)';
            });

            tabContents.forEach(function(c) {
                c.style.display = 'none';
            });

            this.classList.add('active');
            this.style.borderBottomColor = 'var(--primary-light)';
            this.style.color = 'var(--primary-light)';
            document.getElementById('tab-' + target).style.display = 'block';
        });
    });

    // Activate first tab
    var firstBtn = document.querySelector('.tab-btn.active');
    if (firstBtn) {
        firstBtn.style.borderBottomColor = 'var(--primary-light)';
        firstBtn.style.color = 'var(--primary-light)';
    }
});
</script>
@endsection
