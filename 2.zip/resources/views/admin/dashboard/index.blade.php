@extends('admin.layouts.app')

@section('title', 'Dashboard')

@section('breadcrumb')
    <i class="fa fa-grid-2" style="color: var(--primary-light);"></i>
    <span class="current">Dashboard</span>
@endsection

@section('content')

{{-- Welcome --}}
<div style="margin-bottom: 20px;">
    <h1 style="font-size: 22px; font-weight: 700; color: var(--text-primary); letter-spacing: -.4px;">
        Salom, {{ auth()->user()->name }} 👋
    </h1>
    <p style="font-size: 13px; color: var(--text-muted); margin-top: 2px;">
        Platforma holati va statistikasi
    </p>
</div>

{{-- Urgent Actions --}}
@php
    $urgentItems = [];
    if(($stats['pending_deposits'] ?? 0) > 0) $urgentItems[] = ['label' => 'Kutilayotgan depozitlar', 'count' => $stats['pending_deposits'], 'route' => route('admin.deposits.index'), 'color' => 'var(--warning)'];
    if(($stats['pending_withdrawals'] ?? 0) > 0) $urgentItems[] = ['label' => 'Kutilayotgan yechishlar', 'count' => $stats['pending_withdrawals'], 'route' => route('admin.withdrawals.index'), 'color' => 'var(--danger)'];
    if(($stats['pending_kyc'] ?? 0) > 0) $urgentItems[] = ['label' => 'KYC so\'rovlari', 'count' => $stats['pending_kyc'], 'route' => route('admin.kyc.index'), 'color' => 'var(--info)'];
    if(($stats['pending_tasks'] ?? 0) > 0) $urgentItems[] = ['label' => 'Topshiriq tasdiqlash', 'count' => $stats['pending_tasks'], 'route' => route('admin.tasks.index'), 'color' => 'var(--primary)'];
@endphp

@if(count($urgentItems))
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 10px; margin-bottom: 20px;">
    @foreach($urgentItems as $item)
    <a href="{{ $item['route'] }}" style="display: flex; align-items: center; gap: 10px; padding: 12px 14px;
              background: {{ $item['color'] }}10; border: 1px solid {{ $item['color'] }}25; border-radius: 10px;
              text-decoration: none; transition: all .2s;"
       onmouseenter="this.style.transform='translateY(-1px)'" onmouseleave="this.style.transform='translateY(0)'">
        <div style="width: 32px; height: 32px; border-radius: 8px; background: {{ $item['color'] }}18;
                    display: flex; align-items: center; justify-content: center;">
            <span style="font-size: 14px; font-weight: 800; color: {{ $item['color'] }};">{{ $item['count'] }}</span>
        </div>
        <div>
            <div style="font-size: 12px; font-weight: 600; color: var(--text-primary);">{{ $item['label'] }}</div>
            <div style="font-size: 11px; color: var(--text-muted);">Ko'rish →</div>
        </div>
    </a>
    @endforeach
</div>
@endif

{{-- Main Stats --}}
<div class="stats-grid">
    <div class="admin-stat">
        <div class="admin-stat-icon" style="background: rgba(99,102,241,.1); color: #a5b4fc;">
            <i class="fa fa-users"></i>
        </div>
        <div class="admin-stat-value">{{ number_format($stats['total_users'] ?? 0) }}</div>
        <div class="admin-stat-label">Jami foydalanuvchilar</div>
    </div>
    <div class="admin-stat">
        <div class="admin-stat-icon" style="background: rgba(16,185,129,.1); color: #34d399;">
            <i class="fa fa-user-check"></i>
        </div>
        <div class="admin-stat-value">{{ number_format($stats['active_users'] ?? 0) }}</div>
        <div class="admin-stat-label">Faol foydalanuvchilar</div>
    </div>
    <div class="admin-stat">
        <div class="admin-stat-icon" style="background: rgba(245,158,11,.1); color: #fbbf24;">
            <i class="fa fa-user-plus"></i>
        </div>
        <div class="admin-stat-value">{{ $stats['new_users_today'] ?? 0 }}</div>
        <div class="admin-stat-label">Bugun yangi</div>
    </div>
    <div class="admin-stat">
        <div class="admin-stat-icon" style="background: rgba(6,182,212,.1); color: #22d3ee;">
            <i class="fa fa-calendar-week"></i>
        </div>
        <div class="admin-stat-value">{{ $stats['new_users_week'] ?? 0 }}</div>
        <div class="admin-stat-label">Haftalik yangi</div>
    </div>
</div>

{{-- Financial Stats --}}
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 14px; margin-bottom: 20px;">
    {{-- Deposits --}}
    <div class="admin-card">
        <div class="admin-card-header">
            <span class="admin-card-title"><i class="fa fa-arrow-down" style="color: var(--success); margin-right: 6px;"></i> Depozitlar</span>
            <a href="{{ route('admin.deposits.index') }}" style="font-size: 12px; color: var(--primary-light); text-decoration: none;">Barchasi →</a>
        </div>
        <div class="admin-card-body">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div>
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 2px;">Jami tasdiqlangan</div>
                    <div style="font-size: 18px; font-weight: 700; color: var(--success);">{{ number_format($stats['total_deposits_amount'] ?? 0, 0) }}</div>
                </div>
                <div>
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 2px;">Bugungi</div>
                    <div style="font-size: 18px; font-weight: 700; color: var(--text-primary);">{{ number_format($stats['today_deposits'] ?? 0, 0) }}</div>
                </div>
            </div>
        </div>
    </div>

    {{-- Withdrawals --}}
    <div class="admin-card">
        <div class="admin-card-header">
            <span class="admin-card-title"><i class="fa fa-arrow-up" style="color: var(--danger); margin-right: 6px;"></i> Yechib olish</span>
            <a href="{{ route('admin.withdrawals.index') }}" style="font-size: 12px; color: var(--primary-light); text-decoration: none;">Barchasi →</a>
        </div>
        <div class="admin-card-body">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div>
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 2px;">Jami tasdiqlangan</div>
                    <div style="font-size: 18px; font-weight: 700; color: var(--danger);">{{ number_format($stats['total_withdrawals_amount'] ?? 0, 0) }}</div>
                </div>
                <div>
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 2px;">Kutilayotgan</div>
                    <div style="font-size: 18px; font-weight: 700; color: var(--warning);">{{ $stats['pending_withdrawals'] ?? 0 }}</div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- AIS & Level Stats --}}
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 14px; margin-bottom: 20px;">
    {{-- AIS --}}
    <div class="admin-card">
        <div class="admin-card-header">
            <span class="admin-card-title"><i class="fa fa-coins" style="color: #fbbf24; margin-right: 6px;"></i> AIS Valyuta</span>
            <a href="{{ route('admin.ais.rate') }}" style="font-size: 12px; color: var(--primary-light); text-decoration: none;">Boshqarish →</a>
        </div>
        <div class="admin-card-body">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div>
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 2px;">Joriy kurs</div>
                    <div style="font-size: 18px; font-weight: 700; color: #fbbf24;">{{ number_format($stats['ais_rate'] ?? 0, 0) }} UZS</div>
                </div>
                <div>
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 2px;">Jami AIS</div>
                    <div style="font-size: 18px; font-weight: 700; color: var(--text-primary);">{{ number_format($stats['total_ais_supply'] ?? 0, 2) }}</div>
                </div>
                <div>
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 2px;">Bugungi transferlar</div>
                    <div style="font-size: 16px; font-weight: 600; color: var(--text-secondary);">{{ $stats['total_transfers_today'] ?? 0 }}</div>
                </div>
                <div>
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 2px;">Jami hajm</div>
                    <div style="font-size: 16px; font-weight: 600; color: var(--text-secondary);">{{ number_format($stats['total_transfers_volume'] ?? 0, 2) }}</div>
                </div>
            </div>
        </div>
    </div>

    {{-- Level --}}
    <div class="admin-card">
        <div class="admin-card-header">
            <span class="admin-card-title"><i class="fa fa-bolt" style="color: #a5b4fc; margin-right: 6px;"></i> Level tizimi</span>
            <a href="{{ route('admin.levels.index') }}" style="font-size: 12px; color: var(--primary-light); text-decoration: none;">Batafsil →</a>
        </div>
        <div class="admin-card-body">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                <div>
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 2px;">O'rtacha level</div>
                    <div style="font-size: 18px; font-weight: 700; color: var(--primary-light);">{{ $stats['avg_level'] ?? 0 }}</div>
                </div>
                <div>
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 2px;">Jami XP berilgan</div>
                    <div style="font-size: 18px; font-weight: 700; color: var(--text-primary);">{{ number_format($stats['total_xp_awarded'] ?? 0) }}</div>
                </div>
            </div>
            @if($stats['top_level_user'] ?? null)
            <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border); display: flex; align-items: center; gap: 8px;">
                <div style="width: 28px; height: 28px; border-radius: 6px; background: rgba(245,158,11,.1); display: flex; align-items: center; justify-content: center;">
                    <i class="fa fa-trophy" style="color: #fbbf24; font-size: 12px;"></i>
                </div>
                <div style="flex: 1;">
                    <div style="font-size: 12px; font-weight: 600; color: var(--text-primary);">{{ $stats['top_level_user']->user->name ?? 'N/A' }}</div>
                    <div style="font-size: 11px; color: var(--text-muted);">Level {{ $stats['top_level_user']->level }} — Top foydalanuvchi</div>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>

{{-- Module Stats --}}
<div class="stats-grid">
    <div class="admin-stat">
        <div class="admin-stat-icon" style="background: rgba(236,72,153,.1); color: #f472b6;">
            <i class="fa fa-cube"></i>
        </div>
        <div class="admin-stat-value">{{ $stats['active_purchases'] ?? 0 }}</div>
        <div class="admin-stat-label">Faol paketlar</div>
    </div>
    <div class="admin-stat">
        <div class="admin-stat-icon" style="background: rgba(168,85,247,.1); color: #c084fc;">
            <i class="fa fa-heart"></i>
        </div>
        <div class="admin-stat-value">{{ $stats['pending_crowdfunding'] ?? 0 }}</div>
        <div class="admin-stat-label">Crowdfunding (kutilmoqda)</div>
    </div>
    <div class="admin-stat">
        <div class="admin-stat-icon" style="background: rgba(14,165,233,.1); color: #38bdf8;">
            <i class="fa fa-graduation-cap"></i>
        </div>
        <div class="admin-stat-value">{{ $stats['total_courses'] ?? 0 }}</div>
        <div class="admin-stat-label">Kurslar</div>
    </div>
    <div class="admin-stat">
        <div class="admin-stat-icon" style="background: rgba(34,197,94,.1); color: #4ade80;">
            <i class="fa fa-stethoscope"></i>
        </div>
        <div class="admin-stat-value">{{ $stats['active_consultations'] ?? 0 }}</div>
        <div class="admin-stat-label">Faol konsultatsiyalar</div>
    </div>
</div>

@endsection
