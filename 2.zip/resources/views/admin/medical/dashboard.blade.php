@extends('admin.layouts.app')

@section('title', 'Tibbiyot — Dashboard')
@section('sidebar-title', 'Tibbiyot')

@section('breadcrumb')
    <li class="flex items-center space-x-2">
        <a href="{{ route('admin.dashboard') }}" class="text-primary transition-colors hover:text-primary-focus dark:text-accent-light dark:hover:text-accent">Admin</a>
        <svg xmlns="http://www.w3.org/2000/svg" class="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
    </li>
    <li>Tibbiyot xizmatlari</li>
@endsection

@section('content')
<div class="mt-4 space-y-4">
    {{-- Statistika kartalar --}}
    <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
        <div class="card p-4">
            <div class="flex items-center justify-between">
                <p class="text-xs+ text-slate-500 dark:text-navy-200">Jami shifokorlar</p>
                <i class="fa fa-user-doctor text-lg text-primary"></i>
            </div>
            <p class="mt-2 text-2xl font-semibold text-slate-700 dark:text-navy-100">{{ $stats['total_doctors'] }}</p>
            <p class="text-xs text-slate-400">Tasdiqlangan: {{ $stats['approved_doctors'] }}</p>
        </div>

        <div class="card p-4">
            <div class="flex items-center justify-between">
                <p class="text-xs+ text-slate-500 dark:text-navy-200">Kutilmoqda</p>
                <i class="fa fa-clock text-lg text-warning"></i>
            </div>
            <p class="mt-2 text-2xl font-semibold text-slate-700 dark:text-navy-100">{{ $stats['pending_doctors'] }}</p>
            <p class="text-xs text-slate-400">Tasdiqlash kerak</p>
        </div>

        <div class="card p-4">
            <div class="flex items-center justify-between">
                <p class="text-xs+ text-slate-500 dark:text-navy-200">Faol maslahatlar</p>
                <i class="fa fa-comments text-lg text-success"></i>
            </div>
            <p class="mt-2 text-2xl font-semibold text-slate-700 dark:text-navy-100">{{ $stats['active_consultations'] }}</p>
            <p class="text-xs text-slate-400">Bugun tugallangan: {{ $stats['completed_today'] }}</p>
        </div>

        <div class="card p-4">
            <div class="flex items-center justify-between">
                <p class="text-xs+ text-slate-500 dark:text-navy-200">Oylik daromad</p>
                <i class="fa fa-coins text-lg text-secondary"></i>
            </div>
            <p class="mt-2 text-2xl font-semibold text-slate-700 dark:text-navy-100">{{ number_format($stats['monthly_revenue'], 2) }}</p>
            <p class="text-xs text-slate-400">AIS (komissiya)</p>
        </div>

        <div class="card p-4">
            <div class="flex items-center justify-between">
                <p class="text-xs+ text-slate-500 dark:text-navy-200">Escrow muzlatilgan</p>
                <i class="fa fa-lock text-lg text-info"></i>
            </div>
            <p class="mt-2 text-2xl font-semibold text-slate-700 dark:text-navy-100">{{ number_format($stats['escrow_frozen'], 2) }}</p>
            <p class="text-xs text-slate-400">AIS</p>
        </div>
    </div>

    {{-- Tezkor havolalar --}}
    <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <a href="{{ route('admin.medical.doctors', ['status' => 'pending']) }}" class="card p-4 hover:bg-slate-100 dark:hover:bg-navy-600 transition-colors">
            <div class="flex items-center gap-3">
                <div class="flex size-10 items-center justify-center rounded-lg bg-warning/10 text-warning">
                    <i class="fa fa-user-clock"></i>
                </div>
                <div>
                    <p class="font-medium text-slate-700 dark:text-navy-100">Shifokor tasdiqlash</p>
                    <p class="text-xs text-slate-400">{{ $stats['pending_doctors'] }} ta kutmoqda</p>
                </div>
            </div>
        </a>

        <a href="{{ route('admin.medical.consultations') }}" class="card p-4 hover:bg-slate-100 dark:hover:bg-navy-600 transition-colors">
            <div class="flex items-center gap-3">
                <div class="flex size-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <i class="fa fa-stethoscope"></i>
                </div>
                <div>
                    <p class="font-medium text-slate-700 dark:text-navy-100">Maslahatlar</p>
                    <p class="text-xs text-slate-400">Barcha maslahatlar</p>
                </div>
            </div>
        </a>

        <a href="{{ route('admin.medical.medicine-orders') }}" class="card p-4 hover:bg-slate-100 dark:hover:bg-navy-600 transition-colors">
            <div class="flex items-center gap-3">
                <div class="flex size-10 items-center justify-center rounded-lg bg-success/10 text-success">
                    <i class="fa fa-pills"></i>
                </div>
                <div>
                    <p class="font-medium text-slate-700 dark:text-navy-100">Dori buyurtmalar</p>
                    <p class="text-xs text-slate-400">{{ $stats['pending_orders'] }} ta yangi</p>
                </div>
            </div>
        </a>

        <a href="{{ route('admin.medical.complaints') }}" class="card p-4 hover:bg-slate-100 dark:hover:bg-navy-600 transition-colors">
            <div class="flex items-center gap-3">
                <div class="flex size-10 items-center justify-center rounded-lg bg-error/10 text-error">
                    <i class="fa fa-flag"></i>
                </div>
                <div>
                    <p class="font-medium text-slate-700 dark:text-navy-100">Shikoyatlar</p>
                    <p class="text-xs text-slate-400">{{ $stats['pending_complaints'] }} ta kutmoqda</p>
                </div>
            </div>
        </a>

        <a href="{{ route('admin.medical.financial-report') }}" class="card p-4 hover:bg-slate-100 dark:hover:bg-navy-600 transition-colors">
            <div class="flex items-center gap-3">
                <div class="flex size-10 items-center justify-center rounded-lg bg-secondary/10 text-secondary">
                    <i class="fa fa-chart-line"></i>
                </div>
                <div>
                    <p class="font-medium text-slate-700 dark:text-navy-100">Moliyaviy hisobot</p>
                    <p class="text-xs text-slate-400">Daromad va xarajat</p>
                </div>
            </div>
        </a>
    </div>
</div>
@endsection
