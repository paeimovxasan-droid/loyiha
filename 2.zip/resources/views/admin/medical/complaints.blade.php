@extends('admin.layouts.app')
@section('title', 'Shikoyatlar')

@section('breadcrumb')
    <a href="{{ route('admin.medical.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Shikoyatlar</span>
@endsection

@section('header-actions')
    <form action="{{ route('admin.medical.complaints') }}" method="GET" style="display: inline-flex;">
        <select name="status" onchange="this.form.submit()" class="form-control" style="width: auto; font-size: 13px;">
            <option value="">Barchasi</option>
            <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Kutilmoqda</option>
            <option value="reviewed" {{ request('status') === 'reviewed' ? 'selected' : '' }}>Ko'rib chiqilgan</option>
            <option value="resolved" {{ request('status') === 'resolved' ? 'selected' : '' }}>Hal qilingan</option>
        </select>
    </form>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">Tibbiy shikoyatlar</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Bemor</th>
                        <th>Shifokor</th>
                        <th>Tur</th>
                        <th>Xabar</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Amal</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($complaints as $complaint)
                    <tr>
                        <td style="color: var(--text-primary);">{{ $complaint->patient->name ?? '—' }}</td>
                        <td style="color: var(--text-secondary);">{{ $complaint->doctor->name ?? '—' }}</td>
                        <td>
                            @switch($complaint->type)
                                @case('wrong_advice') <span style="font-size: 12px; color: var(--danger);">Noto'g'ri maslahat</span> @break
                                @case('rude_behavior') <span style="font-size: 12px; color: var(--warning);">Qo'pol munosabat</span> @break
                                @case('no_response') <span style="font-size: 12px; color: var(--text-muted);">Javob bermadi</span> @break
                                @case('other') <span style="font-size: 12px; color: var(--info);">Boshqa</span> @break
                            @endswitch
                        </td>
                        <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px; color: var(--text-secondary);">{{ $complaint->message }}</td>
                        <td style="text-align: center;">
                            @if($complaint->status === 'pending')
                                <span class="badge badge-warning">Kutilmoqda</span>
                            @elseif($complaint->status === 'reviewed')
                                @if($complaint->is_justified)
                                    <span class="badge badge-danger">Asosli</span>
                                @else
                                    <span class="badge badge-success">Asossiz</span>
                                @endif
                            @endif
                        </td>
                        <td style="text-align: center;">
                            @if($complaint->status === 'pending')
                            <div style="position: relative; display: inline-block;">
                                <button type="button" class="btn btn-outline btn-sm" onclick="toggleReviewForm({{ $complaint->id }})">
                                    <i class="fa fa-gavel"></i>
                                </button>
                                <div id="review-form-{{ $complaint->id }}" style="display: none; position: absolute; right: 0; top: 36px; z-index: 10; width: 280px; border-radius: 8px; background: var(--bg-card); padding: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); border: 1px solid var(--border);">
                                    <form method="POST" action="{{ route('admin.medical.complaints.review', $complaint) }}">
                                        @csrf
                                        <p style="font-size: 13px; font-weight: 500; margin-bottom: 8px; color: var(--text-primary);">Shikoyatni ko'rib chiqish</p>
                                        <div style="display: flex; gap: 12px; margin-bottom: 8px;">
                                            <label style="display: flex; align-items: center; gap: 4px; cursor: pointer;">
                                                <input type="radio" name="is_justified" value="1" required>
                                                <span style="font-size: 12px; color: var(--danger);">Asosli</span>
                                            </label>
                                            <label style="display: flex; align-items: center; gap: 4px; cursor: pointer;">
                                                <input type="radio" name="is_justified" value="0" required>
                                                <span style="font-size: 12px; color: var(--success);">Asossiz</span>
                                            </label>
                                        </div>
                                        <textarea name="admin_response" placeholder="Izoh (ixtiyoriy)..." class="form-control" style="font-size: 12px; margin-bottom: 8px;" rows="2"></textarea>
                                        <button type="submit" class="btn btn-primary btn-sm" style="width: 100%;">Saqlash</button>
                                    </form>
                                </div>
                            </div>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">Shikoyatlar topilmadi</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 12px 16px;">{{ $complaints->withQueryString()->links() }}</div>
    </div>
</div>

<script>
function toggleReviewForm(id) {
    var form = document.getElementById('review-form-' + id);
    if (form.style.display === 'none') {
        // Close all other forms first
        document.querySelectorAll('[id^="review-form-"]').forEach(function(el) {
            el.style.display = 'none';
        });
        form.style.display = 'block';
    } else {
        form.style.display = 'none';
    }
}

// Close forms when clicking outside
document.addEventListener('click', function(e) {
    if (!e.target.closest('[id^="review-form-"]') && !e.target.closest('[onclick^="toggleReviewForm"]')) {
        document.querySelectorAll('[id^="review-form-"]').forEach(function(el) {
            el.style.display = 'none';
        });
    }
});
</script>
@endsection
