@extends('admin.layouts.app')

@section('title', 'Tibbiyot sozlamalari')
@section('sidebar-title', 'Tibbiyot')

@section('breadcrumb')
    <li class="flex items-center space-x-2">
        <a href="{{ route('admin.medical.dashboard') }}" class="text-primary transition-colors hover:text-primary-focus dark:text-accent-light dark:hover:text-accent">Tibbiyot</a>
        <svg xmlns="http://www.w3.org/2000/svg" class="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
    </li>
    <li>Sozlamalar</li>
@endsection

@section('content')
<div class="mt-4">
    <h2 class="text-base font-medium tracking-wide text-slate-700 dark:text-navy-100 mb-4">Tibbiyot moduli sozlamalari</h2>

    <form method="POST" action="{{ route('admin.medical.settings.update') }}">
        @csrf @method('PUT')

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            {{-- Moliyaviy sozlamalar --}}
            <div class="card p-4 sm:p-5">
                <h3 class="font-medium text-slate-700 dark:text-navy-100 border-b border-slate-200 dark:border-navy-500 pb-3 mb-4">💰 Moliyaviy</h3>
                <div class="space-y-4">
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Komissiya foizi (%)</label>
                        <input type="number" name="commission_percent" value="{{ $settings['commission_percent'] ?? 20 }}" step="0.01" min="0" max="50"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                        <p class="text-xs text-slate-400 mt-1">Har maslahatdan platforma oladigan foiz</p>
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Dori yetkazish narxi (AIS)</label>
                        <input type="number" name="delivery_fee" value="{{ $settings['delivery_fee'] ?? 5 }}" step="0.01" min="0"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Platforma ustamasi (AIS)</label>
                        <input type="number" name="platform_fee" value="{{ $settings['platform_fee'] ?? 2 }}" step="0.01" min="0"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Min maslahat narxi (AIS)</label>
                        <input type="number" name="min_consultation_price" value="{{ $settings['min_consultation_price'] ?? 5 }}" min="1"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Max maslahat narxi (AIS)</label>
                        <input type="number" name="max_consultation_price" value="{{ $settings['max_consultation_price'] ?? 500 }}" min="10"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                    </div>
                </div>
            </div>

            {{-- Vaqt sozlamalari --}}
            <div class="card p-4 sm:p-5">
                <h3 class="font-medium text-slate-700 dark:text-navy-100 border-b border-slate-200 dark:border-navy-500 pb-3 mb-4">⏰ Vaqt</h3>
                <div class="space-y-4">
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Maslahat muddati (soat)</label>
                        <input type="number" name="escrow_timeout_hours" value="{{ $settings['escrow_timeout_hours'] ?? 24 }}" min="1" max="72"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                        <p class="text-xs text-slate-400 mt-1">Shifokor javob bermasa pul qaytariladi</p>
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Uyga chaqirish muddati (soat)</label>
                        <input type="number" name="home_visit_timeout_hours" value="{{ $settings['home_visit_timeout_hours'] ?? 2 }}" min="1" max="12"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Faoliyatsizlik muddati (kun)</label>
                        <input type="number" name="inactivity_days" value="{{ $settings['inactivity_days'] ?? 30 }}" min="7" max="90"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                        <p class="text-xs text-slate-400 mt-1">Shu kundan keyin shifokor nofaol bo'ladi</p>
                    </div>
                </div>
            </div>

            {{-- Sifat nazorati --}}
            <div class="card p-4 sm:p-5">
                <h3 class="font-medium text-slate-700 dark:text-navy-100 border-b border-slate-200 dark:border-navy-500 pb-3 mb-4">🛡️ Sifat nazorati</h3>
                <div class="space-y-4">
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Avtomatik suspend — shikoyatlar soni</label>
                        <input type="number" name="auto_suspend_complaints" value="{{ $settings['auto_suspend_complaints'] ?? 3 }}" min="1" max="10"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Avtomatik suspend — reyting chegarasi</label>
                        <input type="number" name="auto_suspend_rating" value="{{ $settings['auto_suspend_rating'] ?? '2.0' }}" step="0.1" min="1" max="3"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Avtomatik suspend — muddati o'tganlar</label>
                        <input type="number" name="auto_suspend_expired" value="{{ $settings['auto_suspend_expired'] ?? 5 }}" min="2" max="20"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                        <p class="text-xs text-slate-400 mt-1">Ketma-ket shu miqdor expire bo'lsa</p>
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Ogohlantirish reyting chegarasi</label>
                        <input type="number" name="warning_rating" value="{{ $settings['warning_rating'] ?? '3.0' }}" step="0.1" min="2" max="4"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                    </div>
                </div>
            </div>

            {{-- XP sozlamalari --}}
            <div class="card p-4 sm:p-5">
                <h3 class="font-medium text-slate-700 dark:text-navy-100 border-b border-slate-200 dark:border-navy-500 pb-3 mb-4">⭐ XP (Gamifikatsiya)</h3>
                <div class="space-y-4">
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Maslahat olish (bemor) XP</label>
                        <input type="number" name="xp_consultation_patient" value="{{ $settings['xp_consultation_patient'] ?? 30 }}" min="0" max="200"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Maslahat berish (shifokor) XP</label>
                        <input type="number" name="xp_consultation_doctor" value="{{ $settings['xp_consultation_doctor'] ?? 50 }}" min="0" max="200"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                    </div>
                    <div>
                        <label class="text-xs font-medium text-slate-600 dark:text-navy-200">Sharh qoldirish XP</label>
                        <input type="number" name="xp_review" value="{{ $settings['xp_review'] ?? 10 }}" min="0" max="100"
                               class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
                    </div>
                </div>
            </div>
        </div>

        <div class="mt-4">
            <button type="submit" class="btn bg-primary font-medium text-white hover:bg-primary-focus px-6 py-2.5 rounded-lg">
                <i class="fa fa-save mr-2"></i> Saqlash
            </button>
        </div>
    </form>
</div>
@endsection
