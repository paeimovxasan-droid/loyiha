@extends('admin.layouts.app')
@section('title', 'Maslahat #' . $consultation->id)

@section('breadcrumb')
    <a href="{{ route('admin.medical.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.medical.consultations') }}">Maslahatlar</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">#{{ $consultation->id }}</span>
@endsection

@section('content')
<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
    {{-- Asosiy ma'lumot --}}
    <div style="display: flex; flex-direction: column; gap: 20px;">
        <div class="admin-card">
            <div class="admin-card-header" style="display: flex; align-items: center; justify-content: space-between;">
                <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">Maslahat tafsilotlari</h3>
                @switch($consultation->status)
                    @case('pending') <span class="badge badge-warning">Kutilmoqda</span> @break
                    @case('active') <span class="badge badge-info">Faol</span> @break
                    @case('completed') <span class="badge badge-success">Tugallangan</span> @break
                    @case('cancelled') <span class="badge badge-info">Bekor</span> @break
                    @case('expired') <span class="badge badge-danger">Muddati o'tgan</span> @break
                @endswitch
            </div>
            <div class="admin-card-body">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div>
                        <span style="font-size: 12px; color: var(--text-muted);">Bemor</span>
                        <p style="font-weight: 500; color: var(--text-primary);">{{ $consultation->patient->name }}</p>
                    </div>
                    <div>
                        <span style="font-size: 12px; color: var(--text-muted);">Shifokor</span>
                        <p style="font-weight: 500; color: var(--text-primary);">{{ $consultation->doctor->name }}</p>
                        <p style="font-size: 12px; color: var(--text-muted);">{{ ucfirst($consultation->doctorProfile->specialty) }}</p>
                    </div>
                    <div>
                        <span style="font-size: 12px; color: var(--text-muted);">Narx</span>
                        <p style="font-weight: 700; color: var(--text-primary);">{{ number_format($consultation->price, 2) }} AIS</p>
                    </div>
                    <div>
                        <span style="font-size: 12px; color: var(--text-muted);">Komissiya</span>
                        <p style="font-weight: 500;">{{ $consultation->commission_rate }}% = {{ number_format($consultation->commission_amount, 2) }} AIS</p>
                    </div>
                    <div>
                        <span style="font-size: 12px; color: var(--text-muted);">Shifokor daromadi</span>
                        <p style="font-weight: 500; color: var(--success);">{{ number_format($consultation->doctor_earning, 2) }} AIS</p>
                    </div>
                    <div>
                        <span style="font-size: 12px; color: var(--text-muted);">Yaratilgan</span>
                        <p style="font-weight: 500;">{{ $consultation->created_at->format('d.m.Y H:i') }}</p>
                    </div>
                </div>
            </div>
        </div>

        {{-- Chat tarixi --}}
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">Chat tarixi ({{ $consultation->messages->count() }} xabar)</h3>
            </div>
            <div class="admin-card-body">
                <div style="max-height: 384px; overflow-y: auto; display: flex; flex-direction: column; gap: 12px;">
                    @forelse($consultation->messages->sortBy('created_at') as $msg)
                    <div style="display: flex; gap: 10px; {{ $msg->sender_id === $consultation->doctor_id ? 'flex-direction: row-reverse;' : '' }}">
                        <div style="width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; font-weight: 700; flex-shrink: 0; {{ $msg->sender_id === $consultation->doctor_id ? 'background: var(--primary-light); color: var(--text-primary);' : 'background: rgba(var(--success-rgb), 0.1); color: var(--success);' }}">
                            {{ mb_substr($msg->sender->name ?? '?', 0, 1) }}
                        </div>
                        <div style="max-width: 70%; padding: 10px 14px; border-radius: 12px; font-size: 13px; {{ $msg->sender_id === $consultation->doctor_id ? 'background: var(--primary-light);' : 'background: var(--bg-card); border: 1px solid var(--border);' }}">
                            <p style="color: var(--text-primary);">{{ $msg->message }}</p>
                            <p style="font-size: 11px; color: var(--text-muted); margin-top: 4px;">{{ $msg->created_at->format('H:i') }}</p>
                        </div>
                    </div>
                    @empty
                    <p style="text-align: center; color: var(--text-muted); padding: 16px;">Xabarlar yo'q</p>
                    @endforelse
                </div>
            </div>
        </div>

        {{-- Retseptlar --}}
        @if($consultation->prescriptions->count())
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">Retseptlar</h3>
            </div>
            <div class="admin-card-body">
                @foreach($consultation->prescriptions as $prescription)
                <div style="margin-bottom: 16px; padding: 12px; border-radius: 8px; background: var(--primary-light); border: 1px solid var(--border);">
                    <p style="font-size: 12px; color: var(--text-muted); margin-bottom: 8px;">Retsept #{{ $prescription->id }} — {{ $prescription->created_at->format('d.m.Y') }}</p>
                    <table class="admin-table">
                        <thead>
                            <tr>
                                <th>Dori</th>
                                <th>Doza</th>
                                <th>Tartib</th>
                                <th>Muddat</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($prescription->items as $item)
                            <tr>
                                <td style="font-weight: 500;">{{ $item->medicine_name }}</td>
                                <td>{{ $item->dosage }}</td>
                                <td>{{ $item->frequency }}</td>
                                <td>{{ $item->duration }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    @if($prescription->notes)
                    <p style="font-size: 12px; color: var(--text-secondary); margin-top: 8px;"><strong>Izoh:</strong> {{ $prescription->notes }}</p>
                    @endif
                </div>
                @endforeach
            </div>
        </div>
        @endif

        {{-- Yo'llanmalar --}}
        @if($consultation->referrals->count())
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">Analiz yo'llanmalar</h3>
            </div>
            <div class="admin-card-body">
                @foreach($consultation->referrals as $referral)
                <div style="margin-bottom: 12px; padding: 12px; border-radius: 8px; background: var(--primary-light); border: 1px solid var(--border);">
                    <p style="font-weight: 500; color: var(--text-primary);">{{ $referral->analysis_type }}</p>
                    @if($referral->laboratory)<p style="font-size: 12px; color: var(--text-muted);">Laboratoriya: {{ $referral->laboratory }}</p>@endif
                    @if($referral->instructions)<p style="font-size: 12px; color: var(--text-secondary); margin-top: 4px;">{{ $referral->instructions }}</p>@endif
                </div>
                @endforeach
            </div>
        </div>
        @endif
    </div>

    {{-- Yon panel --}}
    <div style="display: flex; flex-direction: column; gap: 20px;">
        {{-- Sharh --}}
        @if($consultation->review)
        <div class="admin-card">
            <div class="admin-card-header">
                <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">Bemor sharhi</h3>
            </div>
            <div class="admin-card-body">
                <div style="display: flex; align-items: center; gap: 4px; margin-bottom: 8px;">
                    @for($i = 1; $i <= 5; $i++)
                        <i class="fa fa-star" style="color: {{ $i <= $consultation->review->rating ? 'var(--warning)' : 'var(--border)' }};"></i>
                    @endfor
                </div>
                @if($consultation->review->comment)
                <p style="font-size: 13px; color: var(--text-secondary);">{{ $consultation->review->comment }}</p>
                @endif
            </div>
        </div>
        @endif

        {{-- Shikoyat --}}
        @if($consultation->complaint)
        <div class="admin-card" style="border-left: 4px solid var(--danger);">
            <div class="admin-card-header">
                <h3 style="font-size: 14px; font-weight: 600; color: var(--danger);">Shikoyat</h3>
            </div>
            <div class="admin-card-body">
                <p style="font-size: 12px; color: var(--text-muted); margin-bottom: 4px;">Tur: {{ $consultation->complaint->type }}</p>
                <p style="font-size: 13px; color: var(--text-secondary);">{{ $consultation->complaint->message }}</p>
                @if($consultation->complaint->admin_response)
                <div style="margin-top: 8px; padding: 8px; border-radius: 6px; background: var(--primary-light);">
                    <p style="font-size: 12px; color: var(--text-muted);">Admin javobi:</p>
                    <p style="font-size: 13px; color: var(--text-primary);">{{ $consultation->complaint->admin_response }}</p>
                </div>
                @endif
            </div>
        </div>
        @endif
    </div>
</div>
@endsection
