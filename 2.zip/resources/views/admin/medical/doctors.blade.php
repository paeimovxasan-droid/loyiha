@extends('admin.layouts.app')
@section('title', 'Shifokorlar')

@section('breadcrumb')
    <a href="{{ route('admin.medical.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Shifokorlar</span>
@endsection

@section('header-actions')
    <form action="{{ route('admin.medical.doctors') }}" method="GET" style="display: inline-flex;">
        <select name="status" onchange="this.form.submit()" class="form-control" style="width: auto; font-size: 13px;">
            <option value="">Barchasi</option>
            <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Kutilmoqda</option>
            <option value="approved" {{ request('status') === 'approved' ? 'selected' : '' }}>Tasdiqlangan</option>
            <option value="rejected" {{ request('status') === 'rejected' ? 'selected' : '' }}>Rad etilgan</option>
            <option value="suspended" {{ request('status') === 'suspended' ? 'selected' : '' }}>To'xtatilgan</option>
        </select>
    </form>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">Shifokor profillar</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Shifokor</th>
                        <th>Ixtisoslik</th>
                        <th style="text-align: center;">Narx (AIS)</th>
                        <th style="text-align: center;">Reyting</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($doctors as $doctor)
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <div style="width: 40px; height: 40px; border-radius: 50%; background: var(--primary-light); display: flex; align-items: center; justify-content: center; font-weight: 700; color: var(--text-primary);">
                                    {{ mb_substr($doctor->user->name ?? '?', 0, 1) }}
                                </div>
                                <div>
                                    <p style="font-weight: 500; color: var(--text-primary);">{{ $doctor->user->name ?? 'Noma\'lum' }}</p>
                                    <p style="font-size: 12px; color: var(--text-muted);">{{ $doctor->user->phone ?? '' }}</p>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge badge-info">{{ ucfirst($doctor->specialty) }}</span>
                        </td>
                        <td style="text-align: center; font-weight: 500;">{{ number_format($doctor->consultation_price, 0) }}</td>
                        <td style="text-align: center;">
                            <div style="display: flex; align-items: center; justify-content: center; gap: 4px;">
                                <i class="fa fa-star" style="font-size: 12px; color: var(--warning);"></i>
                                <span>{{ $doctor->rating }}</span>
                                <span style="font-size: 12px; color: var(--text-muted);">({{ $doctor->reviews_count }})</span>
                            </div>
                        </td>
                        <td style="text-align: center;">
                            @if($doctor->status === 'pending')
                                <span class="badge badge-warning">Kutilmoqda</span>
                            @elseif($doctor->status === 'approved')
                                <span class="badge badge-success">Tasdiqlangan</span>
                            @elseif($doctor->status === 'rejected')
                                <span class="badge badge-danger">Rad etilgan</span>
                            @elseif($doctor->status === 'suspended')
                                <span class="badge badge-info">To'xtatilgan</span>
                            @endif
                        </td>
                        <td style="text-align: center;">
                            <div style="display: flex; align-items: center; justify-content: center; gap: 6px;">
                                <a href="{{ route('admin.medical.doctors.show', $doctor) }}" class="btn btn-outline btn-sm">
                                    <i class="fa fa-eye"></i>
                                </a>
                                @if($doctor->status === 'pending')
                                <form method="POST" action="{{ route('admin.medical.doctors.approve', $doctor) }}" style="display: inline;">
                                    @csrf
                                    <button type="submit" class="btn btn-success btn-sm">
                                        <i class="fa fa-check"></i>
                                    </button>
                                </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                            <i class="fa fa-user-doctor" style="font-size: 24px; margin-bottom: 8px; display: block; opacity: 0.3;"></i>
                            <p>Shifokorlar topilmadi</p>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 12px 16px;">
            {{ $doctors->withQueryString()->links() }}
        </div>
    </div>
</div>
@endsection
