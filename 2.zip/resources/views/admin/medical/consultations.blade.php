@extends('admin.layouts.app')
@section('title', 'Maslahatlar')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.medical.dashboard') }}">Tibbiyot</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Maslahatlar</span>
@endsection

@section('header-actions')
    <form action="{{ route('admin.medical.consultations') }}" method="GET" style="display: inline-flex;">
        <select name="status" onchange="this.form.submit()" class="form-control" style="font-size: 12px; padding: 6px 12px; min-width: 140px;">
            <option value="">Barchasi</option>
            <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Kutilmoqda</option>
            <option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>Faol</option>
            <option value="completed" {{ request('status') === 'completed' ? 'selected' : '' }}>Tugallangan</option>
            <option value="cancelled" {{ request('status') === 'cancelled' ? 'selected' : '' }}>Bekor qilingan</option>
            <option value="expired" {{ request('status') === 'expired' ? 'selected' : '' }}>Muddati o'tgan</option>
        </select>
    </form>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">Barcha maslahatlar</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Bemor</th>
                        <th>Shifokor</th>
                        <th>Narx</th>
                        <th>Holat</th>
                        <th>Sana</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($consultations as $c)
                    <tr>
                        <td style="font-weight: 500; color: var(--text-primary);">#{{ $c->id }}</td>
                        <td style="color: var(--text-primary);">{{ $c->patient->name ?? '—' }}</td>
                        <td>
                            <span style="color: var(--text-primary);">{{ $c->doctor->name ?? '—' }}</span>
                            @if($c->doctorProfile->specialty ?? null)
                                <br><span style="font-size: 11px; color: var(--text-muted);">{{ $c->doctorProfile->specialty }}</span>
                            @endif
                        </td>
                        <td style="font-weight: 600; color: var(--text-primary);">{{ number_format($c->price, 0) }} AIS</td>
                        <td>
                            @switch($c->status)
                                @case('pending') <span class="badge badge-warning">Kutilmoqda</span> @break
                                @case('active') <span class="badge badge-info">Faol</span> @break
                                @case('completed') <span class="badge badge-success">Tugallangan</span> @break
                                @case('cancelled') <span class="badge badge-secondary">Bekor</span> @break
                                @case('expired') <span class="badge badge-danger">Muddati o'tgan</span> @break
                            @endswitch
                        </td>
                        <td style="font-size: 12px; color: var(--text-muted);">{{ $c->created_at->format('d.m.Y H:i') }}</td>
                        <td>
                            <a href="{{ route('admin.medical.consultations.show', $c) }}" class="btn btn-outline btn-sm" title="Ko'rish">
                                <i class="fa fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 32px 16px; color: var(--text-muted);">
                            Maslahatlar topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $consultations->withQueryString()->links() }}
        </div>
    </div>
</div>
@endsection
