@extends('admin.layouts.app')
@section('title', 'Dori buyurtmalar')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.medical.dashboard') }}">Tibbiyot</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Dori buyurtmalar</span>
@endsection

@section('header-actions')
    <form action="{{ route('admin.medical.medicine-orders') }}" method="GET" style="display: inline-flex;">
        <select name="status" onchange="this.form.submit()" class="form-control" style="font-size: 12px; padding: 6px 12px; min-width: 140px;">
            <option value="">Barchasi</option>
            <option value="new" {{ request('status') === 'new' ? 'selected' : '' }}>Yangi</option>
            <option value="processing" {{ request('status') === 'processing' ? 'selected' : '' }}>Jarayonda</option>
            <option value="delivering" {{ request('status') === 'delivering' ? 'selected' : '' }}>Yetkazilmoqda</option>
            <option value="delivered" {{ request('status') === 'delivered' ? 'selected' : '' }}>Yetkazildi</option>
            <option value="cancelled" {{ request('status') === 'cancelled' ? 'selected' : '' }}>Bekor</option>
        </select>
    </form>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">Dori buyurtmalar</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Bemor</th>
                        <th>Dorilar</th>
                        <th>Jami (AIS)</th>
                        <th>Holat</th>
                        <th>Sana</th>
                        <th>Amal</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($orders as $order)
                    <tr>
                        <td style="font-weight: 500; color: var(--text-primary);">#{{ $order->id }}</td>
                        <td style="color: var(--text-primary);">{{ $order->patient->name ?? '—' }}</td>
                        <td style="font-size: 12px; color: var(--text-muted);">{{ $order->items->count() }} ta dori</td>
                        <td style="font-weight: 600; color: var(--text-primary);">{{ number_format($order->total_amount, 0) }}</td>
                        <td>
                            @switch($order->status)
                                @case('new') <span class="badge badge-warning">Yangi</span> @break
                                @case('processing') <span class="badge badge-info">Jarayonda</span> @break
                                @case('delivering') <span class="badge badge-primary">Yetkazilmoqda</span> @break
                                @case('delivered') <span class="badge badge-success">Yetkazildi</span> @break
                                @case('cancelled') <span class="badge badge-danger">Bekor</span> @break
                            @endswitch
                        </td>
                        <td style="font-size: 12px; color: var(--text-muted);">{{ $order->created_at->format('d.m.Y H:i') }}</td>
                        <td>
                            @if(!in_array($order->status, ['delivered', 'cancelled']))
                            <form method="POST" action="{{ route('admin.medical.medicine-orders.status', $order) }}" style="display: inline-flex;">
                                @csrf
                                <select name="status" onchange="this.form.submit()" class="form-control" style="font-size: 11px; padding: 4px 8px; min-width: 120px;">
                                    <option value="">Yangilash...</option>
                                    @if($order->status === 'new')<option value="processing">Jarayonda</option>@endif
                                    @if(in_array($order->status, ['new', 'processing']))<option value="delivering">Yetkazilmoqda</option>@endif
                                    @if($order->status === 'delivering')<option value="delivered">Yetkazildi</option>@endif
                                    <option value="cancelled">Bekor qilish</option>
                                </select>
                            </form>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 32px 16px; color: var(--text-muted);">
                            Buyurtmalar topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $orders->withQueryString()->links() }}
        </div>
    </div>
</div>
@endsection
