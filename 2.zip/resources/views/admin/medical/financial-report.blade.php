@extends('admin.layouts.app')

@section('title', 'Moliyaviy hisobot — Tibbiyot')
@section('sidebar-title', 'Tibbiyot')

@section('breadcrumb')
    <li class="flex items-center space-x-2">
        <a href="{{ route('admin.medical.dashboard') }}" class="text-primary transition-colors hover:text-primary-focus dark:text-accent-light dark:hover:text-accent">Tibbiyot</a>
        <svg xmlns="http://www.w3.org/2000/svg" class="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
    </li>
    <li>Moliyaviy hisobot</li>
@endsection

@section('content')
<div class="mt-4 space-y-4">
    {{-- Sana filtri --}}
    <div class="card p-4">
        <form action="{{ route('admin.medical.financial-report') }}" method="GET" class="flex flex-wrap items-end gap-3">
            <div>
                <label class="text-xs text-slate-500">Boshlanish</label>
                <input type="date" name="from" value="{{ $from }}" class="form-input mt-1 rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
            </div>
            <div>
                <label class="text-xs text-slate-500">Tugash</label>
                <input type="date" name="to" value="{{ $to }}" class="form-input mt-1 rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450">
            </div>
            <button type="submit" class="btn bg-primary text-white px-4 py-2 rounded-lg text-sm">
                <i class="fa fa-filter mr-1"></i> Filtrlash
            </button>
        </form>
    </div>

    {{-- Statistika --}}
    <div class="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <div class="card p-4">
            <p class="text-xs text-slate-500 dark:text-navy-200">Platforma daromadi</p>
            <p class="mt-2 text-xl font-bold text-success">{{ number_format($stats['total_revenue'], 2) }} AIS</p>
            <p class="text-xs text-slate-400">Komissiya</p>
        </div>
        <div class="card p-4">
            <p class="text-xs text-slate-500 dark:text-navy-200">Shifokorlarga to'langan</p>
            <p class="mt-2 text-xl font-bold text-primary dark:text-accent-light">{{ number_format($stats['total_paid_doctors'], 2) }} AIS</p>
        </div>
        <div class="card p-4">
            <p class="text-xs text-slate-500 dark:text-navy-200">Qaytarilgan</p>
            <p class="mt-2 text-xl font-bold text-error">{{ number_format($stats['refunded'], 2) }} AIS</p>
            <p class="text-xs text-slate-400">Bekor/Expired</p>
        </div>
        <div class="card p-4">
            <p class="text-xs text-slate-500 dark:text-navy-200">Dori yetkazish daromadi</p>
            <p class="mt-2 text-xl font-bold text-warning">{{ number_format($stats['medicine_revenue'], 2) }} AIS</p>
            <p class="text-xs text-slate-400">Platforma ustamasi</p>
        </div>
        <div class="card p-4">
            <p class="text-xs text-slate-500 dark:text-navy-200">Escrow muzlatilgan</p>
            <p class="mt-2 text-xl font-bold text-info">{{ number_format($stats['escrow_frozen'], 2) }} AIS</p>
            <p class="text-xs text-slate-400">Hozirgi holat</p>
        </div>
    </div>

    {{-- Top shifokorlar --}}
    <div class="card p-4 sm:p-5">
        <h3 class="font-medium text-slate-700 dark:text-navy-100 border-b border-slate-200 dark:border-navy-500 pb-3 mb-4">Top 10 shifokor (reyting bo'yicha)</h3>
        <div class="is-scrollbar-hidden overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead>
                    <tr class="text-xs text-slate-500 uppercase">
                        <th class="pb-2">#</th>
                        <th class="pb-2">Shifokor</th>
                        <th class="pb-2">Ixtisoslik</th>
                        <th class="pb-2">Reyting</th>
                        <th class="pb-2">Maslahatlar</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($topDoctors as $i => $doc)
                    <tr class="border-t border-slate-100 dark:border-navy-600">
                        <td class="py-2 font-medium">{{ $i + 1 }}</td>
                        <td class="py-2">{{ $doc->user->name ?? '—' }}</td>
                        <td class="py-2 text-xs">{{ ucfirst($doc->specialty) }}</td>
                        <td class="py-2"><i class="fa fa-star text-warning text-xs"></i> {{ $doc->rating }}</td>
                        <td class="py-2">{{ $doc->consultations_count }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
