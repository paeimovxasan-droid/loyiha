@extends('admin.layouts.app')
@section('title', 'Uyga chaqirishlar')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.medical.dashboard') }}">Tibbiyot</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Uyga chaqirishlar</span>
@endsection

@section('header-actions')
    <form action="{{ route('admin.medical.home-visits') }}" method="GET" style="display: inline-flex;">
        <select name="status" onchange="this.form.submit()" class="form-control" style="font-size: 12px; padding: 6px 12px; min-width: 140px;">
            <option value="">Barchasi</option>
            <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>Kutilmoqda</option>
            <option value="accepted" {{ request('status') === 'accepted' ? 'selected' : '' }}>Qabul qilingan</option>
            <option value="on_the_way" {{ request('status') === 'on_the_way' ? 'selected' : '' }}>Yo'lda</option>
            <option value="completed" {{ request('status') === 'completed' ? 'selected' : '' }}>Tugallangan</option>
            <option value="cancelled" {{ request('status') === 'cancelled' ? 'selected' : '' }}>Bekor</option>
        </select>
    </form>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">Uyga chaqirishlar</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Bemor</th>
                        <th>Shifokor</th>
                        <th>Manzil</th>
                        <th>Narx</th>
                        <th>Holat</th>
                        <th>Sana</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($visits as $visit)
                    <tr>
                        <td style="font-weight: 500; color: var(--text-primary);">#{{ $visit->id }}</td>
                        <td style="color: var(--text-primary);">{{ $visit->patient->name ?? '—' }}</td>
                        <td>
                            <span style="color: var(--text-primary);">{{ $visit->doctor->name ?? '—' }}</span>
                            @if($visit->doctorProfile->specialty ?? null)
                                <br><span style="font-size: 11px; color: var(--text-muted);">{{ $visit->doctorProfile->specialty }}</span>
                            @endif
                        </td>
                        <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px; color: var(--text-muted);">{{ $visit->address }}</td>
                        <td style="font-weight: 600; color: var(--text-primary);">{{ number_format($visit->price, 0) }} AIS</td>
                        <td>
                            @switch($visit->status)
                                @case('pending') <span class="badge badge-warning">Kutilmoqda</span> @break
                                @case('accepted') <span class="badge badge-info">Qabul qilingan</span> @break
                                @case('on_the_way') <span class="badge badge-primary">Yo'lda</span> @break
                                @case('completed') <span class="badge badge-success">Tugallangan</span> @break
                                @case('cancelled') <span class="badge badge-danger">Bekor</span> @break
                            @endswitch
                        </td>
                        <td style="font-size: 12px; color: var(--text-muted);">{{ $visit->created_at->format('d.m.Y H:i') }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 32px 16px; color: var(--text-muted);">
                            Uyga chaqirishlar topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $visits->withQueryString()->links() }}
        </div>
    </div>
</div>
@endsection
