@extends('admin.layouts.app')
@section('title', 'Dori katalogi')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.medical.dashboard') }}">Tibbiyot</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Dori katalogi</span>
@endsection

@section('header-actions')
    <button type="button" class="btn btn-primary btn-sm" onclick="document.getElementById('addMedicineModal').style.display='flex'">
        <i class="fa fa-plus"></i> Dori qo'shish
    </button>
@endsection

@section('content')
{{-- Modal: Yangi dori qo'shish --}}
<div id="addMedicineModal" style="display: none; position: fixed; inset: 0; z-index: 50; align-items: center; justify-content: center; background: rgba(0,0,0,0.5);" onclick="if(event.target===this) this.style.display='none'">
    <div style="width: 100%; max-width: 440px; background: var(--bg-card); border-radius: 12px; padding: 24px; box-shadow: 0 20px 60px rgba(0,0,0,0.3);">
        <h3 style="font-size: 16px; font-weight: 600; color: var(--text-primary); margin-bottom: 16px;">Yangi dori qo'shish</h3>
        <form method="POST" action="{{ route('admin.medical.medicines.store') }}">
            @csrf
            <div class="form-group">
                <label class="form-label">Nomi</label>
                <input type="text" name="name" required class="form-control">
            </div>
            <div class="form-group">
                <label class="form-label">Turi</label>
                <select name="type" class="form-control">
                    <option value="tablet">Tabletka</option>
                    <option value="syrup">Sirop</option>
                    <option value="injection">Ukol</option>
                    <option value="ointment">Maz</option>
                    <option value="drops">Tomchi</option>
                    <option value="other">Boshqa</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Narxi (AIS)</label>
                <input type="number" name="price" step="0.01" min="0" required class="form-control">
            </div>
            <div class="form-group">
                <label class="form-label">Tavsif</label>
                <textarea name="description" rows="2" class="form-control"></textarea>
            </div>
            <div style="display: flex; gap: 8px; margin-top: 16px;">
                <button type="button" class="btn btn-outline btn-sm" style="flex: 1;" onclick="document.getElementById('addMedicineModal').style.display='none'">Bekor</button>
                <button type="submit" class="btn btn-primary btn-sm" style="flex: 1;">Saqlash</button>
            </div>
        </form>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">Dori katalogi</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Nomi</th>
                        <th>Turi</th>
                        <th>Narx (AIS)</th>
                        <th>Holat</th>
                        <th>Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($medicines as $medicine)
                    <tr>
                        <td style="font-weight: 500; color: var(--text-primary);">{{ $medicine->name }}</td>
                        <td style="font-size: 12px; color: var(--text-muted);">
                            @switch($medicine->type)
                                @case('tablet') Tabletka @break
                                @case('syrup') Sirop @break
                                @case('injection') Ukol @break
                                @case('ointment') Maz @break
                                @case('drops') Tomchi @break
                                @default Boshqa @break
                            @endswitch
                        </td>
                        <td style="font-weight: 600; color: var(--text-primary);">{{ number_format($medicine->price, 0) }}</td>
                        <td>
                            @if($medicine->is_active && $medicine->in_stock)
                                <span class="badge badge-success">Faol</span>
                            @elseif(!$medicine->in_stock)
                                <span class="badge badge-warning">Tugagan</span>
                            @else
                                <span class="badge badge-secondary">O'chirilgan</span>
                            @endif
                        </td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 4px;">
                                <form method="POST" action="{{ route('admin.medical.medicines.update', $medicine) }}" style="display: inline;">
                                    @csrf @method('PUT')
                                    <input type="hidden" name="in_stock" value="{{ $medicine->in_stock ? '0' : '1' }}">
                                    <button type="submit" class="btn btn-outline btn-sm" title="{{ $medicine->in_stock ? 'Tugadi deb belgilash' : 'Mavjud deb belgilash' }}">
                                        <i class="fa {{ $medicine->in_stock ? 'fa-box' : 'fa-box-open' }}"></i>
                                    </button>
                                </form>
                                <form method="POST" action="{{ route('admin.medical.medicines.destroy', $medicine) }}" style="display: inline;" onsubmit="return confirm('O\'chirilsinmi?')">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 32px 16px; color: var(--text-muted);">
                            Dorilar topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $medicines->withQueryString()->links() }}
        </div>
    </div>
</div>
@endsection
