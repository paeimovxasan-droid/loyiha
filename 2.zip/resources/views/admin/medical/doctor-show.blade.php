@extends('admin.layouts.app')
@section('title', 'Shifokor — ' . $doctorProfile->user->name)

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.medical.dashboard') }}">Tibbiyot</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.medical.doctors') }}">Shifokorlar</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ $doctorProfile->user->name }}</span>
@endsection

@section('content')
<div style="display: grid; grid-template-columns: 1fr; gap: 16px; margin-top: 16px;">
    {{-- Main content area --}}
    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 16px;">
        {{-- Left column: Profile + Stats --}}
        <div style="display: flex; flex-direction: column; gap: 16px;">
            {{-- Shifokor profili --}}
            <div class="admin-card">
                <div class="admin-card-header" style="display: flex; align-items: center; justify-content: space-between;">
                    <h3 style="color: var(--text-primary); font-weight: 600;">Shifokor profili</h3>
                    @if($doctorProfile->status === 'pending')
                        <span class="badge badge-warning">Kutilmoqda</span>
                    @elseif($doctorProfile->status === 'approved')
                        <span class="badge badge-success">Tasdiqlangan</span>
                    @elseif($doctorProfile->status === 'rejected')
                        <span class="badge badge-danger">Rad etilgan</span>
                    @elseif($doctorProfile->status === 'suspended')
                        <span class="badge badge-secondary">To'xtatilgan</span>
                    @endif
                </div>
                <div class="admin-card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                        <div>
                            <span style="font-size: 11px; color: var(--text-muted); display: block;">Ism</span>
                            <p style="font-weight: 700; color: var(--text-primary); margin: 4px 0 0;">{{ $doctorProfile->user->name }}</p>
                        </div>
                        <div>
                            <span style="font-size: 11px; color: var(--text-muted); display: block;">Ixtisoslik</span>
                            <p style="font-weight: 500; color: var(--text-primary); margin: 4px 0 0;">{{ ucfirst($doctorProfile->specialty) }}</p>
                        </div>
                        <div>
                            <span style="font-size: 11px; color: var(--text-muted); display: block;">Tajriba</span>
                            <p style="font-weight: 500; color: var(--text-primary); margin: 4px 0 0;">{{ $doctorProfile->experience_years }} yil</p>
                        </div>
                        <div>
                            <span style="font-size: 11px; color: var(--text-muted); display: block;">Ish joyi</span>
                            <p style="font-weight: 500; color: var(--text-primary); margin: 4px 0 0;">{{ $doctorProfile->workplace }}</p>
                        </div>
                        <div>
                            <span style="font-size: 11px; color: var(--text-muted); display: block;">Litsenziya raqami</span>
                            <p style="font-weight: 500; color: var(--text-primary); margin: 4px 0 0;">{{ $doctorProfile->license_number }}</p>
                        </div>
                        <div>
                            <span style="font-size: 11px; color: var(--text-muted); display: block;">Maslahat narxi</span>
                            <p style="font-weight: 700; color: var(--text-primary); margin: 4px 0 0;">{{ number_format($doctorProfile->consultation_price, 0) }} AIS</p>
                        </div>
                        <div>
                            <span style="font-size: 11px; color: var(--text-muted); display: block;">Uyga chaqirish narxi</span>
                            <p style="font-weight: 500; color: var(--text-primary); margin: 4px 0 0;">{{ $doctorProfile->home_visit_price > 0 ? number_format($doctorProfile->home_visit_price, 0) . ' AIS' : 'Taqdim etmaydi' }}</p>
                        </div>
                        <div>
                            <span style="font-size: 11px; color: var(--text-muted); display: block;">Reyting</span>
                            <p style="font-weight: 500; color: var(--text-primary); margin: 4px 0 0;">
                                <i class="fa fa-star" style="color: var(--warning);"></i> {{ $doctorProfile->rating }} ({{ $doctorProfile->reviews_count }} sharh)
                            </p>
                        </div>
                    </div>

                    @if($doctorProfile->bio)
                    <div style="margin-top: 16px; padding: 12px; border-radius: 8px; border: 1px solid var(--border); background: rgba(0,0,0,0.02);">
                        <span style="font-size: 11px; color: var(--text-muted); display: block; margin-bottom: 4px;">Bio</span>
                        <p style="font-size: 13px; color: var(--text-primary); margin: 0;">{{ $doctorProfile->bio }}</p>
                    </div>
                    @endif

                    @if($doctorProfile->diploma_image)
                    <div style="margin-top: 16px;">
                        <span style="font-size: 11px; color: var(--text-muted); display: block; margin-bottom: 8px;">Diplom rasmi</span>
                        <img src="{{ $doctorProfile->diploma_image }}" style="border-radius: 8px; max-width: 100%; max-width: 400px;" alt="Diplom">
                    </div>
                    @endif
                </div>
            </div>

            {{-- Faoliyat statistikasi --}}
            <div class="admin-card">
                <div class="admin-card-header">
                    <h3 style="color: var(--text-primary); font-weight: 600;">Faoliyat statistikasi</h3>
                </div>
                <div class="admin-card-body">
                    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; text-align: center;">
                        <div>
                            <p style="font-size: 24px; font-weight: 700; color: var(--text-primary); margin: 0;">{{ $stats['total_consultations'] }}</p>
                            <p style="font-size: 11px; color: var(--text-muted); margin: 4px 0 0;">Jami maslahatlar</p>
                        </div>
                        <div>
                            <p style="font-size: 24px; font-weight: 700; color: var(--success); margin: 0;">{{ $stats['completed'] }}</p>
                            <p style="font-size: 11px; color: var(--text-muted); margin: 4px 0 0;">Tugallangan</p>
                        </div>
                        <div>
                            <p style="font-size: 24px; font-weight: 700; color: var(--danger); margin: 0;">{{ $stats['expired'] }}</p>
                            <p style="font-size: 11px; color: var(--text-muted); margin: 4px 0 0;">Muddati o'tgan</p>
                        </div>
                        <div>
                            <p style="font-size: 24px; font-weight: 700; color: var(--warning); margin: 0;">{{ number_format($stats['avg_response_hours'], 1) }} soat</p>
                            <p style="font-size: 11px; color: var(--text-muted); margin: 4px 0 0;">O'rtacha javob vaqti</p>
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; text-align: center; margin-top: 16px;">
                        <div>
                            <p style="font-size: 20px; font-weight: 700; color: var(--text-primary); margin: 0;">{{ number_format($stats['total_earnings'], 0) }} AIS</p>
                            <p style="font-size: 11px; color: var(--text-muted); margin: 4px 0 0;">Jami daromad</p>
                        </div>
                        <div>
                            <p style="font-size: 20px; font-weight: 700; color: var(--danger); margin: 0;">{{ $stats['justified_complaints'] }}</p>
                            <p style="font-size: 11px; color: var(--text-muted); margin: 4px 0 0;">Asosli shikoyatlar</p>
                        </div>
                        <div>
                            <p style="font-size: 20px; font-weight: 700; color: var(--text-muted); margin: 0;">{{ $stats['cancelled'] }}</p>
                            <p style="font-size: 11px; color: var(--text-muted); margin: 4px 0 0;">Bekor qilingan</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Right column: Actions + Reviews --}}
        <div style="display: flex; flex-direction: column; gap: 16px;">
            {{-- Amallar --}}
            <div class="admin-card">
                <div class="admin-card-header">
                    <h3 style="color: var(--text-primary); font-weight: 600;">Amallar</h3>
                </div>
                <div class="admin-card-body">
                    @if($doctorProfile->status === 'pending')
                    <div style="display: flex; flex-direction: column; gap: 8px;">
                        <form method="POST" action="{{ route('admin.medical.doctors.approve', $doctorProfile) }}">
                            @csrf
                            <button type="submit" class="btn btn-primary btn-sm" style="width: 100%;">
                                <i class="fa fa-check"></i> Tasdiqlash
                            </button>
                        </form>

                        <form method="POST" action="{{ route('admin.medical.doctors.reject', $doctorProfile) }}" id="rejectForm">
                            @csrf
                            <div class="form-group">
                                <textarea name="reason" id="rejectReason" placeholder="Rad etish sababi..." required class="form-control" rows="3"></textarea>
                            </div>
                            <button type="submit" class="btn btn-danger btn-sm" style="width: 100%;" id="rejectBtn" disabled>
                                <i class="fa fa-times"></i> Rad etish
                            </button>
                        </form>
                    </div>
                    @endif

                    @if($doctorProfile->status === 'approved')
                    <form method="POST" action="{{ route('admin.medical.doctors.suspend', $doctorProfile) }}">
                        @csrf
                        <button type="submit" class="btn btn-outline btn-sm" style="width: 100%;" onclick="return confirm('Shifokor profilini to\'xtatmoqchimisiz?')">
                            <i class="fa fa-ban"></i> To'xtatish (Suspend)
                        </button>
                    </form>
                    @endif

                    @if($doctorProfile->status === 'suspended')
                    <form method="POST" action="{{ route('admin.medical.doctors.reactivate', $doctorProfile) }}">
                        @csrf
                        <button type="submit" class="btn btn-primary btn-sm" style="width: 100%;">
                            <i class="fa fa-redo"></i> Qayta faollashtirish
                        </button>
                    </form>
                    @endif

                    @if($doctorProfile->rejection_reason)
                    <div style="margin-top: 16px; padding: 12px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.05); border: 1px solid rgba(var(--danger-rgb), 0.2);">
                        <span style="font-size: 11px; font-weight: 600; color: var(--danger); display: block; margin-bottom: 4px;">Rad etish sababi:</span>
                        <p style="font-size: 13px; color: var(--text-primary); margin: 0;">{{ $doctorProfile->rejection_reason }}</p>
                    </div>
                    @endif
                </div>
            </div>

            {{-- Sharhlar --}}
            @if($doctorProfile->reviews->count())
            <div class="admin-card">
                <div class="admin-card-header">
                    <h3 style="color: var(--text-primary); font-weight: 600;">So'nggi sharhlar</h3>
                </div>
                <div class="admin-card-body" style="max-height: 256px; overflow-y: auto;">
                    <div style="display: flex; flex-direction: column; gap: 12px;">
                        @foreach($doctorProfile->reviews->take(5) as $review)
                        <div style="padding: 8px 12px; border-radius: 8px; border: 1px solid var(--border);">
                            <div style="display: flex; align-items: center; justify-content: space-between;">
                                <span style="font-size: 12px; font-weight: 500; color: var(--text-primary);">{{ $review->patient->name ?? 'Anonim' }}</span>
                                <div style="display: flex; align-items: center; gap: 2px;">
                                    @for($i = 1; $i <= 5; $i++)
                                        <i class="fa fa-star" style="font-size: 10px; color: {{ $i <= $review->rating ? 'var(--warning)' : 'var(--border)' }};"></i>
                                    @endfor
                                </div>
                            </div>
                            @if($review->comment)
                            <p style="font-size: 12px; color: var(--text-muted); margin: 4px 0 0;">{{ $review->comment }}</p>
                            @endif
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var reasonField = document.getElementById('rejectReason');
    var rejectBtn = document.getElementById('rejectBtn');

    if (reasonField && rejectBtn) {
        reasonField.addEventListener('input', function() {
            rejectBtn.disabled = !this.value.trim();
        });
    }
});
</script>
@endsection
