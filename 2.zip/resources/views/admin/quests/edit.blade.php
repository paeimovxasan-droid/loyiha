@extends('admin.layouts.app')
@section('title', 'Kvestni tahrirlash')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.quests.index') }}">Kvestlar</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Tahrirlash</span>
@endsection

@section('content')
@if($errors->any())
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid var(--danger); color: var(--danger); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <i class="fa fa-exclamation-circle"></i> {{ $errors->first() }}
</div>
@endif

<form method="POST" action="{{ route('admin.quests.update', $quest) }}">
    @csrf @method('PUT')
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">

        <div class="admin-card">
            <div class="admin-card-header">Asosiy</div>
            <div class="admin-card-body">
                <div class="form-group">
                    <label class="form-label">Nomi (UZ) *</label>
                    <input type="text" name="title_uz" value="{{ old('title_uz', $quest->getTranslation('title','uz')) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Nomi (RU)</label>
                    <input type="text" name="title_ru" value="{{ old('title_ru', $quest->getTranslation('title','ru')) }}" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Tavsif (UZ)</label>
                    <textarea name="description_uz" rows="2" class="form-control">{{ old('description_uz', $quest->getTranslation('description','uz')) }}</textarea>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div class="form-group">
                        <label class="form-label">Icon</label>
                        <input type="text" name="icon" value="{{ old('icon', $quest->icon) }}" required maxlength="10" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tartib</label>
                        <input type="number" name="sort_order" value="{{ old('sort_order', $quest->sort_order) }}" min="0" class="form-control">
                    </div>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div class="form-group">
                        <label class="form-label">Kategoriya</label>
                        <select name="category" class="form-control">
                            @foreach(['general'=>'Asosiy','daily'=>'Kunlik','weekly'=>'Haftalik','investment'=>'Investitsiya','referral'=>'Referral','social'=>'Ijtimoiy'] as $val => $label)
                            <option value="{{ $val }}" {{ $quest->category === $val ? 'selected' : '' }}>{{ $label }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tur</label>
                        <select name="type" class="form-control">
                            @foreach(['one_time'=>'Bir marta','daily'=>'Kunlik','weekly'=>'Haftalik','repeatable'=>'Takroriy'] as $val => $label)
                            <option value="{{ $val }}" {{ $quest->type === $val ? 'selected' : '' }}>{{ $label }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div class="form-group">
                        <label class="form-label">Min daraja</label>
                        <input type="number" name="min_level" value="{{ old('min_level', $quest->min_level) }}" min="0" max="99" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Holat</label>
                        <select name="status" class="form-control">
                            <option value="active" {{ $quest->status === 'active' ? 'selected' : '' }}>Faol</option>
                            <option value="inactive" {{ $quest->status === 'inactive' ? 'selected' : '' }}>Nofaol</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Muddat</label>
                    <input type="datetime-local" name="expires_at" value="{{ old('expires_at', $quest->expires_at?->format('Y-m-d\TH:i')) }}" class="form-control">
                </div>
            </div>
        </div>

        <div>
            <div class="admin-card" style="margin-bottom: 16px;">
                <div class="admin-card-header">Talab</div>
                <div class="admin-card-body">
                    <div class="form-group">
                        <label class="form-label">Talab turi</label>
                        <select name="requirement_type" class="form-control">
                            @foreach(['deposit_count'=>'Depozit soni','referral_count'=>'Referral soni','purchase_count'=>'Paket xaridi','checkin_streak'=>'Check-in streak','level_reach'=>'Darajaga yetish','transfer_count'=>"P2P o'tkazma",'task_complete'=>'Topshiriq','fund_invest'=>'Fond investitsiya','profile_fill'=>"Profil to'ldirish",'kyc_verify'=>'KYC tasdiqlash','lucky_draw'=>'Lucky Draw','total_deposit'=>'Jami depozit'] as $val => $label)
                            <option value="{{ $val }}" {{ $quest->requirement_type === $val ? 'selected' : '' }}>{{ $label }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Talab qiymati</label>
                        <input type="number" name="requirement_value" value="{{ old('requirement_value', $quest->requirement_value) }}" min="1" required class="form-control">
                    </div>
                </div>
            </div>

            <div class="admin-card" style="margin-bottom: 16px;">
                <div class="admin-card-header">Mukofot</div>
                <div class="admin-card-body">
                    <div class="form-group">
                        <label class="form-label">AIS mukofot</label>
                        <input type="number" name="reward_ais" value="{{ old('reward_ais', $quest->reward_ais) }}" min="0" step="0.0001" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">UZS mukofot</label>
                        <input type="number" name="reward_uzs" value="{{ old('reward_uzs', $quest->reward_uzs) }}" min="0" step="1000" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">XP mukofot</label>
                        <input type="number" name="reward_xp" value="{{ old('reward_xp', $quest->reward_xp) }}" min="0" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Badge</label>
                        <input type="text" name="reward_badge" value="{{ old('reward_badge', $quest->reward_badge) }}" maxlength="50" class="form-control">
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%;">
                <i class="fa fa-save"></i> Saqlash
            </button>
        </div>
    </div>
</form>
@endsection
