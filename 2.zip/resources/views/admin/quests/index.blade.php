@extends('admin.layouts.app')
@section('title', 'Kvestlar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Kvestlar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.quests.create') }}" class="btn btn-primary btn-sm">
    <i class="fa fa-plus"></i> Yangi kvest
</a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif

{{-- Statistika --}}
<div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 24px;">
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--text-primary);">{{ $stats['total'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Jami kvestlar</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--success);">{{ $stats['active'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Faol</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 16px;">
        <div style="font-size: 24px; font-weight: 700; color: var(--warning);">{{ $stats['total_claimed'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Mukofot olindi</div>
    </div>
</div>

<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="text-align: left;">Kvest</th>
                        <th style="text-align: center;">Tur</th>
                        <th style="text-align: center;">Talab</th>
                        <th style="text-align: center;">Mukofot</th>
                        <th style="text-align: center;">Bajarildi</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($quests as $quest)
                    <tr>
                        <td>
                            <div style="display: flex; align-items: center; gap: 12px;">
                                <div style="font-size: 24px;">{{ $quest->icon }}</div>
                                <div>
                                    <div style="font-weight: 500; color: var(--text-primary);">{{ $quest->getTranslation('title', 'uz') }}</div>
                                    <div style="font-size: 12px; color: var(--text-muted);">{{ $quest->category }}</div>
                                </div>
                            </div>
                        </td>
                        <td style="text-align: center;">
                            @php
                                $typeClass = match($quest->type) {
                                    'one_time' => 'badge-info',
                                    'daily' => 'badge-danger',
                                    'weekly' => 'badge-warning',
                                    'repeatable' => 'badge-success',
                                    default => 'badge-info',
                                };
                            @endphp
                            <span class="badge {{ $typeClass }}">
                                {{ match($quest->type) {
                                    'one_time'   => 'Bir marta',
                                    'daily'      => 'Kunlik',
                                    'weekly'     => 'Haftalik',
                                    'repeatable' => 'Takroriy',
                                    default      => $quest->type,
                                } }}
                            </span>
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">
                            {{ $quest->requirement_type }}: {{ $quest->requirement_value }}
                        </td>
                        <td style="text-align: center;">
                            <div style="font-size: 12px;">
                                @if($quest->reward_ais > 0)
                                <div style="color: var(--text-primary); font-weight: 600;">{{ $quest->reward_ais }} AIS</div>
                                @endif
                                @if($quest->reward_uzs > 0)
                                <div style="color: var(--success); font-weight: 600;">{{ number_format($quest->reward_uzs, 0) }} UZS</div>
                                @endif
                                @if($quest->reward_xp > 0)
                                <div style="color: var(--warning); font-weight: 600;">+{{ $quest->reward_xp }} XP</div>
                                @endif
                            </div>
                        </td>
                        <td style="text-align: center;">
                            <span style="color: var(--success); font-weight: 600;">{{ $quest->claimed_count }}</span>
                            <span style="color: var(--text-muted);">/{{ $quest->user_quests_count }}</span>
                        </td>
                        <td style="text-align: center;">
                            @if($quest->status === 'active')
                            <span class="badge badge-success">Faol</span>
                            @else
                            <span class="badge badge-warning">Nofaol</span>
                            @endif
                        </td>
                        <td style="text-align: center;">
                            <div style="display: flex; align-items: center; justify-content: center; gap: 8px;">
                                <a href="{{ route('admin.quests.edit', $quest) }}" class="btn btn-outline btn-sm">
                                    <i class="fa fa-pen"></i>
                                </a>
                                <form method="POST" action="{{ route('admin.quests.destroy', $quest) }}">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('O\'chirishni tasdiqlaysizmi?')">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            <i class="fa fa-map" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Kvest topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
