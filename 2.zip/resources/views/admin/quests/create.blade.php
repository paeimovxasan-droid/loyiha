@extends('admin.layouts.app')
@section('title', 'Yangi Kvest')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.quests.index') }}">Kvestlar</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Yangi kvest</span>
@endsection

@section('content')
@if($errors->any())
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid var(--danger); color: var(--danger); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <i class="fa fa-exclamation-circle"></i> {{ $errors->first() }}
</div>
@endif

<form method="POST" action="{{ route('admin.quests.store') }}">
    @csrf
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">

        {{-- Asosiy ma'lumotlar --}}
        <div class="admin-card">
            <div class="admin-card-header">Asosiy</div>
            <div class="admin-card-body">
                <div class="form-group">
                    <label class="form-label">Nomi (UZ) *</label>
                    <input type="text" name="title_uz" value="{{ old('title_uz') }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Nomi (RU)</label>
                    <input type="text" name="title_ru" value="{{ old('title_ru') }}" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Tavsif (UZ)</label>
                    <textarea name="description_uz" rows="2" class="form-control">{{ old('description_uz') }}</textarea>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div class="form-group">
                        <label class="form-label">Icon (emoji)</label>
                        <input type="text" name="icon" value="{{ old('icon', '🎯') }}" required maxlength="10" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tartib</label>
                        <input type="number" name="sort_order" value="{{ old('sort_order', 0) }}" min="0" class="form-control">
                    </div>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div class="form-group">
                        <label class="form-label">Kategoriya</label>
                        <select name="category" class="form-control">
                            <option value="general">Asosiy</option>
                            <option value="daily">Kunlik</option>
                            <option value="weekly">Haftalik</option>
                            <option value="investment">Investitsiya</option>
                            <option value="referral">Referral</option>
                            <option value="social">Ijtimoiy</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tur</label>
                        <select name="type" class="form-control">
                            <option value="one_time">Bir marta</option>
                            <option value="daily">Kunlik</option>
                            <option value="weekly">Haftalik</option>
                            <option value="repeatable">Takroriy</option>
                        </select>
                    </div>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div class="form-group">
                        <label class="form-label">Min daraja</label>
                        <input type="number" name="min_level" value="{{ old('min_level', 0) }}" min="0" max="99" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Holat</label>
                        <select name="status" class="form-control">
                            <option value="active">Faol</option>
                            <option value="inactive">Nofaol</option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label">Muddat (ixtiyoriy)</label>
                    <input type="datetime-local" name="expires_at" value="{{ old('expires_at') }}" class="form-control">
                </div>
            </div>
        </div>

        {{-- Talab va mukofot --}}
        <div>
            <div class="admin-card" style="margin-bottom: 16px;">
                <div class="admin-card-header">Talab</div>
                <div class="admin-card-body">
                    <div class="form-group">
                        <label class="form-label">Talab turi</label>
                        <select name="requirement_type" class="form-control">
                            <option value="deposit_count">Depozit soni</option>
                            <option value="referral_count">Referral soni</option>
                            <option value="purchase_count">Paket xaridi soni</option>
                            <option value="checkin_streak">Check-in streak</option>
                            <option value="level_reach">Darajaga yetish</option>
                            <option value="transfer_count">P2P o'tkazma soni</option>
                            <option value="task_complete">Topshiriq bajarish</option>
                            <option value="fund_invest">Fond investitsiya</option>
                            <option value="profile_fill">Profil to'ldirish</option>
                            <option value="kyc_verify">KYC tasdiqlash</option>
                            <option value="lucky_draw">Lucky Draw ishtirok</option>
                            <option value="total_deposit">Jami depozit (UZS)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Talab qiymati</label>
                        <input type="number" name="requirement_value" value="{{ old('requirement_value', 1) }}" min="1" required class="form-control">
                    </div>
                </div>
            </div>

            <div class="admin-card" style="margin-bottom: 16px;">
                <div class="admin-card-header">Mukofot</div>
                <div class="admin-card-body">
                    <div class="form-group">
                        <label class="form-label">AIS mukofot</label>
                        <input type="number" name="reward_ais" value="{{ old('reward_ais', 0) }}" min="0" step="0.0001" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">UZS mukofot</label>
                        <input type="number" name="reward_uzs" value="{{ old('reward_uzs', 0) }}" min="0" step="1000" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">XP mukofot</label>
                        <input type="number" name="reward_xp" value="{{ old('reward_xp', 0) }}" min="0" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Badge (ixtiyoriy)</label>
                        <input type="text" name="reward_badge" value="{{ old('reward_badge') }}" maxlength="50" class="form-control" placeholder="Masalan: Investor Pro">
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%;">
                <i class="fa fa-save"></i> Saqlash
            </button>
        </div>
    </div>
</form>
@endsection
