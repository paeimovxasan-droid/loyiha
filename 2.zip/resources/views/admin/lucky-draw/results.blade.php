@extends('admin.layouts.app')
@section('title', 'Lucky Draw Natijalari')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.lucky-draw.index') }}">Lucky Draw</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Natijalar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.lucky-draw.index') }}" class="btn btn-outline btn-sm">
    <i class="fa fa-arrow-left"></i> Orqaga
</a>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="text-align: left;">O'yin</th>
                        <th style="text-align: center;">G'olib</th>
                        <th style="text-align: center;">G'olibga berildi</th>
                        <th style="text-align: center;">Platforma daromadi</th>
                        <th style="text-align: center;">Jami yig'ildi</th>
                        <th style="text-align: center;">Qur'a sanasi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($completed as $draw)
                    @php
                        $totalCollected = $draw->tickets()->sum('total_paid');
                        $platformEarning = $totalCollected - $draw->winner_prize;
                    @endphp
                    <tr>
                        <td style="font-weight: 500; color: var(--text-primary);">{{ $draw->getTranslation('name', 'uz') }}</td>
                        <td style="text-align: center;">
                            <div style="font-weight: 600; color: var(--success);">🏆 {{ $draw->winner?->name }}</div>
                            <div style="font-size: 12px; color: var(--text-muted);">{{ $draw->winner?->username }}</div>
                        </td>
                        <td style="text-align: center; font-weight: 700; color: var(--success);">
                            {{ number_format($draw->winner_prize, 2) }} UZS
                        </td>
                        <td style="text-align: center; font-weight: 700; color: var(--warning);">
                            {{ number_format($platformEarning, 2) }} UZS
                            <div style="font-size: 12px; color: var(--text-muted);">({{ $draw->platform_rake_percent }}% rake)</div>
                        </td>
                        <td style="text-align: center; color: var(--text-secondary);">
                            {{ number_format($totalCollected, 2) }} UZS
                            <div style="font-size: 12px; color: var(--text-muted);">{{ $draw->getTotalTicketsSold() }} ta chipta</div>
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">
                            {{ $draw->drawn_at?->format('d.m.Y H:i') }}
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">Hali qur'a tashlangan o'yin yo'q</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    @if($completed->hasPages())
    <div class="pagination" style="padding: 12px 16px; border-top: 1px solid var(--border);">{{ $completed->links() }}</div>
    @endif
</div>
@endsection
