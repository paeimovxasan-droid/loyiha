@extends('admin.layouts.app')
@section('title', 'Yangi Lucky Draw')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.lucky-draw.index') }}">Lucky Draw</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Yangi o'yin</span>
@endsection

@section('content')
@if($errors->any())
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid var(--danger); color: var(--danger); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <i class="fa fa-exclamation-circle"></i> {{ $errors->first() }}
</div>
@endif

<form method="POST" action="{{ route('admin.lucky-draw.store') }}">
    @csrf
    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
        <div class="admin-card">
            <div class="admin-card-header">Nomi</div>
            <div class="admin-card-body">
                <div class="form-group">
                    <label class="form-label">Nomi (UZ) *</label>
                    <input type="text" name="name[uz]" value="{{ old('name.uz') }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Nomi (RU)</label>
                    <input type="text" name="name[ru]" value="{{ old('name.ru') }}" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Nomi (EN)</label>
                    <input type="text" name="name[en]" value="{{ old('name.en') }}" class="form-control">
                </div>
            </div>
        </div>

        <div>
            <div class="admin-card" style="margin-bottom: 16px;">
                <div class="admin-card-header">Sozlamalar</div>
                <div class="admin-card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                        <div class="form-group">
                            <label class="form-label">Chipta narxi (UZS) *</label>
                            <input type="number" name="entry_fee" value="{{ old('entry_fee', 0) }}" min="0" step="0.01" required class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Sovrin (UZS) *</label>
                            <input type="number" name="prize_amount" value="{{ old('prize_amount', 0) }}" min="0" step="0.01" required class="form-control">
                        </div>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                        <div class="form-group">
                            <label class="form-label">Max chiptalar</label>
                            <input type="number" name="max_tickets" value="{{ old('max_tickets') }}" min="0" class="form-control">
                        </div>
                        <div class="form-group">
                            <label class="form-label">O'tkazish sanasi *</label>
                            <input type="datetime-local" name="draw_at" value="{{ old('draw_at') }}" required class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Holat *</label>
                        <select name="status" required class="form-control">
                            <option value="active">Faol</option>
                            <option value="inactive">Nofaol</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary" style="width: 100%;">
                <i class="fa fa-save"></i> Saqlash
            </button>
        </div>
    </div>
</form>
@endsection
