@extends('admin.layouts.app')
@section('title', 'Lucky Draw')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Lucky Draw</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.lucky-draw.results') }}" class="btn btn-outline btn-sm">
    <i class="fa fa-trophy"></i> Natijalar
</a>
<a href="{{ route('admin.lucky-draw.create') }}" class="btn btn-primary btn-sm">
    <i class="fa fa-plus"></i> Yangi o'yin
</a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif
@if(session('error'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid var(--danger); color: var(--danger); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <i class="fa fa-exclamation-circle"></i> {{ session('error') }}
</div>
@endif

<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="text-align: left;">Nomi</th>
                        <th style="text-align: center;">Chipta narxi</th>
                        <th style="text-align: center;">Sovrin / Rake</th>
                        <th style="text-align: center;">Sotilgan / Yig'ilgan</th>
                        <th style="text-align: center;">Draw vaqti</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($draws as $draw)
                    @php
                        $totalCollected = $draw->tickets()->sum('total_paid');
                        $platformEarning = round($totalCollected * ($draw->platform_rake_percent ?? 25) / 100, 0);
                        $winnerPrize = $totalCollected - $platformEarning;
                        $ticketsSold = $draw->getTotalTicketsSold();
                    @endphp
                    <tr>
                        <td style="font-weight: 500; color: var(--text-primary);">{{ $draw->getTranslation('name', 'uz') }}</td>
                        <td style="text-align: center;">{{ number_format($draw->entry_fee) }} UZS</td>
                        <td style="text-align: center;">
                            <div style="font-size: 12px; color: var(--success); font-weight: 600;">G'olib: {{ number_format($winnerPrize) }} UZS</div>
                            <div style="font-size: 12px; color: var(--warning);">Platforma: {{ number_format($platformEarning) }} UZS ({{ $draw->platform_rake_percent ?? 25 }}%)</div>
                        </td>
                        <td style="text-align: center;">
                            <div style="font-weight: 600;">{{ $ticketsSold }} ta chipta</div>
                            <div style="font-size: 12px; color: var(--text-muted);">{{ number_format($totalCollected) }} UZS yig'ildi</div>
                        </td>
                        <td style="text-align: center; font-size: 12px;">
                            {{ $draw->draw_at?->format('d.m.Y H:i') }}
                            @if($draw->draw_at && $draw->draw_at->isPast() && $draw->status === 'active')
                                <div style="color: var(--danger); font-weight: 600; font-size: 12px;">⏰ Vaqt o'tdi!</div>
                            @endif
                        </td>
                        <td style="text-align: center;">
                            @php
                                $statusBadge = match($draw->status) {
                                    'active'    => 'badge-success',
                                    'completed' => 'badge-info',
                                    default     => 'badge-warning',
                                };
                                $statusLabel = match($draw->status) {
                                    'active'    => 'Faol',
                                    'completed' => 'Tugagan',
                                    default     => $draw->status,
                                };
                            @endphp
                            <span class="badge {{ $statusBadge }}">{{ $statusLabel }}</span>
                            @if($draw->status === 'completed' && $draw->winner)
                                <div style="font-size: 12px; color: var(--success); margin-top: 4px;">🏆 {{ $draw->winner->name }}</div>
                            @endif
                        </td>
                        <td style="text-align: center;">
                            <div style="display: flex; align-items: center; justify-content: center; gap: 8px;">
                                @if($draw->status === 'active' && $ticketsSold > 0)
                                <form method="POST" action="{{ route('admin.lucky-draw.draw', $draw) }}">
                                    @csrf
                                    <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('Qur\'a tashlashni tasdiqlaysizmi? Bu amalni qaytarib bo\'lmaydi!')">
                                        🎲 Qur'a
                                    </button>
                                </form>
                                @elseif($draw->status === 'active' && $ticketsSold === 0)
                                <span style="font-size: 12px; color: var(--text-muted);">Chipta yo'q</span>
                                @endif
                                <a href="{{ route('admin.lucky-draw.edit', $draw) }}" class="btn btn-outline btn-sm">
                                    <i class="fa fa-pen"></i>
                                </a>
                                @if($draw->status !== 'completed')
                                <form method="POST" action="{{ route('admin.lucky-draw.destroy', $draw) }}">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('O\'chirishni tasdiqlaysizmi?')">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">O'yin topilmadi</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    @if($draws->hasPages())
    <div class="pagination" style="padding: 12px 16px; border-top: 1px solid var(--border);">{{ $draws->links() }}</div>
    @endif
</div>
@endsection
