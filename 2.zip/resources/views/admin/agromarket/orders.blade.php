@extends('admin.layouts.app')
@section('title', 'AgroMarket Buyurtmalar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">AgroMarket Buyurtmalar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.agromarket.listings') }}" class="btn btn-outline btn-sm">
    <i class="fa fa-arrow-left"></i> E'lonlar
</a>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">Buyurtmalar ro'yxati</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>E'lon</th>
                        <th>Xaridor</th>
                        <th style="text-align: center;">Miqdor</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($orders as $order)
                    <tr>
                        <td style="color: var(--text-muted);">#{{ $order->id }}</td>
                        <td style="color: var(--text-primary);">{{ $order->listing->title ?? '#'.$order->listing_id }}</td>
                        <td style="color: var(--text-secondary);">{{ $order->buyer->name ?? '—' }}</td>
                        <td style="text-align: center; font-weight: 600; color: var(--text-primary);">{{ number_format($order->total ?? $order->amount ?? 0, 2) }} AIS</td>
                        <td style="text-align: center;">
                            @php
                                $statusClass = match($order->status ?? 'pending') {
                                    'completed' => 'badge-success',
                                    'pending' => 'badge-warning',
                                    'cancelled' => 'badge-danger',
                                    default => 'badge-info'
                                };
                            @endphp
                            <span class="badge {{ $statusClass }}">{{ ucfirst($order->status ?? 'pending') }}</span>
                        </td>
                        <td style="text-align: center; color: var(--text-muted); font-size: 13px;">{{ $order->created_at->format('d.m.Y') }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            Buyurtma topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($orders->hasPages())
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $orders->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
