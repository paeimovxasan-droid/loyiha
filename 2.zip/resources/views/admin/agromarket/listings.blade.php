@extends('admin.layouts.app')
@section('title', 'AgroMarket E\'lonlar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">AgroMarket E'lonlar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.agromarket.orders') }}" class="btn btn-primary btn-sm">
    <i class="fa fa-shopping-cart"></i> Buyurtmalar
</a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: color-mix(in srgb, var(--success) 10%, transparent); border: 1px solid color-mix(in srgb, var(--success) 30%, transparent); color: var(--success);">
    {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">E'lonlar ro'yxati</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Nomi</th>
                        <th>Sotuvchi</th>
                        <th style="text-align: center;">Narx</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($listings as $listing)
                    <tr>
                        <td style="color: var(--text-primary); font-weight: 500;">{{ $listing->title ?? $listing->name ?? '#'.$listing->id }}</td>
                        <td style="color: var(--text-secondary);">{{ $listing->user->name ?? '—' }}</td>
                        <td style="text-align: center; font-weight: 600; color: var(--text-primary);">{{ number_format($listing->price ?? 0, 2) }} AIS</td>
                        <td style="text-align: center;">
                            <span class="badge {{ ($listing->status ?? 'active') == 'active' ? 'badge-success' : 'badge-warning' }}">
                                {{ ucfirst($listing->status ?? 'active') }}
                            </span>
                        </td>
                        <td style="text-align: center; color: var(--text-muted); font-size: 13px;">{{ $listing->created_at->format('d.m.Y') }}</td>
                        <td style="text-align: center;">
                            <div style="display: flex; align-items: center; justify-content: center; gap: 4px;">
                                <a href="{{ route('admin.agromarket.listings.edit', $listing) }}" class="btn btn-primary btn-sm">
                                    <i class="fa fa-pen"></i>
                                </a>
                                <form method="POST" action="{{ route('admin.agromarket.listings.destroy', $listing) }}" style="display: inline;">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('O\'chirishni tasdiqlaysizmi?')">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            <i class="fa fa-seedling" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            E'lon topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($listings->hasPages())
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $listings->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
