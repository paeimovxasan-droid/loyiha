@extends('admin.layouts.app')
@section('title', 'AgroMarket e\'lon tahrirlash')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.agromarket.listings') }}">E'lonlar</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Tahrirlash #{{ $listing->id }}</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.agromarket.listings') }}" class="btn btn-outline btn-sm">
    <i class="fa fa-arrow-left"></i> Orqaga
</a>
@endsection

@section('content')
@if($errors->any())
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: color-mix(in srgb, var(--danger) 10%, transparent); border: 1px solid color-mix(in srgb, var(--danger) 30%, transparent); color: var(--danger);">
    <ul style="margin: 0; padding-left: 20px;">
        @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
    </ul>
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); font-weight: 600;">E'lon tahrirlash</h3>
    </div>
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.agromarket.listings.update', $listing) }}">
            @csrf
            @method('PUT')
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 16px;">
                <div class="form-group">
                    <label class="form-label">Sotuvchi</label>
                    <input type="text" value="{{ $listing->user->name ?? '—' }}" disabled class="form-control" style="background: var(--primary-light);">
                </div>
                <div class="form-group">
                    <label class="form-label">Nomi</label>
                    <input type="text" name="title" value="{{ old('title', $listing->title ?? $listing->name) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Narx (AIS)</label>
                    <input type="number" step="0.01" name="price" value="{{ old('price', $listing->price) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Holat</label>
                    <select name="status" class="form-control">
                        @foreach(['active','sold','expired'] as $s)
                        <option value="{{ $s }}" {{ old('status', $listing->status) == $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group" style="grid-column: 1 / -1;">
                    <label class="form-label">Tavsif</label>
                    <textarea name="description" rows="4" class="form-control">{{ old('description', $listing->description) }}</textarea>
                </div>
            </div>
            <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
                <button type="submit" class="btn btn-primary btn-sm">Yangilash</button>
            </div>
        </form>
    </div>
</div>
@endsection
