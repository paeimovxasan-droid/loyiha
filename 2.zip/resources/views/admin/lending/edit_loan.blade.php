@extends('admin.layouts.app')
@section('title', 'Qarz tahrirlash')

@section('breadcrumb')
    <a href="{{ route('admin.lending.loans') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Qarz tahrirlash</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.lending.loans') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> Orqaga
    </a>
@endsection

@section('content')
@if($errors->any())
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid var(--danger); color: var(--danger); margin-bottom: 16px;">
    <ul style="list-style: disc; padding-left: 20px;">
        @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
    </ul>
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">🤝 Qarz tahrirlash #{{ $loan->id }}</h3>
    </div>
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.lending.loans.update', $loan) }}">
            @csrf
            @method('PUT')
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label">Qarz oluvchi</label>
                    <input type="text" value="{{ $loan->borrower->name ?? '—' }}" disabled class="form-control" style="background: var(--primary-light);">
                </div>
                <div class="form-group">
                    <label class="form-label">Qarz beruvchi</label>
                    <input type="text" value="{{ $loan->lender->name ?? '—' }}" disabled class="form-control" style="background: var(--primary-light);">
                </div>
                <div class="form-group">
                    <label class="form-label">Miqdor (AIS)</label>
                    <input type="text" value="{{ number_format($loan->amount ?? 0, 2) }}" disabled class="form-control" style="background: var(--primary-light);">
                </div>
                <div class="form-group">
                    <label class="form-label">Foiz stavkasi (%)</label>
                    <input type="text" value="{{ $loan->interest_rate ?? 0 }}%" disabled class="form-control" style="background: var(--primary-light);">
                </div>
                <div class="form-group">
                    <label class="form-label">Holat</label>
                    <select name="status" class="form-control">
                        @foreach(['pending','active','repaid','defaulted'] as $s)
                        <option value="{{ $s }}" {{ old('status', $loan->status) == $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
                <button type="submit" class="btn btn-primary">Yangilash</button>
            </div>
        </form>
    </div>
</div>
@endsection
