@extends('admin.layouts.app')
@section('title', 'P2P Qarzlar')

@section('breadcrumb')
    <a href="{{ route('admin.lending.loans') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">P2P Qarzlar</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.lending.offers') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-hand-holding-usd"></i> Takliflar
    </a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 16px;">
    {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">🤝 P2P Qarzlar</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Qarz oluvchi</th>
                        <th>Qarz beruvchi</th>
                        <th style="text-align: center;">Miqdor</th>
                        <th style="text-align: center;">Foiz</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($loans as $loan)
                    <tr>
                        <td style="color: var(--text-muted);">#{{ $loan->id }}</td>
                        <td style="color: var(--text-primary);">{{ $loan->borrower->name ?? '—' }}</td>
                        <td style="color: var(--text-secondary);">{{ $loan->lender->name ?? '—' }}</td>
                        <td style="text-align: center; font-weight: 600;">{{ number_format($loan->amount ?? 0, 2) }} AIS</td>
                        <td style="text-align: center;">{{ $loan->interest_rate ?? 0 }}%</td>
                        <td style="text-align: center;">
                            @if(($loan->status ?? '') == 'active')
                                <span class="badge badge-success">Active</span>
                            @elseif(($loan->status ?? '') == 'pending')
                                <span class="badge badge-warning">Pending</span>
                            @elseif(($loan->status ?? '') == 'repaid')
                                <span class="badge badge-info">Repaid</span>
                            @elseif(($loan->status ?? '') == 'defaulted')
                                <span class="badge badge-danger">Defaulted</span>
                            @else
                                <span class="badge badge-warning">{{ ucfirst($loan->status ?? 'pending') }}</span>
                            @endif
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $loan->created_at->format('d.m.Y') }}</td>
                        <td style="text-align: center;">
                            <a href="{{ route('admin.lending.loans.edit', $loan) }}" class="btn btn-primary btn-sm">
                                <i class="fa fa-pen"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px; color: var(--text-muted);">
                            <i class="fa fa-handshake" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Qarz topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 12px 16px;">{{ $loans->withQueryString()->links() }}</div>
    </div>
</div>
@endsection
