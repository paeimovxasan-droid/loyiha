@extends('admin.layouts.app')
@section('title', 'Qarz Takliflari')

@section('breadcrumb')
    <a href="{{ route('admin.lending.loans') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Qarz Takliflari</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.lending.loans') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> Qarzlar
    </a>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">💰 Qarz Takliflari</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Qarz beruvchi</th>
                        <th style="text-align: center;">Miqdor</th>
                        <th style="text-align: center;">Foiz</th>
                        <th style="text-align: center;">Muddat</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($offers as $offer)
                    <tr>
                        <td style="color: var(--text-muted);">#{{ $offer->id }}</td>
                        <td style="color: var(--text-primary);">{{ $offer->lender->name ?? '—' }}</td>
                        <td style="text-align: center; font-weight: 600;">{{ number_format($offer->amount ?? 0, 2) }} AIS</td>
                        <td style="text-align: center;">{{ $offer->interest_rate ?? 0 }}%</td>
                        <td style="text-align: center;">{{ $offer->duration_days ?? '—' }} kun</td>
                        <td style="text-align: center;">
                            @if(($offer->status ?? 'active') == 'active')
                                <span class="badge badge-success">Active</span>
                            @else
                                <span class="badge badge-info">{{ ucfirst($offer->status ?? 'active') }}</span>
                            @endif
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $offer->created_at->format('d.m.Y') }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-muted);">Taklif topilmadi</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div style="padding: 12px 16px;">{{ $offers->withQueryString()->links() }}</div>
    </div>
</div>
@endsection
