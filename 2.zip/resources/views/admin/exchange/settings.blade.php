@extends('admin.layouts.app')
@section('title', 'Birja Sozlamalari')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Birja Sozlamalari</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.exchange.stats') }}" class="btn btn-outline btn-sm"><i class="fa fa-chart-bar"></i> Statistika</a>
<a href="{{ route('admin.exchange.orders') }}" class="btn btn-primary btn-sm"><i class="fa fa-list"></i> Buyurtmalar</a>
<a href="{{ route('admin.exchange.trades') }}" class="btn btn-success btn-sm"><i class="fa fa-exchange-alt"></i> Savdolar</a>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 20px;">
    {{ session('success') }}
</div>
@endif

<div class="admin-card" style="max-width: 700px;">
    <div class="admin-card-header">
        <h3 style="color: var(--text-primary); margin: 0;">Sozlamalar</h3>
    </div>
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.exchange.settings.update') }}">
            @csrf @method('PUT')
            <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px;">
                <div class="form-group">
                    <label class="form-label">Maker komissiya (%)</label>
                    <input type="number" step="0.01" name="maker_fee_percent" value="{{ $settings['maker_fee_percent'] ?? 0.1 }}" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Taker komissiya (%)</label>
                    <input type="number" step="0.01" name="taker_fee_percent" value="{{ $settings['taker_fee_percent'] ?? 0.2 }}" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Min buyurtma miqdori</label>
                    <input type="number" step="0.0001" name="min_order_amount" value="{{ $settings['min_order_amount'] ?? 0.01 }}" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Max buyurtma miqdori</label>
                    <input type="number" step="1" name="max_order_amount" value="{{ $settings['max_order_amount'] ?? 100000 }}" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Min narx</label>
                    <input type="number" step="0.01" name="min_order_price" value="{{ $settings['min_order_price'] ?? 1 }}" class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Max narx</label>
                    <input type="number" step="1" name="max_order_price" value="{{ $settings['max_order_price'] ?? 1000000 }}" class="form-control">
                </div>
                <div class="form-group" style="grid-column: span 2;">
                    <label class="form-label">Texnik xizmat rejimi</label>
                    <select name="is_maintenance" class="form-control">
                        <option value="false" {{ ($settings['is_maintenance'] ?? 'false') == 'false' ? 'selected' : '' }}>O'chirilgan</option>
                        <option value="true" {{ ($settings['is_maintenance'] ?? 'false') == 'true' ? 'selected' : '' }}>Yoqilgan</option>
                    </select>
                </div>
            </div>
            <div style="margin-top: 20px;">
                <button type="submit" class="btn btn-primary btn-sm">Saqlash</button>
            </div>
        </form>
    </div>
</div>
@endsection
