@extends('admin.layouts.app')
@section('title', 'Birja Statistikasi')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.exchange.settings.index') }}">Birja</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Statistika</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.exchange.settings.index') }}" class="btn btn-outline btn-sm"><i class="fa fa-arrow-left"></i> Sozlamalar</a>
@endsection

@section('content')
<div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px;">
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <p style="font-size: 12px; color: var(--text-muted); text-transform: uppercase; margin-bottom: 4px;">Hajm (24s)</p>
            <p style="font-size: 24px; font-weight: 700; color: var(--text-primary); margin: 0;">{{ number_format($volume24h, 2) }}</p>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <p style="font-size: 12px; color: var(--text-muted); text-transform: uppercase; margin-bottom: 4px;">Komissiyalar</p>
            <p style="font-size: 24px; font-weight: 700; color: var(--success); margin: 0;">{{ number_format($totalFees, 2) }}</p>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <p style="font-size: 12px; color: var(--text-muted); text-transform: uppercase; margin-bottom: 4px;">Faol foydalanuvchilar</p>
            <p style="font-size: 24px; font-weight: 700; color: var(--info); margin: 0;">{{ $activeUsers }}</p>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <p style="font-size: 12px; color: var(--text-muted); text-transform: uppercase; margin-bottom: 4px;">Buyurtmalar</p>
            <p style="font-size: 24px; font-weight: 700; color: var(--text-primary); margin: 0;">{{ $totalOrders }}</p>
        </div>
    </div>
    <div class="admin-card">
        <div class="admin-card-body" style="text-align: center;">
            <p style="font-size: 12px; color: var(--text-muted); text-transform: uppercase; margin-bottom: 4px;">Savdolar</p>
            <p style="font-size: 24px; font-weight: 700; color: var(--primary-light); margin: 0;">{{ $totalTrades }}</p>
        </div>
    </div>
</div>
@endsection
