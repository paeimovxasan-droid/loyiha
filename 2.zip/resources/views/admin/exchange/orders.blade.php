@extends('admin.layouts.app')
@section('title', 'Birja Buyurtmalari')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.exchange.settings.index') }}">Birja</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Buyurtmalar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.exchange.settings.index') }}" class="btn btn-outline btn-sm"><i class="fa fa-arrow-left"></i> Sozlamalar</a>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Foydalanuvchi</th>
                        <th style="text-align: center;">Turi</th>
                        <th style="text-align: center;">Yo'nalish</th>
                        <th style="text-align: center;">Miqdor</th>
                        <th style="text-align: center;">Narx</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($orders as $order)
                    <tr>
                        <td style="color: var(--text-muted);">#{{ $order->id }}</td>
                        <td style="color: var(--text-primary);">{{ $order->user->name ?? '—' }}</td>
                        <td style="text-align: center;">
                            <span class="badge {{ $order->type == 'limit' ? 'badge-info' : 'badge-warning' }}">{{ ucfirst($order->type) }}</span>
                        </td>
                        <td style="text-align: center;">
                            <span style="font-weight: 600; color: {{ $order->side == 'buy' ? 'var(--success)' : 'var(--danger)' }};">{{ strtoupper($order->side) }}</span>
                        </td>
                        <td style="text-align: center;">{{ number_format($order->quantity, 4) }}</td>
                        <td style="text-align: center;">{{ $order->price ? number_format($order->price, 2) : 'Market' }}</td>
                        <td style="text-align: center;">
                            @if($order->status == 'open')
                                <span class="badge badge-primary">{{ ucfirst($order->status) }}</span>
                            @elseif($order->status == 'filled')
                                <span class="badge badge-success">{{ ucfirst($order->status) }}</span>
                            @elseif($order->status == 'cancelled')
                                <span class="badge badge-danger">{{ ucfirst($order->status) }}</span>
                            @elseif($order->status == 'partial')
                                <span class="badge badge-warning">{{ ucfirst($order->status) }}</span>
                            @else
                                <span class="badge badge-info">{{ ucfirst($order->status) }}</span>
                            @endif
                        </td>
                        <td style="text-align: center; color: var(--text-muted); font-size: 12px;">{{ $order->created_at->format('d.m.Y H:i') }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="8" style="text-align: center; padding: 40px; color: var(--text-muted);">Buyurtma topilmadi</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($orders->hasPages())
        <div class="pagination" style="padding: 12px 16px;">
            {{ $orders->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
