@extends('admin.layouts.app')
@section('title', 'Birja Savdolari')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.exchange.settings.index') }}">Birja</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Savdolar</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.exchange.settings.index') }}" class="btn btn-outline btn-sm"><i class="fa fa-arrow-left"></i> Sozlamalar</a>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Sotuvchi</th>
                        <th>Xaridor</th>
                        <th style="text-align: center;">Miqdor</th>
                        <th style="text-align: center;">Narx</th>
                        <th style="text-align: center;">Jami</th>
                        <th style="text-align: center;">Sana</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($trades as $trade)
                    <tr>
                        <td style="color: var(--text-muted);">#{{ $trade->id }}</td>
                        <td style="color: var(--text-primary);">{{ $trade->seller->name ?? '—' }}</td>
                        <td style="color: var(--text-primary);">{{ $trade->buyer->name ?? '—' }}</td>
                        <td style="text-align: center;">{{ number_format($trade->quantity, 4) }}</td>
                        <td style="text-align: center;">{{ number_format($trade->price, 2) }}</td>
                        <td style="text-align: center; font-weight: 600;">{{ number_format($trade->total, 2) }}</td>
                        <td style="text-align: center; color: var(--text-muted); font-size: 12px;">{{ $trade->created_at->format('d.m.Y H:i') }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-muted);">Savdo topilmadi</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if($trades->hasPages())
        <div class="pagination" style="padding: 12px 16px;">
            {{ $trades->withQueryString()->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
