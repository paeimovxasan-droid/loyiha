@extends('admin.layouts.app')
@section('title', 'Level Reytingi')

@section('breadcrumb')
    <a href="{{ route('admin.levels.leaderboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Level Reytingi</span>
@endsection

@section('content')
<div class="admin-card">
    <div class="admin-card-header">
        <h3 style="font-size: 14px; font-weight: 600; color: var(--text-primary);">🏆 Level Reytingi (Top 50)</h3>
    </div>
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">#</th>
                        <th>Foydalanuvchi</th>
                        <th style="text-align: center;">Level</th>
                        <th style="text-align: center;">Unvon</th>
                        <th style="text-align: right;">Jami XP</th>
                        <th style="text-align: right;">Progress</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($users as $i => $item)
                    <tr>
                        <td style="text-align: center; font-weight: 700; {{ $i === 0 ? 'color: #f59e0b;' : ($i === 1 ? 'color: #94a3b8;' : ($i === 2 ? 'color: #d97706;' : 'color: var(--text-muted);')) }}">
                            {{ $i < 3 ? ['🥇','🥈','🥉'][$i] : ($users->firstItem() + $i) }}
                        </td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 10px;">
                                <img src="{{ $item->user?->avatar_url }}" style="width: 32px; height: 32px; border-radius: 8px; object-fit: cover;">
                                <div>
                                    <div style="font-weight: 500; color: var(--text-primary);">{{ $item->user?->name }}</div>
                                    <div style="font-size: 12px; color: var(--text-muted);">{{ $item->user?->username ?? '—' }}</div>
                                </div>
                            </div>
                        </td>
                        <td style="text-align: center;">
                            <span class="badge" style="background: {{ $item->badge_color }}22; color: {{ $item->badge_color }}; font-weight: 700;">
                                Lv.{{ $item->level }}
                            </span>
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-secondary);">{{ $item->title }}</td>
                        <td style="text-align: right; font-weight: 600; color: var(--text-primary);">
                            {{ number_format($item->total_xp) }}
                        </td>
                        <td style="text-align: right;">
                            <div style="display: flex; align-items: center; justify-content: flex-end; gap: 8px;">
                                <div style="width: 80px; height: 6px; background: var(--border); border-radius: 3px; overflow: hidden;">
                                    <div style="height: 100%; border-radius: 3px; width: {{ $item->progress_percent }}%; background: {{ $item->badge_color }};"></div>
                                </div>
                                <span style="font-size: 12px; color: var(--text-muted);">{{ $item->progress_percent }}%</span>
                            </div>
                        </td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        @if($users->hasPages())
        <div style="padding: 12px 16px; border-top: 1px solid var(--border);">
            {{ $users->links() }}
        </div>
        @endif
    </div>
</div>
@endsection
