@extends('admin.layouts.app')

@section('title', 'Level Tizimi')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Level Tizimi</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.levels.leaderboard') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-trophy"></i> Reyting
    </a>
@endsection

@section('content')

{{-- Statistics --}}
<div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px;">
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--primary-light);">{{ number_format($stats['total_xp_awarded']) }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Jami berilgan XP</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--primary-light);">{{ $stats['avg_level'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">O'rtacha level</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--warning);">{{ $stats['max_level'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Eng yuqori level</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--success);">{{ $stats['level_dist']->count() }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Faol darajalar</div>
    </div>
</div>

{{-- Level Distribution Chart --}}
<div class="admin-card" style="margin-bottom: 24px;">
    <div style="padding: 20px;">
        <h3 style="font-size: 14px; font-weight: 700; color: var(--text-primary); margin-bottom: 16px;">
            Foydalanuvchilar daraja taqsimoti
        </h3>
        <div style="display: grid; gap: 8px;">
            @php $maxCnt = $stats['level_dist']->max('cnt') ?: 1; @endphp
            @foreach($stats['level_dist'] as $dist)
            @php
                [$title, $color] = \App\Models\Level\UserLevel::getTitleAndColor($dist->level);
                $pct = round($dist->cnt / $maxCnt * 100);
            @endphp
            <div style="display: flex; align-items: center; gap: 12px;">
                <div style="width: 60px; text-align: right; font-size: 12px; font-weight: 700; color: {{ $color }}; flex-shrink: 0;">
                    Lv.{{ $dist->level }}
                </div>
                <div style="flex: 1; height: 22px; background: var(--border); border-radius: 11px; overflow: hidden;">
                    <div style="height: 100%; border-radius: 11px; display: flex; align-items: center; padding-left: 8px; font-size: 11px; color: #fff; font-weight: 700; width: {{ max($pct, 3) }}%; background: {{ $color }}; min-width: 24px;">
                        {{ $dist->cnt }}
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</div>

{{-- Level Configurations Table --}}
<div style="margin-bottom: 16px;">
    <h2 style="font-size: 18px; font-weight: 700; color: var(--text-primary);">Level konfiguratsiyalari</h2>
</div>

<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Level</th>
                    <th>Unvon</th>
                    <th style="text-align: right;">Kerakli XP</th>
                    <th style="text-align: center;">Ref bonus</th>
                    <th style="text-align: center;">Cashback</th>
                    <th style="text-align: center;">Mining+</th>
                    <th style="text-align: center;">P2P</th>
                    <th style="text-align: center;">Karta</th>
                </tr>
            </thead>
            <tbody>
                @foreach($configs as $cfg)
                <tr>
                    <td>
                        <span style="display: inline-flex; align-items: center; gap: 6px; padding: 4px 10px; border-radius: 8px; font-size: 12px; font-weight: 700; background: {{ $cfg->badge_color }}22; color: {{ $cfg->badge_color }};">
                            {{ $cfg->badge_icon }} Lv.{{ $cfg->level }}
                        </span>
                    </td>
                    <td>
                        <span style="font-size: 13px; color: var(--text-secondary);">{{ $cfg->title_uz ?? $cfg->title }}</span>
                    </td>
                    <td style="text-align: right;">
                        <span style="font-size: 12px; font-family: monospace; color: var(--text-muted);">{{ number_format($cfg->xp_required) }}</span>
                    </td>
                    <td style="text-align: center;">
                        <span style="font-size: 12px; font-weight: 600; color: var(--primary-light);">
                            {{ $cfg->ref_bonus_percent > 0 ? '+' . $cfg->ref_bonus_percent . '%' : '—' }}
                        </span>
                    </td>
                    <td style="text-align: center;">
                        <span style="font-size: 12px; font-weight: 600; color: var(--success);">
                            {{ $cfg->cashback_percent > 0 ? $cfg->cashback_percent . '%' : '—' }}
                        </span>
                    </td>
                    <td style="text-align: center;">
                        <span style="font-size: 12px; font-weight: 600; color: var(--warning);">
                            {{ $cfg->daily_mining_bonus > 0 ? '+' . $cfg->daily_mining_bonus . '%' : '—' }}
                        </span>
                    </td>
                    <td style="text-align: center;">
                        @if($cfg->p2p_unlocked)
                        <i class="fa fa-check" style="color: var(--success);"></i>
                        @else
                        <i class="fa fa-lock" style="color: var(--text-muted); opacity: .5;"></i>
                        @endif
                    </td>
                    <td style="text-align: center;">
                        @if($cfg->virtual_card_unlocked)
                        <i class="fa fa-check" style="color: var(--success);"></i>
                        @else
                        <i class="fa fa-lock" style="color: var(--text-muted); opacity: .5;"></i>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>

@endsection
