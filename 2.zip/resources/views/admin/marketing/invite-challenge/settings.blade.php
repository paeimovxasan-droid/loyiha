@extends('admin.layouts.app')
@section('title', 'Invite Challenge')
@section('content')
<div class="flex items-center justify-between py-5 lg:py-6">
    <h2 class="text-xl font-medium text-slate-800 dark:text-navy-50 lg:text-2xl">🎯 Invite Challenge Sozlamalari</h2>
</div>

@if(session('success'))
<div class="alert mb-4 flex rounded-lg border border-success/30 bg-success/10 px-4 py-4 text-success">{{ session('success') }}</div>
@endif

<div class="rounded-2xl bg-white shadow dark:bg-navy-700 p-6 max-w-lg">
    <form method="POST" action="{{ route('admin.marketing.invite-challenge.update') }}">
        @csrf @method('PUT')
        <div class="space-y-4">
            <label class="block">
                <span class="text-sm text-slate-600 dark:text-navy-200">Davomiyligi (kun)</span>
                <input type="number" name="duration_days" value="{{ $settings->duration_days }}" class="form-input mt-1.5 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450 dark:bg-navy-700">
            </label>
            <label class="block">
                <span class="text-sm text-slate-600 dark:text-navy-200">Maqsad referrallar soni</span>
                <input type="number" name="target_referrals" value="{{ $settings->target_referrals }}" class="form-input mt-1.5 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450 dark:bg-navy-700">
            </label>
            <label class="block">
                <span class="text-sm text-slate-600 dark:text-navy-200">Mukofot (AIS)</span>
                <input type="number" step="0.01" name="reward_ais" value="{{ $settings->reward_ais }}" class="form-input mt-1.5 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450 dark:bg-navy-700">
            </label>
            <label class="inline-flex items-center space-x-2">
                <input type="hidden" name="min_deposit_required" value="0">
                <input type="checkbox" name="min_deposit_required" value="1" {{ $settings->min_deposit_required ? 'checked' : '' }} class="form-checkbox is-basic h-5 w-5 rounded border-slate-400/70 checked:border-primary checked:bg-primary dark:border-navy-400 dark:checked:border-accent dark:checked:bg-accent">
                <span class="text-sm text-slate-600 dark:text-navy-200">Min depozit talab qilinadi</span>
            </label>
        </div>
        <button type="submit" class="btn mt-6 bg-primary text-white hover:bg-primary-focus px-6">Saqlash</button>
    </form>
</div>
@endsection
