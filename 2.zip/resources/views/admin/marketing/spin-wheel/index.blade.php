@extends('admin.layouts.app')
@section('title', 'Spin Wheel')
@section('content')

<div class="flex items-center justify-between py-5 lg:py-6">
    <h2 class="text-xl font-medium text-slate-800 dark:text-navy-50 lg:text-2xl">🎡 Spin Wheel Boshqaruvi</h2>
</div>

{{-- Statistika --}}
<div class="grid grid-cols-3 gap-4 mb-5">
    <div class="card p-4 text-center">
        <div class="text-2xl font-bold text-primary">{{ number_format($totalSpins) }}</div>
        <div class="text-xs text-slate-400 mt-1">Jami spinlar</div>
    </div>
    <div class="card p-4 text-center">
        <div class="text-2xl font-bold text-warning">{{ number_format($todaySpins) }}</div>
        <div class="text-xs text-slate-400 mt-1">Bugungi spinlar</div>
    </div>
    <div class="card p-4 text-center">
        <div class="text-2xl font-bold text-success">{{ number_format($totalAisGiven, 2) }}</div>
        <div class="text-xs text-slate-400 mt-1">Jami berilgan AIS</div>
    </div>
</div>

@if(session('success'))
<div class="alert mb-4 flex rounded-lg border border-success/30 bg-success/10 px-4 py-4 text-success">
    <i class="fa fa-check-circle mr-2"></i> {{ session('success') }}
</div>
@endif

{{-- Yangi mukofot qo'shish --}}
<div class="card p-5 mb-5">
    <h3 class="font-semibold text-slate-700 dark:text-navy-100 mb-4">+ Yangi mukofot qo'shish</h3>
    <form method="POST" action="{{ route('admin.marketing.spin-wheel.store') }}">
        @csrf
        <div class="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            <div>
                <label class="block text-xs font-medium text-slate-500 mb-1">Turi *</label>
                <select name="type" class="form-select w-full text-sm" required>
                    <option value="ais">💰 AIS</option>
                    <option value="xp">⭐ XP</option>
                    <option value="lucky_ticket">🎫 Lucky Ticket</option>
                    <option value="nothing">❌ Hech narsa</option>
                </select>
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-500 mb-1">Qiymat *</label>
                <input type="number" name="value" step="0.01" min="0" value="0"
                       class="form-input w-full text-sm" required>
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-500 mb-1">Label (UZ) *</label>
                <input type="text" name="label_uz" class="form-input w-full text-sm"
                       placeholder="Masalan: 10 AIS" required>
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-500 mb-1">Og'irlik (1-1000) *</label>
                <input type="number" name="weight" min="1" max="1000" value="10"
                       class="form-input w-full text-sm" required>
                <p class="text-xs text-slate-400 mt-0.5">Yuqori = ko'p ehtimol</p>
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-500 mb-1">Rang</label>
                <input type="color" name="color" value="#6366f1"
                       class="form-input w-full h-9 p-1 text-sm">
            </div>
            <div>
                <label class="block text-xs font-medium text-slate-500 mb-1">Holat *</label>
                <select name="status" class="form-select w-full text-sm" required>
                    <option value="active">Faol</option>
                    <option value="inactive">Nofaol</option>
                </select>
            </div>
        </div>
        <div class="mt-3">
            <button type="submit" class="btn bg-primary text-white text-sm">
                <i class="fa fa-plus mr-1"></i> Qo'shish
            </button>
        </div>
    </form>
</div>

{{-- Mukofotlar jadvali --}}
<div class="card">
    <div class="p-4 border-b border-slate-200 dark:border-navy-500">
        <h3 class="font-semibold text-slate-700 dark:text-navy-100">Mukofotlar ro'yxati</h3>
        <p class="text-xs text-slate-400 mt-1">Og'irlik qanchalik yuqori bo'lsa, ehtimollik shunchalik ko'p</p>
    </div>
    <div class="is-scrollbar-hidden min-w-full overflow-x-auto">
        <table class="is-hoverable w-full text-left">
            <thead>
                <tr>
                    <th class="whitespace-nowrap rounded-tl-lg bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 text-xs">#</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 text-xs">Turi</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 text-xs">Qiymat</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 text-xs">Label</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 text-xs">Og'irlik</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 text-xs">Ehtimollik</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 text-xs">Rang</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 text-xs">Holat</th>
                    <th class="whitespace-nowrap rounded-tr-lg bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 text-xs">Amallar</th>
                </tr>
            </thead>
            <tbody>
                @php $totalWeight = $prizes->sum('weight') ?: 1; @endphp
                @forelse($prizes as $prize)
                <tr class="border-y border-transparent border-b-slate-200 dark:border-b-navy-500" x-data="{ editing: false }">
                    {{-- Ko'rish holati --}}
                    <td class="px-4 py-3 text-sm text-slate-500" x-show="!editing">#{{ $prize->id }}</td>
                    <td class="px-4 py-3 text-sm font-medium" x-show="!editing">
                        @if($prize->type === 'ais') 💰 AIS
                        @elseif($prize->type === 'xp') ⭐ XP
                        @elseif($prize->type === 'lucky_ticket') 🎫 Lucky Ticket
                        @else ❌ Hech narsa
                        @endif
                    </td>
                    <td class="px-4 py-3 text-sm font-semibold" x-show="!editing">{{ number_format($prize->value, 2) }}</td>
                    <td class="px-4 py-3 text-sm" x-show="!editing">{{ $prize->getTranslation('label', 'uz') }}</td>
                    <td class="px-4 py-3 text-sm" x-show="!editing">{{ $prize->weight }}</td>
                    <td class="px-4 py-3 text-sm" x-show="!editing">
                        <div class="flex items-center gap-2">
                            <div class="h-1.5 bg-slate-200 rounded-full w-16 overflow-hidden">
                                <div class="h-full bg-primary rounded-full"
                                     style="width: {{ round($prize->weight / $totalWeight * 100, 1) }}%"></div>
                            </div>
                            <span class="text-xs text-slate-500">{{ round($prize->weight / $totalWeight * 100, 1) }}%</span>
                        </div>
                    </td>
                    <td class="px-4 py-3" x-show="!editing">
                        <div class="w-6 h-6 rounded-full border border-slate-300"
                             style="background:{{ $prize->color ?? '#6366f1' }}"></div>
                    </td>
                    <td class="px-4 py-3" x-show="!editing">
                        <span class="badge text-xs {{ $prize->status === 'active' ? 'bg-success/10 text-success' : 'bg-slate-200 text-slate-500' }}">
                            {{ $prize->status === 'active' ? 'Faol' : 'Nofaol' }}
                        </span>
                    </td>
                    <td class="px-4 py-3" x-show="!editing">
                        <div class="flex gap-2">
                            <button @click="editing = true"
                                    class="btn btn-sm bg-info/10 text-info hover:bg-info/20 px-2 text-xs">
                                ✏️
                            </button>
                            <form method="POST" action="{{ route('admin.marketing.spin-wheel.prize.destroy', $prize) }}">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-sm bg-error/10 text-error hover:bg-error/20 px-2 text-xs"
                                        onclick="return confirm('O\'chirasizmi?')">🗑️</button>
                            </form>
                        </div>
                    </td>

                    {{-- Tahrirlash holati --}}
                    <form method="POST" action="{{ route('admin.marketing.spin-wheel.prize.update', $prize) }}"
                          x-show="editing" style="display:contents">
                        @csrf @method('PUT')
                        <td class="px-2 py-2 text-xs text-slate-400">#{{ $prize->id }}</td>
                        <td class="px-2 py-2">
                            <select name="type" class="form-select text-xs w-28">
                                <option value="ais" {{ $prize->type==='ais'?'selected':'' }}>💰 AIS</option>
                                <option value="xp" {{ $prize->type==='xp'?'selected':'' }}>⭐ XP</option>
                                <option value="lucky_ticket" {{ $prize->type==='lucky_ticket'?'selected':'' }}>🎫 Ticket</option>
                                <option value="nothing" {{ $prize->type==='nothing'?'selected':'' }}>❌ Hech narsa</option>
                            </select>
                        </td>
                        <td class="px-2 py-2">
                            <input type="number" name="value" step="0.01" min="0"
                                   value="{{ $prize->value }}" class="form-input text-xs w-20">
                        </td>
                        <td class="px-2 py-2">
                            <input type="text" name="label_uz"
                                   value="{{ $prize->getTranslation('label', 'uz') }}"
                                   class="form-input text-xs w-24">
                        </td>
                        <td class="px-2 py-2">
                            <input type="number" name="weight" min="1" max="1000"
                                   value="{{ $prize->weight }}" class="form-input text-xs w-16">
                        </td>
                        <td class="px-2 py-2"></td>
                        <td class="px-2 py-2">
                            <input type="color" name="color" value="{{ $prize->color ?? '#6366f1' }}"
                                   class="form-input w-10 h-8 p-0.5">
                        </td>
                        <td class="px-2 py-2">
                            <select name="status" class="form-select text-xs w-24">
                                <option value="active" {{ $prize->status==='active'?'selected':'' }}>Faol</option>
                                <option value="inactive" {{ $prize->status!=='active'?'selected':'' }}>Nofaol</option>
                            </select>
                        </td>
                        <td class="px-2 py-2">
                            <div class="flex gap-1">
                                <button type="submit" class="btn btn-sm bg-success text-white px-2 text-xs">✓</button>
                                <button type="button" @click="editing = false"
                                        class="btn btn-sm bg-slate-200 text-slate-700 px-2 text-xs">✕</button>
                            </div>
                        </td>
                    </form>
                </tr>
                @empty
                <tr><td colspan="9" class="px-4 py-10 text-center text-slate-400">Mukofot topilmadi. Yuqoridan qo'shing.</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

{{-- G'ildirak preview --}}
<div class="card p-5 mt-5">
    <h3 class="font-semibold text-slate-700 dark:text-navy-100 mb-4">🎡 G'ildirak ko'rinishi</h3>
    <div style="display:flex; justify-content:center;">
        <canvas id="previewCanvas" width="280" height="280" style="border-radius:50%;"></canvas>
    </div>
</div>

<script>
const prizes = @json($prizes->where('status', 'active')->map(fn($p) => [
    'label'  => $p->getTranslation('label', 'uz') ?: ($p->type === 'ais' ? $p->value.' AIS' : ($p->type === 'xp' ? $p->value.' XP' : ($p->type === 'lucky_ticket' ? 'Chipta' : 'Omad yo\'q'))),
    'color'  => $p->color ?? '#6366f1',
    'weight' => $p->weight,
])->values());

const canvas = document.getElementById('previewCanvas');
const ctx = canvas.getContext('2d');
const cx = canvas.width / 2, cy = canvas.height / 2, r = cx - 6;

if (prizes.length) {
    const total = prizes.reduce((s, p) => s + (p.weight || 1), 0);
    let start = -Math.PI / 2;
    prizes.forEach(p => {
        const slice = (p.weight || 1) / total * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, r, start, start + slice);
        ctx.closePath();
        ctx.fillStyle = p.color;
        ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,.2)';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(start + slice / 2);
        ctx.textAlign = 'right';
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 11px Inter, sans-serif';
        ctx.shadowColor = 'rgba(0,0,0,.5)';
        ctx.shadowBlur = 3;
        ctx.fillText(p.label, r - 8, 4);
        ctx.restore();
        start += slice;
    });

    ctx.beginPath();
    ctx.arc(cx, cy, 16, 0, Math.PI * 2);
    ctx.fillStyle = '#1e293b';
    ctx.fill();
} else {
    ctx.fillStyle = '#334155';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#64748b';
    ctx.font = '14px Inter';
    ctx.textAlign = 'center';
    ctx.fillText('Mukofot yo\'q', cx, cy);
}
</script>
@endsection
