@extends('admin.layouts.app')
@section('title', 'Mavsumiy Tadbirlar')
@section('content')
<div class="flex items-center justify-between py-5 lg:py-6">
    <h2 class="text-xl font-medium text-slate-800 dark:text-navy-50 lg:text-2xl">🎉 Mavsumiy Tadbirlar</h2>
</div>

@if(session('success'))
<div class="alert mb-4 flex rounded-lg border border-success/30 bg-success/10 px-4 py-4 text-success">{{ session('success') }}</div>
@endif

<div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
    <div class="lg:col-span-2 rounded-2xl bg-white shadow dark:bg-navy-700 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead>
                    <tr class="border-b border-slate-200 dark:border-navy-500">
                        <th class="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Nomi</th>
                        <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Boshlanish</th>
                        <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Tugash</th>
                        <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Holat</th>
                        <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Amallar</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-navy-600">
                    @forelse($events as $event)
                    <tr class="hover:bg-slate-50 dark:hover:bg-navy-600">
                        <td class="px-4 py-3 font-medium text-slate-700 dark:text-navy-100">{{ is_array($event->name) ? ($event->name['uz'] ?? $event->name['en'] ?? '') : $event->name }}</td>
                        <td class="px-4 py-3 text-center text-xs">{{ $event->starts_at?->format('d.m.Y') }}</td>
                        <td class="px-4 py-3 text-center text-xs">{{ $event->ends_at?->format('d.m.Y') }}</td>
                        <td class="px-4 py-3 text-center"><span class="badge rounded-full px-2 py-0.5 text-xs {{ $event->status == 'active' ? 'bg-success/10 text-success' : 'bg-slate-200 text-slate-500' }}">{{ ucfirst($event->status) }}</span></td>
                        <td class="px-4 py-3 text-center">
                            <form method="POST" action="{{ route('admin.marketing.events.destroy', $event->id) }}" class="inline">
                                @csrf @method('DELETE')
                                <button class="btn btn-sm h-7 bg-error/10 text-error hover:bg-error/20 px-2 text-xs" onclick="return confirm('O\'chirishni tasdiqlaysizmi?')"><i class="fa fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="5" class="px-4 py-10 text-center text-slate-400">Tadbir topilmadi</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="px-4 py-3">{{ $events->links() }}</div>
    </div>

    <div class="rounded-2xl bg-white shadow dark:bg-navy-700 p-5">
        <h3 class="text-base font-semibold text-slate-700 dark:text-navy-100 mb-4">Yangi tadbir</h3>
        <form method="POST" action="{{ route('admin.marketing.events.store') }}">
            @csrf
            <div class="space-y-3">
                <label class="block">
                    <span class="text-sm text-slate-600 dark:text-navy-200">Nomi</span>
                    <input type="text" name="name" required class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450 dark:bg-navy-700">
                </label>
                <label class="block">
                    <span class="text-sm text-slate-600 dark:text-navy-200">Tavsif</span>
                    <textarea name="description" rows="2" class="form-textarea mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450 dark:bg-navy-700"></textarea>
                </label>
                <label class="block">
                    <span class="text-sm text-slate-600 dark:text-navy-200">Boshlanish</span>
                    <input type="date" name="starts_at" required class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450 dark:bg-navy-700">
                </label>
                <label class="block">
                    <span class="text-sm text-slate-600 dark:text-navy-200">Tugash</span>
                    <input type="date" name="ends_at" required class="form-input mt-1 w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 dark:border-navy-450 dark:bg-navy-700">
                </label>
                <button type="submit" class="btn w-full bg-primary text-white hover:bg-primary-focus">Yaratish</button>
            </div>
        </form>
    </div>
</div>
@endsection
