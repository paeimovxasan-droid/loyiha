@extends('admin.layouts.app')
@section('title', 'VIP Sozlamalari')
@section('content')
<div class="flex items-center justify-between py-5 lg:py-6">
    <h2 class="text-xl font-medium text-slate-800 dark:text-navy-50 lg:text-2xl">👑 VIP Daraja Sozlamalari</h2>
</div>

@if(session('success'))
<div class="alert mb-4 flex rounded-lg border border-success/30 bg-success/10 px-4 py-4 text-success">{{ session('success') }}</div>
@endif

<div class="rounded-2xl bg-white shadow dark:bg-navy-700 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="border-b border-slate-200 dark:border-navy-500">
                    <th class="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Daraja</th>
                    <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Min AIS</th>
                    <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Min Referral</th>
                    <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Cashback %</th>
                    <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Chegirma %</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 dark:divide-navy-600">
                @forelse($tiers as $tier)
                <tr class="hover:bg-slate-50 dark:hover:bg-navy-600">
                    <td class="px-4 py-3 font-semibold text-slate-700 dark:text-navy-100">{{ ucfirst($tier->tier) }}</td>
                    <td class="px-4 py-3 text-center">{{ number_format($tier->min_ais_earned) }}</td>
                    <td class="px-4 py-3 text-center">{{ $tier->min_referrals }}</td>
                    <td class="px-4 py-3 text-center text-success font-semibold">{{ $tier->cashback_percent }}%</td>
                    <td class="px-4 py-3 text-center text-info font-semibold">{{ $tier->fee_discount_percent }}%</td>
                </tr>
                @empty
                <tr><td colspan="5" class="px-4 py-10 text-center text-slate-400">VIP daraja topilmadi</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
