@extends('admin.layouts.app')
@section('title', 'Promo-kod Statistikasi')
@section('content')
<div class="flex items-center justify-between py-5 lg:py-6">
    <h2 class="text-xl font-medium text-slate-800 dark:text-navy-50 lg:text-2xl">📊 Promo-kod: {{ $promo->code }}</h2>
    <a href="{{ route('admin.marketing.promo-codes.index') }}" class="btn h-9 bg-slate-150 text-slate-800 dark:bg-navy-500 dark:text-navy-100 px-4"><i class="fa fa-arrow-left mr-1"></i> Orqaga</a>
</div>

<div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
    @foreach($stats as $key => $value)
    <div class="rounded-2xl bg-white shadow dark:bg-navy-700 p-5 text-center">
        <p class="text-xs text-slate-400 uppercase mb-1">{{ str_replace('_', ' ', ucfirst($key)) }}</p>
        <p class="text-2xl font-bold text-slate-700 dark:text-navy-100">{{ is_numeric($value) ? number_format($value) : $value }}</p>
    </div>
    @endforeach
</div>
@endsection
