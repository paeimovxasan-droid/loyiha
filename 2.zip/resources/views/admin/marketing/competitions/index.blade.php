@extends('admin.layouts.app')
@section('title', 'Musobaqalar')
@section('content')
<div class="flex items-center justify-between py-5 lg:py-6">
    <h2 class="text-xl font-medium text-slate-800 dark:text-navy-50 lg:text-2xl">🏆 Musobaqalar (Leaderboard)</h2>
</div>

@if(session('success'))
<div class="alert mb-4 flex rounded-lg border border-success/30 bg-success/10 px-4 py-4 text-success">{{ session('success') }}</div>
@endif

<h3 class="text-lg font-semibold text-slate-700 dark:text-navy-100 mb-3">Faol musobaqalar</h3>
<div class="rounded-2xl bg-white shadow dark:bg-navy-700 overflow-hidden mb-6">
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="border-b border-slate-200 dark:border-navy-500">
                    <th class="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Turi</th>
                    <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Boshlanish</th>
                    <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Tugash</th>
                    <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Holat</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 dark:divide-navy-600">
                @forelse($active as $comp)
                <tr>
                    <td class="px-4 py-3 font-medium text-slate-700 dark:text-navy-100">{{ ucfirst($comp->type) }}</td>
                    <td class="px-4 py-3 text-center text-xs">{{ $comp->starts_at?->format('d.m.Y') }}</td>
                    <td class="px-4 py-3 text-center text-xs">{{ $comp->ends_at?->format('d.m.Y') }}</td>
                    <td class="px-4 py-3 text-center"><span class="badge rounded-full px-2 py-0.5 text-xs bg-success/10 text-success">{{ ucfirst($comp->status) }}</span></td>
                </tr>
                @empty
                <tr><td colspan="4" class="px-4 py-6 text-center text-slate-400">Faol musobaqa yo'q</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

<h3 class="text-lg font-semibold text-slate-700 dark:text-navy-100 mb-3">Tarix</h3>
<div class="rounded-2xl bg-white shadow dark:bg-navy-700 overflow-hidden">
    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead>
                <tr class="border-b border-slate-200 dark:border-navy-500">
                    <th class="px-4 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Turi</th>
                    <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Davr</th>
                    <th class="px-4 py-3 text-center text-xs font-semibold text-slate-500 uppercase">Holat</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-slate-100 dark:divide-navy-600">
                @forelse($history as $comp)
                <tr>
                    <td class="px-4 py-3 font-medium text-slate-700 dark:text-navy-100">{{ ucfirst($comp->type) }}</td>
                    <td class="px-4 py-3 text-center text-xs">{{ $comp->starts_at?->format('d.m') }} — {{ $comp->ends_at?->format('d.m.Y') }}</td>
                    <td class="px-4 py-3 text-center"><span class="badge rounded-full px-2 py-0.5 text-xs bg-slate-200 text-slate-500">Yakunlangan</span></td>
                </tr>
                @empty
                <tr><td colspan="3" class="px-4 py-6 text-center text-slate-400">Tarix bo'sh</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
