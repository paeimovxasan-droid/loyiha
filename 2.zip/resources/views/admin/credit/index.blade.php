@extends('admin.layouts.app')
@section('title', 'Mikro-kreditlar')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Mikro-kreditlar</span>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div class="admin-card-body" style="padding: 0;">
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th style="text-align: left;">ID</th>
                        <th style="text-align: left;">Foydalanuvchi</th>
                        <th style="text-align: center;">Miqdor</th>
                        <th style="text-align: center;">Foiz</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Muddat</th>
                        <th style="text-align: center;">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($credits as $credit)
                    <tr>
                        <td style="color: var(--text-muted);">#{{ $credit->id }}</td>
                        <td style="color: var(--text-primary);">{{ $credit->user->name ?? '—' }}</td>
                        <td style="text-align: center; font-weight: 600;">{{ number_format($credit->amount ?? 0, 2) }} AIS</td>
                        <td style="text-align: center;">{{ $credit->interest_rate ?? 0 }}%</td>
                        <td style="text-align: center;">
                            @php
                                $statusBadge = match($credit->status ?? 'pending') {
                                    'active' => 'badge-success',
                                    'pending' => 'badge-warning',
                                    'repaid' => 'badge-info',
                                    'overdue' => 'badge-danger',
                                    default => 'badge-warning',
                                };
                            @endphp
                            <span class="badge {{ $statusBadge }}">{{ ucfirst($credit->status ?? 'pending') }}</span>
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $credit->due_date ? \Carbon\Carbon::parse($credit->due_date)->format('d.m.Y') : '—' }}</td>
                        <td style="text-align: center;">
                            <a href="{{ route('admin.credits.edit', $credit) }}" class="btn btn-outline btn-sm">
                                <i class="fa fa-pen"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">
                            <i class="fa fa-credit-card" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                            Kredit topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
    <div class="pagination" style="padding: 12px 16px; border-top: 1px solid var(--border);">{{ $credits->withQueryString()->links() }}</div>
</div>
@endsection
