@extends('admin.layouts.app')
@section('title', 'Kredit tahrirlash')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<a href="{{ route('admin.credits.index') }}">Mikro-kreditlar</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">Tahrirlash #{{ $credit->id }}</span>
@endsection

@section('header-actions')
<a href="{{ route('admin.credits.index') }}" class="btn btn-outline btn-sm">
    <i class="fa fa-arrow-left"></i> Orqaga
</a>
@endsection

@section('content')
@if($errors->any())
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid var(--danger); color: var(--danger); margin-bottom: 16px;">
    <ul style="margin: 0; padding-left: 16px;">
        @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
    </ul>
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">Kredit ma'lumotlari</div>
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.credits.update', $credit) }}">
            @csrf
            @method('PUT')
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label">Foydalanuvchi</label>
                    <input type="text" value="{{ $credit->user->name ?? '—' }}" disabled class="form-control" style="background: var(--primary-light);">
                </div>
                <div class="form-group">
                    <label class="form-label">Miqdor (AIS)</label>
                    <input type="number" step="0.01" name="amount" value="{{ old('amount', $credit->amount) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Foiz stavkasi (%)</label>
                    <input type="number" step="0.01" name="interest_rate" value="{{ old('interest_rate', $credit->interest_rate) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Muddat (kun)</label>
                    <input type="number" name="term_days" value="{{ old('term_days', $credit->term_days) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Holat</label>
                    <select name="status" class="form-control">
                        @foreach(['pending','active','repaid','overdue','defaulted'] as $s)
                        <option value="{{ $s }}" {{ old('status', $credit->status) == $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">To'lov sanasi</label>
                    <input type="date" name="due_date" value="{{ old('due_date', $credit->due_date ? \Carbon\Carbon::parse($credit->due_date)->format('Y-m-d') : '') }}" class="form-control">
                </div>
            </div>
            <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i> Yangilash
                </button>
            </div>
        </form>
    </div>
</div>
@endsection
