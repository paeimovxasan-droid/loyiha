@extends('admin.layouts.app')
@section('title', 'FAQ')

@section('breadcrumb')
<a href="{{ route('admin.dashboard') }}">Admin</a>
<i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
<span class="current">FAQ</span>
@endsection

@section('content')
@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid var(--success); color: var(--success); margin-bottom: 16px; display: flex; align-items: center; gap: 8px;">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 16px;">
    {{-- FAQ jadvali --}}
    <div class="admin-card">
        <div class="admin-card-body" style="padding: 0;">
            <div style="overflow-x: auto;">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th style="text-align: left;">Savol</th>
                            <th style="text-align: center;">Kategoriya</th>
                            <th style="text-align: center;">Holat</th>
                            <th style="text-align: center;">Amallar</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($faqs as $faq)
                        <tr>
                            <td>
                                <div style="font-weight: 500; color: var(--text-primary);">{{ $faq->question }}</div>
                                <div style="font-size: 12px; color: var(--text-muted); max-width: 300px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ Str::limit($faq->answer, 60) }}</div>
                            </td>
                            <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $faq->category ?? '—' }}</td>
                            <td style="text-align: center;">
                                @if($faq->is_active ?? true)
                                <span class="badge badge-success">Faol</span>
                                @else
                                <span class="badge badge-warning">O'chirilgan</span>
                                @endif
                            </td>
                            <td style="text-align: center;">
                                <form method="POST" action="{{ route('admin.faq.destroy', $faq) }}" style="display: inline;">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('O\'chirishni tasdiqlaysizmi?')">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="4" style="text-align: center; padding: 40px 16px; color: var(--text-muted);">FAQ topilmadi</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        <div class="pagination" style="padding: 12px 16px; border-top: 1px solid var(--border);">{{ $faqs->links() }}</div>
    </div>

    {{-- Yangi FAQ formasi --}}
    <div class="admin-card">
        <div class="admin-card-header">Yangi FAQ</div>
        <div class="admin-card-body">
            <form method="POST" action="{{ route('admin.faq.store') }}">
                @csrf
                <div class="form-group">
                    <label class="form-label">Savol</label>
                    <input type="text" name="question" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Javob</label>
                    <textarea name="answer" rows="3" required class="form-control"></textarea>
                </div>
                <div class="form-group">
                    <label class="form-label">Kategoriya</label>
                    <input type="text" name="category" class="form-control" placeholder="Umumiy">
                </div>
                <div class="form-group">
                    <label class="form-label">Kalit so'zlar</label>
                    <input type="text" name="keywords" class="form-control" placeholder="parol, kirish, ro'yxat">
                </div>
                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    <i class="fa fa-plus"></i> Yaratish
                </button>
            </form>
        </div>
    </div>
</div>
@endsection
