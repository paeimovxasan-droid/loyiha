@extends('admin.layouts.app')
@section('title', __('translations.edit'))

@section('content')

<form method="POST" action="{{ route('admin.translations.update', $translation) }}">
    @csrf @method('PUT')

    {{-- Page Header --}}
    <div class="flex flex-col items-center justify-between space-y-4 py-5 sm:flex-row sm:space-y-0 lg:py-6">
        <div class="flex items-center space-x-2">
            <i class="fa fa-language text-xl text-slate-600 dark:text-navy-100"></i>
            <div>
                <h2 class="text-xl font-medium text-slate-700 dark:text-navy-50">{{ __('translations.edit') }}</h2>
                <div class="flex items-center gap-1.5 mt-0.5">
                    @if($translation->group)
                    <span class="badge rounded-full bg-primary/10 text-primary dark:bg-accent-light/10 dark:text-accent-light text-xs px-2 py-0.5">{{ $translation->group }}</span>
                    @endif
                    <code class="text-xs text-slate-400 dark:text-navy-400 font-mono">{{ $translation->key }}</code>
                </div>
            </div>
        </div>
        <div class="flex justify-center space-x-2">
            <button type="button"
                    onclick="event.preventDefault(); window.dispatchEvent(new CustomEvent('open-confirm-modal', { detail: { message: '{{ addslashes(__('messages.delete_confirm')) }}', form: document.getElementById('delete-form') } }));"
                    class="btn border border-error/30 font-medium text-error hover:bg-error/10 dark:border-error/30 dark:text-error dark:hover:bg-error/10">
                <i class="fa fa-trash mr-1.5 text-xs"></i> {{ __('buttons.delete') }}
            </button>
            <a href="{{ route('admin.translations.index') }}"
               class="btn min-w-[7rem] border border-slate-300 font-medium text-slate-700 hover:bg-slate-150 dark:border-navy-450 dark:text-navy-100 dark:hover:bg-navy-500">
                {{ __('buttons.cancel') }}
            </a>
            <button type="submit"
                    class="btn min-w-[7rem] bg-primary font-medium text-white hover:bg-primary-focus focus:bg-primary-focus dark:bg-accent dark:hover:bg-accent-focus">
                {{ __('buttons.update') }}
            </button>
        </div>
    </div>

    @if($errors->any())
    <div class="alert mb-5 flex rounded-lg bg-error/10 px-4 py-4 text-error sm:px-5">
        <i class="fa fa-exclamation-circle mr-2 mt-0.5 shrink-0"></i>
        <div>@foreach($errors->all() as $e)<p>{{ $e }}</p>@endforeach</div>
    </div>
    @endif

    <div class="grid grid-cols-12 gap-4 sm:gap-5 lg:gap-6">

        {{-- Left: texts --}}
        <div class="col-span-12 lg:col-span-8">
            <div class="card p-4 sm:p-5">
                <p class="text-base font-medium text-slate-700 dark:text-navy-100 mb-4">{{ __('translations.title') }}</p>

                <div x-data="{ tab: 'uz' }">
                    <div class="flex border-b border-slate-200 dark:border-navy-500 mb-4 space-x-1">
                        <button type="button" @click="tab = 'uz'"
                                :class="tab === 'uz' ? 'border-primary dark:border-accent text-primary dark:text-accent-light' : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-navy-300 dark:hover:text-navy-100'"
                                class="btn shrink-0 rounded-none border-b-2 px-4 py-2 font-medium">
                            🇺🇿 {{ __('payment_methods.uzbek') }}
                        </button>
                        <button type="button" @click="tab = 'ru'"
                                :class="tab === 'ru' ? 'border-primary dark:border-accent text-primary dark:text-accent-light' : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-navy-300 dark:hover:text-navy-100'"
                                class="btn shrink-0 rounded-none border-b-2 px-4 py-2 font-medium">
                            🇷🇺 {{ __('payment_methods.russian') }}
                        </button>
                        <button type="button" @click="tab = 'en'"
                                :class="tab === 'en' ? 'border-primary dark:border-accent text-primary dark:text-accent-light' : 'border-transparent text-slate-500 hover:text-slate-800 dark:text-navy-300 dark:hover:text-navy-100'"
                                class="btn shrink-0 rounded-none border-b-2 px-4 py-2 font-medium">
                            🇬🇧 {{ __('payment_methods.english') }}
                        </button>
                    </div>

                    {{-- UZ --}}
                    <div x-show="tab === 'uz'">
                        <label class="block">
                            <span class="font-medium text-slate-600 dark:text-navy-100">{{ __('translations.uz_text') }} <span class="text-error">*</span></span>
                            <span class="relative mt-1.5 flex">
                                <textarea name="text[uz]" rows="3" required
                                          class="form-textarea peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent @error('text.uz') border-error @enderror">{{ old('text.uz', $translation->text['uz'] ?? '') }}</textarea>
                                <span class="pointer-events-none absolute flex h-10 w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
                                    <span class="text-sm">🇺🇿</span>
                                </span>
                            </span>
                            @error('text.uz') <span class="text-tiny+ text-error mt-1 block">{{ $message }}</span> @enderror
                        </label>
                    </div>

                    {{-- RU --}}
                    <div x-show="tab === 'ru'" style="display:none">
                        <label class="block">
                            <span class="font-medium text-slate-600 dark:text-navy-100">{{ __('translations.ru_text') }}</span>
                            <span class="relative mt-1.5 flex">
                                <textarea name="text[ru]" rows="3"
                                          class="form-textarea peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent">{{ old('text.ru', $translation->text['ru'] ?? '') }}</textarea>
                                <span class="pointer-events-none absolute flex h-10 w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
                                    <span class="text-sm">🇷🇺</span>
                                </span>
                            </span>
                        </label>
                    </div>

                    {{-- EN --}}
                    <div x-show="tab === 'en'" style="display:none">
                        <label class="block">
                            <span class="font-medium text-slate-600 dark:text-navy-100">{{ __('translations.en_text') }}</span>
                            <span class="relative mt-1.5 flex">
                                <textarea name="text[en]" rows="3"
                                          class="form-textarea peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent">{{ old('text.en', $translation->text['en'] ?? '') }}</textarea>
                                <span class="pointer-events-none absolute flex h-10 w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
                                    <span class="text-sm">🇬🇧</span>
                                </span>
                            </span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        {{-- Right: group + key --}}
        <div class="col-span-12 lg:col-span-4 space-y-4">
            <div class="card p-4 sm:p-5">
                <p class="text-base font-medium text-slate-700 dark:text-navy-100 mb-4">{{ __('translations.identification') }}</p>

                <label class="block mb-4">
                    <span class="font-medium text-slate-600 dark:text-navy-100">{{ __('translations.group') }}</span>
                    <span class="relative mt-1.5 flex">
                        <input list="groups-list" name="group" value="{{ old('group', $translation->group) }}"
                               class="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent @error('group') border-error @enderror"
                               placeholder="buttons, auth ...">
                        <span class="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
                            <i class="fa fa-tag text-xs"></i>
                        </span>
                        <datalist id="groups-list">
                            @foreach($groups as $g)
                            <option value="{{ $g }}">
                            @endforeach
                        </datalist>
                    </span>
                </label>

                <label class="block">
                    <span class="font-medium text-slate-600 dark:text-navy-100">
                        {{ __('translations.key') }} <span class="text-error">*</span>
                    </span>
                    <span class="relative mt-1.5 flex">
                        <input name="key" value="{{ old('key', $translation->key) }}" required
                               class="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 font-mono placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent @error('key') border-error @enderror">
                        <span class="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
                            <i class="fa fa-key text-xs"></i>
                        </span>
                    </span>
                    @error('key') <span class="text-tiny+ text-error mt-1 block">{{ $message }}</span> @enderror
                </label>
            </div>
        </div>
    </div>
</form>

@endsection

{{-- Hidden Delete Form --}}
<form id="delete-form" method="POST" action="{{ route('admin.translations.destroy', $translation) }}" class="hidden">
    @csrf
    @method('DELETE')
</form>
