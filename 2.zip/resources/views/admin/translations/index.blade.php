@extends('admin.layouts.app')

@section('title', __('translations.title'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('translations.title') }}</span>
@endsection

@section('header-actions')
    <form method="POST" action="{{ route('admin.translations.clear-cache') }}" style="display: inline;">
        @csrf
        <button type="submit" class="btn btn-outline btn-sm">
            <i class="fa fa-rotate-right"></i> {{ __('translations.clear_cache') }}
        </button>
    </form>
    <a href="{{ route('admin.translations.create') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-plus"></i> {{ __('translations.create') }}
    </a>
@endsection

@section('content')

@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.3); color: var(--success); font-size: 13px; margin-bottom: 16px;">
    <i class="fa fa-check-circle" style="margin-right: 6px;"></i> {{ session('success') }}
</div>
@endif

{{-- Filter --}}
<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; flex-wrap: wrap; gap: 10px;">
    <div>
        <span style="font-size: 13px; color: var(--text-muted);">
            {{ __('translations.total') }}: <strong style="color: var(--text-primary);">{{ $translations->total() }}</strong> ta &middot; {{ __('translations.three_langs') }}
        </span>
    </div>
    <form method="GET" action="{{ route('admin.translations.index') }}" style="display: flex; gap: 8px; align-items: center;">
        <select name="group" class="form-control" style="width: 150px; padding: 7px 12px; font-size: 12px;">
            <option value="">— {{ __('translations.group') }} —</option>
            @foreach($groups as $g)
                <option value="{{ $g }}" {{ request('group') == $g ? 'selected' : '' }}>{{ $g }}</option>
            @endforeach
        </select>
        <input type="text" name="search" value="{{ request('search') }}" placeholder="{{ __('translations.search_hint') }}"
               class="form-control" style="width: 200px; padding: 7px 12px; font-size: 12px;">
        <button type="submit" class="btn btn-primary btn-sm">{{ __('buttons.search') }}</button>
        @if(request()->hasAny(['group','search']))
        <a href="{{ route('admin.translations.index') }}" class="btn btn-outline btn-sm">
            <i class="fa fa-times"></i> {{ __('buttons.clear') }}
        </a>
        @endif
    </form>
</div>

{{-- Table --}}
<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th style="width: 110px;">{{ __('translations.group') }}</th>
                    <th>{{ __('translations.key') }}</th>
                    <th>🇺🇿 {{ __('translations.uz_text') }}</th>
                    <th>🇷🇺 {{ __('translations.ru_text') }}</th>
                    <th>🇬🇧 {{ __('translations.en_text') }}</th>
                    <th style="text-align: right;">{{ __('table.actions') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($translations as $t)
                <tr>
                    <td>
                        @if($t->group)
                        <a href="{{ route('admin.translations.index', ['group' => $t->group]) }}">
                            <span class="badge badge-primary">{{ $t->group }}</span>
                        </a>
                        @else
                        <span style="color: var(--text-muted); font-size: 12px;">—</span>
                        @endif
                    </td>
                    <td>
                        <code style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 4px; padding: 2px 6px; font-size: 11px; font-family: monospace; color: var(--text-secondary);">{{ $t->key }}</code>
                    </td>
                    <td style="max-width: 200px;">
                        <span style="font-size: 13px; font-weight: 500; color: var(--text-primary); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="{{ $t->text['uz'] ?? '' }}">
                            {{ $t->text['uz'] ?? '—' }}
                        </span>
                    </td>
                    <td style="max-width: 180px;">
                        <span style="font-size: 12px; color: var(--text-secondary); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="{{ $t->text['ru'] ?? '' }}">
                            {{ $t->text['ru'] ?? '—' }}
                        </span>
                    </td>
                    <td style="max-width: 180px;">
                        <span style="font-size: 12px; color: var(--text-muted); display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="{{ $t->text['en'] ?? '' }}">
                            {{ $t->text['en'] ?? '—' }}
                        </span>
                    </td>
                    <td>
                        <div style="display: flex; align-items: center; justify-content: flex-end; gap: 4px;">
                            <a href="{{ route('admin.translations.edit', $t) }}" class="btn btn-outline btn-sm" title="{{ __('buttons.edit') }}">
                                <i class="fa fa-pen"></i>
                            </a>
                            <form method="POST" action="{{ route('admin.translations.destroy', $t) }}" style="margin: 0;"
                                  onsubmit="return confirm('{{ addslashes(__('messages.delete_confirm')) }}')">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" title="{{ __('buttons.delete') }}">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                        <i class="fa fa-language" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                        {{ __('translations.not_found') }}
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($translations->hasPages())
    <div style="padding: 14px 20px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between;">
        <span style="font-size: 12px; color: var(--text-muted);">
            {{ $translations->firstItem() }}–{{ $translations->lastItem() }} / <strong>{{ $translations->total() }}</strong> ta
        </span>
        <div class="pagination">
            @if(!$translations->onFirstPage())
            <a href="{{ $translations->previousPageUrl() }}"><i class="fa fa-chevron-left" style="font-size: 10px;"></i></a>
            @endif
            @foreach($translations->getUrlRange(max(1, $translations->currentPage()-2), min($translations->lastPage(), $translations->currentPage()+2)) as $page => $url)
                @if($page == $translations->currentPage())
                <span class="active"><span>{{ $page }}</span></span>
                @else
                <a href="{{ $url }}">{{ $page }}</a>
                @endif
            @endforeach
            @if($translations->hasMorePages())
            <a href="{{ $translations->nextPageUrl() }}"><i class="fa fa-chevron-right" style="font-size: 10px;"></i></a>
            @endif
        </div>
    </div>
    @else
    <div style="padding: 12px 20px; border-top: 1px solid var(--border);">
        <span style="font-size: 12px; color: var(--text-muted);">{{ __('translations.total') }}: <strong>{{ $translations->total() }}</strong> ta</span>
    </div>
    @endif
</div>

@endsection
