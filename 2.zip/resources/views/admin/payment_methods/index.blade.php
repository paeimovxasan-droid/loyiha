@extends('admin.layouts.app')

@section('title', __('payment_methods.title'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('payment_methods.title') }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.payment_methods.create') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-plus"></i> {{ __('buttons.add_new') }}
    </a>
@endsection

@section('content')

<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
    <h2 style="font-size: 18px; font-weight: 700; color: var(--text-primary);">{{ __('payment_methods.card_types') }}</h2>
</div>

<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>{{ __('payment_methods.main_image') }}</th>
                    <th>{{ __('payment_methods.name') }}</th>
                    <th>{{ __('payment_methods.number_card') }}</th>
                    <th>{{ __('payment_methods.limits') }}</th>
                    <th>{{ __('table.status') }}</th>
                    <th>{{ __('table.actions') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($methods as $method)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>
                        @if($method->photo_url)
                            <img src="{{ $method->photo_url }}" alt="Rasm" style="width: 36px; height: 36px; border-radius: 8px; object-fit: cover; border: 1px solid var(--border);">
                        @else
                            <span style="font-size: 12px; color: var(--text-muted);">{{ __('payment_methods.no_image') }}</span>
                        @endif
                    </td>
                    <td>
                        <span style="font-size: 13px; font-weight: 600; color: var(--text-primary);">{{ $method->getTranslation('name', 'uz') }}</span>
                    </td>
                    <td>
                        <span class="badge badge-info">{{ $method->number ?? 'N/A' }}</span>
                    </td>
                    <td>
                        <div style="font-size: 11px; line-height: 1.8;">
                            <div><i class="fa fa-arrow-down" style="color: var(--success); margin-right: 4px;"></i> {{ number_format($method->minimum_deposit, 0, '.', ' ') }} - {{ number_format($method->maximum_deposit, 0, '.', ' ') }}</div>
                            <div><i class="fa fa-arrow-up" style="color: var(--danger); margin-right: 4px;"></i> {{ number_format($method->minimum_withdraw, 0, '.', ' ') }} - {{ number_format($method->maximum_withdraw, 0, '.', ' ') }}</div>
                        </div>
                    </td>
                    <td>
                        @if($method->status == 'active')
                            <span class="badge badge-success">{{ __('status.active') }}</span>
                        @else
                            <span class="badge badge-warning">{{ __('status.inactive') }}</span>
                        @endif
                    </td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 4px;">
                            <a href="{{ route('admin.payment_methods.edit', $method) }}" class="btn btn-outline btn-sm" title="{{ __('buttons.edit') }}">
                                <i class="fa fa-pen"></i>
                            </a>
                            <form action="{{ route('admin.payment_methods.destroy', $method) }}" method="POST" style="margin: 0;"
                                  onsubmit="return confirm('{{ addslashes(__('messages.confirm_action')) }}')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" title="{{ __('buttons.delete') }}">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align: center; padding: 32px; color: var(--text-muted);">
                        <i class="fa fa-credit-card" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                        {{ __('table.not_found') }}
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

@endsection
