@extends('admin.layouts.app')

@section('title', __('payment_methods.add_title'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.payment_methods.index') }}">{{ __('payment_methods.title') }}</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('buttons.add_new') }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.payment_methods.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> {{ __('buttons.cancel') }}
    </a>
    <button type="submit" form="payment-method-form" class="btn btn-primary btn-sm">
        <i class="fa fa-save"></i> {{ __('buttons.save') }}
    </button>
@endsection

@section('content')

<form id="payment-method-form" action="{{ route('admin.payment_methods.store') }}" method="POST" enctype="multipart/form-data">
    @csrf

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
        {{-- Left Column --}}
        <div>
            {{-- Basic Info --}}
            <div class="admin-card" style="margin-bottom: 20px;">
                <div class="admin-card-header">
                    <span class="admin-card-title"><i class="fa fa-info-circle" style="margin-right: 6px; color: var(--primary-light);"></i> {{ __('payment_methods.basic_info') }}</span>
                </div>
                <div class="admin-card-body">
                    {{-- Language Tabs --}}
                    <div style="margin-bottom: 20px;">
                        <div style="display: flex; gap: 4px; border-bottom: 1px solid var(--border); margin-bottom: 16px;">
                            <button type="button" class="tab-btn active" onclick="switchTab(this, 'tab-uz')">{{ __('payment_methods.uzbek') }}</button>
                            <button type="button" class="tab-btn" onclick="switchTab(this, 'tab-ru')">{{ __('payment_methods.russian') }}</button>
                            <button type="button" class="tab-btn" onclick="switchTab(this, 'tab-en')">{{ __('payment_methods.english') }}</button>
                        </div>

                        <div id="tab-uz" class="tab-content">
                            <div class="form-group">
                                <label class="form-label">{{ __('payment_methods.name_uz') }} <span style="color: var(--danger);">*</span></label>
                                <input name="name[uz]" type="text" value="{{ old('name.uz') }}" required class="form-control" placeholder="Masalan: Uzcard / Humo / ...">
                                @error('name.uz') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                            </div>
                        </div>
                        <div id="tab-ru" class="tab-content" style="display: none;">
                            <div class="form-group">
                                <label class="form-label">{{ __('payment_methods.name_ru') }}</label>
                                <input name="name[ru]" type="text" value="{{ old('name.ru') }}" class="form-control" placeholder="Например: Uzcard / Humo / ...">
                            </div>
                        </div>
                        <div id="tab-en" class="tab-content" style="display: none;">
                            <div class="form-group">
                                <label class="form-label">{{ __('payment_methods.name_en') }}</label>
                                <input name="name[en]" type="text" value="{{ old('name.en') }}" class="form-control" placeholder="For example: Uzcard / Humo / ...">
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label">{{ __('payment_methods.card_number_label') }}</label>
                        <input name="number" type="text" value="{{ old('number') }}" class="form-control" placeholder="8600 0000 0000 0000">
                        @error('number') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                    </div>

                    <div class="form-group" style="margin-top: 16px;">
                        <x-admin.file-upload
                            name="photo_id"
                            folder="payment-methods"
                            :label="__('payment_methods.image_logo')"
                        />
                        @error('photo_id') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>

            {{-- Deposit Settings --}}
            <div class="admin-card" style="margin-bottom: 20px;">
                <div class="admin-card-header">
                    <span class="admin-card-title"><i class="fa fa-arrow-down" style="margin-right: 6px; color: var(--success);"></i> {{ __('payment_methods.finance_deposit') }}</span>
                </div>
                <div class="admin-card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px;">
                        <div class="form-group">
                            <label class="form-label">{{ __('payment_methods.min_deposit') }}</label>
                            <input name="minimum_deposit" type="number" step="0.01" value="{{ old('minimum_deposit', 0) }}" required class="form-control">
                            @error('minimum_deposit') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                        </div>
                        <div class="form-group">
                            <label class="form-label">{{ __('payment_methods.max_deposit') }}</label>
                            <input name="maximum_deposit" type="number" step="0.01" value="{{ old('maximum_deposit', 100000000) }}" required class="form-control">
                            @error('maximum_deposit') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                        </div>
                        <div class="form-group">
                            <label class="form-label">{{ __('payment_methods.deposit_charge') }}</label>
                            <input name="deposit_charge_percent" type="number" step="0.01" value="{{ old('deposit_charge_percent', 0) }}" required class="form-control">
                            @error('deposit_charge_percent') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>
            </div>

            {{-- Withdraw Settings --}}
            <div class="admin-card">
                <div class="admin-card-header">
                    <span class="admin-card-title"><i class="fa fa-arrow-up" style="margin-right: 6px; color: var(--danger);"></i> {{ __('payment_methods.finance_withdraw') }}</span>
                </div>
                <div class="admin-card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px;">
                        <div class="form-group">
                            <label class="form-label">{{ __('payment_methods.min_withdraw') }}</label>
                            <input name="minimum_withdraw" type="number" step="0.01" value="{{ old('minimum_withdraw', 0) }}" required class="form-control">
                            @error('minimum_withdraw') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                        </div>
                        <div class="form-group">
                            <label class="form-label">{{ __('payment_methods.max_withdraw') }}</label>
                            <input name="maximum_withdraw" type="number" step="0.01" value="{{ old('maximum_withdraw', 100000000) }}" required class="form-control">
                            @error('maximum_withdraw') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                        </div>
                        <div class="form-group">
                            <label class="form-label">{{ __('payment_methods.withdraw_charge') }}</label>
                            <input name="withdraw_charge_percent" type="number" step="0.01" value="{{ old('withdraw_charge_percent', 0) }}" required class="form-control">
                            @error('withdraw_charge_percent') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Right Column --}}
        <div>
            <div class="admin-card">
                <div class="admin-card-header">
                    <span class="admin-card-title"><i class="fa fa-cog" style="margin-right: 6px; color: var(--text-muted);"></i> {{ __('payment_methods.settings') }}</span>
                </div>
                <div class="admin-card-body">
                    <div class="form-group">
                        <label class="form-label">{{ __('admins.status') }} <span style="color: var(--danger);">*</span></label>
                        <select name="status" class="form-control">
                            <option value="active" {{ old('status') == 'active' ? 'selected' : '' }}>{{ __('status.active') }}</option>
                            <option value="inactive" {{ old('status') == 'inactive' ? 'selected' : '' }}>{{ __('status.inactive') }}</option>
                        </select>
                        @error('status') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                    </div>

                    <div class="form-group" style="margin-top: 16px;">
                        <label class="form-label">{{ __('payment_methods.sort_order') }} <span style="color: var(--danger);">*</span></label>
                        <input name="sort_order" type="number" value="{{ old('sort_order', 0) }}" required class="form-control">
                        @error('sort_order') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
function switchTab(btn, tabId) {
    // Remove active from all tab buttons in same container
    btn.parentElement.querySelectorAll('.tab-btn').forEach(function(b) { b.classList.remove('active'); });
    btn.classList.add('active');

    // Hide all tab contents in same parent
    var container = btn.closest('.admin-card-body') || btn.closest('.admin-card');
    container.querySelectorAll('.tab-content').forEach(function(t) { t.style.display = 'none'; });
    document.getElementById(tabId).style.display = 'block';
}
</script>

<style>
.tab-btn {
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 500;
    color: var(--text-muted);
    background: none;
    border: none;
    border-bottom: 2px solid transparent;
    cursor: pointer;
    transition: all .2s;
}
.tab-btn:hover { color: var(--text-primary); }
.tab-btn.active {
    color: var(--primary-light);
    border-bottom-color: var(--primary-light);
}
</style>

@endsection
