@extends('admin.layouts.app')

@section('title', __('packages.title'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('packages.title') }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.packages.create') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-plus"></i> {{ __('packages.create') }}
    </a>
@endsection

@section('content')

<div style="margin-bottom: 16px;">
    <h2 style="font-size: 18px; font-weight: 700; color: var(--text-primary);">{{ __('packages.title') }}</h2>
</div>

<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>{{ __('packages.name') }}</th>
                    <th>{{ __('packages.price') }}</th>
                    <th>{{ __('packages.daily_profit') }}</th>
                    <th>{{ __('packages.validity') }}</th>
                    <th>{{ __('table.status') }}</th>
                    <th>{{ __('table.actions') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($packages as $package)
                <tr>
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            @if($package->photo_url)
                            <img src="{{ $package->photo_url }}" alt="" style="width: 40px; height: 40px; border-radius: 8px; object-fit: cover;">
                            @else
                            <div style="width: 40px; height: 40px; border-radius: 8px; background: linear-gradient(135deg, rgba(99,102,241,.2), rgba(139,92,246,.15)); display: flex; align-items: center; justify-content: center;">
                                <i class="fa fa-cube" style="color: var(--primary-light); font-size: 14px;"></i>
                            </div>
                            @endif
                            <div style="font-size: 13px; font-weight: 600; color: var(--text-primary);">
                                {{ $package->getTranslation('name', app()->getLocale()) }}
                            </div>
                        </div>
                    </td>
                    <td style="font-weight: 700; color: var(--primary-light);">{{ number_format($package->price, 0) }} UZS</td>
                    <td>
                        <span class="badge badge-success">{{ $package->daily_profit_percent }}%</span>
                    </td>
                    <td style="color: var(--text-secondary);">{{ $package->validity_days }} kun</td>
                    <td>
                        @if($package->status === 'active')
                        <span class="badge badge-success"><i class="fa fa-circle" style="font-size: 6px;"></i> Faol</span>
                        @else
                        <span class="badge badge-danger"><i class="fa fa-circle" style="font-size: 6px;"></i> Nofaol</span>
                        @endif
                    </td>
                    <td>
                        <div style="display: flex; gap: 4px;">
                            <a href="{{ route('admin.packages.edit', $package) }}" class="btn btn-outline btn-sm"><i class="fa fa-pen"></i></a>
                            <form method="POST" action="{{ route('admin.packages.destroy', $package) }}" style="margin:0;"
                                  onsubmit="return confirm('O\'chirilsinmi?')">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                        <i class="fa fa-cube" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                        Paketlar topilmadi
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

@endsection
