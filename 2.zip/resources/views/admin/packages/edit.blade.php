@extends('admin.layouts.app')

@section('title', __('packages.edit'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.packages.index') }}">{{ __('packages.title') }}</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('packages.edit') }}: {{ $package->getTranslation('name', 'uz') }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.packages.index') }}" class="btn btn-outline">{{ __('buttons.cancel') }}</a>
    <button type="submit" form="packageEditForm" class="btn btn-primary">{{ __('buttons.save') }}</button>
@endsection

@section('content')
    <form id="packageEditForm" action="{{ route('admin.packages.update', $package) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
            {{-- Left Column --}}
            <div style="display: flex; flex-direction: column; gap: 24px;">
                {{-- Package Info --}}
                <div class="admin-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 20px;">{{ __('packages.info') }}</h3>

                    {{-- Language Tabs --}}
                    <div style="margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 20px;">
                        <div style="display: flex; gap: 8px; border-bottom: 1px solid var(--border); margin-bottom: 16px;">
                            <button type="button" class="tab-btn active" onclick="switchTab('uz', this)" style="padding: 8px 16px; border: none; border-bottom: 2px solid var(--primary-light); background: none; font-weight: 500; color: var(--primary-light); cursor: pointer;">{{ __('payment_methods.uzbek') }}</button>
                            <button type="button" class="tab-btn" onclick="switchTab('ru', this)" style="padding: 8px 16px; border: none; border-bottom: 2px solid transparent; background: none; font-weight: 500; color: var(--text-muted); cursor: pointer;">{{ __('payment_methods.russian') }}</button>
                            <button type="button" class="tab-btn" onclick="switchTab('en', this)" style="padding: 8px 16px; border: none; border-bottom: 2px solid transparent; background: none; font-weight: 500; color: var(--text-muted); cursor: pointer;">{{ __('payment_methods.english') }}</button>
                        </div>

                        <div id="tab-uz" class="tab-content">
                            <div class="form-group">
                                <label class="form-label">{{ __('packages.name_uz') }} <span style="color: var(--danger);">*</span></label>
                                <input name="name_uz" type="text" value="{{ old('name_uz', $package->getTranslation('name', 'uz', false)) }}" required class="form-control @error('name_uz') is-invalid @enderror" placeholder="Masalan: VIP 1">
                                @error('name_uz') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                            </div>
                        </div>

                        <div id="tab-ru" class="tab-content" style="display: none;">
                            <div class="form-group">
                                <label class="form-label">{{ __('packages.name_ru') }}</label>
                                <input name="name_ru" type="text" value="{{ old('name_ru', $package->getTranslation('name', 'ru', false)) }}" class="form-control @error('name_ru') is-invalid @enderror" placeholder="Masalan: ВИП 1">
                                @error('name_ru') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                            </div>
                        </div>

                        <div id="tab-en" class="tab-content" style="display: none;">
                            <div class="form-group">
                                <label class="form-label">{{ __('packages.name_en') }}</label>
                                <input name="name_en" type="text" value="{{ old('name_en', $package->getTranslation('name', 'en', false)) }}" class="form-control @error('name_en') is-invalid @enderror" placeholder="Masalan: VIP 1">
                                @error('name_en') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                            </div>
                        </div>
                    </div>

                    {{-- Photo Upload --}}
                    <div class="form-group">
                        <x-admin.file-upload
                            name="photo_id"
                            folder="packages"
                            :label="__('packages.photo')"
                            :current-url="$package->photo_url"
                            :current-id="$package->photo_id"
                        />
                        @error('photo_id') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                    </div>

                    {{-- Price & Duration --}}
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                        <div class="form-group">
                            <label class="form-label">{{ __('packages.price') }} <span style="color: var(--danger);">*</span></label>
                            <input name="price" type="number" step="0.01" value="{{ old('price', $package->price) }}" required class="form-control @error('price') is-invalid @enderror">
                            @error('price') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group">
                            <label class="form-label">{{ __('packages.duration') }} <span style="color: var(--danger);">*</span></label>
                            <input name="validity_days" type="number" value="{{ old('validity_days', $package->validity_days) }}" required class="form-control @error('validity_days') is-invalid @enderror">
                            @error('validity_days') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>

                {{-- Profit Settings --}}
                <div class="admin-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 20px;">{{ __('packages.profit_settings') }}</h3>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                        <div class="form-group">
                            <label class="form-label">{{ __('packages.daily_profit') }} <span style="color: var(--danger);">*</span></label>
                            <input name="daily_profit_percent" type="number" step="0.01" value="{{ old('daily_profit_percent', $package->daily_profit_percent) }}" required class="form-control @error('daily_profit_percent') is-invalid @enderror">
                            @error('daily_profit_percent') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group">
                            <label class="form-label">{{ __('packages.total_profit') }} <span style="color: var(--danger);">*</span></label>
                            <input name="total_profit_percent" type="number" step="0.01" value="{{ old('total_profit_percent', $package->total_profit_percent) }}" required class="form-control @error('total_profit_percent') is-invalid @enderror">
                            @error('total_profit_percent') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>

                {{-- Referral System --}}
                <div class="admin-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 20px;">{{ __('packages.referral_system') }}</h3>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                        <div class="form-group">
                            <label class="form-label">{{ __('packages.sponsor_income') }} <span style="color: var(--danger);">*</span></label>
                            <input name="sponsor_income" type="number" step="0.01" value="{{ old('sponsor_income', $package->sponsor_income) }}" required class="form-control @error('sponsor_income') is-invalid @enderror">
                            @error('sponsor_income') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group">
                            <label class="form-label">{{ __('packages.referral_l1') }} <span style="color: var(--danger);">*</span></label>
                            <input name="ref_level1" type="number" step="0.01" value="{{ old('ref_level1', $package->ref_level1) }}" required class="form-control @error('ref_level1') is-invalid @enderror">
                        </div>

                        <div class="form-group">
                            <label class="form-label">{{ __('packages.referral_l2') }} <span style="color: var(--danger);">*</span></label>
                            <input name="ref_level2" type="number" step="0.01" value="{{ old('ref_level2', $package->ref_level2) }}" required class="form-control @error('ref_level2') is-invalid @enderror">
                        </div>

                        <div class="form-group">
                            <label class="form-label">{{ __('packages.referral_l3') }} <span style="color: var(--danger);">*</span></label>
                            <input name="ref_level3" type="number" step="0.01" value="{{ old('ref_level3', $package->ref_level3) }}" required class="form-control @error('ref_level3') is-invalid @enderror">
                        </div>
                    </div>
                </div>
            </div>

            {{-- Right Column - Settings --}}
            <div>
                <div class="admin-card" style="padding: 24px;">
                    <h3 style="font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 20px;">{{ __('packages.settings') }}</h3>

                    <div class="form-group">
                        <label class="form-label">{{ __('packages.sort_order') }} <span style="color: var(--danger);">*</span></label>
                        <input name="sort_order" type="number" value="{{ old('sort_order', $package->sort_order) }}" required class="form-control @error('sort_order') is-invalid @enderror">
                    </div>

                    <div class="form-group">
                        <label class="form-label">{{ __('admins.status') }} <span style="color: var(--danger);">*</span></label>
                        <select name="status" class="form-control">
                            <option value="active" {{ old('status', $package->status) == 'active' ? 'selected' : '' }}>{{ __('status.active') }}</option>
                            <option value="inactive" {{ old('status', $package->status) == 'inactive' ? 'selected' : '' }}>{{ __('status.inactive') }}</option>
                        </select>
                    </div>

                    <div class="form-group" style="padding-top: 16px; border-top: 1px solid var(--border); margin-top: 16px;">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                            <input name="is_default" type="checkbox" value="1" {{ old('is_default', $package->is_default) ? 'checked' : '' }} style="width: 18px; height: 18px; accent-color: var(--primary-light);">
                            <span style="font-weight: 500; color: var(--text-primary);">{{ __('packages.is_default') }}</span>
                        </label>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <script>
        function switchTab(tab, btn) {
            document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
            document.querySelectorAll('.tab-btn').forEach(el => {
                el.style.borderBottomColor = 'transparent';
                el.style.color = 'var(--text-muted)';
            });
            document.getElementById('tab-' + tab).style.display = 'block';
            btn.style.borderBottomColor = 'var(--primary-light)';
            btn.style.color = 'var(--primary-light)';
        }
    </script>
@endsection
