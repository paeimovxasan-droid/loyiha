@extends('admin.layouts.app')

@section('title', __('withdrawals.show_title'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.withdrawals.index') }}">{{ __('withdrawals.title') }}</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">№ {{ $withdrawal->id }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.withdrawals.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> {{ __('admin_misc.back') }}
    </a>
@endsection

@section('content')

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
    {{-- Left Column --}}
    <div>
        {{-- Details Card --}}
        <div class="admin-card">
            <div class="admin-card-header">
                <span class="admin-card-title"><i class="fa fa-file-invoice" style="margin-right: 6px; color: var(--primary-light);"></i> {{ __('withdrawals.details') }}</span>
                @if($withdrawal->isPending())
                    <span class="badge badge-warning">{{ __('status.pending') }}</span>
                @elseif($withdrawal->isApproved())
                    <span class="badge badge-success">{{ __('status.approved') }}</span>
                @else
                    <span class="badge badge-danger">{{ __('status.rejected') }}</span>
                @endif
            </div>
            <div class="admin-card-body">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div>
                        <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 4px;">{{ __('withdrawals.amount_req') }}</div>
                        <div style="font-size: 16px; font-weight: 700; color: var(--text-primary);">{{ number_format($withdrawal->amount, 2) }} UZS</div>
                    </div>
                    <div>
                        <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 4px;">{{ __('withdrawals.commission_fee') }}</div>
                        <div style="font-size: 14px; font-weight: 600; color: var(--danger);">{{ number_format($withdrawal->charge, 2) }} UZS</div>
                    </div>
                    <div>
                        <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 4px;">{{ __('withdrawals.net_amount') }}</div>
                        <div style="font-size: 18px; font-weight: 700; color: var(--primary-light);">{{ number_format($withdrawal->final_amount, 2) }} UZS</div>
                    </div>
                    <div>
                        <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 4px;">{{ __('withdrawals.date') }}</div>
                        <div style="font-size: 14px; font-weight: 500; color: var(--text-primary);">{{ $withdrawal->created_at->format('d.m.Y H:i:s') }}</div>
                    </div>
                </div>

                @if($withdrawal->feedback)
                <div style="margin-top: 16px; padding: 12px; border-radius: 8px; border: 1px solid var(--border); background: var(--bg-card);">
                    <div style="font-size: 12px; font-weight: 600; color: var(--text-primary); margin-bottom: 4px;">{{ __('admin_misc.feedback') }}</div>
                    <div style="font-size: 13px; color: var(--text-secondary);">{{ $withdrawal->feedback }}</div>
                </div>
                @endif
            </div>
        </div>
    </div>

    {{-- Right Column --}}
    <div>
        {{-- User Info Card --}}
        <div class="admin-card" style="margin-bottom: 20px;">
            <div class="admin-card-body" style="text-align: center;">
                @if($withdrawal->user)
                    <img src="{{ $withdrawal->user->avatar_url ?? 'https://ui-avatars.com/api/?name='.$withdrawal->user->name }}" alt="user"
                         style="width: 64px; height: 64px; border-radius: 50%; border: 2px solid var(--border); margin: 0 auto 12px;">
                    <div style="font-size: 15px; font-weight: 600; color: var(--text-primary);">{{ $withdrawal->user->name }}</div>
                    <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">{{ $withdrawal->user->email }} / {{ $withdrawal->user->phone }}</div>
                @else
                    <div style="width: 64px; height: 64px; border-radius: 50%; background: var(--border); display: flex; align-items: center; justify-content: center; margin: 0 auto 12px;">
                        <span style="font-size: 24px; color: var(--text-muted);">?</span>
                    </div>
                    <div style="font-size: 15px; font-weight: 600; color: var(--text-primary);">{{ __('admin_misc.deleted_user') }}</div>
                @endif
            </div>

            <div style="padding: 0 20px 20px;">
                <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 8px; padding: 12px; text-align: center; margin-bottom: 12px;">
                    <div style="font-size: 11px; color: var(--text-muted);">{{ __('withdrawals.current_balance') }}</div>
                    <div style="font-size: 16px; font-weight: 700; color: var(--text-primary); margin-top: 4px;">{{ number_format($withdrawal->user?->balance ?? 0, 2) }} <span style="font-size: 11px; color: var(--text-muted);">UZS</span></div>
                </div>

                <div style="border-top: 1px solid var(--border); padding-top: 12px; margin-top: 12px;">
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 6px;">{{ __('withdrawals.payment_method') }}</div>
                    <div style="display: flex; align-items: center; gap: 8px; background: var(--bg-card); border: 1px solid var(--border); padding: 8px 12px; border-radius: 6px;">
                        @if($withdrawal->paymentMethod)
                            <img src="{{ $withdrawal->paymentMethod->photo_url }}" alt="method" style="width: 24px; height: 24px; border-radius: 4px;">
                        @endif
                        <div style="font-size: 13px; font-weight: 600; color: var(--text-primary);">{{ $withdrawal->method_name }}</div>
                    </div>
                </div>

                <div style="margin-top: 12px;">
                    <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 6px;">{{ __('withdrawals.where_to_send') }}</div>
                    <div style="font-size: 16px; font-weight: 700; color: var(--primary-light); background: var(--bg-card); border: 1px solid var(--border); padding: 10px 12px; border-radius: 6px;">
                        {{ $withdrawal->receiver_number ?? __('admin_misc.not_entered') }}
                    </div>
                </div>
            </div>
        </div>

        {{-- Action Card --}}
        @if($withdrawal->isPending())
        <div class="admin-card">
            <div class="admin-card-header">
                <span class="admin-card-title"><i class="fa fa-gavel" style="margin-right: 6px; color: var(--warning);"></i> {{ __('withdrawals.decision') }}</span>
            </div>
            <div class="admin-card-body">
                <div id="withdrawal-action-buttons">
                    <div style="display: flex; gap: 8px;">
                        <button type="button" onclick="showWithdrawalForm('approve')" class="btn btn-success" style="flex: 1;">
                            <i class="fa fa-check"></i> {{ __('withdrawals.paid') }}
                        </button>
                        <button type="button" onclick="showWithdrawalForm('reject')" class="btn btn-danger" style="flex: 1;">
                            <i class="fa fa-times"></i> {{ __('withdrawals.reject') }}
                        </button>
                    </div>
                </div>

                <div id="withdrawal-action-form" style="display: none;">
                    <h4 id="withdrawal-form-title" style="font-size: 13px; font-weight: 600; margin-bottom: 12px;"></h4>
                    <form id="withdrawal-form" method="POST">
                        @csrf
                        <div class="form-group">
                            <textarea name="feedback" rows="3" class="form-control" placeholder="{{ __('admin_misc.feedback_placeholder') }}"></textarea>
                        </div>
                        <div style="display: flex; gap: 8px; margin-top: 12px;">
                            <button type="button" onclick="hideWithdrawalForm()" class="btn btn-outline" style="flex: 1;">
                                {{ __('admin_misc.back') }}
                            </button>
                            <button type="submit" id="withdrawal-submit-btn" class="btn" style="flex: 1;"></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script>
        function showWithdrawalForm(type) {
            document.getElementById('withdrawal-action-buttons').style.display = 'none';
            document.getElementById('withdrawal-action-form').style.display = 'block';

            var form = document.getElementById('withdrawal-form');
            var title = document.getElementById('withdrawal-form-title');
            var submitBtn = document.getElementById('withdrawal-submit-btn');

            if (type === 'approve') {
                form.action = '{{ route('admin.withdrawals.approve', $withdrawal) }}';
                title.textContent = '{{ __('withdrawals.approve_complete') }}';
                title.style.color = 'var(--success)';
                submitBtn.className = 'btn btn-success';
                submitBtn.style.flex = '1';
                submitBtn.textContent = '{{ __('buttons.approve') }}';
            } else {
                form.action = '{{ route('admin.withdrawals.reject', $withdrawal) }}';
                title.textContent = '{{ __('withdrawals.reject_reason') }}';
                title.style.color = 'var(--danger)';
                submitBtn.className = 'btn btn-danger';
                submitBtn.style.flex = '1';
                submitBtn.textContent = '{{ __('buttons.reject') }}';
            }
        }

        function hideWithdrawalForm() {
            document.getElementById('withdrawal-action-buttons').style.display = 'block';
            document.getElementById('withdrawal-action-form').style.display = 'none';
        }
        </script>
        @endif
    </div>
</div>

@endsection
