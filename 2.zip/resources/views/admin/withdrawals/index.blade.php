@extends('admin.layouts.app')

@section('title', __('withdrawals.title'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('withdrawals.title') }}</span>
@endsection

@section('content')

{{-- Filters --}}
<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; flex-wrap: wrap; gap: 10px;">
    <h2 style="font-size: 18px; font-weight: 700; color: var(--text-primary);">{{ __('withdrawals.requests') }}</h2>
    <form action="{{ route('admin.withdrawals.index') }}" method="GET" style="display: flex; gap: 8px; align-items: center;">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="{{ __('buttons.search') }}..."
               class="form-control" style="width: 160px; padding: 7px 12px; font-size: 12px;">
        <select name="status" onchange="this.form.submit()" class="form-control" style="width: 130px; padding: 7px 12px; font-size: 12px;">
            <option value="">{{ __('table.status') }}</option>
            <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>{{ __('status.pending') }}</option>
            <option value="approved" {{ request('status') === 'approved' ? 'selected' : '' }}>{{ __('status.approved') }}</option>
            <option value="rejected" {{ request('status') === 'rejected' ? 'selected' : '' }}>{{ __('status.rejected') }}</option>
        </select>
        @if(request()->anyFilled(['search', 'status']))
        <a href="{{ route('admin.withdrawals.index') }}" class="btn btn-outline btn-sm"><i class="fa fa-times"></i></a>
        @endif
    </form>
</div>

{{-- Table --}}
<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>{{ __('table.order_date') }}</th>
                    <th>{{ __('table.client') }}</th>
                    <th>{{ __('table.payment_method_sender') }}</th>
                    <th>{{ __('table.amount_net') }}</th>
                    <th>{{ __('table.status') }}</th>
                    <th>{{ __('table.details') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($withdrawals as $withdrawal)
                <tr>
                    <td>
                        <div style="font-size: 13px; font-weight: 600; color: var(--text-primary);">#{{ $withdrawal->id }}</div>
                        <div style="font-size: 11px; color: var(--text-muted);">{{ $withdrawal->created_at->format('d.m.Y H:i') }}</div>
                    </td>
                    <td>
                        <div style="font-size: 13px; font-weight: 500; color: var(--text-primary);">{{ $withdrawal->user->name ?? 'Noma\'lum' }}</div>
                        <div style="font-size: 11px; color: var(--text-muted);">{{ $withdrawal->user->email ?? '' }}</div>
                    </td>
                    <td>
                        <div style="font-size: 13px; font-weight: 500; color: var(--text-primary);">{{ $withdrawal->method_name ?? $withdrawal->paymentMethod?->getTranslation('name', app()->getLocale()) }}</div>
                        <div style="font-size: 11px; color: var(--text-muted);">{{ $withdrawal->account_number }}</div>
                    </td>
                    <td>
                        <div style="font-size: 13px; font-weight: 700; color: var(--danger);">{{ number_format($withdrawal->final_amount, 0) }} UZS</div>
                        <div style="font-size: 11px; color: var(--text-muted);">Fee: {{ number_format($withdrawal->charge ?? 0, 0) }}</div>
                    </td>
                    <td>
                        @if($withdrawal->isPending())
                        <span class="badge badge-warning"><i class="fa fa-clock" style="font-size: 8px;"></i> {{ __('status.pending') }}</span>
                        @elseif($withdrawal->isApproved())
                        <span class="badge badge-success"><i class="fa fa-check" style="font-size: 8px;"></i> {{ __('status.approved') }}</span>
                        @else
                        <span class="badge badge-danger"><i class="fa fa-times" style="font-size: 8px;"></i> {{ __('status.rejected') }}</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('admin.withdrawals.show', $withdrawal) }}" class="btn btn-outline btn-sm">
                            <i class="fa fa-eye"></i>
                        </a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                        <i class="fa fa-inbox" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                        {{ __('table.not_found') }}
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($withdrawals->hasPages())
    <div style="padding: 14px 20px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: center;">
        <div class="pagination">
            @if(!$withdrawals->onFirstPage())
            <a href="{{ $withdrawals->previousPageUrl() }}"><i class="fa fa-chevron-left" style="font-size: 10px;"></i></a>
            @endif
            @foreach($withdrawals->getUrlRange(max(1, $withdrawals->currentPage()-2), min($withdrawals->lastPage(), $withdrawals->currentPage()+2)) as $page => $url)
                @if($page == $withdrawals->currentPage())
                <span class="active"><span>{{ $page }}</span></span>
                @else
                <a href="{{ $url }}">{{ $page }}</a>
                @endif
            @endforeach
            @if($withdrawals->hasMorePages())
            <a href="{{ $withdrawals->nextPageUrl() }}"><i class="fa fa-chevron-right" style="font-size: 10px;"></i></a>
            @endif
        </div>
    </div>
    @endif
</div>

@endsection
