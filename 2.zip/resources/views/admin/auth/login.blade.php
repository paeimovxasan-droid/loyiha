<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kirish — {{ config('app.name') }}</title>
    <link rel="icon" type="image/png" href="{{ $global_setting->favicon_url }}">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', -apple-system, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #0a0e1a;
            color: #f1f5f9;
            padding: 20px;
            -webkit-font-smoothing: antialiased;
        }

        /* Background decoration */
        body::before {
            content: '';
            position: fixed;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(ellipse at 30% 20%, rgba(99,102,241,.08) 0%, transparent 50%),
                        radial-gradient(ellipse at 70% 80%, rgba(139,92,246,.06) 0%, transparent 50%);
            pointer-events: none;
        }

        .login-container {
            width: 100%;
            max-width: 380px;
            position: relative;
            z-index: 1;
        }

        .login-header {
            text-align: center;
            margin-bottom: 28px;
        }

        .login-logo {
            width: 52px;
            height: 52px;
            border-radius: 14px;
            margin: 0 auto 16px;
            object-fit: contain;
        }

        .login-title {
            font-size: 22px;
            font-weight: 700;
            color: #f1f5f9;
            letter-spacing: -.4px;
            margin-bottom: 4px;
        }

        .login-subtitle {
            font-size: 13px;
            color: #64748b;
        }

        .login-card {
            background: #13151d;
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 16px;
            padding: 28px;
            box-shadow: 0 16px 48px rgba(0,0,0,.3);
        }

        .error-box {
            background: rgba(239,68,68,.08);
            border: 1px solid rgba(239,68,68,.15);
            border-radius: 10px;
            padding: 10px 14px;
            margin-bottom: 16px;
            font-size: 13px;
            color: #f87171;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .form-group { margin-bottom: 16px; }

        .form-label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            color: #94a3b8;
            margin-bottom: 6px;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
            font-size: 14px;
            transition: color .2s;
        }

        .form-input {
            width: 100%;
            background: rgba(255,255,255,.03);
            border: 1px solid rgba(255,255,255,.08);
            border-radius: 10px;
            padding: 11px 14px 11px 38px;
            color: #f1f5f9;
            font-size: 14px;
            font-family: inherit;
            outline: none;
            transition: all .2s;
        }

        .form-input:focus {
            border-color: rgba(99,102,241,.5);
            background: rgba(99,102,241,.03);
            box-shadow: 0 0 0 3px rgba(99,102,241,.08);
        }

        .form-input:focus + i,
        .form-input:focus ~ i { color: #818cf8; }

        .form-input::placeholder { color: #475569; }

        .form-footer {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: #94a3b8;
            cursor: pointer;
        }

        .checkbox-label input[type="checkbox"] {
            width: 16px;
            height: 16px;
            border-radius: 4px;
            accent-color: #6366f1;
        }

        .submit-btn {
            width: 100%;
            padding: 12px;
            border-radius: 10px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: #fff;
            font-size: 14px;
            font-weight: 600;
            font-family: inherit;
            border: none;
            cursor: pointer;
            transition: all .2s;
            box-shadow: 0 4px 12px rgba(99,102,241,.3);
        }

        .submit-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(99,102,241,.4);
        }

        .submit-btn:active { transform: translateY(0) scale(.98); }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <img src="{{ $global_setting->logo_url }}" alt="Logo" class="login-logo">
            <h1 class="login-title">Xush kelibsiz!</h1>
            <p class="login-subtitle">Admin paneliga kirish</p>
        </div>

        <div class="login-card">
            @if($errors->any())
            <div class="error-box">
                <i class="fa fa-exclamation-circle"></i>
                {{ $errors->first() }}
            </div>
            @endif

            <form method="POST" action="{{ route('admin.login.post') }}">
                @csrf

                <div class="form-group">
                    <label class="form-label">Email</label>
                    <div class="input-wrapper">
                        <input type="email" name="email" value="{{ old('email') }}" class="form-input"
                               placeholder="admin@aisoqqa.uz" autocomplete="email" required>
                        <i class="fa fa-envelope"></i>
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Parol</label>
                    <div class="input-wrapper">
                        <input type="password" name="password" class="form-input"
                               placeholder="••••••••" autocomplete="current-password" required>
                        <i class="fa fa-lock"></i>
                    </div>
                </div>

                <div class="form-footer">
                    <label class="checkbox-label">
                        <input type="checkbox" name="remember">
                        Meni eslab qol
                    </label>
                </div>

                <button type="submit" class="submit-btn">
                    <i class="fa fa-right-to-bracket" style="margin-right: 6px;"></i> Kirish
                </button>
            </form>
        </div>
    </div>
</body>
</html>
