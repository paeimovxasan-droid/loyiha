@extends('admin.layouts.app')

@section('title', __('users.edit'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.users.index') }}">{{ __('nav.users') }}</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('buttons.edit') }}: {{ $user->name }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.users.index') }}" class="btn btn-outline">{{ __('buttons.cancel') }}</a>
    <button type="submit" form="userEditForm" class="btn btn-primary">{{ __('buttons.save') }}</button>
@endsection

@section('content')
    <form id="userEditForm" action="{{ route('admin.users.update', $user) }}" method="POST">
        @csrf
        @method('PUT')

        <div style="display: grid; grid-template-columns: 1fr; gap: 24px;">
            {{-- Main Content --}}
            <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 24px;">
                {{-- Left Column --}}
                <div style="display: flex; flex-direction: column; gap: 24px;">
                    {{-- Personal Info --}}
                    <div class="admin-card" style="padding: 24px;">
                        <h3 style="font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 20px;">{{ __('users.personal_info') }}</h3>

                        <div class="form-group">
                            <label class="form-label">{{ __('front.auth.full_name') }} <span style="color: var(--danger);">*</span></label>
                            <input name="name" type="text" value="{{ old('name', $user->name) }}" required class="form-control @error('name') is-invalid @enderror" placeholder="{{ __('users.client_name') }}">
                            @error('name') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                        </div>

                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                            <div class="form-group">
                                <label class="form-label">{{ __('front.auth.username') }} <span style="color: var(--danger);">*</span></label>
                                <input name="username" type="text" value="{{ old('username', $user->username) }}" required class="form-control @error('username') is-invalid @enderror" placeholder="username">
                                @error('username') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                            </div>

                            <div class="form-group">
                                <label class="form-label">{{ __('front.auth.phone') }}</label>
                                <input name="phone" type="text" value="{{ old('phone', $user->phone) }}" class="form-control @error('phone') is-invalid @enderror" placeholder="+998901234567">
                                @error('phone') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                            </div>
                        </div>
                    </div>

                    {{-- Login Info --}}
                    <div class="admin-card" style="padding: 24px;">
                        <h3 style="font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 20px;">{{ __('users.login_info') }}</h3>

                        <div class="form-group">
                            <label class="form-label">{{ __('front.auth.email') }} <span style="color: var(--danger);">*</span></label>
                            <input name="email" type="email" value="{{ old('email', $user->email) }}" required class="form-control @error('email') is-invalid @enderror" placeholder="email@example.com">
                            @error('email') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group">
                            <label class="form-label">{{ __('users.password_change_hint') }}</label>
                            <input name="password" type="password" spellcheck="false" class="form-control @error('password') is-invalid @enderror" placeholder="{{ __('users.secret_password') }}">
                            @error('password') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>

                {{-- Right Column - Settings --}}
                <div>
                    <div class="admin-card" style="padding: 24px;">
                        <h3 style="font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 20px;">{{ __('settings.title') }}</h3>

                        <div class="form-group">
                            <label class="form-label">{{ __('table.status') }} <span style="color: var(--danger);">*</span></label>
                            <select name="status" required class="form-control @error('status') is-invalid @enderror">
                                <option value="active" {{ old('status', $user->status) === 'active' ? 'selected' : '' }}>{{ __('status.active') }}</option>
                                <option value="banned" {{ old('status', $user->status) === 'banned' ? 'selected' : '' }}>{{ __('status.banned') }}</option>
                            </select>
                            @error('status') <span style="color: var(--danger); font-size: 12px; margin-top: 4px; display: block;">{{ $message }}</span> @enderror
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection
