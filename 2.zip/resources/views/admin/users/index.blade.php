@extends('admin.layouts.app')

@section('title', __('nav.users'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('nav.users') }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.users.create') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-plus"></i> {{ __('buttons.add_new') }}
    </a>
@endsection

@section('content')

{{-- Filters --}}
<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; flex-wrap: wrap; gap: 10px;">
    <h2 style="font-size: 18px; font-weight: 700; color: var(--text-primary);">{{ __('users.title') }}</h2>
    <div style="display: flex; align-items: center; gap: 8px;">
        <form action="{{ route('admin.users.index') }}" method="GET" style="display: flex; gap: 8px; align-items: center;">
            <input type="text" name="search" value="{{ request('search') }}" placeholder="{{ __('buttons.search') }}..."
                   class="form-control" style="width: 180px; padding: 7px 12px; font-size: 12px;">
            <select name="status" onchange="this.form.submit()" class="form-control" style="width: 120px; padding: 7px 12px; font-size: 12px;">
                <option value="">{{ __('table.status') }}</option>
                <option value="active" {{ request('status') === 'active' ? 'selected' : '' }}>{{ __('status.active') }}</option>
                <option value="banned" {{ request('status') === 'banned' ? 'selected' : '' }}>{{ __('status.banned') }}</option>
            </select>
            @if(request()->anyFilled(['search', 'status']))
            <a href="{{ route('admin.users.index') }}" class="btn btn-outline btn-sm" title="{{ __('buttons.clear') }}">
                <i class="fa fa-times"></i>
            </a>
            @endif
        </form>
    </div>
</div>

{{-- Table --}}
<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>{{ __('common.user') }}</th>
                    <th>{{ __('table.role') }}</th>
                    <th>{{ __('table.phone') }}</th>
                    <th>{{ __('table.balance') }}</th>
                    <th>{{ __('table.status') }}</th>
                    <th>{{ __('table.actions') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($users as $user)
                <tr>
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <img src="{{ $user->avatar_url }}" alt=""
                                 style="width: 34px; height: 34px; border-radius: 8px; object-fit: cover; border: 1px solid var(--border);">
                            <div>
                                <div style="font-size: 13px; font-weight: 600; color: var(--text-primary);">{{ $user->name }}</div>
                                <div style="font-size: 11px; color: var(--text-muted);">{{ $user->username ? '@'.$user->username : $user->email }}</div>
                            </div>
                        </div>
                    </td>
                    <td>
                        @foreach($user->roles as $role)
                        <span class="badge badge-primary">{{ $role->name }}</span>
                        @endforeach
                    </td>
                    <td>
                        <div style="font-size: 12px;">{{ $user->email }}</div>
                        <div style="font-size: 11px; color: var(--text-muted);">{{ $user->phone ?? '—' }}</div>
                    </td>
                    <td>
                        <span style="font-weight: 600; color: var(--text-primary);">{{ number_format($user->balance ?? 0, 0) }}</span>
                        <span style="font-size: 11px; color: var(--text-muted);">UZS</span>
                    </td>
                    <td>
                        @if($user->status === 'active')
                        <span class="badge badge-success"><i class="fa fa-circle" style="font-size: 6px;"></i> {{ __('status.active') }}</span>
                        @else
                        <span class="badge badge-danger"><i class="fa fa-circle" style="font-size: 6px;"></i> {{ __('status.banned') }}</span>
                        @endif
                    </td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 4px;">
                            <a href="{{ route('admin.users.edit', $user) }}" class="btn btn-outline btn-sm" title="Tahrirlash">
                                <i class="fa fa-pen"></i>
                            </a>

                            @can('users.balance-adjust')
                            <button onclick="openBalanceModal({{ $user->id }}, {{ $user->balance }})" class="btn btn-outline btn-sm" title="{{ __('users.adjust_balance') }}">
                                <i class="fa fa-wallet"></i>
                            </button>
                            @endcan

                            @can('users.ban')
                            <form method="POST" action="{{ route('admin.users.ban', $user) }}" style="margin:0;"
                                  onsubmit="return confirm('{{ __('messages.confirm_action') }}')">
                                @csrf
                                <button type="submit" class="btn btn-sm {{ $user->status === 'active' ? 'btn-warning' : 'btn-success' }}" title="{{ $user->status === 'active' ? __('buttons.ban') : __('buttons.unban') }}">
                                    <i class="fa {{ $user->status === 'active' ? 'fa-ban' : 'fa-check' }}"></i>
                                </button>
                            </form>
                            @endcan

                            <form method="POST" action="{{ route('admin.users.destroy', $user) }}" style="margin:0;"
                                  onsubmit="return confirm('{{ __('buttons.confirm_delete') }}')">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                        <i class="fa fa-users" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                        {{ __('users.no_users') }}
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($users->hasPages())
    <div style="padding: 14px 20px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between;">
        <span style="font-size: 12px; color: var(--text-muted);">{{ __('table.total') }}: <strong>{{ $users->total() }}</strong></span>
        <div class="pagination">
            @if(!$users->onFirstPage())
            <a href="{{ $users->previousPageUrl() }}"><i class="fa fa-chevron-left" style="font-size: 10px;"></i></a>
            @endif
            @foreach($users->getUrlRange(max(1, $users->currentPage()-2), min($users->lastPage(), $users->currentPage()+2)) as $page => $url)
                @if($page == $users->currentPage())
                <span class="active"><span>{{ $page }}</span></span>
                @else
                <a href="{{ $url }}">{{ $page }}</a>
                @endif
            @endforeach
            @if($users->hasMorePages())
            <a href="{{ $users->nextPageUrl() }}"><i class="fa fa-chevron-right" style="font-size: 10px;"></i></a>
            @endif
        </div>
    </div>
    @endif
</div>

{{-- Balance Modal --}}
@can('users.balance-adjust')
<div id="balanceModal" style="position: fixed; inset: 0; z-index: 9999; display: none; align-items: center; justify-content: center;
            background: rgba(10,14,26,.8); backdrop-filter: blur(4px);">
    <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 14px; padding: 24px;
                width: 90%; max-width: 360px; box-shadow: 0 16px 48px rgba(0,0,0,.4);">
        <h3 style="font-size: 16px; font-weight: 700; color: var(--text-primary); margin-bottom: 4px;">{{ __('users.adjust_balance') }}</h3>
        <p style="font-size: 13px; color: var(--text-muted); margin-bottom: 16px;">
            Joriy balans: <strong id="modalBalance" style="color: var(--primary-light);">0</strong> UZS
        </p>
        <form id="balanceForm" method="POST">
            @csrf
            <div style="display: flex; gap: 10px; margin-bottom: 14px;">
                <label style="display: flex; align-items: center; gap: 6px; font-size: 13px; color: var(--text-secondary); cursor: pointer;">
                    <input type="radio" name="action" value="add" checked style="accent-color: var(--success);"> + Qo'shish
                </label>
                <label style="display: flex; align-items: center; gap: 6px; font-size: 13px; color: var(--text-secondary); cursor: pointer;">
                    <input type="radio" name="action" value="subtract" style="accent-color: var(--danger);"> − Ayirish
                </label>
            </div>
            <div class="form-group">
                <label class="form-label">Miqdor (UZS)</label>
                <input type="number" name="amount" step="0.01" min="0.01" required class="form-control" placeholder="10000">
            </div>
            <div style="display: flex; gap: 8px; margin-top: 16px;">
                <button type="button" onclick="closeBalanceModal()" class="btn btn-outline" style="flex: 1;">{{ __('buttons.cancel') }}</button>
                <button type="submit" class="btn btn-primary" style="flex: 1;">{{ __('buttons.confirm') }}</button>
            </div>
        </form>
    </div>
</div>

<script>
function openBalanceModal(userId, balance) {
    document.getElementById('balanceForm').action = '/admin/users/' + userId + '/balance';
    document.getElementById('modalBalance').textContent = new Intl.NumberFormat().format(balance);
    document.getElementById('balanceModal').style.display = 'flex';
}
function closeBalanceModal() {
    document.getElementById('balanceModal').style.display = 'none';
}
document.getElementById('balanceModal').addEventListener('click', function(e) {
    if (e.target === this) closeBalanceModal();
});
</script>
@endcan

@endsection
