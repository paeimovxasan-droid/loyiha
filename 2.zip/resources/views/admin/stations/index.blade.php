@extends('admin.layouts.app')
@section('title', __('stations.title'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('stations.title') }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.stations.create') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-plus" style="margin-right: 4px;"></i> {{ __('stations.create') }}
    </a>
@endsection

@section('content')

<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>{{ __('stations.name') }}</th>
                    <th>{{ __('stations.address') }}</th>
                    <th>{{ __('stations.capacity') }}</th>
                    <th>{{ __('stations.price_per_kw') }}</th>
                    <th>{{ __('table.status') }}</th>
                    <th>{{ __('table.actions') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($stations as $station)
                    <tr>
                        <td>
                            <span style="font-weight: 500; color: var(--text-primary);">{{ $station->getTranslation('name', 'uz') }}</span>
                        </td>
                        <td>
                            <div style="font-weight: 500; font-size: 14px; color: var(--text-primary);">{{ $station->getTranslation('district', 'uz') }}</div>
                            <div style="font-size: 12px; color: var(--text-muted);">{{ $station->getTranslation('address', 'uz') }}</div>
                        </td>
                        <td>
                            <span style="font-weight: 500; color: var(--text-primary);">{{ $station->capacity_kw }} kW</span>
                        </td>
                        <td>{{ number_format($station->price_per_kw, 2) }} UZS</td>
                        <td>
                            @if($station->status === 'active')
                                <span class="badge badge-success">{{ __('status.active') }}</span>
                            @elseif($station->status === 'inactive')
                                <span class="badge badge-danger">{{ __('status.inactive') }}</span>
                            @else
                                <span class="badge badge-warning">{{ __('stations.maintenance') }}</span>
                            @endif
                        </td>
                        <td>
                            <div style="display: flex; align-items: center; gap: 8px;">
                                <a href="{{ route('admin.stations.edit', $station) }}" class="btn btn-outline btn-sm" title="{{ __('buttons.edit') }}">
                                    <i class="fa fa-edit"></i>
                                </a>
                                <form method="POST" action="{{ route('admin.stations.destroy', $station) }}" onsubmit="return confirm('{{ __('messages.delete_confirm') }}');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" title="{{ __('buttons.delete') }}">
                                        <i class="fa fa-trash-alt"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" style="text-align: center; padding: 40px; color: var(--text-muted);">{{ __('stations.no_stations') }}</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($stations->hasPages())
    <div class="pagination" style="padding: 16px;">
        {{ $stations->links() }}
    </div>
    @endif
</div>
@endsection
