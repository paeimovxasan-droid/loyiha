@extends('admin.layouts.app')
@section('title', __('stations.edit'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.stations.index') }}">{{ __('stations.title') }}</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('stations.edit') }}: {{ $station->getTranslation('name', app()->getLocale()) ?? '#' . $station->id }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.stations.index') }}" class="btn btn-outline btn-sm">{{ __('buttons.cancel') }}</a>
    <button type="submit" form="station-form" class="btn btn-primary btn-sm">{{ __('buttons.save') }}</button>
@endsection

@section('content')
<form id="station-form" action="{{ route('admin.stations.update', $station) }}" method="POST">
    @csrf
    @method('PUT')

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
        {{-- Main info --}}
        <div class="admin-card">
            <div class="admin-card-header">{{ __('stations.info') }}</div>
            <div class="admin-card-body">
                {{-- Language tabs --}}
                <div style="margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 20px;">
                    <div style="display: flex; gap: 8px; border-bottom: 1px solid var(--border); margin-bottom: 16px;">
                        <button type="button" class="tab-btn active" onclick="switchTab('uz', this)">{{ __('payment_methods.uzbek') }}</button>
                        <button type="button" class="tab-btn" onclick="switchTab('ru', this)">{{ __('payment_methods.russian') }}</button>
                        <button type="button" class="tab-btn" onclick="switchTab('en', this)">{{ __('payment_methods.english') }}</button>
                    </div>

                    {{-- UZ Tab --}}
                    <div class="tab-panel" id="tab-uz">
                        <div class="form-group">
                            <label class="form-label">{{ __('stations.name_uz') }} <span style="color: var(--danger);">*</span></label>
                            <input name="name[uz]" type="text" value="{{ old('name.uz', $station->getTranslation('name', 'uz', false)) }}" required class="form-control @error('name.uz') is-invalid @enderror">
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                            <div class="form-group">
                                <label class="form-label">{{ __('stations.address_uz') }}</label>
                                <input name="address[uz]" type="text" value="{{ old('address.uz', $station->getTranslation('address', 'uz', false)) }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label">{{ __('stations.district') }} (UZ)</label>
                                <input name="district[uz]" type="text" value="{{ old('district.uz', $station->getTranslation('district', 'uz', false)) }}" class="form-control">
                            </div>
                        </div>
                    </div>

                    {{-- RU Tab --}}
                    <div class="tab-panel" id="tab-ru" style="display: none;">
                        <div class="form-group">
                            <label class="form-label">{{ __('stations.name_ru') }}</label>
                            <input name="name[ru]" type="text" value="{{ old('name.ru', $station->getTranslation('name', 'ru', false)) }}" class="form-control">
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                            <div class="form-group">
                                <label class="form-label">{{ __('stations.address_ru') }}</label>
                                <input name="address[ru]" type="text" value="{{ old('address.ru', $station->getTranslation('address', 'ru', false)) }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label">{{ __('stations.district') }} (RU)</label>
                                <input name="district[ru]" type="text" value="{{ old('district.ru', $station->getTranslation('district', 'ru', false)) }}" class="form-control">
                            </div>
                        </div>
                    </div>

                    {{-- EN Tab --}}
                    <div class="tab-panel" id="tab-en" style="display: none;">
                        <div class="form-group">
                            <label class="form-label">{{ __('stations.name_en') }}</label>
                            <input name="name[en]" type="text" value="{{ old('name.en', $station->getTranslation('name', 'en', false)) }}" class="form-control">
                        </div>
                        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                            <div class="form-group">
                                <label class="form-label">{{ __('stations.address_en') }}</label>
                                <input name="address[en]" type="text" value="{{ old('address.en', $station->getTranslation('address', 'en', false)) }}" class="form-control">
                            </div>
                            <div class="form-group">
                                <label class="form-label">{{ __('stations.district') }} (EN)</label>
                                <input name="district[en]" type="text" value="{{ old('district.en', $station->getTranslation('district', 'en', false)) }}" class="form-control">
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Lokatsiya --}}
                <h4 style="font-weight: 500; color: var(--text-primary); margin-bottom: 12px;">Lokatsiya</h4>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    <div class="form-group">
                        <label class="form-label">Kenglik (Latitude) xaritadan</label>
                        <input name="latitude" type="number" step="0.00000001" value="{{ old('latitude', $station->latitude) }}" class="form-control">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Uzunlik (Longitude) xaritadan</label>
                        <input name="longitude" type="number" step="0.00000001" value="{{ old('longitude', $station->longitude) }}" class="form-control">
                    </div>
                </div>
            </div>
        </div>

        {{-- Settings sidebar --}}
        <div class="admin-card">
            <div class="admin-card-header">{{ __('stations.settings') }}</div>
            <div class="admin-card-body">
                <div class="form-group">
                    <label class="form-label">{{ __('stations.capacity') }} <span style="color: var(--danger);">*</span></label>
                    <input name="capacity_kw" type="number" value="{{ old('capacity_kw', $station->capacity_kw) }}" required class="form-control @error('capacity_kw') is-invalid @enderror">
                </div>
                <div class="form-group">
                    <label class="form-label">{{ __('stations.price_per_kw') }} <span style="color: var(--danger);">*</span></label>
                    <input name="price_per_kw" type="number" step="0.01" value="{{ old('price_per_kw', $station->price_per_kw) }}" required class="form-control @error('price_per_kw') is-invalid @enderror">
                </div>
                <div class="form-group">
                    <label class="form-label">Eski narx (chegirma bo'lsa) (UZS)</label>
                    <input name="old_price_per_kw" type="number" step="0.01" value="{{ old('old_price_per_kw', $station->old_price_per_kw) }}" class="form-control">
                </div>
                <div class="form-group">
                    <label style="display: inline-flex; align-items: center; gap: 8px; cursor: pointer;">
                        <input name="has_discount" type="checkbox" value="1" {{ old('has_discount', $station->has_discount) ? 'checked' : '' }}>
                        <span style="font-weight: 500; color: var(--text-primary);">Bu stansiyada chegirma bormi?</span>
                    </label>
                </div>
                <div class="form-group">
                    <label class="form-label">{{ __('admins.status') }} <span style="color: var(--danger);">*</span></label>
                    <select name="status" class="form-control">
                        <option value="active" {{ old('status', $station->status) == 'active' ? 'selected' : '' }}>{{ __('status.active') }}</option>
                        <option value="inactive" {{ old('status', $station->status) == 'inactive' ? 'selected' : '' }}>{{ __('status.inactive') }}</option>
                        <option value="maintenance" {{ old('status', $station->status) == 'maintenance' ? 'selected' : '' }}>{{ __('stations.maintenance') }}</option>
                    </select>
                </div>
            </div>
        </div>
    </div>
</form>

<style>
    .tab-btn {
        padding: 8px 16px;
        font-size: 14px;
        font-weight: 500;
        border: none;
        background: none;
        border-bottom: 2px solid transparent;
        color: var(--text-muted);
        cursor: pointer;
    }
    .tab-btn.active {
        color: var(--text-primary);
        border-bottom-color: var(--info);
    }
</style>

<script>
    function switchTab(lang, btn) {
        document.querySelectorAll('.tab-panel').forEach(function(panel) {
            panel.style.display = 'none';
        });
        document.querySelectorAll('.tab-btn').forEach(function(b) {
            b.classList.remove('active');
        });
        document.getElementById('tab-' + lang).style.display = 'block';
        btn.classList.add('active');
    }
</script>
@endsection
