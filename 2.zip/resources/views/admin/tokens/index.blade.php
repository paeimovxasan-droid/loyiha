@extends('admin.layouts.app')

@section('title', 'Tokenizatsiya')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Tokenizatsiya</span>
@endsection

@section('content')

@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.3); color: var(--success); font-size: 13px; margin-bottom: 16px;">
    <i class="fa fa-check-circle" style="margin-right: 6px;"></i> {{ session('success') }}
</div>
@endif

<div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
    {{-- Assets Table --}}
    <div class="admin-card">
        <div class="admin-card-header">
            <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary);">Aktivlar</h3>
        </div>
        <div style="overflow-x: auto;">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Nomi</th>
                        <th style="text-align: center;">Umumiy qiymat</th>
                        <th style="text-align: center;">Tokenlar</th>
                        <th style="text-align: center;">Holat</th>
                        <th style="text-align: center;">Sana</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($assets as $asset)
                    <tr>
                        <td>
                            <div style="font-size: 13px; font-weight: 600; color: var(--text-primary);">{{ $asset->name }}</div>
                            <div style="font-size: 11px; color: var(--text-muted); max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{{ Str::limit($asset->description, 50) }}</div>
                        </td>
                        <td style="text-align: center; font-weight: 600;">{{ number_format($asset->total_value) }} AIS</td>
                        <td style="text-align: center;">{{ number_format($asset->total_tokens) }}</td>
                        <td style="text-align: center;">
                            @if($asset->status == 'active')
                            <span class="badge badge-success">{{ ucfirst($asset->status) }}</span>
                            @elseif($asset->status == 'sold_out')
                            <span class="badge badge-warning">{{ ucfirst($asset->status) }}</span>
                            @else
                            <span class="badge badge-info">{{ ucfirst($asset->status) }}</span>
                            @endif
                        </td>
                        <td style="text-align: center; font-size: 12px; color: var(--text-muted);">{{ $asset->created_at->format('d.m.Y') }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" style="text-align: center; padding: 32px; color: var(--text-muted);">
                            <i class="fa fa-gem" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                            Aktiv topilmadi
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if($assets->hasPages())
        <div style="padding: 14px 20px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between;">
            <span style="font-size: 12px; color: var(--text-muted);">Jami: <strong>{{ $assets->total() }}</strong></span>
            <div class="pagination">
                @if(!$assets->onFirstPage())
                <a href="{{ $assets->previousPageUrl() }}"><i class="fa fa-chevron-left" style="font-size: 10px;"></i></a>
                @endif
                @foreach($assets->getUrlRange(max(1, $assets->currentPage()-2), min($assets->lastPage(), $assets->currentPage()+2)) as $page => $url)
                    @if($page == $assets->currentPage())
                    <span class="active"><span>{{ $page }}</span></span>
                    @else
                    <a href="{{ $url }}">{{ $page }}</a>
                    @endif
                @endforeach
                @if($assets->hasMorePages())
                <a href="{{ $assets->nextPageUrl() }}"><i class="fa fa-chevron-right" style="font-size: 10px;"></i></a>
                @endif
            </div>
        </div>
        @endif
    </div>

    {{-- Create Form --}}
    <div class="admin-card" style="align-self: start;">
        <div class="admin-card-header">
            <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary);">Yangi aktiv</h3>
        </div>
        <div class="admin-card-body">
            <form method="POST" action="{{ route('admin.tokens.store') }}">
                @csrf

                <div class="form-group">
                    <label class="form-label">Nomi</label>
                    <input type="text" name="name" required class="form-control">
                </div>

                <div class="form-group">
                    <label class="form-label">Tavsif</label>
                    <textarea name="description" rows="2" required class="form-control" style="resize: vertical;"></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Umumiy qiymat (AIS)</label>
                    <input type="number" step="1" name="total_value" required class="form-control">
                </div>

                <div class="form-group">
                    <label class="form-label">Tokenlar soni</label>
                    <input type="number" name="total_tokens" required class="form-control">
                </div>

                <button type="submit" class="btn btn-primary" style="width: 100%; margin-top: 8px;">
                    <i class="fa fa-plus" style="margin-right: 4px;"></i> Yaratish
                </button>
            </form>
        </div>
    </div>
</div>

@endsection
