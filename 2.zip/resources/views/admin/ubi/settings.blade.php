@extends('admin.layouts.app')

@section('title', 'UBI Sozlamalari')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">UBI Sozlamalari</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.ubi.claims') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-list"></i> Olishlar tarixi
    </a>
@endsection

@section('content')

@if(session('success'))
<div style="padding: 12px 16px; border-radius: 8px; background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.3); color: var(--success); font-size: 13px; margin-bottom: 16px;">
    <i class="fa fa-check-circle" style="margin-right: 6px;"></i> {{ session('success') }}
</div>
@endif

{{-- Stats --}}
<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px;">
    <div class="admin-card" style="padding: 20px; text-align: center;">
        <div style="font-size: 11px; color: var(--text-muted); text-transform: uppercase; margin-bottom: 6px;">Holat</div>
        <div style="font-size: 20px; font-weight: 700; color: {{ $setting->is_active ? 'var(--success)' : 'var(--danger)' }};">
            {{ $setting->is_active ? 'Faol' : 'O\'chirilgan' }}
        </div>
    </div>
    <div class="admin-card" style="padding: 20px; text-align: center;">
        <div style="font-size: 11px; color: var(--text-muted); text-transform: uppercase; margin-bottom: 6px;">Jami olishlar</div>
        <div style="font-size: 20px; font-weight: 700; color: var(--text-primary);">{{ number_format($totalClaims) }}</div>
    </div>
    <div class="admin-card" style="padding: 20px; text-align: center;">
        <div style="font-size: 11px; color: var(--text-muted); text-transform: uppercase; margin-bottom: 6px;">Jami to'langan</div>
        <div style="font-size: 20px; font-weight: 700; color: var(--primary-light);">{{ number_format($totalPaid, 2) }} AIS</div>
    </div>
</div>

{{-- Settings Form --}}
<div class="admin-card" style="max-width: 480px;">
    <div class="admin-card-header">
        <h3 style="font-size: 15px; font-weight: 700; color: var(--text-primary);">Sozlamalar</h3>
    </div>
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.ubi.settings.update') }}">
            @csrf @method('PUT')

            <div class="form-group">
                <label class="form-label">Kunlik miqdor (AIS)</label>
                <input type="number" step="0.0001" name="daily_amount" value="{{ $setting->daily_amount }}" required class="form-control">
            </div>

            <div class="form-group">
                <label class="form-label">Min daraja</label>
                <input type="number" name="min_level" value="{{ $setting->min_level }}" class="form-control">
            </div>

            <div class="form-group">
                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 13px; color: var(--text-secondary);">
                    <input type="hidden" name="is_active" value="0">
                    <input type="checkbox" name="is_active" value="1" {{ $setting->is_active ? 'checked' : '' }}
                           style="width: 18px; height: 18px; accent-color: var(--primary-light);">
                    Faollashtirish
                </label>
            </div>

            <button type="submit" class="btn btn-primary" style="margin-top: 8px;">
                <i class="fa fa-save" style="margin-right: 4px;"></i> Saqlash
            </button>
        </form>
    </div>
</div>

@endsection
