@extends('admin.layouts.app')

@section('title', 'UBI Olishlar')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.ubi.settings') }}">UBI</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Olishlar tarixi</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.ubi.settings') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> Sozlamalar
    </a>
@endsection

@section('content')

<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Foydalanuvchi</th>
                    <th style="text-align: center;">Miqdor</th>
                    <th style="text-align: center;">Sana</th>
                </tr>
            </thead>
            <tbody>
                @forelse($claims as $claim)
                <tr>
                    <td>
                        <span style="font-size: 13px; font-weight: 600; color: var(--text-primary);">{{ $claim->user->name ?? '—' }}</span>
                        <span style="font-size: 11px; color: var(--text-muted); margin-left: 4px;">{{ $claim->user->username ?? '' }}</span>
                    </td>
                    <td style="text-align: center;">
                        <span style="font-weight: 600; color: var(--success);">+{{ number_format($claim->amount, 4) }} AIS</span>
                    </td>
                    <td style="text-align: center; font-size: 12px; color: var(--text-muted);">
                        {{ $claim->claimed_at->format('d.m.Y H:i') }}
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="3" style="text-align: center; padding: 32px; color: var(--text-muted);">
                        <i class="fa fa-inbox" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                        Olish topilmadi
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($claims->hasPages())
    <div style="padding: 14px 20px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between;">
        <span style="font-size: 12px; color: var(--text-muted);">Jami: <strong>{{ $claims->total() }}</strong></span>
        <div class="pagination">
            @if(!$claims->onFirstPage())
            <a href="{{ $claims->previousPageUrl() }}"><i class="fa fa-chevron-left" style="font-size: 10px;"></i></a>
            @endif
            @foreach($claims->getUrlRange(max(1, $claims->currentPage()-2), min($claims->lastPage(), $claims->currentPage()+2)) as $page => $url)
                @if($page == $claims->currentPage())
                <span class="active"><span>{{ $page }}</span></span>
                @else
                <a href="{{ $url }}">{{ $page }}</a>
                @endif
            @endforeach
            @if($claims->hasMorePages())
            <a href="{{ $claims->nextPageUrl() }}"><i class="fa fa-chevron-right" style="font-size: 10px;"></i></a>
            @endif
        </div>
    </div>
    @endif
</div>

@endsection
