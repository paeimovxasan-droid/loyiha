<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Admin') — {{ config('app.name') }}</title>
    <link rel="icon" type="image/png" href="{{ $global_setting->favicon_url }}">

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    {{-- Alpine.js for interactive components --}}
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

    @if(file_exists(public_path('build/manifest.json')))
        @vite(['resources/css/app.css', 'resources/js/app.js'])
    @endif

    <style>
        :root {
            --sidebar-width: 260px;
            --sidebar-collapsed: 68px;
            --header-height: 56px;
            --primary: #6366f1;
            --primary-light: #818cf8;
            --primary-dark: #4f46e5;
            --bg-body: #0f1117;
            --bg-sidebar: #13151d;
            --bg-header: rgba(19, 21, 29, 0.85);
            --bg-card: #1a1d27;
            --bg-card-hover: #1f2230;
            --bg-input: #1a1d27;
            --border: rgba(255,255,255,.06);
            --border-hover: rgba(99,102,241,.3);
            --text-primary: #f1f5f9;
            --text-secondary: #94a3b8;
            --text-muted: #64748b;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #06b6d4;
            --radius: 10px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-body);
            color: var(--text-primary);
            min-height: 100vh;
            -webkit-font-smoothing: antialiased;
        }

        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(99,102,241,.3); border-radius: 4px; }

        /* ═══ LAYOUT ═══ */
        .admin-layout {
            display: flex;
            min-height: 100vh;
        }

        /* ═══ SIDEBAR ═══ */
        .admin-sidebar {
            width: var(--sidebar-width);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 50;
            background: var(--bg-sidebar);
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            transition: width .25s cubic-bezier(.4,0,.2,1), transform .25s;
            overflow: hidden;
        }

        .sidebar-header {
            height: var(--header-height);
            display: flex;
            align-items: center;
            padding: 0 16px;
            border-bottom: 1px solid var(--border);
            flex-shrink: 0;
            gap: 10px;
        }

        .sidebar-logo {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
        }

        .sidebar-logo img { width: 30px; height: 30px; border-radius: 8px; }
        .sidebar-logo span { font-size: 15px; font-weight: 700; color: var(--text-primary); letter-spacing: -.3px; }

        .sidebar-toggle {
            margin-left: auto;
            width: 28px;
            height: 28px;
            border-radius: 6px;
            background: rgba(255,255,255,.04);
            border: 1px solid var(--border);
            color: var(--text-muted);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            transition: all .2s;
        }

        .sidebar-toggle:hover { background: rgba(99,102,241,.1); color: var(--primary-light); border-color: var(--border-hover); }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 12px 8px;
        }

        .nav-section {
            margin-bottom: 16px;
        }

        .nav-section-title {
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: .8px;
            color: var(--text-muted);
            padding: 0 10px;
            margin-bottom: 6px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px 10px;
            border-radius: 8px;
            text-decoration: none;
            color: var(--text-secondary);
            font-size: 13px;
            font-weight: 500;
            transition: all .15s;
            position: relative;
            margin-bottom: 1px;
        }

        .nav-link:hover { background: rgba(255,255,255,.04); color: var(--text-primary); }

        .nav-link.active {
            background: rgba(99,102,241,.1);
            color: var(--primary-light);
        }

        .nav-link.active::before {
            content: '';
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 3px;
            height: 16px;
            background: var(--primary);
            border-radius: 0 3px 3px 0;
        }

        .nav-link i { width: 18px; text-align: center; font-size: 14px; flex-shrink: 0; }

        .nav-badge {
            margin-left: auto;
            min-width: 18px;
            height: 18px;
            border-radius: 9px;
            background: var(--danger);
            color: #fff;
            font-size: 10px;
            font-weight: 700;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0 5px;
        }

        .nav-badge.warning { background: var(--warning); }

        .sidebar-footer {
            padding: 12px;
            border-top: 1px solid var(--border);
            flex-shrink: 0;
        }

        .sidebar-user {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 8px;
            border-radius: 8px;
            transition: background .15s;
        }

        .sidebar-user:hover { background: rgba(255,255,255,.04); }

        .sidebar-user-avatar {
            width: 34px;
            height: 34px;
            border-radius: 8px;
            object-fit: cover;
            border: 2px solid rgba(99,102,241,.3);
        }

        .sidebar-user-info { flex: 1; min-width: 0; }
        .sidebar-user-name { font-size: 13px; font-weight: 600; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .sidebar-user-role { font-size: 11px; color: var(--text-muted); }

        /* ═══ MAIN CONTENT ═══ */
        .admin-main {
            flex: 1;
            margin-left: var(--sidebar-width);
            min-height: 100vh;
            transition: margin-left .25s cubic-bezier(.4,0,.2,1);
        }

        .admin-header {
            height: var(--header-height);
            position: sticky;
            top: 0;
            z-index: 40;
            background: var(--bg-header);
            backdrop-filter: blur(16px);
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 24px;
        }

        .header-breadcrumb {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
            color: var(--text-muted);
        }

        .header-breadcrumb a { color: var(--text-secondary); text-decoration: none; transition: color .15s; }
        .header-breadcrumb a:hover { color: var(--primary-light); }
        .header-breadcrumb .current { color: var(--text-primary); font-weight: 500; }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .admin-content {
            padding: 24px;
        }

        /* ═══ CARDS ═══ */
        .admin-card {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            overflow: hidden;
        }

        .admin-card-header {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .admin-card-title { font-size: 14px; font-weight: 600; color: var(--text-primary); }
        .admin-card-body { padding: 20px; }

        /* ═══ STAT CARDS ═══ */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 14px;
            margin-bottom: 20px;
        }

        .admin-stat {
            background: var(--bg-card);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 16px;
            transition: all .2s;
        }

        .admin-stat:hover { border-color: var(--border-hover); transform: translateY(-1px); }

        .admin-stat-icon {
            width: 36px;
            height: 36px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .admin-stat-value { font-size: 22px; font-weight: 700; color: var(--text-primary); letter-spacing: -.4px; }
        .admin-stat-label { font-size: 12px; color: var(--text-muted); margin-top: 2px; }

        /* ═══ TABLE ═══ */
        .admin-table {
            width: 100%;
            border-collapse: collapse;
        }

        .admin-table th {
            padding: 10px 14px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: .5px;
            color: var(--text-muted);
            text-align: left;
            border-bottom: 1px solid var(--border);
        }

        .admin-table td {
            padding: 12px 14px;
            font-size: 13px;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--border);
        }

        .admin-table tr:hover td { background: rgba(255,255,255,.02); }
        .admin-table tr:last-child td { border-bottom: none; }

        /* ═══ BUTTONS ═══ */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 8px 14px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: all .2s;
            text-decoration: none;
            font-family: inherit;
        }

        .btn:active { transform: scale(.97); }
        .btn-primary { background: var(--primary); color: #fff; }
        .btn-primary:hover { background: var(--primary-dark); }
        .btn-outline { background: transparent; border: 1px solid var(--border); color: var(--text-secondary); }
        .btn-outline:hover { border-color: var(--border-hover); color: var(--text-primary); }
        .btn-success { background: var(--success); color: #fff; }
        .btn-danger { background: var(--danger); color: #fff; }
        .btn-warning { background: var(--warning); color: #fff; }
        .btn-sm { padding: 6px 10px; font-size: 12px; }
        .btn-lg { padding: 12px 20px; font-size: 14px; }

        /* ═══ FORMS ═══ */
        .form-group { margin-bottom: 14px; }
        .form-label { display: block; font-size: 12px; font-weight: 600; color: var(--text-secondary); margin-bottom: 5px; }

        .form-control {
            width: 100%;
            background: var(--bg-input);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 9px 12px;
            color: var(--text-primary);
            font-size: 13px;
            font-family: inherit;
            outline: none;
            transition: all .2s;
        }

        .form-control:focus { border-color: rgba(99,102,241,.5); box-shadow: 0 0 0 3px rgba(99,102,241,.08); }
        .form-control::placeholder { color: var(--text-muted); }

        /* ═══ BADGES ═══ */
        .badge { display: inline-flex; align-items: center; gap: 4px; padding: 3px 8px; border-radius: 6px; font-size: 11px; font-weight: 600; }
        .badge-success { background: rgba(16,185,129,.12); color: #34d399; }
        .badge-danger { background: rgba(239,68,68,.12); color: #f87171; }
        .badge-warning { background: rgba(245,158,11,.12); color: #fbbf24; }
        .badge-info { background: rgba(6,182,212,.12); color: #22d3ee; }
        .badge-primary { background: rgba(99,102,241,.12); color: #a5b4fc; }

        /* ═══ ALERTS ═══ */
        .alert { padding: 12px 14px; border-radius: 10px; font-size: 13px; display: flex; align-items: center; gap: 8px; margin-bottom: 14px; }
        .alert-success { background: rgba(16,185,129,.08); border: 1px solid rgba(16,185,129,.15); color: #34d399; }
        .alert-danger { background: rgba(239,68,68,.08); border: 1px solid rgba(239,68,68,.15); color: #f87171; }
        .alert-warning { background: rgba(245,158,11,.08); border: 1px solid rgba(245,158,11,.15); color: #fbbf24; }
        .alert-info { background: rgba(6,182,212,.08); border: 1px solid rgba(6,182,212,.15); color: #22d3ee; }

        /* ═══ MOBILE ═══ */
        .mobile-menu-btn {
            display: none;
            width: 34px;
            height: 34px;
            border-radius: 8px;
            background: rgba(255,255,255,.04);
            border: 1px solid var(--border);
            color: var(--text-secondary);
            cursor: pointer;
            align-items: center;
            justify-content: center;
            font-size: 14px;
        }

        .sidebar-overlay {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,.5);
            z-index: 45;
        }

        @media (max-width: 1024px) {
            .admin-sidebar { transform: translateX(-100%); z-index: 50; }
            .admin-sidebar.open { transform: translateX(0); }
            .admin-main { margin-left: 0; }
            .mobile-menu-btn { display: flex; }
            .sidebar-overlay.show { display: block; }
        }

        /* ═══ TOAST ═══ */
        .toast-container { position: fixed; top: 12px; right: 16px; z-index: 9999; display: flex; flex-direction: column; gap: 8px; }
        .toast { padding: 12px 14px; border-radius: 10px; display: flex; align-items: center; gap: 8px; font-size: 13px; font-weight: 500; animation: slideIn .3s ease; box-shadow: 0 8px 24px rgba(0,0,0,.3); }
        .toast-success { background: rgba(6,78,59,.95); border: 1px solid rgba(16,185,129,.25); color: #6ee7b7; }
        .toast-danger { background: rgba(127,29,29,.95); border: 1px solid rgba(239,68,68,.25); color: #fca5a5; }
        @keyframes slideIn { from { opacity: 0; transform: translateX(16px); } to { opacity: 1; transform: translateX(0); } }

        /* ═══ PAGINATION ═══ */
        .pagination { display: flex; align-items: center; gap: 4px; justify-content: center; margin-top: 16px; }
        .pagination a, .pagination span { padding: 6px 10px; border-radius: 6px; font-size: 12px; font-weight: 500; text-decoration: none; color: var(--text-secondary); border: 1px solid var(--border); transition: all .15s; }
        .pagination a:hover { border-color: var(--border-hover); color: var(--primary-light); }
        .pagination .active span { background: var(--primary); border-color: var(--primary); color: #fff; }
    </style>

    @stack('styles')
</head>
<body>

{{-- Toast --}}
<div class="toast-container">
    @if(session('success'))
    <div class="toast toast-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
    @endif
    @if(session('error'))
    <div class="toast toast-danger"><i class="fa fa-times-circle"></i> {{ session('error') }}</div>
    @endif
</div>

{{-- Sidebar Overlay (mobile) --}}
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

<div class="admin-layout">
    {{-- ═══ SIDEBAR ═══ --}}
    <aside class="admin-sidebar" id="adminSidebar">
        <div class="sidebar-header">
            <a href="{{ route('admin.dashboard') }}" class="sidebar-logo">
                <img src="{{ $global_setting->logo_url }}" alt="Logo">
                <span>{{ config('app.name') }}</span>
            </a>
            <button class="sidebar-toggle" onclick="closeSidebar()">
                <i class="fa fa-chevron-left"></i>
            </button>
        </div>

        <nav class="sidebar-nav">
            {{-- Asosiy --}}
            <div class="nav-section">
                <div class="nav-section-title">Asosiy</div>
                <a href="{{ route('admin.dashboard') }}" class="nav-link {{ request()->routeIs('admin.dashboard') ? 'active' : '' }}">
                    <i class="fa fa-grid-2"></i> Dashboard
                </a>
                @can('users.view')
                <a href="{{ route('admin.users.index') }}" class="nav-link {{ request()->routeIs('admin.users.*') ? 'active' : '' }}">
                    <i class="fa fa-users"></i> Mijozlar
                </a>
                @endcan
                @can('admins.view')
                <a href="{{ route('admin.admins.index') }}" class="nav-link {{ request()->routeIs('admin.admins.*') ? 'active' : '' }}">
                    <i class="fa fa-user-shield"></i> Boshqaruvchilar
                </a>
                @endcan
            </div>

            {{-- Moliya --}}
            <div class="nav-section">
                <div class="nav-section-title">Moliya</div>
                @can('deposits.view')
                <a href="{{ route('admin.deposits.index') }}" class="nav-link {{ request()->routeIs('admin.deposits.*') ? 'active' : '' }}">
                    <i class="fa fa-arrow-down"></i> Depozitlar
                    @php $pd = \App\Models\Payment\Deposit::pending()->count(); @endphp
                    @if($pd > 0)<span class="nav-badge">{{ $pd }}</span>@endif
                </a>
                @endcan
                @can('withdrawals.view')
                <a href="{{ route('admin.withdrawals.index') }}" class="nav-link {{ request()->routeIs('admin.withdrawals.*') ? 'active' : '' }}">
                    <i class="fa fa-arrow-up"></i> Yechib olish
                    @php $pw = \App\Models\Payment\Withdrawal::pending()->count(); @endphp
                    @if($pw > 0)<span class="nav-badge">{{ $pw }}</span>@endif
                </a>
                @endcan
                @can('packages.view')
                <a href="{{ route('admin.packages.index') }}" class="nav-link {{ request()->routeIs('admin.packages.*') ? 'active' : '' }}">
                    <i class="fa fa-cube"></i> Paketlar
                </a>
                @endcan
                @can('payment-methods.view')
                <a href="{{ route('admin.payment_methods.index') }}" class="nav-link {{ request()->routeIs('admin.payment_methods.*') ? 'active' : '' }}">
                    <i class="fa fa-credit-card"></i> To'lov usullari
                </a>
                @endcan
                @can('settings.view')
                <a href="{{ route('admin.ais.rate') }}" class="nav-link {{ request()->routeIs('admin.ais.*') ? 'active' : '' }}">
                    <i class="fa fa-coins"></i> AIS Valyuta
                </a>
                @endcan
                <a href="{{ route('admin.funds.index') }}" class="nav-link {{ request()->routeIs('admin.funds.*') ? 'active' : '' }}">
                    <i class="fa fa-chart-pie"></i> Fondlar
                </a>
                <a href="{{ route('admin.credits.index') }}" class="nav-link {{ request()->routeIs('admin.credits.*') ? 'active' : '' }}">
                    <i class="fa fa-hand-holding-dollar"></i> Kredit
                </a>
                <a href="{{ route('admin.savings.index') }}" class="nav-link {{ request()->routeIs('admin.savings.*') ? 'active' : '' }}">
                    <i class="fa fa-piggy-bank"></i> Jamg'arma
                </a>
                @can('settings.view')
                <a href="{{ route('admin.exchange.settings.index') }}" class="nav-link {{ request()->routeIs('admin.exchange.*') ? 'active' : '' }}">
                    <i class="fa fa-arrow-right-arrow-left"></i> Birja
                </a>
                @endcan
            </div>

            {{-- Gamification --}}
            <div class="nav-section">
                <div class="nav-section-title">Gamification</div>
                <a href="{{ route('admin.levels.index') }}" class="nav-link {{ request()->routeIs('admin.levels.*') ? 'active' : '' }}">
                    <i class="fa fa-bolt"></i> Level tizimi
                </a>
                <a href="{{ route('admin.leaders.index') }}" class="nav-link {{ request()->routeIs('admin.leaders.*') ? 'active' : '' }}">
                    <i class="fa fa-crown"></i> Liderlar
                </a>
                @can('tasks.view')
                <a href="{{ route('admin.tasks.index') }}" class="nav-link {{ request()->routeIs('admin.tasks.*') ? 'active' : '' }}">
                    <i class="fa fa-list-check"></i> Topshiriqlar
                    @php $pt = \App\Models\Game\UserTask::where('status','pending')->count(); @endphp
                    @if($pt > 0)<span class="nav-badge warning">{{ $pt }}</span>@endif
                </a>
                @endcan
                <a href="{{ route('admin.quests.index') }}" class="nav-link {{ request()->routeIs('admin.quests.*') ? 'active' : '' }}">
                    <i class="fa fa-scroll"></i> Kvestlar
                </a>
                <a href="{{ route('admin.lucky-draw.index') }}" class="nav-link {{ request()->routeIs('admin.lucky-draw.*') ? 'active' : '' }}">
                    <i class="fa fa-dice"></i> Lucky Draw
                </a>
            </div>

            {{-- Foydalanuvchi --}}
            <div class="nav-section">
                <div class="nav-section-title">Foydalanuvchi</div>
                <a href="{{ route('admin.kyc.index') }}" class="nav-link {{ request()->routeIs('admin.kyc.*') ? 'active' : '' }}">
                    <i class="fa fa-id-card"></i> KYC
                    @php $pk = \App\Models\User::whereIn('kyc_status', ['passport_pending','face_pending'])->count(); @endphp
                    @if($pk > 0)<span class="nav-badge">{{ $pk }}</span>@endif
                </a>
                <a href="{{ route('admin.support.index') }}" class="nav-link {{ request()->routeIs('admin.support.*') ? 'active' : '' }}">
                    <i class="fa fa-headset"></i> Qo'llab-quvvatlash
                </a>
                <a href="{{ route('admin.fraud.index') }}" class="nav-link {{ request()->routeIs('admin.fraud.*') ? 'active' : '' }}">
                    <i class="fa fa-shield-halved"></i> Anti-Fraud
                </a>
            </div>

            {{-- Modullar --}}
            <div class="nav-section">
                <div class="nav-section-title">Modullar</div>
                <a href="{{ route('admin.crowdfunding.index') }}" class="nav-link {{ request()->routeIs('admin.crowdfunding.*') ? 'active' : '' }}">
                    <i class="fa fa-heart"></i> Crowdfunding
                </a>
                <a href="{{ route('admin.marketplace.index') }}" class="nav-link {{ request()->routeIs('admin.marketplace.*') ? 'active' : '' }}">
                    <i class="fa fa-store"></i> Marketplace
                </a>
                <a href="{{ route('admin.education.index') }}" class="nav-link {{ request()->routeIs('admin.education.*') ? 'active' : '' }}">
                    <i class="fa fa-graduation-cap"></i> Ta'lim
                </a>
                <a href="{{ route('admin.catalog.shops') }}" class="nav-link {{ request()->routeIs('admin.catalog.*') ? 'active' : '' }}">
                    <i class="fa fa-shopping-bag"></i> Katalog
                </a>
                <a href="{{ route('admin.medical.dashboard') }}" class="nav-link {{ request()->routeIs('admin.medical.*') ? 'active' : '' }}">
                    <i class="fa fa-stethoscope"></i> Tibbiyot
                </a>
                <a href="{{ route('admin.agromarket.listings') }}" class="nav-link {{ request()->routeIs('admin.agromarket.*') ? 'active' : '' }}">
                    <i class="fa fa-seedling"></i> AgroMarket
                </a>
                <a href="{{ route('admin.gig-economy.listings') }}" class="nav-link {{ request()->routeIs('admin.gig-economy.*') ? 'active' : '' }}">
                    <i class="fa fa-briefcase"></i> Gig Economy
                </a>
                <a href="{{ route('admin.lending.loans') }}" class="nav-link {{ request()->routeIs('admin.lending.*') ? 'active' : '' }}">
                    <i class="fa fa-handshake"></i> P2P Qarz
                </a>
                <a href="{{ route('admin.influencer.channels.index') }}" class="nav-link {{ request()->routeIs('admin.influencer.*') ? 'active' : '' }}">
                    <i class="fa fa-bullhorn"></i> Influencer
                </a>
                <a href="{{ route('admin.ad-network.campaigns') }}" class="nav-link {{ request()->routeIs('admin.ad-network.*') ? 'active' : '' }}">
                    <i class="fa fa-rectangle-ad"></i> Reklama
                </a>
            </div>

            {{-- Marketing --}}
            <div class="nav-section">
                <div class="nav-section-title">Marketing</div>
                <a href="{{ route('admin.marketing.promo-codes.index') }}" class="nav-link {{ request()->routeIs('admin.marketing.*') ? 'active' : '' }}">
                    <i class="fa fa-tags"></i> Marketing
                </a>
                <a href="{{ route('admin.roadmap.index') }}" class="nav-link {{ request()->routeIs('admin.roadmap.*') ? 'active' : '' }}">
                    <i class="fa fa-road"></i> Roadmap
                </a>
                @can('settings.view')
                <a href="{{ route('admin.channel-posts.index') }}" class="nav-link {{ request()->routeIs('admin.channel-posts.*') ? 'active' : '' }}">
                    <i class="fa fa-paper-plane"></i> Kanal postlari
                </a>
                @endcan
            </div>

            {{-- Tizim --}}
            <div class="nav-section">
                <div class="nav-section-title">Tizim</div>
                @can('settings.view')
                <a href="{{ route('admin.ubi.settings') }}" class="nav-link {{ request()->routeIs('admin.ubi.*') ? 'active' : '' }}">
                    <i class="fa fa-gift"></i> UBI
                </a>
                <a href="{{ route('admin.tokens.index') }}" class="nav-link {{ request()->routeIs('admin.tokens.*') ? 'active' : '' }}">
                    <i class="fa fa-gem"></i> Tokenizatsiya
                </a>
                <a href="{{ route('admin.faq.index') }}" class="nav-link {{ request()->routeIs('admin.faq.*') ? 'active' : '' }}">
                    <i class="fa fa-circle-question"></i> FAQ
                </a>
                <a href="{{ route('admin.stations.index') }}" class="nav-link {{ request()->routeIs('admin.stations.*') ? 'active' : '' }}">
                    <i class="fa fa-charging-station"></i> Stansiyalar
                </a>
                @endcan
                @can('roles.view')
                <a href="{{ route('admin.roles.index') }}" class="nav-link {{ request()->routeIs('admin.roles.*') ? 'active' : '' }}">
                    <i class="fa fa-user-gear"></i> Rollar
                </a>
                @endcan
                @can('translations.view')
                <a href="{{ route('admin.translations.index') }}" class="nav-link {{ request()->routeIs('admin.translations.*') ? 'active' : '' }}">
                    <i class="fa fa-language"></i> Tarjimalar
                </a>
                @endcan
                @can('settings.view')
                <a href="{{ route('admin.settings.index') }}" class="nav-link {{ request()->routeIs('admin.settings.*') ? 'active' : '' }}">
                    <i class="fa fa-gear"></i> Sozlamalar
                </a>
                @endcan
            </div>
        </nav>

        <div class="sidebar-footer">
            <div class="sidebar-user">
                <img src="{{ auth()->user()->avatar_url }}" alt="" class="sidebar-user-avatar">
                <div class="sidebar-user-info">
                    <div class="sidebar-user-name">{{ auth()->user()->name }}</div>
                    <div class="sidebar-user-role">{{ auth()->user()->getRoleNames()->first() ?? 'Admin' }}</div>
                </div>
                <form method="POST" action="{{ route('admin.logout') }}" style="margin:0;">
                    @csrf
                    <button type="submit" style="background:none; border:none; color:var(--text-muted); cursor:pointer; padding:6px; border-radius:6px; transition:all .15s;"
                            onmouseenter="this.style.color='var(--danger)'; this.style.background='rgba(239,68,68,.1)'"
                            onmouseleave="this.style.color='var(--text-muted)'; this.style.background='none'"
                            title="Chiqish">
                        <i class="fa fa-right-from-bracket"></i>
                    </button>
                </form>
            </div>
        </div>
    </aside>

    {{-- ═══ MAIN ═══ --}}
    <div class="admin-main">
        <header class="admin-header">
            <div style="display:flex; align-items:center; gap:12px;">
                <button class="mobile-menu-btn" onclick="openSidebar()">
                    <i class="fa fa-bars"></i>
                </button>
                <nav class="header-breadcrumb">
                    @hasSection('breadcrumb')
                        @yield('breadcrumb')
                    @else
                        <span class="current">Dashboard</span>
                    @endif
                </nav>
            </div>
            <div class="header-actions">
                @yield('header-actions')
            </div>
        </header>

        <main class="admin-content">
            @yield('content')
        </main>
    </div>
</div>

<script>
    // Sidebar toggle
    function openSidebar() {
        document.getElementById('adminSidebar').classList.add('open');
        document.getElementById('sidebarOverlay').classList.add('show');
    }
    function closeSidebar() {
        document.getElementById('adminSidebar').classList.remove('open');
        document.getElementById('sidebarOverlay').classList.remove('show');
    }

    // Toast auto-dismiss
    setTimeout(() => {
        document.querySelectorAll('.toast').forEach(t => {
            t.style.transition = 'opacity .3s, transform .3s';
            t.style.opacity = '0';
            setTimeout(() => t.remove(), 300);
        });
    }, 4000);

    // ═══ FILE UPLOAD (admin panel) ═══
    function handleFileUpload(uid, input) {
        var file = input.files[0];
        if (!file) return;

        var widget = document.getElementById(uid);
        var folder = widget.dataset.folder;
        var uploadUrl = widget.dataset.uploadUrl;
        var spinner = document.getElementById(uid + '_spinner');
        var errorEl = document.getElementById(uid + '_error');

        // Reset error
        errorEl.style.display = 'none';
        errorEl.textContent = '';

        // Show spinner
        spinner.style.display = 'flex';
        // Upload via AJAX
        var formData = new FormData();
        formData.append('file', file);
        formData.append('folder', folder);
        formData.append('_token', document.querySelector('meta[name="csrf-token"]').content);

        fetch(uploadUrl, {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
            }
        })
        .then(function(response) { return response.json(); })
        .then(function(data) {
            spinner.style.display = 'none';

            if (data.success) {
                // Set hidden input value
                document.getElementById(uid + '_id').value = data.id;

                // Show preview
                document.getElementById(uid + '_img').src = data.url;
                document.getElementById(uid + '_preview').style.display = 'block';
                document.getElementById(uid + '_zone').style.display = 'none';
            } else {
                errorEl.textContent = data.message || 'Yuklashda xatolik';
                errorEl.style.display = 'block';
            }
        })
        .catch(function(err) {
            spinner.style.display = 'none';
            errorEl.textContent = 'Server xatosi: ' + err.message;
            errorEl.style.display = 'block';
        });
    }

    function resetUpload(uid) {
        document.getElementById(uid + '_id').value = '';
        document.getElementById(uid + '_img').src = '';
        document.getElementById(uid + '_preview').style.display = 'none';
        document.getElementById(uid + '_zone').style.display = 'block';
        var input = document.getElementById(uid + '_input');
        if (input) input.value = '';
    }
</script>

@stack('scripts')
</body>
</html>
