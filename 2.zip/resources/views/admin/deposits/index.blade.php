@extends('admin.layouts.app')

@section('title', 'Depozitlar')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('deposits.title') }}</span>
@endsection

@section('content')

{{-- Filters --}}
<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; flex-wrap: wrap; gap: 10px;">
    <h2 style="font-size: 18px; font-weight: 700; color: var(--text-primary);">{{ __('deposits.requests') }}</h2>
    <form action="{{ route('admin.deposits.index') }}" method="GET" style="display: flex; gap: 8px; align-items: center;">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="{{ __('buttons.search') }}..."
               class="form-control" style="width: 160px; padding: 7px 12px; font-size: 12px;">
        <select name="status" onchange="this.form.submit()" class="form-control" style="width: 130px; padding: 7px 12px; font-size: 12px;">
            <option value="">{{ __('table.status') }}</option>
            <option value="pending" {{ request('status') === 'pending' ? 'selected' : '' }}>{{ __('status.pending') }}</option>
            <option value="approved" {{ request('status') === 'approved' ? 'selected' : '' }}>{{ __('status.approved') }}</option>
            <option value="rejected" {{ request('status') === 'rejected' ? 'selected' : '' }}>{{ __('status.rejected') }}</option>
        </select>
        @if(request()->anyFilled(['search', 'status']))
        <a href="{{ route('admin.deposits.index') }}" class="btn btn-outline btn-sm"><i class="fa fa-times"></i></a>
        @endif
    </form>
</div>

{{-- Table --}}
<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>{{ __('table.order_date') }}</th>
                    <th>{{ __('table.client') }}</th>
                    <th>{{ __('table.payment_method_sender') }}</th>
                    <th>{{ __('table.amount_net') }}</th>
                    <th>{{ __('table.status') }}</th>
                    <th>{{ __('table.details') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($deposits as $deposit)
                <tr>
                    <td>
                        <div style="font-size: 13px; font-weight: 600; color: var(--text-primary);">{{ $deposit->order_id ?? '#'.$deposit->id }}</div>
                        <div style="font-size: 11px; color: var(--text-muted);">{{ $deposit->created_at->format('d.m.Y H:i') }}</div>
                    </td>
                    <td>
                        <div style="font-size: 13px; font-weight: 500; color: var(--text-primary);">{{ $deposit->user->name ?? 'Noma\'lum' }}</div>
                        <div style="font-size: 11px; color: var(--text-muted);">{{ $deposit->user->email ?? '' }}</div>
                    </td>
                    <td>
                        <div style="font-size: 13px; font-weight: 500; color: var(--text-primary);">{{ $deposit->method_name }}</div>
                        <div style="font-size: 11px; color: var(--text-muted);">{{ $deposit->sender_number }}</div>
                    </td>
                    <td>
                        <div style="font-size: 13px; font-weight: 700; color: var(--success);">{{ number_format($deposit->final_amount, 0) }} UZS</div>
                        <div style="font-size: 11px; color: var(--text-muted);">Fee: {{ number_format($deposit->charge, 0) }}</div>
                    </td>
                    <td>
                        @if($deposit->isPending())
                        <span class="badge badge-warning"><i class="fa fa-clock" style="font-size: 8px;"></i> {{ __('status.pending') }}</span>
                        @elseif($deposit->isApproved())
                        <span class="badge badge-success"><i class="fa fa-check" style="font-size: 8px;"></i> {{ __('status.approved') }}</span>
                        @else
                        <span class="badge badge-danger"><i class="fa fa-times" style="font-size: 8px;"></i> {{ __('status.rejected') }}</span>
                        @endif
                    </td>
                    <td>
                        <a href="{{ route('admin.deposits.show', $deposit) }}" class="btn btn-outline btn-sm">
                            <i class="fa fa-eye"></i>
                        </a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align: center; padding: 32px; color: var(--text-muted);">
                        <i class="fa fa-inbox" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                        {{ __('table.not_found') }}
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($deposits->hasPages())
    <div style="padding: 14px 20px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: center;">
        <div class="pagination">
            @if(!$deposits->onFirstPage())
            <a href="{{ $deposits->previousPageUrl() }}"><i class="fa fa-chevron-left" style="font-size: 10px;"></i></a>
            @endif
            @foreach($deposits->getUrlRange(max(1, $deposits->currentPage()-2), min($deposits->lastPage(), $deposits->currentPage()+2)) as $page => $url)
                @if($page == $deposits->currentPage())
                <span class="active"><span>{{ $page }}</span></span>
                @else
                <a href="{{ $url }}">{{ $page }}</a>
                @endif
            @endforeach
            @if($deposits->hasMorePages())
            <a href="{{ $deposits->nextPageUrl() }}"><i class="fa fa-chevron-right" style="font-size: 10px;"></i></a>
            @endif
        </div>
    </div>
    @endif
</div>

@endsection
