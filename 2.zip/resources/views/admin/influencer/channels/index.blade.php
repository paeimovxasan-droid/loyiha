@extends('admin.layouts.app')

@section('title', 'Influencer Kanallar')
@section('sidebar-title', 'Influencer')

@section('breadcrumb')
    <li class="flex items-center space-x-2">
        <a href="{{ route('admin.dashboard') }}" class="text-primary hover:text-primary-focus">Admin</a>
        <svg xmlns="http://www.w3.org/2000/svg" class="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
    </li>
    <li>Influencer Kanallar</li>
@endsection

@section('content')
<div class="flex items-center justify-between mt-4">
    <h2 class="text-base font-medium text-slate-700 dark:text-navy-100">Influencer Kanallar</h2>
</div>

{{-- Filtrlar --}}
<div class="card mt-3 p-4">
    <form method="GET" class="flex flex-wrap gap-3">
        <select name="status" class="form-select w-40">
            <option value="">Barcha holat</option>
            <option value="pending" @selected(request('status')=='pending')>Kutilmoqda</option>
            <option value="approved" @selected(request('status')=='approved')>Tasdiqlangan</option>
            <option value="rejected" @selected(request('status')=='rejected')>Rad etilgan</option>
            <option value="suspended" @selected(request('status')=='suspended')>Bloklangan</option>
        </select>
        <select name="type" class="form-select w-44">
            <option value="">Barcha tur</option>
            @foreach($types as $key => $label)
                <option value="{{ $key }}" @selected(request('type')==$key)>{{ $label }}</option>
            @endforeach
        </select>
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Kanal nomi yoki URL..." class="form-input w-56">
        <button type="submit" class="btn bg-primary text-white">Qidirish</button>
        <a href="{{ route('admin.influencer.channels.index') }}" class="btn bg-slate-200 text-slate-700">Tozalash</a>
    </form>
</div>

@if(session('success'))
    <div class="alert alert-success mt-3">{{ session('success') }}</div>
@endif
@if(session('error'))
    <div class="alert alert-error mt-3">{{ session('error') }}</div>
@endif

<div class="card mt-3">
    <div class="is-scrollbar-hidden min-w-full overflow-x-auto">
        <table class="is-hoverable w-full text-left">
            <thead>
                <tr>
                    <th class="whitespace-nowrap rounded-tl-lg bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">#</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Publisher</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Kanal</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Tur</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Obunachi</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Holat</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Sana</th>
                    <th class="whitespace-nowrap rounded-tr-lg bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Amallar</th>
                </tr>
            </thead>
            <tbody>
                @forelse($channels as $channel)
                <tr class="border-y border-transparent border-b-slate-200 dark:border-b-navy-500">
                    <td class="px-4 py-3 text-sm">{{ $channel->id }}</td>
                    <td class="px-4 py-3">
                        <div class="text-sm font-medium">{{ $channel->user->name }}</div>
                        <div class="text-xs text-slate-400">{{ $channel->user->username }}</div>
                    </td>
                    <td class="px-4 py-3">
                        <div class="text-sm font-medium">{{ $channel->name }}</div>
                        <a href="{{ $channel->url }}" target="_blank" class="text-xs text-primary hover:underline">{{ Str::limit($channel->url, 40) }}</a>
                    </td>
                    <td class="px-4 py-3 text-sm">{{ $channel->type_label }}</td>
                    <td class="px-4 py-3 text-sm">{{ number_format($channel->subscriber_count) }}</td>
                    <td class="px-4 py-3">{!! $channel->status_badge !!}</td>
                    <td class="px-4 py-3 text-xs text-slate-400">{{ $channel->created_at->format('d.m.Y') }}</td>
                    <td class="px-4 py-3">
                        <div class="flex items-center gap-2">
                            @if($channel->status === 'pending')
                                <form method="POST" action="{{ route('admin.influencer.channels.approve', $channel) }}">
                                    @csrf
                                    <button type="submit" class="btn btn-sm bg-success text-white" onclick="return confirm('Tasdiqlaysizmi?')">✅ Tasdiqlash</button>
                                </form>
                                <button type="button" class="btn btn-sm bg-error text-white"
                                    x-data x-on:click="$dispatch('open-reject-modal', { id: {{ $channel->id }}, url: '{{ route('admin.influencer.channels.reject', $channel) }}' })">
                                    ❌ Rad etish
                                </button>
                            @elseif($channel->status === 'approved')
                                <form method="POST" action="{{ route('admin.influencer.channels.suspend', $channel) }}">
                                    @csrf
                                    <button type="submit" class="btn btn-sm bg-warning text-white" onclick="return confirm('Bloklaysizmi?')">⛔ Bloklash</button>
                                </form>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="8" class="px-4 py-8 text-center text-slate-400">Kanallar topilmadi</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="p-4">{{ $channels->links() }}</div>
</div>

{{-- Rad etish modal --}}
<div x-data="{ open: false, url: '', id: '' }"
     x-on:open-reject-modal.window="open = true; url = $event.detail.url; id = $event.detail.id"
     x-show="open" x-cloak
     class="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
    <div class="card w-full max-w-md p-6" @click.outside="open = false">
        <h3 class="text-lg font-semibold mb-4">Rad etish sababi</h3>
        <form :action="url" method="POST">
            @csrf
            <textarea name="reason" rows="3" class="form-textarea w-full" placeholder="Rad etish sababini kiriting..." required></textarea>
            <div class="flex justify-end gap-2 mt-4">
                <button type="button" class="btn bg-slate-200" @click="open = false">Bekor qilish</button>
                <button type="submit" class="btn bg-error text-white">Rad etish</button>
            </div>
        </form>
    </div>
</div>
@endsection
