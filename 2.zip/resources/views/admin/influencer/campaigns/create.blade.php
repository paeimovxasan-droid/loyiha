@extends('admin.layouts.app')

@section('title', 'Yangi Kampaniya')

@section('breadcrumb')
    <li class="flex items-center space-x-2">
        <a href="{{ route('admin.influencer.campaigns.index') }}" class="text-primary hover:text-primary-focus">Kampaniyalar</a>
        <svg xmlns="http://www.w3.org/2000/svg" class="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
    </li>
    <li>Yangi Kampaniya</li>
@endsection

@section('content')
<div class="mt-4">
    <h2 class="text-base font-medium text-slate-700 dark:text-navy-100">Yangi Influencer Kampaniya</h2>
</div>

<form method="POST" action="{{ route('admin.influencer.campaigns.store') }}" enctype="multipart/form-data" class="mt-4 space-y-4">
    @csrf

    <div class="card p-6 space-y-4">
        <h3 class="font-semibold text-slate-700">Asosiy ma'lumotlar</h3>

        <div>
            <label class="block text-sm font-medium mb-1">Kampaniya nomi *</label>
            <input type="text" name="name" value="{{ old('name') }}" class="form-input w-full" required>
            @error('name')<p class="text-error text-xs mt-1">{{ $message }}</p>@enderror
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Tavsif</label>
            <textarea name="description" rows="2" class="form-textarea w-full">{{ old('description') }}</textarea>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Reklama matni (UZ) *</label>
            <textarea name="ad_text_uz" rows="3" class="form-textarea w-full" required>{{ old('ad_text_uz') }}</textarea>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Reklama matni (RU)</label>
            <textarea name="ad_text_ru" rows="3" class="form-textarea w-full">{{ old('ad_text_ru') }}</textarea>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Reklama matni (EN)</label>
            <textarea name="ad_text_en" rows="3" class="form-textarea w-full">{{ old('ad_text_en') }}</textarea>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Maqsadli URL *</label>
            <input type="url" name="target_url" value="{{ old('target_url', 'https://aisoqqa.uz') }}" class="form-input w-full" required>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Reklama rasmi (ixtiyoriy)</label>
            <input type="file" name="image" accept="image/*" class="form-input w-full">
        </div>
    </div>

    <div class="card p-6 space-y-4">
        <h3 class="font-semibold text-slate-700">Moliyaviy sozlamalar</h3>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Asosiy mukofot (AIS) *</label>
                <input type="number" name="reward_amount" value="{{ old('reward_amount') }}" step="0.0001" min="0.0001" class="form-input w-full" required>
                <p class="text-xs text-slate-400 mt-1">Koeffitsient bilan ko'paytiriladi</p>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Umumiy byudjet (AIS) *</label>
                <input type="number" name="total_budget" value="{{ old('total_budget') }}" step="0.0001" min="0.0001" class="form-input w-full" required>
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Boshlanish sanasi *</label>
                <input type="datetime-local" name="starts_at" value="{{ old('starts_at') }}" class="form-input w-full" required>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Tugash sanasi *</label>
                <input type="datetime-local" name="ends_at" value="{{ old('ends_at') }}" class="form-input w-full" required>
            </div>
        </div>
    </div>

    <div class="card p-6 space-y-4">
        <h3 class="font-semibold text-slate-700">Kanal sozlamalari</h3>

        <div>
            <label class="block text-sm font-medium mb-2">Maqsadli kanal turlari *</label>
            <div class="flex flex-wrap gap-3">
                @foreach($channelTypes as $key => $label)
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="target_channel_types[]" value="{{ $key }}"
                        {{ in_array($key, old('target_channel_types', [])) ? 'checked' : '' }}
                        class="form-checkbox">
                    <span class="text-sm">{{ $label }}</span>
                </label>
                @endforeach
            </div>
            @error('target_channel_types')<p class="text-error text-xs mt-1">{{ $message }}</p>@enderror
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Minimal obunachi soni</label>
                <input type="number" name="min_subscribers" value="{{ old('min_subscribers', 0) }}" min="0" class="form-input w-full">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Kanal boshiga max submission</label>
                <input type="number" name="max_submissions_per_channel" value="{{ old('max_submissions_per_channel', 1) }}" min="1" class="form-input w-full">
            </div>
        </div>
    </div>

    <div class="flex justify-end gap-3">
        <a href="{{ route('admin.influencer.campaigns.index') }}" class="btn bg-slate-200">Bekor qilish</a>
        <button type="submit" class="btn bg-primary text-white">Kampaniya yaratish</button>
    </div>
</form>
@endsection
