@extends('admin.layouts.app')

@section('title', 'Kampaniyani tahrirlash')

@section('content')
<div class="mt-4">
    <h2 class="text-base font-medium text-slate-700 dark:text-navy-100">Kampaniyani tahrirlash: {{ $campaign->name }}</h2>
</div>

<form method="POST" action="{{ route('admin.influencer.campaigns.update', $campaign) }}" class="mt-4 space-y-4">
    @csrf @method('PUT')

    <div class="card p-6 space-y-4">
        <div>
            <label class="block text-sm font-medium mb-1">Kampaniya nomi *</label>
            <input type="text" name="name" value="{{ old('name', $campaign->name) }}" class="form-input w-full" required>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Reklama matni (UZ) *</label>
            <textarea name="ad_text_uz" rows="3" class="form-textarea w-full" required>{{ old('ad_text_uz', $campaign->getTranslation('ad_text', 'uz')) }}</textarea>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Reklama matni (RU)</label>
            <textarea name="ad_text_ru" rows="3" class="form-textarea w-full">{{ old('ad_text_ru', $campaign->getTranslation('ad_text', 'ru')) }}</textarea>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Maqsadli URL *</label>
            <input type="url" name="target_url" value="{{ old('target_url', $campaign->target_url) }}" class="form-input w-full" required>
        </div>
    </div>

    <div class="card p-6 space-y-4">
        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Asosiy mukofot (AIS) *</label>
                <input type="number" name="reward_amount" value="{{ old('reward_amount', $campaign->reward_amount) }}" step="0.0001" min="0.0001" class="form-input w-full" required>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Umumiy byudjet (AIS) *</label>
                <input type="number" name="total_budget" value="{{ old('total_budget', $campaign->total_budget) }}" step="0.0001" min="{{ $campaign->spent_budget }}" class="form-input w-full" required>
                <p class="text-xs text-slate-400 mt-1">Sarflangan: {{ number_format($campaign->spent_budget, 2) }} AIS</p>
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium mb-1">Holat *</label>
            <select name="status" class="form-select w-full">
                <option value="active" @selected(old('status', $campaign->status)=='active')>Faol</option>
                <option value="paused" @selected(old('status', $campaign->status)=='paused')>To'xtatilgan</option>
                <option value="completed" @selected(old('status', $campaign->status)=='completed')>Tugagan</option>
                <option value="cancelled" @selected(old('status', $campaign->status)=='cancelled')>Bekor qilingan</option>
            </select>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Boshlanish sanasi *</label>
                <input type="datetime-local" name="starts_at" value="{{ old('starts_at', $campaign->starts_at->format('Y-m-d\TH:i')) }}" class="form-input w-full" required>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Tugash sanasi *</label>
                <input type="datetime-local" name="ends_at" value="{{ old('ends_at', $campaign->ends_at->format('Y-m-d\TH:i')) }}" class="form-input w-full" required>
            </div>
        </div>

        <div>
            <label class="block text-sm font-medium mb-2">Maqsadli kanal turlari *</label>
            <div class="flex flex-wrap gap-3">
                @foreach($channelTypes as $key => $label)
                <label class="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" name="target_channel_types[]" value="{{ $key }}"
                        {{ in_array($key, old('target_channel_types', $campaign->target_channel_types ?? [])) ? 'checked' : '' }}
                        class="form-checkbox">
                    <span class="text-sm">{{ $label }}</span>
                </label>
                @endforeach
            </div>
        </div>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Minimal obunachi soni</label>
                <input type="number" name="min_subscribers" value="{{ old('min_subscribers', $campaign->min_subscribers) }}" min="0" class="form-input w-full">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Kanal boshiga max submission</label>
                <input type="number" name="max_submissions_per_channel" value="{{ old('max_submissions_per_channel', $campaign->max_submissions_per_channel) }}" min="1" class="form-input w-full">
            </div>
        </div>
    </div>

    <div class="flex justify-end gap-3">
        <a href="{{ route('admin.influencer.campaigns.index') }}" class="btn bg-slate-200">Bekor qilish</a>
        <button type="submit" class="btn bg-primary text-white">Saqlash</button>
    </div>
</form>
@endsection
