@extends('admin.layouts.app')

@section('title', 'Influencer Kampaniyalar')

@section('breadcrumb')
    <li class="flex items-center space-x-2">
        <a href="{{ route('admin.dashboard') }}" class="text-primary hover:text-primary-focus">Admin</a>
        <svg xmlns="http://www.w3.org/2000/svg" class="size-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
    </li>
    <li>Influencer Kampaniyalar</li>
@endsection

@section('content')
<div class="flex items-center justify-between mt-4">
    <h2 class="text-base font-medium text-slate-700 dark:text-navy-100">Influencer Kampaniyalar</h2>
    <a href="{{ route('admin.influencer.campaigns.create') }}" class="btn bg-primary text-white">+ Yangi kampaniya</a>
</div>

<div class="card mt-3 p-4">
    <form method="GET" class="flex gap-3">
        <select name="status" class="form-select w-40">
            <option value="">Barcha holat</option>
            <option value="active" @selected(request('status')=='active')>Faol</option>
            <option value="paused" @selected(request('status')=='paused')>To'xtatilgan</option>
            <option value="completed" @selected(request('status')=='completed')>Tugagan</option>
            <option value="cancelled" @selected(request('status')=='cancelled')>Bekor qilingan</option>
        </select>
        <button type="submit" class="btn bg-primary text-white">Filtrlash</button>
    </form>
</div>

@if(session('success'))
    <div class="alert alert-success mt-3">{{ session('success') }}</div>
@endif

<div class="card mt-3">
    <div class="is-scrollbar-hidden min-w-full overflow-x-auto">
        <table class="is-hoverable w-full text-left">
            <thead>
                <tr>
                    <th class="whitespace-nowrap rounded-tl-lg bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Nomi</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Mukofot</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Byudjet</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Holat</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Muddat</th>
                    <th class="whitespace-nowrap rounded-tr-lg bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Amallar</th>
                </tr>
            </thead>
            <tbody>
                @forelse($campaigns as $campaign)
                <tr class="border-y border-transparent border-b-slate-200 dark:border-b-navy-500">
                    <td class="px-4 py-3">
                        <div class="font-medium text-sm">{{ $campaign->name }}</div>
                        <div class="text-xs text-slate-400">{{ implode(', ', array_map(fn($t) => $channelTypes[$t] ?? $t, $campaign->target_channel_types ?? [])) }}</div>
                    </td>
                    <td class="px-4 py-3 text-sm font-semibold text-success">{{ number_format($campaign->reward_amount, 2) }} AIS</td>
                    <td class="px-4 py-3">
                        <div class="text-xs mb-1">{{ number_format($campaign->spent_budget, 2) }} / {{ number_format($campaign->total_budget, 2) }} AIS</div>
                        <div class="progress h-1.5 bg-slate-200 rounded-full">
                            <div class="h-full bg-primary rounded-full" style="width: {{ $campaign->budget_percent }}%"></div>
                        </div>
                    </td>
                    <td class="px-4 py-3">
                        @php
                            $badge = match($campaign->status) {
                                'active'    => 'bg-success/10 text-success',
                                'paused'    => 'bg-warning/10 text-warning',
                                'completed' => 'bg-slate-200 text-slate-600',
                                'cancelled' => 'bg-error/10 text-error',
                                default     => 'bg-slate-200 text-slate-600',
                            };
                            $label = match($campaign->status) {
                                'active'    => 'Faol',
                                'paused'    => "To'xtatilgan",
                                'completed' => 'Tugagan',
                                'cancelled' => 'Bekor',
                                default     => $campaign->status,
                            };
                        @endphp
                        <span class="badge {{ $badge }}">{{ $label }}</span>
                    </td>
                    <td class="px-4 py-3 text-xs text-slate-500">
                        {{ $campaign->starts_at->format('d.m.Y') }} — {{ $campaign->ends_at->format('d.m.Y') }}
                    </td>
                    <td class="px-4 py-3">
                        <div class="flex gap-2">
                            <a href="{{ route('admin.influencer.campaigns.edit', $campaign) }}" class="btn btn-sm bg-slate-200">✏️</a>
                            <form method="POST" action="{{ route('admin.influencer.campaigns.destroy', $campaign) }}">
                                @csrf @method('DELETE')
                                <button type="submit" class="btn btn-sm bg-error/10 text-error" onclick="return confirm('O\'chirasizmi?')">🗑️</button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr><td colspan="6" class="px-4 py-8 text-center text-slate-400">Kampaniyalar topilmadi</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="p-4">{{ $campaigns->links() }}</div>
</div>
@endsection
