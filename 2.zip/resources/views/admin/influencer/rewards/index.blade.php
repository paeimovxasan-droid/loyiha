@extends('admin.layouts.app')

@section('title', 'Influencer Mukofotlar')

@section('content')
<div class="flex items-center justify-between mt-4">
    <h2 class="text-base font-medium text-slate-700 dark:text-navy-100">Influencer Mukofotlar Tarixi</h2>
    <div class="text-sm font-semibold text-success">Jami: {{ number_format($totalAis, 2) }} AIS</div>
</div>

<div class="card mt-3 p-4">
    <form method="GET" class="flex flex-wrap gap-3">
        <select name="campaign_id" class="form-select w-48">
            <option value="">Barcha kampaniya</option>
            @foreach($campaigns as $c)
                <option value="{{ $c->id }}" @selected(request('campaign_id')==$c->id)>{{ $c->name }}</option>
            @endforeach
        </select>
        <input type="date" name="date_from" value="{{ request('date_from') }}" class="form-input w-36">
        <input type="date" name="date_to" value="{{ request('date_to') }}" class="form-input w-36">
        <button type="submit" class="btn bg-primary text-white">Filtrlash</button>
    </form>
</div>

<div class="card mt-3">
    <div class="is-scrollbar-hidden min-w-full overflow-x-auto">
        <table class="is-hoverable w-full text-left">
            <thead>
                <tr>
                    <th class="whitespace-nowrap rounded-tl-lg bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Publisher</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Kanal</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Kampaniya</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Mukofot</th>
                    <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Koeffitsient</th>
                    <th class="whitespace-nowrap rounded-tr-lg bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Sana</th>
                </tr>
            </thead>
            <tbody>
                @forelse($rewards as $reward)
                <tr class="border-y border-transparent border-b-slate-200 dark:border-b-navy-500">
                    <td class="px-4 py-3">
                        <div class="text-sm font-medium">{{ $reward->user->name }}</div>
                        <div class="text-xs text-slate-400">{{ $reward->user->username }}</div>
                    </td>
                    <td class="px-4 py-3">
                        <div class="text-sm">{{ $reward->channel->name }}</div>
                        <div class="text-xs text-slate-400">{{ $reward->channel->type_label }}</div>
                    </td>
                    <td class="px-4 py-3 text-sm">{{ $reward->campaign->name }}</td>
                    <td class="px-4 py-3 text-sm font-semibold text-success">{{ number_format($reward->amount, 2) }} AIS</td>
                    <td class="px-4 py-3 text-sm">{{ $reward->coefficient }}x</td>
                    <td class="px-4 py-3 text-xs text-slate-400">{{ $reward->created_at->format('d.m.Y H:i') }}</td>
                </tr>
                @empty
                <tr><td colspan="6" class="px-4 py-8 text-center text-slate-400">Mukofotlar topilmadi</td></tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="p-4">{{ $rewards->links() }}</div>
</div>
@endsection
