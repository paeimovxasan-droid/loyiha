@extends('admin.layouts.app')

@section('title', 'Influencer Sozlamalar')

@section('content')
<div class="mt-4">
    <h2 class="text-base font-medium text-slate-700 dark:text-navy-100">Influencer Ad Network — Sozlamalar</h2>
</div>

@if(session('success'))
    <div class="alert alert-success mt-3">{{ session('success') }}</div>
@endif

<form method="POST" action="{{ route('admin.influencer.settings.update') }}" class="mt-4 space-y-4">
    @csrf @method('PUT')

    <div class="card p-6 space-y-4">
        <h3 class="font-semibold text-slate-700">Umumiy sozlamalar</h3>

        <label class="flex items-center gap-3 cursor-pointer">
            <input type="hidden" name="is_enabled" value="0">
            <input type="checkbox" name="is_enabled" value="1" {{ $setting->is_enabled ? 'checked' : '' }} class="form-checkbox">
            <span class="text-sm font-medium">Influencer moduli yoqilgan</span>
        </label>

        <label class="flex items-center gap-3 cursor-pointer">
            <input type="hidden" name="screenshot_required" value="0">
            <input type="checkbox" name="screenshot_required" value="1" {{ $setting->screenshot_required ? 'checked' : '' }} class="form-checkbox">
            <span class="text-sm font-medium">Screenshot yuklash majburiy</span>
        </label>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">Kunlik max submission (Publisher boshiga)</label>
                <input type="number" name="max_daily_submissions" value="{{ $setting->max_daily_submissions }}" min="1" max="100" class="form-input w-full">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Foydalanuvchi boshiga max kanal</label>
                <input type="number" name="max_channels_per_user" value="{{ $setting->max_channels_per_user }}" min="1" max="50" class="form-input w-full">
            </div>
        </div>
    </div>

    <div class="card p-6 space-y-4">
        <h3 class="font-semibold text-slate-700">Kanal turi koeffitsientlari</h3>
        <p class="text-xs text-slate-400">Mukofot = Kampaniya asosiy mukofoti × Koeffitsient</p>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">🎬 YouTube Kanal</label>
                <div class="flex items-center gap-2">
                    <input type="number" name="coeff_youtube_channel" value="{{ $setting->coeff_youtube_channel }}" step="0.01" min="0.01" max="10" class="form-input w-full">
                    <span class="text-sm text-slate-500">x</span>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">📢 Telegram Kanal</label>
                <div class="flex items-center gap-2">
                    <input type="number" name="coeff_telegram_channel" value="{{ $setting->coeff_telegram_channel }}" step="0.01" min="0.01" max="10" class="form-input w-full">
                    <span class="text-sm text-slate-500">x</span>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">👥 Telegram Guruh</label>
                <div class="flex items-center gap-2">
                    <input type="number" name="coeff_telegram_group" value="{{ $setting->coeff_telegram_group }}" step="0.01" min="0.01" max="10" class="form-input w-full">
                    <span class="text-sm text-slate-500">x</span>
                </div>
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">🤖 Telegram Bot</label>
                <div class="flex items-center gap-2">
                    <input type="number" name="coeff_telegram_bot" value="{{ $setting->coeff_telegram_bot }}" step="0.01" min="0.01" max="10" class="form-input w-full">
                    <span class="text-sm text-slate-500">x</span>
                </div>
            </div>
        </div>
    </div>

    <div class="card p-6 space-y-4">
        <h3 class="font-semibold text-slate-700">Minimal obunachi soni</h3>

        <div class="grid grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium mb-1">YouTube kanallar uchun</label>
                <input type="number" name="min_subscribers_youtube" value="{{ $setting->min_subscribers_youtube }}" min="0" class="form-input w-full">
            </div>
            <div>
                <label class="block text-sm font-medium mb-1">Telegram (kanal/guruh/bot) uchun</label>
                <input type="number" name="min_subscribers_telegram" value="{{ $setting->min_subscribers_telegram }}" min="0" class="form-input w-full">
            </div>
        </div>
    </div>

    <div class="flex justify-end">
        <button type="submit" class="btn bg-primary text-white">Saqlash</button>
    </div>
</form>
@endsection
