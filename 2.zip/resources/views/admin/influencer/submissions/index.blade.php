@extends('admin.layouts.app')

@section('title', 'Influencer Submissionlar')

@section('content')
<div class="flex items-center justify-between mt-4">
    <h2 class="text-base font-medium text-slate-700 dark:text-navy-100">Influencer Submissionlar</h2>
    <a href="{{ route('admin.influencer.stats') }}" class="btn bg-slate-200 text-sm">📊 Statistika</a>
</div>

<div class="card mt-3 p-4">
    <form method="GET" class="flex flex-wrap gap-3">
        <select name="status" class="form-select w-40">
            <option value="">Barcha holat</option>
            <option value="pending" @selected(request('status')=='pending')>Kutilmoqda</option>
            <option value="approved" @selected(request('status')=='approved')>Tasdiqlangan</option>
            <option value="rejected" @selected(request('status')=='rejected')>Rad etilgan</option>
            <option value="reward_failed" @selected(request('status')=='reward_failed')>Mukofot xatosi</option>
        </select>
        <select name="campaign_id" class="form-select w-48">
            <option value="">Barcha kampaniya</option>
            @foreach($campaigns as $c)
                <option value="{{ $c->id }}" @selected(request('campaign_id')==$c->id)>{{ $c->name }}</option>
            @endforeach
        </select>
        <select name="channel_type" class="form-select w-44">
            <option value="">Barcha kanal turi</option>
            @foreach($channelTypes as $key => $label)
                <option value="{{ $key }}" @selected(request('channel_type')==$key)>{{ $label }}</option>
            @endforeach
        </select>
        <button type="submit" class="btn bg-primary text-white">Filtrlash</button>
    </form>
</div>

@if(session('success'))
    <div class="alert alert-success mt-3">{{ session('success') }}</div>
@endif
@if(session('error'))
    <div class="alert alert-error mt-3">{{ session('error') }}</div>
@endif

<form id="bulk-form" method="POST" action="{{ route('admin.influencer.submissions.bulk-approve') }}">
    @csrf
    <div class="card mt-3">
        <div class="p-4 border-b border-slate-200 flex items-center gap-3">
            <button type="submit" class="btn bg-success text-white text-sm" onclick="return confirm('Tanlangan submissionlarni tasdiqlaysizmi?')">
                ✅ Tanlanganlari tasdiqlash
            </button>
        </div>
        <div class="is-scrollbar-hidden min-w-full overflow-x-auto">
            <table class="is-hoverable w-full text-left">
                <thead>
                    <tr>
                        <th class="whitespace-nowrap rounded-tl-lg bg-slate-200 px-4 py-3">
                            <input type="checkbox" id="select-all" class="form-checkbox">
                        </th>
                        <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Publisher</th>
                        <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Kanal</th>
                        <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Kampaniya</th>
                        <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Post URL</th>
                        <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Mukofot</th>
                        <th class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Holat</th>
                        <th class="whitespace-nowrap rounded-tr-lg bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100">Amallar</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($submissions as $sub)
                    <tr class="border-y border-transparent border-b-slate-200 dark:border-b-navy-500">
                        <td class="px-4 py-3">
                            @if($sub->isPending())
                                <input type="checkbox" name="ids[]" value="{{ $sub->id }}" class="form-checkbox submission-check">
                            @endif
                        </td>
                        <td class="px-4 py-3">
                            <div class="text-sm font-medium">{{ $sub->user->name }}</div>
                            <div class="text-xs text-slate-400">{{ $sub->user->username }}</div>
                        </td>
                        <td class="px-4 py-3">
                            <div class="text-sm">{{ $sub->channel->name }}</div>
                            <div class="text-xs text-slate-400">{{ $sub->channel->type_label }}</div>
                        </td>
                        <td class="px-4 py-3 text-sm">{{ $sub->campaign->name }}</td>
                        <td class="px-4 py-3">
                            <a href="{{ $sub->post_url }}" target="_blank" class="text-xs text-primary hover:underline">
                                {{ Str::limit($sub->post_url, 35) }}
                            </a>
                            @if($sub->screenshot_url)
                                <a href="{{ $sub->screenshot_url }}" target="_blank" class="block text-xs text-slate-400 hover:text-primary mt-1">📷 Screenshot</a>
                            @endif
                        </td>
                        <td class="px-4 py-3 text-sm font-semibold text-success">
                            {{ $sub->reward_amount ? number_format($sub->reward_amount, 2).' AIS' : '—' }}
                        </td>
                        <td class="px-4 py-3">{!! $sub->status_badge !!}</td>
                        <td class="px-4 py-3">
                            @if($sub->isPending())
                            <div class="flex gap-2">
                                <form method="POST" action="{{ route('admin.influencer.submissions.approve', $sub) }}">
                                    @csrf
                                    <button type="submit" class="btn btn-sm bg-success text-white" onclick="return confirm('Tasdiqlaysizmi?')">✅</button>
                                </form>
                                <button type="button" class="btn btn-sm bg-error text-white"
                                    x-data x-on:click="$dispatch('open-reject-sub-modal', { id: {{ $sub->id }}, url: '{{ route('admin.influencer.submissions.reject', $sub) }}' })">
                                    ❌
                                </button>
                            </div>
                            @elseif($sub->status === 'rejected')
                                <span class="text-xs text-slate-400" title="{{ $sub->rejection_reason }}">{{ Str::limit($sub->rejection_reason, 30) }}</span>
                            @endif
                        </td>
                    </tr>
                    @empty
                    <tr><td colspan="8" class="px-4 py-8 text-center text-slate-400">Submissionlar topilmadi</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        <div class="p-4">{{ $submissions->links() }}</div>
    </div>
</form>

{{-- Rad etish modal --}}
<div x-data="{ open: false, url: '' }"
     x-on:open-reject-sub-modal.window="open = true; url = $event.detail.url"
     x-show="open" x-cloak
     class="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
    <div class="card w-full max-w-md p-6" @click.outside="open = false">
        <h3 class="text-lg font-semibold mb-4">Rad etish sababi</h3>
        <form :action="url" method="POST">
            @csrf
            <textarea name="reason" rows="3" class="form-textarea w-full" placeholder="Sabab kiriting..." required></textarea>
            <div class="flex justify-end gap-2 mt-4">
                <button type="button" class="btn bg-slate-200" @click="open = false">Bekor</button>
                <button type="submit" class="btn bg-error text-white">Rad etish</button>
            </div>
        </form>
    </div>
</div>

<script>
document.getElementById('select-all')?.addEventListener('change', function() {
    document.querySelectorAll('.submission-check').forEach(cb => cb.checked = this.checked);
});
</script>
@endsection
