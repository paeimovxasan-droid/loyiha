@extends('admin.layouts.app')

@section('title', 'Influencer Statistika')

@section('content')
<div class="mt-4">
    <h2 class="text-base font-medium text-slate-700 dark:text-navy-100">Influencer Ad Network — Statistika</h2>
</div>

{{-- Umumiy statistika --}}
<div class="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
    <div class="card p-4 text-center">
        <div class="text-2xl font-bold text-primary">{{ number_format($totalStats['total_channels']) }}</div>
        <div class="text-xs text-slate-400 mt-1">Jami kanallar</div>
    </div>
    <div class="card p-4 text-center">
        <div class="text-2xl font-bold text-success">{{ number_format($totalStats['approved_channels']) }}</div>
        <div class="text-xs text-slate-400 mt-1">Tasdiqlangan</div>
    </div>
    <div class="card p-4 text-center">
        <div class="text-2xl font-bold text-slate-700">{{ number_format($totalStats['total_submissions']) }}</div>
        <div class="text-xs text-slate-400 mt-1">Jami submission</div>
    </div>
    <div class="card p-4 text-center">
        <div class="text-2xl font-bold text-warning">{{ number_format($totalStats['pending_submissions']) }}</div>
        <div class="text-xs text-slate-400 mt-1">Kutilayotgan</div>
    </div>
    <div class="card p-4 text-center">
        <div class="text-2xl font-bold text-success">{{ number_format($totalStats['total_spent_ais'], 2) }}</div>
        <div class="text-xs text-slate-400 mt-1">Jami sarflangan AIS</div>
    </div>
    <div class="card p-4 text-center">
        <div class="text-2xl font-bold text-primary">{{ number_format($totalStats['active_campaigns']) }}</div>
        <div class="text-xs text-slate-400 mt-1">Faol kampaniyalar</div>
    </div>
</div>

<div class="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
    {{-- Publisher reytingi --}}
    <div class="card">
        <div class="p-4 border-b border-slate-200">
            <h3 class="font-semibold text-slate-700">🏆 Publisher Reytingi (Top 20)</h3>
        </div>
        <div class="is-scrollbar-hidden overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-100">
                        <th class="px-4 py-2 text-xs font-semibold uppercase text-slate-600">#</th>
                        <th class="px-4 py-2 text-xs font-semibold uppercase text-slate-600">Publisher</th>
                        <th class="px-4 py-2 text-xs font-semibold uppercase text-slate-600">Jami AIS</th>
                        <th class="px-4 py-2 text-xs font-semibold uppercase text-slate-600">Submission</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($topPublishers as $i => $pub)
                    <tr class="border-b border-slate-100">
                        <td class="px-4 py-2 text-sm font-bold text-slate-500">{{ $i + 1 }}</td>
                        <td class="px-4 py-2">
                            <div class="text-sm font-medium">{{ $pub->user->name ?? '—' }}</div>
                            <div class="text-xs text-slate-400">{{ $pub->user->username ?? '' }}</div>
                        </td>
                        <td class="px-4 py-2 text-sm font-semibold text-success">{{ number_format($pub->total_reward, 2) }} AIS</td>
                        <td class="px-4 py-2 text-sm">{{ $pub->total_count }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    {{-- Kampaniya samaradorligi --}}
    <div class="card">
        <div class="p-4 border-b border-slate-200">
            <h3 class="font-semibold text-slate-700">📢 Kampaniya Samaradorligi</h3>
        </div>
        <div class="is-scrollbar-hidden overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-slate-100">
                        <th class="px-4 py-2 text-xs font-semibold uppercase text-slate-600">Kampaniya</th>
                        <th class="px-4 py-2 text-xs font-semibold uppercase text-slate-600">Jami</th>
                        <th class="px-4 py-2 text-xs font-semibold uppercase text-slate-600">✅</th>
                        <th class="px-4 py-2 text-xs font-semibold uppercase text-slate-600">❌</th>
                        <th class="px-4 py-2 text-xs font-semibold uppercase text-slate-600">Sarflangan</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($campaignStats as $camp)
                    <tr class="border-b border-slate-100">
                        <td class="px-4 py-2 text-sm">{{ Str::limit($camp->name, 25) }}</td>
                        <td class="px-4 py-2 text-sm">{{ $camp->submissions_count }}</td>
                        <td class="px-4 py-2 text-sm text-success">{{ $camp->approved_count }}</td>
                        <td class="px-4 py-2 text-sm text-error">{{ $camp->rejected_count }}</td>
                        <td class="px-4 py-2 text-sm font-semibold">{{ number_format($camp->spent_budget, 2) }} AIS</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
