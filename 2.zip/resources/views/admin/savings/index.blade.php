@extends('admin.layouts.app')
@section('title', 'Jamg\'arma rejalar')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Jamg'arma rejalar</span>
@endsection

@section('content')

@if(session('success'))
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: rgba(var(--success-rgb), 0.1); border: 1px solid rgba(var(--success-rgb), 0.3); color: var(--success);">
    {{ session('success') }}
</div>
@endif

<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Foydalanuvchi</th>
                    <th style="text-align: center;">Muddat (oy)</th>
                    <th style="text-align: center;">Oylik to'lov</th>
                    <th style="text-align: center;">Jami yig'ilgan</th>
                    <th style="text-align: center;">Holat</th>
                    <th style="text-align: center;">Amallar</th>
                </tr>
            </thead>
            <tbody>
                @forelse($plans as $plan)
                <tr>
                    <td style="color: var(--text-muted);">#{{ $plan->id }}</td>
                    <td style="color: var(--text-primary);">{{ $plan->user->name ?? '—' }}</td>
                    <td style="text-align: center;">{{ $plan->term_months ?? 0 }} oy</td>
                    <td style="text-align: center; font-weight: 600;">{{ number_format($plan->monthly_amount ?? 0, 2) }} AIS</td>
                    <td style="text-align: center; font-weight: 600; color: var(--success);">{{ number_format($plan->total_saved ?? 0, 2) }} AIS</td>
                    <td style="text-align: center;">
                        @if(($plan->status ?? '') == 'active')
                            <span class="badge badge-success">Active</span>
                        @elseif(($plan->status ?? '') == 'pending')
                            <span class="badge badge-warning">Pending</span>
                        @elseif(($plan->status ?? '') == 'completed')
                            <span class="badge badge-info">Completed</span>
                        @elseif(($plan->status ?? '') == 'cancelled')
                            <span class="badge badge-danger">Cancelled</span>
                        @else
                            <span class="badge badge-warning">{{ ucfirst($plan->status ?? 'pending') }}</span>
                        @endif
                    </td>
                    <td style="text-align: center;">
                        <a href="{{ route('admin.savings.edit', $plan) }}" class="btn btn-outline btn-sm">
                            <i class="fa fa-pen"></i>
                        </a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px; color: var(--text-muted);">
                        <i class="fa fa-piggy-bank" style="font-size: 24px; opacity: 0.3; display: block; margin-bottom: 8px;"></i>
                        Reja topilmadi
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="pagination" style="padding: 16px;">{{ $plans->withQueryString()->links() }}</div>
</div>
@endsection
