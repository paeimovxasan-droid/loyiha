@extends('admin.layouts.app')
@section('title', 'Jamg\'arma reja tahrirlash')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.savings.index') }}">Jamg'arma rejalar</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">Tahrirlash #{{ $plan->id }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.savings.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left" style="margin-right: 4px;"></i> Orqaga
    </a>
@endsection

@section('content')

@if($errors->any())
<div style="padding: 12px 16px; margin-bottom: 16px; border-radius: 8px; background: rgba(var(--danger-rgb), 0.1); border: 1px solid rgba(var(--danger-rgb), 0.3); color: var(--danger);">
    <ul style="list-style: disc; padding-left: 20px; margin: 0;">
        @foreach($errors->all() as $error)<li>{{ $error }}</li>@endforeach
    </ul>
</div>
@endif

<div class="admin-card">
    <div class="admin-card-header">Jamg'arma reja tahrirlash #{{ $plan->id }}</div>
    <div class="admin-card-body">
        <form method="POST" action="{{ route('admin.savings.update', $plan) }}">
            @csrf
            @method('PUT')
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                <div class="form-group">
                    <label class="form-label">Foydalanuvchi</label>
                    <input type="text" value="{{ $plan->user->name ?? '—' }}" disabled class="form-control" style="background: var(--bg-card); opacity: 0.7;">
                </div>
                <div class="form-group">
                    <label class="form-label">Jami yig'ilgan (AIS)</label>
                    <input type="text" value="{{ number_format($plan->total_saved ?? 0, 2) }}" disabled class="form-control" style="background: var(--bg-card); opacity: 0.7;">
                </div>
                <div class="form-group">
                    <label class="form-label">Muddat (oy)</label>
                    <input type="number" name="term_months" value="{{ old('term_months', $plan->term_months) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Oylik to'lov (AIS)</label>
                    <input type="number" step="0.01" name="monthly_amount" value="{{ old('monthly_amount', $plan->monthly_amount) }}" required class="form-control">
                </div>
                <div class="form-group">
                    <label class="form-label">Holat</label>
                    <select name="status" class="form-control">
                        @foreach(['active','completed','cancelled'] as $s)
                        <option value="{{ $s }}" {{ old('status', $plan->status) == $s ? 'selected' : '' }}>{{ ucfirst($s) }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div style="margin-top: 24px; display: flex; justify-content: flex-end;">
                <button type="submit" class="btn btn-primary btn-sm">Yangilash</button>
            </div>
        </form>
    </div>
</div>
@endsection
