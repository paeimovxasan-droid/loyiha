@extends('admin.layouts.app')
@section('title', 'KYC — Pasport Ko\'rish')

@section('breadcrumb')
<span>Boshqaruv</span>
<i class="fa fa-chevron-right" style="font-size: 10px; color: var(--text-muted);"></i>
<a href="{{ route('admin.kyc.index') }}" style="color: var(--text-muted); text-decoration: none;">KYC</a>
<i class="fa fa-chevron-right" style="font-size: 10px; color: var(--text-muted);"></i>
<span style="color: var(--text-primary);">{{ $user->name }}</span>
@endsection

@section('content')
<div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.5rem;">
    <a href="{{ route('admin.kyc.index') }}" class="btn btn-outline btn-sm" style="width: 2rem; height: 2rem; padding: 0; display: flex; align-items: center; justify-content: center; border-radius: 50%;">
        <i class="fa fa-arrow-left" style="font-size: 0.75rem;"></i>
    </a>
    <h2 style="font-size: 1.25rem; font-weight: 600; color: var(--text-primary);">🪪 Pasport Ko'rish — {{ $user->name }}</h2>
</div>

@if(session('success'))
<div style="margin-bottom: 1rem; padding: 0.75rem 1rem; border-radius: 8px; border: 1px solid var(--success); background: color-mix(in srgb, var(--success) 10%, transparent); color: var(--success);">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif
@if(session('error'))
<div style="margin-bottom: 1rem; padding: 0.75rem 1rem; border-radius: 8px; border: 1px solid var(--danger); background: color-mix(in srgb, var(--danger) 10%, transparent); color: var(--danger);">
    <i class="fa fa-exclamation-circle"></i> {{ session('error') }}
</div>
@endif

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem;">
    {{-- Foydalanuvchi ma'lumotlari --}}
    <div class="admin-card" style="padding: 1.5rem;">
        <h3 style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase; margin-bottom: 1rem;">Foydalanuvchi</h3>
        <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1rem;">
            <img src="{{ $user->avatar_url }}" style="width: 3.5rem; height: 3.5rem; border-radius: 12px; object-fit: cover;">
            <div>
                <div style="font-weight: 600; color: var(--text-primary);">{{ $user->name }}</div>
                <div style="font-size: 0.875rem; color: var(--text-muted);">{{ $user->email }}</div>
                <div style="font-size: 0.75rem; color: var(--text-muted);">{{ $user->username ?? '—' }}</div>
            </div>
        </div>
        <div style="display: flex; flex-direction: column; gap: 0.5rem; font-size: 0.875rem;">
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <span style="color: var(--text-muted);">KYC holati:</span>
                @if($user->kyc_status == 'passport_pending')
                    <span class="badge badge-warning">{{ $user->kyc_status }}</span>
                @elseif($user->kyc_status == 'passport_verified')
                    <span class="badge badge-info">{{ $user->kyc_status }}</span>
                @elseif($user->kyc_status == 'face_pending')
                    <span class="badge badge-info">{{ $user->kyc_status }}</span>
                @elseif($user->kyc_status == 'verified')
                    <span class="badge badge-success">{{ $user->kyc_status }}</span>
                @elseif($user->kyc_status == 'rejected')
                    <span class="badge badge-danger">{{ $user->kyc_status }}</span>
                @else
                    <span class="badge badge-secondary">{{ $user->kyc_status }}</span>
                @endif
            </div>
            @if($user->kyc_submitted_at)
            <div style="display: flex; justify-content: space-between;">
                <span style="color: var(--text-muted);">Yuborilgan:</span>
                <span style="color: var(--text-primary);">{{ $user->kyc_submitted_at->format('d.m.Y H:i') }}</span>
            </div>
            @endif
            @if($user->kyc_rejection_reason)
            <div style="display: flex; justify-content: space-between;">
                <span style="color: var(--text-muted);">Rad sababi:</span>
                <span style="color: var(--danger); font-size: 0.75rem;">{{ $user->kyc_rejection_reason }}</span>
            </div>
            @endif
        </div>

        {{-- Amallar --}}
        @if($user->kyc_status === 'passport_pending')
        <div style="margin-top: 1.5rem; display: flex; gap: 0.75rem;">
            @can('kyc.approve')
            <form method="POST" action="{{ route('admin.kyc.approve', $user) }}" style="flex: 1;">
                @csrf
                <button type="submit" class="btn btn-primary" style="width: 100%;">
                    <i class="fa fa-check"></i> Tasdiqlash
                </button>
            </form>
            @endcan
            @can('kyc.reject')
            <button type="button" class="btn btn-danger btn-sm" style="flex: 1; height: 2.5rem;" onclick="showRejectModal()">
                <i class="fa fa-times"></i> Rad etish
            </button>
            @endcan
        </div>
        @endif
    </div>

    {{-- Pasport rasmi --}}
    <div class="admin-card" style="padding: 1.5rem;">
        <h3 style="font-size: 0.75rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase; margin-bottom: 1rem;">Pasport Rasmi</h3>
        @if($docUrl)
        <img src="{{ $docUrl }}" alt="Pasport" style="width: 100%; border-radius: 12px; object-fit: contain; max-height: 20rem; border: 1px solid var(--border);">
        @else
        <div style="display: flex; align-items: center; justify-content: center; height: 10rem; border: 1px solid var(--border); border-radius: 12px;">
            <div style="text-align: center; color: var(--text-muted);">
                <i class="fa fa-id-card" style="font-size: 1.5rem; opacity: 0.3; display: block; margin-bottom: 0.5rem;"></i>
                <div style="font-size: 0.875rem;">Rasm mavjud emas</div>
            </div>
        </div>
        @endif
    </div>
</div>

{{-- Face ID urinishlari tarixi --}}
@if($attempts->count() > 0)
<div class="admin-card" style="overflow: hidden; margin-top: 1.5rem;">
    <div style="padding: 1rem 1.5rem; border-bottom: 1px solid var(--border);">
        <h3 style="font-size: 0.875rem; font-weight: 600; color: var(--text-primary);">Face ID Urinishlari Tarixi</h3>
    </div>
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th style="text-align: left;">Sessiya</th>
                    <th style="text-align: center;">Holat</th>
                    <th style="text-align: center;">Liveness</th>
                    <th style="text-align: center;">Vaqt</th>
                    <th style="text-align: center;">Amal</th>
                </tr>
            </thead>
            <tbody>
                @foreach($attempts as $attempt)
                <tr>
                    <td style="font-size: 0.75rem; color: var(--text-muted); font-family: monospace;">{{ substr($attempt->session_id, 0, 8) }}...</td>
                    <td style="text-align: center;">
                        @if($attempt->status == 'submitted')
                            <span class="badge badge-warning">{{ $attempt->status }}</span>
                        @elseif($attempt->status == 'approved')
                            <span class="badge badge-success">{{ $attempt->status }}</span>
                        @elseif($attempt->status == 'rejected' || $attempt->status == 'failed')
                            <span class="badge badge-danger">{{ $attempt->status }}</span>
                        @elseif($attempt->status == 'pending')
                            <span class="badge badge-info">{{ $attempt->status }}</span>
                        @else
                            <span class="badge badge-secondary">{{ $attempt->status }}</span>
                        @endif
                    </td>
                    <td style="text-align: center; font-size: 0.75rem; color: var(--text-muted);">
                        {{ $attempt->liveness_score ? round($attempt->liveness_score * 100) . '%' : '—' }}
                    </td>
                    <td style="text-align: center; font-size: 0.75rem; color: var(--text-muted);">
                        {{ $attempt->created_at->format('d.m.Y H:i') }}
                    </td>
                    <td style="text-align: center;">
                        @if($attempt->status === 'submitted')
                        <a href="{{ route('admin.kyc.face.show', $attempt) }}" class="btn btn-primary btn-sm">
                            <i class="fa fa-eye"></i> Ko'rish
                        </a>
                        @else
                        <span style="color: var(--text-muted); font-size: 0.75rem;">—</span>
                        @endif
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endif

{{-- Rad etish modal --}}
<div id="rejectModal" style="display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.6); z-index: 9999; align-items: center; justify-content: center;">
    <div class="admin-card" style="padding: 1.5rem; width: 90%; max-width: 420px;">
        <h3 style="font-size: 1rem; font-weight: 700; color: var(--text-primary); margin-bottom: 1rem;">❌ Pasportni rad etish</h3>
        <form method="POST" action="{{ route('admin.kyc.reject', $user) }}">
            @csrf
            <div class="form-group">
                <label class="form-label">Rad etish sababi</label>
                <textarea name="reason" rows="3" required class="form-control" placeholder="Masalan: Hujjat noaniq, yuz ko'rinmaydi..."></textarea>
            </div>
            <div style="display: flex; gap: 0.75rem; margin-top: 1rem;">
                <button type="button" class="btn btn-outline" style="flex: 1;" onclick="hideRejectModal()">
                    Bekor qilish
                </button>
                <button type="submit" class="btn btn-danger" style="flex: 1;">
                    Rad etish
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
function showRejectModal() {
    var modal = document.getElementById('rejectModal');
    modal.style.display = 'flex';
}

function hideRejectModal() {
    var modal = document.getElementById('rejectModal');
    modal.style.display = 'none';
}

document.getElementById('rejectModal').addEventListener('click', function(e) {
    if (e.target === this) {
        hideRejectModal();
    }
});
</script>
@endpush
