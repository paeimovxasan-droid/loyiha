@extends('admin.layouts.app')

@section('title', 'KYC Boshqaruvi — Pasport')

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">KYC Pasport</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.kyc.face.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-camera"></i> Face ID so'rovlari
    </a>
@endsection

@section('content')

@if(session('success'))
<div style="display: flex; align-items: center; gap: 8px; padding: 12px 16px; border-radius: 10px; margin-bottom: 16px; background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.2); color: var(--success); font-size: 13px;">
    <i class="fa fa-check-circle"></i> {{ session('success') }}
</div>
@endif
@if(session('error'))
<div style="display: flex; align-items: center; gap: 8px; padding: 12px 16px; border-radius: 10px; margin-bottom: 16px; background: rgba(239,68,68,.1); border: 1px solid rgba(239,68,68,.2); color: var(--danger); font-size: 13px;">
    <i class="fa fa-exclamation-circle"></i> {{ session('error') }}
</div>
@endif

{{-- Statistics --}}
<div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 16px; margin-bottom: 24px;">
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--warning);">{{ $stats['passport_pending'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Pasport kutilmoqda</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--primary-light);">{{ $stats['passport_verified'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Pasport tasdiqlandi</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--primary-light);">{{ $stats['face_pending'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Face ID kutilmoqda</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--success);">{{ $stats['verified'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Tasdiqlangan</div>
    </div>
    <div class="admin-card" style="text-align: center; padding: 20px;">
        <div style="font-size: 22px; font-weight: 700; color: var(--danger);">{{ $stats['rejected'] }}</div>
        <div style="font-size: 12px; color: var(--text-muted); margin-top: 4px;">Rad etilgan</div>
    </div>
</div>

{{-- Filters --}}
<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; flex-wrap: wrap; gap: 10px;">
    <h2 style="font-size: 18px; font-weight: 700; color: var(--text-primary);">🪪 KYC So'rovlari</h2>
    <form method="GET" style="display: flex; gap: 8px; align-items: center;">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Ism, email, username..."
               class="form-control" style="width: 180px; padding: 7px 12px; font-size: 12px;">
        <select name="status" onchange="this.form.submit()" class="form-control" style="width: 160px; padding: 7px 12px; font-size: 12px;">
            <option value="">Barchasi</option>
            <option value="passport_pending"  {{ request('status') === 'passport_pending'  ? 'selected' : '' }}>Pasport kutilmoqda</option>
            <option value="passport_verified" {{ request('status') === 'passport_verified' ? 'selected' : '' }}>Pasport tasdiqlandi</option>
            <option value="face_pending"      {{ request('status') === 'face_pending'      ? 'selected' : '' }}>Face ID kutilmoqda</option>
            <option value="verified"          {{ request('status') === 'verified'          ? 'selected' : '' }}>Tasdiqlangan</option>
            <option value="rejected"          {{ request('status') === 'rejected'          ? 'selected' : '' }}>Rad etilgan</option>
        </select>
        @if(request()->anyFilled(['search', 'status']))
        <a href="{{ route('admin.kyc.index') }}" class="btn btn-outline btn-sm"><i class="fa fa-times"></i></a>
        @endif
    </form>
</div>

{{-- Table --}}
<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>Foydalanuvchi</th>
                    <th style="text-align: center;">Holat</th>
                    <th style="text-align: center;">Hujjat</th>
                    <th style="text-align: center;">Yuborilgan</th>
                    <th style="text-align: center;">Amallar</th>
                </tr>
            </thead>
            <tbody>
                @forelse($users as $user)
                <tr>
                    <td>
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <img src="{{ $user->avatar_url }}" alt=""
                                 style="width: 36px; height: 36px; border-radius: 10px; object-fit: cover; border: 1px solid var(--border);">
                            <div>
                                <div style="font-size: 13px; font-weight: 600; color: var(--text-primary);">{{ $user->name }}</div>
                                <div style="font-size: 11px; color: var(--text-muted);">{{ $user->email }}</div>
                            </div>
                        </div>
                    </td>
                    <td style="text-align: center;">
                        @php
                            $badgeMap = [
                                'passport_pending'  => ['badge-warning',  '⏳ Pasport kutilmoqda'],
                                'passport_verified' => ['badge-primary',  '🪪 Pasport tasdiqlandi'],
                                'face_pending'      => ['badge-info',     '🤳 Face ID kutilmoqda'],
                                'verified'          => ['badge-success',  '✅ Tasdiqlangan'],
                                'rejected'          => ['badge-danger',   '❌ Rad etilgan'],
                            ];
                            [$cls, $label] = $badgeMap[$user->kyc_status] ?? ['badge-info', '— Noma\'lum'];
                        @endphp
                        <span class="badge {{ $cls }}">{{ $label }}</span>
                    </td>
                    <td style="text-align: center;">
                        @if($user->kyc_document)
                        <a href="{{ route('admin.kyc.show', $user) }}" class="btn btn-outline btn-sm">
                            <i class="fa fa-eye"></i> Ko'rish
                        </a>
                        @else
                        <span style="font-size: 12px; color: var(--text-muted);">—</span>
                        @endif
                    </td>
                    <td style="text-align: center;">
                        <span style="font-size: 12px; color: var(--text-muted);">
                            {{ $user->kyc_submitted_at?->format('d.m.Y H:i') ?? $user->updated_at->format('d.m.Y H:i') }}
                        </span>
                    </td>
                    <td style="text-align: center;">
                        @if($user->kyc_status === 'passport_pending')
                        <div style="display: flex; align-items: center; justify-content: center; gap: 4px;">
                            @can('kyc.approve')
                            <form method="POST" action="{{ route('admin.kyc.approve', $user) }}" style="margin: 0;">
                                @csrf
                                <button type="submit" class="btn btn-sm btn-success" title="Tasdiqlash">
                                    <i class="fa fa-check"></i>
                                </button>
                            </form>
                            @endcan
                            @can('kyc.reject')
                            <button type="button" onclick="showRejectModal({{ $user->id }}, '{{ addslashes($user->name) }}')"
                                    class="btn btn-danger btn-sm" title="Rad etish">
                                <i class="fa fa-times"></i>
                            </button>
                            @endcan
                        </div>
                        @else
                        <span style="font-size: 12px; color: var(--text-muted);">—</span>
                        @endif
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="5" style="text-align: center; padding: 32px; color: var(--text-muted);">
                        <i class="fa fa-id-card" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                        KYC so'rovi topilmadi
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($users->hasPages())
    <div style="padding: 14px 20px; border-top: 1px solid var(--border); display: flex; align-items: center; justify-content: center;">
        <div class="pagination">
            @if(!$users->onFirstPage())
            <a href="{{ $users->previousPageUrl() }}"><i class="fa fa-chevron-left" style="font-size: 10px;"></i></a>
            @endif
            @foreach($users->getUrlRange(max(1, $users->currentPage()-2), min($users->lastPage(), $users->currentPage()+2)) as $page => $url)
                @if($page == $users->currentPage())
                <span class="active"><span>{{ $page }}</span></span>
                @else
                <a href="{{ $url }}">{{ $page }}</a>
                @endif
            @endforeach
            @if($users->hasMorePages())
            <a href="{{ $users->nextPageUrl() }}"><i class="fa fa-chevron-right" style="font-size: 10px;"></i></a>
            @endif
        </div>
    </div>
    @endif
</div>

{{-- Reject Modal --}}
<div id="rejectModal" style="position: fixed; inset: 0; z-index: 9999; display: none; align-items: center; justify-content: center;
            background: rgba(10,14,26,.8); backdrop-filter: blur(4px);">
    <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 14px; padding: 24px;
                width: 90%; max-width: 400px; box-shadow: 0 16px 48px rgba(0,0,0,.4);">
        <h3 style="font-size: 16px; font-weight: 700; color: var(--text-primary); margin-bottom: 4px;">
            ❌ Pasportni rad etish
        </h3>
        <p id="rejectUserName" style="font-size: 13px; color: var(--text-muted); margin-bottom: 16px;"></p>
        <form id="rejectForm" method="POST">
            @csrf
            <div class="form-group">
                <label class="form-label">Rad etish sababi</label>
                <textarea name="reason" rows="3" required class="form-control"
                          placeholder="Masalan: Hujjat noaniq, yuz ko'rinmaydi..." style="resize: none;"></textarea>
            </div>
            <div style="display: flex; gap: 8px; margin-top: 16px;">
                <button type="button" onclick="closeRejectModal()" class="btn btn-outline" style="flex: 1;">Bekor qilish</button>
                <button type="submit" class="btn btn-danger" style="flex: 1;">Rad etish</button>
            </div>
        </form>
    </div>
</div>

<script>
function showRejectModal(userId, userName) {
    document.getElementById('rejectUserName').textContent = 'Foydalanuvchi: ' + userName;
    document.getElementById('rejectForm').action = '/admin/kyc/passport/' + userId + '/reject';
    document.getElementById('rejectModal').style.display = 'flex';
}
function closeRejectModal() {
    document.getElementById('rejectModal').style.display = 'none';
}
document.getElementById('rejectModal').addEventListener('click', function(e) {
    if (e.target === this) closeRejectModal();
});
</script>

@endsection
