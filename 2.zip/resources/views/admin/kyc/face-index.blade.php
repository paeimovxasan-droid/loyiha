@extends('admin.layouts.app')
@section('title', 'Face ID KYC So\'rovlari')

@section('content')
<div class="page-header">
    <h1 class="page-title">🤳 Face ID KYC</h1>
</div>

{{-- Statistika --}}
<div class="stats-grid" style="display:grid; grid-template-columns:repeat(3,1fr); gap:16px; margin-bottom:24px;">
    @foreach([
        ['submitted', '⏳ Kutilmoqda', $stats['submitted'], '#f59e0b'],
        ['approved',  '✅ Tasdiqlangan', $stats['approved'], '#10b981'],
        ['rejected',  '❌ Rad etilgan', $stats['rejected'], '#ef4444'],
    ] as [$key, $label, $count, $color])
    <a href="{{ route('admin.kyc.face.index', ['status' => $key]) }}"
       style="background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08);
              border-radius:14px; padding:16px; text-decoration:none; display:block;">
        <div style="font-size:22px; font-weight:800; color:{{ $color }};">{{ $count }}</div>
        <div style="font-size:12px; color:#94a3b8; margin-top:4px;">{{ $label }}</div>
    </a>
    @endforeach
</div>

{{-- Filter --}}
<form method="GET" style="display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap;">
    <select name="status" class="form-control" style="width:auto;" onchange="this.form.submit()">
        <option value="">Barcha holatlar</option>
        <option value="submitted" {{ request('status') === 'submitted' ? 'selected' : '' }}>⏳ Kutilmoqda</option>
        <option value="approved"  {{ request('status') === 'approved'  ? 'selected' : '' }}>✅ Tasdiqlangan</option>
        <option value="rejected"  {{ request('status') === 'rejected'  ? 'selected' : '' }}>❌ Rad etilgan</option>
    </select>
    <input type="text" name="search" value="{{ request('search') }}"
           placeholder="Ism, username, email..." class="form-control" style="flex:1; min-width:200px;">
    <button type="submit" class="btn btn-primary">Qidirish</button>
</form>

{{-- Jadval --}}
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Foydalanuvchi</th>
                    <th>Hujjat turi</th>
                    <th>Liveness</th>
                    <th>Holat</th>
                    <th>Yuborilgan</th>
                    <th>Amal</th>
                </tr>
            </thead>
            <tbody>
                @forelse($attempts as $attempt)
                <tr>
                    <td>{{ $attempt->id }}</td>
                    <td>
                        <div style="font-weight:600; color:#f1f5f9;">{{ $attempt->user?->name }}</div>
                        <div style="font-size:12px; color:#64748b;">{{ $attempt->user?->username ?? '—' }}</div>
                    </td>
                    <td>
                        {{ $attempt->document_type === 'passport' ? '📘 Pasport' : '🪪 ID karta' }}
                    </td>
                    <td>
                        @if($attempt->liveness_score)
                            <span style="color:{{ $attempt->liveness_score >= 0.8 ? '#34d399' : '#fbbf24' }}; font-weight:600;">
                                {{ round($attempt->liveness_score * 100) }}%
                            </span>
                        @else
                            <span style="color:#64748b;">—</span>
                        @endif
                    </td>
                    <td>
                        @php
                            $badge = match($attempt->status) {
                                'submitted' => ['⏳', '#f59e0b', 'Kutilmoqda'],
                                'approved'  => ['✅', '#10b981', 'Tasdiqlangan'],
                                'rejected'  => ['❌', '#ef4444', 'Rad etildi'],
                                'failed'    => ['⚠️', '#f97316', 'Xato'],
                                default     => ['❓', '#64748b', $attempt->status],
                            };
                        @endphp
                        <span style="color:{{ $badge[1] }}; font-weight:600;">
                            {{ $badge[0] }} {{ $badge[2] }}
                        </span>
                    </td>
                    <td style="font-size:12px; color:#64748b;">
                        {{ $attempt->submitted_at?->format('d.m.Y H:i') ?? '—' }}
                    </td>
                    <td>
                        <a href="{{ route('admin.kyc.face.show', $attempt) }}"
                           class="btn btn-sm btn-outline">
                            👁 Ko'rish
                        </a>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align:center; color:#64748b; padding:32px;">
                        So'rovlar topilmadi
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div style="padding:16px;">
        {{ $attempts->withQueryString()->links() }}
    </div>
</div>
@endsection
