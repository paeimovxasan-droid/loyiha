@extends('admin.layouts.app')
@section('title', 'Face KYC #' . $attempt->id)

@section('content')
<div class="page-header" style="display:flex; align-items:center; gap:12px; margin-bottom:24px;">
    <a href="{{ route('admin.kyc.face.index') }}" class="btn btn-outline btn-sm">← Orqaga</a>
    <h1 class="page-title" style="margin:0;">🤳 Face KYC #{{ $attempt->id }}</h1>
</div>

@if(session('success'))
<div class="alert alert-success">{{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger">{{ session('error') }}</div>
@endif

<div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; align-items:start;">

    {{-- Chap: Foydalanuvchi ma'lumotlari --}}
    <div>
        <div class="card" style="margin-bottom:16px;">
            <div class="card-header"><span class="card-title">👤 Foydalanuvchi</span></div>
            <div class="card-body">
                @php $user = $attempt->user; @endphp
                <div style="display:flex; align-items:center; gap:12px; margin-bottom:16px;">
                    <img src="{{ $user?->avatar_url }}" alt=""
                         style="width:52px; height:52px; border-radius:50%; object-fit:cover;">
                    <div>
                        <div style="font-weight:700; color:#f1f5f9;">{{ $user?->name }}</div>
                        <div style="font-size:12px; color:#64748b;">{{ $user?->username ?? '—' }}</div>
                    </div>
                </div>
                <table style="width:100%; font-size:13px;">
                    <tr><td style="color:#64748b; padding:4px 0;">Email</td><td style="color:#e2e8f0;">{{ $user?->email ?? '—' }}</td></tr>
                    <tr><td style="color:#64748b; padding:4px 0;">Telefon</td><td style="color:#e2e8f0;">{{ $user?->phone ?? '—' }}</td></tr>
                    <tr><td style="color:#64748b; padding:4px 0;">Ro'yxat sanasi</td><td style="color:#e2e8f0;">{{ $user?->created_at?->format('d.m.Y') }}</td></tr>
                    <tr><td style="color:#64748b; padding:4px 0;">KYC holati</td>
                        <td>
                            <span style="color:{{ match($user?->kyc_status) {
                                'approved' => '#10b981', 'pending' => '#f59e0b',
                                'rejected' => '#ef4444', default => '#64748b'
                            } }}; font-weight:600;">
                                {{ $user?->kyc_status ?? 'none' }}
                            </span>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        {{-- Attempt ma'lumotlari --}}
        <div class="card" style="margin-bottom:16px;">
            <div class="card-header"><span class="card-title">📋 So'rov ma'lumotlari</span></div>
            <div class="card-body">
                <table style="width:100%; font-size:13px;">
                    <tr><td style="color:#64748b; padding:4px 0;">Holat</td>
                        <td>
                            @php
                                $badge = match($attempt->status) {
                                    'submitted' => ['⏳', '#f59e0b', 'Kutilmoqda'],
                                    'approved'  => ['✅', '#10b981', 'Tasdiqlangan'],
                                    'rejected'  => ['❌', '#ef4444', 'Rad etildi'],
                                    'failed'    => ['⚠️', '#f97316', 'Xato'],
                                    default     => ['❓', '#64748b', $attempt->status],
                                };
                            @endphp
                            <span style="color:{{ $badge[1] }}; font-weight:600;">{{ $badge[0] }} {{ $badge[2] }}</span>
                        </td>
                    </tr>
                    <tr><td style="color:#64748b; padding:4px 0;">Hujjat turi</td>
                        <td style="color:#e2e8f0;">{{ $attempt->document_type === 'passport' ? '📘 Pasport' : '🪪 ID karta' }}</td>
                    </tr>
                    <tr><td style="color:#64748b; padding:4px 0;">Liveness score</td>
                        <td>
                            @if($attempt->liveness_score)
                                <span style="color:{{ $attempt->liveness_score >= 0.8 ? '#34d399' : '#fbbf24' }}; font-weight:700;">
                                    {{ round($attempt->liveness_score * 100) }}%
                                </span>
                            @else —
                            @endif
                        </td>
                    </tr>
                    <tr><td style="color:#64748b; padding:4px 0;">Yuborilgan</td>
                        <td style="color:#e2e8f0;">{{ $attempt->submitted_at?->format('d.m.Y H:i') ?? '—' }}</td>
                    </tr>
                    @if($attempt->fail_reason)
                    <tr><td style="color:#64748b; padding:4px 0;">Sabab</td>
                        <td style="color:#fca5a5;">{{ $attempt->fail_reason }}</td>
                    </tr>
                    @endif
                    @if($attempt->reviewer)
                    <tr><td style="color:#64748b; padding:4px 0;">Ko'rib chiqqan</td>
                        <td style="color:#e2e8f0;">{{ $attempt->reviewer->name }} ({{ $attempt->reviewed_at?->format('d.m.Y H:i') }})</td>
                    </tr>
                    @endif
                </table>

                {{-- Challenge --}}
                @if($attempt->challenge)
                <div style="margin-top:12px;">
                    <div style="font-size:12px; color:#64748b; margin-bottom:6px;">Liveness challenge:</div>
                    <div style="display:flex; flex-wrap:wrap; gap:6px;">
                        @foreach($attempt->challenge as $action)
                        <span style="background:rgba(99,102,241,.15); color:#818cf8; font-size:11px;
                                     padding:3px 10px; border-radius:10px;">
                            {{ $action }}
                        </span>
                        @endforeach
                    </div>
                </div>
                @endif
            </div>
        </div>

        {{-- Amallar --}}
        @if($attempt->status === 'submitted')
        <div class="card">
            <div class="card-header"><span class="card-title">⚡ Qaror</span></div>
            <div class="card-body">
                {{-- Tasdiqlash --}}
                <form method="POST" action="{{ route('admin.kyc.face.approve', $attempt) }}"
                      onsubmit="return confirm('Tasdiqlashni xohlaysizmi?')">
                    @csrf
                    <button type="submit" class="btn btn-success btn-full" style="margin-bottom:10px;">
                        ✅ Tasdiqlash
                    </button>
                </form>

                {{-- Rad etish --}}
                <form method="POST" action="{{ route('admin.kyc.face.reject', $attempt) }}"
                      onsubmit="return confirm('Rad etishni xohlaysizmi?')">
                    @csrf
                    <div class="form-group" style="margin-bottom:10px;">
                        <textarea name="reason" class="form-control" rows="2"
                                  placeholder="Rad etish sababi..." required></textarea>
                        @error('reason')
                        <div class="invalid-feedback" style="display:block;">{{ $message }}</div>
                        @enderror
                    </div>
                    <button type="submit" class="btn btn-danger btn-full">
                        ❌ Rad etish
                    </button>
                </form>
            </div>
        </div>
        @endif
    </div>

    {{-- O'ng: Rasmlar --}}
    <div>
        {{-- Selfie --}}
        <div class="card" style="margin-bottom:16px;">
            <div class="card-header"><span class="card-title">🤳 Selfie</span></div>
            <div class="card-body" style="text-align:center;">
                @if($selfieUrl)
                    <img src="{{ $selfieUrl }}" alt="Selfie"
                         style="max-width:100%; max-height:320px; border-radius:16px; object-fit:contain;">
                @else
                    <div style="color:#64748b; padding:32px;">Rasm topilmadi</div>
                @endif
            </div>
        </div>

        {{-- Hujjat old tomoni --}}
        <div class="card" style="margin-bottom:16px;">
            <div class="card-header"><span class="card-title">📄 Hujjat (old tomoni)</span></div>
            <div class="card-body" style="text-align:center;">
                @if($docFrontUrl)
                    <img src="{{ $docFrontUrl }}" alt="Hujjat old"
                         style="max-width:100%; max-height:280px; border-radius:12px; object-fit:contain;">
                @else
                    <div style="color:#64748b; padding:32px;">Rasm topilmadi</div>
                @endif
            </div>
        </div>

        {{-- Hujjat orqa tomoni --}}
        @if($docBackUrl)
        <div class="card">
            <div class="card-header"><span class="card-title">📄 Hujjat (orqa tomoni)</span></div>
            <div class="card-body" style="text-align:center;">
                <img src="{{ $docBackUrl }}" alt="Hujjat orqa"
                     style="max-width:100%; max-height:280px; border-radius:12px; object-fit:contain;">
            </div>
        </div>
        @endif
    </div>

</div>
@endsection
