@extends('admin.layouts.app')

@section('title', __('roles.edit'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <a href="{{ route('admin.roles.index') }}">{{ __('roles.title') }}</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ $role->name }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.roles.index') }}" class="btn btn-outline btn-sm">
        <i class="fa fa-arrow-left"></i> {{ __('buttons.cancel') }}
    </a>
    <button type="submit" form="role-form" class="btn btn-primary btn-sm">
        <i class="fa fa-save"></i> {{ __('buttons.save') }}
    </button>
@endsection

@section('content')

<form id="role-form" action="{{ route('admin.roles.update', $role) }}" method="POST">
    @csrf
    @method('PUT')

    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px;">
        {{-- Left Column - Permissions --}}
        <div>
            <div class="admin-card">
                <div class="admin-card-header">
                    <span class="admin-card-title"><i class="fa fa-shield-alt" style="margin-right: 6px; color: var(--primary-light);"></i> {{ __('roles.permissions') }}</span>
                </div>
                <div class="admin-card-body">
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                        @php
                            $currentPerms = old('permissions', $rolePermissions ?? []);
                        @endphp
                        @foreach($permissions as $group => $perms)
                        <div style="border: 1px solid var(--border); border-radius: 8px; padding: 16px;">
                            <div style="display: flex; align-items: center; justify-content: space-between; border-bottom: 1px solid var(--border); padding-bottom: 10px; margin-bottom: 12px;">
                                <h4 style="font-size: 12px; font-weight: 700; color: var(--text-primary); text-transform: uppercase;">{{ $group }}</h4>
                                <label style="display: flex; align-items: center; gap: 6px; cursor: pointer; font-size: 11px; color: var(--text-muted);">
                                    <input type="checkbox" class="main-cb" onchange="toggleGroup(this)">
                                    {{ __('roles.select_all') }}
                                </label>
                            </div>
                            <div style="display: flex; flex-direction: column; gap: 8px;">
                                @foreach($perms as $perm)
                                <label style="display: flex; align-items: center; gap: 8px; cursor: pointer; font-size: 12px; color: var(--text-secondary);">
                                    <input name="permissions[]" value="{{ $perm->name }}" type="checkbox" class="perm-cb" onchange="updateGroupCheckbox(this)"
                                           {{ in_array($perm->name, $currentPerms) ? 'checked' : '' }}>
                                    <span>{{ Str::after($perm->name, '.') }}</span>
                                </label>
                                @endforeach
                            </div>
                        </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>

        {{-- Right Column - Role Name --}}
        <div>
            <div class="admin-card">
                <div class="admin-card-header">
                    <span class="admin-card-title"><i class="fa fa-tag" style="margin-right: 6px; color: var(--primary-light);"></i> {{ __('roles.name') }}</span>
                </div>
                <div class="admin-card-body">
                    <div class="form-group">
                        <label class="form-label">{{ __('roles.name') }} <span style="color: var(--danger);">*</span></label>
                        <input name="name" type="text" value="{{ old('name', $role->name) }}" required class="form-control">
                        @error('name') <span style="font-size: 11px; color: var(--danger);">{{ $message }}</span> @enderror
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<script>
function toggleGroup(mainCb) {
    var container = mainCb.closest('div[style*="border"]') || mainCb.closest('div');
    var groupDiv = mainCb.closest('div[style*="border: 1px"]');
    if (!groupDiv) {
        groupDiv = mainCb.closest('div').parentElement.parentElement;
    }
    var checkboxes = groupDiv.querySelectorAll('.perm-cb');
    checkboxes.forEach(function(cb) { cb.checked = mainCb.checked; });
}

function updateGroupCheckbox(permCb) {
    var groupDiv = permCb.closest('div[style*="border: 1px"]');
    if (!groupDiv) return;
    var mainCb = groupDiv.querySelector('.main-cb');
    if (!mainCb) return;
    var allCbs = groupDiv.querySelectorAll('.perm-cb');
    var checkedCbs = groupDiv.querySelectorAll('.perm-cb:checked');
    mainCb.checked = (allCbs.length > 0 && checkedCbs.length === allCbs.length);
    mainCb.indeterminate = (checkedCbs.length > 0 && checkedCbs.length < allCbs.length);
}

// Initialize group checkboxes on page load
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.perm-cb').forEach(function(cb) {
        updateGroupCheckbox(cb);
    });
});
</script>

@endsection
