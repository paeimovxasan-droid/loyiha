@extends('admin.layouts.app')

@section('title', __('roles.title'))

@section('breadcrumb')
    <a href="{{ route('admin.dashboard') }}">Admin</a>
    <i class="fa fa-chevron-right" style="font-size: 9px; color: var(--text-muted);"></i>
    <span class="current">{{ __('roles.title') }}</span>
@endsection

@section('header-actions')
    <a href="{{ route('admin.roles.create') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-plus"></i> {{ __('roles.create') }}
    </a>
@endsection

@section('content')

<div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px;">
    <h2 style="font-size: 18px; font-weight: 700; color: var(--text-primary);">{{ __('roles.list') }}</h2>
</div>

<div class="admin-card">
    <div style="overflow-x: auto;">
        <table class="admin-table">
            <thead>
                <tr>
                    <th>{{ __('table.name') }}</th>
                    <th>{{ __('roles.permissions_count') }}</th>
                    <th>{{ __('table.actions') }}</th>
                </tr>
            </thead>
            <tbody>
                @forelse($roles as $role)
                <tr>
                    <td>
                        <span style="font-size: 13px; font-weight: 600; color: var(--text-primary);">{{ ucfirst($role->name) }}</span>
                        @if($role->name === 'super-admin')
                            <span class="badge badge-danger" style="margin-left: 6px;">Admin</span>
                        @endif
                    </td>
                    <td>
                        <span class="badge badge-info">
                            {{ $role->name === 'super-admin' ? __('status.all') : $role->permissions->count() }}
                        </span>
                    </td>
                    <td>
                        <div style="display: flex; align-items: center; gap: 4px;">
                            @if($role->name !== 'super-admin')
                                <a href="{{ route('admin.roles.edit', $role) }}" class="btn btn-outline btn-sm" title="{{ __('buttons.edit') }}">
                                    <i class="fa fa-pen"></i>
                                </a>

                                @if(!in_array($role->name, ['admin', 'user']))
                                <form method="POST" action="{{ route('admin.roles.destroy', $role) }}" style="margin: 0;"
                                      onsubmit="return confirm('{{ addslashes(__('messages.delete_confirm')) }}')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm" title="{{ __('buttons.delete') }}">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                                @endif
                            @else
                                <span style="font-size: 11px; color: var(--text-muted);">{{ __('roles.no_permission') }}</span>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="3" style="text-align: center; padding: 32px; color: var(--text-muted);">
                        <i class="fa fa-shield-alt" style="font-size: 24px; opacity: .3; display: block; margin-bottom: 8px;"></i>
                        {{ __('roles.no_roles') }}
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

@endsection
