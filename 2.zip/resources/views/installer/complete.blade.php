@extends('installer.layout')
@section('content')

<div class="installer-card" style="text-align:center;">

    <div style="font-size:64px; margin-bottom:16px;">🎉</div>

    <div class="card-title" style="font-size:24px; margin-bottom:8px;">
        AISOQQA o'rnatildi!
    </div>
    <div class="card-subtitle" style="margin-bottom:32px;">
        Platforma muvaffaqiyatli ishga tushirildi. Endi admin panelga kirishingiz mumkin.
    </div>

    <div style="background:rgba(99,102,241,.08); border:1px solid rgba(99,102,241,.15);
                border-radius:16px; padding:20px; margin-bottom:28px; text-align:left;">
        <div style="font-size:12px; font-weight:600; color:#94a3b8; text-transform:uppercase;
                    letter-spacing:.4px; margin-bottom:14px;">
            Kirish ma'lumotlari
        </div>
        <div style="display:flex; flex-direction:column; gap:10px;">
            <div style="display:flex; justify-content:space-between; font-size:13px;">
                <span style="color:#64748b;">Admin panel:</span>
                <a href="/admin" style="color:#818cf8; text-decoration:none; font-weight:600;">/admin</a>
            </div>
            <div style="display:flex; justify-content:space-between; font-size:13px;">
                <span style="color:#64748b;">Frontend:</span>
                <a href="/" style="color:#818cf8; text-decoration:none; font-weight:600;">/</a>
            </div>
        </div>
    </div>

    <div style="display:flex; flex-direction:column; gap:10px;">
        <a href="/admin" class="btn btn-primary btn-full btn-lg">
            <i class="fa fa-gauge-high"></i> Admin panelga kirish
        </a>
        <a href="/" class="btn btn-full"
           style="background:rgba(255,255,255,.06); color:#94a3b8; border:1px solid rgba(255,255,255,.08);">
            <i class="fa fa-house"></i> Saytga o'tish
        </a>
    </div>

    <div style="margin-top:24px; padding:14px; background:rgba(245,158,11,.08);
                border:1px solid rgba(245,158,11,.15); border-radius:12px; font-size:12px; color:#fbbf24;">
        <i class="fa fa-triangle-exclamation" style="margin-right:6px;"></i>
        Xavfsizlik uchun: <code style="background:rgba(0,0,0,.2); padding:2px 6px; border-radius:4px;">/install</code>
        sahifasi endi bloklangan.
    </div>

</div>

@endsection
