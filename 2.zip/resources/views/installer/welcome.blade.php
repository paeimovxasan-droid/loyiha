@extends('installer.layout')
@section('content')

<div class="installer-card">
    <div class="card-title">🚀 Xush kelibsiz!</div>
    <div class="card-subtitle">AISOQQA platformasini o'rnatishdan oldin tizim talablarini tekshiramiz.</div>

    @php $allOk = collect($checks)->every(fn($c) => $c['ok']); @endphp

    @if($allOk)
    <div class="alert alert-success">
        <i class="fa fa-check-circle"></i>
        Barcha talablar bajarilgan. O'rnatishni boshlashingiz mumkin.
    </div>
    @else
    <div class="alert alert-danger">
        <i class="fa fa-exclamation-triangle"></i>
        Ba'zi talablar bajarilmagan. Hostingda kerakli kengaytmalarni yoqing.
    </div>
    @endif

    <div style="margin-bottom: 24px;">
        @foreach($checks as $check)
        <div class="check-item {{ $check['ok'] ? 'ok' : 'fail' }}">
            <span class="name">
                <i class="fa fa-{{ $check['ok'] ? 'check-circle' : 'times-circle' }}"
                   style="margin-right:8px; color:{{ $check['ok'] ? '#34d399' : '#f87171' }};"></i>
                {{ $check['name'] }}
            </span>
            <span class="value">{{ $check['value'] }}</span>
        </div>
        @endforeach
    </div>

    @if($allOk)
    <a href="{{ route('install.database') }}" class="btn btn-primary btn-full btn-lg">
        Boshlash <i class="fa fa-arrow-right"></i>
    </a>
    @else
    <button disabled class="btn btn-primary btn-full btn-lg" style="opacity:.5; cursor:not-allowed;">
        Talablar bajarilmagan
    </button>
    @endif
</div>

@endsection
