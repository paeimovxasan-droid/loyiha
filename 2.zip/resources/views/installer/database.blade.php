@extends('installer.layout')
@section('content')

<div class="installer-card">
    <div class="card-title">🗄️ Ma'lumotlar bazasi</div>
    <div class="card-subtitle">Hosting boshqaruv panelida yaratgan MySQL bazangiz ma'lumotlarini kiriting.</div>

    @if($errors->any())
    <div class="alert alert-danger">
        <i class="fa fa-exclamation-circle"></i>
        {{ $errors->first() }}
    </div>
    @endif

    <form method="POST" action="{{ route('install.database.save') }}">
        @csrf

        <div class="form-row">
            <div class="form-group">
                <label class="form-label">DB Host</label>
                <input type="text" name="db_host" value="{{ old('db_host', 'localhost') }}"
                       class="form-control" placeholder="localhost" required>
            </div>
            <div class="form-group">
                <label class="form-label">DB Port</label>
                <input type="number" name="db_port" value="{{ old('db_port', '3306') }}"
                       class="form-control" placeholder="3306" required>
            </div>
        </div>

        <div class="form-group">
            <label class="form-label">Baza nomi</label>
            <input type="text" name="db_name" value="{{ old('db_name') }}"
                   class="form-control" placeholder="aisoqqa_db" required>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Foydalanuvchi</label>
                <input type="text" name="db_user" value="{{ old('db_user') }}"
                       class="form-control" placeholder="aisoqqa_user" required>
            </div>
            <div class="form-group">
                <label class="form-label">Parol</label>
                <input type="password" name="db_password"
                       class="form-control" placeholder="••••••••">
            </div>
        </div>

        <div class="alert alert-info" style="margin-bottom:20px;">
            <i class="fa fa-info-circle"></i>
            <div>
                Hosting cPanel → MySQL Databases bo'limida baza va foydalanuvchi yarating,
                keyin ularni bir-biriga ulang.
            </div>
        </div>

        <button type="submit" class="btn btn-primary btn-full btn-lg">
            Ulanishni tekshirish <i class="fa fa-arrow-right"></i>
        </button>
    </form>
</div>

@endsection
