@extends('installer.layout')
@section('content')

<div class="installer-card">
    <div class="card-title">⚙️ Sayt sozlamalari</div>
    <div class="card-subtitle">Platformangiz haqida asosiy ma'lumotlarni kiriting.</div>

    @if($errors->any())
    <div class="alert alert-danger">
        <i class="fa fa-exclamation-circle"></i> {{ $errors->first() }}
    </div>
    @endif

    <form method="POST" action="{{ route('install.site.save') }}">
        @csrf

        <div class="form-group">
            <label class="form-label">Sayt nomi</label>
            <input type="text" name="site_name" value="{{ old('site_name', 'AISOQQA') }}"
                   class="form-control" placeholder="AISOQQA" required>
        </div>

        <div class="form-group">
            <label class="form-label">Domen (protokolsiz)</label>
            <input type="text" name="site_domain" value="{{ old('site_domain', request()->getHost()) }}"
                   class="form-control" placeholder="aisoqqa.uz" required>
            <div style="font-size:11px; color:#64748b; margin-top:4px;">
                Misol: aisoqqa.uz (https:// siz)
            </div>
        </div>

        <div class="form-group">
            <label class="form-label">Aloqa email</label>
            <input type="email" name="contact_email" value="{{ old('contact_email') }}"
                   class="form-control" placeholder="support@aisoqqa.uz" required>
        </div>

        <div class="divider"></div>

        <div style="font-size:12px; font-weight:600; color:#94a3b8; text-transform:uppercase; letter-spacing:.4px; margin-bottom:14px;">
            AIS Valyuta sozlamalari
        </div>

        <div class="form-row">
            <div class="form-group">
                <label class="form-label">1 AIS = ? UZS</label>
                <input type="number" name="ais_rate" value="{{ old('ais_rate', '1000') }}"
                       class="form-control" placeholder="1000" min="1" required>
            </div>
            <div class="form-group">
                <label class="form-label">Asosiy valyuta</label>
                <select name="currency" class="form-control">
                    <option value="AIS" {{ old('currency') === 'AIS' ? 'selected' : '' }}>AIS</option>
                    <option value="UZS" {{ old('currency') === 'UZS' ? 'selected' : '' }}>UZS</option>
                    <option value="USD" {{ old('currency') === 'USD' ? 'selected' : '' }}>USD</option>
                </select>
            </div>
        </div>

        <button type="submit" class="btn btn-primary btn-full btn-lg">
            Davom etish <i class="fa fa-arrow-right"></i>
        </button>
    </form>
</div>

@endsection
