<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>AISOQQA — O'rnatish</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            min-height: 100vh;
        }

        /* Glow background */
        body::before {
            content: '';
            position: fixed;
            width: 600px; height: 600px;
            background: radial-gradient(circle, rgba(99,102,241,.12) 0%, transparent 70%);
            top: -200px; left: -100px;
            pointer-events: none;
        }

        .installer-wrap {
            max-width: 680px;
            margin: 0 auto;
            padding: 40px 20px 60px;
            position: relative;
            z-index: 1;
        }

        /* Logo */
        .installer-logo {
            text-align: center;
            margin-bottom: 40px;
        }

        .installer-logo .logo-icon {
            width: 64px; height: 64px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            border-radius: 20px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            margin-bottom: 12px;
            box-shadow: 0 8px 32px rgba(99,102,241,.4);
        }

        .installer-logo h1 {
            font-size: 24px;
            font-weight: 800;
            color: #f1f5f9;
            letter-spacing: -0.5px;
        }

        .installer-logo p {
            font-size: 13px;
            color: #64748b;
            margin-top: 4px;
        }

        /* Steps */
        .steps {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0;
            margin-bottom: 32px;
        }

        .step-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            position: relative;
        }

        .step-item:not(:last-child)::after {
            content: '';
            position: absolute;
            top: 16px;
            left: calc(50% + 16px);
            width: calc(100% - 8px);
            height: 2px;
            background: rgba(255,255,255,.08);
        }

        .step-item.done::after { background: #6366f1; }

        .step-num {
            width: 32px; height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 13px;
            font-weight: 700;
            background: rgba(255,255,255,.06);
            color: #64748b;
            border: 2px solid rgba(255,255,255,.08);
            transition: all .3s;
            z-index: 1;
        }

        .step-item.active .step-num {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: #fff;
            border-color: transparent;
            box-shadow: 0 0 16px rgba(99,102,241,.5);
        }

        .step-item.done .step-num {
            background: #10b981;
            color: #fff;
            border-color: transparent;
        }

        .step-label {
            font-size: 10px;
            color: #475569;
            font-weight: 500;
            white-space: nowrap;
        }

        .step-item.active .step-label { color: #818cf8; }
        .step-item.done .step-label { color: #34d399; }

        /* Card */
        .installer-card {
            background: #1e293b;
            border: 1px solid rgba(255,255,255,.06);
            border-radius: 24px;
            padding: 32px;
        }

        .card-title {
            font-size: 20px;
            font-weight: 700;
            color: #f1f5f9;
            margin-bottom: 6px;
        }

        .card-subtitle {
            font-size: 13px;
            color: #64748b;
            margin-bottom: 28px;
        }

        /* Form */
        .form-group { margin-bottom: 18px; }

        .form-label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            color: #94a3b8;
            margin-bottom: 7px;
            text-transform: uppercase;
            letter-spacing: .4px;
        }

        .form-control {
            width: 100%;
            background: rgba(255,255,255,.04);
            border: 1px solid rgba(255,255,255,.08);
            border-radius: 12px;
            padding: 12px 16px;
            color: #e2e8f0;
            font-size: 14px;
            font-family: inherit;
            outline: none;
            transition: all .2s;
        }

        .form-control:focus {
            border-color: rgba(99,102,241,.5);
            background: rgba(99,102,241,.05);
        }

        .form-control::placeholder { color: #475569; }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
        }

        /* Buttons */
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 24px;
            border-radius: 12px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: all .2s;
            font-family: inherit;
            text-decoration: none;
        }

        .btn-primary {
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: #fff;
            box-shadow: 0 4px 14px rgba(99,102,241,.35);
        }

        .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 6px 20px rgba(99,102,241,.45); }
        .btn-full { width: 100%; justify-content: center; }
        .btn-lg { padding: 14px 28px; font-size: 15px; }

        /* Alert */
        .alert {
            padding: 12px 16px;
            border-radius: 12px;
            font-size: 13px;
            margin-bottom: 20px;
            display: flex;
            align-items: flex-start;
            gap: 8px;
        }

        .alert-danger { background: rgba(239,68,68,.1); border: 1px solid rgba(239,68,68,.2); color: #f87171; }
        .alert-success { background: rgba(16,185,129,.1); border: 1px solid rgba(16,185,129,.2); color: #34d399; }
        .alert-info { background: rgba(99,102,241,.1); border: 1px solid rgba(99,102,241,.2); color: #818cf8; }

        /* Check item */
        .check-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px 14px;
            border-radius: 10px;
            margin-bottom: 6px;
            background: rgba(255,255,255,.03);
        }

        .check-item .name { font-size: 13px; color: #94a3b8; }
        .check-item .value { font-size: 12px; font-weight: 600; }
        .check-item.ok .value { color: #34d399; }
        .check-item.fail .value { color: #f87171; }

        /* Progress log */
        .log-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 14px;
            border-radius: 10px;
            margin-bottom: 6px;
            font-size: 13px;
            background: rgba(255,255,255,.03);
            animation: fadeIn .3s ease;
        }

        .log-item.ok { color: #34d399; }
        .log-item.fail { color: #f87171; }
        .log-item.pending { color: #94a3b8; }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(4px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .spinner {
            width: 16px; height: 16px;
            border: 2px solid rgba(255,255,255,.2);
            border-top-color: #818cf8;
            border-radius: 50%;
            animation: spin .6s linear infinite;
            flex-shrink: 0;
        }

        @keyframes spin { to { transform: rotate(360deg); } }

        /* Divider */
        .divider { height: 1px; background: rgba(255,255,255,.06); margin: 20px 0; }
    </style>
</head>
<body>
<div class="installer-wrap">

    {{-- Logo --}}
    <div class="installer-logo">
        <div class="logo-icon">💎</div>
        <h1>AISOQQA</h1>
        <p>Platform Installer v1.0.0</p>
    </div>

    {{-- Steps --}}
    @php
        $steps = [
            ['label' => 'Talab', 'route' => 'install.welcome'],
            ['label' => 'Baza', 'route' => 'install.database'],
            ['label' => 'Sayt', 'route' => 'install.site'],
            ['label' => 'Admin', 'route' => 'install.admin'],
            ['label' => 'O\'rnatish', 'route' => 'install.process'],
        ];
        $currentRoute = request()->route()?->getName() ?? '';
        $stepOrder = array_column($steps, 'route');
        $currentIndex = array_search($currentRoute, $stepOrder);
        if ($currentIndex === false) $currentIndex = count($steps);
    @endphp

    <div class="steps">
        @foreach($steps as $i => $s)
        <div class="step-item {{ $i < $currentIndex ? 'done' : ($i === $currentIndex ? 'active' : '') }}"
             style="min-width: {{ count($steps) > 4 ? '80px' : '100px' }};">
            <div class="step-num">
                @if($i < $currentIndex)
                    <i class="fa fa-check" style="font-size:11px;"></i>
                @else
                    {{ $i + 1 }}
                @endif
            </div>
            <div class="step-label">{{ $s['label'] }}</div>
        </div>
        @endforeach
    </div>

    {{-- Content --}}
    @yield('content')

</div>
</body>
</html>
