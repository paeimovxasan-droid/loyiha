@extends('installer.layout')
@section('content')

<div class="installer-card">
    <div class="card-title">👤 Super Admin hisob</div>
    <div class="card-subtitle">Platformani boshqarish uchun asosiy admin hisobini yarating.</div>

    @if($errors->any())
    <div class="alert alert-danger">
        <i class="fa fa-exclamation-circle"></i> {{ $errors->first() }}
    </div>
    @endif

    <form method="POST" action="{{ route('install.admin.save') }}">
        @csrf

        <div class="form-group">
            <label class="form-label">To'liq ism</label>
            <input type="text" name="name" value="{{ old('name') }}"
                   class="form-control" placeholder="Super Admin" required>
        </div>

        <div class="form-group">
            <label class="form-label">Email</label>
            <input type="email" name="email" value="{{ old('email') }}"
                   class="form-control" placeholder="admin@aisoqqa.uz" required>
        </div>

        <div class="form-group">
            <label class="form-label">Parol (kamida 8 belgi)</label>
            <input type="password" name="password"
                   class="form-control" placeholder="••••••••" required minlength="8">
        </div>

        <div class="form-group">
            <label class="form-label">Parolni tasdiqlang</label>
            <input type="password" name="password_confirmation"
                   class="form-control" placeholder="••••••••" required>
        </div>

        <div class="alert alert-info">
            <i class="fa fa-shield-halved"></i>
            <div>Bu ma'lumotlarni xavfsiz joyda saqlang. Parolni keyinchalik admin paneldan o'zgartirish mumkin.</div>
        </div>

        <button type="submit" class="btn btn-primary btn-full btn-lg">
            O'rnatishni boshlash <i class="fa fa-rocket"></i>
        </button>
    </form>
</div>

@endsection
