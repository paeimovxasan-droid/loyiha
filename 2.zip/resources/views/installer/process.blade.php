@extends('installer.layout')
@section('content')

<div class="installer-card">
    <div class="card-title" id="processTitle">⚙️ O'rnatilmoqda...</div>
    <div class="card-subtitle" id="processSubtitle">Iltimos kuting, bu bir necha soniya oladi.</div>

    <div id="logContainer" style="margin-bottom: 24px; min-height: 200px;">
        <div class="log-item pending">
            <div class="spinner"></div>
            <span>O'rnatish boshlanmoqda...</span>
        </div>
    </div>

    <div id="progressWrap" style="margin-bottom: 20px;">
        <div style="display:flex; justify-content:space-between; font-size:12px; color:#64748b; margin-bottom:6px;">
            <span>Jarayon</span>
            <span id="progressPct">0%</span>
        </div>
        <div style="height:6px; background:rgba(255,255,255,.06); border-radius:10px; overflow:hidden;">
            <div id="progressBar"
                 style="height:100%; width:0%; background:linear-gradient(90deg,#6366f1,#8b5cf6);
                        border-radius:10px; transition:width .4s;"></div>
        </div>
    </div>

    <div id="actionBtn" style="display:none;">
        <a href="/admin" class="btn btn-primary btn-full btn-lg">
            <i class="fa fa-gauge-high"></i> Admin panelga kirish
        </a>
    </div>

    <div id="errorMsg" style="display:none;" class="alert alert-danger">
        <i class="fa fa-exclamation-triangle"></i>
        <div id="errorText"></div>
    </div>
</div>

<script>
const TOTAL_STEPS = 10;
let completedSteps = 0;

function addLog(text, status = 'ok') {
    const container = document.getElementById('logContainer');
    // Spinner ni olib tashlash
    const spinner = container.querySelector('.log-item.pending');
    if (spinner) spinner.remove();

    const div = document.createElement('div');
    div.className = `log-item ${status}`;
    div.innerHTML = status === 'ok'
        ? `<i class="fa fa-check-circle" style="color:#34d399; flex-shrink:0;"></i><span>${text}</span>`
        : `<i class="fa fa-times-circle" style="color:#f87171; flex-shrink:0;"></i><span>${text}</span>`;
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;

    completedSteps++;
    const pct = Math.round((completedSteps / TOTAL_STEPS) * 100);
    document.getElementById('progressBar').style.width = pct + '%';
    document.getElementById('progressPct').textContent = pct + '%';
}

async function runInstall() {
    try {
        const res = await fetch('{{ route("install.run") }}', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
            },
            body: JSON.stringify({}),
        });

        const data = await res.json();

        // Steplarni ko'rsatish
        if (data.steps) {
            for (const step of data.steps) {
                await new Promise(r => setTimeout(r, 200));
                addLog(step.step, step.ok ? 'ok' : 'fail');
            }
        }

        if (data.success) {
            document.getElementById('progressBar').style.width = '100%';
            document.getElementById('progressPct').textContent = '100%';
            document.getElementById('processTitle').textContent = '🎉 O\'rnatish yakunlandi!';
            document.getElementById('processSubtitle').textContent = 'AISOQQA muvaffaqiyatli o\'rnatildi.';

            await new Promise(r => setTimeout(r, 500));
            window.location.href = data.redirect || '/install/complete';
        } else {
            document.getElementById('processTitle').textContent = '❌ Xato yuz berdi';
            document.getElementById('processSubtitle').textContent = 'Quyidagi xatoni ko\'ring va qaytadan urinib ko\'ring.';
            document.getElementById('errorMsg').style.display = 'flex';
            document.getElementById('errorText').textContent = data.message || 'Noma\'lum xato';
        }

    } catch (err) {
        document.getElementById('errorMsg').style.display = 'flex';
        document.getElementById('errorText').textContent = 'Server bilan bog\'lanishda xato: ' + err.message;
    }
}

// Sahifa yuklanganda avtomatik boshlash
window.addEventListener('load', () => {
    setTimeout(runInstall, 600);
});
</script>

@endsection
