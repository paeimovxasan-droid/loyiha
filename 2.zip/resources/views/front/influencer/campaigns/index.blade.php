@extends('front.layouts.app')

@section('title', 'Faol Kampaniyalar')

@section('content')
<div class="container mx-auto px-4 py-6 max-w-2xl">

    <div class="flex items-center gap-3 mb-6">
        <a href="{{ route('app.influencer.dashboard') }}" class="text-slate-400 hover:text-primary">←</a>
        <h1 class="text-xl font-bold text-slate-800 dark:text-white">📢 Faol Kampaniyalar</h1>
    </div>

    @if(session('success'))
        <div class="bg-success/10 text-success border border-success/20 rounded-lg p-3 mb-4 text-sm">{{ session('success') }}</div>
    @endif
    @if(session('error'))
        <div class="bg-error/10 text-error border border-error/20 rounded-lg p-3 mb-4 text-sm">{{ session('error') }}</div>
    @endif

    @if(!$hasApprovedChannel)
    <div class="card p-6 text-center">
        <div class="text-4xl mb-3">🔒</div>
        <h3 class="font-semibold text-slate-700 dark:text-white mb-2">Kanal tasdiqlanmagan</h3>
        <p class="text-sm text-slate-400 mb-4">Kampaniyalarda ishtirok etish uchun avval kanal qo'shing va admin tasdiqlashini kuting.</p>
        <a href="{{ route('app.influencer.channels') }}" class="btn bg-primary text-white">Kanal qo'shish</a>
    </div>
    @elseif($campaigns->isEmpty())
    <div class="card p-8 text-center">
        <div class="text-4xl mb-3">📭</div>
        <p class="text-slate-400 text-sm">Hozirda sizning kanal turingizga mos faol kampaniyalar yo'q</p>
    </div>
    @else
    <div class="space-y-4">
        @foreach($campaigns as $campaign)
        <div class="card p-5" x-data="{ showForm: false }">
            {{-- Kampaniya ma'lumotlari --}}
            <div class="flex items-start gap-3">
                @if($campaign->image_url)
                <img src="{{ $campaign->image_url }}" alt="" class="w-16 h-16 rounded-lg object-cover flex-shrink-0">
                @endif
                <div class="flex-1">
                    <h3 class="font-semibold text-slate-800 dark:text-white">{{ $campaign->name }}</h3>
                    <div class="text-xs text-slate-400 mt-1">
                        {{ implode(', ', array_map(fn($t) => \App\Models\Influencer\InfluencerChannel::TYPES[$t] ?? $t, $campaign->target_channel_types ?? [])) }}
                    </div>
                    <div class="text-xs text-slate-400">Tugash: {{ $campaign->ends_at->format('d.m.Y') }}</div>
                </div>
                <div class="text-right flex-shrink-0">
                    <div class="text-xl font-bold text-success">{{ number_format($campaign->reward_amount, 0) }}+</div>
                    <div class="text-xs text-slate-400">AIS mukofot</div>
                </div>
            </div>

            {{-- Reklama matni --}}
            <div class="mt-3 bg-slate-50 dark:bg-navy-800 rounded-lg p-3 text-sm text-slate-600 dark:text-slate-300">
                {{ $campaign->getTranslation('ad_text', app()->getLocale()) ?: $campaign->getTranslation('ad_text', 'uz') }}
            </div>

            {{-- Byudjet progress --}}
            <div class="mt-3">
                <div class="flex justify-between text-xs text-slate-400 mb-1">
                    <span>Byudjet</span>
                    <span>{{ number_format($campaign->remaining_budget, 0) }} AIS qoldi</span>
                </div>
                <div class="h-1.5 bg-slate-200 rounded-full">
                    <div class="h-full bg-primary rounded-full" style="width: {{ $campaign->budget_percent }}%"></div>
                </div>
            </div>

            {{-- Submission tugmasi --}}
            <button @click="showForm = !showForm" class="btn bg-primary text-white w-full mt-4 text-sm">
                📤 Submission yuborish
            </button>

            {{-- Submission formasi --}}
            <form x-show="showForm" x-cloak method="POST" action="{{ route('app.influencer.submissions.store') }}"
                  enctype="multipart/form-data" class="mt-4 space-y-3 border-t border-slate-200 pt-4">
                @csrf
                <input type="hidden" name="campaign_id" value="{{ $campaign->id }}">

                <div>
                    <label class="block text-sm font-medium mb-1">Kanal tanlang *</label>
                    <select name="channel_id" class="form-select w-full" required>
                        <option value="">Tanlang...</option>
                        @foreach($campaign->eligible_channels as $ch)
                            <option value="{{ $ch->id }}">{{ $ch->name }} ({{ $ch->type_label }})</option>
                        @endforeach
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium mb-1">Post URL *</label>
                    <input type="url" name="post_url" class="form-input w-full" placeholder="https://t.me/kanalim/123" required>
                    <p class="text-xs text-slate-400 mt-1">Reklama joylashtirgan post havolasi</p>
                </div>

                <div>
                    <label class="block text-sm font-medium mb-1">Screenshot</label>
                    <input type="file" name="screenshot" accept="image/*" class="form-input w-full">
                    <p class="text-xs text-slate-400 mt-1">Post screenshotini yuklang (majburiy bo'lishi mumkin)</p>
                </div>

                <div class="flex gap-3">
                    <button type="button" @click="showForm = false" class="btn bg-slate-200 flex-1">Bekor</button>
                    <button type="submit" class="btn bg-success text-white flex-1">✅ Yuborish</button>
                </div>
            </form>
        </div>
        @endforeach
    </div>
    @endif
</div>
@endsection
