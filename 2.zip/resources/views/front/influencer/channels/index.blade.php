@extends('front.layouts.app')

@section('title', 'Mening Kanallarim')

@section('content')

<div style="display:flex; align-items:center; gap:12px; margin-bottom:20px;">
    <a href="{{ route('app.influencer.dashboard') }}" style="color:var(--text-muted); text-decoration:none; font-size:18px;">←</a>
    <h1 class="page-title" style="margin-bottom:0;">📡 Mening Kanallarim</h1>
</div>

@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif
@if(session('error'))
    <div class="alert alert-danger">{{ session('error') }}</div>
@endif

{{-- Kanal qo'shish formasi --}}
<div class="card" style="padding:20px; margin-bottom:20px;">
    <div style="display:flex; align-items:center; justify-content:space-between; cursor:pointer;" onclick="document.getElementById('channelForm').style.display = document.getElementById('channelForm').style.display === 'none' ? 'block' : 'none'">
        <span style="font-size:14px; font-weight:600; color:var(--text);">+ Yangi kanal qo'shish</span>
        <span style="font-size:18px; color:var(--text-muted);">▼</span>
    </div>

    <form id="channelForm" method="POST" action="{{ route('app.influencer.channels.store') }}" style="display:none; margin-top:16px;">
        @csrf
        <div class="form-group">
            <label class="form-label">Kanal turi *</label>
            <select name="type" class="form-control" required>
                <option value="">Tanlang...</option>
                @foreach($types as $key => $label)
                    <option value="{{ $key }}" @selected(old('type')==$key)>{{ $label }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label class="form-label">Kanal nomi *</label>
            <input type="text" name="name" value="{{ old('name') }}" class="form-control" placeholder="Masalan: AISOQQA News" required>
        </div>
        <div class="form-group">
            <label class="form-label">Kanal URL yoki @username *</label>
            <input type="text" name="url" value="{{ old('url') }}" class="form-control" placeholder="https://t.me/kanalim yoki @kanalim" required>
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px;">
            <div class="form-group">
                <label class="form-label">Obunachi soni</label>
                <input type="number" name="subscriber_count" value="{{ old('subscriber_count', 0) }}" min="0" class="form-control">
            </div>
            <div class="form-group">
                <label class="form-label">Til</label>
                <select name="language" class="form-control">
                    <option value="uz" @selected(old('language')=='uz')>O'zbek</option>
                    <option value="ru" @selected(old('language')=='ru')>Русский</option>
                    <option value="en" @selected(old('language')=='en')>English</option>
                </select>
            </div>
        </div>
        <button type="submit" class="btn btn-primary btn-full">Kanal qo'shish</button>
    </form>
</div>

{{-- Kanallar ro'yxati --}}
@forelse($channels as $channel)
<div class="card" style="padding:16px; margin-bottom:10px;">
    <div style="display:flex; align-items:flex-start; justify-content:space-between;">
        <div style="flex:1;">
            <div style="display:flex; align-items:center; gap:8px;">
                <span style="font-size:13px; font-weight:600; color:var(--text);">{{ $channel->name }}</span>
                {!! $channel->status_badge !!}
            </div>
            <div style="font-size:11px; color:var(--text-muted); margin-top:4px;">{{ $channel->type_label }}</div>
            <a href="{{ $channel->url }}" target="_blank" style="font-size:11px; color:var(--primary); text-decoration:none;">{{ Str::limit($channel->url, 45) }}</a>
            <div style="font-size:11px; color:var(--text-muted); margin-top:4px;">👥 {{ number_format($channel->subscriber_count) }} obunachi</div>

            @if($channel->status === 'rejected' && $channel->rejection_reason)
                <div style="font-size:11px; color:var(--danger); margin-top:8px; background:rgba(239,68,68,.08); border-radius:8px; padding:8px;">
                    ❌ Rad etish sababi: {{ $channel->rejection_reason }}
                </div>
            @endif
        </div>

        @if(in_array($channel->status, ['pending', 'rejected']))
        <form method="POST" action="{{ route('app.influencer.channels.destroy', $channel) }}" style="margin-left:12px;">
            @csrf @method('DELETE')
            <button type="submit" style="font-size:11px; color:var(--danger); background:none; border:none; cursor:pointer; text-decoration:underline;" onclick="return confirm('O\'chirasizmi?')">O'chirish</button>
        </form>
        @endif
    </div>
</div>
@empty
<div class="card" style="padding:40px; text-align:center;">
    <div style="font-size:40px; margin-bottom:12px;">📡</div>
    <p style="font-size:13px; color:var(--text-muted);">Hali kanal qo'shilmagan</p>
</div>
@endforelse

@endsection
