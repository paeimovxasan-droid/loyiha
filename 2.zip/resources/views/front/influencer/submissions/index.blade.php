@extends('front.layouts.app')

@section('title', 'Submission Tarixi')

@section('content')

<div style="display:flex; align-items:center; gap:12px; margin-bottom:20px;">
    <a href="{{ route('app.influencer.dashboard') }}" style="color:var(--text-muted); text-decoration:none; font-size:18px;">←</a>
    <h1 class="page-title" style="margin-bottom:0;">📋 Submission Tarixi</h1>
</div>

@forelse($submissions as $sub)
<div class="card" style="padding:16px; margin-bottom:10px;">
    <div style="display:flex; align-items:flex-start; justify-content:space-between;">
        <div style="flex:1;">
            <div style="font-size:13px; font-weight:600; color:var(--text);">{{ $sub->campaign?->name ?? '—' }}</div>
            <div style="font-size:11px; color:var(--text-muted); margin-top:4px;">
                📡 {{ $sub->channel?->name ?? '—' }} ({{ $sub->channel?->type_label ?? '' }})
            </div>
            <a href="{{ $sub->post_url }}" target="_blank" style="font-size:11px; color:var(--primary); text-decoration:none; display:block; margin-top:4px;">
                🔗 {{ Str::limit($sub->post_url, 45) }}
            </a>
            <div style="font-size:11px; color:var(--text-muted); margin-top:4px;">{{ $sub->created_at->format('d.m.Y H:i') }}</div>

            @if($sub->status === 'rejected' && $sub->rejection_reason)
                <div style="font-size:11px; color:var(--danger); margin-top:8px; background:rgba(239,68,68,.08); border-radius:8px; padding:8px;">
                    ❌ {{ $sub->rejection_reason }}
                </div>
            @endif
        </div>
        <div style="text-align:right; margin-left:12px;">
            {!! $sub->status_badge !!}
            @if($sub->reward && $sub->reward->amount)
                <div style="font-size:13px; font-weight:700; color:#10b981; margin-top:6px;">+{{ number_format($sub->reward->amount, 2) }} AIS</div>
            @elseif($sub->reward_amount)
                <div style="font-size:11px; color:var(--text-muted); margin-top:4px;">~{{ number_format($sub->reward_amount, 2) }} AIS</div>
            @endif
        </div>
    </div>
</div>
@empty
<div class="card" style="padding:40px; text-align:center;">
    <div style="font-size:40px; margin-bottom:12px;">📭</div>
    <p style="font-size:13px; color:var(--text-muted); margin-bottom:16px;">Hali submission yuborilmagan</p>
    <a href="{{ route('app.influencer.campaigns') }}" class="btn btn-primary">Kampaniyalarni ko'rish</a>
</div>
@endforelse

@if($submissions->hasPages())
<div style="margin-top:16px; text-align:center;">
    {{ $submissions->links() }}
</div>
@endif

@endsection
