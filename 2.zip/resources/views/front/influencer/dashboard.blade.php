@extends('front.layouts.app')

@section('title', 'Influencer Dashboard')

@section('content')

{{-- Header --}}
<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:20px;">
    <div>
        <h1 class="page-title" style="margin-bottom:4px;">📢 Influencer</h1>
        <p style="font-size:13px; color:var(--text-muted);">Reklama qilib AIS mukofot oling</p>
    </div>
    <a href="{{ route('app.influencer.channels') }}" class="btn btn-primary btn-sm">+ Kanal qo'shish</a>
</div>

@if(session('success'))
    <div class="alert alert-success">{{ session('success') }}</div>
@endif
@if(session('error'))
    <div class="alert alert-danger">{{ session('error') }}</div>
@endif

{{-- Statistika --}}
<div class="grid grid-2" style="margin-bottom:20px;">
    <div class="stat-card">
        <div class="stat-value" style="color:#818cf8;">{{ number_format($stats['total_earned_ais'], 2) }}</div>
        <div class="stat-label">Jami AIS mukofot</div>
    </div>
    <div class="stat-card">
        <div class="stat-value" style="color:#10b981;">{{ $stats['approved_channels'] }}</div>
        <div class="stat-label">Tasdiqlangan kanal</div>
    </div>
    <div class="stat-card">
        <div class="stat-value">{{ $stats['total_submissions'] }}</div>
        <div class="stat-label">Jami submission</div>
    </div>
    <div class="stat-card">
        <div class="stat-value" style="color:#f59e0b;">{{ $stats['pending_submissions'] }}</div>
        <div class="stat-label">Kutilayotgan</div>
    </div>
</div>

{{-- Faol kampaniyalar --}}
@if($hasApprovedChannel && count($activeCampaigns) > 0)
<div style="margin-bottom:20px;">
    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:12px;">
        <h2 style="font-size:15px; font-weight:600; color:var(--text);">🔥 Faol Kampaniyalar</h2>
        <a href="{{ route('app.influencer.campaigns') }}" style="font-size:13px; color:var(--primary); text-decoration:none;">Barchasi →</a>
    </div>
    <div style="display:flex; flex-direction:column; gap:12px;">
        @foreach($activeCampaigns as $campaign)
        <div class="card" style="padding:16px;">
            <div style="display:flex; align-items:flex-start; justify-content:space-between;">
                <div style="flex:1;">
                    <div style="font-size:14px; font-weight:600; color:var(--text);">{{ $campaign->name }}</div>
                    <div style="font-size:12px; color:var(--text-muted); margin-top:4px;">
                        {{ implode(', ', array_map(fn($t) => \App\Models\Influencer\InfluencerChannel::TYPES[$t] ?? $t, $campaign->target_channel_types ?? [])) }}
                    </div>
                    <div style="font-size:12px; color:var(--text-muted);">Tugash: {{ $campaign->ends_at->format('d.m.Y') }}</div>
                </div>
                <div style="text-align:right; margin-left:12px;">
                    <div style="font-size:20px; font-weight:800; color:#10b981;">{{ number_format($campaign->reward_amount, 0) }}+</div>
                    <div style="font-size:11px; color:var(--text-muted);">AIS</div>
                </div>
            </div>
            <a href="{{ route('app.influencer.campaigns') }}" class="btn btn-primary btn-full" style="margin-top:12px; font-size:12px;">
                Ishtirok etish →
            </a>
        </div>
        @endforeach
    </div>
</div>
@elseif(!$hasApprovedChannel)
<div class="card" style="padding:30px; text-align:center; margin-bottom:20px;">
    <div style="font-size:48px; margin-bottom:12px;">📢</div>
    <h3 style="font-size:16px; font-weight:700; color:var(--text); margin-bottom:8px;">Kanal qo'shing</h3>
    <p style="font-size:13px; color:var(--text-muted); margin-bottom:16px;">Kampaniyalarda ishtirok etish uchun avval kanal qo'shing va admin tasdiqlashini kuting.</p>
    <a href="{{ route('app.influencer.channels') }}" class="btn btn-primary">Kanal qo'shish</a>
</div>
@endif

{{-- Oxirgi submissionlar --}}
@if(count($recentSubmissions) > 0)
<div style="margin-bottom:20px;">
    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:12px;">
        <h2 style="font-size:15px; font-weight:600; color:var(--text);">📋 Oxirgi Submissionlar</h2>
        <a href="{{ route('app.influencer.submissions') }}" style="font-size:13px; color:var(--primary); text-decoration:none;">Barchasi →</a>
    </div>
    <div style="display:flex; flex-direction:column; gap:8px;">
        @foreach($recentSubmissions as $sub)
        <div class="card" style="padding:12px 16px; display:flex; align-items:center; justify-content:space-between;">
            <div>
                <div style="font-size:13px; font-weight:600; color:var(--text);">{{ $sub->campaign?->name ?? '—' }}</div>
                <div style="font-size:11px; color:var(--text-muted);">{{ $sub->channel?->name ?? '—' }} • {{ $sub->created_at->format('d.m.Y') }}</div>
            </div>
            <div style="text-align:right;">
                {!! $sub->status_badge !!}
                @if($sub->reward_amount)
                    <div style="font-size:11px; color:#10b981; margin-top:2px;">+{{ number_format($sub->reward_amount, 2) }} AIS</div>
                @endif
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif

{{-- Navigatsiya --}}
<div class="grid grid-3" style="margin-top:20px;">
    <a href="{{ route('app.influencer.channels') }}" class="card" style="padding:16px; text-align:center; text-decoration:none; transition:all .2s;">
        <div style="font-size:28px;">📡</div>
        <div style="font-size:12px; color:var(--text-muted); margin-top:6px;">Kanallar</div>
    </a>
    <a href="{{ route('app.influencer.campaigns') }}" class="card" style="padding:16px; text-align:center; text-decoration:none; transition:all .2s;">
        <div style="font-size:28px;">📢</div>
        <div style="font-size:12px; color:var(--text-muted); margin-top:6px;">Kampaniyalar</div>
    </a>
    <a href="{{ route('app.influencer.submissions') }}" class="card" style="padding:16px; text-align:center; text-decoration:none; transition:all .2s;">
        <div style="font-size:28px;">📋</div>
        <div style="font-size:12px; color:var(--text-muted); margin-top:6px;">Submissionlar</div>
    </a>
</div>

@endsection
