@extends('front.layouts.auth')

@section('title', 'Parolni tiklash')

@section('content')
<div class="auth-card">
    <h2 class="auth-title">Parolni tiklash 🔑</h2>
    <p class="auth-subtitle">Email manzilingizni kiriting, parolni tiklash havolasini yuboramiz.</p>

    @if($errors->any())
    <div class="alert-danger">
        <i class="fa fa-exclamation-circle"></i>
        {{ $errors->first() }}
    </div>
    @endif

    @if(session('success'))
    <div class="alert-success">
        <i class="fa fa-check-circle"></i>
        {{ session('success') }}
    </div>
    @endif

    <form method="POST" action="{{ route('password.send') }}">
        @csrf

        <div class="form-group">
            <label class="form-label">Email</label>
            <div class="input-wrap">
                <i class="fa fa-envelope input-icon"></i>
                <input type="email" name="email" class="form-input" placeholder="email@example.com" value="{{ old('email') }}" required>
            </div>
        </div>

        <button type="submit" class="btn-primary w-full">Havola yuborish</button>
    </form>

    <div class="auth-footer">
        <a href="{{ route('login') }}">← Kirish sahifasiga qaytish</a>
    </div>
</div>
@endsection
