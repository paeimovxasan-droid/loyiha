@extends('front.layouts.auth')

@section('title', __('front.auth.register_title'))

@section('content')
<div class="auth-card">
    <h2 class="auth-title">{{ __('front.auth.register_title') }} 🚀</h2>
    <p class="auth-subtitle">{{ __('front.auth.register_subtitle') }}</p>

    @if(isset($referrer))
    <div class="ref-badge">
        <i class="fa fa-user-plus"></i>
        {{ __('front.auth.referrer_label') }} <strong>{{ $referrer->name }}</strong>
    </div>
    @endif

    @if($errors->any())
    <div class="alert-danger">
        <i class="fa fa-exclamation-circle"></i>
        {{ $errors->first() }}
    </div>
    @endif

    <form method="POST" action="{{ route('register.post') }}">
        @csrf
        @if(isset($referrer))
        <input type="hidden" name="ref" value="{{ $referrer->username }}">
        @endif

        <div class="form-group">
            <label class="form-label">{{ __('front.auth.full_name') }} <span style="color:#ef4444;">*</span></label>
            <div class="input-wrap">
                <i class="fa fa-user input-icon"></i>
                <input type="text" name="name" value="{{ old('name') }}" required
                       class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}"
                       placeholder="{{ __('front.auth.full_name_placeholder') }}">
            </div>
            @error('name') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
        </div>

        <div class="form-group">
            <label class="form-label">{{ __('front.auth.username') }} <span style="color:#ef4444;">*</span></label>
            <div class="input-wrap">
                <i class="fa fa-at input-icon"></i>
                <input type="text" name="username" value="{{ old('username') }}" required
                       class="form-control {{ $errors->has('username') ? 'is-invalid' : '' }}"
                       placeholder="{{ __('front.auth.username_placeholder') }}">
            </div>
            @error('username') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
        </div>

        <div class="form-group">
            <label class="form-label">{{ __('front.auth.email') }} <span style="color:#ef4444;">*</span></label>
            <div class="input-wrap">
                <i class="fa fa-envelope input-icon"></i>
                <input type="email" name="email" value="{{ old('email') }}" required
                       class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}"
                       placeholder="email@example.com">
            </div>
            @error('email') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
        </div>

        <div class="form-group">
            <label class="form-label">{{ __('front.auth.phone') }}</label>
            <div class="input-wrap">
                <i class="fa fa-phone input-icon"></i>
                <input type="text" name="phone" value="{{ old('phone') }}"
                       class="form-control {{ $errors->has('phone') ? 'is-invalid' : '' }}"
                       placeholder="+998901234567">
            </div>
            @error('phone') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
        </div>

        <div class="form-group">
            <label class="form-label">{{ __('front.auth.password') }} <span style="color:#ef4444;">*</span></label>
            <div class="input-wrap">
                <i class="fa fa-lock input-icon"></i>
                <input type="password" name="password" required
                       class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                       placeholder="{{ __('front.auth.password_placeholder') }}">
            </div>
            @error('password') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
        </div>

        <div class="form-group" style="margin-bottom:24px;">
            <label class="form-label">{{ __('front.auth.password_confirm') }} <span style="color:#ef4444;">*</span></label>
            <div class="input-wrap">
                <i class="fa fa-lock input-icon"></i>
                <input type="password" name="password_confirmation" required
                       class="form-control"
                       placeholder="{{ __('front.auth.password_confirm_placeholder') }}">
            </div>
        </div>

        <input type="hidden" name="fingerprint_hash" id="fingerprint_hash">

        <button type="submit" class="btn-auth">
            <i class="fa fa-user-plus"></i>
            {{ __('front.auth.register_btn') }}
        </button>
    </form>

    <script>
    (async function() {
        try {
            const raw = navigator.userAgent + '|' + screen.width + 'x' + screen.height + '|' +
                Intl.DateTimeFormat().resolvedOptions().timeZone + '|' + navigator.language;
            const encoder = new TextEncoder();
            const data = encoder.encode(raw);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
            document.getElementById('fingerprint_hash').value = hashHex;
        } catch(e) {}
    })();
    </script>

    <div class="auth-link-row">
        {{ __('front.auth.have_account') }} <a href="{{ route('login') }}">{{ __('front.auth.login_btn') }}</a>
    </div>
</div>
@endsection
