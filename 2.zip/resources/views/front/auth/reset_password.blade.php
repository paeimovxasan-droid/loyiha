@extends('front.layouts.auth')

@section('title', 'Yangi parol')

@section('content')
<div class="auth-card">
    <h2 class="auth-title">Yangi parol o'rnatish 🔐</h2>
    <p class="auth-subtitle">Yangi parolingizni kiriting.</p>

    @if($errors->any())
    <div class="alert-danger">
        <i class="fa fa-exclamation-circle"></i>
        {{ $errors->first() }}
    </div>
    @endif

    <form method="POST" action="{{ route('password.update') }}">
        @csrf
        <input type="hidden" name="token" value="{{ $token }}">
        <input type="hidden" name="email" value="{{ $email }}">

        <div class="form-group">
            <label class="form-label">Yangi parol</label>
            <div class="input-wrap">
                <i class="fa fa-lock input-icon"></i>
                <input type="password" name="password" class="form-input" placeholder="Kamida 8 ta belgi" required>
            </div>
        </div>

        <div class="form-group">
            <label class="form-label">Parolni tasdiqlash</label>
            <div class="input-wrap">
                <i class="fa fa-lock input-icon"></i>
                <input type="password" name="password_confirmation" class="form-input" placeholder="Parolni qayta kiriting" required>
            </div>
        </div>

        <button type="submit" class="btn-primary w-full">Parolni yangilash</button>
    </form>

    <div class="auth-footer">
        <a href="{{ route('login') }}">← Kirish sahifasiga qaytish</a>
    </div>
</div>
@endsection
