@extends('front.layouts.auth')

@section('title', __('front.auth.login_title'))

@section('content')
<div class="auth-card">
    <h2 class="auth-title">{{ __('front.auth.welcome') }} 👋</h2>
    <p class="auth-subtitle">{{ __('front.auth.login_subtitle') }}</p>

    @if($errors->any())
    <div class="alert-danger">
        <i class="fa fa-exclamation-circle"></i>
        {{ $errors->first() }}
    </div>
    @endif

    @if(session('success'))
    <div class="alert-success">
        <i class="fa fa-check-circle"></i>
        {{ session('success') }}
    </div>
    @endif

    <form method="POST" action="{{ route('login.post') }}">
        @csrf

        <div class="form-group">
            <label class="form-label">{{ __('front.auth.login_label') }}</label>
            <div class="input-wrap">
                <i class="fa fa-user input-icon"></i>
                <input type="text" name="login" value="{{ old('login') }}" required autofocus
                       class="form-control {{ $errors->has('login') ? 'is-invalid' : '' }}"
                       placeholder="{{ __('front.auth.login_placeholder') }}">
            </div>
            @error('login')
            <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div>
            @enderror
        </div>

        <div class="form-group">
            <label class="form-label">{{ __('front.auth.password') }}</label>
            <div class="input-wrap">
                <i class="fa fa-lock input-icon"></i>
                <input type="password" name="password" required
                       class="form-control {{ $errors->has('password') ? 'is-invalid' : '' }}"
                       placeholder="••••••••">
            </div>
            @error('password')
            <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div>
            @enderror
        </div>

        <div class="form-group" style="display:flex; align-items:center; gap:8px; margin-bottom: 24px;">
            <input type="checkbox" name="remember" id="remember" style="accent-color: #6366f1;">
            <label for="remember" style="font-size:13px; color:#64748b; cursor:pointer;">
                {{ __('front.auth.remember_me') }}
            </label>
        </div>

        <input type="hidden" name="fingerprint_hash" id="fingerprint_hash">

        <button type="submit" class="btn-auth">
            <i class="fa fa-right-to-bracket"></i>
            {{ __('front.auth.login_btn') }}
        </button>
    </form>

    <script>
    (async function() {
        try {
            const raw = navigator.userAgent + '|' + screen.width + 'x' + screen.height + '|' +
                Intl.DateTimeFormat().resolvedOptions().timeZone + '|' + navigator.language;
            const encoder = new TextEncoder();
            const data = encoder.encode(raw);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
            document.getElementById('fingerprint_hash').value = hashHex;
        } catch(e) {}
    })();
    </script>

    <div class="auth-link-row">
        {{ __('front.auth.no_account') }} <a href="{{ route('register') }}">{{ __('front.auth.register_title') }}</a>
    </div>
</div>
@endsection
