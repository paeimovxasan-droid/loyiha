                            @extends('front.layouts.app')
@section('title', 'KYC Tasdiqlash')
@section('content')

<div class="page-title">🪪 KYC Tasdiqlash</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

{{-- Holat kartasi --}}
<div class="card" style="margin-bottom:20px; padding:20px;">
    <div style="display:flex; align-items:center; gap:14px;">
        <div style="width:52px; height:52px; border-radius:16px; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-size:24px;
            background:{{ match($user->kyc_status) {
                'verified'      => 'rgba(16,185,129,.15)',
                'pending'       => 'rgba(245,158,11,.15)',
                'video_pending' => 'rgba(245,158,11,.15)',
                'rejected'      => 'rgba(239,68,68,.15)',
                default         => 'rgba(100,116,139,.15)',
            } }};">
            {{ match($user->kyc_status) {
                'verified'      => '✅',
                'pending'       => '⏳',
                'video_pending' => '🎥',
                'rejected'      => '❌',
                default         => '🪪',
            } }}
        </div>
        <div>
            <div style="font-size:15px; font-weight:700; color:#f1f5f9;">
                @if($user->kyc_status === 'verified') Tasdiqlangan
                @elseif($user->kyc_status === 'pending') Ko'rib chiqilmoqda
                @elseif($user->kyc_status === 'video_pending') Video ko'rib chiqilmoqda
                @elseif($user->kyc_status === 'rejected') Rad etildi
                @else Tasdiqlanmagan
                @endif
            </div>
            <div style="font-size:12px; color:var(--gray); margin-top:2px;">
                @if($user->kyc_status === 'verified')
                    {{ $user->kyc_verified_at ? \Carbon\Carbon::parse($user->kyc_verified_at)->format('d.m.Y') : '' }} da tasdiqlandi
                @elseif($user->kyc_status === 'pending')
                    24 soat ichida ko'rib chiqiladi
                @elseif($user->kyc_status === 'video_pending')
                    24 soat ichida natija bildiriladi
                @elseif($user->kyc_status === 'rejected')
                    Qaytadan yuborishingiz mumkin
                @else
                    Hujjat yuklanmagan
                @endif
            </div>
        </div>
        @if($user->kyc_status === 'verified')
        <div style="margin-left:auto;">
            <span class="badge badge-success"><i class="fa fa-shield-halved"></i> Verified</span>
        </div>
        @endif
    </div>
</div>

{{-- KYC afzalliklari --}}
<div class="card" style="margin-bottom:20px; padding:18px;">
    <div style="font-size:13px; font-weight:600; color:#94a3b8; text-transform:uppercase; letter-spacing:.4px; margin-bottom:12px;">
        KYC tasdiqlash afzalliklari
    </div>
    <div style="display:flex; flex-direction:column; gap:8px;">
        @foreach([
            ['+500 XP', 'Bir martalik bonus', '#818cf8'],
            ['Limit oshadi', 'Yechish limiti 2x oshadi', '#34d399'],
            ['Ishonch belgisi', 'Profilingizda ✅ belgisi', '#fbbf24'],
            ['Xavfsizlik', 'Hisobingiz himoyalangan', '#06b6d4'],
        ] as [$title, $desc, $color])
        <div style="display:flex; align-items:center; gap:10px;">
            <div style="width:8px; height:8px; border-radius:50%; background:{{ $color }}; flex-shrink:0;"></div>
            <div>
                <span style="font-size:13px; font-weight:600; color:{{ $color }};">{{ $title }}</span>
                <span style="font-size:12px; color:var(--gray); margin-left:6px;">— {{ $desc }}</span>
            </div>
        </div>
        @endforeach
    </div>
</div>

{{-- Yuklash formasi --}}
@if(!in_array($user->kyc_status, ['pending', 'video_pending', 'verified']))
<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fa fa-upload"></i> Hujjat yuklash</span>
    </div>
    <div class="card-body">
        <div class="alert alert-info" style="margin-bottom:16px;">
            <i class="fa fa-info-circle"></i>
            <div style="font-size:12px;">
                Passport yoki ID kartangizning <strong>aniq</strong> rasmini yuklang.
                Rasm 5MB dan oshmasin. Qabul qilinadigan formatlar: JPG, PNG, WEBP.
            </div>
        </div>

        <form method="POST" action="{{ route('app.kyc.submit') }}" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label class="form-label">Hujjat rasmi</label>
                <div id="kycPicker"
                     onclick="document.getElementById('kycInput').click()"
                     style="border:2px dashed rgba(99,102,241,.4); border-radius:16px; padding:24px;
                            text-align:center; cursor:pointer; background:rgba(99,102,241,.05); transition:all .2s;"
                     onmouseenter="this.style.borderColor='rgba(99,102,241,.8)'"
                     onmouseleave="this.style.borderColor='rgba(99,102,241,.4)'">
                    <div id="kycDefault">
                        <i class="fa fa-id-card" style="font-size:32px; color:#818cf8; display:block; margin-bottom:10px;"></i>
                        <div style="font-size:14px; font-weight:600; color:#c7d2fe;">Rasm tanlash</div>
                        <div style="font-size:12px; color:var(--gray); margin-top:4px;">JPG, PNG, WEBP — max 5MB</div>
                    </div>
                    <div id="kycPreview" style="display:none;">
                        <img id="kycImg" src="" style="max-width:100%; max-height:200px; border-radius:10px; object-fit:contain;">
                        <div style="font-size:12px; color:#818cf8; margin-top:8px;" id="kycName"></div>
                    </div>
                </div>
                <input type="file" id="kycInput" name="document" accept="image/*"
                       style="display:none;" onchange="previewKyc(this)">
                @error('document')
                <div class="invalid-feedback" style="display:block;"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div>
                @enderror
            </div>

            <button type="submit" class="btn btn-primary btn-full btn-lg">
                <i class="fa fa-paper-plane"></i> Yuborish
            </button>
        </form>
    </div>
</div>
@endif

{{-- Video KYC section --}}
@if(!in_array($user->kyc_status, ['pending', 'video_pending', 'verified']))
<div class="card" style="margin-top:16px;">
    <div class="card-header">
        <span class="card-title"><i class="fa fa-video"></i> Video KYC (Tezkor)</span>
    </div>
    <div class="card-body">
        <div class="alert alert-info" style="margin-bottom:16px;">
            <i class="fa fa-info-circle"></i>
            <div style="font-size:12px;">
                Tasodifiy kodni o'qib beruvchi qisqa video yuboring. Tezroq tasdiqlanadi.
            </div>
        </div>

        <div id="videoCodeSection" style="display:none;">
            <div style="background:rgba(99,102,241,.1); border-radius:12px; padding:16px; text-align:center; margin-bottom:16px;">
                <div style="font-size:12px; color:#94a3b8; margin-bottom:6px;">Videoda o'qib bering:</div>
                <div id="videoCodeDisplay" style="font-size:32px; font-weight:800; color:#818cf8; letter-spacing:8px;"></div>
                <div id="videoCodeExpiry" style="font-size:11px; color:#64748b; margin-top:6px;"></div>
            </div>

            <form method="POST" action="{{ route('app.kyc.video') }}" enctype="multipart/form-data">
                @csrf
                <div class="form-group">
                    <label class="form-label">Video fayl (MP4, MOV, WEBM — max 50MB)</label>
                    <input type="file" name="video" class="form-control" accept="video/mp4,video/quicktime,video/webm" required>
                    @error('video')
                    <div class="invalid-feedback" style="display:block;">{{ $message }}</div>
                    @enderror
                </div>
                <button type="submit" class="btn btn-primary btn-full">
                    <i class="fa fa-paper-plane"></i> Video yuborish
                </button>
            </form>
        </div>

        <button type="button" id="getVideoCodeBtn" class="btn btn-outline btn-full" onclick="getVideoCode()">
            <i class="fa fa-key"></i> Kod olish va video yuborish
        </button>
    </div>
</div>
@endif

@if($user->kyc_status === 'video_pending')
<div class="card" style="margin-top:16px;">
    <div class="card-body" style="text-align:center; padding:24px;">
        <div style="font-size:32px; margin-bottom:12px;">🎥</div>
        <div style="font-size:15px; font-weight:700; color:#f1f5f9;">Video ko'rib chiqilmoqda</div>
        <div style="font-size:12px; color:#94a3b8; margin-top:6px;">24 soat ichida natija bildiriladi</div>
    </div>
</div>
@endif

@endsection

@section('scripts')
<script>
function previewKyc(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
        document.getElementById('kycImg').src = e.target.result;
        document.getElementById('kycName').textContent = file.name;
        document.getElementById('kycDefault').style.display = 'none';
        document.getElementById('kycPreview').style.display = 'block';
        document.getElementById('kycPicker').style.borderColor = 'rgba(16,185,129,.6)';
    };
    reader.readAsDataURL(file);
}

async function getVideoCode() {
    const btn = document.getElementById('getVideoCodeBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Yuklanmoqda...';

    try {
        const response = await fetch('{{ route("app.kyc.video-code") }}', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json',
            }
        });
        const data = await response.json();

        if (data.error) {
            alert(data.error);
            btn.disabled = false;
            btn.innerHTML = '<i class="fa fa-key"></i> Kod olish va video yuborish';
            return;
        }

        document.getElementById('videoCodeDisplay').textContent = data.code;
        const expiry = new Date(data.expires_at);
        document.getElementById('videoCodeExpiry').textContent = '30 daqiqa ichida yuborish kerak';
        document.getElementById('videoCodeSection').style.display = 'block';
        btn.style.display = 'none';
    } catch (e) {
        alert('Xato yuz berdi. Qaytadan urinib ko\'ring.');
        btn.disabled = false;
        btn.innerHTML = '<i class="fa fa-key"></i> Kod olish va video yuborish';
    }
}
</script>
@endsection
