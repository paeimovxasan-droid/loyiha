<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Kirish') — {{ $setting->getTranslation('site_name', app()->getLocale()) }}</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="icon" href="{{ $setting->favicon_url }}">

    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
            overflow-x: hidden;
            overflow-y: auto;
            padding: 20px 0;
        }

        /* Background glows */
        body::before, body::after {
            content: '';
            position: fixed;
            border-radius: 50%;
            filter: blur(80px);
            z-index: 0;
        }
        body::before {
            width: 500px; height: 500px;
            background: rgba(99, 102, 241, 0.15);
            top: -150px; left: -100px;
        }
        body::after {
            width: 400px; height: 400px;
            background: rgba(139, 92, 246, 0.12);
            bottom: -100px; right: -50px;
        }

        .auth-container {
            width: 100%; max-width: 440px;
            position: relative; z-index: 1;
            padding: 20px;
        }

        .auth-logo {
            text-align: center;
            margin-bottom: 32px;
        }

        .auth-logo img {
            width: 60px; height: 60px;
            border-radius: 16px;
            object-fit: contain;
            margin-bottom: 12px;
        }

        .auth-logo h1 {
            font-size: 22px;
            font-weight: 700;
            color: #f1f5f9;
        }

        .auth-logo p {
            font-size: 14px;
            color: #64748b;
            margin-top: 4px;
        }

        .auth-card {
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 20px;
            padding: 32px;
        }

        .auth-title {
            font-size: 20px;
            font-weight: 700;
            color: #f1f5f9;
            margin-bottom: 6px;
        }

        .auth-subtitle {
            font-size: 13px;
            color: #64748b;
            margin-bottom: 28px;
        }

        .form-group { margin-bottom: 18px; }

        .form-label {
            display: block;
            font-size: 13px;
            font-weight: 500;
            color: #94a3b8;
            margin-bottom: 8px;
        }

        .input-wrap { position: relative; }

        .input-icon {
            position: absolute;
            left: 14px; top: 50%;
            transform: translateY(-50%);
            color: #475569;
            font-size: 15px;
            transition: color .2s;
        }

        .form-control {
            width: 100%;
            background: #0f172a;
            border: 1px solid #334155;
            border-radius: 12px;
            padding: 13px 16px 13px 44px;
            color: #e2e8f0;
            font-size: 14px;
            font-family: inherit;
            outline: none;
            transition: border-color .2s, box-shadow .2s;
        }

        .form-control:focus {
            border-color: #6366f1;
            box-shadow: 0 0 0 3px rgba(99, 102, 241, .15);
        }

        .form-control.is-invalid { border-color: #ef4444; }
        .form-control::placeholder { color: #475569; }

        .invalid-feedback {
            font-size: 12px;
            color: #f87171;
            margin-top: 6px;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .btn-auth {
            width: 100%;
            padding: 14px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: all .2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 4px 15px rgba(99, 102, 241, .35);
            font-family: inherit;
        }

        .btn-auth:hover {
            transform: translateY(-1px);
            box-shadow: 0 6px 20px rgba(99, 102, 241, .45);
        }

        .auth-divider {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 20px 0;
            color: #475569;
            font-size: 13px;
        }

        .auth-divider::before,
        .auth-divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: #334155;
        }

        .auth-link-row {
            text-align: center;
            font-size: 13px;
            color: #64748b;
            margin-top: 20px;
        }

        .auth-link-row a {
            color: #818cf8;
            text-decoration: none;
            font-weight: 600;
        }

        .auth-link-row a:hover { color: #a5b4fc; }

        .alert-danger {
            background: rgba(239,68,68,.12);
            border: 1px solid rgba(239,68,68,.3);
            color: #f87171;
            border-radius: 12px;
            padding: 12px 16px;
            font-size: 13px;
            margin-bottom: 18px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .alert-success {
            background: rgba(16,185,129,.12);
            border: 1px solid rgba(16,185,129,.3);
            color: #34d399;
            border-radius: 12px;
            padding: 12px 16px;
            font-size: 13px;
            margin-bottom: 18px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .ref-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(16,185,129,.1);
            border: 1px solid rgba(16,185,129,.2);
            color: #34d399;
            padding: 8px 14px;
            border-radius: 8px;
            font-size: 13px;
            margin-bottom: 20px;
        }

        /* ─── Language Switcher ─── */
        .lang-switcher {
            position: absolute;
            top: 20px;
            right: 20px;
            z-index: 10;
        }

        .lang-btn {
            display: flex;
            align-items: center;
            gap: 6px;
            background: rgba(255,255,255,.05);
            border: 1px solid rgba(255,255,255,.1);
            border-radius: 10px;
            padding: 8px 14px;
            color: #94a3b8;
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: all .2s;
            backdrop-filter: blur(10px);
        }

        .lang-btn:hover {
            background: rgba(255,255,255,.1);
            color: #e2e8f0;
        }

        .lang-btn i { font-size: 10px; transition: transform .2s; }
        .lang-switcher.open .lang-btn i { transform: rotate(180deg); }

        .lang-dropdown {
            position: absolute;
            top: calc(100% + 8px);
            right: 0;
            background: #1e293b;
            border: 1px solid rgba(255,255,255,.1);
            border-radius: 12px;
            padding: 6px;
            min-width: 150px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-8px);
            transition: all .2s;
            box-shadow: 0 10px 40px rgba(0,0,0,.5);
        }

        .lang-switcher.open .lang-dropdown {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .lang-option {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 8px;
            color: #94a3b8;
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            transition: all .15s;
        }

        .lang-option:hover {
            background: rgba(99,102,241,.1);
            color: #e2e8f0;
        }

        .lang-option.active {
            background: rgba(99,102,241,.15);
            color: #818cf8;
        }
    </style>
</head>
<body>
@php
    $currentLang = app()->getLocale();
    $languages = [
        'uz' => ['name' => "O'zbekcha", 'flag' => '🇺🇿'],
        'ru' => ['name' => 'Русский', 'flag' => '🇷🇺'],
        'en' => ['name' => 'English', 'flag' => '🇬🇧'],
    ];
@endphp

{{-- Language Switcher --}}
<div class="lang-switcher" id="langSwitcher">
    <button type="button" class="lang-btn" onclick="toggleLangDropdown()">
        <span style="font-size:16px;">{{ $languages[$currentLang]['flag'] }}</span>
        <span>{{ strtoupper($currentLang) }}</span>
        <i class="fa fa-chevron-down"></i>
    </button>
    <div class="lang-dropdown">
        @foreach($languages as $code => $lang)
        <a href="{{ request()->fullUrlWithQuery(['lang' => $code]) }}"
           class="lang-option {{ $currentLang === $code ? 'active' : '' }}">
            <span style="font-size:18px;">{{ $lang['flag'] }}</span>
            <span>{{ $lang['name'] }}</span>
            @if($currentLang === $code)
            <i class="fa fa-check" style="margin-left:auto; font-size:11px;"></i>
            @endif
        </a>
        @endforeach
    </div>
</div>

<div class="auth-container">
    <div class="auth-logo">
        <img src="{{ $setting->logo_url }}" alt="Logo">
        <h1>{{ $setting->getTranslation('site_name', app()->getLocale()) }}</h1>
        <p>{{ __('front.auth.platform_subtitle') }}</p>
    </div>

    @yield('content')
</div>

<script>
    // Language switcher
    function toggleLangDropdown() {
        document.getElementById('langSwitcher').classList.toggle('open');
    }

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        const switcher = document.getElementById('langSwitcher');
        if (switcher && !switcher.contains(e.target)) {
            switcher.classList.remove('open');
        }
    });
</script>
</body>
</html>
