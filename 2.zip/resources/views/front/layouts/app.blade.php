<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'AISOQQA') — {{ $setting->getTranslation('site_name', app()->getLocale()) }}</title>

    {{-- PWA Meta --}}
    <meta name="application-name" content="{{ $setting->getTranslation('site_name', app()->getLocale()) }}">
    <meta name="description" content="{{ $setting->getTranslation('site_description', app()->getLocale()) ?? 'Investitsiya va moliyaviy platforma' }}">
    <meta name="theme-color" content="#0f172a">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
    <meta name="apple-mobile-web-app-title" content="{{ $setting->getTranslation('site_name', app()->getLocale()) }}">
    <meta name="msapplication-TileColor" content="#6366f1">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="format-detection" content="telephone=no">

    {{-- PWA Manifest --}}
    <link rel="manifest" href="{{ route('pwa.manifest') }}">

    {{-- Apple Touch Icons --}}
    <link rel="apple-touch-icon" href="/images/pwa/icon-192.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/images/pwa/icon-152.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/images/pwa/icon-144.png">
    <link rel="apple-touch-icon" sizes="128x128" href="/images/pwa/icon-128.png">

    {{-- Favicon --}}
    <link rel="icon" type="image/png" sizes="32x32" href="/images/pwa/icon-96.png">
    <link rel="icon" href="{{ $setting->favicon_url }}">

    {{-- Open Graph --}}
    <meta property="og:type" content="website">
    <meta property="og:title" content="{{ $setting->getTranslation('site_name', app()->getLocale()) }}">
    <meta property="og:description" content="{{ $setting->getTranslation('site_description', app()->getLocale()) ?? 'Investitsiya va moliyaviy platforma' }}">
    <meta property="og:image" content="/images/pwa/icon-512.png">
    <meta property="og:url" content="{{ url()->current() }}">

    {{-- Fonts & Icons --}}
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    @vite(['resources/css/app.css', 'resources/js/app.js'])

    <style>
        :root {
            --primary: #6366f1;
            --primary-light: #818cf8;
            --primary-dark: #4f46e5;
            --secondary: #8b5cf6;
            --accent: #06b6d4;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --bg-primary: #0a0e1a;
            --bg-secondary: #111827;
            --bg-card: #1a1f2e;
            --bg-card-hover: #1f2537;
            --bg-elevated: #242938;
            --border-primary: rgba(255,255,255,.06);
            --border-hover: rgba(99,102,241,.3);
            --text-primary: #f1f5f9;
            --text-secondary: #94a3b8;
            --text-muted: #64748b;
            --glass-bg: rgba(17, 24, 39, 0.7);
            --glass-border: rgba(255,255,255,.08);
            --nav-height: 72px;
            --header-height: 60px;
            --radius-sm: 10px;
            --radius-md: 14px;
            --radius-lg: 20px;
            --radius-xl: 24px;
            --shadow-sm: 0 2px 8px rgba(0,0,0,.2);
            --shadow-md: 0 8px 24px rgba(0,0,0,.3);
            --shadow-lg: 0 16px 48px rgba(0,0,0,.4);
            --shadow-glow: 0 0 20px rgba(99,102,241,.15);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            min-height: 100vh;
            min-height: 100dvh;
            padding-bottom: calc(var(--nav-height) + env(safe-area-inset-bottom, 0px));
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
            overflow-x: hidden;
        }

        /* Scrollbar */
        ::-webkit-scrollbar { width: 3px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--primary); border-radius: 10px; }

        /* ═══════════════════════════════════════════════════════════
           HEADER
        ═══════════════════════════════════════════════════════════ */
        .app-header {
            position: sticky;
            top: 0;
            z-index: 100;
            height: var(--header-height);
            background: var(--glass-bg);
            backdrop-filter: blur(20px) saturate(1.2);
            -webkit-backdrop-filter: blur(20px) saturate(1.2);
            border-bottom: 1px solid var(--glass-border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 16px;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .header-logo {
            display: flex;
            align-items: center;
            gap: 8px;
            text-decoration: none;
        }

        .header-logo img {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            object-fit: contain;
        }

        .header-logo-text {
            font-size: 15px;
            font-weight: 700;
            color: var(--text-primary);
            letter-spacing: -.3px;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* Balance Chip */
        .balance-chip {
            display: flex;
            align-items: center;
            gap: 6px;
            background: linear-gradient(135deg, rgba(99,102,241,.12), rgba(139,92,246,.08));
            border: 1px solid rgba(99,102,241,.2);
            border-radius: var(--radius-sm);
            padding: 7px 12px;
            font-size: 13px;
            font-weight: 600;
            color: var(--primary-light);
            transition: all .2s;
        }

        .balance-chip:hover {
            border-color: rgba(99,102,241,.4);
            background: linear-gradient(135deg, rgba(99,102,241,.18), rgba(139,92,246,.12));
        }

        .balance-chip i { font-size: 11px; opacity: .7; }

        /* Language Switcher */
        .lang-switcher { position: relative; }

        .lang-btn {
            display: flex;
            align-items: center;
            gap: 5px;
            background: rgba(255,255,255,.04);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-sm);
            padding: 7px 10px;
            color: var(--text-secondary);
            font-size: 12px;
            font-weight: 500;
            cursor: pointer;
            transition: all .2s;
        }

        .lang-btn:hover { background: rgba(255,255,255,.07); color: var(--text-primary); }
        .lang-btn i { font-size: 9px; transition: transform .2s; }
        .lang-switcher.open .lang-btn i { transform: rotate(180deg); }

        .lang-dropdown {
            position: absolute;
            top: calc(100% + 6px);
            right: 0;
            background: var(--bg-card);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-md);
            padding: 4px;
            min-width: 130px;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-6px) scale(.96);
            transition: all .2s cubic-bezier(.4,0,.2,1);
            z-index: 1000;
            box-shadow: var(--shadow-lg);
        }

        .lang-switcher.open .lang-dropdown {
            opacity: 1;
            visibility: visible;
            transform: translateY(0) scale(1);
        }

        .lang-option {
            display: flex;
            align-items: center;
            gap: 8px;
            padding: 8px 10px;
            border-radius: 8px;
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 12px;
            font-weight: 500;
            transition: all .15s;
        }

        .lang-option:hover { background: rgba(99,102,241,.08); color: var(--text-primary); }
        .lang-option.active { background: rgba(99,102,241,.12); color: var(--primary-light); }

        /* Avatar */
        .avatar-btn {
            width: 34px;
            height: 34px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            border: 2px solid rgba(99,102,241,.3);
            cursor: pointer;
            text-decoration: none;
            display: block;
            transition: all .2s;
            flex-shrink: 0;
        }

        .avatar-btn:hover { border-color: var(--primary); box-shadow: var(--shadow-glow); }
        .avatar-btn img { width: 100%; height: 100%; object-fit: cover; }

        /* PWA Install */
        .pwa-install-btn {
            width: 34px;
            height: 34px;
            border-radius: var(--radius-sm);
            background: rgba(99,102,241,.1);
            border: 1px solid rgba(99,102,241,.25);
            color: var(--primary-light);
            cursor: pointer;
            font-size: 13px;
            display: none;
            align-items: center;
            justify-content: center;
            transition: all .2s;
        }

        .pwa-install-btn:hover {
            background: rgba(99,102,241,.2);
            border-color: rgba(99,102,241,.5);
            transform: translateY(-1px);
        }

        /* ═══════════════════════════════════════════════════════════
           PAGE CONTENT
        ═══════════════════════════════════════════════════════════ */
        .page-content {
            max-width: 640px;
            margin: 0 auto;
            padding: 16px;
            animation: fadeInUp .3s ease;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(8px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ═══════════════════════════════════════════════════════════
           BOTTOM NAVIGATION
        ═══════════════════════════════════════════════════════════ */
        .bottom-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 200;
            height: var(--nav-height);
            background: rgba(10, 14, 26, 0.92);
            backdrop-filter: blur(24px) saturate(1.3);
            -webkit-backdrop-filter: blur(24px) saturate(1.3);
            border-top: 1px solid rgba(255,255,255,.05);
            display: flex;
            align-items: center;
            justify-content: space-around;
            padding: 0 8px;
            padding-bottom: env(safe-area-inset-bottom, 0px);
        }

        .nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 3px;
            padding: 6px 12px;
            border-radius: var(--radius-md);
            text-decoration: none;
            color: var(--text-muted);
            font-size: 10px;
            font-weight: 600;
            letter-spacing: .2px;
            transition: all .2s ease;
            position: relative;
            min-width: 56px;
        }

        .nav-item i { font-size: 19px; transition: all .2s; }
        .nav-item:hover { color: var(--text-secondary); }

        .nav-item.active {
            color: var(--primary-light);
        }

        .nav-item.active i {
            filter: drop-shadow(0 0 6px rgba(99,102,241,.5));
            transform: translateY(-1px);
        }

        .nav-item.active::after {
            content: '';
            position: absolute;
            bottom: 0;
            width: 20px;
            height: 2.5px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            border-radius: 2px;
        }

        /* Center Button */
        .nav-center-btn {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 3px;
            text-decoration: none;
            color: #fff;
            font-size: 10px;
            font-weight: 600;
        }

        .nav-center-btn .center-circle {
            width: 48px;
            height: 48px;
            border-radius: 16px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 16px rgba(99,102,241,.4), inset 0 1px 0 rgba(255,255,255,.15);
            transition: all .25s cubic-bezier(.4,0,.2,1);
            margin-top: -14px;
        }

        .nav-center-btn:hover .center-circle {
            transform: translateY(-2px) scale(1.03);
            box-shadow: 0 8px 24px rgba(99,102,241,.5), inset 0 1px 0 rgba(255,255,255,.2);
        }

        .nav-center-btn:active .center-circle {
            transform: translateY(0) scale(.97);
        }

        .nav-center-btn i { font-size: 18px; }
        .nav-center-label { color: var(--primary-light); margin-top: 1px; }

        /* ═══════════════════════════════════════════════════════════
           CARDS & COMPONENTS
        ═══════════════════════════════════════════════════════════ */
        .card {
            background: var(--bg-card);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-lg);
            overflow: hidden;
            transition: all .2s;
        }

        .card:hover {
            border-color: rgba(255,255,255,.08);
            box-shadow: var(--shadow-sm);
        }

        .card-header {
            padding: 16px 18px;
            border-bottom: 1px solid var(--border-primary);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .card-title {
            font-size: 14px;
            font-weight: 600;
            color: var(--text-primary);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .card-title i { color: var(--primary-light); font-size: 13px; }
        .card-body { padding: 18px; }

        /* Stat Cards */
        .stat-card {
            background: var(--bg-card);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-lg);
            padding: 16px;
            position: relative;
            overflow: hidden;
            transition: all .25s;
        }

        .stat-card:hover {
            border-color: var(--border-hover);
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, var(--stat-color, var(--primary)), transparent);
            opacity: 0;
            transition: opacity .2s;
        }

        .stat-card:hover::before { opacity: 1; }

        .stat-icon {
            width: 38px;
            height: 38px;
            border-radius: var(--radius-sm);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 15px;
            margin-bottom: 10px;
        }

        .stat-value {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            margin-bottom: 2px;
            letter-spacing: -.4px;
        }

        .stat-label {
            font-size: 11px;
            color: var(--text-muted);
            font-weight: 500;
        }

        /* ═══════════════════════════════════════════════════════════
           BUTTONS
        ═══════════════════════════════════════════════════════════ */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            padding: 10px 18px;
            border-radius: var(--radius-sm);
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: all .2s cubic-bezier(.4,0,.2,1);
            text-decoration: none;
            font-family: inherit;
            line-height: 1;
        }

        .btn:active { transform: scale(.97); }

        .btn-primary {
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: #fff;
            box-shadow: 0 4px 12px rgba(99,102,241,.3), inset 0 1px 0 rgba(255,255,255,.1);
        }

        .btn-primary:hover {
            box-shadow: 0 6px 20px rgba(99,102,241,.4), inset 0 1px 0 rgba(255,255,255,.15);
            transform: translateY(-1px);
        }

        .btn-outline {
            background: transparent;
            border: 1px solid var(--border-primary);
            color: var(--text-secondary);
        }

        .btn-outline:hover {
            background: rgba(255,255,255,.04);
            border-color: rgba(255,255,255,.12);
            color: var(--text-primary);
        }

        .btn-ghost {
            background: rgba(255,255,255,.04);
            color: var(--text-secondary);
            border: none;
        }

        .btn-ghost:hover { background: rgba(255,255,255,.08); color: var(--text-primary); }

        .btn-success { background: linear-gradient(135deg, #10b981, #059669); color: #fff; box-shadow: 0 4px 12px rgba(16,185,129,.3); }
        .btn-danger { background: linear-gradient(135deg, #ef4444, #dc2626); color: #fff; box-shadow: 0 4px 12px rgba(239,68,68,.3); }
        .btn-warning { background: linear-gradient(135deg, #f59e0b, #d97706); color: #fff; box-shadow: 0 4px 12px rgba(245,158,11,.3); }

        .btn-sm { padding: 7px 12px; font-size: 12px; border-radius: 8px; }
        .btn-lg { padding: 14px 24px; font-size: 15px; border-radius: var(--radius-md); }
        .btn-full { width: 100%; }
        .btn-icon { width: 36px; height: 36px; padding: 0; }

        /* ═══════════════════════════════════════════════════════════
           FORMS
        ═══════════════════════════════════════════════════════════ */
        .form-group { margin-bottom: 16px; }

        .form-label {
            display: block;
            font-size: 12px;
            font-weight: 600;
            color: var(--text-secondary);
            margin-bottom: 6px;
            letter-spacing: .3px;
        }

        .form-control {
            width: 100%;
            background: rgba(255,255,255,.03);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-sm);
            padding: 11px 14px;
            color: var(--text-primary);
            font-size: 14px;
            font-family: inherit;
            outline: none;
            transition: all .2s;
        }

        .form-control:focus {
            border-color: rgba(99,102,241,.5);
            background: rgba(99,102,241,.03);
            box-shadow: 0 0 0 3px rgba(99,102,241,.08);
        }

        .form-control::placeholder { color: var(--text-muted); }
        .form-control.is-invalid { border-color: rgba(239,68,68,.5); }
        .invalid-feedback { font-size: 12px; color: #f87171; margin-top: 4px; display: flex; align-items: center; gap: 4px; }

        select.form-control {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%2394a3b8' d='M6 8L1 3h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            padding-right: 32px;
        }

        /* ═══════════════════════════════════════════════════════════
           ALERTS & BADGES
        ═══════════════════════════════════════════════════════════ */
        .alert {
            padding: 12px 14px;
            border-radius: var(--radius-md);
            font-size: 13px;
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 14px;
            font-weight: 500;
        }

        .alert-success { background: rgba(16,185,129,.08); border: 1px solid rgba(16,185,129,.15); color: #34d399; }
        .alert-danger { background: rgba(239,68,68,.08); border: 1px solid rgba(239,68,68,.15); color: #f87171; }
        .alert-info { background: rgba(6,182,212,.08); border: 1px solid rgba(6,182,212,.15); color: #22d3ee; }
        .alert-warning { background: rgba(245,158,11,.08); border: 1px solid rgba(245,158,11,.15); color: #fbbf24; }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 3px 8px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: 600;
        }

        .badge-success { background: rgba(16,185,129,.12); color: #34d399; }
        .badge-danger { background: rgba(239,68,68,.12); color: #f87171; }
        .badge-warning { background: rgba(245,158,11,.12); color: #fbbf24; }
        .badge-info { background: rgba(6,182,212,.12); color: #22d3ee; }
        .badge-primary { background: rgba(99,102,241,.12); color: #a5b4fc; }
        .badge-gray { background: rgba(100,116,139,.12); color: #94a3b8; }

        /* ═══════════════════════════════════════════════════════════
           UTILITIES
        ═══════════════════════════════════════════════════════════ */
        .progress {
            height: 4px;
            background: rgba(255,255,255,.06);
            border-radius: 10px;
            overflow: hidden;
        }

        .progress-bar {
            height: 100%;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            border-radius: 10px;
            transition: width .5s cubic-bezier(.4,0,.2,1);
        }

        .divider { height: 1px; background: var(--border-primary); margin: 14px 0; }

        .grid { display: grid; gap: 12px; }
        .grid-2 { grid-template-columns: repeat(2, 1fr); }
        .grid-3 { grid-template-columns: repeat(3, 1fr); }
        .grid-4 { grid-template-columns: repeat(4, 1fr); }

        @media (max-width: 420px) {
            .grid-3 { grid-template-columns: repeat(2, 1fr); }
            .grid-4 { grid-template-columns: repeat(2, 1fr); }
        }

        .page-title {
            font-size: 20px;
            font-weight: 700;
            color: var(--text-primary);
            letter-spacing: -.4px;
            margin-bottom: 16px;
        }

        .section-label {
            font-size: 11px;
            font-weight: 600;
            color: var(--text-muted);
            text-transform: uppercase;
            letter-spacing: .6px;
            margin-bottom: 10px;
        }

        .list-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-primary);
            transition: background .15s;
        }

        .list-item:last-child { border-bottom: none; }
        .list-item:hover { background: rgba(255,255,255,.02); }

        /* Package Card */
        .package-card {
            background: var(--bg-card);
            border: 1px solid var(--border-primary);
            border-radius: var(--radius-lg);
            overflow: hidden;
            transition: all .25s;
        }

        .package-card:hover {
            transform: translateY(-3px);
            border-color: var(--border-hover);
            box-shadow: var(--shadow-md), var(--shadow-glow);
        }

        .package-card img { width: 100%; height: 130px; object-fit: cover; }
        .package-card-body { padding: 14px; }
        .package-name { font-size: 14px; font-weight: 700; color: var(--text-primary); margin-bottom: 6px; }
        .package-price { font-size: 20px; font-weight: 800; color: var(--primary-light); letter-spacing: -.4px; }

        .package-meta { display: flex; flex-direction: column; gap: 4px; margin: 8px 0 12px; }
        .package-meta-row { display: flex; justify-content: space-between; font-size: 12px; color: var(--text-muted); }
        .package-meta-row span:last-child { color: var(--text-secondary); font-weight: 500; }

        /* ═══════════════════════════════════════════════════════════
           TOAST NOTIFICATIONS
        ═══════════════════════════════════════════════════════════ */
        .toast-container {
            position: fixed;
            top: calc(var(--header-height) + 12px);
            right: 16px;
            z-index: 9999;
            display: flex;
            flex-direction: column;
            gap: 8px;
            pointer-events: none;
        }

        .toast {
            min-width: 260px;
            max-width: 340px;
            padding: 12px 14px;
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
            font-weight: 500;
            animation: toastSlideIn .3s cubic-bezier(.34,1.56,.64,1);
            box-shadow: var(--shadow-lg);
            pointer-events: auto;
        }

        .toast-success { background: rgba(6,78,59,.95); border: 1px solid rgba(16,185,129,.25); color: #6ee7b7; }
        .toast-danger { background: rgba(127,29,29,.95); border: 1px solid rgba(239,68,68,.25); color: #fca5a5; }
        .toast-info { background: rgba(12,74,110,.95); border: 1px solid rgba(6,182,212,.25); color: #7dd3fc; }

        @keyframes toastSlideIn {
            from { opacity: 0; transform: translateX(20px) scale(.95); }
            to { opacity: 1; transform: translateX(0) scale(1); }
        }

        /* ═══════════════════════════════════════════════════════════
           CONFIRM MODAL
        ═══════════════════════════════════════════════════════════ */
        .confirm-overlay {
            position: fixed;
            inset: 0;
            background: rgba(10, 14, 26, 0.8);
            backdrop-filter: blur(6px);
            z-index: 99999;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            visibility: hidden;
            transition: all .25s;
        }

        .confirm-overlay.show { opacity: 1; visibility: visible; }

        .confirm-box {
            background: var(--bg-card);
            border: 1px solid var(--glass-border);
            border-radius: var(--radius-xl);
            padding: 24px;
            width: 90%;
            max-width: 320px;
            text-align: center;
            transform: translateY(16px) scale(.95);
            transition: all .3s cubic-bezier(.34,1.56,.64,1);
            box-shadow: var(--shadow-lg);
        }

        .confirm-overlay.show .confirm-box { transform: translateY(0) scale(1); }

        .confirm-icon {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background: rgba(245,158,11,.1);
            color: #fbbf24;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin: 0 auto 14px;
        }

        .confirm-title { font-size: 17px; font-weight: 700; color: var(--text-primary); margin-bottom: 6px; }
        .confirm-message { font-size: 13px; color: var(--text-secondary); margin-bottom: 20px; line-height: 1.5; }
        .confirm-actions { display: flex; gap: 10px; }
        .confirm-actions .btn { flex: 1; }

        /* ═══════════════════════════════════════════════════════════
           SKELETON LOADING
        ═══════════════════════════════════════════════════════════ */
        .skeleton {
            background: linear-gradient(90deg, var(--bg-card) 25%, var(--bg-elevated) 50%, var(--bg-card) 75%);
            background-size: 200% 100%;
            animation: shimmer 1.5s infinite;
            border-radius: var(--radius-sm);
        }

        @keyframes shimmer {
            0% { background-position: 200% 0; }
            100% { background-position: -200% 0; }
        }

        /* ═══════════════════════════════════════════════════════════
           EMPTY STATE
        ═══════════════════════════════════════════════════════════ */
        .empty-state {
            text-align: center;
            padding: 32px 16px;
        }

        .empty-state-icon {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background: rgba(99,102,241,.08);
            color: var(--primary-light);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin: 0 auto 12px;
        }

        .empty-state-title { font-size: 15px; font-weight: 600; color: var(--text-primary); margin-bottom: 4px; }
        .empty-state-text { font-size: 13px; color: var(--text-muted); }
    </style>

    @yield('styles')
</head>
<body>

{{-- Toast Notifications --}}
<div class="toast-container" id="toastContainer">
    @if(session('success'))
    <div class="toast toast-success">
        <i class="fa fa-check-circle"></i>
        <span>{{ session('success') }}</span>
    </div>
    @endif
    @if(session('error'))
    <div class="toast toast-danger">
        <i class="fa fa-times-circle"></i>
        <span>{{ session('error') }}</span>
    </div>
    @endif
    @if(session('info'))
    <div class="toast toast-info">
        <i class="fa fa-info-circle"></i>
        <span>{{ session('info') }}</span>
    </div>
    @endif
</div>

{{-- Header --}}
<header class="app-header">
    <div class="header-left">
        <a class="header-logo" href="{{ route('app.dashboard') }}">
            <img src="{{ $setting->logo_url }}" alt="Logo">
            <span class="header-logo-text">{{ $setting->getTranslation('site_name', app()->getLocale()) }}</span>
        </a>
    </div>

    <div class="header-right">
        @php
            $currentLang = app()->getLocale();
            $languages = [
                'uz' => ['name' => "O'zbekcha", 'flag' => '🇺🇿'],
                'ru' => ['name' => 'Русский', 'flag' => '🇷🇺'],
                'en' => ['name' => 'English', 'flag' => '🇬🇧'],
            ];
        @endphp
        <div class="lang-switcher" id="langSwitcher">
            <button type="button" class="lang-btn" onclick="toggleLangDropdown()">
                <span>{{ $languages[$currentLang]['flag'] }}</span>
                <span>{{ strtoupper($currentLang) }}</span>
                <i class="fa fa-chevron-down"></i>
            </button>
            <div class="lang-dropdown">
                @foreach($languages as $code => $lang)
                <a href="{{ request()->fullUrlWithQuery(['lang' => $code]) }}"
                   class="lang-option {{ $currentLang === $code ? 'active' : '' }}">
                    <span>{{ $lang['flag'] }}</span>
                    <span>{{ $lang['name'] }}</span>
                    @if($currentLang === $code)
                    <i class="fa fa-check" style="margin-left:auto; font-size:10px;"></i>
                    @endif
                </a>
                @endforeach
            </div>
        </div>

        <div class="balance-chip">
            <i class="fa fa-wallet"></i>
            {{ number_format(auth()->user()->balance ?? 0, 0) }}
        </div>

        <button id="pwaInstallBtn" class="pwa-install-btn" onclick="installPwa()" title="Ilovani o'rnatish">
            <i class="fa fa-download"></i>
        </button>

        <a class="avatar-btn" href="{{ route('app.profile') }}">
            <img src="{{ auth()->user()->avatar_url }}" alt="Avatar">
        </a>
    </div>
</header>

{{-- Page Content --}}
<main class="page-content">
    @yield('content')
</main>

{{-- Bottom Navigation --}}
<nav class="bottom-nav">
    <a href="{{ route('app.dashboard') }}"
       class="nav-item {{ request()->routeIs('app.dashboard') ? 'active' : '' }}">
        <i class="fa fa-house"></i>
        <span>Bosh</span>
    </a>

    <a href="{{ route('app.wallet') }}"
       class="nav-item {{ request()->routeIs('app.wallet*') ? 'active' : '' }}">
        <i class="fa fa-wallet"></i>
        <span>AIS</span>
    </a>

    <a href="{{ route('app.deposit') }}" class="nav-center-btn">
        <div class="center-circle">
            <i class="fa fa-plus"></i>
        </div>
        <span class="nav-center-label">Depozit</span>
    </a>

    <a href="{{ route('app.level') }}"
       class="nav-item {{ request()->routeIs('app.level', 'app.leaderboard') ? 'active' : '' }}">
        <i class="fa fa-bolt"></i>
        <span>Level</span>
    </a>

    <a href="{{ route('app.profile') }}"
       class="nav-item {{ request()->routeIs('app.profile*') ? 'active' : '' }}">
        <i class="fa fa-user"></i>
        <span>Profil</span>
    </a>
</nav>

{{-- Confirm Modal --}}
<div id="globalConfirmModal" class="confirm-overlay">
    <div class="confirm-box">
        <div class="confirm-icon">
            <i class="fa fa-exclamation-triangle"></i>
        </div>
        <h3 class="confirm-title">{{ __('front.common.confirm') }}</h3>
        <p class="confirm-message" id="globalConfirmMessage"></p>
        <div class="confirm-actions">
            <button type="button" class="btn btn-outline" id="globalConfirmCancel">
                {{ __('front.common.cancel') }}
            </button>
            <button type="button" class="btn btn-primary" id="globalConfirmApprove">
                {{ __('front.common.yes') }}
            </button>
        </div>
    </div>
</div>

<script>
    // Toast auto-dismiss
    setTimeout(() => {
        document.querySelectorAll('.toast').forEach(t => {
            t.style.transition = 'opacity .3s, transform .3s';
            t.style.opacity = '0';
            t.style.transform = 'translateX(16px)';
            setTimeout(() => t.remove(), 300);
        });
    }, 4000);

    // Language switcher
    function toggleLangDropdown() {
        document.getElementById('langSwitcher').classList.toggle('open');
    }

    document.addEventListener('click', function(e) {
        const switcher = document.getElementById('langSwitcher');
        if (switcher && !switcher.contains(e.target)) {
            switcher.classList.remove('open');
        }
    });

    // Confirm modal
    document.addEventListener("DOMContentLoaded", () => {
        const overlay = document.getElementById('globalConfirmModal');
        const msgEl = document.getElementById('globalConfirmMessage');
        const btnCancel = document.getElementById('globalConfirmCancel');
        const btnApprove = document.getElementById('globalConfirmApprove');
        let currentForm = null;

        window.openConfirmModal = function(message, formElement) {
            msgEl.textContent = message;
            currentForm = formElement;
            overlay.classList.add('show');
        };

        const closeModal = () => { overlay.classList.remove('show'); currentForm = null; };
        btnCancel.addEventListener('click', closeModal);
        overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
        btnApprove.addEventListener('click', () => { if (currentForm) currentForm.submit(); });
    });

    // PWA Install
    let deferredPrompt;
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        const btn = document.getElementById('pwaInstallBtn');
        if (btn) btn.style.display = 'flex';
    });

    function installPwa() {
        if (deferredPrompt) {
            deferredPrompt.prompt();
            deferredPrompt.userChoice.then(() => { deferredPrompt = null; });
        }
    }
</script>

@yield('scripts')
</body>
</html>
