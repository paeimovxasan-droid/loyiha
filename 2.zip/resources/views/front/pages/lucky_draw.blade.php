@extends('front.layouts.app')
@section('title', 'Lucky Draw')
@section('content')

<div class="page-title">🎰 Lucky Draw</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

{{-- Faol o'yinlar --}}
@forelse($draws as $draw)
@php
    $totalCollected = \App\Models\Game\LuckyDrawTicket::where('lucky_draw_id', $draw->id)->sum('total_paid');
    $rakePercent    = $draw->platform_rake_percent ?? 25;
    $winnerPrize    = round($totalCollected * (1 - $rakePercent / 100), 2);
    $ticketsSold    = $draw->getTotalTicketsSold();
    $myTicketCount  = \App\Models\Game\LuckyDrawTicket::where('lucky_draw_id', $draw->id)
                        ->where('user_id', auth()->id())->sum('quantity');
    $timeLeft       = $draw->draw_at ? now()->diff($draw->draw_at) : null;
@endphp
<div class="card" style="margin-bottom:16px; overflow:hidden;">

    {{-- Header --}}
    <div style="background:linear-gradient(135deg, rgba(168,85,247,.2), rgba(99,102,241,.15));
                padding:20px; border-bottom:1px solid rgba(255,255,255,.05);">
        <div style="display:flex; align-items:flex-start; justify-content:space-between;">
            <div>
                <div style="font-size:17px; font-weight:700; color:#f1f5f9;">
                    {{ $draw->getTranslation('name', app()->getLocale()) }}
                </div>
                @if($draw->draw_at)
                <div style="font-size:12px; color:var(--gray); margin-top:4px;">
                    <i class="fa fa-clock"></i>
                    @if($draw->draw_at->isFuture())
                        Qur'a: {{ $draw->draw_at->format('d.m.Y H:i') }}
                    @else
                        <span style="color:#f87171;">Qur'a vaqti keldi!</span>
                    @endif
                </div>
                @endif
            </div>
            <span style="background:rgba(16,185,129,.2); color:#34d399; font-size:11px;
                         padding:4px 10px; border-radius:20px; font-weight:600;">
                ● Faol
            </span>
        </div>
    </div>

    <div style="padding:16px;">
        {{-- Statistika --}}
        <div class="grid grid-3" style="gap:10px; margin-bottom:16px;">
            <div style="background:rgba(16,185,129,.08); border-radius:12px; padding:12px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#34d399;">
                    {{ number_format($winnerPrize, 0) }}
                </div>
                <div style="font-size:10px; color:var(--gray);">G'olibga (UZS)</div>
            </div>
            <div style="background:rgba(245,158,11,.08); border-radius:12px; padding:12px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#fbbf24;">
                    {{ number_format($draw->entry_fee, 0) }}
                </div>
                <div style="font-size:10px; color:var(--gray);">Chipta (UZS)</div>
            </div>
            <div style="background:rgba(99,102,241,.08); border-radius:12px; padding:12px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#818cf8;">
                    {{ $ticketsSold }}
                </div>
                <div style="font-size:10px; color:var(--gray);">Sotilgan</div>
            </div>
        </div>

        {{-- Mening chiptalarim --}}
        @if($myTicketCount > 0)
        <div style="background:rgba(99,102,241,.1); border:1px solid rgba(99,102,241,.2);
                    border-radius:12px; padding:10px 14px; margin-bottom:14px;
                    display:flex; align-items:center; gap:10px;">
            <i class="fa fa-ticket" style="color:#818cf8;"></i>
            <div>
                <div style="font-size:13px; font-weight:600; color:#a5b4fc;">
                    Sizda {{ $myTicketCount }} ta chipta bor
                </div>
                <div style="font-size:11px; color:var(--gray);">
                    Yutish ehtimoli: ~{{ $ticketsSold > 0 ? round($myTicketCount / $ticketsSold * 100, 1) : 0 }}%
                </div>
            </div>
        </div>
        @endif

        {{-- Progress bar --}}
        @if($draw->max_tickets > 0)
        @php $pct = min(100, round($ticketsSold / $draw->max_tickets * 100)); @endphp
        <div style="margin-bottom:14px;">
            <div style="display:flex; justify-content:space-between; font-size:11px; color:var(--gray); margin-bottom:5px;">
                <span>{{ number_format($ticketsSold) }} / {{ number_format($draw->max_tickets) }} chipta</span>
                <span>{{ $pct }}% to'ldi</span>
            </div>
            <div class="progress">
                <div class="progress-bar" style="width:{{ $pct }}%;"></div>
            </div>
        </div>
        @endif

        {{-- Xarid formasi --}}
        <form method="POST" action="{{ route('app.lucky_draw.buy', $draw) }}">
            @csrf
            <div style="display:flex; gap:8px;">
                <input type="number" name="quantity" value="1" min="1" max="100"
                       class="form-control" style="flex:1;" placeholder="Chipta soni">
                <button type="submit" class="btn btn-primary" style="white-space:nowrap;">
                    <i class="fa fa-ticket"></i> Xarid
                </button>
            </div>
            <div style="font-size:11px; color:var(--gray); margin-top:6px; text-align:center;">
                1 chipta = {{ number_format($draw->entry_fee, 0) }} UZS · Ko'p chipta = ko'p imkoniyat
            </div>
        </form>
    </div>
</div>
@empty
<div class="card" style="padding:50px; text-align:center; color:var(--gray);">
    <i class="fa fa-dice" style="font-size:40px; opacity:.3; display:block; margin-bottom:14px;"></i>
    Hozircha faol o'yin yo'q
</div>
@endforelse

{{-- So'nggi g'oliblar --}}
@if($recentWinners->count())
<p class="section-label" style="margin-top:24px;">🏆 So'nggi G'oliblar</p>
<div class="card">
    @foreach($recentWinners as $w)
    <div class="list-item">
        <div style="width:42px; height:42px; border-radius:12px; flex-shrink:0;
                    background:linear-gradient(135deg, rgba(245,158,11,.2), rgba(168,85,247,.2));
                    display:flex; align-items:center; justify-content:center; font-size:18px;">
            🏆
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:600; color:#f1f5f9;">
                {{ $w->winner?->name ?? 'Noma\'lum' }}
            </div>
            <div style="font-size:11px; color:var(--gray);">
                {{ $w->getTranslation('name', app()->getLocale()) }}
                · {{ $w->drawn_at?->format('d.m.Y') }}
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:14px; font-weight:700; color:#34d399;">
                +{{ number_format($w->winner_prize, 0) }}
            </div>
            <div style="font-size:10px; color:var(--gray);">UZS</div>
        </div>
    </div>
    @endforeach
</div>
@endif

{{-- Mening chiptalarim tarixi --}}
@if($myTickets->count())
<p class="section-label" style="margin-top:24px;">Mening chiptalarim</p>
<div class="card">
    @foreach($myTickets as $t)
    <div class="list-item">
        <div style="width:40px; height:40px; border-radius:12px; flex-shrink:0;
                    background:{{ $t->is_winner ? 'rgba(16,185,129,.15)' : 'rgba(245,158,11,.1)' }};
                    display:flex; align-items:center; justify-content:center;">
            <i class="fa fa-ticket" style="color:{{ $t->is_winner ? '#34d399' : '#fbbf24' }};"></i>
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:500; color:#e2e8f0;">
                {{ $t->luckyDraw?->getTranslation('name', app()->getLocale()) }}
            </div>
            <div style="font-size:11px; color:var(--gray);">
                {{ $t->created_at->format('d.m.Y H:i') }}
                @if($t->luckyDraw?->status === 'completed' && !$t->is_winner)
                    · <span style="color:#f87171;">Yutmadi</span>
                @endif
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:13px; font-weight:600; color:#fbbf24;">{{ $t->quantity }} ta</div>
            @if($t->is_winner)
            <div style="font-size:12px; font-weight:700; color:#34d399;">
                🏆 +{{ number_format($t->prize_won, 0) }} UZS
            </div>
            @elseif($t->luckyDraw?->status === 'active')
            <span style="font-size:10px; background:rgba(99,102,241,.15); color:#818cf8;
                         padding:2px 8px; border-radius:10px;">Kutilmoqda</span>
            @endif
        </div>
    </div>
    @endforeach
</div>
@endif

@endsection
