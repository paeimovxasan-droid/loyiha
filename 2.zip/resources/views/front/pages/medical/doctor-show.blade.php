@extends('front.layouts.app')

@section('title', $doctorProfile->user->name)

@section('content')
<div style="margin-bottom: 16px;">
    <a href="{{ route('app.medical.doctors') }}" style="color:var(--gray); text-decoration:none; font-size:12px;">
        <i class="fa fa-arrow-left"></i> Shifokorlar
    </a>
</div>

{{-- Profil kartasi --}}
<div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:20px; padding:20px; margin-bottom:16px; text-align:center;">
    <div style="width:72px; height:72px; border-radius:20px; background:linear-gradient(135deg, rgba(99,102,241,.3), rgba(139,92,246,.2)); display:flex; align-items:center; justify-content:center; font-size:28px; font-weight:700; color:#a5b4fc; margin:0 auto 12px; position:relative;">
        {{ mb_substr($doctorProfile->user->name, 0, 1) }}
        @if($doctorProfile->is_online)
        <div style="position:absolute; bottom:4px; right:4px; width:14px; height:14px; border-radius:50%; background:#10b981; border:3px solid var(--dark-2);"></div>
        @endif
    </div>
    <div style="font-size:18px; font-weight:700; color:#f1f5f9;">{{ $doctorProfile->user->name }}</div>
    <div style="font-size:13px; color:var(--primary); font-weight:500; margin-top:4px;">{{ ucfirst($doctorProfile->specialty) }}</div>
    <div style="font-size:12px; color:var(--gray); margin-top:4px;">{{ $doctorProfile->workplace }}</div>

    <div style="display:flex; justify-content:center; gap:20px; margin-top:16px;">
        <div>
            <div style="font-size:18px; font-weight:700; color:#fbbf24;">⭐ {{ $doctorProfile->rating }}</div>
            <div style="font-size:11px; color:var(--gray);">{{ $doctorProfile->reviews_count }} sharh</div>
        </div>
        <div>
            <div style="font-size:18px; font-weight:700; color:#f1f5f9;">{{ $doctorProfile->experience_years }}</div>
            <div style="font-size:11px; color:var(--gray);">yil tajriba</div>
        </div>
        <div>
            <div style="font-size:18px; font-weight:700; color:#f1f5f9;">{{ $doctorProfile->consultations_count }}</div>
            <div style="font-size:11px; color:var(--gray);">maslahat</div>
        </div>
    </div>
</div>

{{-- Bio --}}
@if($doctorProfile->bio)
<div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:16px; margin-bottom:16px;">
    <div style="font-size:13px; font-weight:600; color:#f1f5f9; margin-bottom:8px;">Haqida</div>
    <div style="font-size:13px; color:var(--gray); line-height:1.5;">{{ $doctorProfile->bio }}</div>
</div>
@endif

{{-- Narxlar va amallar --}}
<div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:16px; margin-bottom:16px;">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <span style="font-size:13px; color:var(--gray);">Chat maslahat narxi:</span>
        <span style="font-size:16px; font-weight:700; color:var(--primary);">{{ number_format($doctorProfile->consultation_price, 0) }} AIS</span>
    </div>
    @if($doctorProfile->offers_home_visit && $doctorProfile->home_visit_price > 0)
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
        <span style="font-size:13px; color:var(--gray);">Uyga chaqirish:</span>
        <span style="font-size:16px; font-weight:700; color:var(--secondary);">{{ number_format($doctorProfile->home_visit_price, 0) }} AIS</span>
    </div>
    @endif

    <form method="POST" action="{{ route('app.medical.consultations.start') }}">
        @csrf
        <input type="hidden" name="doctor_profile_id" value="{{ $doctorProfile->id }}">
        <button type="submit" style="width:100%; background:linear-gradient(135deg, var(--primary), var(--secondary)); border:none; border-radius:12px; padding:14px; color:#fff; font-size:14px; font-weight:600; cursor:pointer; margin-top:4px;">
            💬 Maslahat olish ({{ number_format($doctorProfile->consultation_price, 0) }} AIS)
        </button>
    </form>
</div>

{{-- Sharhlar --}}
@if($doctorProfile->reviews->count())
<div style="margin-bottom:16px;">
    <div style="font-size:15px; font-weight:600; color:#f1f5f9; margin-bottom:12px;">Sharhlar</div>
    <div style="display:flex; flex-direction:column; gap:10px;">
        @foreach($doctorProfile->reviews as $review)
        <div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:14px; padding:14px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:6px;">
                <span style="font-size:12px; font-weight:600; color:#f1f5f9;">{{ $review->patient->name ?? 'Anonim' }}</span>
                <span style="font-size:12px; color:#fbbf24;">
                    @for($i = 1; $i <= 5; $i++)⭐@if($i >= $review->rating)@break @endif @endfor
                    {{ $review->rating }}/5
                </span>
            </div>
            @if($review->comment)
            <p style="font-size:12px; color:var(--gray); line-height:1.4;">{{ $review->comment }}</p>
            @endif
            <div style="font-size:11px; color:var(--gray); margin-top:6px; opacity:.6;">{{ $review->created_at->diffForHumans() }}</div>
        </div>
        @endforeach
    </div>
</div>
@endif
@endsection
