@extends('front.layouts.app')

@section('title', 'Shifokorlar')

@section('content')
<div style="margin-bottom: 16px;">
    <a href="{{ route('app.medical.index') }}" style="color:var(--gray); text-decoration:none; font-size:12px;">
        <i class="fa fa-arrow-left"></i> Tibbiyot
    </a>
    <div style="font-size: 20px; font-weight: 700; color: #f1f5f9; margin-top:8px;">👨‍⚕️ Shifokorlar</div>
</div>

{{-- Filtr --}}
<div style="display:flex; gap:8px; overflow-x:auto; padding-bottom:8px; margin-bottom:16px; -webkit-overflow-scrolling:touch;">
    <a href="{{ route('app.medical.doctors') }}"
       style="white-space:nowrap; padding:6px 14px; border-radius:20px; font-size:12px; text-decoration:none; font-weight:500;
              {{ !request('specialty') ? 'background:var(--primary); color:#fff;' : 'background:rgba(255,255,255,.05); color:var(--gray); border:1px solid rgba(255,255,255,.08);' }}">
        Barchasi
    </a>
    @foreach($specialties as $spec)
    <a href="{{ route('app.medical.doctors', ['specialty' => $spec]) }}"
       style="white-space:nowrap; padding:6px 14px; border-radius:20px; font-size:12px; text-decoration:none; font-weight:500;
              {{ request('specialty') === $spec ? 'background:var(--primary); color:#fff;' : 'background:rgba(255,255,255,.05); color:var(--gray); border:1px solid rgba(255,255,255,.08);' }}">
        {{ ucfirst($spec) }}
    </a>
    @endforeach
</div>

{{-- Ro'yxat --}}
<div style="display:flex; flex-direction:column; gap:10px;">
    @forelse($doctors as $doc)
    <a href="{{ route('app.medical.doctors.show', $doc) }}" style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:14px; text-decoration:none; display:flex; align-items:center; gap:12px;">
        <div style="width:48px; height:48px; border-radius:14px; background:linear-gradient(135deg, rgba(99,102,241,.2), rgba(139,92,246,.15)); display:flex; align-items:center; justify-content:center; font-size:20px; font-weight:700; color:#a5b4fc; flex-shrink:0; position:relative;">
            {{ mb_substr($doc->user->name ?? '?', 0, 1) }}
            @if($doc->is_online)
            <div style="position:absolute; bottom:2px; right:2px; width:10px; height:10px; border-radius:50%; background:#10b981; border:2px solid var(--dark-2);"></div>
            @endif
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:14px; font-weight:600; color:#f1f5f9;">{{ $doc->user->name }}</div>
            <div style="font-size:12px; color:var(--gray);">{{ ucfirst($doc->specialty) }} • {{ $doc->experience_years }} yil tajriba</div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">
                ⭐ {{ $doc->rating }} ({{ $doc->reviews_count }}) • {{ $doc->consultations_count }} maslahat
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:14px; color:var(--primary); font-weight:700;">{{ number_format($doc->consultation_price, 0) }}</div>
            <div style="font-size:10px; color:var(--gray);">AIS</div>
        </div>
    </a>
    @empty
    <div style="text-align:center; padding:40px 20px; color:var(--gray);">
        <div style="font-size:40px; margin-bottom:12px;">🔍</div>
        <p>Shifokorlar topilmadi</p>
    </div>
    @endforelse
</div>

<div style="margin-top:16px;">
    {{ $doctors->withQueryString()->links() }}
</div>
@endsection
