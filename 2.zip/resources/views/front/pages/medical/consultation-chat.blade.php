@extends('front.layouts.app')

@section('title', 'Chat — ' . ($isDoctor ? $consultation->patient->name : $consultation->doctor->name))

@section('content')
<div style="margin-bottom: 12px;">
    <a href="{{ route('app.medical.consultations') }}" style="color:var(--gray); text-decoration:none; font-size:12px;">
        <i class="fa fa-arrow-left"></i> Maslahatlarim
    </a>
</div>

{{-- Header --}}
<div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:14px; margin-bottom:12px; display:flex; align-items:center; gap:12px;">
    <div style="width:40px; height:40px; border-radius:12px; background:linear-gradient(135deg, rgba(99,102,241,.2), rgba(139,92,246,.15)); display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:700; color:#a5b4fc;">
        {{ mb_substr($isDoctor ? $consultation->patient->name : $consultation->doctor->name, 0, 1) }}
    </div>
    <div style="flex:1;">
        <div style="font-size:14px; font-weight:600; color:#f1f5f9;">
            {{ $isDoctor ? $consultation->patient->name : $consultation->doctor->name }}
        </div>
        <div style="font-size:11px; color:var(--gray);">
            {{ ucfirst($consultation->doctorProfile->specialty) }}
            •
            @switch($consultation->status)
                @case('pending') Kutilmoqda @break
                @case('active') Faol @break
                @case('completed') Tugallangan @break
                @case('cancelled') Bekor @break
                @case('expired') Muddati o'tgan @break
            @endswitch
        </div>
    </div>
    <div style="font-size:12px; color:var(--primary); font-weight:600;">{{ number_format($consultation->price, 0) }} AIS</div>
</div>

{{-- Shifokor uchun qabul qilish tugmasi --}}
@if($isDoctor && $consultation->isPending())
<form method="POST" action="{{ url('/api/v1/medical/consultations/' . $consultation->id . '/accept') }}" style="margin-bottom:12px;">
    @csrf
    <button type="submit" style="width:100%; background:linear-gradient(135deg, #10b981, #059669); border:none; border-radius:12px; padding:12px; color:#fff; font-size:14px; font-weight:600; cursor:pointer;">
        ✅ Maslahatni qabul qilish
    </button>
</form>
@endif

{{-- Bemor uchun bekor qilish --}}
@if(!$isDoctor && $consultation->canCancel())
<form method="POST" action="{{ url('/api/v1/medical/consultations/' . $consultation->id . '/cancel') }}" style="margin-bottom:12px;" onsubmit="return confirm('Bekor qilmoqchimisiz? To\'lov qaytariladi.')">
    @csrf
    <button type="submit" style="width:100%; background:rgba(239,68,68,.1); border:1px solid rgba(239,68,68,.3); border-radius:12px; padding:10px; color:#f87171; font-size:13px; font-weight:500; cursor:pointer;">
        ❌ Bekor qilish (to'lov qaytariladi)
    </button>
</form>
@endif

{{-- Chat xabarlar --}}
<div id="chat-messages" style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:14px; margin-bottom:12px; max-height:400px; overflow-y:auto;">
    @forelse($consultation->messages as $msg)
    <div style="display:flex; margin-bottom:10px; {{ $msg->sender_id === auth()->id() ? 'justify-content:flex-end;' : 'justify-content:flex-start;' }}">
        <div style="max-width:75%; padding:10px 14px; border-radius:14px; font-size:13px; line-height:1.4;
            {{ $msg->sender_id === auth()->id() ? 'background:rgba(99,102,241,.15); color:#e0e7ff;' : 'background:rgba(255,255,255,.05); color:#e2e8f0;' }}">
            <p>{{ $msg->message }}</p>
            <div style="font-size:10px; color:var(--gray); margin-top:4px; text-align:right;">{{ $msg->created_at->format('H:i') }}</div>
        </div>
    </div>
    @empty
    <div style="text-align:center; padding:30px; color:var(--gray); font-size:13px;">
        @if($consultation->isActive())
            Suhbatni boshlang...
        @elseif($consultation->isPending())
            Shifokor javobini kuting...
        @else
            Maslahat tugallangan
        @endif
    </div>
    @endforelse
</div>

{{-- Xabar yuborish --}}
@if($consultation->canSendMessage())
<form method="POST" action="{{ url('/api/v1/medical/consultations/' . $consultation->id . '/messages') }}" style="display:flex; gap:8px;">
    @csrf
    <input type="text" name="message" placeholder="Xabar yozing..." required maxlength="2000"
           style="flex:1; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:12px 16px; color:#f1f5f9; font-size:13px; outline:none;">
    <button type="submit" style="background:var(--primary); border:none; border-radius:12px; padding:12px 16px; color:#fff; cursor:pointer;">
        <i class="fa fa-paper-plane"></i>
    </button>
</form>
@endif

{{-- Shifokor uchun tugatish --}}
@if($isDoctor && $consultation->isActive())
<div style="margin-top:12px; display:flex; gap:8px;">
    <form method="POST" action="{{ url('/api/v1/medical/consultations/' . $consultation->id . '/complete') }}" style="flex:1;">
        @csrf
        <button type="submit" style="width:100%; background:rgba(16,185,129,.1); border:1px solid rgba(16,185,129,.3); border-radius:12px; padding:10px; color:#34d399; font-size:13px; font-weight:500; cursor:pointer;"
                onclick="return confirm('Maslahatni tugatmoqchimisiz?')">
            ✅ Maslahatni tugatish
        </button>
    </form>
</div>
@endif

{{-- Retseptlar --}}
@if($consultation->prescriptions->count())
<div style="margin-top:16px;">
    <div style="font-size:14px; font-weight:600; color:#f1f5f9; margin-bottom:10px;">📋 Retseptlar</div>
    @foreach($consultation->prescriptions as $prescription)
    <div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:14px; padding:14px; margin-bottom:8px;">
        @foreach($prescription->items as $item)
        <div style="display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid rgba(255,255,255,.03);">
            <div>
                <div style="font-size:13px; font-weight:600; color:#f1f5f9;">{{ $item->medicine_name }}</div>
                <div style="font-size:11px; color:var(--gray);">{{ $item->dosage }} • {{ $item->frequency }} • {{ $item->duration }}</div>
            </div>
        </div>
        @endforeach
        @if($prescription->notes)
        <div style="font-size:12px; color:var(--gray); margin-top:8px; font-style:italic;">{{ $prescription->notes }}</div>
        @endif
    </div>
    @endforeach
</div>
@endif

{{-- Yo'llanmalar --}}
@if($consultation->referrals->count())
<div style="margin-top:16px;">
    <div style="font-size:14px; font-weight:600; color:#f1f5f9; margin-bottom:10px;">🔬 Analiz yo'llanmalar</div>
    @foreach($consultation->referrals as $referral)
    <div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:14px; padding:14px; margin-bottom:8px;">
        <div style="font-size:14px; font-weight:600; color:#f1f5f9;">{{ $referral->analysis_type }}</div>
        @if($referral->laboratory)<div style="font-size:12px; color:var(--gray); margin-top:4px;">🏥 {{ $referral->laboratory }}</div>@endif
        @if($referral->instructions)<div style="font-size:12px; color:var(--gray); margin-top:4px;">{{ $referral->instructions }}</div>@endif
    </div>
    @endforeach
</div>
@endif
@endsection
