@extends('front.layouts.app')

@section('title', 'Shifokor paneli')

@section('content')
<div style="margin-bottom: 16px;">
    <a href="{{ route('app.medical.index') }}" style="color:var(--gray); text-decoration:none; font-size:12px;">
        <i class="fa fa-arrow-left"></i> Tibbiyot
    </a>
    <div style="font-size: 20px; font-weight: 700; color: #f1f5f9; margin-top:8px;">🩺 Shifokor paneli</div>
</div>

{{-- Profil holati --}}
<div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:16px; margin-bottom:16px; display:flex; align-items:center; justify-content:space-between;">
    <div>
        <div style="font-size:14px; font-weight:600; color:#f1f5f9;">{{ ucfirst($profile->specialty) }}</div>
        <div style="font-size:12px; color:var(--gray);">
            @if($profile->status === 'approved')
                <span style="color:#34d399;">✅ Tasdiqlangan</span>
            @elseif($profile->status === 'pending')
                <span style="color:#fbbf24;">⏳ Kutilmoqda</span>
            @elseif($profile->status === 'suspended')
                <span style="color:#f87171;">🚫 To'xtatilgan</span>
            @endif
        </div>
    </div>
    <div style="text-align:right;">
        <div style="font-size:12px; color:var(--gray);">Reyting</div>
        <div style="font-size:16px; font-weight:700; color:#fbbf24;">⭐ {{ $profile->rating }}</div>
    </div>
</div>

{{-- Statistika --}}
<div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:16px;">
    <div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:14px; padding:14px; text-align:center;">
        <div style="font-size:20px; font-weight:700; color:#f1f5f9;">{{ $stats['total_consultations'] }}</div>
        <div style="font-size:11px; color:var(--gray);">Jami maslahatlar</div>
    </div>
    <div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:14px; padding:14px; text-align:center;">
        <div style="font-size:20px; font-weight:700; color:#34d399;">{{ number_format($stats['total_earnings'], 0) }}</div>
        <div style="font-size:11px; color:var(--gray);">Jami daromad (AIS)</div>
    </div>
    <div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:14px; padding:14px; text-align:center;">
        <div style="font-size:20px; font-weight:700; color:var(--primary);">{{ number_format($stats['monthly_earnings'], 0) }}</div>
        <div style="font-size:11px; color:var(--gray);">Oylik daromad (AIS)</div>
    </div>
    <div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:14px; padding:14px; text-align:center;">
        <div style="font-size:20px; font-weight:700; color:#fbbf24;">{{ $stats['pending_home_visits'] }}</div>
        <div style="font-size:11px; color:var(--gray);">Uyga chaqirish</div>
    </div>
</div>

{{-- Kutilayotgan maslahatlar --}}
@if($pendingConsultations->count())
<div style="margin-bottom:16px;">
    <div style="font-size:14px; font-weight:600; color:#f1f5f9; margin-bottom:10px;">⏳ Kutilayotgan so'rovlar</div>
    @foreach($pendingConsultations as $c)
    <a href="{{ route('app.medical.consultation', $c) }}" style="background:rgba(245,158,11,.05); border:1px solid rgba(245,158,11,.15); border-radius:14px; padding:12px; margin-bottom:8px; display:flex; align-items:center; gap:10px; text-decoration:none;">
        <div style="font-size:20px;">👤</div>
        <div style="flex:1;">
            <div style="font-size:13px; font-weight:600; color:#f1f5f9;">{{ $c->patient->name }}</div>
            <div style="font-size:11px; color:var(--gray);">{{ $c->created_at->diffForHumans() }}</div>
        </div>
        <div style="font-size:13px; color:#fbbf24; font-weight:600;">{{ number_format($c->price, 0) }} AIS</div>
    </a>
    @endforeach
</div>
@endif

{{-- Faol maslahatlar --}}
@if($activeConsultations->count())
<div style="margin-bottom:16px;">
    <div style="font-size:14px; font-weight:600; color:#f1f5f9; margin-bottom:10px;">💬 Faol maslahatlar</div>
    @foreach($activeConsultations as $c)
    <a href="{{ route('app.medical.consultation', $c) }}" style="background:rgba(6,182,212,.05); border:1px solid rgba(6,182,212,.15); border-radius:14px; padding:12px; margin-bottom:8px; display:flex; align-items:center; gap:10px; text-decoration:none;">
        <div style="font-size:20px;">💬</div>
        <div style="flex:1;">
            <div style="font-size:13px; font-weight:600; color:#f1f5f9;">{{ $c->patient->name }}</div>
            <div style="font-size:11px; color:var(--gray);">{{ $c->accepted_at?->diffForHumans() }}</div>
        </div>
        <span style="font-size:11px; background:rgba(6,182,212,.15); color:#22d3ee; padding:3px 8px; border-radius:8px;">Faol</span>
    </a>
    @endforeach
</div>
@endif

{{-- Onlayn holat --}}
<div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:14px; padding:14px; display:flex; align-items:center; justify-content:space-between;">
    <div>
        <div style="font-size:13px; font-weight:600; color:#f1f5f9;">Onlayn holat</div>
        <div style="font-size:11px; color:var(--gray);">{{ $profile->is_online ? 'Siz onlaysiz' : 'Siz oflaynsiz' }}</div>
    </div>
    <div style="width:44px; height:24px; border-radius:12px; background:{{ $profile->is_online ? '#10b981' : 'rgba(255,255,255,.1)' }}; position:relative; cursor:pointer;">
        <div style="width:20px; height:20px; border-radius:50%; background:#fff; position:absolute; top:2px; {{ $profile->is_online ? 'right:2px;' : 'left:2px;' }} transition:all .2s;"></div>
    </div>
</div>
@endsection
