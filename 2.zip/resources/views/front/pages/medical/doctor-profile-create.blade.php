@extends('front.layouts.app')

@section('title', 'Shifokor profili yaratish')

@section('content')
<div style="margin-bottom: 16px;">
    <a href="{{ route('app.medical.index') }}" style="color:var(--gray); text-decoration:none; font-size:12px;">
        <i class="fa fa-arrow-left"></i> Tibbiyot
    </a>
    <div style="font-size: 20px; font-weight: 700; color: #f1f5f9; margin-top:8px;">🩺 Shifokor profili yaratish</div>
    <div style="font-size:12px; color:var(--gray); margin-top:4px;">Ma'lumotlarni to'ldiring, admin tasdiqlaydi</div>
</div>

<form method="POST" action="{{ url('/api/v1/medical/doctor-profile') }}" style="display:flex; flex-direction:column; gap:14px;">
    @csrf

    {{-- Ixtisoslik --}}
    <div>
        <label style="font-size:12px; font-weight:500; color:var(--gray); display:block; margin-bottom:6px;">Ixtisoslik *</label>
        <select name="specialty" required style="width:100%; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:12px 16px; color:#f1f5f9; font-size:13px; outline:none; appearance:none;">
            <option value="" style="background:var(--dark-2);">Tanlang...</option>
            @foreach($specialties as $spec)
            <option value="{{ $spec }}" style="background:var(--dark-2);">{{ ucfirst($spec) }}</option>
            @endforeach
        </select>
    </div>

    {{-- Tajriba --}}
    <div>
        <label style="font-size:12px; font-weight:500; color:var(--gray); display:block; margin-bottom:6px;">Tajriba (yil) *</label>
        <input type="number" name="experience_years" min="1" max="60" required
               style="width:100%; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:12px 16px; color:#f1f5f9; font-size:13px; outline:none;">
    </div>

    {{-- Ish joyi --}}
    <div>
        <label style="font-size:12px; font-weight:500; color:var(--gray); display:block; margin-bottom:6px;">Ish joyi *</label>
        <input type="text" name="workplace" required placeholder="Masalan: Toshkent shahar 1-son klinikasi"
               style="width:100%; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:12px 16px; color:#f1f5f9; font-size:13px; outline:none;">
    </div>

    {{-- Litsenziya --}}
    <div>
        <label style="font-size:12px; font-weight:500; color:var(--gray); display:block; margin-bottom:6px;">Litsenziya raqami *</label>
        <input type="text" name="license_number" required
               style="width:100%; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:12px 16px; color:#f1f5f9; font-size:13px; outline:none;">
    </div>

    {{-- Diplom rasmi --}}
    <div>
        <label style="font-size:12px; font-weight:500; color:var(--gray); display:block; margin-bottom:6px;">Diplom rasmi (URL) *</label>
        <input type="text" name="diploma_image" required placeholder="Rasm URL manzili"
               style="width:100%; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:12px 16px; color:#f1f5f9; font-size:13px; outline:none;">
    </div>

    {{-- Maslahat narxi --}}
    <div>
        <label style="font-size:12px; font-weight:500; color:var(--gray); display:block; margin-bottom:6px;">Maslahat narxi (AIS) *</label>
        <input type="number" name="consultation_price" min="1" step="0.01" required
               style="width:100%; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:12px 16px; color:#f1f5f9; font-size:13px; outline:none;">
    </div>

    {{-- Uyga chaqirish narxi --}}
    <div>
        <label style="font-size:12px; font-weight:500; color:var(--gray); display:block; margin-bottom:6px;">Uyga chaqirish narxi (AIS, ixtiyoriy)</label>
        <input type="number" name="home_visit_price" min="0" step="0.01" value="0"
               style="width:100%; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:12px 16px; color:#f1f5f9; font-size:13px; outline:none;">
    </div>

    {{-- Bio --}}
    <div>
        <label style="font-size:12px; font-weight:500; color:var(--gray); display:block; margin-bottom:6px;">Qisqacha haqingizda</label>
        <textarea name="bio" rows="3" maxlength="1000" placeholder="Tajribangiz, mutaxassisligingiz haqida..."
                  style="width:100%; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08); border-radius:12px; padding:12px 16px; color:#f1f5f9; font-size:13px; outline:none; resize:vertical;"></textarea>
    </div>

    <button type="submit" style="width:100%; background:linear-gradient(135deg, var(--primary), var(--secondary)); border:none; border-radius:12px; padding:14px; color:#fff; font-size:14px; font-weight:600; cursor:pointer; margin-top:8px;">
        📤 Profilni yuborish
    </button>
</form>
@endsection
