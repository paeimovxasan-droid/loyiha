@extends('front.layouts.app')

@section('title', 'Tibbiyot xizmatlari')

@section('content')
<div style="margin-bottom: 20px;">
    <div style="font-size: 22px; font-weight: 700; color: #f1f5f9; letter-spacing: -.4px;">🏥 Tibbiyot xizmatlari</div>
    <div style="font-size: 13px; color: var(--gray); margin-top: 4px;">Shifokorlardan onlayn maslahat oling</div>
</div>

{{-- Tezkor havolalar --}}
<div style="display:grid; grid-template-columns: 1fr 1fr; gap:12px; margin-bottom:20px;">
    <a href="{{ route('app.medical.doctors') }}" style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:16px; text-decoration:none; text-align:center;">
        <div style="font-size:28px; margin-bottom:8px;">👨‍⚕️</div>
        <div style="font-size:13px; font-weight:600; color:#f1f5f9;">Shifokorlar</div>
        <div style="font-size:11px; color:var(--gray); margin-top:2px;">Mutaxassis toping</div>
    </a>
    <a href="{{ route('app.medical.consultations') }}" style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:16px; text-decoration:none; text-align:center;">
        <div style="font-size:28px; margin-bottom:8px;">💬</div>
        <div style="font-size:13px; font-weight:600; color:#f1f5f9;">Maslahatlarim</div>
        <div style="font-size:11px; color:var(--gray); margin-top:2px;">Chat tarixi</div>
    </a>
    <a href="{{ route('app.medical.medicine-orders') }}" style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:16px; text-decoration:none; text-align:center;">
        <div style="font-size:28px; margin-bottom:8px;">💊</div>
        <div style="font-size:13px; font-weight:600; color:#f1f5f9;">Dori buyurtmalar</div>
        <div style="font-size:11px; color:var(--gray); margin-top:2px;">Buyurtma holati</div>
    </a>
    <a href="{{ route('app.medical.doctor.create') }}" style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:16px; text-decoration:none; text-align:center;">
        <div style="font-size:28px; margin-bottom:8px;">🩺</div>
        <div style="font-size:13px; font-weight:600; color:#f1f5f9;">Shifokor bo'lish</div>
        <div style="font-size:11px; color:var(--gray); margin-top:2px;">Profil yarating</div>
    </a>
</div>

{{-- Ixtisosliklar --}}
<div style="margin-bottom:20px;">
    <div style="font-size:15px; font-weight:600; color:#f1f5f9; margin-bottom:12px;">Ixtisosliklar</div>
    <div style="display:flex; flex-wrap:wrap; gap:8px;">
        @foreach($specialties as $spec)
        <a href="{{ route('app.medical.doctors', ['specialty' => $spec]) }}"
           style="background:rgba(99,102,241,.1); border:1px solid rgba(99,102,241,.2); border-radius:20px; padding:6px 14px; text-decoration:none; font-size:12px; color:#a5b4fc; font-weight:500;">
            {{ ucfirst($spec) }}
        </a>
        @endforeach
    </div>
</div>

{{-- Top shifokorlar --}}
@if($topDoctors->count())
<div>
    <div style="font-size:15px; font-weight:600; color:#f1f5f9; margin-bottom:12px;">⭐ Top shifokorlar</div>
    <div style="display:flex; flex-direction:column; gap:10px;">
        @foreach($topDoctors as $doc)
        <a href="{{ route('app.medical.doctors.show', $doc) }}" style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:14px; text-decoration:none; display:flex; align-items:center; gap:12px;">
            <div style="width:44px; height:44px; border-radius:12px; background:linear-gradient(135deg, rgba(99,102,241,.2), rgba(139,92,246,.15)); display:flex; align-items:center; justify-content:center; font-size:18px; font-weight:700; color:#a5b4fc; flex-shrink:0;">
                {{ mb_substr($doc->user->name ?? '?', 0, 1) }}
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-size:14px; font-weight:600; color:#f1f5f9;">{{ $doc->user->name }}</div>
                <div style="font-size:12px; color:var(--gray);">{{ ucfirst($doc->specialty) }} • {{ $doc->experience_years }} yil</div>
            </div>
            <div style="text-align:right; flex-shrink:0;">
                <div style="font-size:12px; color:#fbbf24;">⭐ {{ $doc->rating }}</div>
                <div style="font-size:12px; color:var(--primary); font-weight:600;">{{ number_format($doc->consultation_price, 0) }} AIS</div>
            </div>
        </a>
        @endforeach
    </div>
</div>
@endif
@endsection
