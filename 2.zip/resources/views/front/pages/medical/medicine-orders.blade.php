@extends('front.layouts.app')

@section('title', 'Dori buyurtmalarim')

@section('content')
<div style="margin-bottom: 16px;">
    <a href="{{ route('app.medical.index') }}" style="color:var(--gray); text-decoration:none; font-size:12px;">
        <i class="fa fa-arrow-left"></i> Tibbiyot
    </a>
    <div style="font-size: 20px; font-weight: 700; color: #f1f5f9; margin-top:8px;">💊 Dori buyurtmalarim</div>
</div>

<div style="display:flex; flex-direction:column; gap:10px;">
    @forelse($orders as $order)
    <div style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:14px;">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
            <span style="font-size:13px; font-weight:600; color:#f1f5f9;">Buyurtma #{{ $order->id }}</span>
            @switch($order->status)
                @case('new')
                    <span style="font-size:11px; background:rgba(245,158,11,.15); color:#fbbf24; padding:3px 8px; border-radius:8px;">Yangi</span>
                @break
                @case('processing')
                    <span style="font-size:11px; background:rgba(6,182,212,.15); color:#22d3ee; padding:3px 8px; border-radius:8px;">Jarayonda</span>
                @break
                @case('delivering')
                    <span style="font-size:11px; background:rgba(99,102,241,.15); color:#a5b4fc; padding:3px 8px; border-radius:8px;">Yetkazilmoqda</span>
                @break
                @case('delivered')
                    <span style="font-size:11px; background:rgba(16,185,129,.15); color:#34d399; padding:3px 8px; border-radius:8px;">Yetkazildi ✅</span>
                @break
                @case('cancelled')
                    <span style="font-size:11px; background:rgba(239,68,68,.15); color:#f87171; padding:3px 8px; border-radius:8px;">Bekor</span>
                @break
            @endswitch
        </div>

        <div style="font-size:12px; color:var(--gray); margin-bottom:6px;">
            {{ $order->items->count() }} ta dori • {{ $order->created_at->format('d.m.Y H:i') }}
        </div>

        <div style="display:flex; justify-content:space-between; align-items:center;">
            <span style="font-size:11px; color:var(--gray);">📍 {{ \Illuminate\Support\Str::limit($order->delivery_address, 30) }}</span>
            <span style="font-size:14px; font-weight:700; color:var(--primary);">{{ number_format($order->total_amount, 0) }} AIS</span>
        </div>
    </div>
    @empty
    <div style="text-align:center; padding:40px 20px; color:var(--gray);">
        <div style="font-size:40px; margin-bottom:12px;">💊</div>
        <p>Hali buyurtma bermadingiz</p>
    </div>
    @endforelse
</div>

<div style="margin-top:16px;">{{ $orders->links() }}</div>
@endsection
