@extends('front.layouts.app')

@section('title', 'Maslahatlarim')

@section('content')
<div style="margin-bottom: 16px;">
    <a href="{{ route('app.medical.index') }}" style="color:var(--gray); text-decoration:none; font-size:12px;">
        <i class="fa fa-arrow-left"></i> Tibbiyot
    </a>
    <div style="font-size: 20px; font-weight: 700; color: #f1f5f9; margin-top:8px;">💬 Maslahatlarim</div>
</div>

<div style="display:flex; flex-direction:column; gap:10px;">
    @forelse($consultations as $c)
    @php
        $isPatient = $c->patient_id === auth()->id();
        $otherUser = $isPatient ? $c->doctor : $c->patient;
    @endphp
    <a href="{{ route('app.medical.consultation', $c) }}" style="background:var(--dark-2); border:1px solid rgba(255,255,255,.05); border-radius:16px; padding:14px; text-decoration:none; display:flex; align-items:center; gap:12px;">
        <div style="width:44px; height:44px; border-radius:12px; background:linear-gradient(135deg, rgba(99,102,241,.2), rgba(139,92,246,.15)); display:flex; align-items:center; justify-content:center; font-size:18px; font-weight:700; color:#a5b4fc; flex-shrink:0;">
            {{ mb_substr($otherUser->name ?? '?', 0, 1) }}
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:14px; font-weight:600; color:#f1f5f9;">{{ $otherUser->name }}</div>
            <div style="font-size:12px; color:var(--gray);">
                {{ ucfirst($c->doctorProfile->specialty ?? '') }}
                • {{ $isPatient ? 'Bemor' : 'Shifokor' }} sifatida
            </div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">{{ $c->created_at->diffForHumans() }}</div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            @switch($c->status)
                @case('pending')
                    <span style="font-size:11px; background:rgba(245,158,11,.15); color:#fbbf24; padding:3px 8px; border-radius:8px;">Kutilmoqda</span>
                @break
                @case('active')
                    <span style="font-size:11px; background:rgba(6,182,212,.15); color:#22d3ee; padding:3px 8px; border-radius:8px;">Faol</span>
                @break
                @case('completed')
                    <span style="font-size:11px; background:rgba(16,185,129,.15); color:#34d399; padding:3px 8px; border-radius:8px;">Tugallangan</span>
                @break
                @case('cancelled')
                    <span style="font-size:11px; background:rgba(100,116,139,.15); color:#94a3b8; padding:3px 8px; border-radius:8px;">Bekor</span>
                @break
                @case('expired')
                    <span style="font-size:11px; background:rgba(239,68,68,.15); color:#f87171; padding:3px 8px; border-radius:8px;">Muddati o'tgan</span>
                @break
            @endswitch
        </div>
    </a>
    @empty
    <div style="text-align:center; padding:40px 20px; color:var(--gray);">
        <div style="font-size:40px; margin-bottom:12px;">💬</div>
        <p>Hali maslahat olmadingiz</p>
        <a href="{{ route('app.medical.doctors') }}" style="color:var(--primary); font-size:13px; text-decoration:none; margin-top:8px; display:inline-block;">Shifokor toping →</a>
    </div>
    @endforelse
</div>

<div style="margin-top:16px;">{{ $consultations->links() }}</div>
@endsection
