@extends('front.layouts.app')
@section('title', 'Topshiriqlar')
@section('content')

<div class="page-title">📋 Topshiriqlar</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<div style="display:flex; flex-direction:column; gap:12px;">
@forelse($tasks as $task)
@php $status = $myTasks[$task->id] ?? null; @endphp
<div class="card">
    <div style="padding:18px;">
        <div style="display:flex; align-items:flex-start; gap:14px;">
            {{-- Platform icon --}}
            <div style="width:46px; height:46px; border-radius:14px; flex-shrink:0;
                        background:rgba(99,102,241,.12); display:flex; align-items:center; justify-content:center; font-size:20px;">
                @if($task->platform === 'youtube') 📺
                @elseif($task->platform === 'telegram') ✈️
                @elseif($task->platform === 'instagram') 📸
                @else 🔗
                @endif
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-size:14px; font-weight:600; color:#f1f5f9; margin-bottom:4px;">
                    {{ $task->getTranslation('title', app()->getLocale()) }}
                </div>
                @if($task->getTranslation('description', app()->getLocale()))
                <div style="font-size:12px; color:var(--gray); margin-bottom:8px;">
                    {{ $task->getTranslation('description', app()->getLocale()) }}
                </div>
                @endif
                <div style="display:flex; align-items:center; gap:10px;">
                    <span style="font-size:12px; font-weight:600; color:#818cf8;">
                        <i class="fa fa-bolt"></i> +{{ $task->reward }} XP
                    </span>
                    @if($task->link)
                    <a href="{{ $task->link }}" target="_blank"
                       style="font-size:12px; color:#34d399; text-decoration:none;">
                        <i class="fa fa-arrow-up-right-from-square"></i> Ochish
                    </a>
                    @endif
                </div>
            </div>
            {{-- Status --}}
            <div style="flex-shrink:0;">
                @if($status === 'approved')
                <span class="badge badge-success"><i class="fa fa-check"></i> Tasdiqlandi</span>
                @elseif($status === 'pending')
                <span class="badge badge-warning"><i class="fa fa-clock"></i> Kutilmoqda</span>
                @elseif($status === 'rejected')
                <span class="badge badge-danger"><i class="fa fa-times"></i> Rad etildi</span>
                @endif
            </div>
        </div>

        @if(!$status)
        <form method="POST" action="{{ route('app.tasks.submit', $task) }}" style="margin-top:14px;">
            @csrf
            <div style="display:flex; gap:8px;">
                <input type="text" name="proof" class="form-control"
                       placeholder="Havola yoki izoh (ixtiyoriy)" style="flex:1; font-size:13px;">
                <button type="submit" class="btn btn-primary btn-sm" style="white-space:nowrap;">
                    <i class="fa fa-paper-plane"></i> Yuborish
                </button>
            </div>
        </form>
        @endif
    </div>
</div>
@empty
<div class="card" style="padding:50px; text-align:center; color:var(--gray);">
    <i class="fa fa-list-check" style="font-size:40px; opacity:.3; display:block; margin-bottom:14px;"></i>
    Hozircha topshiriq yo'q
</div>
@endforelse
</div>

@endsection
