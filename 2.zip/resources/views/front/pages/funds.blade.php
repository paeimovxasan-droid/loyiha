@extends('front.layouts.app')
@section('title', 'Investitsiya Fondlari')
@section('content')

<div class="page-title">📈 Investitsiya Fondlari</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<div style="display:flex; flex-direction:column; gap:14px; margin-bottom:24px;">
@forelse($funds as $fund)
<div class="card">
    <div style="padding:20px;">
        <div style="display:flex; align-items:center; gap:14px; margin-bottom:14px;">
            <img src="{{ $fund->photo_url }}"
                 style="width:52px; height:52px; border-radius:14px; object-fit:cover; flex-shrink:0;">
            <div style="flex:1;">
                <div style="font-size:15px; font-weight:700; color:#f1f5f9;">
                    {{ $fund->getTranslation('name', app()->getLocale()) }}
                </div>
                @if($fund->getTranslation('description', app()->getLocale()))
                <div style="font-size:12px; color:var(--gray); margin-top:2px;">
                    {{ Str::limit($fund->getTranslation('description', app()->getLocale()), 80) }}
                </div>
                @endif
            </div>
        </div>

        <div class="grid grid-3" style="gap:8px; margin-bottom:16px;">
            <div style="background:rgba(16,185,129,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#34d399;">{{ $fund->commission_percent }}%</div>
                <div style="font-size:10px; color:var(--gray);">Foyda</div>
            </div>
            <div style="background:rgba(99,102,241,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#818cf8;">{{ $fund->validity_days }}</div>
                <div style="font-size:10px; color:var(--gray);">Kun</div>
            </div>
            <div style="background:rgba(245,158,11,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:14px; font-weight:700; color:#fbbf24;">{{ number_format($fund->min_invest, 0) }}</div>
                <div style="font-size:10px; color:var(--gray);">Min UZS</div>
            </div>
        </div>

        <form method="POST" action="{{ route('app.funds.invest', $fund) }}">
            @csrf
            <div style="display:flex; gap:8px;">
                <input type="number" name="amount" min="{{ $fund->min_invest }}" step="1000" required
                       class="form-control" placeholder="Miqdor (UZS)" style="flex:1;"
                       oninput="calcProfit(this, {{ $fund->commission_percent }})">
                <button type="submit" class="btn btn-primary" style="white-space:nowrap;">
                    <i class="fa fa-chart-line"></i> Invest
                </button>
            </div>
            <div class="profit-info-{{ $fund->id }}"
                 style="font-size:12px; color:#34d399; margin-top:6px; display:none;"></div>
        </form>
    </div>
</div>
@empty
<div class="card" style="padding:50px; text-align:center; color:var(--gray);">
    <i class="fa fa-chart-pie" style="font-size:40px; opacity:.3; display:block; margin-bottom:14px;"></i>
    Hozircha fond yo'q
</div>
@endforelse
</div>

{{-- Mening investitsiyalarim --}}
@if($myInvests->count())
<p class="section-label">Mening investitsiyalarim</p>
<div class="card">
    @foreach($myInvests as $inv)
    <div class="list-item">
        <div style="width:40px; height:40px; border-radius:12px; flex-shrink:0;
                    background:rgba(16,185,129,.1); display:flex; align-items:center; justify-content:center;">
            <i class="fa fa-chart-line" style="color:#34d399;"></i>
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:500; color:#e2e8f0;">
                {{ $inv->fund?->getTranslation('name', app()->getLocale()) }}
            </div>
            <div style="font-size:11px; color:var(--gray);">
                {{ $inv->started_at->format('d.m.Y') }} → {{ $inv->expires_at->format('d.m.Y') }}
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:13px; font-weight:600; color:#f1f5f9;">{{ number_format($inv->amount) }}</div>
            <div style="font-size:11px; color:#34d399;">+{{ number_format($inv->expected_profit) }}</div>
            @if($inv->status === 'active')
            <span class="badge badge-success" style="font-size:10px;">Faol</span>
            @elseif($inv->status === 'matured')
            <span class="badge badge-info" style="font-size:10px;">Tugadi</span>
            @endif
        </div>
    </div>
    @endforeach
</div>
@if($myInvests->hasPages())
<div style="margin-top:12px;">{{ $myInvests->links() }}</div>
@endif
@endif

@endsection

@section('scripts')
<script>
function calcProfit(input, pct) {
    const amount = parseFloat(input.value) || 0;
    const profit = (amount * pct / 100).toFixed(0);
    const form = input.closest('form');
    const info = form.querySelector('[class^="profit-info"]');
    if (info) {
        if (amount > 0) {
            info.style.display = 'block';
            info.textContent = `Kutilayotgan foyda: +${Number(profit).toLocaleString()} UZS`;
        } else {
            info.style.display = 'none';
        }
    }
}
</script>
@endsection
