@extends('front.layouts.app')
@section('title', 'Reyting')
@section('content')

<div class="page-title">🏆 Reyting</div>

{{-- Mening o'rnim --}}
@if($userLevel)
<div style="background:rgba(99,102,241,.1); border:1px solid rgba(99,102,241,.2);
            border-radius:16px; padding:16px; margin-bottom:20px;
            display:flex; align-items:center; gap:14px;">
    <div style="font-size:24px; font-weight:800; color:#818cf8; min-width:40px;">#{{ $userRank }}</div>
    <img src="{{ auth()->user()->avatar_url }}"
         style="width:44px; height:44px; border-radius:12px; object-fit:cover; flex-shrink:0;">
    <div style="flex:1;">
        <div style="font-size:14px; font-weight:600; color:#f1f5f9;">{{ auth()->user()->name }}</div>
        <div style="font-size:12px; color:var(--gray);">{{ $userLevel->title }} · {{ number_format($userLevel->total_xp) }} XP</div>
    </div>
    <div style="font-size:16px; font-weight:700; color:{{ $userLevel->badge_color }};">
        Lv.{{ $userLevel->level }}
    </div>
</div>
@endif

{{-- Top 50 --}}
<div class="card">
    @foreach($topUsers as $i => $item)
    @php $isMe = $item->user_id === auth()->id(); @endphp
    <div class="list-item" style="{{ $isMe ? 'background:rgba(99,102,241,.06);' : '' }}">
        <div style="width:32px; text-align:center; flex-shrink:0; font-size:14px; font-weight:700;
                    color:{{ $i === 0 ? '#fbbf24' : ($i === 1 ? '#94a3b8' : ($i === 2 ? '#b45309' : 'var(--gray)')) }};">
            @if($i < 3)
                {{ ['🥇','🥈','🥉'][$i] }}
            @else
                {{ $i + 1 }}
            @endif
        </div>
        <img src="{{ $item->user?->avatar_url }}"
             style="width:38px; height:38px; border-radius:10px; object-fit:cover; flex-shrink:0;">
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:{{ $isMe ? '700' : '500' }}; color:#e2e8f0;">
                {{ $item->user?->name }}
                @if($isMe) <span style="color:#818cf8; font-size:11px;">(Siz)</span> @endif
            </div>
            <div style="font-size:11px; color:var(--gray);">@{{ $item->user?->username ?? '—' }}</div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:13px; font-weight:700; color:{{ $item->badge_color }};">
                Lv.{{ $item->level }}
            </div>
            <div style="font-size:11px; color:var(--gray);">{{ number_format($item->total_xp) }} XP</div>
        </div>
    </div>
    @endforeach
</div>

@endsection
