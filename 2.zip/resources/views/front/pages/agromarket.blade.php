@extends('front.layouts.app')
@section('title', 'AgroMarket')
@section('content')

<div class="page-title">🌾 AgroMarket</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<a href="{{ route('app.agromarket.create') }}"
   style="display:flex; align-items:center; justify-content:center; gap:8px; width:100%;
          padding:14px; margin-bottom:16px; background:linear-gradient(135deg, rgba(16,185,129,.15), rgba(16,185,129,.08));
          border:1px solid rgba(16,185,129,.3); border-radius:14px; color:#34d399;
          text-decoration:none; font-size:14px; font-weight:600;">
    <i class="fa fa-plus"></i> E'lon berish
</a>

<div style="display:flex; flex-direction:column; gap:14px;">
@forelse($listings as $listing)
<div class="card">
    <div style="padding:20px;">
        <div style="display:flex; align-items:center; gap:14px; margin-bottom:12px;">
            <div style="width:48px; height:48px; border-radius:14px; background:rgba(16,185,129,.1);
                        display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                <i class="fa fa-seedling" style="color:#34d399; font-size:18px;"></i>
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-size:15px; font-weight:700; color:#f1f5f9;">{{ $listing->title }}</div>
                <div style="font-size:12px; color:var(--gray); margin-top:2px;">
                    <i class="fa fa-user" style="font-size:10px;"></i> {{ $listing->user->name ?? 'Noma\'lum' }}
                </div>
            </div>
        </div>

        @if($listing->description)
        <div style="font-size:13px; color:var(--gray); margin-bottom:14px; line-height:1.5;">
            {{ Str::limit($listing->description, 120) }}
        </div>
        @endif

        <div style="display:flex; gap:8px;">
            <div style="flex:1; background:rgba(16,185,129,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#34d399;">{{ number_format($listing->price_per_unit) }}</div>
                <div style="font-size:10px; color:var(--gray);">Narxi</div>
            </div>
            <div style="flex:1; background:rgba(99,102,241,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#818cf8;">{{ number_format($listing->quantity, 1) }}</div>
                <div style="font-size:10px; color:var(--gray);">{{ $listing->category ?? 'dona' }}</div>
            </div>
        </div>
    </div>
</div>
@empty
<div class="card" style="padding:50px; text-align:center; color:var(--gray);">
    <i class="fa fa-seedling" style="font-size:40px; opacity:.3; display:block; margin-bottom:14px;"></i>
    Hozircha e'lonlar yo'q
</div>
@endforelse
</div>

@if($listings->hasPages())
<div style="margin-top:16px;">{{ $listings->links() }}</div>
@endif

@endsection
