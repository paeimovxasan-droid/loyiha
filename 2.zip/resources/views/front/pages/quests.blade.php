@extends('front.layouts.app')
@section('title', 'Kvestlar')
@section('content')

<div class="page-title">🎯 Kvestlar</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

{{-- Statistika --}}
<div class="grid grid-3" style="margin-bottom:20px; gap:10px;">
    <div style="background:rgba(99,102,241,.1); border:1px solid rgba(99,102,241,.2);
                border-radius:16px; padding:14px; text-align:center;">
        <div style="font-size:22px; font-weight:800; color:#818cf8;">{{ $stats['total'] }}</div>
        <div style="font-size:11px; color:var(--gray); margin-top:2px;">Jami</div>
    </div>
    <div style="background:rgba(16,185,129,.1); border:1px solid rgba(16,185,129,.2);
                border-radius:16px; padding:14px; text-align:center;">
        <div style="font-size:22px; font-weight:800; color:#34d399;">{{ $stats['completed'] }}</div>
        <div style="font-size:11px; color:var(--gray); margin-top:2px;">Tugallangan</div>
    </div>
    <div style="background:rgba(245,158,11,.1); border:1px solid rgba(245,158,11,.2);
                border-radius:16px; padding:14px; text-align:center;">
        <div style="font-size:22px; font-weight:800; color:#fbbf24;">{{ $stats['claimed'] }}</div>
        <div style="font-size:11px; color:var(--gray); margin-top:2px;">Olingan</div>
    </div>
</div>

{{-- Umumiy progress --}}
@if($stats['total'] > 0)
<div style="margin-bottom:20px; background:rgba(255,255,255,.03); border-radius:14px; padding:14px;">
    <div style="display:flex; justify-content:space-between; font-size:12px; color:var(--gray); margin-bottom:6px;">
        <span>Umumiy progress</span>
        <span>{{ $stats['claimed'] }} / {{ $stats['total'] }}</span>
    </div>
    <div style="height:6px; background:rgba(255,255,255,.06); border-radius:10px; overflow:hidden;">
        <div style="height:100%; width:{{ $stats['total'] > 0 ? round($stats['claimed']/$stats['total']*100) : 0 }}%;
                    background:linear-gradient(90deg,#6366f1,#8b5cf6); border-radius:10px; transition:width .5s;"></div>
    </div>
</div>
@endif

{{-- Kategoriyalar bo'yicha kvestlar --}}
@php
$categoryLabels = [
    'general'    => ['🌟 Asosiy', '#06b6d4'],
    'daily'      => ['🔥 Kunlik', '#f87171'],
    'weekly'     => ['📅 Haftalik', '#a855f7'],
    'investment' => ['📈 Investitsiya', '#34d399'],
    'referral'   => ['👥 Referral', '#fbbf24'],
    'social'     => ['🌐 Ijtimoiy', '#818cf8'],
];
@endphp

@foreach($grouped as $category => $categoryQuests)
@php [$catLabel, $catColor] = $categoryLabels[$category] ?? ['🎯 Boshqa', '#64748b']; @endphp

<div style="margin-bottom:24px;">
    <div style="display:flex; align-items:center; gap:8px; margin-bottom:12px;">
        <div style="font-size:12px; font-weight:700; color:{{ $catColor }};
                    text-transform:uppercase; letter-spacing:.5px;">
            {{ $catLabel }}
        </div>
        <div style="flex:1; height:1px; background:rgba(255,255,255,.06);"></div>
        <div style="font-size:11px; color:var(--gray);">
            {{ $categoryQuests->filter(fn($q) => $q->isClaimed())->count() }}/{{ $categoryQuests->count() }}
        </div>
    </div>

    <div style="display:flex; flex-direction:column; gap:10px;">
        @foreach($categoryQuests as $uq)
        @php
            $quest    = $uq->quest;
            $required = $quest->requirement_value;
            $progress = $uq->progress ?? 0;
            $pct      = $required > 0 ? min(100, round($progress / $required * 100)) : 0;
            $claimed  = $uq->isClaimed();
            $completed = $uq->isCompleted();
        @endphp

        <div style="background:{{ $claimed ? 'rgba(16,185,129,.06)' : 'var(--dark-2)' }};
                    border:1px solid {{ $claimed ? 'rgba(16,185,129,.2)' : 'rgba(255,255,255,.05)' }};
                    border-radius:18px; padding:16px; position:relative; overflow:hidden;">

            {{-- Completed overlay --}}
            @if($claimed)
            <div style="position:absolute; top:12px; right:12px; font-size:20px;">✅</div>
            @endif

            <div style="display:flex; align-items:flex-start; gap:14px;">
                {{-- Icon --}}
                <div style="width:48px; height:48px; border-radius:14px; flex-shrink:0;
                            background:{{ $catColor }}18; display:flex; align-items:center;
                            justify-content:center; font-size:22px;">
                    {{ $quest->icon }}
                </div>

                <div style="flex:1; min-width:0;">
                    <div style="font-size:14px; font-weight:700; color:{{ $claimed ? '#34d399' : '#f1f5f9' }};
                                margin-bottom:3px;">
                        {{ $quest->getTranslation('title', app()->getLocale()) }}
                    </div>
                    <div style="font-size:12px; color:var(--gray); margin-bottom:10px;">
                        {{ $quest->getTranslation('description', app()->getLocale()) }}
                    </div>

                    {{-- Mukofot --}}
                    <div style="display:flex; flex-wrap:wrap; gap:6px; margin-bottom:10px;">
                        @if($quest->reward_ais > 0)
                        <span style="font-size:11px; font-weight:600; color:#818cf8;
                                     background:rgba(99,102,241,.1); padding:3px 8px; border-radius:8px;">
                            💎 {{ number_format($quest->reward_ais, 2) }} AIS
                        </span>
                        @endif
                        @if($quest->reward_uzs > 0)
                        <span style="font-size:11px; font-weight:600; color:#34d399;
                                     background:rgba(16,185,129,.1); padding:3px 8px; border-radius:8px;">
                            💵 {{ number_format($quest->reward_uzs, 0) }} UZS
                        </span>
                        @endif
                        @if($quest->reward_xp > 0)
                        <span style="font-size:11px; font-weight:600; color:#fbbf24;
                                     background:rgba(245,158,11,.1); padding:3px 8px; border-radius:8px;">
                            ⚡ +{{ $quest->reward_xp }} XP
                        </span>
                        @endif
                    </div>

                    {{-- Progress --}}
                    @if(!$claimed)
                    <div style="margin-bottom:8px;">
                        <div style="display:flex; justify-content:space-between; font-size:11px;
                                    color:var(--gray); margin-bottom:4px;">
                            <span>{{ $progress }} / {{ $required }}</span>
                            <span>{{ $pct }}%</span>
                        </div>
                        <div style="height:5px; background:rgba(255,255,255,.06); border-radius:10px; overflow:hidden;">
                            <div style="height:100%; width:{{ $pct }}%;
                                        background:{{ $completed ? '#10b981' : $catColor }};
                                        border-radius:10px; transition:width .4s;"></div>
                        </div>
                    </div>
                    @endif

                    {{-- Claim tugmasi --}}
                    @if($completed && !$claimed && $uq->id)
                    <form method="POST" action="{{ route('app.quests.claim', $uq) }}">
                        @csrf
                        <button type="submit"
                                style="background:linear-gradient(135deg,#10b981,#059669);
                                       border:none; border-radius:10px; padding:8px 18px;
                                       color:#fff; font-size:13px; font-weight:600;
                                       cursor:pointer; font-family:inherit; display:flex;
                                       align-items:center; gap:6px; transition:all .2s;"
                                onmouseenter="this.style.transform='translateY(-1px)'"
                                onmouseleave="this.style.transform='translateY(0)'">
                            <i class="fa fa-gift"></i> Mukofot olish
                        </button>
                    </form>
                    @elseif($claimed)
                    <div style="font-size:12px; color:#34d399; font-weight:600;">
                        <i class="fa fa-check-circle"></i> Mukofot olindi
                        @if($uq->claimed_at)
                        <span style="color:var(--gray); font-weight:400;">
                            · {{ $uq->claimed_at->format('d.m.Y') }}
                        </span>
                        @endif
                    </div>
                    @elseif($quest->min_level > 0 && (auth()->user()->userLevel?->level ?? 0) < $quest->min_level)
                    <div style="font-size:12px; color:var(--gray);">
                        <i class="fa fa-lock"></i> Level {{ $quest->min_level }} dan ochiladi
                    </div>
                    @endif
                </div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endforeach

@if($quests->isEmpty())
<div class="card" style="padding:50px; text-align:center; color:var(--gray);">
    <i class="fa fa-map" style="font-size:40px; opacity:.3; display:block; margin-bottom:14px;"></i>
    Hozircha kvest yo'q
</div>
@endif

@endsection
