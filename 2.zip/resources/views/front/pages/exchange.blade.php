@extends('front.layouts.app')
@section('title', 'Birja')
@section('content')

<div class="page-title">📊 AIS Birja</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

{{-- Current rates --}}
<div style="display:flex; gap:10px; margin-bottom:20px;">
    <div class="card" style="flex:1; padding:20px; text-align:center;">
        <div style="font-size:11px; color:var(--gray); margin-bottom:6px;">Sotib olish</div>
        <div style="font-size:22px; font-weight:800; color:#34d399;">{{ number_format($buyRate, 2) }}</div>
        <div style="font-size:11px; color:var(--gray);">UZS / AIS</div>
    </div>
    <div class="card" style="flex:1; padding:20px; text-align:center;">
        <div style="font-size:11px; color:var(--gray); margin-bottom:6px;">Sotish</div>
        <div style="font-size:22px; font-weight:800; color:#f87171;">{{ number_format($sellRate, 2) }}</div>
        <div style="font-size:11px; color:var(--gray);">UZS / AIS</div>
    </div>
</div>

{{-- Order form --}}
<div class="card" style="margin-bottom:20px;">
    <div style="padding:20px;">
        <div style="font-size:15px; font-weight:700; color:#f1f5f9; margin-bottom:16px;">
            <i class="fa fa-exchange-alt"></i> Buyurtma berish
        </div>
        <form method="POST" action="{{ route('app.exchange.order') }}">
            @csrf
            <div style="margin-bottom:12px;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Turi</label>
                <select name="side" class="form-control" required>
                    <option value="buy">Sotib olish (Buy)</option>
                    <option value="sell">Sotish (Sell)</option>
                </select>
            </div>
            <div style="margin-bottom:14px;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Miqdor (AIS)</label>
                <input type="number" name="amount" min="1" step="0.0001" required
                       class="form-control" placeholder="Miqdor kiriting">
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;">
                <i class="fa fa-paper-plane"></i> Buyurtma berish
            </button>
        </form>
    </div>
</div>

{{-- My orders --}}
@if($myOrders->count())
<p class="section-label">Mening buyurtmalarim</p>
<div class="card">
    @foreach($myOrders as $order)
    <div class="list-item">
        <div style="width:40px; height:40px; border-radius:12px; flex-shrink:0;
                    background:{{ $order->side === 'buy' ? 'rgba(16,185,129,.1)' : 'rgba(239,68,68,.1)' }};
                    display:flex; align-items:center; justify-content:center;">
            <i class="fa fa-arrow-{{ $order->side === 'buy' ? 'down' : 'up' }}"
               style="color:{{ $order->side === 'buy' ? '#34d399' : '#f87171' }};"></i>
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:500; color:#e2e8f0;">
                {{ strtoupper($order->side) }} — {{ number_format($order->amount, 4) }} AIS
            </div>
            <div style="font-size:11px; color:var(--gray);">
                {{ $order->created_at->format('d.m.Y H:i') }}
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:12px; font-weight:600; color:#f1f5f9;">{{ number_format($order->price, 2) }}</div>
            <span style="font-size:10px; padding:2px 8px; border-radius:10px;
                         background:{{ $order->status === 'open' ? 'rgba(245,158,11,.15)' : 'rgba(16,185,129,.15)' }};
                         color:{{ $order->status === 'open' ? '#fbbf24' : '#34d399' }};">
                {{ $order->status }}
            </span>
        </div>
    </div>
    @endforeach
</div>
@endif

@endsection
