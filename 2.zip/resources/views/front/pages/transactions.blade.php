@extends('front.layouts.app')
@section('title', __('front.transactions.title'))
@section('content')

<div class="page-title">📋 {{ __('front.transactions.title') }}</div>

<div class="card">
    @forelse($transactions as $tx)
    <div class="list-item">
        <div style="width:42px; height:42px; border-radius:12px; flex-shrink:0;
                    background: {{ $tx->amount > 0 ? 'rgba(16,185,129,.1)' : 'rgba(239,68,68,.1)' }};
                    display:flex; align-items:center; justify-content:center;">
            @if($tx->type === 'mining' && $tx->direction === 'credit')
                <i class="fa fa-chart-line" style="color:#34d399; font-size:15px;"></i>
            @elseif($tx->type === 'deposit')
                <i class="fa fa-arrow-down-to-line" style="color:#22d3ee; font-size:15px;"></i>
            @elseif($tx->type === 'withdraw')
                <i class="fa fa-arrow-up-from-line" style="color:#f87171; font-size:15px;"></i>
            @elseif($tx->type === 'commission')
                <i class="fa fa-users" style="color:#fbbf24; font-size:15px;"></i>
            @elseif($tx->type === 'mining' && $tx->direction === 'debit')
                <i class="fa fa-box" style="color:#818cf8; font-size:15px;"></i>
            @else
                <i class="fa fa-arrow-right-arrow-left" style="color:#94a3b8; font-size:15px;"></i>
            @endif
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:500; color:#e2e8f0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                {{ $tx->description ?? __('front.transactions.type_' . $tx->type) }}
            </div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">
                {{ $tx->created_at->format('d.m.Y · H:i') }}
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:14px; font-weight:700; color: {{ $tx->direction === 'credit' ? '#34d399' : '#f87171' }};">
                {{ $tx->direction === 'credit' ? '+' : '-' }}{{ number_format($tx->amount, 2) }}
            </div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">
                {{ $tx->type }}
            </div>
        </div>
    </div>
    @empty
    <div style="padding:50px; text-align:center; color:var(--gray);">
        <i class="fa fa-receipt" style="font-size:36px; opacity:.3; display:block; margin-bottom:14px;"></i>
        {{ __('front.transactions.no_tx') }}
    </div>
    @endforelse
</div>

@if($transactions->hasPages())
<div style="margin-top:16px; text-align:center;">{{ $transactions->links() }}</div>
@endif

@endsection
