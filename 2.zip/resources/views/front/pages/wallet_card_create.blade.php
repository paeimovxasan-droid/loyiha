@extends('front.layouts.app')
@section('title', 'Virtual Karta Yaratish')
@section('content')

<div style="display:flex; align-items:center; gap:12px; margin-bottom:20px;">
    <a href="{{ route('app.wallet') }}"
       style="width:36px; height:36px; border-radius:10px; background:rgba(255,255,255,.06);
              display:flex; align-items:center; justify-content:center; color:var(--text-muted);
              text-decoration:none; flex-shrink:0;">
        <i class="fa fa-arrow-left"></i>
    </a>
    <div class="page-title" style="margin-bottom:0;">💳 Virtual Karta Yaratish</div>
</div>

@if($errors->any())
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ $errors->first() }}</div>
@endif

{{-- Karta preview --}}
<div id="cardPreview"
     style="background:linear-gradient(135deg, #0f172a, #1e1b4b);
            border-radius:20px; padding:24px; margin-bottom:24px;
            border:1px solid rgba(99,102,241,.2); position:relative; overflow:hidden;">
    <div style="position:absolute; top:-20px; right:-20px; width:100px; height:100px;
                border-radius:50%; background:rgba(255,255,255,.03);"></div>
    <div style="font-size:11px; color:rgba(255,255,255,.4); margin-bottom:16px; letter-spacing:1px;">
        AISOQQA VIRTUAL CARD
    </div>
    <div style="font-size:20px; font-weight:700; color:#e2e8f0; letter-spacing:3px; margin-bottom:20px;">
        4XXX XXXX XXXX XXXX
    </div>
    <div style="display:flex; justify-content:space-between; align-items:flex-end;">
        <div>
            <div style="font-size:10px; color:rgba(255,255,255,.4);">KARTA EGASI</div>
            <div id="previewName" style="font-size:14px; font-weight:600; color:#e2e8f0; letter-spacing:1px;">
                FULL NAME
            </div>
        </div>
        <div style="text-align:right;">
            <div style="font-size:10px; color:rgba(255,255,255,.4);">MUDDAT</div>
            <div style="font-size:14px; font-weight:600; color:#e2e8f0;">
                {{ now()->addYears(3)->format('m') }}/{{ substr(now()->addYears(3)->format('Y'), -2) }}
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fa fa-credit-card"></i> Karta ma'lumotlari</span>
    </div>
    <div class="card-body">
        <form method="POST" action="{{ route('app.wallet.card.store') }}">
            @csrf
            <div class="form-group">
                <label class="form-label">Karta egasi ismi (lotin harflarda)</label>
                <input type="text" name="card_holder" required
                       class="form-control {{ $errors->has('card_holder') ? 'is-invalid' : '' }}"
                       placeholder="FIRSTNAME LASTNAME"
                       style="text-transform:uppercase; letter-spacing:1px;"
                       oninput="document.getElementById('previewName').textContent = this.value.toUpperCase() || 'FULL NAME'"
                       maxlength="26">
                <div style="font-size:11px; color:var(--gray); margin-top:4px;">
                    Faqat lotin harflari va bo'sh joy. Masalan: JOHN DOE
                </div>
                @error('card_holder')
                <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div>
                @enderror
            </div>

            <div style="background:rgba(245,158,11,.08); border:1px solid rgba(245,158,11,.2);
                        border-radius:12px; padding:14px; margin-bottom:16px;">
                <div style="font-size:12px; color:#fbbf24; font-weight:600; margin-bottom:6px;">
                    <i class="fa fa-triangle-exclamation"></i> Muhim!
                </div>
                <div style="font-size:12px; color:var(--gray); line-height:1.6;">
                    Karta yaratilganda CVV kodi <strong style="color:#fbbf24;">bir marta</strong> ko'rsatiladi.
                    Uni eslab qoling yoki yozib oling — keyinchalik ko'rsatilmaydi.
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-full btn-lg">
                <i class="fa fa-credit-card"></i> Karta yaratish
            </button>
        </form>
    </div>
</div>

@endsection
