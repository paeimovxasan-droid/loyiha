@extends('front.layouts.app')
@section('title', 'Kurs yaratish')
@section('content')

<div class="page-title">🎓 Kurs yaratish</div>

@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<div class="card" style="padding:20px;">
    <form method="POST" action="{{ route('app.education.store') }}">
        @csrf
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Kurs nomi</label>
            <input type="text" name="title" class="form-control" required value="{{ old('title') }}" placeholder="Masalan: Python dasturlash asoslari">
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Kategoriya</label>
            <select name="category" class="form-control" required>
                <option value="">Tanlang...</option>
                <option value="dasturlash" {{ old('category') == 'dasturlash' ? 'selected' : '' }}>💻 Dasturlash</option>
                <option value="dizayn" {{ old('category') == 'dizayn' ? 'selected' : '' }}>🎨 Dizayn</option>
                <option value="marketing" {{ old('category') == 'marketing' ? 'selected' : '' }}>📢 Marketing</option>
                <option value="biznes" {{ old('category') == 'biznes' ? 'selected' : '' }}>💼 Biznes</option>
                <option value="tillar" {{ old('category') == 'tillar' ? 'selected' : '' }}>🌍 Tillar</option>
                <option value="boshqa" {{ old('category') == 'boshqa' ? 'selected' : '' }}>📚 Boshqa</option>
            </select>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Tavsif</label>
            <textarea name="description" class="form-control" rows="4" required placeholder="Kurs haqida batafsil yozing">{{ old('description') }}</textarea>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Narxi (AIS)</label>
            <input type="number" name="price" class="form-control" required min="0" step="0.01" value="{{ old('price') }}" placeholder="0 = bepul">
        </div>
        <div class="alert alert-info" style="margin-bottom:14px;">
            <i class="fa fa-info-circle"></i> Kurs "draft" holatda yaratiladi. Admin tasdiqlangandan keyin nashr etiladi.
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;">
            <i class="fa fa-plus"></i> Kurs yaratish
        </button>
    </form>
</div>

@endsection
