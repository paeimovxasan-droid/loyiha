@extends('front.layouts.app')
@section('title', 'Roadmap')
@section('content')

<div class="page-title">🗺️ Roadmap</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<div style="display:flex; flex-direction:column; gap:14px;">
@forelse($modules as $module)
<div class="card">
    <div style="padding:20px;">
        {{-- Header --}}
        <div style="display:flex; align-items:center; gap:14px; margin-bottom:14px;">
            <div style="width:48px; height:48px; border-radius:14px; background:rgba(99,102,241,.1);
                        display:flex; align-items:center; justify-content:center; font-size:22px; flex-shrink:0;">
                {{ $module->icon ?? '📦' }}
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-size:15px; font-weight:700; color:#f1f5f9;">{{ $module->title }}</div>
                <span style="display:inline-block; font-size:11px; font-weight:600; padding:3px 10px;
                             border-radius:20px; color:#fff; background:{{ $module->status_color }};">
                    {{ $module->status_label }}
                </span>
            </div>
        </div>

        {{-- Description --}}
        @if($module->description)
        <div style="font-size:13px; color:var(--gray); margin-bottom:14px; line-height:1.5;">
            {{ $module->description }}
        </div>
        @endif

        {{-- Progress bar --}}
        <div style="margin-bottom:14px;">
            <div style="display:flex; justify-content:space-between; font-size:11px; color:var(--gray); margin-bottom:6px;">
                <span>Progress</span>
                <span>{{ $module->progress_percent ?? 0 }}%</span>
            </div>
            <div style="height:6px; background:var(--dark-3); border-radius:3px; overflow:hidden;">
                <div style="height:100%; width:{{ $module->progress_percent ?? 0 }}%;
                            background:linear-gradient(90deg, var(--primary), var(--secondary));
                            border-radius:3px; transition:width .3s;"></div>
            </div>
        </div>

        {{-- Vote --}}
        <div style="display:flex; align-items:center; justify-content:space-between;">
            <div style="font-size:12px; color:var(--gray);">
                <i class="fa fa-thumbs-up"></i> {{ $module->votes_count ?? 0 }} ovoz
            </div>
            <form method="POST" action="{{ route('app.roadmap.vote', $module->id) }}">
                @csrf
                <button type="submit" class="btn btn-primary" style="font-size:12px; padding:6px 16px;">
                    @if(in_array($module->id, $votedIds))
                        <i class="fa fa-check"></i> Ovoz berilgan
                    @else
                        <i class="fa fa-thumbs-up"></i> Ovoz berish
                    @endif
                </button>
            </form>
        </div>
    </div>
</div>
@empty
<div class="card" style="padding:50px; text-align:center; color:var(--gray);">
    <i class="fa fa-map" style="font-size:40px; opacity:.3; display:block; margin-bottom:14px;"></i>
    Hozircha roadmap mavjud emas
</div>
@endforelse
</div>

@endsection
