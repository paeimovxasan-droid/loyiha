<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>Internetga ulanish yo'q — AISOQQA</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Inter', sans-serif;
            background: #0f172a;
            color: #e2e8f0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }
        .container {
            text-align: center;
            max-width: 320px;
        }
        .icon {
            font-size: 72px;
            margin-bottom: 24px;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        h1 {
            font-size: 22px;
            font-weight: 800;
            color: #f1f5f9;
            margin-bottom: 12px;
        }
        p {
            font-size: 14px;
            color: #64748b;
            line-height: 1.6;
            margin-bottom: 32px;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 14px 28px;
            background: linear-gradient(135deg, #6366f1, #8b5cf6);
            color: #fff;
            border: none;
            border-radius: 14px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            font-family: inherit;
            transition: all .2s;
            text-decoration: none;
        }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(99,102,241,.4); }
        .status {
            margin-top: 24px;
            font-size: 12px;
            color: #475569;
        }
        .status.online { color: #34d399; }
    </style>
</head>
<body>
    <div class="container">
        <div class="icon">📡</div>
        <h1>Internet aloqasi yo'q</h1>
        <p>
            Hozirda internetga ulanish mavjud emas.<br>
            Aloqani tekshirib, qaytadan urinib ko'ring.
        </p>
        <button class="btn" onclick="tryReconnect()">
            🔄 Qayta urinish
        </button>
        <div class="status" id="statusText">Ulanish tekshirilmoqda...</div>
    </div>

    <script>
        function tryReconnect() {
            if (navigator.onLine) {
                window.location.href = '/app';
            } else {
                document.getElementById('statusText').textContent = 'Hali ham internet yo\'q. Iltimos, kuting.';
            }
        }

        window.addEventListener('online', () => {
            document.getElementById('statusText').textContent = '✅ Internet tiklandi! Yo\'naltirilmoqda...';
            document.getElementById('statusText').className = 'status online';
            setTimeout(() => window.location.href = '/app', 1000);
        });

        window.addEventListener('offline', () => {
            document.getElementById('statusText').textContent = '❌ Internet yo\'q';
        });

        // Dastlabki holat
        document.getElementById('statusText').textContent = navigator.onLine
            ? '✅ Internet bor — sahifa yangilanmoqda...'
            : '❌ Internet yo\'q';

        if (navigator.onLine) {
            setTimeout(() => window.location.href = '/app', 500);
        }
    </script>
</body>
</html>
