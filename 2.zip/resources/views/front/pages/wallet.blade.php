@extends('front.layouts.app')
@section('title', 'AIS Hamyon')
@section('content')

{{-- Header --}}
<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:18px;">
    <div class="page-title" style="margin-bottom:0;">💎 AIS Hamyon</div>
    <div style="font-size:11px; color:var(--gray); text-align:right;">
        <div>1 AIS = <strong style="color:#818cf8;">{{ number_format($rate->rate_uzs, 0) }} UZS</strong></div>
        <div style="margin-top:2px;">Sotib olish: {{ number_format($rate->buy_rate, 0) }} | Sotish: {{ number_format($rate->sell_rate, 0) }}</div>
    </div>
</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

{{-- Hamyon kartasi --}}
<div style="background: linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #4c1d95 100%);
            border-radius: 24px; padding: 24px; margin-bottom: 20px; position:relative; overflow:hidden;">
    <div style="position:absolute; top:-40px; right:-30px; width:160px; height:160px;
                border-radius:50%; background:rgba(255,255,255,.05);"></div>
    <div style="position:absolute; bottom:-50px; left:-20px; width:120px; height:120px;
                border-radius:50%; background:rgba(255,255,255,.04);"></div>

    <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:20px;">
        <div style="font-size:12px; color:rgba(255,255,255,.5); font-weight:600; letter-spacing:.5px;">
            AISOQQA WALLET
        </div>
        <div style="font-size:20px;">💎</div>
    </div>

    <div style="font-size:13px; color:rgba(255,255,255,.5); margin-bottom:4px;">Hamyon raqami</div>
    <div style="font-size:16px; font-weight:700; color:#c7d2fe; letter-spacing:2px; margin-bottom:20px;">
        {{ $wallet->wallet_number }}
    </div>

    <div style="font-size:12px; color:rgba(255,255,255,.5); margin-bottom:4px;">Balans</div>
    <div style="font-size:34px; font-weight:800; color:#fff; letter-spacing:-1px;">
        {{ number_format($wallet->balance ?? 0, 4) }}
        <span style="font-size:16px; font-weight:500; color:rgba(255,255,255,.5);">AIS</span>
    </div>
    <div style="font-size:13px; color:rgba(255,255,255,.4); margin-top:4px;">
        ≈ {{ number_format(($wallet->balance ?? 0) * ($rate->sell_rate ?? 0), 0) }} UZS
    </div>

    @if($wallet->frozen_balance > 0)
    <div style="margin-top:10px; font-size:12px; color:#fbbf24;">
        <i class="fa fa-lock"></i> Muzlatilgan: {{ number_format($wallet->frozen_balance, 4) }} AIS
    </div>
    @endif
</div>

{{-- Tezkor amallar --}}
<div class="grid grid-2" style="margin-bottom:20px; gap:10px;">
    <button onclick="openTab('transfer')"
            style="background:rgba(99,102,241,.15); border:1px solid rgba(99,102,241,.3);
                   border-radius:16px; padding:16px; color:#818cf8; font-size:13px;
                   font-weight:600; cursor:pointer; display:flex; flex-direction:column;
                   align-items:center; gap:8px; font-family:inherit; transition:all .2s;"
            onmouseenter="this.style.background='rgba(99,102,241,.25)'"
            onmouseleave="this.style.background='rgba(99,102,241,.15)'">
        <i class="fa fa-paper-plane" style="font-size:22px;"></i>
        O'tkazma
    </button>
    <button onclick="openTab('convert')"
            style="background:rgba(16,185,129,.12); border:1px solid rgba(16,185,129,.25);
                   border-radius:16px; padding:16px; color:#34d399; font-size:13px;
                   font-weight:600; cursor:pointer; display:flex; flex-direction:column;
                   align-items:center; gap:8px; font-family:inherit; transition:all .2s;"
            onmouseenter="this.style.background='rgba(16,185,129,.22)'"
            onmouseleave="this.style.background='rgba(16,185,129,.12)'">
        <i class="fa fa-arrows-rotate" style="font-size:22px;"></i>
        Konvertatsiya
    </button>
</div>

{{-- P2P Transfer paneli --}}
<div id="tab-transfer" style="display:none; margin-bottom:20px;">
    <div class="card">
        <div class="card-header">
            <span class="card-title"><i class="fa fa-paper-plane"></i> P2P O'tkazma</span>
            @if(!$p2pUnlocked)
            <span class="badge badge-warning"><i class="fa fa-lock"></i> Level 5 kerak</span>
            @endif
        </div>
        <div class="card-body">
            @if($p2pUnlocked)
            <form method="POST" action="{{ route('app.wallet.transfer') }}">
                @csrf
                <div class="form-group">
                    <label class="form-label">Qabul qiluvchi (username yoki AIS-XXXX-XXXX-XXXX)</label>
                    <input type="text" name="receiver" required
                           class="form-control" placeholder="username yoki AIS-1234-5678-9012">
                </div>
                <div class="form-group">
                    <label class="form-label">Miqdor (AIS)</label>
                    <input type="number" name="amount" step="0.0001" min="0.0001" required
                           class="form-control" placeholder="0.0000"
                           oninput="calcTransferFee(this.value)">
                    <div id="transferFeeInfo" style="font-size:12px; color:var(--gray); margin-top:6px;"></div>
                </div>
                <div class="form-group">
                    <label class="form-label">Izoh (ixtiyoriy)</label>
                    <input type="text" name="note" class="form-control" placeholder="To'lov uchun...">
                </div>
                <button type="submit" class="btn btn-primary btn-full">
                    <i class="fa fa-paper-plane"></i> O'tkazish
                </button>
            </form>
            @else
            <div style="text-align:center; padding:20px; color:var(--gray);">
                <i class="fa fa-lock" style="font-size:32px; opacity:.3; display:block; margin-bottom:10px;"></i>
                P2P transfer <strong style="color:#fbbf24;">Level 5</strong> dan ochiladi.<br>
                <small>Hozirgi darajangiz: Level {{ $level->level }}</small>
            </div>
            @endif
        </div>
    </div>
</div>

{{-- Konvertatsiya paneli --}}
<div id="tab-convert" style="display:none; margin-bottom:20px;">
    <div class="card">
        <div class="card-header">
            <span class="card-title"><i class="fa fa-arrows-rotate"></i> Konvertatsiya</span>
        </div>
        <div class="card-body">
            {{-- UZS → AIS --}}
            <div style="margin-bottom:16px; padding:14px; background:rgba(99,102,241,.06);
                        border:1px solid rgba(99,102,241,.15); border-radius:14px;">
                <div style="font-size:12px; color:var(--gray); margin-bottom:10px; font-weight:600;">
                    UZS → AIS (Sotib olish)
                </div>
                <form method="POST" action="{{ route('app.wallet.convert') }}">
                    @csrf
                    <input type="hidden" name="direction" value="buy">
                    <div style="display:flex; gap:8px;">
                        <input type="number" name="amount" min="1000" step="1000" required
                               class="form-control" placeholder="UZS miqdori"
                               oninput="calcBuy(this.value)" style="flex:1;">
                        <button type="submit" class="btn btn-primary" style="white-space:nowrap;">
                            <i class="fa fa-arrow-right"></i> AIS ol
                        </button>
                    </div>
                    <div id="buyInfo" style="font-size:12px; color:#818cf8; margin-top:6px;"></div>
                </form>
            </div>

            {{-- AIS → UZS --}}
            <div style="padding:14px; background:rgba(16,185,129,.06);
                        border:1px solid rgba(16,185,129,.15); border-radius:14px;">
                <div style="font-size:12px; color:var(--gray); margin-bottom:10px; font-weight:600;">
                    AIS → UZS (Sotish)
                </div>
                <form method="POST" action="{{ route('app.wallet.convert') }}">
                    @csrf
                    <input type="hidden" name="direction" value="sell">
                    <div style="display:flex; gap:8px;">
                        <input type="number" name="amount" min="0.0001" step="0.0001" required
                               class="form-control" placeholder="AIS miqdori"
                               oninput="calcSell(this.value)" style="flex:1;">
                        <button type="submit" class="btn btn-success" style="white-space:nowrap;">
                            <i class="fa fa-arrow-right"></i> UZS ol
                        </button>
                    </div>
                    <div id="sellInfo" style="font-size:12px; color:#34d399; margin-top:6px;"></div>
                </form>
            </div>
        </div>
    </div>
</div>

{{-- Virtual kartalar --}}
<p class="section-label">Virtual Kartalar</p>
<div style="margin-bottom:20px;">
    @forelse($cards as $card)
    <div style="background: linear-gradient(135deg,
                {{ $card->isFrozen() ? '#1e293b, #334155' : '#0f172a, #1e1b4b' }});
                border-radius:20px; padding:20px; margin-bottom:12px;
                border:1px solid {{ $card->isFrozen() ? 'rgba(239,68,68,.2)' : 'rgba(99,102,241,.2)' }};
                position:relative; overflow:hidden;">
        <div style="position:absolute; top:-20px; right:-20px; width:100px; height:100px;
                    border-radius:50%; background:rgba(255,255,255,.03);"></div>

        @if($card->isFrozen())
        <div style="position:absolute; top:12px; right:12px;">
            <span class="badge badge-danger"><i class="fa fa-snowflake"></i> Muzlatilgan</span>
        </div>
        @endif

        <div style="font-size:11px; color:rgba(255,255,255,.4); margin-bottom:14px; letter-spacing:1px;">
            AISOQQA VIRTUAL CARD
        </div>
        <div style="font-size:18px; font-weight:700; color:#e2e8f0; letter-spacing:3px; margin-bottom:16px;">
            {{ $card->formatted_number }}
        </div>
        <div style="display:flex; justify-content:space-between; align-items:flex-end;">
            <div>
                <div style="font-size:10px; color:rgba(255,255,255,.4);">KARTA EGASI</div>
                <div style="font-size:13px; font-weight:600; color:#e2e8f0;">{{ $card->card_holder }}</div>
            </div>
            <div style="text-align:right;">
                <div style="font-size:10px; color:rgba(255,255,255,.4);">MUDDAT</div>
                <div style="font-size:13px; font-weight:600; color:#e2e8f0;">{{ $card->expiry }}</div>
            </div>
        </div>

        <div style="margin-top:14px; display:flex; gap:8px;">
            <form method="POST" action="{{ route('app.wallet.card.freeze', $card) }}" style="flex:1;">
                @csrf
                <button type="submit" class="btn btn-sm btn-full"
                        style="background:rgba(255,255,255,.08); color:rgba(255,255,255,.6); border:none;">
                    <i class="fa fa-{{ $card->isFrozen() ? 'play' : 'snowflake' }}"></i>
                    {{ $card->isFrozen() ? 'Faollashtirish' : 'Muzlatish' }}
                </button>
            </form>
        </div>
    </div>
    @empty
    <div class="card" style="padding:30px; text-align:center; color:var(--gray);">
        <i class="fa fa-credit-card" style="font-size:32px; opacity:.3; display:block; margin-bottom:10px;"></i>
        @if($cardUnlocked)
            Hali karta yo'q.
        @else
            Virtual karta <strong style="color:#fbbf24;">Level 10</strong> dan ochiladi.
            <br><small>Hozirgi: Level {{ $level->level }}</small>
        @endif
    </div>
    @endforelse

    @if($cardUnlocked && $cards->count() < 3)
    <a href="{{ route('app.wallet.card.create') }}" class="btn btn-outline btn-full" style="margin-top:8px;">
        <i class="fa fa-plus"></i> Yangi karta yaratish
    </a>
    @endif
</div>

{{-- So'nggi o'tkazmalar --}}
<p class="section-label">So'nggi o'tkazmalar</p>
<div class="card" style="margin-bottom:20px;">
    @forelse($recentTransfers as $item)
    @php $t = $item['item']; $isSent = $item['type'] === 'sent'; @endphp
    <div class="list-item">
        <div style="width:42px; height:42px; border-radius:12px; flex-shrink:0;
                    background:{{ $isSent ? 'rgba(239,68,68,.1)' : 'rgba(16,185,129,.1)' }};
                    display:flex; align-items:center; justify-content:center;">
            <i class="fa fa-{{ $isSent ? 'arrow-up-right' : 'arrow-down-left' }}"
               style="color:{{ $isSent ? '#f87171' : '#34d399' }}; font-size:15px;"></i>
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:500; color:#e2e8f0;">
                {{ $isSent ? '@'.$t->receiver?->username : '@'.$t->sender?->username }}
            </div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">
                {{ $t->reference }} · {{ $t->created_at->format('d.m.Y H:i') }}
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:14px; font-weight:700; color:{{ $isSent ? '#f87171' : '#34d399' }};">
                {{ $isSent ? '-' : '+' }}{{ number_format($t->amount, 4) }} AIS
            </div>
            @if($isSent && $t->fee > 0)
            <div style="font-size:10px; color:var(--gray);">komissiya: {{ number_format($t->fee, 4) }}</div>
            @endif
        </div>
    </div>
    @empty
    <div style="padding:30px; text-align:center; color:var(--gray); font-size:13px;">
        <i class="fa fa-paper-plane" style="font-size:28px; opacity:.3; display:block; margin-bottom:10px;"></i>
        Hali o'tkazma yo'q
    </div>
    @endforelse
</div>

@endsection

@section('scripts')
<script>
const RATE_BUY  = {{ $rate->buy_rate }};
const RATE_SELL = {{ $rate->sell_rate }};
const FEE_PCT   = 0.5; // transfer fee %

function openTab(name) {
    ['transfer','convert'].forEach(t => {
        document.getElementById('tab-' + t).style.display = (t === name) ? 'block' : 'none';
    });
}

function calcTransferFee(val) {
    const amount = parseFloat(val) || 0;
    const fee = (amount * FEE_PCT / 100).toFixed(4);
    const total = (amount + parseFloat(fee)).toFixed(4);
    document.getElementById('transferFeeInfo').textContent =
        amount > 0 ? `Komissiya: ${fee} AIS | Jami yechiladi: ${total} AIS` : '';
}

function calcBuy(val) {
    const uzs = parseFloat(val) || 0;
    const ais = (uzs / RATE_BUY).toFixed(4);
    document.getElementById('buyInfo').textContent =
        uzs > 0 ? `≈ ${ais} AIS olasiz` : '';
}

function calcSell(val) {
    const ais = parseFloat(val) || 0;
    const uzs = Math.round(ais * RATE_SELL).toLocaleString();
    document.getElementById('sellInfo').textContent =
        ais > 0 ? `≈ ${uzs} UZS olasiz` : '';
}
</script>
@endsection
