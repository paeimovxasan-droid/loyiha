@extends('front.layouts.app')

@section('title', __('front.dashboard.title'))

@section('content')

{{-- Welcome & Level --}}
<div style="margin-bottom: 16px;">
    <div style="display: flex; align-items: center; justify-content: space-between;">
        <div>
            <div style="font-size: 12px; color: var(--text-muted); margin-bottom: 2px;">{{ __('front.dashboard.welcome') }} 👋</div>
            <div style="font-size: 20px; font-weight: 700; color: var(--text-primary); letter-spacing: -.3px;">
                {{ auth()->user()->name }}
            </div>
        </div>
        @php $ul = auth()->user()->userLevel; @endphp
        @if($ul)
        <a href="{{ route('app.level') }}" style="text-decoration: none;">
            <div style="display: flex; align-items: center; gap: 8px; background: {{ $ul->badge_color }}12;
                        border: 1px solid {{ $ul->badge_color }}25; border-radius: var(--radius-sm); padding: 6px 10px;">
                <span style="font-size: 16px;">{{ \App\Models\Level\UserLevel::getTitleColorAndIcon($ul->level)[2] ?? '🌱' }}</span>
                <div>
                    <div style="font-size: 11px; font-weight: 700; color: {{ $ul->badge_color }};">Lv.{{ $ul->level }}</div>
                    <div style="font-size: 10px; color: var(--text-muted);">{{ number_format($ul->total_xp) }} XP</div>
                </div>
            </div>
        </a>
        @endif
    </div>
</div>

{{-- Daily Check-in --}}
@php $todayCheckIn = \App\Models\Game\CheckIn::todayFor(auth()->id()); @endphp
@if(!$todayCheckIn)
<form method="POST" action="{{ route('app.checkin') }}" style="margin-bottom: 14px;">
    @csrf
    <button type="submit" style="width: 100%; background: linear-gradient(135deg, rgba(245,158,11,.08), rgba(245,158,11,.04));
            border: 1px solid rgba(245,158,11,.2); border-radius: var(--radius-md); padding: 12px 16px;
            display: flex; align-items: center; gap: 12px; cursor: pointer; font-family: inherit;
            transition: all .2s;" class="btn-hover-lift">
        <div style="width: 40px; height: 40px; border-radius: 10px; background: rgba(245,158,11,.12);
                    display: flex; align-items: center; justify-content: center; font-size: 20px;">🎁</div>
        <div style="text-align: left; flex: 1;">
            <div style="font-size: 13px; font-weight: 700; color: #fbbf24;">Kunlik belgilash</div>
            <div style="font-size: 11px; color: var(--text-muted); margin-top: 1px;">Bosing va bonus oling!</div>
        </div>
        <div style="font-size: 12px; color: #fbbf24; font-weight: 600;">
            +XP <i class="fa fa-chevron-right" style="font-size: 10px; margin-left: 4px;"></i>
        </div>
    </button>
</form>
@else
<div style="margin-bottom: 14px; background: rgba(16,185,129,.06); border: 1px solid rgba(16,185,129,.15);
            border-radius: var(--radius-md); padding: 12px 16px; display: flex; align-items: center; gap: 10px;">
    <div style="font-size: 18px;">✅</div>
    <div style="flex: 1;">
        <div style="font-size: 12px; font-weight: 600; color: #34d399;">Bugun belgiladingiz!</div>
        <div style="font-size: 11px; color: var(--text-muted);">Streak: {{ $todayCheckIn->streak }} kun 🔥</div>
    </div>
</div>
@endif

{{-- Balance Card --}}
<div style="background: linear-gradient(135deg, #312e81 0%, #4c1d95 50%, #581c87 100%);
            border-radius: var(--radius-xl); padding: 22px; margin-bottom: 16px; position: relative; overflow: hidden;">
    {{-- Decorative elements --}}
    <div style="position: absolute; top: -20px; right: -10px; width: 100px; height: 100px;
                border-radius: 50%; background: rgba(255,255,255,.05);"></div>
    <div style="position: absolute; bottom: -30px; left: 20px; width: 80px; height: 80px;
                border-radius: 50%; background: rgba(255,255,255,.03);"></div>
    <div style="position: absolute; top: 50%; right: 30%; width: 60px; height: 60px;
                border-radius: 50%; background: rgba(255,255,255,.02);"></div>

    <div style="position: relative; z-index: 1;">
        <div style="font-size: 11px; font-weight: 600; color: rgba(255,255,255,.55); text-transform: uppercase;
                    letter-spacing: .8px; margin-bottom: 6px;">
            {{ __('front.dashboard.total_balance') }}
        </div>
        <div style="font-size: 28px; font-weight: 800; color: #fff; letter-spacing: -1px; margin-bottom: 4px;">
            {{ number_format($stats['balance'], 0) }}
            <span style="font-size: 14px; font-weight: 500; opacity: .6; margin-left: 2px;">UZS</span>
        </div>

        @if($ul)
        <div style="margin-bottom: 16px;">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px;">
                <span style="font-size: 10px; color: rgba(255,255,255,.5);">Level {{ $ul->level }} → {{ $ul->level + 1 }}</span>
                <span style="font-size: 10px; color: rgba(255,255,255,.5);">{{ $ul->progress_percent }}%</span>
            </div>
            <div style="height: 3px; background: rgba(255,255,255,.1); border-radius: 4px; overflow: hidden;">
                <div style="height: 100%; width: {{ $ul->progress_percent }}%; background: linear-gradient(90deg, #818cf8, #c084fc);
                            border-radius: 4px; transition: width .5s;"></div>
            </div>
        </div>
        @endif

        <div style="display: flex; gap: 8px;">
            <a href="{{ route('app.deposit') }}"
               style="flex: 1; background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.15);
                      border-radius: var(--radius-sm); padding: 10px; text-align: center; color: #fff;
                      text-decoration: none; font-size: 12px; font-weight: 600; transition: all .2s;
                      display: flex; align-items: center; justify-content: center; gap: 5px;
                      backdrop-filter: blur(4px);">
                <i class="fa fa-plus" style="font-size: 11px;"></i> {{ __('front.dashboard.deposit_btn') }}
            </a>
            <a href="{{ route('app.withdraw') }}"
               style="flex: 1; background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.15);
                      border-radius: var(--radius-sm); padding: 10px; text-align: center; color: #fff;
                      text-decoration: none; font-size: 12px; font-weight: 600; transition: all .2s;
                      display: flex; align-items: center; justify-content: center; gap: 5px;
                      backdrop-filter: blur(4px);">
                <i class="fa fa-arrow-up" style="font-size: 11px;"></i> {{ __('front.dashboard.withdraw_btn') }}
            </a>
            <a href="{{ route('app.wallet') }}"
               style="flex: 1; background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.15);
                      border-radius: var(--radius-sm); padding: 10px; text-align: center; color: #fff;
                      text-decoration: none; font-size: 12px; font-weight: 600; transition: all .2s;
                      display: flex; align-items: center; justify-content: center; gap: 5px;
                      backdrop-filter: blur(4px);">
                <i class="fa fa-wallet" style="font-size: 11px;"></i> AIS
            </a>
        </div>
    </div>
</div>

{{-- Stats Grid --}}
<div class="grid grid-3" style="margin-bottom: 16px;">
    <div class="stat-card" style="--stat-color: #10b981;">
        <div class="stat-icon" style="background: rgba(16,185,129,.1); color: #34d399;">
            <i class="fa fa-chart-line"></i>
        </div>
        <div class="stat-value">{{ number_format($stats['total_earn'], 0) }}</div>
        <div class="stat-label">Daromad</div>
    </div>
    <div class="stat-card" style="--stat-color: #6366f1;">
        <div class="stat-icon" style="background: rgba(99,102,241,.1); color: #a5b4fc;">
            <i class="fa fa-arrow-down"></i>
        </div>
        <div class="stat-value">{{ number_format($stats['total_deposit'], 0) }}</div>
        <div class="stat-label">Depozit</div>
    </div>
    <div class="stat-card" style="--stat-color: #f59e0b;">
        <div class="stat-icon" style="background: rgba(245,158,11,.1); color: #fbbf24;">
            <i class="fa fa-users"></i>
        </div>
        <div class="stat-value">{{ $stats['total_ref'] }}</div>
        <div class="stat-label">Referral</div>
    </div>
</div>

{{-- Active Packages --}}
@if($activePurchases->count())
<div class="card" style="margin-bottom: 16px;">
    <div class="card-header">
        <div class="card-title"><i class="fa fa-cube"></i> Faol paketlar</div>
        <a href="{{ route('app.packages') }}" style="font-size: 12px; color: var(--primary-light); text-decoration: none; font-weight: 500;">
            Barchasi <i class="fa fa-chevron-right" style="font-size: 9px;"></i>
        </a>
    </div>
    <div style="padding: 4px 0;">
        @foreach($activePurchases->take(3) as $purchase)
        <div class="list-item">
            <div style="width: 38px; height: 38px; border-radius: 10px; background: linear-gradient(135deg, rgba(99,102,241,.15), rgba(139,92,246,.1));
                        display: flex; align-items: center; justify-content: center;">
                <i class="fa fa-gem" style="color: var(--primary-light); font-size: 14px;"></i>
            </div>
            <div style="flex: 1; min-width: 0;">
                <div style="font-size: 13px; font-weight: 600; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                    {{ $purchase->package->name }}
                </div>
                <div style="font-size: 11px; color: var(--text-muted); margin-top: 1px;">
                    {{ $purchase->package->daily_profit_percent }}% kunlik
                </div>
            </div>
            <div style="text-align: right;">
                <div style="font-size: 13px; font-weight: 700; color: #34d399;">
                    +{{ number_format($purchase->package->calcDailyProfit($purchase->amount), 0) }}
                </div>
                <div style="font-size: 10px; color: var(--text-muted);">UZS/kun</div>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif

{{-- Quick Services --}}
<div style="margin-bottom: 16px;">
    <div class="section-label">Xizmatlar</div>
    <div class="grid grid-4" style="gap: 10px;">
        @php
            $services = [
                ['route' => 'app.packages', 'icon' => 'fa-cube', 'label' => 'Paketlar', 'color' => '#6366f1'],
                ['route' => 'app.funds', 'icon' => 'fa-chart-pie', 'label' => 'Fondlar', 'color' => '#8b5cf6'],
                ['route' => 'app.wallet', 'icon' => 'fa-wallet', 'label' => 'AIS Hamyon', 'color' => '#818cf8'],
                ['route' => 'app.referrals', 'icon' => 'fa-user-plus', 'label' => 'Referral', 'color' => '#06b6d4'],
                ['route' => 'app.tasks', 'icon' => 'fa-clipboard-check', 'label' => 'Vazifalar', 'color' => '#10b981'],
                ['route' => 'app.quests', 'icon' => 'fa-scroll', 'label' => 'Kvestlar', 'color' => '#f59e0b'],
                ['route' => 'app.lucky_draw', 'icon' => 'fa-ticket', 'label' => 'Lotereya', 'color' => '#ec4899'],
                ['route' => 'app.spin_wheel', 'icon' => 'fa-dharmachakra', 'label' => 'Spin', 'color' => '#14b8a6'],
                ['route' => 'app.exchange', 'icon' => 'fa-arrow-right-arrow-left', 'label' => 'Birja', 'color' => '#f97316'],
                ['route' => 'app.credit', 'icon' => 'fa-hand-holding-dollar', 'label' => 'Kredit', 'color' => '#ef4444'],
                ['route' => 'app.savings', 'icon' => 'fa-piggy-bank', 'label' => "Jamg'arma", 'color' => '#22c55e'],
                ['route' => 'app.crowdfunding', 'icon' => 'fa-heart', 'label' => 'Xayriya', 'color' => '#e11d48'],
                ['route' => 'app.education', 'icon' => 'fa-graduation-cap', 'label' => "Ta'lim", 'color' => '#3b82f6'],
                ['route' => 'app.marketplace', 'icon' => 'fa-store', 'label' => 'Marketplace', 'color' => '#8b5cf6'],
                ['route' => 'app.catalog', 'icon' => 'fa-shopping-bag', 'label' => 'Katalog', 'color' => '#a855f7'],
                ['route' => 'app.gig', 'icon' => 'fa-briefcase', 'label' => 'Gig', 'color' => '#0ea5e9'],
                ['route' => 'app.agromarket', 'icon' => 'fa-seedling', 'label' => 'AgroMarket', 'color' => '#84cc16'],
                ['route' => 'app.lending', 'icon' => 'fa-handshake', 'label' => 'P2P Qarz', 'color' => '#d946ef'],
                ['route' => 'app.medical.index', 'icon' => 'fa-stethoscope', 'label' => 'Tibbiyot', 'color' => '#10b981'],
                ['route' => 'app.ai', 'icon' => 'fa-robot', 'label' => 'AI Yordamchi', 'color' => '#6366f1'],
                ['route' => 'app.roadmap', 'icon' => 'fa-road', 'label' => 'Roadmap', 'color' => '#64748b'],
                ['route' => 'app.influencer.dashboard', 'icon' => 'fa-bullhorn', 'label' => 'Influencer', 'color' => '#f43f5e'],
                ['route' => 'app.support.index', 'icon' => 'fa-headset', 'label' => 'Yordam', 'color' => '#0891b2'],
                ['route' => 'app.transactions', 'icon' => 'fa-clock-rotate-left', 'label' => 'Tarix', 'color' => '#475569'],
            ];
        @endphp
        @foreach($services as $svc)
        <a href="{{ route($svc['route']) }}"
           style="display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 12px 4px;
                  background: var(--bg-card); border: 1px solid var(--border-primary); border-radius: var(--radius-md);
                  text-decoration: none; transition: all .2s;"
           onmouseenter="this.style.borderColor='{{ $svc['color'] }}30'; this.style.transform='translateY(-2px)'"
           onmouseleave="this.style.borderColor='var(--border-primary)'; this.style.transform='translateY(0)'">
            <div style="width: 36px; height: 36px; border-radius: 10px; background: {{ $svc['color'] }}15;
                        display: flex; align-items: center; justify-content: center;">
                <i class="fa {{ $svc['icon'] }}" style="color: {{ $svc['color'] }}; font-size: 14px;"></i>
            </div>
            <span style="font-size: 10px; font-weight: 600; color: var(--text-secondary); text-align: center;">{{ $svc['label'] }}</span>
        </a>
        @endforeach
    </div>
</div>

{{-- Recent Transactions --}}
<div class="card">
    <div class="card-header">
        <div class="card-title"><i class="fa fa-clock-rotate-left"></i> So'nggi operatsiyalar</div>
        <a href="{{ route('app.transactions') }}" style="font-size: 12px; color: var(--primary-light); text-decoration: none; font-weight: 500;">
            Barchasi <i class="fa fa-chevron-right" style="font-size: 9px;"></i>
        </a>
    </div>
    @if($recentTransactions->count())
    <div style="padding: 4px 0;">
        @foreach($recentTransactions as $tx)
        <div class="list-item">
            <div style="width: 36px; height: 36px; border-radius: 10px;
                        background: {{ $tx->isCredit() ? 'rgba(16,185,129,.1)' : 'rgba(239,68,68,.1)' }};
                        display: flex; align-items: center; justify-content: center;">
                <i class="fa {{ $tx->isCredit() ? 'fa-arrow-down' : 'fa-arrow-up' }}"
                   style="color: {{ $tx->isCredit() ? '#34d399' : '#f87171' }}; font-size: 13px;"></i>
            </div>
            <div style="flex: 1; min-width: 0;">
                <div style="font-size: 13px; font-weight: 500; color: var(--text-primary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">
                    {{ $tx->description ?: ucfirst($tx->type) }}
                </div>
                <div style="font-size: 11px; color: var(--text-muted); margin-top: 1px;">
                    {{ $tx->created_at->diffForHumans() }}
                </div>
            </div>
            <div style="font-size: 13px; font-weight: 700; color: {{ $tx->isCredit() ? '#34d399' : '#f87171' }};">
                {{ $tx->isCredit() ? '+' : '-' }}{{ number_format($tx->amount, 0) }}
            </div>
        </div>
        @endforeach
    </div>
    @else
    <div class="empty-state">
        <div class="empty-state-icon"><i class="fa fa-receipt"></i></div>
        <div class="empty-state-title">Operatsiyalar yo'q</div>
        <div class="empty-state-text">Birinchi depozitingizni qiling</div>
    </div>
    @endif
</div>

{{-- Referral Link --}}
<div style="margin-top: 16px; background: linear-gradient(135deg, rgba(6,182,212,.06), rgba(99,102,241,.06));
            border: 1px solid rgba(6,182,212,.15); border-radius: var(--radius-lg); padding: 16px;">
    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
        <div style="width: 36px; height: 36px; border-radius: 10px; background: rgba(6,182,212,.12);
                    display: flex; align-items: center; justify-content: center;">
            <i class="fa fa-share-nodes" style="color: #22d3ee; font-size: 14px;"></i>
        </div>
        <div>
            <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">Do'stlarni taklif qiling</div>
            <div style="font-size: 11px; color: var(--text-muted);">Har bir referral uchun bonus oling</div>
        </div>
    </div>
    <div style="display: flex; gap: 8px;">
        <div style="flex: 1; background: rgba(255,255,255,.04); border: 1px solid var(--border-primary);
                    border-radius: 8px; padding: 8px 12px; font-size: 12px; color: var(--text-secondary);
                    overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" id="refLink">
            {{ url('/register/' . auth()->user()->username) }}
        </div>
        <button onclick="copyRefLink()" class="btn btn-sm btn-primary" style="flex-shrink: 0;">
            <i class="fa fa-copy"></i>
        </button>
    </div>
</div>

<script>
function copyRefLink() {
    const link = document.getElementById('refLink').textContent.trim();
    navigator.clipboard.writeText(link).then(() => {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = 'toast toast-success';
        toast.innerHTML = '<i class="fa fa-check-circle"></i><span>Havola nusxalandi!</span>';
        container.appendChild(toast);
        setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 300); }, 3000);
    });
}
</script>

@endsection
