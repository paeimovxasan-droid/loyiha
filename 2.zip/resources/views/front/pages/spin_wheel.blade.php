@extends('front.layouts.app')
@section('title', 'Spin Wheel')
@section('content')

<div class="page-title">🎡 Spin Wheel</div>

@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

{{-- G'ildirak --}}
<div style="display:flex; flex-direction:column; align-items:center; margin-bottom:24px;">

    {{-- Pointer --}}
    <div style="width:0; height:0; border-left:12px solid transparent; border-right:12px solid transparent;
                border-top:24px solid #f1f5f9; margin-bottom:-4px; z-index:10; position:relative;
                filter:drop-shadow(0 2px 4px rgba(0,0,0,.4));"></div>

    {{-- Canvas --}}
    <canvas id="spinCanvas" width="300" height="300"
            style="border-radius:50%; box-shadow:0 8px 40px rgba(99,102,241,.3); display:block;"></canvas>

    {{-- Spin tugmasi --}}
    @if($canSpin)
    <form method="POST" action="{{ route('app.spin_wheel.spin') }}" id="spinForm" style="margin-top:20px;">
        @csrf
        <button type="button" id="spinBtn"
                style="padding:14px 48px; border-radius:14px; font-size:16px; font-weight:700;
                       background:linear-gradient(135deg,#6366f1,#8b5cf6); color:#fff;
                       border:none; cursor:pointer; box-shadow:0 6px 24px rgba(99,102,241,.4);
                       transition:all .2s;">
            <i class="fa fa-rotate-right"></i> Aylantirish
        </button>
    </form>
    @else
    <div style="margin-top:20px; text-align:center;">
        <div style="padding:14px 28px; border-radius:14px; background:rgba(255,255,255,.05);
                    border:1px solid rgba(255,255,255,.08); color:var(--gray); font-size:14px;">
            <i class="fa fa-clock"></i> Keyingi spin:
            <strong style="color:#818cf8;">
                {{ $nextSpinAt ? $nextSpinAt->format('d.m.Y 00:00') : 'Ertaga' }}
            </strong>
        </div>
    </div>
    @endif
</div>

{{-- Natija modal --}}
@if(session('spin_result'))
@php $r = session('spin_result'); @endphp
<div id="resultModal"
     style="position:fixed; inset:0; z-index:500; display:flex; align-items:center; justify-content:center;
            background:rgba(0,0,0,.7); backdrop-filter:blur(8px);">
    <div style="background:#0d1225; border:1px solid rgba(99,102,241,.3); border-radius:24px;
                padding:40px 32px; text-align:center; max-width:320px; width:90%;
                box-shadow:0 20px 60px rgba(99,102,241,.3); animation:popIn .4s ease;">
        <div style="font-size:56px; margin-bottom:16px;">
            @if($r['prize_type'] === 'ais') 💰
            @elseif($r['prize_type'] === 'xp') ⭐
            @elseif($r['prize_type'] === 'lucky_ticket') 🎫
            @else 😔
            @endif
        </div>
        <div style="font-size:22px; font-weight:800; color:#f1f5f9; margin-bottom:8px;">
            @if($r['prize_type'] === 'nothing')
                Omad kelmadi!
            @else
                Tabriklaymiz! 🎉
            @endif
        </div>
        <div style="font-size:16px; color:#818cf8; font-weight:600; margin-bottom:20px;">
            @if($r['prize_type'] === 'ais')
                +{{ number_format($r['prize_value'], 2) }} AIS
            @elseif($r['prize_type'] === 'xp')
                +{{ number_format($r['prize_value'], 0) }} XP
            @elseif($r['prize_type'] === 'lucky_ticket')
                1 ta Lucky Draw chiptasi
            @else
                Keyingi safar omad kulib boqar!
            @endif
        </div>
        <button onclick="document.getElementById('resultModal').remove()"
                style="padding:12px 32px; border-radius:12px; background:linear-gradient(135deg,#6366f1,#8b5cf6);
                       color:#fff; font-size:14px; font-weight:700; border:none; cursor:pointer;">
            OK
        </button>
    </div>
</div>
<style>
@keyframes popIn{from{transform:scale(.7);opacity:0}to{transform:scale(1);opacity:1}}
</style>
@endif

{{-- Mukofotlar jadvali --}}
<p class="section-label">Mukofotlar</p>
<div class="card" style="margin-bottom:20px;">
    @forelse($prizes as $prize)
    <div style="display:flex; align-items:center; justify-content:space-between; padding:12px 16px;
                border-bottom:1px solid rgba(255,255,255,.05);">
        <div style="display:flex; align-items:center; gap:12px;">
            <div style="width:14px; height:14px; border-radius:50%; background:{{ $prize->color ?? '#6366f1' }};
                        flex-shrink:0;"></div>
            <div>
                <div style="font-size:13px; font-weight:600; color:#e2e8f0;">
                    @if($prize->type === 'ais') 💰 {{ number_format($prize->value, 2) }} AIS
                    @elseif($prize->type === 'xp') ⭐ {{ number_format($prize->value, 0) }} XP
                    @elseif($prize->type === 'lucky_ticket') 🎫 Lucky Draw chiptasi
                    @else ❌ Hech narsa
                    @endif
                </div>
            </div>
        </div>
        <div style="font-size:11px; color:var(--gray);">
            Ehtimollik: {{ round($prize->weight / max($prizes->sum('weight'), 1) * 100, 1) }}%
        </div>
    </div>
    @empty
    <div style="padding:30px; text-align:center; color:var(--gray);">Mukofotlar sozlanmagan</div>
    @endforelse
</div>

{{-- Tarix --}}
@if($history->count())
<p class="section-label">Spin tarixi</p>
<div class="card">
    @foreach($history as $log)
    <div class="list-item">
        <div style="width:40px; height:40px; border-radius:12px; flex-shrink:0;
                    background:rgba(99,102,241,.1); display:flex; align-items:center; justify-content:center; font-size:18px;">
            @if($log->prize_type === 'ais') 💰
            @elseif($log->prize_type === 'xp') ⭐
            @elseif($log->prize_type === 'lucky_ticket') 🎫
            @else ❌
            @endif
        </div>
        <div style="flex:1;">
            <div style="font-size:13px; font-weight:500; color:#e2e8f0;">
                @if($log->prize_type === 'ais') +{{ number_format($log->prize_value, 2) }} AIS
                @elseif($log->prize_type === 'xp') +{{ number_format($log->prize_value, 0) }} XP
                @elseif($log->prize_type === 'lucky_ticket') Lucky Draw chiptasi
                @else Hech narsa
                @endif
            </div>
            <div style="font-size:11px; color:var(--gray);">{{ $log->created_at->format('d.m.Y') }}</div>
        </div>
    </div>
    @endforeach
</div>
@endif

<script>
// — G'ildirak chizish —
const prizes = {!! json_encode($prizes->map(function($p) { return ['label' => $p->type === 'ais' ? number_format($p->value, 0).' AIS' : ($p->type === 'xp' ? $p->value.' XP' : ($p->type === 'lucky_ticket' ? 'Chipta' : 'Omad yoq')), 'color' => $p->color ?? '#6366f1', 'weight' => $p->weight]; })->toArray()) !!};
const canvas = document.getElementById("spinCanvas");
const ctx = canvas.getContext("2d");
const cx = canvas.width / 2;
const cy = canvas.height / 2;
const r = cx - 10;

let currentAngle = 0;
let isSpinning   = false;

function drawWheel(angle) {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    if (!prizes.length) return;

    const total = prizes.reduce((s, p) => s + (p.weight || 1), 0);
    let start = angle;

    prizes.forEach((p, i) => {
        const slice = (p.weight || 1) / total * Math.PI * 2;

        // Sektor
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.arc(cx, cy, r, start, start + slice);
        ctx.closePath();
        ctx.fillStyle = p.color;
        ctx.fill();
        ctx.strokeStyle = 'rgba(0,0,0,.3)';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Matn
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(start + slice / 2);
        ctx.textAlign = 'right';
        ctx.fillStyle = '#fff';
        ctx.font = 'bold 12px Inter, sans-serif';
        ctx.shadowColor = 'rgba(0,0,0,.5)';
        ctx.shadowBlur = 4;
        ctx.fillText(p.label, r - 10, 4);
        ctx.restore();

        start += slice;
    });

    // Markaz doira
    ctx.beginPath();
    ctx.arc(cx, cy, 18, 0, Math.PI * 2);
    ctx.fillStyle = '#0d1225';
    ctx.fill();
    ctx.strokeStyle = 'rgba(99,102,241,.5)';
    ctx.lineWidth = 3;
    ctx.stroke();
}

drawWheel(currentAngle);

// ── Spin animatsiyasi ──────────────────────────────────────────────────────
const spinBtn = document.getElementById('spinBtn');
const spinForm = document.getElementById('spinForm');

if (spinBtn) {
    spinBtn.addEventListener('click', function() {
        if (isSpinning) return;
        isSpinning = true;
        spinBtn.disabled = true;
        spinBtn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Aylanmoqda...';

        const totalRotation = (Math.random() * 360 + 1440) * (Math.PI / 180); // 4-5 to'liq aylanish
        const duration = 4000;
        const startTime = performance.now();
        const startAngle = currentAngle;

        function animate(now) {
            const elapsed = now - startTime;
            const progress = Math.min(elapsed / duration, 1);
            // Ease out cubic
            const eased = 1 - Math.pow(1 - progress, 3);
            currentAngle = startAngle + totalRotation * eased;
            drawWheel(currentAngle);

            if (progress < 1) {
                requestAnimationFrame(animate);
            } else {
                // Animatsiya tugadi — formani yuborish
                setTimeout(() => spinForm.submit(), 300);
            }
        }

        requestAnimationFrame(animate);
    });
}
</script>
@endsection
