@extends('front.layouts.app')
@section('title', 'Agro e\'lon yaratish')
@section('content')

<div class="page-title">🌾 Agro e'lon yaratish</div>

@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<div class="card" style="padding:20px;">
    <form method="POST" action="{{ route('app.agromarket.store') }}">
        @csrf
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Mahsulot nomi</label>
            <input type="text" name="title" class="form-control" required value="{{ old('title') }}" placeholder="Masalan: Bug'doy 1-nav">
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Kategoriya</label>
            <select name="category" class="form-control" required>
                <option value="">Tanlang...</option>
                <option value="bugdoy" {{ old('category') == 'bugdoy' ? 'selected' : '' }}>🌾 Bug'doy</option>
                <option value="paxta" {{ old('category') == 'paxta' ? 'selected' : '' }}>🏵️ Paxta</option>
                <option value="sabzavot" {{ old('category') == 'sabzavot' ? 'selected' : '' }}>🥬 Sabzavot</option>
                <option value="meva" {{ old('category') == 'meva' ? 'selected' : '' }}>🍎 Meva</option>
            </select>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Tavsif</label>
            <textarea name="description" class="form-control" rows="3" placeholder="Mahsulot haqida batafsil">{{ old('description') }}</textarea>
        </div>
        <div style="display:flex; gap:10px; margin-bottom:14px;">
            <div style="flex:1;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Narxi (1 birlik uchun)</label>
                <input type="number" name="price" class="form-control" required min="0" step="100" value="{{ old('price') }}" placeholder="UZS">
            </div>
            <div style="flex:1;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Miqdori (kg/tonna)</label>
                <input type="number" name="quantity" class="form-control" required min="0.01" step="0.01" value="{{ old('quantity') }}">
            </div>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Joylashuv</label>
            <input type="text" name="location" class="form-control" required value="{{ old('location') }}" placeholder="Masalan: Toshkent viloyati">
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;">
            <i class="fa fa-plus"></i> E'lon berish
        </button>
    </form>
</div>

@endsection
