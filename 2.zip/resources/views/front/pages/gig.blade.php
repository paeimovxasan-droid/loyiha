@extends('front.layouts.app')
@section('title', 'Gig Economy')
@section('content')

<div class="page-title">💼 Gig Economy</div>

<a href="{{ route('app.gig.create') }}"
   style="display:flex; align-items:center; justify-content:center; gap:8px; width:100%;
          padding:14px; margin-bottom:16px; background:linear-gradient(135deg, rgba(245,158,11,.15), rgba(245,158,11,.08));
          border:1px solid rgba(245,158,11,.3); border-radius:14px; color:#fbbf24;
          text-decoration:none; font-size:14px; font-weight:600;">
    <i class="fa fa-plus"></i> E'lon berish
</a>

<div style="display:flex; flex-direction:column; gap:14px;">
@forelse($gigs as $gig)
<div class="card">
    <div style="padding:20px;">
        <div style="display:flex; align-items:center; gap:14px; margin-bottom:12px;">
            <div style="width:48px; height:48px; border-radius:14px; background:rgba(245,158,11,.1);
                        display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                <i class="fa fa-hammer" style="color:#fbbf24; font-size:18px;"></i>
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-size:15px; font-weight:700; color:#f1f5f9;">{{ $gig->title }}</div>
                <div style="font-size:12px; color:var(--gray); margin-top:2px;">
                    <i class="fa fa-user" style="font-size:10px;"></i> {{ $gig->user->name ?? 'Noma\'lum' }}
                </div>
            </div>
            <div style="text-align:right; flex-shrink:0;">
                <span style="font-size:10px; padding:3px 10px; border-radius:10px; font-weight:600;
                             background:{{ $gig->status === 'open' ? 'rgba(16,185,129,.15)' : 'rgba(100,116,139,.15)' }};
                             color:{{ $gig->status === 'open' ? '#34d399' : 'var(--gray)' }};">
                    {{ $gig->status === 'open' ? 'Ochiq' : $gig->status }}
                </span>
            </div>
        </div>

        @if($gig->description)
        <div style="font-size:13px; color:var(--gray); margin-bottom:14px; line-height:1.5;">
            {{ Str::limit($gig->description, 120) }}
        </div>
        @endif

        <div style="display:flex; gap:8px;">
            <div style="flex:1; background:rgba(16,185,129,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#34d399;">{{ number_format($gig->price) }}</div>
                <div style="font-size:10px; color:var(--gray);">UZS</div>
            </div>
            @if($gig->work_date)
            <div style="flex:1; background:rgba(99,102,241,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:14px; font-weight:700; color:#818cf8;">{{ $gig->work_date->format('d.m') }}</div>
                <div style="font-size:10px; color:var(--gray);">Sana</div>
            </div>
            @endif
            @if($gig->location)
            <div style="flex:1; background:rgba(245,158,11,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:12px; font-weight:600; color:#fbbf24; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                    {{ $gig->location }}
                </div>
                <div style="font-size:10px; color:var(--gray);">Joylashuv</div>
            </div>
            @endif
        </div>
    </div>
</div>
@empty
<div class="card" style="padding:50px; text-align:center; color:var(--gray);">
    <i class="fa fa-briefcase" style="font-size:40px; opacity:.3; display:block; margin-bottom:14px;"></i>
    Hozircha ishlar yo'q
</div>
@endforelse
</div>

@if($gigs->hasPages())
<div style="margin-top:16px;">{{ $gigs->links() }}</div>
@endif

@endsection
