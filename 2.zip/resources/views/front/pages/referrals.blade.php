@extends('front.layouts.app')
@section('title', __('front.referrals.title'))
@section('content')

<div class="page-title">👥 {{ __('front.referrals.title') }}</div>

{{-- My referral link --}}
<div class="card" style="padding:18px; margin-bottom:20px; background: linear-gradient(135deg, rgba(99,102,241,.15), rgba(139,92,246,.1)); border-color: rgba(99,102,241,.2);">
    <div style="font-size:13px; color:#a5b4fc; font-weight:600; margin-bottom:6px;">
        <i class="fa fa-link"></i> {{ __('front.referrals.your_link') }}
    </div>
    <div style="font-size:13px; color:#818cf8; word-break:break-all; margin-bottom:12px;">
        {{ auth()->user()->username ? url('/register/' . auth()->user()->username) : url('/register') }}
    </div>
    <button onclick="copyRef()" class="btn btn-primary btn-sm">
        <i class="fa fa-copy"></i> {{ __('front.referrals.copy') }}
    </button>
</div>

{{-- Stats --}}
<div class="grid grid-3" style="margin-bottom:20px;">
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(99,102,241,.12); color:#818cf8;"><i class="fa fa-users"></i></div>
        <div class="stat-value">{{ $referrals->total() }}</div>
        <div class="stat-label">{{ __('front.referrals.total') }}</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(16,185,129,.12); color:#34d399;"><i class="fa fa-user-check"></i></div>
        <div class="stat-value">{{ $referrals->where('status','active')->count() }}</div>
        <div class="stat-label">{{ __('front.referrals.active') }}</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(245,158,11,.12); color:#fbbf24;"><i class="fa fa-coins"></i></div>
        <div class="stat-value">{{ number_format($totalCommission, 0) }}</div>
        <div class="stat-label">{{ __('front.referrals.commission') }}</div>
    </div>
</div>

{{-- Referral list --}}
<p class="section-label">{{ __('front.referrals.my_referrals') }}</p>
<div class="card">
    @forelse($referrals as $ref)
    <div class="list-item">
        <img src="{{ $ref->avatar_url }}" style="width:42px;height:42px;border-radius:12px;object-fit:cover;flex-shrink:0;">
        <div style="flex:1;">
            <div style="font-size:14px;font-weight:500;color:#e2e8f0;">{{ $ref->name }}</div>
            <div style="font-size:11px;color:var(--gray);margin-top:2px;">
                @{{ $ref->username ?? '—' }} · {{ $ref->created_at->format('d.m.Y') }}
            </div>
        </div>
        @if($ref->status === 'active')
        <span class="badge badge-success"><i class="fa fa-circle" style="font-size:6px;"></i> {{ __('front.referrals.active') }}</span>
        @else
        <span class="badge badge-gray">{{ $ref->status }}</span>
        @endif
    </div>
    @empty
    <div style="padding:40px;text-align:center;color:var(--gray);">
        <i class="fa fa-users" style="font-size:34px;opacity:.3;display:block;margin-bottom:12px;"></i>
        {{ __('front.referrals.no_referrals') }}<br>
        <span style="font-size:13px;">{{ __('front.referrals.invite_via_link') }}</span>
    </div>
    @endforelse
</div>
@if($referrals->hasPages())
<div style="margin-top:14px;">{{ $referrals->links() }}</div>
@endif

@endsection
@section('scripts')
<script>
function copyRef() {
    const refUrl = '{{ auth()->user()->username ? url('/register/' . auth()->user()->username) : url('/register') }}';
    navigator.clipboard.writeText(refUrl).then(() => {
        const c = document.getElementById('toastContainer');
        const t = document.createElement('div');
        t.className = 'toast toast-success';
        t.innerHTML = '<i class="fa fa-check-circle"></i><span>{{ __('front.dashboard.link_copied') }}</span>';
        c.appendChild(t);
        setTimeout(()=>{ t.style.opacity='0'; setTimeout(()=>t.remove(),300); }, 3000);
    });
}
</script>
@endsection
