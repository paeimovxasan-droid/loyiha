@extends('front.layouts.app')
@section('title', 'Loyiha yaratish')
@section('content')

<div class="page-title">🤝 Loyiha yaratish</div>

@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<div class="card" style="padding:20px;">
    <form method="POST" action="{{ route('app.crowdfunding.store') }}">
        @csrf
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Loyiha nomi</label>
            <input type="text" name="title" class="form-control" required value="{{ old('title') }}" placeholder="Loyiha nomini kiriting">
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Kategoriya</label>
            <select name="category" class="form-control" required>
                <option value="">Tanlang...</option>
                <option value="kocha_tamiri" {{ old('category') == 'kocha_tamiri' ? 'selected' : '' }}>🏗️ Ko'cha ta'miri</option>
                <option value="maktab_jihozlash" {{ old('category') == 'maktab_jihozlash' ? 'selected' : '' }}>🏫 Maktab jihozlash</option>
                <option value="kasb_orgatish" {{ old('category') == 'kasb_orgatish' ? 'selected' : '' }}>📚 Kasb o'rgatish</option>
            </select>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Tavsif</label>
            <textarea name="description" class="form-control" rows="4" required placeholder="Loyiha haqida batafsil yozing">{{ old('description') }}</textarea>
        </div>
        <div style="display:flex; gap:10px; margin-bottom:14px;">
            <div style="flex:1;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Maqsad summasi (UZS)</label>
                <input type="number" name="goal_amount" class="form-control" required min="100000" step="1000" value="{{ old('goal_amount') }}">
            </div>
            <div style="flex:1;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Tugash sanasi</label>
                <input type="date" name="expires_at" class="form-control" value="{{ old('expires_at') }}" min="{{ date('Y-m-d', strtotime('+1 day')) }}">
            </div>
        </div>
        <div style="padding:12px; background:rgba(245,158,11,.08); border-radius:10px; margin-bottom:14px;">
            <div style="font-size:12px; color:#fbbf24;"><i class="fa fa-info-circle"></i> Loyiha admin tomonidan tasdiqlanadi</div>
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;">
            <i class="fa fa-paper-plane"></i> Yuborish
        </button>
    </form>
</div>

@endsection
