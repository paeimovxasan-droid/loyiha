@extends('front.layouts.app')
@section('title', 'Mahsulot qo\'shish')
@section('content')

<div class="page-title">📦 Mahsulot qo'shish</div>

@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

@if($shops->isEmpty())
<div class="card" style="padding:40px; text-align:center; color:var(--gray);">
    <i class="fa fa-store" style="font-size:36px; opacity:.3; display:block; margin-bottom:12px;"></i>
    <div style="margin-bottom:14px;">Avval do'kon ochishingiz kerak</div>
    <a href="{{ route('app.catalog.shop.create') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-plus"></i> Do'kon ochish
    </a>
</div>
@else
<div class="card" style="padding:20px;">
    <form method="POST" action="{{ route('app.catalog.product.store') }}">
        @csrf
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Do'kon</label>
            <select name="shop_id" class="form-control" required>
                @foreach($shops as $shop)
                <option value="{{ $shop->id }}">{{ $shop->name }}</option>
                @endforeach
            </select>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Mahsulot nomi</label>
            <input type="text" name="name" class="form-control" required value="{{ old('name') }}" placeholder="Mahsulot nomini kiriting">
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Tavsif</label>
            <textarea name="description" class="form-control" rows="3" placeholder="Mahsulot haqida">{{ old('description') }}</textarea>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Narxi (UZS)</label>
            <input type="number" name="price" class="form-control" required min="0" step="100" value="{{ old('price') }}" placeholder="Masalan: 50000">
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;">
            <i class="fa fa-plus"></i> Mahsulot qo'shish
        </button>
    </form>
</div>
@endif

@endsection
