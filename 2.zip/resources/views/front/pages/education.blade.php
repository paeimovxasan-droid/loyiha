@extends('front.layouts.app')
@section('title', 'Ta\'lim')
@section('content')

<div class="page-title">🎓 Ta'lim</div>

<a href="{{ route('app.education.create') }}"
   style="display:flex; align-items:center; justify-content:center; gap:8px; width:100%;
          padding:14px; margin-bottom:16px; background:linear-gradient(135deg, rgba(6,182,212,.15), rgba(6,182,212,.08));
          border:1px solid rgba(6,182,212,.3); border-radius:14px; color:#22d3ee;
          text-decoration:none; font-size:14px; font-weight:600;">
    <i class="fa fa-plus"></i> Kurs yaratish
</a>

<div style="display:flex; flex-direction:column; gap:14px;">
@forelse($courses as $course)
<div class="card">
    <div style="padding:20px;">
        <div style="display:flex; align-items:center; gap:14px; margin-bottom:12px;">
            <div style="width:48px; height:48px; border-radius:14px; background:rgba(6,182,212,.1);
                        display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                <i class="fa fa-graduation-cap" style="color:#22d3ee; font-size:18px;"></i>
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-size:15px; font-weight:700; color:#f1f5f9;">{{ $course->title }}</div>
                <div style="font-size:12px; color:var(--gray); margin-top:2px;">
                    <i class="fa fa-user" style="font-size:10px;"></i> {{ $course->user->name ?? 'Noma\'lum' }}
                </div>
            </div>
        </div>

        @if($course->description)
        <div style="font-size:13px; color:var(--gray); margin-bottom:14px; line-height:1.5;">
            {{ Str::limit($course->description, 120) }}
        </div>
        @endif

        <div style="display:flex; gap:8px; margin-bottom:14px;">
            <div style="flex:1; background:rgba(6,182,212,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#22d3ee;">{{ $course->total_lessons ?? 0 }}</div>
                <div style="font-size:10px; color:var(--gray);">Darslar</div>
            </div>
            <div style="flex:1; background:rgba(16,185,129,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#34d399;">{{ number_format($course->price) }}</div>
                <div style="font-size:10px; color:var(--gray);">UZS</div>
            </div>
            @if($course->total_duration)
            <div style="flex:1; background:rgba(99,102,241,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#818cf8;">{{ $course->total_duration }}</div>
                <div style="font-size:10px; color:var(--gray);">Daqiqa</div>
            </div>
            @endif
        </div>

        <div style="display:flex; gap:8px; flex-wrap:wrap;">
            @if($course->category)
            <span style="font-size:11px; padding:4px 10px; border-radius:8px;
                         background:rgba(139,92,246,.1); color:#a78bfa;">
                {{ $course->category }}
            </span>
            @endif
        </div>
    </div>
</div>
@empty
<div class="card" style="padding:50px; text-align:center; color:var(--gray);">
    <i class="fa fa-book" style="font-size:40px; opacity:.3; display:block; margin-bottom:14px;"></i>
    Hozircha kurslar yo'q
</div>
@endforelse
</div>

@if($courses->hasPages())
<div style="margin-top:16px;">{{ $courses->links() }}</div>
@endif

@endsection
