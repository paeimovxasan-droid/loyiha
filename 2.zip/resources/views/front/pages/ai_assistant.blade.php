@extends('front.layouts.app')
@section('title', 'AI Yordamchi')
@section('content')

<div class="page-title">🤖 AI Yordamchi</div>

{{-- FAQ kategoriyalar --}}
@if($categories->isNotEmpty())
<div style="display:flex; gap:8px; overflow-x:auto; margin-bottom:16px; padding-bottom:4px;">
    @foreach($categories as $cat)
    <button type="button" onclick="showCategory('{{ $cat }}')"
            style="flex-shrink:0; padding:6px 14px; border-radius:20px; font-size:12px; font-weight:600;
                   background:rgba(99,102,241,.1); border:1px solid rgba(99,102,241,.2); color:#818cf8;
                   cursor:pointer;">
        {{ $cat }}
    </button>
    @endforeach
</div>
@endif

{{-- Tez-tez beriladigan savollar --}}
@if($faqs->isNotEmpty())
<div id="faqSection" style="margin-bottom:16px;">
    <p class="section-label">Tez-tez beriladigan savollar</p>
    <div style="display:flex; flex-direction:column; gap:8px;">
        @foreach($faqs->take(5) as $faq)
        <div class="faq-item" data-category="{{ $faq->category }}"
             style="background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.06);
                    border-radius:14px; padding:14px; cursor:pointer;"
             onclick="askFaq('{{ addslashes($faq->question) }}')">
            <div style="font-size:13px; font-weight:600; color:#e2e8f0; margin-bottom:4px;">
                {{ $faq->question }}
            </div>
            <div style="font-size:12px; color:var(--gray);">
                {{ Str::limit($faq->answer, 80) }}
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif

{{-- Chat oynasi --}}
<div class="card" style="margin-bottom:16px;">
    <div style="padding:14px 16px; border-bottom:1px solid rgba(255,255,255,.06);
                display:flex; align-items:center; gap:10px;">
        <div style="width:36px; height:36px; border-radius:12px; background:linear-gradient(135deg, #6366f1, #8b5cf6);
                    display:flex; align-items:center; justify-content:center; font-size:18px;">🤖</div>
        <div>
            <div style="font-size:14px; font-weight:600; color:#f1f5f9;">AISOQQA Yordamchi</div>
            <div style="font-size:11px; color:var(--gray);">Savolingizga javob beraman</div>
        </div>
    </div>

    {{-- Xabarlar --}}
    <div id="chatMessages" style="max-height:400px; overflow-y:auto; padding:16px;">
        @if($messages->isEmpty())
        <div style="text-align:center; padding:30px 0;">
            <div style="font-size:40px; margin-bottom:10px;">💬</div>
            <div style="font-size:14px; color:var(--gray);">Savol bering yoki yuqoridagi FAQ lardan tanlang</div>
        </div>
        @endif

        @foreach($messages as $msg)
        <div style="display:flex; gap:10px; margin-bottom:14px;
                    {{ $msg->role === 'user' ? 'flex-direction:row-reverse;' : '' }}">
            <div style="width:32px; height:32px; border-radius:10px; flex-shrink:0;
                        background:{{ $msg->role === 'user' ? 'rgba(99,102,241,.2)' : 'rgba(16,185,129,.2)' }};
                        display:flex; align-items:center; justify-content:center; font-size:14px;">
                {{ $msg->role === 'user' ? '👤' : '🤖' }}
            </div>
            <div style="max-width:80%; padding:10px 14px; border-radius:14px; font-size:13px; line-height:1.5;
                        {{ $msg->role === 'user'
                            ? 'background:rgba(99,102,241,.15); color:#c7d2fe; border-bottom-right-radius:4px;'
                            : 'background:rgba(255,255,255,.06); color:#e2e8f0; border-bottom-left-radius:4px;' }}">
                {{ $msg->content }}
            </div>
        </div>
        @endforeach
    </div>

    {{-- Xabar yuborish --}}
    <form method="POST" action="{{ route('app.ai.send') }}"
          style="padding:12px 16px; border-top:1px solid rgba(255,255,255,.06);
                 display:flex; gap:8px;">
        @csrf
        <input type="text" name="message" id="chatInput" required autocomplete="off"
               placeholder="Savol yozing..."
               style="flex:1; background:rgba(255,255,255,.04); border:1px solid rgba(255,255,255,.08);
                      border-radius:12px; padding:10px 14px; color:#e2e8f0; font-size:13px;
                      outline:none; font-family:inherit;">
        <button type="submit"
                style="width:42px; height:42px; border-radius:12px; border:none; cursor:pointer;
                       background:linear-gradient(135deg, #6366f1, #8b5cf6); color:#fff;
                       display:flex; align-items:center; justify-content:center; font-size:16px;">
            <i class="fa fa-paper-plane"></i>
        </button>
    </form>
</div>

@endsection

@section('scripts')
<script>
// Scroll to bottom
const chatEl = document.getElementById('chatMessages');
if (chatEl) chatEl.scrollTop = chatEl.scrollHeight;

function askFaq(question) {
    document.getElementById('chatInput').value = question;
    document.getElementById('chatInput').closest('form').submit();
}

function showCategory(cat) {
    document.querySelectorAll('.faq-item').forEach(el => {
        el.style.display = (!cat || el.dataset.category === cat) ? 'block' : 'none';
    });
}
</script>
@endsection
