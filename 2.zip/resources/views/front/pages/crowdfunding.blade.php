@extends('front.layouts.app')
@section('title', 'Crowdfunding')
@section('content')

<div class="page-title">🤝 Crowdfunding</div>

<a href="{{ route('app.crowdfunding.create') }}"
   style="display:flex; align-items:center; justify-content:center; gap:8px; width:100%;
          padding:14px; margin-bottom:16px; background:linear-gradient(135deg, rgba(16,185,129,.15), rgba(16,185,129,.08));
          border:1px solid rgba(16,185,129,.3); border-radius:14px; color:#34d399;
          text-decoration:none; font-size:14px; font-weight:600;">
    <i class="fa fa-plus"></i> Loyiha yaratish
</a>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<div style="display:flex; flex-direction:column; gap:14px;">
@forelse($projects as $project)
<div class="card">
    <div style="padding:20px;">
        <div style="display:flex; align-items:center; gap:12px; margin-bottom:14px;">
            <div style="width:42px; height:42px; border-radius:12px; background:rgba(16,185,129,.1);
                        display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                <i class="fa fa-hand-holding-heart" style="color:#34d399; font-size:18px;"></i>
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-size:15px; font-weight:700; color:#f1f5f9;">{{ $project->title }}</div>
                <div style="font-size:12px; color:var(--gray);">{{ $project->user->name ?? 'Noma\'lum' }}</div>
            </div>
        </div>

        @if($project->description)
        <div style="font-size:13px; color:var(--gray); margin-bottom:14px; line-height:1.5;">
            {{ Str::limit($project->description, 120) }}
        </div>
        @endif

        {{-- Stats --}}
        <div style="display:flex; gap:8px; margin-bottom:14px;">
            <div style="flex:1; background:rgba(16,185,129,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:14px; font-weight:700; color:#34d399;">{{ number_format($project->collected_amount) }}</div>
                <div style="font-size:10px; color:var(--gray);">Yig'ildi</div>
            </div>
            <div style="flex:1; background:rgba(99,102,241,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:14px; font-weight:700; color:#818cf8;">{{ number_format($project->goal_amount) }}</div>
                <div style="font-size:10px; color:var(--gray);">Maqsad</div>
            </div>
        </div>

        {{-- Progress --}}
        <div style="margin-bottom:14px;">
            <div style="display:flex; justify-content:space-between; font-size:11px; color:var(--gray); margin-bottom:6px;">
                <span>Progress</span>
                <span>{{ $project->progress }}%</span>
            </div>
            <div style="height:6px; background:var(--dark-3); border-radius:3px; overflow:hidden;">
                <div style="height:100%; width:{{ min($project->progress, 100) }}%;
                            background:linear-gradient(90deg, #10b981, #34d399);
                            border-radius:3px;"></div>
            </div>
        </div>

        {{-- Donate form --}}
        <form method="POST" action="{{ route('app.crowdfunding.donate', $project->id) }}">
            @csrf
            <div style="display:flex; gap:8px;">
                <input type="number" name="amount" min="1000" step="1000" required
                       class="form-control" placeholder="Miqdor (UZS)" style="flex:1;">
                <button type="submit" class="btn btn-primary" style="white-space:nowrap;">
                    <i class="fa fa-heart"></i> Xayriya
                </button>
            </div>
        </form>
    </div>
</div>
@empty
<div class="card" style="padding:50px; text-align:center; color:var(--gray);">
    <i class="fa fa-hand-holding-heart" style="font-size:40px; opacity:.3; display:block; margin-bottom:14px;"></i>
    Hozircha loyihalar yo'q
</div>
@endforelse
</div>

@if($projects->hasPages())
<div style="margin-top:16px;">{{ $projects->links() }}</div>
@endif

@endsection
