@extends('front.layouts.app')
@section('title', 'Do\'kon ochish')
@section('content')

<div class="page-title">🏪 Do'kon ochish</div>

<div class="alert alert-info" style="margin-bottom:16px;">
    <i class="fa fa-info-circle"></i> Do'kon ochish uchun 10 AIS to'lov olinadi
</div>

@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<div class="card" style="padding:20px;">
    <form method="POST" action="{{ route('app.catalog.shop.store') }}">
        @csrf
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Do'kon nomi</label>
            <input type="text" name="name" class="form-control" required value="{{ old('name') }}" placeholder="Masalan: Texno Do'kon">
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Kategoriya</label>
            <select name="category" class="form-control" required>
                <option value="">Tanlang...</option>
                <option value="oziq-ovqat" {{ old('category') == 'oziq-ovqat' ? 'selected' : '' }}>🍞 Oziq-ovqat</option>
                <option value="kiyim" {{ old('category') == 'kiyim' ? 'selected' : '' }}>👕 Kiyim-kechak</option>
                <option value="texnika" {{ old('category') == 'texnika' ? 'selected' : '' }}>📱 Texnika</option>
                <option value="uy-jihozlari" {{ old('category') == 'uy-jihozlari' ? 'selected' : '' }}>🏠 Uy jihozlari</option>
                <option value="boshqa" {{ old('category') == 'boshqa' ? 'selected' : '' }}>📦 Boshqa</option>
            </select>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Tavsif</label>
            <textarea name="description" class="form-control" rows="3" placeholder="Do'kon haqida">{{ old('description') }}</textarea>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Manzil</label>
            <input type="text" name="address" class="form-control" required value="{{ old('address') }}" placeholder="Masalan: Toshkent, Chilonzor 7">
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Telefon</label>
            <input type="text" name="phone" class="form-control" required value="{{ old('phone') }}" placeholder="+998901234567">
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;">
            <i class="fa fa-store"></i> Do'kon ochish (10 AIS)
        </button>
    </form>
</div>

@endsection
