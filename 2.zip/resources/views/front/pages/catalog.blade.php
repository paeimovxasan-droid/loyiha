@extends('front.layouts.app')
@section('title', 'Katalog')
@section('content')

<div class="page-title">🏪 Katalog</div>

<div style="display:flex; gap:10px; margin-bottom:16px;">
    <a href="{{ route('app.catalog.shop.create') }}"
       style="flex:1; display:flex; align-items:center; justify-content:center; gap:8px;
              padding:14px; background:linear-gradient(135deg, rgba(245,158,11,.15), rgba(245,158,11,.08));
              border:1px solid rgba(245,158,11,.3); border-radius:14px; color:#fbbf24;
              text-decoration:none; font-size:13px; font-weight:600;">
        <i class="fa fa-store"></i> Do'kon ochish
    </a>
    <a href="{{ route('app.catalog.product.create') }}"
       style="flex:1; display:flex; align-items:center; justify-content:center; gap:8px;
              padding:14px; background:linear-gradient(135deg, rgba(99,102,241,.15), rgba(99,102,241,.08));
              border:1px solid rgba(99,102,241,.3); border-radius:14px; color:#818cf8;
              text-decoration:none; font-size:13px; font-weight:600;">
        <i class="fa fa-plus"></i> Mahsulot qo'shish
    </a>
</div>

{{-- Shops --}}
<p class="section-label">Do'konlar</p>
<div style="display:flex; flex-direction:column; gap:14px; margin-bottom:24px;">
@forelse($shops as $shop)
<div class="card">
    <div style="padding:20px;">
        <div style="display:flex; align-items:center; gap:14px;">
            <div style="width:48px; height:48px; border-radius:14px; background:rgba(245,158,11,.1);
                        display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                @if($shop->image)
                    <img src="{{ $shop->image }}" style="width:48px; height:48px; border-radius:14px; object-fit:cover;">
                @else
                    <i class="fa fa-store" style="color:#fbbf24; font-size:18px;"></i>
                @endif
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-size:15px; font-weight:700; color:#f1f5f9;">{{ $shop->name }}</div>
                <div style="font-size:12px; color:var(--gray); margin-top:2px;">
                    <i class="fa fa-user" style="font-size:10px;"></i> {{ $shop->user->name ?? 'Noma\'lum' }}
                </div>
            </div>
            <div style="text-align:right; flex-shrink:0;">
                <div style="font-size:13px; color:#fbbf24;">⭐ {{ number_format($shop->avg_rating, 1) }}</div>
                <div style="font-size:11px; color:var(--gray);">{{ $shop->total_reviews }} sharh</div>
            </div>
        </div>
        @if($shop->description)
        <div style="font-size:13px; color:var(--gray); margin-top:10px; line-height:1.5;">
            {{ Str::limit($shop->description, 100) }}
        </div>
        @endif
        @if($shop->cashback_percent > 0)
        <div style="margin-top:10px;">
            <span style="font-size:11px; padding:4px 10px; border-radius:8px;
                         background:rgba(16,185,129,.1); color:#34d399;">
                <i class="fa fa-percent"></i> {{ $shop->cashback_percent }}% cashback
            </span>
        </div>
        @endif
    </div>
</div>
@empty
<div class="card" style="padding:40px; text-align:center; color:var(--gray);">
    <i class="fa fa-store" style="font-size:36px; opacity:.3; display:block; margin-bottom:12px;"></i>
    Hozircha do'konlar yo'q
</div>
@endforelse
</div>

@if($shops->hasPages())
<div style="margin-bottom:20px;">{{ $shops->links() }}</div>
@endif

{{-- Products --}}
<p class="section-label">Mahsulotlar</p>
<div style="display:flex; flex-direction:column; gap:14px;">
@forelse($products as $product)
<div class="card">
    <div style="padding:20px;">
        <div style="display:flex; align-items:center; gap:14px;">
            <div style="width:48px; height:48px; border-radius:14px; background:rgba(99,102,241,.1);
                        display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                @if($product->image)
                    <img src="{{ $product->image }}" style="width:48px; height:48px; border-radius:14px; object-fit:cover;">
                @else
                    <i class="fa fa-box" style="color:#818cf8; font-size:18px;"></i>
                @endif
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-size:15px; font-weight:700; color:#f1f5f9;">{{ $product->name }}</div>
                <div style="font-size:12px; color:var(--gray); margin-top:2px;">
                    {{ $product->shop->name ?? '' }}
                </div>
            </div>
            <div style="text-align:right; flex-shrink:0;">
                <div style="font-size:16px; font-weight:800; color:#34d399;">{{ number_format($product->price) }}</div>
                <div style="font-size:10px; color:var(--gray);">UZS</div>
            </div>
        </div>
    </div>
</div>
@empty
<div class="card" style="padding:40px; text-align:center; color:var(--gray);">
    <i class="fa fa-box-open" style="font-size:36px; opacity:.3; display:block; margin-bottom:12px;"></i>
    Hozircha mahsulotlar yo'q
</div>
@endforelse
</div>

@if($products->hasPages())
<div style="margin-top:16px;">{{ $products->appends(['page' => $shops->currentPage()])->links() }}</div>
@endif

@endsection
