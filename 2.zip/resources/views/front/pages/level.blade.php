@extends('front.layouts.app')
@section('title', 'Daraja — Level ' . $userLevel->level)
@section('content')

<div class="page-title">⚡ Daraja & XP</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif

{{-- Level kartasi --}}
<div style="background: linear-gradient(135deg, {{ $userLevel->badge_color }}22, {{ $userLevel->badge_color }}44);
            border: 1px solid {{ $userLevel->badge_color }}55;
            border-radius: 24px; padding: 24px; margin-bottom: 20px; position:relative; overflow:hidden;">
    <div style="position:absolute; top:-30px; right:-20px; width:120px; height:120px;
                border-radius:50%; background:{{ $userLevel->badge_color }}15;"></div>

    <div style="display:flex; align-items:center; gap:16px; margin-bottom:20px;">
        <div style="width:64px; height:64px; border-radius:20px; flex-shrink:0;
                    background:{{ $userLevel->badge_color }}33;
                    display:flex; align-items:center; justify-content:center; font-size:28px;">
            {{ $currentConfig?->badge_icon ?? '🌱' }}
        </div>
        <div>
            <div style="font-size:13px; color:var(--gray); margin-bottom:2px;">Joriy daraja</div>
            <div style="font-size:28px; font-weight:800; color:#f1f5f9; letter-spacing:-1px;">
                Level {{ $userLevel->level }}
            </div>
            <div style="font-size:14px; font-weight:600; color:{{ $userLevel->badge_color }};">
                {{ $userLevel->title }}
            </div>
        </div>
        <div style="margin-left:auto; text-align:right;">
            <div style="font-size:11px; color:var(--gray);">Reyting</div>
            <div style="font-size:22px; font-weight:700; color:#f1f5f9;">#{{ $userRank }}</div>
        </div>
    </div>

    {{-- Progress bar --}}
    <div style="margin-bottom:8px; display:flex; justify-content:space-between; font-size:12px; color:var(--gray);">
        <span>{{ number_format($userLevel->current_xp) }} XP</span>
        <span>{{ number_format($userLevel->next_level_xp) }} XP (Level {{ $userLevel->level + 1 }})</span>
    </div>
    <div style="height:8px; background:rgba(255,255,255,.08); border-radius:10px; overflow:hidden;">
        <div style="height:100%; width:{{ $userLevel->progress_percent }}%;
                    background:linear-gradient(90deg, {{ $userLevel->badge_color }}, {{ $userLevel->badge_color }}aa);
                    border-radius:10px; transition:width .5s;"></div>
    </div>
    <div style="margin-top:6px; font-size:11px; color:var(--gray); text-align:center;">
        Keyingi darajaga {{ number_format($userLevel->remaining_xp) }} XP qoldi
    </div>
</div>

{{-- Statistika --}}
<div class="grid grid-3" style="margin-bottom:20px;">
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(99,102,241,.12); color:#818cf8;"><i class="fa fa-star"></i></div>
        <div class="stat-value">{{ number_format($userLevel->total_xp) }}</div>
        <div class="stat-label">Jami XP</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(16,185,129,.12); color:#34d399;"><i class="fa fa-trophy"></i></div>
        <div class="stat-value">{{ $userLevel->level }}</div>
        <div class="stat-label">Daraja</div>
    </div>
    <div class="stat-card">
        <div class="stat-icon" style="background:rgba(245,158,11,.12); color:#fbbf24;"><i class="fa fa-ranking-star"></i></div>
        <div class="stat-value">#{{ $userRank }}</div>
        <div class="stat-label">Reyting</div>
    </div>
</div>

{{-- Joriy daraja bonuslari --}}
@if($currentConfig)
<p class="section-label">Joriy daraja bonuslari</p>
<div class="card" style="margin-bottom:20px;">
    <div style="padding:16px; display:grid; grid-template-columns:1fr 1fr; gap:12px;">
        <div style="background:rgba(99,102,241,.08); border-radius:12px; padding:12px; text-align:center;">
            <div style="font-size:18px; font-weight:700; color:#818cf8;">+{{ $currentConfig->ref_bonus_percent }}%</div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">Referral bonus</div>
        </div>
        <div style="background:rgba(16,185,129,.08); border-radius:12px; padding:12px; text-align:center;">
            <div style="font-size:18px; font-weight:700; color:#34d399;">+{{ $currentConfig->cashback_percent }}%</div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">AIS cashback</div>
        </div>
        <div style="background:rgba(245,158,11,.08); border-radius:12px; padding:12px; text-align:center;">
            <div style="font-size:18px; font-weight:700; color:#fbbf24;">+{{ $currentConfig->daily_mining_bonus }}%</div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">Mining bonus</div>
        </div>
        <div style="background:rgba(239,68,68,.08); border-radius:12px; padding:12px; text-align:center;">
            <div style="font-size:18px; font-weight:700; color:#f87171;">-{{ $currentConfig->transfer_fee_discount }}%</div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">Transfer chegirma</div>
        </div>
    </div>
    <div style="padding:0 16px 16px; display:flex; gap:8px;">
        <div style="flex:1; padding:10px; border-radius:10px; text-align:center;
                    background:{{ $currentConfig->p2p_unlocked ? 'rgba(16,185,129,.1)' : 'rgba(100,116,139,.08)' }};
                    border:1px solid {{ $currentConfig->p2p_unlocked ? 'rgba(16,185,129,.2)' : 'rgba(100,116,139,.1)' }};">
            <i class="fa fa-{{ $currentConfig->p2p_unlocked ? 'check' : 'lock' }}"
               style="color:{{ $currentConfig->p2p_unlocked ? '#34d399' : '#64748b' }};"></i>
            <div style="font-size:11px; color:var(--gray); margin-top:4px;">P2P Transfer</div>
        </div>
        <div style="flex:1; padding:10px; border-radius:10px; text-align:center;
                    background:{{ $currentConfig->virtual_card_unlocked ? 'rgba(16,185,129,.1)' : 'rgba(100,116,139,.08)' }};
                    border:1px solid {{ $currentConfig->virtual_card_unlocked ? 'rgba(16,185,129,.2)' : 'rgba(100,116,139,.1)' }};">
            <i class="fa fa-{{ $currentConfig->virtual_card_unlocked ? 'check' : 'lock' }}"
               style="color:{{ $currentConfig->virtual_card_unlocked ? '#34d399' : '#64748b' }};"></i>
            <div style="font-size:11px; color:var(--gray); margin-top:4px;">Virtual karta</div>
        </div>
    </div>
</div>
@endif

{{-- Top 3 --}}
<p class="section-label">Top o'yinchilar</p>
<div class="card" style="margin-bottom:20px;">
    @foreach($topUsers as $i => $top)
    <div class="list-item">
        <div style="width:36px; height:36px; border-radius:10px; flex-shrink:0;
                    background:{{ ['rgba(245,158,11,.2)','rgba(148,163,184,.15)','rgba(180,83,9,.15)'][$i] ?? 'rgba(99,102,241,.1)' }};
                    display:flex; align-items:center; justify-content:center;
                    font-size:16px; font-weight:800;
                    color:{{ ['#fbbf24','#94a3b8','#b45309'][$i] ?? '#818cf8' }};">
            {{ ['🥇','🥈','🥉'][$i] ?? ($i+1) }}
        </div>
        <img src="{{ $top->user?->avatar_url }}"
             style="width:36px; height:36px; border-radius:10px; object-fit:cover; flex-shrink:0;">
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:600; color:#e2e8f0;">{{ $top->user?->name }}</div>
            <div style="font-size:11px; color:var(--gray);">@{{ $top->user?->username ?? '—' }}</div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:13px; font-weight:700; color:{{ $top->badge_color }};">
                {{ $top->badge_icon ?? '🌱' }} Lv.{{ $top->level }}
            </div>
            <div style="font-size:11px; color:var(--gray);">{{ number_format($top->total_xp) }} XP</div>
        </div>
    </div>
    @endforeach
    <div style="padding:12px 20px; border-top:1px solid rgba(255,255,255,.04);">
        <a href="{{ route('app.leaderboard') }}" class="btn btn-outline btn-full btn-sm">
            <i class="fa fa-list-ol"></i> To'liq reyting
        </a>
    </div>
</div>

{{-- XP tarixi --}}
<p class="section-label">XP tarixi</p>
<div class="card">
    @forelse($xpLogs as $log)
    <div class="list-item">
        <div style="width:38px; height:38px; border-radius:10px; flex-shrink:0;
                    background:rgba(99,102,241,.1);
                    display:flex; align-items:center; justify-content:center;">
            <i class="fa fa-bolt" style="color:#818cf8; font-size:14px;"></i>
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:500; color:#e2e8f0;">
                {{ $log->description ?? $log->action }}
            </div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">
                {{ $log->created_at->format('d.m.Y H:i') }}
            </div>
        </div>
        <div style="font-size:14px; font-weight:700; color:#818cf8; flex-shrink:0;">
            +{{ $log->xp }} XP
        </div>
    </div>
    @empty
    <div style="padding:30px; text-align:center; color:var(--gray);">
        <i class="fa fa-star" style="font-size:28px; opacity:.3; display:block; margin-bottom:10px;"></i>
        Hali XP yo'q. Faoliyat ko'rsating!
    </div>
    @endforelse
</div>

@endsection
