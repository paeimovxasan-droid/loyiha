@extends('front.layouts.app')
@section('title', 'Ish e\'loni berish')
@section('content')

<div class="page-title">💼 Ish e'loni berish</div>

@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<div class="card" style="padding:20px;">
    <form method="POST" action="{{ route('app.gig.store') }}">
        @csrf
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Sarlavha</label>
            <input type="text" name="title" class="form-control" required value="{{ old('title') }}" placeholder="Masalan: Yuk ko'chirish kerak">
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Kategoriya</label>
            <select name="category" class="form-control" required>
                <option value="">Tanlang...</option>
                <option value="yuk_tashish" {{ old('category') == 'yuk_tashish' ? 'selected' : '' }}>🚛 Yuk tashish</option>
                <option value="tozalash" {{ old('category') == 'tozalash' ? 'selected' : '' }}>🧹 Tozalash</option>
                <option value="qurilish" {{ old('category') == 'qurilish' ? 'selected' : '' }}>🏗️ Qurilish</option>
                <option value="kuryer" {{ old('category') == 'kuryer' ? 'selected' : '' }}>📦 Kuryer</option>
            </select>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Tavsif</label>
            <textarea name="description" class="form-control" rows="3" required placeholder="Ish haqida batafsil">{{ old('description') }}</textarea>
        </div>
        <div style="display:flex; gap:10px; margin-bottom:14px;">
            <div style="flex:1;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">To'lov (UZS)</label>
                <input type="number" name="price" class="form-control" required min="1000" step="1000" value="{{ old('price') }}">
            </div>
            <div style="flex:1;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Ish sanasi</label>
                <input type="date" name="work_date" class="form-control" required value="{{ old('work_date', date('Y-m-d')) }}">
            </div>
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Joylashuv</label>
            <input type="text" name="location" class="form-control" required value="{{ old('location') }}" placeholder="Masalan: Toshkent, Chilonzor">
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;">
            <i class="fa fa-plus"></i> E'lon berish
        </button>
    </form>
</div>

@endsection
