@extends('front.layouts.app')
@section('title', __('front.deposit.title'))
@section('content')

<div class="page-title">💳 {{ __('front.deposit.title') }}</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if($errors->any())
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ $errors->first() }}</div>
@endif

<div class="card" style="margin-bottom: 20px;">
    <div class="card-header">
        <span class="card-title"><i class="fa fa-arrow-down-to-line"></i> {{ __('front.deposit.new_deposit') }}</span>
    </div>
    <div class="card-body">
        <form method="POST" action="{{ route('app.deposit.store') }}" enctype="multipart/form-data">
            @csrf

            <div class="form-group">
                <label class="form-label">{{ __('front.deposit.payment_method') }}</label>
                <select name="payment_method_id" required class="form-control {{ $errors->has('payment_method_id') ? 'is-invalid' : '' }}"
                        onchange="showMethodDetails(this)">
                    <option value="">{{ __('front.deposit.select') }}</option>
                    @foreach($methods as $method)
                    <option value="{{ $method->id }}"
                            data-number="{{ $method->number }}"
                            data-charge="{{ $method->deposit_charge_percent }}"
                            data-min="{{ $method->minimum_deposit }}"
                            data-max="{{ $method->maximum_deposit }}">
                        {{ $method->getTranslation('name', app()->getLocale()) }}
                    </option>
                    @endforeach
                </select>
            </div>

            {{-- Method info --}}
            <div id="methodInfo" style="display:none; margin-bottom:16px;">
                <div style="background: rgba(99,102,241,.08); border: 1px solid rgba(99,102,241,.2);
                            border-radius: 14px; padding: 14px;">
                    <div style="font-size: 12px; color: var(--gray); margin-bottom: 6px;">{{ __('front.deposit.card_number') }}</div>
                    <div id="methodNumber" style="font-size: 18px; font-weight: 700; color: #818cf8; letter-spacing: 1px;"></div>
                    <div id="methodCharge" style="font-size: 12px; color: var(--gray); margin-top: 6px;"></div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">{{ __('front.deposit.amount') }}</label>
                <input type="number" name="amount" step="0.01"
                       min="{{ $setting->min_deposit }}" max="{{ $setting->max_deposit }}"
                       value="{{ old('amount') }}" required
                       class="form-control {{ $errors->has('amount') ? 'is-invalid' : '' }}"
                       placeholder="{{ $setting->min_deposit }} — {{ $setting->max_deposit }}"
                       oninput="calcCharge()">
                <div id="chargeInfo" style="font-size:12px; color:var(--gray); margin-top:6px;"></div>
                @error('amount') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
            </div>

            <div class="form-group">
                <label class="form-label">{{ __('front.deposit.sender_number') }}</label>
                <input type="text" name="sender_number" value="{{ old('sender_number') }}" required
                       class="form-control {{ $errors->has('sender_number') ? 'is-invalid' : '' }}"
                       placeholder="{{ __('front.deposit.sender_placeholder') }}">
                @error('sender_number') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
            </div>

            <div class="form-group">
                <label class="form-label">{{ __('front.deposit.screenshot') }}</label>

                {{-- Custom file picker --}}
                <div id="screenshotPicker"
                     onclick="document.getElementById('screenshotInput').click()"
                     style="
                        border: 2px dashed rgba(99,102,241,.4);
                        border-radius: 16px;
                        padding: 20px 16px;
                        text-align: center;
                        cursor: pointer;
                        transition: border-color .2s, background .2s;
                        background: rgba(99,102,241,.05);
                     "
                     onmouseenter="this.style.borderColor='rgba(99,102,241,.8)'; this.style.background='rgba(99,102,241,.1)'"
                     onmouseleave="this.style.borderColor='rgba(99,102,241,.4)'; this.style.background='rgba(99,102,241,.05)'">

                    {{-- Default state --}}
                    <div id="screenshotDefault">
                        <div style="width:52px; height:52px; border-radius:14px;
                                    background:rgba(99,102,241,.15); margin:0 auto 12px;
                                    display:flex; align-items:center; justify-content:center;">
                            <i class="fa fa-image" style="font-size:22px; color:#818cf8;"></i>
                        </div>
                        <div style="font-size:14px; font-weight:600; color:#c7d2fe;">{{ __('front.deposit.upload_screenshot') }}</div>
                        <div style="font-size:12px; color:var(--gray); margin-top:4px;">{{ __('front.deposit.upload_hint') }}</div>
                    </div>

                    {{-- Preview state (hidden by default) --}}
                    <div id="screenshotPreview" style="display:none;">
                        <img id="screenshotImg"
                             src="" alt="preview"
                             style="max-width:100%; max-height:180px; border-radius:10px; object-fit:contain; margin-bottom:8px;">
                        <div style="font-size:12px; color:#818cf8;">
                            <i class="fa fa-check-circle"></i>
                            <span id="screenshotName">{{ __('front.deposit.file_selected') }}</span>
                        </div>
                        <div style="font-size:12px; color:var(--gray); margin-top:4px;">{{ __('front.deposit.tap_to_change') }}</div>
                    </div>
                </div>

                <input type="file" id="screenshotInput" name="screenshot" accept="image/*"
                       style="display:none;"
                       onchange="previewScreenshot(this)">

                @error('screenshot')
                    <div class="invalid-feedback" style="display:block;">
                        <i class="fa fa-exclamation-circle"></i> {{ $message }}
                    </div>
                @enderror
            </div>

            <button type="submit" class="btn btn-primary btn-full btn-lg">
                <i class="fa fa-paper-plane"></i> {{ __('front.deposit.submit') }}
            </button>
        </form>
    </div>
</div>

{{-- Tarix --}}
<p class="section-label" style="margin-top: 24px;">{{ __('front.deposit.history') }}</p>
<div class="card">
    @forelse($deposits as $dep)
    <div class="list-item">
        <div style="width:42px; height:42px; border-radius:12px; flex-shrink:0;
                    background: rgba(6,182,212,.1); display:flex; align-items:center; justify-content:center;">
            <i class="fa fa-arrow-down-to-line" style="color:#22d3ee; font-size:15px;"></i>
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:500; color:#e2e8f0;">
                {{ $dep->method_name ?? $dep->paymentMethod?->getTranslation('name', app()->getLocale()) }}
            </div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">
                {{ $dep->created_at->format('d.m.Y H:i') }}
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:14px; font-weight:600; color:#22d3ee;">
                +{{ number_format($dep->final_amount, 2) }}
            </div>
            <div style="margin-top:3px;">
                @if($dep->status === 'approved')
                <span class="badge badge-success"><i class="fa fa-check"></i> {{ __('front.deposit.approved') }}</span>
                @elseif($dep->status === 'rejected')
                <span class="badge badge-danger"><i class="fa fa-times"></i> {{ __('front.deposit.rejected') }}</span>
                @else
                <span class="badge badge-warning"><i class="fa fa-clock"></i> {{ __('front.deposit.pending') }}</span>
                @endif
            </div>
        </div>
    </div>
    @empty
    <div style="padding:40px; text-align:center; color:var(--gray);">
        <i class="fa fa-receipt" style="font-size:32px; opacity:.3; display:block; margin-bottom:10px;"></i>
        {{ __('front.deposit.no_deposits') }}
    </div>
    @endforelse
</div>

@if($deposits->hasPages())
<div style="margin-top:16px; text-align:center;">
    {{ $deposits->links() }}
</div>
@endif

@endsection

@section('scripts')
<script>
let selectedMethod = null;

function showMethodDetails(sel) {
    const opt = sel.options[sel.selectedIndex];
    const info = document.getElementById('methodInfo');
    if (!opt.value) { info.style.display = 'none'; selectedMethod = null; return; }

    selectedMethod = {
        number: opt.dataset.number,
        charge: parseFloat(opt.dataset.charge),
        min: parseFloat(opt.dataset.min),
        max: parseFloat(opt.dataset.max),
    };

    document.getElementById('methodNumber').textContent = opt.dataset.number || '—';
    document.getElementById('methodCharge').textContent =
        '{{ __('front.deposit.commission_label') }} ' + opt.dataset.charge + '%  |  {{ __('front.deposit.min_label') }} ' + opt.dataset.min + '  |  {{ __('front.deposit.max_label') }} ' + opt.dataset.max;
    info.style.display = 'block';
    calcCharge();
}

function calcCharge() {
    if (!selectedMethod) return;
    const amount = parseFloat(document.querySelector('[name=amount]').value) || 0;
    const charge = (amount * selectedMethod.charge / 100).toFixed(2);
    const net = (amount - charge).toFixed(2);
    document.getElementById('chargeInfo').textContent =
        amount > 0 ? `{{ __('front.deposit.commission_label') }} ${charge} | {{ __('front.deposit.credited_label') }} ${net}` : '';
}

function previewScreenshot(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        document.getElementById('screenshotImg').src = e.target.result;
        document.getElementById('screenshotName').textContent = file.name;
        document.getElementById('screenshotDefault').style.display = 'none';
        document.getElementById('screenshotPreview').style.display = 'block';
        // Border rangini yashil qil
        document.getElementById('screenshotPicker').style.borderColor = 'rgba(16,185,129,.6)';
        document.getElementById('screenshotPicker').style.background = 'rgba(16,185,129,.05)';
    };
    reader.readAsDataURL(file);
}

// Drag & drop support
const picker = document.getElementById('screenshotPicker');
if (picker) {
    picker.addEventListener('dragover', e => {
        e.preventDefault();
        picker.style.borderColor = 'rgba(99,102,241,.9)';
        picker.style.background = 'rgba(99,102,241,.15)';
    });
    picker.addEventListener('dragleave', () => {
        picker.style.borderColor = 'rgba(99,102,241,.4)';
        picker.style.background = 'rgba(99,102,241,.05)';
    });
    picker.addEventListener('drop', e => {
        e.preventDefault();
        const dt = e.dataTransfer;
        if (dt.files.length) {
            const inp = document.getElementById('screenshotInput');
            inp.files = dt.files;
            previewScreenshot(inp);
        }
    });
}
</script>
@endsection
