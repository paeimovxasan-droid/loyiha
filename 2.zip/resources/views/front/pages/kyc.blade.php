@extends('front.layouts.app')
@section('title', 'KYC Tasdiqlash')
@section('content')

<div class="page-title">🪪 KYC Tasdiqlash</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

{{-- Holat kartasi --}}
<div class="card" style="margin-bottom:20px; padding:20px;">
    <div style="display:flex; align-items:center; gap:14px;">
        <div style="width:52px; height:52px; border-radius:16px; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-size:24px;
            background:{{ match($user->kyc_status) {
                'verified'          => 'rgba(16,185,129,.15)',
                'passport_pending'  => 'rgba(245,158,11,.15)',
                'passport_verified' => 'rgba(99,102,241,.15)',
                'face_pending'      => 'rgba(245,158,11,.15)',
                'rejected'          => 'rgba(239,68,68,.15)',
                default             => 'rgba(100,116,139,.15)',
            } }};">
            {{ match($user->kyc_status) {
                'verified'          => '✅',
                'passport_pending'  => '⏳',
                'passport_verified' => '🪪',
                'face_pending'      => '🤳',
                'rejected'          => '❌',
                default             => '🪪',
            } }}
        </div>
        <div>
            <div style="font-size:15px; font-weight:700; color:#f1f5f9;">
                @if($user->kyc_status === 'verified') Tasdiqlangan
                @elseif($user->kyc_status === 'passport_pending') Pasport ko'rib chiqilmoqda
                @elseif($user->kyc_status === 'passport_verified') Pasport tasdiqlandi — Face ID kerak
                @elseif($user->kyc_status === 'face_pending') Face ID ko'rib chiqilmoqda
                @elseif($user->kyc_status === 'rejected') Rad etildi
                @else Tasdiqlanmagan
                @endif
            </div>
            <div style="font-size:12px; color:var(--gray); margin-top:2px;">
                @if($user->kyc_status === 'verified')
                    {{ $user->kyc_verified_at?->format('d.m.Y') }} da tasdiqlandi
                @elseif($user->kyc_status === 'passport_pending')
                    24 soat ichida ko'rib chiqiladi
                @elseif($user->kyc_status === 'passport_verified')
                    Endi Face ID bosqichini o'ting
                @elseif($user->kyc_status === 'face_pending')
                    24 soat ichida natija bildiriladi
                @elseif($user->kyc_status === 'rejected')
                    Sabab: {{ $user->kyc_rejection_reason ?? 'Ko\'rsatilmagan' }}
                @else
                    Hujjat yuklanmagan
                @endif
            </div>
        </div>
        @if($user->kyc_status === 'verified')
        <div style="margin-left:auto;">
            <span class="badge badge-success"><i class="fa fa-shield-halved"></i> Verified</span>
        </div>
        @endif
    </div>
</div>

{{-- Bosqichlar ko'rsatkichi --}}
<div class="card" style="margin-bottom:20px; padding:18px;">
    <div style="font-size:13px; font-weight:600; color:#94a3b8; text-transform:uppercase; letter-spacing:.4px; margin-bottom:14px;">
        KYC Bosqichlari
    </div>
    <div style="display:flex; align-items:center; gap:0;">
        {{-- Bosqich 1: Pasport --}}
        @php
            $step1Done = in_array($user->kyc_status, ['passport_verified', 'face_pending', 'verified']);
            $step1Active = $user->kyc_status === 'passport_pending';
            $step2Done = $user->kyc_status === 'verified';
            $step2Active = in_array($user->kyc_status, ['passport_verified', 'face_pending']);
        @endphp
        <div style="display:flex; flex-direction:column; align-items:center; flex:1;">
            <div style="width:36px; height:36px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:700;
                background:{{ $step1Done ? 'rgba(16,185,129,.2)' : ($step1Active ? 'rgba(245,158,11,.2)' : 'rgba(100,116,139,.15)') }};
                color:{{ $step1Done ? '#34d399' : ($step1Active ? '#fbbf24' : '#64748b') }};
                border: 2px solid {{ $step1Done ? '#34d399' : ($step1Active ? '#fbbf24' : '#334155') }};">
                {{ $step1Done ? '✓' : '1' }}
            </div>
            <div style="font-size:11px; margin-top:6px; font-weight:600; color:{{ $step1Done ? '#34d399' : ($step1Active ? '#fbbf24' : '#64748b') }};">
                Pasport
            </div>
            <div style="font-size:10px; color:#475569; margin-top:2px;">
                {{ $step1Done ? 'Tasdiqlandi' : ($step1Active ? 'Ko\'rib chiqilmoqda' : 'Kutilmoqda') }}
            </div>
        </div>
        {{-- Chiziq --}}
        <div style="flex:1; height:2px; background:{{ $step1Done ? '#34d399' : '#1e293b' }}; margin-bottom:20px;"></div>
        {{-- Bosqich 2: Face ID --}}
        <div style="display:flex; flex-direction:column; align-items:center; flex:1;">
            <div style="width:36px; height:36px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-size:16px; font-weight:700;
                background:{{ $step2Done ? 'rgba(16,185,129,.2)' : ($step2Active ? 'rgba(245,158,11,.2)' : 'rgba(100,116,139,.15)') }};
                color:{{ $step2Done ? '#34d399' : ($step2Active ? '#fbbf24' : '#64748b') }};
                border: 2px solid {{ $step2Done ? '#34d399' : ($step2Active ? '#fbbf24' : '#334155') }};">
                {{ $step2Done ? '✓' : '2' }}
            </div>
            <div style="font-size:11px; margin-top:6px; font-weight:600; color:{{ $step2Done ? '#34d399' : ($step2Active ? '#fbbf24' : '#64748b') }};">
                Face ID
            </div>
            <div style="font-size:10px; color:#475569; margin-top:2px;">
                {{ $step2Done ? 'Tasdiqlandi' : ($step2Active ? 'Jarayonda' : 'Kutilmoqda') }}
            </div>
        </div>
    </div>
</div>

{{-- KYC afzalliklari --}}
@if($user->kyc_status === 'none' || $user->kyc_status === null)
<div class="card" style="margin-bottom:20px; padding:18px;">
    <div style="font-size:13px; font-weight:600; color:#94a3b8; text-transform:uppercase; letter-spacing:.4px; margin-bottom:12px;">
        KYC tasdiqlash afzalliklari
    </div>
    <div style="display:flex; flex-direction:column; gap:8px;">
        @foreach([
            ['+50 XP', 'Bir martalik bonus', '#818cf8'],
            ['Limit oshadi', 'Yechish limiti 2x oshadi', '#34d399'],
            ['Ishonch belgisi', 'Profilingizda ✅ belgisi', '#fbbf24'],
            ['Xavfsizlik', 'Hisobingiz himoyalangan', '#06b6d4'],
        ] as [$title, $desc, $color])
        <div style="display:flex; align-items:center; gap:10px;">
            <div style="width:8px; height:8px; border-radius:50%; background:{{ $color }}; flex-shrink:0;"></div>
            <div>
                <span style="font-size:13px; font-weight:600; color:{{ $color }};">{{ $title }}</span>
                <span style="font-size:12px; color:var(--gray); margin-left:6px;">— {{ $desc }}</span>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endif

{{-- ═══════════════════════════════════════════════════════════════ --}}
{{-- 1-BOSQICH: Pasport yuklash --}}
{{-- ═══════════════════════════════════════════════════════════════ --}}
@if(in_array($user->kyc_status, ['none', null, 'rejected']))
<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fa fa-id-card"></i> 1-bosqich: Pasport yuklash</span>
    </div>
    <div class="card-body">
        <div class="alert alert-info" style="margin-bottom:16px;">
            <i class="fa fa-info-circle"></i>
            <div style="font-size:12px;">
                Passport yoki ID kartangizning <strong>old tomoni</strong> rasmini yuklang (majburiy).
                Orqa tomoni ixtiyoriy. Rasm 5MB dan oshmasin. Formatlar: JPG, PNG, WEBP.
            </div>
        </div>

        <form method="POST" action="{{ route('app.kyc.passport') }}" enctype="multipart/form-data">
            @csrf

            {{-- Hujjat turi --}}
            <div class="form-group" style="margin-bottom:16px;">
                <label class="form-label">Hujjat turi</label>
                <select name="document_type" class="form-control" required>
                    <option value="passport">Pasport</option>
                    <option value="id_card">ID karta</option>
                </select>
            </div>

            {{-- Old tomoni --}}
            <div class="form-group" style="margin-bottom:16px;">
                <label class="form-label">Old tomoni <span style="color:#ef4444;">*</span></label>
                <div id="frontPicker"
                     onclick="document.getElementById('frontInput').click()"
                     style="border:2px dashed rgba(99,102,241,.4); border-radius:16px; padding:20px;
                            text-align:center; cursor:pointer; background:rgba(99,102,241,.05); transition:all .2s;"
                     onmouseenter="this.style.borderColor='rgba(99,102,241,.8)'"
                     onmouseleave="this.style.borderColor='rgba(99,102,241,.4)'">
                    <div id="frontDefault">
                        <i class="fa fa-id-card" style="font-size:28px; color:#818cf8; display:block; margin-bottom:8px;"></i>
                        <div style="font-size:13px; font-weight:600; color:#c7d2fe;">Old tomoni rasmini tanlang</div>
                        <div style="font-size:11px; color:var(--gray); margin-top:3px;">JPG, PNG, WEBP — max 5MB</div>
                    </div>
                    <div id="frontPreview" style="display:none;">
                        <img id="frontImg" src="" style="max-width:100%; max-height:160px; border-radius:10px; object-fit:contain;">
                        <div style="font-size:11px; color:#818cf8; margin-top:6px;" id="frontName"></div>
                    </div>
                </div>
                <input type="file" id="frontInput" name="document_front" accept="image/*"
                       style="display:none;" onchange="previewImage(this,'frontImg','frontName','frontDefault','frontPreview','frontPicker')" required>
                @error('document_front')
                <div class="invalid-feedback" style="display:block;"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div>
                @enderror
            </div>

            {{-- Orqa tomoni --}}
            <div class="form-group" style="margin-bottom:20px;">
                <label class="form-label">Orqa tomoni <span style="color:#64748b; font-size:11px;">(ixtiyoriy)</span></label>
                <div id="backPicker"
                     onclick="document.getElementById('backInput').click()"
                     style="border:2px dashed rgba(99,102,241,.25); border-radius:16px; padding:16px;
                            text-align:center; cursor:pointer; background:rgba(99,102,241,.03); transition:all .2s;"
                     onmouseenter="this.style.borderColor='rgba(99,102,241,.6)'"
                     onmouseleave="this.style.borderColor='rgba(99,102,241,.25)'">
                    <div id="backDefault">
                        <i class="fa fa-id-card" style="font-size:22px; color:#64748b; display:block; margin-bottom:6px;"></i>
                        <div style="font-size:12px; color:#64748b;">Orqa tomoni (ixtiyoriy)</div>
                    </div>
                    <div id="backPreview" style="display:none;">
                        <img id="backImg" src="" style="max-width:100%; max-height:120px; border-radius:10px; object-fit:contain;">
                        <div style="font-size:11px; color:#818cf8; margin-top:6px;" id="backName"></div>
                    </div>
                </div>
                <input type="file" id="backInput" name="document_back" accept="image/*"
                       style="display:none;" onchange="previewImage(this,'backImg','backName','backDefault','backPreview','backPicker')">
            </div>

            <button type="submit" class="btn btn-primary btn-full btn-lg">
                <i class="fa fa-paper-plane"></i> Pasportni yuborish
            </button>
        </form>
    </div>
</div>
@endif

{{-- ═══════════════════════════════════════════════════════════════ --}}
{{-- Pasport ko'rib chiqilmoqda --}}
{{-- ═══════════════════════════════════════════════════════════════ --}}
@if($user->kyc_status === 'passport_pending')
<div class="card" style="text-align:center; padding:28px;">
    <div style="font-size:40px; margin-bottom:12px;">⏳</div>
    <div style="font-size:16px; font-weight:700; color:#f1f5f9; margin-bottom:8px;">Pasportingiz ko'rib chiqilmoqda</div>
    <div style="font-size:13px; color:#94a3b8;">Admin 24 soat ichida ko'rib chiqadi. Natija Telegram orqali bildiriladi.</div>
</div>
@endif

{{-- ═══════════════════════════════════════════════════════════════ --}}
{{-- 2-BOSQICH: Face ID --}}
{{-- ═══════════════════════════════════════════════════════════════ --}}
@if($user->kyc_status === 'passport_verified')
<div class="card">
    <div class="card-header">
        <span class="card-title"><i class="fa fa-camera"></i> 2-bosqich: Face ID</span>
    </div>
    <div class="card-body">
        <div class="alert alert-success" style="margin-bottom:16px;">
            <i class="fa fa-check-circle"></i>
            <div style="font-size:12px;">
                <strong>Pasportingiz tasdiqlandi!</strong> Endi yuz orqali identifikatsiyani o'ting.
            </div>
        </div>

        <div id="faceIdSection">
            {{-- Challenge ko'rsatish joyi --}}
            <div id="challengeBox" style="display:none; background:rgba(99,102,241,.1); border-radius:12px; padding:16px; margin-bottom:16px; text-align:center;">
                <div style="font-size:12px; color:#94a3b8; margin-bottom:8px;">Kamera oldida bajaring:</div>
                <div id="challengeSteps" style="font-size:18px; font-weight:700; color:#818cf8; letter-spacing:2px;"></div>
                <div style="font-size:11px; color:#64748b; margin-top:6px;" id="sessionExpiry"></div>
            </div>

            <form id="faceIdForm" method="POST" action="{{ route('app.kyc.face.submit') }}" enctype="multipart/form-data" style="display:none;">
                @csrf
                <input type="hidden" name="session_id" id="sessionIdInput">
                <input type="hidden" name="document_type" value="passport">
                <input type="hidden" name="liveness_passed" value="1">
                <input type="hidden" name="liveness_score" value="0.85">

                <div class="form-group" style="margin-bottom:16px;">
                    <label class="form-label">Selfi (yuz rasmi) <span style="color:#ef4444;">*</span></label>
                    <div id="selfiePicker"
                         onclick="document.getElementById('selfieInput').click()"
                         style="border:2px dashed rgba(99,102,241,.4); border-radius:16px; padding:20px;
                                text-align:center; cursor:pointer; background:rgba(99,102,241,.05); transition:all .2s;"
                         onmouseenter="this.style.borderColor='rgba(99,102,241,.8)'"
                         onmouseleave="this.style.borderColor='rgba(99,102,241,.4)'">
                        <div id="selfieDefault">
                            <i class="fa fa-camera" style="font-size:28px; color:#818cf8; display:block; margin-bottom:8px;"></i>
                            <div style="font-size:13px; font-weight:600; color:#c7d2fe;">Selfi rasmini tanlang</div>
                            <div style="font-size:11px; color:var(--gray); margin-top:3px;">Yuzingiz aniq ko'rinsin</div>
                        </div>
                        <div id="selfiePreview" style="display:none;">
                            <img id="selfieImg" src="" style="max-width:100%; max-height:160px; border-radius:10px; object-fit:contain;">
                            <div style="font-size:11px; color:#818cf8; margin-top:6px;" id="selfieName"></div>
                        </div>
                    </div>
                    <input type="file" id="selfieInput" name="selfie" accept="image/*"
                           style="display:none;" onchange="previewImage(this,'selfieImg','selfieName','selfieDefault','selfiePreview','selfiePicker')" required>
                </div>

                <div class="form-group" style="margin-bottom:20px;">
                    <label class="form-label">Pasport rasmi (solishtirish uchun) <span style="color:#ef4444;">*</span></label>
                    <div id="docPicker"
                         onclick="document.getElementById('docInput').click()"
                         style="border:2px dashed rgba(99,102,241,.4); border-radius:16px; padding:20px;
                                text-align:center; cursor:pointer; background:rgba(99,102,241,.05); transition:all .2s;"
                         onmouseenter="this.style.borderColor='rgba(99,102,241,.8)'"
                         onmouseleave="this.style.borderColor='rgba(99,102,241,.4)'">
                        <div id="docDefault">
                            <i class="fa fa-id-card" style="font-size:28px; color:#818cf8; display:block; margin-bottom:8px;"></i>
                            <div style="font-size:13px; font-weight:600; color:#c7d2fe;">Pasport rasmini tanlang</div>
                        </div>
                        <div id="docPreview" style="display:none;">
                            <img id="docImg" src="" style="max-width:100%; max-height:160px; border-radius:10px; object-fit:contain;">
                            <div style="font-size:11px; color:#818cf8; margin-top:6px;" id="docName"></div>
                        </div>
                    </div>
                    <input type="file" id="docInput" name="document_front" accept="image/*"
                           style="display:none;" onchange="previewImage(this,'docImg','docName','docDefault','docPreview','docPicker')" required>
                </div>

                <button type="submit" class="btn btn-primary btn-full btn-lg">
                    <i class="fa fa-paper-plane"></i> Face ID yuborish
                </button>
            </form>

            <button type="button" id="startFaceIdBtn" class="btn btn-primary btn-full btn-lg" onclick="startFaceId()">
                <i class="fa fa-camera"></i> Face ID boshlash
            </button>
        </div>
    </div>
</div>
@endif

{{-- Face ID ko'rib chiqilmoqda --}}
@if($user->kyc_status === 'face_pending')
<div class="card" style="text-align:center; padding:28px;">
    <div style="font-size:40px; margin-bottom:12px;">🤳</div>
    <div style="font-size:16px; font-weight:700; color:#f1f5f9; margin-bottom:8px;">Face ID ko'rib chiqilmoqda</div>
    <div style="font-size:13px; color:#94a3b8;">Admin 24 soat ichida ko'rib chiqadi. Natija Telegram orqali bildiriladi.</div>
</div>
@endif

{{-- Tasdiqlangan --}}
@if($user->kyc_status === 'verified')
<div class="card" style="text-align:center; padding:28px;">
    <div style="font-size:48px; margin-bottom:12px;">✅</div>
    <div style="font-size:18px; font-weight:700; color:#34d399; margin-bottom:8px;">KYC Tasdiqlandi!</div>
    <div style="font-size:13px; color:#94a3b8;">Siz barcha moliyaviy amallarni bajara olasiz.</div>
    @if($user->kyc_verified_at)
    <div style="font-size:11px; color:#475569; margin-top:8px;">{{ $user->kyc_verified_at->format('d.m.Y H:i') }}</div>
    @endif
</div>
@endif

@endsection

@section('scripts')
<script>
function previewImage(input, imgId, nameId, defaultId, previewId, pickerId) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = e => {
        document.getElementById(imgId).src = e.target.result;
        document.getElementById(nameId).textContent = file.name;
        document.getElementById(defaultId).style.display = 'none';
        document.getElementById(previewId).style.display = 'block';
        document.getElementById(pickerId).style.borderColor = 'rgba(16,185,129,.6)';
    };
    reader.readAsDataURL(file);
}

async function startFaceId() {
    const btn = document.getElementById('startFaceIdBtn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Yuklanmoqda...';

    try {
        const response = await fetch('{{ route("app.kyc.face.start") }}', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Accept': 'application/json',
            }
        });
        const data = await response.json();

        if (data.error) {
            alert(data.error);
            btn.disabled = false;
            btn.innerHTML = '<i class="fa fa-camera"></i> Face ID boshlash';
            return;
        }

        // Session ID ni formga qo'yish
        document.getElementById('sessionIdInput').value = data.session_id;

        // Challenge ko'rsatish
        const actionLabels = {
            'turn_left':  '⬅️ Chapga qaring',
            'turn_right': '➡️ O\'ngga qaring',
            'blink':      '👁️ Ko\'z qirpiting',
            'smile':      '😊 Kuling',
            'nod':        '⬇️ Bosh irg\'ang',
        };
        const steps = data.challenge.map(s => actionLabels[s] || s).join('  •  ');
        document.getElementById('challengeSteps').textContent = steps;

        const expiry = new Date(data.expires_at);
        document.getElementById('sessionExpiry').textContent = '10 daqiqa ichida yuborish kerak';

        document.getElementById('challengeBox').style.display = 'block';
        document.getElementById('faceIdForm').style.display = 'block';
        btn.style.display = 'none';

    } catch (e) {
        alert('Xato yuz berdi. Qaytadan urinib ko\'ring.');
        btn.disabled = false;
        btn.innerHTML = '<i class="fa fa-camera"></i> Face ID boshlash';
    }
}
</script>
@endsection
