@extends('front.layouts.app')
@section('title', 'Kredit')
@section('content')

<div class="page-title">💳 Kredit</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

{{-- Active credit --}}
@if($activeCredit)
<div class="card" style="margin-bottom:20px; border-left:3px solid #34d399;">
    <div style="padding:20px;">
        <div style="font-size:13px; color:var(--gray); margin-bottom:8px;">
            <i class="fa fa-check-circle" style="color:#34d399;"></i> Faol kredit
        </div>
        <div style="display:flex; gap:8px; margin-bottom:14px;">
            <div style="flex:1; background:rgba(16,185,129,.08); border-radius:10px; padding:12px; text-align:center;">
                <div style="font-size:18px; font-weight:800; color:#34d399;">{{ number_format($activeCredit->amount) }}</div>
                <div style="font-size:10px; color:var(--gray);">Miqdor (UZS)</div>
            </div>
            <div style="flex:1; background:rgba(245,158,11,.08); border-radius:10px; padding:12px; text-align:center;">
                <div style="font-size:18px; font-weight:800; color:#fbbf24;">{{ $activeCredit->interest_rate }}%</div>
                <div style="font-size:10px; color:var(--gray);">Foiz</div>
            </div>
            <div style="flex:1; background:rgba(99,102,241,.08); border-radius:10px; padding:12px; text-align:center;">
                <div style="font-size:18px; font-weight:800; color:#818cf8;">{{ $activeCredit->term_days }}</div>
                <div style="font-size:10px; color:var(--gray);">Kun</div>
            </div>
        </div>
        <div style="font-size:12px; color:var(--gray);">
            Muddat: {{ $activeCredit->due_date?->format('d.m.Y') ?? '—' }}
        </div>
    </div>
</div>
@endif

{{-- Apply form --}}
@if(!$activeCredit)
<div class="card" style="margin-bottom:20px;">
    <div style="padding:20px;">
        <div style="font-size:15px; font-weight:700; color:#f1f5f9; margin-bottom:16px;">
            <i class="fa fa-file-invoice-dollar"></i> Kredit olish
        </div>
        <form method="POST" action="{{ route('app.credit.apply') }}">
            @csrf
            <div style="margin-bottom:12px;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Miqdor (UZS)</label>
                <input type="number" name="amount" min="50000" step="10000" required
                       class="form-control" placeholder="Miqdor kiriting">
            </div>
            <div style="margin-bottom:14px;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Muddat</label>
                <select name="term_days" class="form-control" required>
                    <option value="30">30 kun — 5%</option>
                    <option value="60">60 kun — 8%</option>
                    <option value="90">90 kun — 10%</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;">
                <i class="fa fa-paper-plane"></i> Ariza yuborish
            </button>
        </form>
    </div>
</div>
@endif

{{-- Credit history --}}
@if($credits->count())
<p class="section-label">Kredit tarixi</p>
<div class="card">
    @foreach($credits as $credit)
    <div class="list-item">
        <div style="width:40px; height:40px; border-radius:12px; flex-shrink:0;
                    background:{{ $credit->status === 'active' ? 'rgba(16,185,129,.1)' : ($credit->status === 'overdue' ? 'rgba(239,68,68,.1)' : 'rgba(100,116,139,.1)') }};
                    display:flex; align-items:center; justify-content:center;">
            <i class="fa fa-credit-card"
               style="color:{{ $credit->status === 'active' ? '#34d399' : ($credit->status === 'overdue' ? '#f87171' : 'var(--gray)') }};"></i>
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:500; color:#e2e8f0;">
                {{ number_format($credit->amount) }} UZS
            </div>
            <div style="font-size:11px; color:var(--gray);">
                {{ $credit->term_days }} kun · {{ $credit->interest_rate }}%
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <span style="font-size:10px; padding:2px 8px; border-radius:10px;
                         background:{{ $credit->status === 'active' ? 'rgba(16,185,129,.15)' : ($credit->status === 'overdue' ? 'rgba(239,68,68,.15)' : 'rgba(100,116,139,.15)') }};
                         color:{{ $credit->status === 'active' ? '#34d399' : ($credit->status === 'overdue' ? '#f87171' : 'var(--gray)') }};">
                {{ $credit->status }}
            </span>
        </div>
    </div>
    @endforeach
</div>
@endif

@endsection
