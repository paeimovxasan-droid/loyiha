@extends('front.layouts.app')
@section('title', 'Ticket #' . $ticket->ticket_number)
@section('content')

{{-- Header --}}
<div style="display:flex; align-items:center; gap:12px; margin-bottom:16px;">
    <a href="{{ route('app.support.index') }}" style="color:var(--gray); font-size:18px;">
        <i class="fa fa-arrow-left"></i>
    </a>
    <div style="flex:1; min-width:0;">
        <div style="font-size:11px; color:var(--gray); font-family:monospace;">
            #{{ $ticket->ticket_number }}
        </div>
        <div style="font-size:15px; font-weight:700; color:#f1f5f9; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
            {{ $ticket->subject }}
        </div>
    </div>
    {!! $ticket->status_badge !!}
</div>

{{-- Info --}}
<div style="display:flex; gap:8px; flex-wrap:wrap; margin-bottom:16px;">
    <span style="font-size:11px; background:rgba(255,255,255,.05); border-radius:8px; padding:4px 10px; color:var(--gray);">
        🏷️ {{ $ticket->category_label }}
    </span>
    <span style="font-size:11px; background:rgba(255,255,255,.05); border-radius:8px; padding:4px 10px; color:{{ $ticket->priority_color }};">
        ⚡ {{ $ticket->priority_label }}
    </span>
    <span style="font-size:11px; background:rgba(255,255,255,.05); border-radius:8px; padding:4px 10px; color:var(--gray);">
        📅 {{ $ticket->created_at->format('d.m.Y H:i') }}
    </span>
</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

{{-- Xabarlar --}}
<div style="display:flex; flex-direction:column; gap:12px; margin-bottom:20px;">
    @foreach($messages as $msg)
    @php $isAdmin = $msg->is_admin_reply; @endphp
    <div style="display:flex; {{ $isAdmin ? '' : 'flex-direction:row-reverse;' }} gap:10px; align-items:flex-end;">

        {{-- Avatar --}}
        <div style="width:36px; height:36px; border-radius:12px; flex-shrink:0; overflow:hidden;
                    border:2px solid {{ $isAdmin ? 'rgba(99,102,241,.4)' : 'rgba(16,185,129,.4)' }};">
            <img src="{{ $msg->user->avatar_url }}" style="width:100%; height:100%; object-fit:cover;">
        </div>

        {{-- Xabar --}}
        <div style="max-width:80%;">
            <div style="font-size:10px; color:var(--gray); margin-bottom:4px;
                        {{ $isAdmin ? '' : 'text-align:right;' }}">
                {{ $isAdmin ? '🛡️ Support' : auth()->user()->name }}
                · {{ $msg->created_at->format('d.m H:i') }}
            </div>
            <div style="background:{{ $isAdmin ? 'rgba(99,102,241,.12)' : 'rgba(16,185,129,.1)' }};
                        border:1px solid {{ $isAdmin ? 'rgba(99,102,241,.2)' : 'rgba(16,185,129,.2)' }};
                        border-radius:{{ $isAdmin ? '4px 16px 16px 16px' : '16px 4px 16px 16px' }};
                        padding:12px 16px;">
                <div style="font-size:14px; color:#e2e8f0; line-height:1.6; white-space:pre-wrap;">{{ $msg->message }}</div>
                @if($msg->attachment_url)
                <a href="{{ $msg->attachment_url }}" target="_blank"
                   style="display:inline-flex; align-items:center; gap:6px; margin-top:8px;
                          font-size:12px; color:#818cf8; text-decoration:none;">
                    <i class="fa fa-paperclip"></i> Fayl ko'rish
                </a>
                @endif
            </div>
        </div>
    </div>
    @endforeach
</div>

{{-- Javob formasi --}}
@if($ticket->isOpen())
<div class="card" style="padding:16px;">
    <form method="POST" action="{{ route('app.support.reply', $ticket) }}" enctype="multipart/form-data">
        @csrf
        <textarea name="message" class="form-control" rows="4"
                  placeholder="Javobingizni yozing..."
                  minlength="2" maxlength="5000" required
                  style="margin-bottom:10px;"></textarea>
        <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
            <input type="file" name="attachment" class="form-control" style="flex:1; min-width:150px;"
                   accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
            <button type="submit" class="btn btn-primary" style="white-space:nowrap;">
                <i class="fa fa-paper-plane"></i> Yuborish
            </button>
        </div>
    </form>
</div>

{{-- Yopish tugmasi --}}
<form method="POST" action="{{ route('app.support.close', $ticket) }}" style="margin-top:10px;">
    @csrf
    <button type="submit" class="btn btn-sm"
            style="width:100%; background:rgba(255,255,255,.05); color:var(--gray); border:1px solid rgba(255,255,255,.08);"
            onclick="return confirm('Muammo hal bo\'ldimi? Ticketni yopasizmi?')">
        <i class="fa fa-check"></i> Muammo hal bo'ldi — Yopish
    </button>
</form>

@else
<div style="text-align:center; padding:20px; color:var(--gray); font-size:13px;">
    <i class="fa fa-lock" style="margin-bottom:8px; display:block; font-size:24px; opacity:.4;"></i>
    Ticket yopilgan
</div>
@endif

@endsection
