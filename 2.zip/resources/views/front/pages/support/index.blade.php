@extends('front.layouts.app')
@section('title', 'Support')
@section('content')

<div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:20px;">
    <div class="page-title" style="margin-bottom:0;">🎫 Support</div>
    <a href="{{ route('app.support.create') }}" class="btn btn-primary btn-sm">
        <i class="fa fa-plus"></i> Yangi murojaat
    </a>
</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif

@forelse($tickets as $ticket)
<a href="{{ route('app.support.show', $ticket) }}"
   style="display:block; text-decoration:none; margin-bottom:10px;">
<div class="card" style="padding:16px; transition:all .2s;"
     onmouseenter="this.style.borderColor='rgba(99,102,241,.4)'"
     onmouseleave="this.style.borderColor='transparent'">
    <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:12px;">
        <div style="flex:1; min-width:0;">
            <div style="display:flex; align-items:center; gap:8px; margin-bottom:4px;">
                <span style="font-size:11px; color:var(--gray); font-family:monospace;">
                    #{{ $ticket->ticket_number }}
                </span>
                {!! $ticket->status_badge !!}
                @php $unread = $ticket->messages()->where('is_admin_reply', true)->where('is_read', false)->count(); @endphp
                @if($unread > 0)
                <span style="background:#ef4444; color:#fff; font-size:10px; font-weight:700;
                             padding:2px 7px; border-radius:20px;">{{ $unread }} yangi</span>
                @endif
            </div>
            <div style="font-size:14px; font-weight:600; color:#f1f5f9; margin-bottom:4px;
                        white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                {{ $ticket->subject }}
            </div>
            <div style="font-size:11px; color:var(--gray);">
                {{ $ticket->category_label }}
                · {{ $ticket->created_at->diffForHumans() }}
            </div>
        </div>
        <div style="flex-shrink:0; text-align:right;">
            <div style="font-size:11px; color:var(--gray);">
                {{ $ticket->messages()->count() }} xabar
            </div>
            @if($ticket->lastMessage)
            <div style="font-size:10px; color:var(--gray); margin-top:2px;">
                {{ $ticket->lastMessage->created_at->format('d.m H:i') }}
            </div>
            @endif
        </div>
    </div>
</div>
</a>
@empty
<div class="card" style="padding:50px; text-align:center;">
    <div style="font-size:40px; margin-bottom:14px;">🎫</div>
    <div style="color:var(--gray); font-size:14px; margin-bottom:16px;">
        Hali murojaat yuborilmagan
    </div>
    <a href="{{ route('app.support.create') }}" class="btn btn-primary">
        Birinchi murojaatni yuborish
    </a>
</div>
@endforelse

<div style="margin-top:16px;">{{ $tickets->links() }}</div>

@endsection
