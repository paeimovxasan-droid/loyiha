@extends('front.layouts.app')
@section('title', 'Yangi Murojaat')
@section('content')

<div style="display:flex; align-items:center; gap:12px; margin-bottom:20px;">
    <a href="{{ route('app.support.index') }}" style="color:var(--gray); font-size:18px;">
        <i class="fa fa-arrow-left"></i>
    </a>
    <div class="page-title" style="margin-bottom:0;">🎫 Yangi Murojaat</div>
</div>

@if($errors->any())
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ $errors->first() }}</div>
@endif

<div class="card" style="padding:20px;">
    <form method="POST" action="{{ route('app.support.store') }}" enctype="multipart/form-data">
        @csrf

        <div class="form-group">
            <label class="form-label">Kategoriya *</label>
            <select name="category" class="form-control" required>
                <option value="">Tanlang...</option>
                @foreach($categories as $key => $label)
                <option value="{{ $key }}" {{ old('category') === $key ? 'selected' : '' }}>
                    {{ $label }}
                </option>
                @endforeach
            </select>
        </div>

        <div class="form-group">
            <label class="form-label">Mavzu *</label>
            <input type="text" name="subject" value="{{ old('subject') }}"
                   class="form-control" placeholder="Muammoingizni qisqacha yozing..."
                   maxlength="255" required>
        </div>

        <div class="form-group">
            <label class="form-label">Xabar *</label>
            <textarea name="message" class="form-control" rows="6"
                      placeholder="Muammoingizni batafsil tushuntiring..."
                      minlength="10" maxlength="5000" required>{{ old('message') }}</textarea>
            <div style="font-size:11px; color:var(--gray); margin-top:4px;">Minimal 10 ta belgi</div>
        </div>

        <div class="form-group">
            <label class="form-label">Fayl biriktirish (ixtiyoriy)</label>
            <input type="file" name="attachment" class="form-control"
                   accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
            <div style="font-size:11px; color:var(--gray); margin-top:4px;">
                JPG, PNG, PDF, DOC — max 5MB
            </div>
        </div>

        <button type="submit" class="btn btn-primary btn-full">
            <i class="fa fa-paper-plane"></i> Yuborish
        </button>
    </form>
</div>

@endsection
