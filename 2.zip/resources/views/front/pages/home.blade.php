<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title>{{ $setting->getTranslation('site_name', app()->getLocale()) ?? 'AISOQQA' }} — Moliyaviy Super-Platforma</title>
<meta name="description" content="AISOQQA — AIS valyuta, investitsiya, tibbiyot, ta'lim va 30+ xizmat bitta platformada.">
<link rel="icon" href="{{ $setting->favicon_url ?? '' }}">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:'Inter',sans-serif;background:#050816;color:#e2e8f0;overflow-x:hidden;line-height:1.6}
a{text-decoration:none;color:inherit}

.glow{position:fixed;border-radius:50%;pointer-events:none;z-index:0;filter:blur(100px)}
.glow-1{width:700px;height:700px;background:radial-gradient(circle,rgba(99,102,241,.1),transparent 70%);top:-200px;left:-150px}
.glow-2{width:500px;height:500px;background:radial-gradient(circle,rgba(236,72,153,.07),transparent 70%);bottom:-150px;right:-100px}

.wrap{max-width:1200px;margin:0 auto;padding:0 24px;position:relative;z-index:1}

/* NAV */
.nav{position:fixed;top:0;left:0;right:0;z-index:500;background:rgba(5,8,22,.9);backdrop-filter:blur(20px);border-bottom:1px solid rgba(255,255,255,.04)}
.nav-inner{display:flex;align-items:center;justify-content:space-between;height:64px}
.nav-logo{display:flex;align-items:center;gap:10px;font-size:20px;font-weight:900}
.nav-logo img{width:36px;height:36px;border-radius:10px}
.nav-logo span{background:linear-gradient(135deg,#818cf8,#c084fc);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.nav-links{display:flex;gap:4px}
.nav-links a{font-size:13px;color:#94a3b8;font-weight:500;padding:7px 14px;border-radius:8px;transition:all .2s}
.nav-links a:hover{color:#f1f5f9;background:rgba(255,255,255,.05)}
.nav-btns{display:flex;gap:8px}
.btn-o{padding:9px 20px;border-radius:10px;font-size:13px;font-weight:600;border:1px solid rgba(99,102,241,.3);color:#a5b4fc;transition:all .2s}
.btn-o:hover{background:rgba(99,102,241,.1)}
.btn-f{padding:9px 22px;border-radius:10px;font-size:13px;font-weight:700;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;transition:all .2s}
.btn-f:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(99,102,241,.4)}
.ham{display:none;font-size:20px;color:#94a3b8;cursor:pointer}
.mob{display:none;position:fixed;inset:0;background:rgba(5,8,22,.98);z-index:600;flex-direction:column;align-items:center;justify-content:center;gap:24px}
.mob.open{display:flex}
.mob a{font-size:18px;font-weight:600;color:#e2e8f0}
.mob-x{position:absolute;top:20px;right:20px;font-size:24px;color:#64748b;cursor:pointer}

/* HERO */
.hero{padding:140px 0 80px;text-align:center}
.hero-chip{display:inline-flex;align-items:center;gap:8px;padding:7px 18px;border-radius:24px;background:rgba(99,102,241,.08);border:1px solid rgba(99,102,241,.2);font-size:12px;font-weight:600;color:#a5b4fc;margin-bottom:28px}
.hero h1{font-size:clamp(36px,6.5vw,64px);font-weight:900;line-height:1.06;letter-spacing:-2px;margin-bottom:20px}
.hero h1 .gr{background:linear-gradient(135deg,#6366f1,#a78bfa,#ec4899);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.hero-p{font-size:clamp(15px,2vw,18px);color:#64748b;max-width:620px;margin:0 auto 36px;line-height:1.7}
.hero-btns{display:flex;gap:14px;justify-content:center;flex-wrap:wrap}
.hb{padding:16px 36px;border-radius:14px;font-size:16px;font-weight:700;display:inline-flex;align-items:center;gap:10px;transition:all .25s}
.hb-main{background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;box-shadow:0 8px 32px rgba(99,102,241,.4)}
.hb-main:hover{transform:translateY(-2px);box-shadow:0 12px 40px rgba(99,102,241,.5)}
.hb-tg{background:linear-gradient(135deg,#0088cc,#00aaff);color:#fff}
.hb-tg:hover{transform:translateY(-2px)}

/* STATS */
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:2px;border-radius:20px;overflow:hidden;margin-top:60px;background:rgba(255,255,255,.04)}
.st{padding:28px;text-align:center;background:rgba(5,8,22,.7)}
.st .v{font-size:clamp(24px,3vw,36px);font-weight:900;margin-bottom:4px}
.st .l{font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.5px}

/* SECTIONS */
.sec{padding:100px 0}
.sec-h{text-align:center;margin-bottom:56px}
.sec-h .tag{display:inline-flex;align-items:center;gap:6px;padding:5px 14px;border-radius:20px;font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;margin-bottom:14px}
.sec-h h2{font-size:clamp(26px,4vw,42px);font-weight:900;color:#f1f5f9;margin-bottom:12px;letter-spacing:-.5px}
.sec-h p{font-size:15px;color:#64748b;max-width:560px;margin:0 auto}

/* MODULE SECTION — alternating layout */
.mod{padding:80px 0;border-bottom:1px solid rgba(255,255,255,.03)}
.mod-inner{display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:center}
.mod-inner.rev{direction:rtl}
.mod-inner.rev>*{direction:ltr}
.mod-text .mod-tag{display:inline-flex;align-items:center;gap:6px;padding:5px 14px;border-radius:20px;font-size:11px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;margin-bottom:14px}
.mod-text h2{font-size:clamp(24px,3.5vw,36px);font-weight:900;color:#f1f5f9;margin-bottom:14px;letter-spacing:-.5px}
.mod-text>p{font-size:15px;color:#64748b;line-height:1.7;margin-bottom:20px}
.mod-list{list-style:none;display:flex;flex-direction:column;gap:10px;margin-bottom:24px}
.mod-list li{font-size:14px;color:#94a3b8;display:flex;align-items:center;gap:10px}
.mod-list li i{color:#34d399;font-size:12px;width:18px}
.mod-visual{display:flex;align-items:center;justify-content:center}
.mod-card{width:100%;max-width:380px;border-radius:24px;padding:32px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.06);position:relative;overflow:hidden}
.mod-card::before{content:'';position:absolute;top:-50%;right:-50%;width:200%;height:200%;background:radial-gradient(circle,var(--accent,.06),transparent 60%);pointer-events:none}
.mod-card i.fa-solid,.mod-card i.fa-brands{font-size:inherit}

/* GRID CARDS */
.g3{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.g4{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}
.gc{border-radius:18px;padding:24px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.05);transition:all .3s}
.gc:hover{transform:translateY(-3px);border-color:rgba(99,102,241,.2)}
.gc .ic{width:48px;height:48px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:20px;margin-bottom:12px}
.gc h3{font-size:14px;font-weight:700;color:#f1f5f9;margin-bottom:6px}
.gc p{font-size:12px;color:#64748b;line-height:1.6}
.mod-icon{width:52px;height:52px;border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:22px;margin-bottom:14px}

/* STEPS */
.steps{display:grid;grid-template-columns:repeat(4,1fr);gap:20px}
.stp{text-align:center;padding:24px 16px}
.stp-n{width:56px;height:56px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;display:inline-flex;align-items:center;justify-content:center;font-size:20px;font-weight:900;margin-bottom:16px;box-shadow:0 6px 24px rgba(99,102,241,.4)}
.stp h3{font-size:14px;font-weight:700;color:#f1f5f9;margin-bottom:6px}
.stp p{font-size:12px;color:#64748b}

/* CTA */
.cta-box{padding:64px 48px;border-radius:28px;background:linear-gradient(135deg,rgba(99,102,241,.08),rgba(139,92,246,.05));border:1px solid rgba(99,102,241,.15);text-align:center}
.cta-box h2{font-size:clamp(24px,4vw,40px);font-weight:900;color:#f1f5f9;margin-bottom:14px}
.cta-box p{font-size:16px;color:#94a3b8;margin-bottom:32px}

/* FOOTER */
.ft{padding:48px 0 28px;border-top:1px solid rgba(255,255,255,.04)}
.ft-grid{display:grid;grid-template-columns:2.5fr 1fr 1fr 1fr;gap:40px;margin-bottom:40px}
.ft-brand p{font-size:13px;color:#64748b;margin-top:12px;max-width:280px;line-height:1.7}
.ft-col h4{font-size:12px;font-weight:700;color:#f1f5f9;text-transform:uppercase;letter-spacing:.5px;margin-bottom:14px}
.ft-col a{display:block;font-size:13px;color:#64748b;margin-bottom:8px;transition:color .2s}
.ft-col a:hover{color:#a5b4fc}
.ft-bot{display:flex;align-items:center;justify-content:space-between;padding-top:20px;border-top:1px solid rgba(255,255,255,.04)}
.ft-bot p{font-size:12px;color:#475569}
.soc{display:flex;gap:10px}
.soc a{width:36px;height:36px;border-radius:10px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06);display:flex;align-items:center;justify-content:center;color:#64748b;font-size:15px;transition:all .2s}
.soc a:hover{background:rgba(99,102,241,.1);color:#818cf8}

@media(max-width:768px){
    .nav-links{display:none}.ham{display:block}
    .hero{padding:100px 0 50px}
    .stats{grid-template-columns:repeat(2,1fr)}
    .mod-inner,.mod-inner.rev{grid-template-columns:1fr;direction:ltr}
    .mod-visual{display:none}
    .g3,.g4{grid-template-columns:1fr}
    .steps{grid-template-columns:repeat(2,1fr)}
    .ft-grid{grid-template-columns:1fr}
    .ft-bot{flex-direction:column;gap:12px;text-align:center}
    .cta-box{padding:40px 20px}
}
@media(max-width:480px){
    .hero-btns{flex-direction:column;align-items:stretch}
    .hb{justify-content:center}
    .stats{grid-template-columns:1fr 1fr}
}
</style>
</head>
<body>
<div class="glow glow-1"></div>
<div class="glow glow-2"></div>

<!-- MOBILE MENU -->
<div class="mob" id="mob">
    <span class="mob-x" onclick="document.getElementById('mob').classList.remove('open')"><i class="fa fa-times"></i></span>
    <a href="#ais" onclick="document.getElementById('mob').classList.remove('open')">AIS Valyuta</a>
    <a href="#invest" onclick="document.getElementById('mob').classList.remove('open')">Investitsiya</a>
    <a href="#medical" onclick="document.getElementById('mob').classList.remove('open')">Tibbiyot</a>
    <a href="#exchange" onclick="document.getElementById('mob').classList.remove('open')">Birja</a>
    <a href="#education" onclick="document.getElementById('mob').classList.remove('open')">Ta'lim</a>
    <a href="{{ route('login') }}" class="btn-o">Kirish</a>
    <a href="{{ route('register') }}" class="btn-f">Ro'yxatdan o'tish</a>
</div>

<!-- NAV -->
<nav class="nav">
    <div class="wrap">
        <div class="nav-inner">
            <a href="/" class="nav-logo">
                <img src="{{ $setting->logo_url ?? '' }}" alt="AISOQQA">
                <span>AISOQQA</span>
            </a>
            <div class="nav-links">
                <a href="#ais">AIS Valyuta</a>
                <a href="#invest">Investitsiya</a>
                <a href="#medical">Tibbiyot</a>
                <a href="#exchange">Birja</a>
                <a href="#gamification">Bonuslar</a>
                <a href="#education">Ta'lim</a>
            </div>
            <div class="nav-btns">
                <a href="{{ route('login') }}" class="btn-o">Kirish</a>
                <a href="{{ route('register') }}" class="btn-f">Boshlash →</a>
            </div>
            <div class="ham" onclick="document.getElementById('mob').classList.add('open')"><i class="fa fa-bars"></i></div>
        </div>
    </div>
</nav>

<!-- HERO -->
<section class="hero">
    <div class="wrap">
        <div class="hero-chip"><i class="fa fa-bolt" style="color:#fbbf24"></i> 30+ xizmat bitta platformada</div>
        <h1>Moliyaviy kelajak<br><span class="gr">bugun boshlanadi</span></h1>
        <p class="hero-p">AISOQQA — AIS valyuta, investitsiya, tibbiyot, ta'lim, birja va yana 25+ xizmat. Bitta hisob, bitta platforma, cheksiz imkoniyat.</p>
        <div class="hero-btns">
            <a href="{{ route('register') }}" class="hb hb-main"><i class="fa fa-rocket"></i> Bepul boshlash</a>
            @if($setting->telegram)
            <a href="{{ $setting->telegram }}" target="_blank" class="hb hb-tg"><i class="fa-brands fa-telegram"></i> Telegram</a>
            @endif
        </div>
        <div class="stats">
            <div class="st"><div class="v" style="color:#818cf8">{{ number_format(\App\Models\User::count()) }}+</div><div class="l">Foydalanuvchilar</div></div>
            <div class="st"><div class="v" style="color:#34d399">30+</div><div class="l">Xizmatlar</div></div>
            <div class="st"><div class="v" style="color:#fbbf24">{{ number_format(\App\Models\AIS\AisRate::current()?->rate_uzs ?? 1000) }}</div><div class="l">1 AIS = UZS</div></div>
            <div class="st"><div class="v" style="color:#f472b6">24/7</div><div class="l">Onlayn</div></div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 1: AIS VALYUTA TIZIMI -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="ais">
    <div class="wrap">
        <div class="mod-inner">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(99,102,241,.08);color:#a5b4fc"><i class="fa fa-coins"></i> AIS VALYUTA</div>
                <h2>AIS — platformaning ichki valyutasi</h2>
                <p>Har bir foydalanuvchiga unikal AIS-XXXX-XXXX-XXXX hamyon beriladi. UZS bilan konvertatsiya qiling, P2P transfer yuboring, virtual karta oling.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> UZS ↔ AIS real vaqtda konvertatsiya</li>
                    <li><i class="fa fa-check"></i> P2P transfer (Level 5 dan ochiladi)</li>
                    <li><i class="fa fa-check"></i> Virtual karta (Level 10 dan ochiladi)</li>
                    <li><i class="fa fa-check"></i> Admin tomonidan kurs boshqaruvi</li>
                    <li><i class="fa fa-check"></i> Tranzaksiya tarixi va hisobotlar</li>
                </ul>
                <a href="{{ route('register') }}" class="btn-f" style="display:inline-flex;align-items:center;gap:8px;padding:12px 28px">Hamyon ochish <i class="fa fa-arrow-right" style="font-size:12px"></i></a>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(99,102,241,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#818cf8"><i class="fa-solid fa-wallet"></i></div>
                        <div style="font-size:11px;color:#64748b;margin-bottom:4px">Hamyon raqami</div>
                        <div style="font-size:16px;font-weight:700;color:#a5b4fc;font-family:monospace;margin-bottom:20px">AIS-4821-7390-1256</div>
                        <div style="font-size:11px;color:#64748b;margin-bottom:4px">Balans</div>
                        <div style="font-size:32px;font-weight:900;color:#f1f5f9;margin-bottom:4px">1,250.00 <span style="font-size:14px;color:#64748b">AIS</span></div>
                        <div style="font-size:12px;color:#34d399;margin-bottom:20px">≈ 1,250,000 UZS</div>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                            <div style="padding:10px;border-radius:10px;background:rgba(99,102,241,.1);color:#a5b4fc;font-size:12px;font-weight:600">↑ Transfer</div>
                            <div style="padding:10px;border-radius:10px;background:rgba(16,185,129,.1);color:#34d399;font-size:12px;font-weight:600">↔ Konvert</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 2: INVESTITSIYA PAKETLARI -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="invest">
    <div class="wrap">
        <div class="mod-inner rev">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(245,158,11,.08);color:#fbbf24"><i class="fa fa-box"></i> INVESTITSIYA</div>
                <h2>Kunlik passiv daromad — paketlar va fondlar</h2>
                <p>Investitsiya paketlaridan birini sotib oling va har kuni avtomatik foyda oling. Fondlarga pul qo'yib professional boshqaruv bilan daromad oshiring.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Kunlik mining daromadi (avtomatik)</li>
                    <li><i class="fa fa-check"></i> Turli narx va muddatdagi paketlar</li>
                    <li><i class="fa fa-check"></i> Investitsiya fondlari</li>
                    <li><i class="fa fa-check"></i> 3 darajali referral komissiya</li>
                    <li><i class="fa fa-check"></i> Reinvestitsiya imkoniyati</li>
                </ul>
                <a href="{{ route('register') }}" class="btn-f" style="display:inline-flex;align-items:center;gap:8px;padding:12px 28px">Investitsiya boshlash <i class="fa fa-arrow-right" style="font-size:12px"></i></a>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(245,158,11,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#fbbf24"><i class="fa-solid fa-box-open"></i></div>
                        <div style="font-size:18px;font-weight:800;color:#f1f5f9;margin-bottom:4px">Gold Paket</div>
                        <div style="font-size:28px;font-weight:900;color:#fbbf24;margin-bottom:16px">500,000 UZS</div>
                        <div style="display:flex;flex-direction:column;gap:8px;text-align:left">
                            <div style="display:flex;justify-content:space-between;font-size:13px;padding:8px 12px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Kunlik foyda</span><span style="color:#34d399;font-weight:700">1.2%</span></div>
                            <div style="display:flex;justify-content:space-between;font-size:13px;padding:8px 12px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Muddat</span><span style="color:#f1f5f9;font-weight:700">30 kun</span></div>
                            <div style="display:flex;justify-content:space-between;font-size:13px;padding:8px 12px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Umumiy foyda</span><span style="color:#fbbf24;font-weight:700">36%</span></div>
                            <div style="display:flex;justify-content:space-between;font-size:13px;padding:8px 12px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Referral</span><span style="color:#a5b4fc;font-weight:700">10% / 5% / 2%</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 3: TIBBIYOT XIZMATLARI -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="medical">
    <div class="wrap">
        <div class="mod-inner">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(6,182,212,.08);color:#22d3ee"><i class="fa fa-heart-pulse"></i> TIBBIYOT</div>
                <h2>Onlayn tibbiy maslahat — 15 ixtisoslik</h2>
                <p>Professional shifokorlardan chat orqali maslahat oling. Retsept, analiz yo'llanma, dori yetkazish va uyga chaqirish — hammasi AIS valyutada.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> 15 ta ixtisoslik (Kardiolog, Terapevt, Pediatr...)</li>
                    <li><i class="fa fa-check"></i> Chat maslahat — Escrow himoyasi bilan</li>
                    <li><i class="fa fa-check"></i> Retsept yozish va PDF yuklab olish</li>
                    <li><i class="fa fa-check"></i> Dori buyurtma va uyga yetkazish</li>
                    <li><i class="fa fa-check"></i> Uyga chaqirish xizmati</li>
                    <li><i class="fa fa-check"></i> Shifokor reytingi va sharhlar</li>
                </ul>
                <a href="{{ route('register') }}" class="btn-f" style="display:inline-flex;align-items:center;gap:8px;padding:12px 28px">Shifokor topish <i class="fa fa-arrow-right" style="font-size:12px"></i></a>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(6,182,212,.08)">
                    <div style="text-align:center">
                        <div style="width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,rgba(6,182,212,.2),rgba(99,102,241,.2));margin:0 auto 12px;display:flex;align-items:center;justify-content:center;font-size:28px;color:#22d3ee"><i class="fa-solid fa-user-doctor"></i></div>
                        <div style="font-size:16px;font-weight:700;color:#f1f5f9">Dr. Karimova</div>
                        <div style="font-size:12px;color:#22d3ee;margin-bottom:4px">Kardiolog • 10 yil</div>
                        <div style="font-size:12px;color:#fbbf24;margin-bottom:16px">⭐ 4.8 (124 sharh)</div>
                        <div style="display:flex;flex-direction:column;gap:8px;text-align:left;margin-bottom:16px">
                            <div style="display:flex;justify-content:space-between;font-size:12px;padding:8px 12px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Chat maslahat</span><span style="color:#22d3ee;font-weight:700">15 AIS</span></div>
                            <div style="display:flex;justify-content:space-between;font-size:12px;padding:8px 12px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Uyga chaqirish</span><span style="color:#22d3ee;font-weight:700">40 AIS</span></div>
                        </div>
                        <div style="padding:12px;border-radius:12px;background:linear-gradient(135deg,#0891b2,#06b6d4);color:#fff;font-size:13px;font-weight:700"><i class="fa-solid fa-comments"></i> Maslahat olish</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 4: BIRJA (EXCHANGE) -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="exchange">
    <div class="wrap">
        <div class="mod-inner rev">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(16,185,129,.08);color:#34d399"><i class="fa fa-chart-line"></i> BIRJA</div>
                <h2>AIS/UZS birja savdosi</h2>
                <p>Real vaqtda AIS/UZS juftligida savdo qiling. Limit va market orderlar, OHLCV grafik, order book — professional savdo vositalari.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Limit va Market orderlar</li>
                    <li><i class="fa fa-check"></i> Real-time OHLCV grafik (candlestick)</li>
                    <li><i class="fa fa-check"></i> Order book va savdo tarixi</li>
                    <li><i class="fa fa-check"></i> Stop-loss va take-profit</li>
                    <li><i class="fa fa-check"></i> Past komissiya (VIP uchun 0%)</li>
                </ul>
                <a href="{{ route('register') }}" class="btn-f" style="display:inline-flex;align-items:center;gap:8px;padding:12px 28px">Savdo boshlash <i class="fa fa-arrow-right" style="font-size:12px"></i></a>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(16,185,129,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#34d399"><i class="fa-solid fa-chart-column"></i></div>
                        <div style="font-size:14px;color:#64748b;margin-bottom:4px">AIS / UZS</div>
                        <div style="font-size:28px;font-weight:900;color:#34d399;margin-bottom:4px">1,050 ↑</div>
                        <div style="font-size:12px;color:#34d399;margin-bottom:20px">+2.4% bugun</div>
                        <div style="height:80px;background:linear-gradient(180deg,rgba(16,185,129,.1),transparent);border-radius:12px;display:flex;align-items:flex-end;padding:0 8px 8px;gap:4px">
                            <div style="flex:1;background:#34d399;border-radius:3px;height:40%"></div>
                            <div style="flex:1;background:#34d399;border-radius:3px;height:60%"></div>
                            <div style="flex:1;background:#ef4444;border-radius:3px;height:30%"></div>
                            <div style="flex:1;background:#34d399;border-radius:3px;height:75%"></div>
                            <div style="flex:1;background:#34d399;border-radius:3px;height:55%"></div>
                            <div style="flex:1;background:#ef4444;border-radius:3px;height:45%"></div>
                            <div style="flex:1;background:#34d399;border-radius:3px;height:85%"></div>
                            <div style="flex:1;background:#34d399;border-radius:3px;height:90%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 5: KREDIT VA JAMG'ARMA -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="finance">
    <div class="wrap">
        <div class="mod-inner">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(236,72,153,.08);color:#f472b6"><i class="fa fa-building-columns"></i> MOLIYA</div>
                <h2>Mikro-kredit, jamg'arma va P2P qarz</h2>
                <p>Kredit reyting asosida mikro-kredit oling. Jamg'arma rejasi tuzing va foiz ishlang. P2P lending orqali boshqalarga qarz bering yoki oling.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Mikro-kredit — kredit reyting asosida</li>
                    <li><i class="fa fa-check"></i> Jamg'arma rejalar (kunlik/oylik foiz)</li>
                    <li><i class="fa fa-check"></i> Jamoaviy jamg'arma (guruh bilan)</li>
                    <li><i class="fa fa-check"></i> P2P lending — qarz berish/olish</li>
                    <li><i class="fa fa-check"></i> Avtomatik to'lov eslatmalari</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(236,72,153,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#f472b6"><i class="fa-solid fa-building-columns"></i></div>
                        <div style="font-size:14px;color:#64748b;margin-bottom:16px">Moliyaviy xizmatlar</div>
                        <div style="display:flex;flex-direction:column;gap:10px">
                            <div style="padding:14px;border-radius:12px;background:rgba(236,72,153,.06);border:1px solid rgba(236,72,153,.1);display:flex;align-items:center;gap:10px"><span style="font-size:20px;color:#f472b6"><i class="fa-solid fa-credit-card"></i></span><div style="text-align:left"><div style="font-size:12px;font-weight:700;color:#f1f5f9">Mikro-kredit</div><div style="font-size:11px;color:#64748b">5-100 AIS, 7-30 kun</div></div></div>
                            <div style="padding:14px;border-radius:12px;background:rgba(16,185,129,.06);border:1px solid rgba(16,185,129,.1);display:flex;align-items:center;gap:10px"><span style="font-size:20px;color:#34d399"><i class="fa-solid fa-piggy-bank"></i></span><div style="text-align:left"><div style="font-size:12px;font-weight:700;color:#f1f5f9">Jamg'arma</div><div style="font-size:11px;color:#64748b">Oylik 3-8% foyda</div></div></div>
                            <div style="padding:14px;border-radius:12px;background:rgba(245,158,11,.06);border:1px solid rgba(245,158,11,.1);display:flex;align-items:center;gap:10px"><span style="font-size:20px;color:#fbbf24"><i class="fa-solid fa-handshake"></i></span><div style="text-align:left"><div style="font-size:12px;font-weight:700;color:#f1f5f9">P2P Lending</div><div style="font-size:11px;color:#64748b">Qarz berish/olish</div></div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 6: GAMIFIKATSIYA -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="gamification">
    <div class="wrap">
        <div class="mod-inner rev">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(245,158,11,.08);color:#fbbf24"><i class="fa fa-gamepad"></i> GAMIFIKATSIYA</div>
                <h2>O'yin o'ynab pul ishlang — XP, Level, Bonuslar</h2>
                <p>Har kuni check-in qiling, topshiriqlar bajaring, kvestlarni tugatib AIS, UZS va XP yig'ing. Level oshgan sari yangi imkoniyatlar ochiladi.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Kunlik check-in (streak bonusi — 40 XP gacha)</li>
                    <li><i class="fa fa-check"></i> 99 ta Level — har biri yangi imkoniyat</li>
                    <li><i class="fa fa-check"></i> Lucky Draw — omad o'yini</li>
                    <li><i class="fa fa-check"></i> Spin Wheel — har kuni aylantiring</li>
                    <li><i class="fa fa-check"></i> 15+ kvest — AIS + UZS + XP mukofot</li>
                    <li><i class="fa fa-check"></i> Badge va leaderboard musobaqalari</li>
                    <li><i class="fa fa-check"></i> Mavsumiy tadbirlar va invite challenge</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(245,158,11,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:8px;color:#fbbf24"><i class="fa-solid fa-trophy"></i></div>
                        <div style="font-size:14px;color:#64748b;margin-bottom:4px">Sizning darajangiz</div>
                        <div style="font-size:22px;font-weight:900;color:#fbbf24;margin-bottom:4px">Level 12 — Experienced <i class="fa-solid fa-fire" style="color:#f59e0b"></i></div>
                        <div style="font-size:12px;color:#64748b;margin-bottom:16px">2,450 / 3,000 XP</div>
                        <div style="height:8px;background:rgba(255,255,255,.06);border-radius:4px;overflow:hidden;margin-bottom:20px"><div style="height:100%;width:82%;background:linear-gradient(90deg,#6366f1,#fbbf24);border-radius:4px"></div></div>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;text-align:center">
                            <div style="padding:12px;border-radius:10px;background:rgba(255,255,255,.03)"><div style="font-size:18px;margin-bottom:4px;color:#818cf8"><i class="fa-solid fa-bullseye"></i></div><div style="font-size:11px;color:#64748b">3 kvest</div></div>
                            <div style="padding:12px;border-radius:10px;background:rgba(255,255,255,.03)"><div style="font-size:18px;margin-bottom:4px;color:#f472b6"><i class="fa-solid fa-dice"></i></div><div style="font-size:11px;color:#64748b">Lucky Draw</div></div>
                            <div style="padding:12px;border-radius:10px;background:rgba(255,255,255,.03)"><div style="font-size:18px;margin-bottom:4px;color:#22d3ee"><i class="fa-solid fa-dharmachakra"></i></div><div style="font-size:11px;color:#64748b">Spin Wheel</div></div>
                            <div style="padding:12px;border-radius:10px;background:rgba(255,255,255,.03)"><div style="font-size:18px;margin-bottom:4px;color:#fbbf24"><i class="fa-solid fa-medal"></i></div><div style="font-size:11px;color:#64748b">5 badge</div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 7: TA'LIM -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="education">
    <div class="wrap">
        <div class="mod-inner">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(132,204,22,.08);color:#a3e635"><i class="fa fa-graduation-cap"></i> TA'LIM</div>
                <h2>Onlayn kurslar va mentorlik</h2>
                <p>Professional kurslarni sotib oling, darslarni o'rganing va sertifikat oling. Mentorlar bilan shaxsiy sessiyalar o'tkazing.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Video va matnli darslar</li>
                    <li><i class="fa fa-check"></i> Progress tracking va sertifikat</li>
                    <li><i class="fa fa-check"></i> Mentor sessiyalari (1-on-1)</li>
                    <li><i class="fa fa-check"></i> AIS bilan to'lov</li>
                    <li><i class="fa fa-check"></i> Kurs yaratish va sotish imkoniyati</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(132,204,22,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#a3e635"><i class="fa-solid fa-graduation-cap"></i></div>
                        <div style="font-size:16px;font-weight:700;color:#f1f5f9;margin-bottom:16px">Mashhur kurslar</div>
                        <div style="display:flex;flex-direction:column;gap:10px;text-align:left">
                            <div style="padding:12px;border-radius:10px;background:rgba(255,255,255,.03);display:flex;align-items:center;gap:10px"><span style="font-size:18px;color:#fbbf24"><i class="fa-solid fa-sack-dollar"></i></span><div><div style="font-size:12px;font-weight:600;color:#f1f5f9">Moliyaviy savodxonlik</div><div style="font-size:11px;color:#64748b">12 dars • 25 AIS</div></div></div>
                            <div style="padding:12px;border-radius:10px;background:rgba(255,255,255,.03);display:flex;align-items:center;gap:10px"><span style="font-size:18px;color:#34d399"><i class="fa-solid fa-chart-line"></i></span><div><div style="font-size:12px;font-weight:600;color:#f1f5f9">Investitsiya asoslari</div><div style="font-size:11px;color:#64748b">8 dars • 15 AIS</div></div></div>
                            <div style="padding:12px;border-radius:10px;background:rgba(255,255,255,.03);display:flex;align-items:center;gap:10px"><span style="font-size:18px;color:#c084fc"><i class="fa-solid fa-store"></i></span><div><div style="font-size:12px;font-weight:600;color:#f1f5f9">Biznes boshlash</div><div style="font-size:11px;color:#64748b">15 dars • 40 AIS</div></div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 8: MARKETPLACE & GIG ECONOMY -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="marketplace">
    <div class="wrap">
        <div class="mod-inner rev">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(168,85,247,.08);color:#c084fc"><i class="fa fa-store"></i> MARKETPLACE</div>
                <h2>Katalog, freelance va agro bozor</h2>
                <p>Do'kon oching va mahsulot soting. Freelance ish toping yoki buyurtma bering. Qishloq xo'jaligi mahsulotlarini sotib oling.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> E-commerce katalog — do'kon ochish</li>
                    <li><i class="fa fa-check"></i> Freelance gig marketplace</li>
                    <li><i class="fa fa-check"></i> AgroMarket — qishloq xo'jaligi</li>
                    <li><i class="fa fa-check"></i> Crowdfunding — loyihalarni qo'llab-quvvatlash</li>
                    <li><i class="fa fa-check"></i> Influencer ad network</li>
                    <li><i class="fa fa-check"></i> Barcha to'lovlar AIS valyutada</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(168,85,247,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#c084fc"><i class="fa-solid fa-store"></i></div>
                        <div style="font-size:14px;color:#64748b;margin-bottom:16px">Platformadagi bozorlar</div>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
                            <div style="padding:16px 10px;border-radius:12px;background:rgba(168,85,247,.06);border:1px solid rgba(168,85,247,.1);text-align:center"><div style="font-size:22px;margin-bottom:6px;color:#c084fc"><i class="fa-solid fa-shop"></i></div><div style="font-size:11px;color:#c084fc;font-weight:600">Katalog</div></div>
                            <div style="padding:16px 10px;border-radius:12px;background:rgba(6,182,212,.06);border:1px solid rgba(6,182,212,.1);text-align:center"><div style="font-size:22px;margin-bottom:6px;color:#22d3ee"><i class="fa-solid fa-briefcase"></i></div><div style="font-size:11px;color:#22d3ee;font-weight:600">Freelance</div></div>
                            <div style="padding:16px 10px;border-radius:12px;background:rgba(16,185,129,.06);border:1px solid rgba(16,185,129,.1);text-align:center"><div style="font-size:22px;margin-bottom:6px;color:#34d399"><i class="fa-solid fa-wheat-awn"></i></div><div style="font-size:11px;color:#34d399;font-weight:600">AgroMarket</div></div>
                            <div style="padding:16px 10px;border-radius:12px;background:rgba(245,158,11,.06);border:1px solid rgba(245,158,11,.1);text-align:center"><div style="font-size:22px;margin-bottom:6px;color:#fbbf24"><i class="fa-solid fa-bullhorn"></i></div><div style="font-size:11px;color:#fbbf24;font-weight:600">Influencer</div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 9: XAVFSIZLIK -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="security">
    <div class="wrap">
        <div class="sec-h">
            <div class="tag" style="background:rgba(16,185,129,.08);color:#34d399"><i class="fa fa-shield-halved"></i> XAVFSIZLIK</div>
            <h2>Bank darajasidagi himoya</h2>
            <p>Sizning pulingiz va ma'lumotlaringiz xavfsiz</p>
        </div>
        <div class="g4">
            <div class="gc">
                <div class="ic" style="background:rgba(16,185,129,.08);color:#34d399"><i class="fa-solid fa-fingerprint"></i></div>
                <h3>2-bosqichli KYC</h3>
                <p>Pasport + Face ID tasdiqlash. Faqat haqiqiy shaxslar.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(99,102,241,.08);color:#818cf8"><i class="fa-solid fa-shield-halved"></i></div>
                <h3>2FA himoya</h3>
                <p>Ikki faktorli autentifikatsiya — hisobingiz xavfsiz.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(236,72,153,.08);color:#f472b6"><i class="fa-solid fa-robot"></i></div>
                <h3>Anti-fraud AI</h3>
                <p>Sun'iy intellekt bilan real-time fraud monitoring.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(245,158,11,.08);color:#fbbf24"><i class="fa-solid fa-clipboard-list"></i></div>
                <h3>Audit log</h3>
                <p>Barcha operatsiyalar qayd etiladi va kuzatiladi.</p>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 10: REFERRAL TIZIMI -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="referral">
    <div class="wrap">
        <div class="mod-inner">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(99,102,241,.08);color:#a5b4fc"><i class="fa fa-users"></i> REFERRAL</div>
                <h2>3 darajali referral — passiv daromad</h2>
                <p>Do'stlaringizni taklif qiling — ular va ularning referallari ham sizga foyda keltiradi. QR kod, havola yoki Telegram orqali taklif qiling.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> 1-daraja: 10% komissiya</li>
                    <li><i class="fa fa-check"></i> 2-daraja: 5% komissiya</li>
                    <li><i class="fa fa-check"></i> 3-daraja: 2% komissiya</li>
                    <li><i class="fa fa-check"></i> Referral daraxti vizualizatsiyasi</li>
                    <li><i class="fa fa-check"></i> Invite Challenge — qo'shimcha bonus</li>
                    <li><i class="fa fa-check"></i> QR kod va share-to-earn</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(99,102,241,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#818cf8"><i class="fa-solid fa-users"></i></div>
                        <div style="font-size:14px;color:#64748b;margin-bottom:16px">Referral daromad</div>
                        <div style="display:flex;flex-direction:column;gap:12px">
                            <div style="padding:14px;border-radius:12px;background:rgba(99,102,241,.08);border:1px solid rgba(99,102,241,.15)"><div style="font-size:20px;font-weight:900;color:#818cf8">10%</div><div style="font-size:11px;color:#64748b">1-daraja (to'g'ridan-to'g'ri)</div></div>
                            <div style="padding:14px;border-radius:12px;background:rgba(139,92,246,.08);border:1px solid rgba(139,92,246,.15)"><div style="font-size:20px;font-weight:900;color:#a78bfa">5%</div><div style="font-size:11px;color:#64748b">2-daraja</div></div>
                            <div style="padding:14px;border-radius:12px;background:rgba(236,72,153,.08);border:1px solid rgba(236,72,153,.15)"><div style="font-size:20px;font-weight:900;color:#f472b6">2%</div><div style="font-size:11px;color:#64748b">3-daraja</div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 11: VIP & TELEGRAM -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod">
    <div class="wrap">
        <div class="sec-h">
            <div class="tag" style="background:rgba(245,158,11,.08);color:#fbbf24"><i class="fa fa-crown"></i> QOSHIMCHA</div>
            <h2>VIP a'zolik va Telegram bot</h2>
            <p>Premium imkoniyatlar va Telegram orqali boshqaruv</p>
        </div>
        <div class="g3">
            <div class="gc">
                <div class="ic" style="background:rgba(245,158,11,.08);color:#fbbf24"><i class="fa-solid fa-crown"></i></div>
                <h3>VIP A'zolik</h3>
                <p>Yuqori komissiya, maxsus paketlar, priority support va eksklyuziv tadbirlarga kirish.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(99,102,241,.08);color:#818cf8"><i class="fa-solid fa-robot"></i></div>
                <h3>AI Yordamchi</h3>
                <p>Sun'iy intellekt bilan suhbat — savollaringizga tezkor javob va moliyaviy maslahat.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(6,182,212,.08);color:#22d3ee"><i class="fa-solid fa-mobile-screen-button"></i></div>
                <h3>Telegram Bot</h3>
                <p>Balans, check-in, spin, promo-kod — hammasi Telegram ichida. /start bilan boshlang.</p>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 12: DEPOZIT VA YECHIB OLISH -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="payments">
    <div class="wrap">
        <div class="mod-inner">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(52,211,153,.08);color:#34d399"><i class="fa fa-credit-card"></i> TO'LOVLAR</div>
                <h2>Depozit va yechib olish — tez va oson</h2>
                <p>UZS balansni to'ldiring va AIS ga aylantiring. Daromadingizni istalgan vaqtda UZS ga yechib oling. Bir nechta to'lov usullari mavjud.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Karta orqali depozit (Uzcard, Humo)</li>
                    <li><i class="fa fa-check"></i> Admin tasdiqlash bilan xavfsiz depozit</li>
                    <li><i class="fa fa-check"></i> Tezkor yechib olish (24 soat ichida)</li>
                    <li><i class="fa fa-check"></i> Minimal komissiya</li>
                    <li><i class="fa fa-check"></i> To'lov tarixi va cheklar</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(52,211,153,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#34d399"><i class="fa-solid fa-credit-card"></i></div>
                        <div style="font-size:14px;color:#64748b;margin-bottom:16px">To'lov operatsiyalari</div>
                        <div style="display:flex;flex-direction:column;gap:10px">
                            <div style="padding:14px;border-radius:12px;background:rgba(52,211,153,.06);border:1px solid rgba(52,211,153,.12);display:flex;align-items:center;gap:12px"><span style="font-size:22px;color:#34d399"><i class="fa-solid fa-circle-arrow-down"></i></span><div style="text-align:left;flex:1"><div style="font-size:12px;font-weight:700;color:#f1f5f9">Depozit</div><div style="font-size:11px;color:#64748b">UZS → Balans</div></div><div style="font-size:12px;color:#34d399;font-weight:700">+500,000</div></div>
                            <div style="padding:14px;border-radius:12px;background:rgba(99,102,241,.06);border:1px solid rgba(99,102,241,.12);display:flex;align-items:center;gap:12px"><span style="font-size:22px;color:#818cf8"><i class="fa-solid fa-arrows-rotate"></i></span><div style="text-align:left;flex:1"><div style="font-size:12px;font-weight:700;color:#f1f5f9">Konvertatsiya</div><div style="font-size:11px;color:#64748b">UZS → AIS</div></div><div style="font-size:12px;color:#818cf8;font-weight:700">500 AIS</div></div>
                            <div style="padding:14px;border-radius:12px;background:rgba(245,158,11,.06);border:1px solid rgba(245,158,11,.12);display:flex;align-items:center;gap:12px"><span style="font-size:22px;color:#fbbf24"><i class="fa-solid fa-circle-arrow-up"></i></span><div style="text-align:left;flex:1"><div style="font-size:12px;font-weight:700;color:#f1f5f9">Yechib olish</div><div style="font-size:11px;color:#64748b">AIS → UZS → Karta</div></div><div style="font-size:12px;color:#fbbf24;font-weight:700">-200 AIS</div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 13: LEVEL / XP TIZIMI -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="levels">
    <div class="wrap">
        <div class="mod-inner rev">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(139,92,246,.08);color:#c084fc"><i class="fa fa-trophy"></i> LEVEL TIZIMI</div>
                <h2>99 ta Level — har biri yangi imkoniyat</h2>
                <p>Platformada faollik ko'rsating, XP yig'ing va levelingizni oshiring. Har yangi level yangi imkoniyatlar ochadi — P2P, virtual karta, VIP va boshqalar.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Lv.5 — P2P transfer ochiladi</li>
                    <li><i class="fa fa-check"></i> Lv.10 — Virtual karta ochiladi</li>
                    <li><i class="fa fa-check"></i> Lv.20 — Expert daraja, maxsus paketlar</li>
                    <li><i class="fa fa-check"></i> Lv.50 — Grandmaster, VIP imtiyozlar</li>
                    <li><i class="fa fa-check"></i> Lv.99 — AISOQQA Elite <i class="fa-solid fa-rocket" style="color:#818cf8"></i></li>
                    <li><i class="fa fa-check"></i> XP manbalari: check-in, depozit, referal, KYC...</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(139,92,246,.08)">
                    <div style="text-align:center">
                        <div style="font-size:14px;color:#64748b;margin-bottom:12px">Level tizimi</div>
                        <div style="display:flex;flex-direction:column;gap:8px;text-align:left">
                            <div style="padding:10px 14px;border-radius:10px;background:rgba(100,116,139,.06);display:flex;align-items:center;justify-content:space-between"><span style="font-size:12px;color:#94a3b8"><i class="fa-solid fa-seedling"></i> Newcomer</span><span style="font-size:11px;color:#64748b">Lv.0–4</span></div>
                            <div style="padding:10px 14px;border-radius:10px;background:rgba(99,102,241,.06);display:flex;align-items:center;justify-content:space-between"><span style="font-size:12px;color:#818cf8"><i class="fa-solid fa-bolt"></i> Active</span><span style="font-size:11px;color:#64748b">Lv.5–9</span></div>
                            <div style="padding:10px 14px;border-radius:10px;background:rgba(245,158,11,.06);display:flex;align-items:center;justify-content:space-between"><span style="font-size:12px;color:#fbbf24"><i class="fa-solid fa-fire"></i> Experienced</span><span style="font-size:11px;color:#64748b">Lv.10–19</span></div>
                            <div style="padding:10px 14px;border-radius:10px;background:rgba(6,182,212,.06);display:flex;align-items:center;justify-content:space-between"><span style="font-size:12px;color:#22d3ee"><i class="fa-solid fa-gem"></i> Expert</span><span style="font-size:11px;color:#64748b">Lv.20–34</span></div>
                            <div style="padding:10px 14px;border-radius:10px;background:rgba(236,72,153,.06);display:flex;align-items:center;justify-content:space-between"><span style="font-size:12px;color:#f472b6"><i class="fa-solid fa-trophy"></i> Master</span><span style="font-size:11px;color:#64748b">Lv.35–49</span></div>
                            <div style="padding:10px 14px;border-radius:10px;background:rgba(168,85,247,.06);display:flex;align-items:center;justify-content:space-between"><span style="font-size:12px;color:#c084fc"><i class="fa-solid fa-crown"></i> Grandmaster</span><span style="font-size:11px;color:#64748b">Lv.50–74</span></div>
                            <div style="padding:10px 14px;border-radius:10px;background:rgba(245,158,11,.08);display:flex;align-items:center;justify-content:space-between"><span style="font-size:12px;color:#fbbf24"><i class="fa-solid fa-rocket"></i> Elite</span><span style="font-size:11px;color:#64748b">Lv.99</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 14: CROWDFUNDING -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="crowdfunding">
    <div class="wrap">
        <div class="mod-inner">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(16,185,129,.08);color:#34d399"><i class="fa fa-hand-holding-heart"></i> CROWDFUNDING</div>
                <h2>Loyihalarni qo'llab-quvvatlang</h2>
                <p>Ijtimoiy va biznes loyihalarni AIS bilan moliyalashtiring. Loyiha yarating yoki mavjudlarini qo'llab-quvvatlang. Shaffof xarajat hisoboti.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Loyiha yaratish va maqsad belgilash</li>
                    <li><i class="fa fa-check"></i> AIS bilan donatsiya qilish</li>
                    <li><i class="fa fa-check"></i> Shaffof xarajat hisoboti</li>
                    <li><i class="fa fa-check"></i> Admin tasdiqlash va nazorat</li>
                    <li><i class="fa fa-check"></i> Muvaffaqiyatli loyihalar vitrinasi</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(16,185,129,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#34d399"><i class="fa-solid fa-handshake"></i></div>
                        <div style="font-size:15px;font-weight:700;color:#f1f5f9;margin-bottom:4px">Maktab kutubxonasi</div>
                        <div style="font-size:12px;color:#64748b;margin-bottom:16px">Qishloq maktabiga kitoblar</div>
                        <div style="height:8px;background:rgba(255,255,255,.06);border-radius:4px;overflow:hidden;margin-bottom:8px"><div style="height:100%;width:72%;background:linear-gradient(90deg,#10b981,#34d399);border-radius:4px"></div></div>
                        <div style="display:flex;justify-content:space-between;font-size:12px;color:#64748b;margin-bottom:16px"><span>720 / 1000 AIS</span><span style="color:#34d399;font-weight:700">72%</span></div>
                        <div style="padding:10px;border-radius:10px;background:rgba(16,185,129,.1);color:#34d399;font-size:13px;font-weight:600"><i class="fa-solid fa-heart"></i> Qo'llab-quvvatlash</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 15: UBI (KUNLIK BEPUL AIS) -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="ubi">
    <div class="wrap">
        <div class="mod-inner rev">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(245,158,11,.08);color:#fbbf24"><i class="fa fa-gift"></i> UBI</div>
                <h2>Kunlik bepul AIS — Universal Basic Income</h2>
                <p>Har kuni platformaga kiring va bepul AIS oling. Hech narsa to'lamasdan, hech narsa qilmasdan — shunchaki claim qiling.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Har kuni bepul AIS claim qilish</li>
                    <li><i class="fa fa-check"></i> KYC tasdiqlangan foydalanuvchilar uchun</li>
                    <li><i class="fa fa-check"></i> Level oshgan sari miqdor oshadi</li>
                    <li><i class="fa fa-check"></i> Hech qanday shart yo'q</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(245,158,11,.08)">
                    <div style="text-align:center">
                        <div style="font-size:48px;margin-bottom:12px;color:#fbbf24"><i class="fa-solid fa-gift"></i></div>
                        <div style="font-size:14px;color:#64748b;margin-bottom:8px">Bugungi UBI</div>
                        <div style="font-size:36px;font-weight:900;color:#fbbf24;margin-bottom:8px">+0.5 AIS</div>
                        <div style="font-size:12px;color:#64748b;margin-bottom:20px">Har kuni bepul!</div>
                        <div style="padding:14px;border-radius:12px;background:linear-gradient(135deg,rgba(245,158,11,.15),rgba(245,158,11,.05));border:1px solid rgba(245,158,11,.2);color:#fbbf24;font-size:14px;font-weight:700"><i class="fa-solid fa-gift"></i> Claim qilish</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 16: INFLUENCER AD NETWORK -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="influencer">
    <div class="wrap">
        <div class="mod-inner">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(236,72,153,.08);color:#f472b6"><i class="fa fa-bullhorn"></i> INFLUENCER</div>
                <h2>Influencer Ad Network — reklama bilan pul ishlang</h2>
                <p>YouTube, TikTok, Instagram kanalingizni ro'yxatdan o'tkazing. Kampaniyalarga qatnashing va har bir post uchun AIS oling.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Kanal ro'yxatdan o'tkazish (YouTube, TikTok, Instagram)</li>
                    <li><i class="fa fa-check"></i> Reklama kampaniyalariga qatnashish</li>
                    <li><i class="fa fa-check"></i> Har post/video uchun AIS mukofot</li>
                    <li><i class="fa fa-check"></i> Avtomatik to'lov (submission tasdiqlanganda)</li>
                    <li><i class="fa fa-check"></i> Kunlik hisobot va statistika</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(236,72,153,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#f472b6"><i class="fa-solid fa-bullhorn"></i></div>
                        <div style="font-size:14px;color:#64748b;margin-bottom:16px">Kampaniya namunasi</div>
                        <div style="padding:16px;border-radius:14px;background:rgba(236,72,153,.04);border:1px solid rgba(236,72,153,.1);text-align:left;margin-bottom:12px">
                            <div style="font-size:13px;font-weight:700;color:#f1f5f9;margin-bottom:4px">AISOQQA tanishtiruv</div>
                            <div style="font-size:11px;color:#64748b;margin-bottom:8px">TikTok video • 30 sek minimum</div>
                            <div style="display:flex;justify-content:space-between;font-size:12px"><span style="color:#64748b">Mukofot:</span><span style="color:#f472b6;font-weight:700">50 AIS</span></div>
                        </div>
                        <div style="padding:16px;border-radius:14px;background:rgba(99,102,241,.04);border:1px solid rgba(99,102,241,.1);text-align:left">
                            <div style="font-size:13px;font-weight:700;color:#f1f5f9;margin-bottom:4px">Telegram post</div>
                            <div style="font-size:11px;color:#64748b;margin-bottom:8px">Kanal post • 500+ obunachi</div>
                            <div style="display:flex;justify-content:space-between;font-size:12px"><span style="color:#64748b">Mukofot:</span><span style="color:#818cf8;font-weight:700">25 AIS</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 17: TOKENIZATSIYA -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="tokenization">
    <div class="wrap">
        <div class="mod-inner rev">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(168,85,247,.08);color:#c084fc"><i class="fa fa-cube"></i> TOKENIZATSIYA</div>
                <h2>Raqamli aktivlar — tokenizatsiya</h2>
                <p>Ko'chmas mulk, san'at asarlari va boshqa aktivlarni tokenlashtiring. Kichik ulushlar bilan katta aktivlarga investitsiya qiling.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Aktivlarni tokenlashtirish</li>
                    <li><i class="fa fa-check"></i> Kichik ulushlar bilan investitsiya</li>
                    <li><i class="fa fa-check"></i> Shaffof boshqaruv</li>
                    <li><i class="fa fa-check"></i> AIS bilan sotib olish</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(168,85,247,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#c084fc"><i class="fa-solid fa-building"></i></div>
                        <div style="font-size:14px;font-weight:700;color:#f1f5f9;margin-bottom:4px">Toshkent kvartira</div>
                        <div style="font-size:12px;color:#64748b;margin-bottom:16px">Tokenizatsiya qilingan mulk</div>
                        <div style="display:flex;justify-content:space-between;font-size:12px;padding:10px;border-radius:8px;background:rgba(255,255,255,.03);margin-bottom:8px"><span style="color:#64748b">Jami qiymat</span><span style="color:#c084fc;font-weight:700">500,000 AIS</span></div>
                        <div style="display:flex;justify-content:space-between;font-size:12px;padding:10px;border-radius:8px;background:rgba(255,255,255,.03);margin-bottom:8px"><span style="color:#64748b">Min. ulush</span><span style="color:#f1f5f9;font-weight:700">10 AIS</span></div>
                        <div style="display:flex;justify-content:space-between;font-size:12px;padding:10px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Yillik foyda</span><span style="color:#34d399;font-weight:700">~12%</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 18: ROADMAP & SUPPORT -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod">
    <div class="wrap">
        <div class="sec-h">
            <div class="tag" style="background:rgba(6,182,212,.08);color:#22d3ee"><i class="fa fa-map"></i> QOSHIMCHA XIZMATLAR</div>
            <h2>Roadmap, Support va boshqalar</h2>
            <p>Platforma rivojlanishi va foydalanuvchi qo'llab-quvvatlashi</p>
        </div>
        <div class="g4">
            <div class="gc">
                <div class="ic" style="background:rgba(6,182,212,.08);color:#22d3ee"><i class="fa-solid fa-map-location-dot"></i></div>
                <h3>Roadmap</h3>
                <p>Platforma rivojlanish rejasi. Ovoz bering va yangi funksiyalar qo'shilishini kuzating.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(236,72,153,.08);color:#f472b6"><i class="fa-solid fa-headset"></i></div>
                <h3>Support Tickets</h3>
                <p>Muammo bo'lsa — ticket oching. Admin 24 soat ichida javob beradi.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(16,185,129,.08);color:#34d399"><i class="fa-solid fa-charging-station"></i></div>
                <h3>EV Zaryadlash</h3>
                <p>Elektr transport zaryadlash stansiyalari tarmog'i. AIS bilan to'lang.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(139,92,246,.08);color:#c084fc"><i class="fa-solid fa-language"></i></div>
                <h3>Ko'p tilli</h3>
                <p>Platforma 3 tilda: O'zbek, Rus, Ingliz. Istalgan vaqtda almashtirishingiz mumkin.</p>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 19: PROMO-KODLAR & SPIN WHEEL & LUCKY DRAW -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="promo">
    <div class="wrap">
        <div class="mod-inner">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(236,72,153,.08);color:#f472b6"><i class="fa fa-ticket"></i> BONUSLAR</div>
                <h2>Promo-kod, Spin Wheel va Lucky Draw</h2>
                <p>Har kuni yangi bonus olish imkoniyati. Promo-kod kiriting, g'ildirakni aylantiring yoki omad o'yinida qatnashing — barchasi bepul!</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Promo-kod — maxsus kodlar bilan AIS/UZS bonus</li>
                    <li><i class="fa fa-check"></i> Spin Wheel — har kuni 1 marta bepul aylantirish</li>
                    <li><i class="fa fa-check"></i> Lucky Draw — chipta sotib oling, katta sovrin yutib oling</li>
                    <li><i class="fa fa-check"></i> Kunlik, haftalik va oylik aksiyalar</li>
                    <li><i class="fa fa-check"></i> VIP uchun qo'shimcha spinlar</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(236,72,153,.08)">
                    <div style="text-align:center">
                        <div style="font-size:48px;margin-bottom:8px;color:#f472b6"><i class="fa-solid fa-dharmachakra"></i></div>
                        <div style="font-size:16px;font-weight:700;color:#f1f5f9;margin-bottom:16px">Spin Wheel</div>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:16px">
                            <div style="padding:10px;border-radius:10px;background:rgba(245,158,11,.08);text-align:center"><div style="font-size:14px;font-weight:700;color:#fbbf24">5 AIS</div><div style="font-size:10px;color:#64748b">Sovrin</div></div>
                            <div style="padding:10px;border-radius:10px;background:rgba(16,185,129,.08);text-align:center"><div style="font-size:14px;font-weight:700;color:#34d399">10 XP</div><div style="font-size:10px;color:#64748b">Sovrin</div></div>
                            <div style="padding:10px;border-radius:10px;background:rgba(99,102,241,.08);text-align:center"><div style="font-size:14px;font-weight:700;color:#818cf8">50 UZS</div><div style="font-size:10px;color:#64748b">Sovrin</div></div>
                            <div style="padding:10px;border-radius:10px;background:rgba(236,72,153,.08);text-align:center"><div style="font-size:14px;font-weight:700;color:#f472b6"><i class="fa-solid fa-dice"></i> x2</div><div style="font-size:10px;color:#64748b">Bonus</div></div>
                        </div>
                        <div style="padding:12px;border-radius:12px;background:linear-gradient(135deg,rgba(236,72,153,.15),rgba(236,72,153,.05));border:1px solid rgba(236,72,153,.2);color:#f472b6;font-size:13px;font-weight:700"><i class="fa-solid fa-dharmachakra"></i> Aylantirish (Bepul)</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 20: BADGE & LEADERBOARD & MUSOBAQALAR -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="competitions">
    <div class="wrap">
        <div class="mod-inner rev">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(245,158,11,.08);color:#fbbf24"><i class="fa fa-medal"></i> MUSOBAQALAR</div>
                <h2>Badge, Leaderboard va musobaqalar</h2>
                <p>Haftalik va oylik musobaqalarda qatnashing. Eng faol foydalanuvchilar leaderboard da ko'rinadi va maxsus mukofotlar oladi. Badge yig'ing!</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Haftalik leaderboard — top 10 mukofotlanadi</li>
                    <li><i class="fa fa-check"></i> Oylik musobaqalar — katta sovrinlar</li>
                    <li><i class="fa fa-check"></i> Badge tizimi — yutuqlar uchun nishonlar</li>
                    <li><i class="fa fa-check"></i> Social Proof — real-time faoliyat oqimi</li>
                    <li><i class="fa fa-check"></i> Invite Challenge — eng ko'p referal jalb qilgan yutadi</li>
                    <li><i class="fa fa-check"></i> Mavsumiy tadbirlar — bayram bonuslari</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(245,158,11,.08)">
                    <div style="text-align:center">
                        <div style="font-size:14px;color:#64748b;margin-bottom:12px"><i class="fa-solid fa-trophy" style="color:#fbbf24"></i> Haftalik Leaderboard</div>
                        <div style="display:flex;flex-direction:column;gap:8px">
                            <div style="padding:12px;border-radius:10px;background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.15);display:flex;align-items:center;gap:10px"><span style="font-size:18px;color:#fbbf24"><i class="fa-solid fa-trophy"></i></span><div style="flex:1;text-align:left"><div style="font-size:12px;font-weight:700;color:#f1f5f9">Aziz_pro</div><div style="font-size:10px;color:#64748b">4,520 XP</div></div><span style="font-size:11px;color:#fbbf24;font-weight:700">100 AIS</span></div>
                            <div style="padding:12px;border-radius:10px;background:rgba(192,192,192,.06);border:1px solid rgba(192,192,192,.1);display:flex;align-items:center;gap:10px"><span style="font-size:18px;color:#94a3b8"><i class="fa-solid fa-trophy"></i></span><div style="flex:1;text-align:left"><div style="font-size:12px;font-weight:700;color:#f1f5f9">Sardor_inv</div><div style="font-size:10px;color:#64748b">3,890 XP</div></div><span style="font-size:11px;color:#94a3b8;font-weight:700">50 AIS</span></div>
                            <div style="padding:12px;border-radius:10px;background:rgba(205,127,50,.06);border:1px solid rgba(205,127,50,.1);display:flex;align-items:center;gap:10px"><span style="font-size:18px;color:#cd7f32"><i class="fa-solid fa-trophy"></i></span><div style="flex:1;text-align:left"><div style="font-size:12px;font-weight:700;color:#f1f5f9">Nilufar_22</div><div style="font-size:10px;color:#64748b">3,210 XP</div></div><span style="font-size:11px;color:#cd7f32;font-weight:700">25 AIS</span></div>
                        </div>
                        <div style="margin-top:12px;display:flex;gap:6px;justify-content:center;flex-wrap:wrap">
                            <span style="padding:4px 10px;border-radius:8px;background:rgba(99,102,241,.08);font-size:10px;color:#818cf8"><i class="fa-solid fa-award"></i> Early Bird</span>
                            <span style="padding:4px 10px;border-radius:8px;background:rgba(16,185,129,.08);font-size:10px;color:#34d399"><i class="fa-solid fa-star"></i> Top Investor</span>
                            <span style="padding:4px 10px;border-radius:8px;background:rgba(245,158,11,.08);font-size:10px;color:#fbbf24"><i class="fa-solid fa-fire"></i> Streak Master</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 21: MAVSUMIY TADBIRLAR & SHARE-TO-EARN -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="events">
    <div class="wrap">
        <div class="sec-h">
            <div class="tag" style="background:rgba(139,92,246,.08);color:#c084fc"><i class="fa fa-calendar-star"></i> TADBIRLAR</div>
            <h2>Mavsumiy tadbirlar va Share-to-Earn</h2>
            <p>Bayramlar, maxsus kunlar va doimiy aksiyalar</p>
        </div>
        <div class="g3">
            <div class="gc">
                <div class="ic" style="background:rgba(16,185,129,.08);color:#34d399"><i class="fa-solid fa-calendar-days"></i></div>
                <h3>Mavsumiy tadbirlar</h3>
                <p>Yangi yil, Navro'z, Ramazon — har bayramda maxsus bonuslar, kvestlar va sovrinlar. Vaqtinchalik aksiyalar.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(99,102,241,.08);color:#818cf8"><i class="fa-solid fa-share-nodes"></i></div>
                <h3>Share-to-Earn</h3>
                <p>Platformani ijtimoiy tarmoqlarda ulashing — har klik uchun AIS oling. Maxsus havola generatsiya qiling.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(245,158,11,.08);color:#fbbf24"><i class="fa-solid fa-chart-simple"></i></div>
                <h3>Social Proof</h3>
                <p>Real vaqtda boshqa foydalanuvchilar faoliyatini ko'ring — depozitlar, yutuqlar, levellar. Motivatsiya!</p>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 22: EV ZARYADLASH STANSIYALARI -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="ev-charging">
    <div class="wrap">
        <div class="mod-inner">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(52,211,153,.08);color:#34d399"><i class="fa fa-charging-station"></i> EV ZARYADLASH</div>
                <h2>Elektr transport zaryadlash stansiyalari</h2>
                <p>AISOQQA zaryadlash stansiyalari tarmog'i. Elektr mashinangizni AIS valyuta bilan zaryadlang. Xaritada eng yaqin stansiyani toping.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Stansiyalar xaritasi (GPS bilan)</li>
                    <li><i class="fa fa-check"></i> AIS bilan to'lov</li>
                    <li><i class="fa fa-check"></i> Real-time band/bo'sh holat</li>
                    <li><i class="fa fa-check"></i> Zaryadlash tarixi va statistika</li>
                    <li><i class="fa fa-check"></i> Sevimli stansiyalar</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(52,211,153,.08)">
                    <div style="text-align:center">
                        <div style="font-size:48px;margin-bottom:12px;color:#34d399"><i class="fa-solid fa-charging-station"></i></div>
                        <div style="font-size:15px;font-weight:700;color:#f1f5f9;margin-bottom:4px">Zaryadlash stansiyasi #12</div>
                        <div style="font-size:12px;color:#64748b;margin-bottom:16px">Toshkent, Amir Temur ko'chasi</div>
                        <div style="display:flex;flex-direction:column;gap:8px">
                            <div style="display:flex;justify-content:space-between;font-size:12px;padding:10px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Holat</span><span style="color:#34d399;font-weight:700"><i class="fa-solid fa-circle-check"></i> Bo'sh</span></div>
                            <div style="display:flex;justify-content:space-between;font-size:12px;padding:10px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Narx</span><span style="color:#f1f5f9;font-weight:700">2 AIS / soat</span></div>
                            <div style="display:flex;justify-content:space-between;font-size:12px;padding:10px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Quvvat</span><span style="color:#f1f5f9;font-weight:700">22 kW</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 23: AD NETWORK (REKLAMA TARMOQ) -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="ads">
    <div class="wrap">
        <div class="mod-inner rev">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(99,102,241,.08);color:#a5b4fc"><i class="fa fa-rectangle-ad"></i> REKLAMA</div>
                <h2>Ad Network — reklama tarmoq</h2>
                <p>Biznesingizni reklama qiling yoki reklama ko'rib AIS ishlang. Platforma ichidagi banner va video reklamalar tarmog'i.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Banner va video reklamalar</li>
                    <li><i class="fa fa-check"></i> Reklama kampaniyasi yaratish (biznes uchun)</li>
                    <li><i class="fa fa-check"></i> Reklama ko'rib AIS ishlash (foydalanuvchi uchun)</li>
                    <li><i class="fa fa-check"></i> Targetlash (yosh, hudud, qiziqish)</li>
                    <li><i class="fa fa-check"></i> Statistika va ROI hisoboti</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(99,102,241,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#818cf8"><i class="fa-solid fa-rectangle-ad"></i></div>
                        <div style="font-size:14px;color:#64748b;margin-bottom:16px">Reklama statistikasi</div>
                        <div style="display:flex;flex-direction:column;gap:8px">
                            <div style="display:flex;justify-content:space-between;font-size:12px;padding:10px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Ko'rishlar</span><span style="color:#818cf8;font-weight:700">12,450</span></div>
                            <div style="display:flex;justify-content:space-between;font-size:12px;padding:10px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Kliklar</span><span style="color:#34d399;font-weight:700">890</span></div>
                            <div style="display:flex;justify-content:space-between;font-size:12px;padding:10px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="color:#64748b">Ishlangan AIS</span><span style="color:#fbbf24;font-weight:700">+45 AIS</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 24: GROUP SAVINGS (JAMOAVIY JAMG'ARMA) -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="group-savings">
    <div class="wrap">
        <div class="mod-inner">
            <div class="mod-text">
                <div class="mod-tag" style="background:rgba(16,185,129,.08);color:#34d399"><i class="fa fa-people-group"></i> JAMOAVIY</div>
                <h2>Jamoaviy jamg'arma — guruh bilan tejang</h2>
                <p>Do'stlar yoki oila a'zolari bilan birgalikda jamg'aring. Har oy navbat bilan pul oling. Shaffof va xavfsiz tizim.</p>
                <ul class="mod-list">
                    <li><i class="fa fa-check"></i> Guruh yaratish (2-20 kishi)</li>
                    <li><i class="fa fa-check"></i> Har oy belgilangan summa to'lash</li>
                    <li><i class="fa fa-check"></i> Navbat bilan to'liq summa olish</li>
                    <li><i class="fa fa-check"></i> Admin tasdiqlash va nazorat</li>
                    <li><i class="fa fa-check"></i> Avtomatik eslatmalar</li>
                </ul>
            </div>
            <div class="mod-visual">
                <div class="mod-card" style="--accent:rgba(16,185,129,.08)">
                    <div style="text-align:center">
                        <div style="font-size:40px;margin-bottom:12px;color:#34d399"><i class="fa-solid fa-people-roof"></i></div>
                        <div style="font-size:15px;font-weight:700;color:#f1f5f9;margin-bottom:4px">Oila jamg'armasi</div>
                        <div style="font-size:12px;color:#64748b;margin-bottom:16px">5 a'zo • Oylik 100 AIS</div>
                        <div style="display:flex;flex-direction:column;gap:6px">
                            <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;background:rgba(16,185,129,.06)"><span style="font-size:14px;color:#34d399"><i class="fa-solid fa-circle-check"></i></span><span style="font-size:12px;color:#94a3b8;flex:1">Aziz (admin)</span><span style="font-size:11px;color:#34d399">To'ladi</span></div>
                            <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;background:rgba(16,185,129,.06)"><span style="font-size:14px;color:#34d399"><i class="fa-solid fa-circle-check"></i></span><span style="font-size:12px;color:#94a3b8;flex:1">Sardor</span><span style="font-size:11px;color:#34d399">To'ladi</span></div>
                            <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;background:rgba(245,158,11,.06)"><span style="font-size:14px;color:#fbbf24"><i class="fa-solid fa-hourglass-half"></i></span><span style="font-size:12px;color:#94a3b8;flex:1">Nilufar</span><span style="font-size:11px;color:#fbbf24">Kutilmoqda</span></div>
                            <div style="display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:8px;background:rgba(255,255,255,.03)"><span style="font-size:14px;color:#64748b"><i class="fa-solid fa-user"></i></span><span style="font-size:12px;color:#94a3b8;flex:1">Jasur</span><span style="font-size:11px;color:#64748b">Navbatda</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- MODULE 25: ONBOARDING & KYC -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="mod" id="onboarding">
    <div class="wrap">
        <div class="sec-h">
            <div class="tag" style="background:rgba(99,102,241,.08);color:#a5b4fc"><i class="fa fa-user-plus"></i> BOSHLASH</div>
            <h2>Oson ro'yxatdan o'tish va KYC</h2>
            <p>Yangi foydalanuvchilar uchun qadam-baqadam yo'riqnoma</p>
        </div>
        <div class="g3">
            <div class="gc">
                <div class="ic" style="background:rgba(99,102,241,.08);color:#818cf8"><i class="fa-brands fa-telegram"></i></div>
                <h3>Telegram Mini App</h3>
                <p>Telegram orqali 1 bosish bilan kirish. Hech narsa yuklamasdan, hech narsa o'rnatmasdan — shunchaki boshlang.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(16,185,129,.08);color:#34d399"><i class="fa-solid fa-id-card"></i></div>
                <h3>2-bosqichli KYC</h3>
                <p>1-bosqich: Pasport rasmi yuklash. 2-bosqich: Face ID tasdiqlash. 5 daqiqada tayyor.</p>
            </div>
            <div class="gc">
                <div class="ic" style="background:rgba(245,158,11,.08);color:#fbbf24"><i class="fa-solid fa-bullseye"></i></div>
                <h3>Onboarding kvestlar</h3>
                <p>Yangi foydalanuvchilar uchun maxsus kvestlar — platformani o'rganib, bonus oling.</p>
            </div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- QANDAY ISHLAYDI -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="sec" id="how">
    <div class="wrap">
        <div class="sec-h">
            <div class="tag" style="background:rgba(99,102,241,.08);color:#a5b4fc"><i class="fa fa-route"></i> BOSHLASH</div>
            <h2>4 qadamda boshlang</h2>
            <p>Ro'yxatdan o'tishdan daromad olishgacha</p>
        </div>
        <div class="steps">
            <div class="stp"><div class="stp-n">1</div><h3>Ro'yxatdan o'ting</h3><p>Telegram yoki email bilan — 1 daqiqa</p></div>
            <div class="stp"><div class="stp-n">2</div><h3>KYC tasdiqlang</h3><p>Pasport + Face ID — 5 daqiqa</p></div>
            <div class="stp"><div class="stp-n">3</div><h3>Balans to'ldiring</h3><p>UZS depozit → AIS konvertatsiya</p></div>
            <div class="stp"><div class="stp-n">4</div><h3>Daromad oling</h3><p>Paket, referal, topshiriq, birja...</p></div>
        </div>
    </div>
</section>

<!-- ══════════════════════════════════════════════════════════════════════════ -->
<!-- CTA -->
<!-- ══════════════════════════════════════════════════════════════════════════ -->
<section class="sec">
    <div class="wrap">
        <div class="cta-box">
            <h2>Kelajakni bugun boshlang <i class="fa-solid fa-rocket" style="color:#818cf8"></i></h2>
            <p>Minglab foydalanuvchilar allaqachon AISOQQA bilan pul ishlashmoqda</p>
            <div style="display:flex;gap:14px;justify-content:center;flex-wrap:wrap">
                <a href="{{ route('register') }}" class="hb hb-main" style="padding:16px 36px"><i class="fa fa-rocket"></i> Bepul ro'yxatdan o'tish</a>
                @if($setting->telegram)
                <a href="{{ $setting->telegram }}" target="_blank" class="hb hb-tg" style="padding:16px 36px"><i class="fa-brands fa-telegram"></i> Telegram Bot</a>
                @endif
            </div>
        </div>
    </div>
</section>

<!-- FOOTER -->
<footer class="ft">
    <div class="wrap">
        <div class="ft-grid">
            <div class="ft-brand">
                <a href="/" class="nav-logo"><img src="{{ $setting->logo_url ?? '' }}" alt=""><span>AISOQQA</span></a>
                <p>O'zbekistonning zamonaviy moliyaviy super-platformasi. 30+ xizmat bitta joyda.</p>
            </div>
            <div class="ft-col">
                <h4>Platforma</h4>
                <a href="#ais">AIS Valyuta</a>
                <a href="#invest">Investitsiya</a>
                <a href="#exchange">Birja</a>
                <a href="#gamification">Bonuslar</a>
            </div>
            <div class="ft-col">
                <h4>Xizmatlar</h4>
                <a href="#medical">Tibbiyot</a>
                <a href="#education">Ta'lim</a>
                <a href="#marketplace">Marketplace</a>
                <a href="#finance">Kredit</a>
            </div>
            <div class="ft-col">
                <h4>Yordam</h4>
                <a href="#">FAQ</a>
                <a href="#">Support</a>
                <a href="#">Maxfiylik</a>
                <a href="#">Shartlar</a>
            </div>
        </div>
        <div class="ft-bot">
            <p>&copy; {{ date('Y') }} AISOQQA. Barcha huquqlar himoyalangan.</p>
            <div class="soc">
                @if($setting->telegram)<a href="{{ $setting->telegram }}" target="_blank"><i class="fa-brands fa-telegram"></i></a>@endif
                @if($setting->instagram ?? false)<a href="{{ $setting->instagram }}" target="_blank"><i class="fa-brands fa-instagram"></i></a>@endif
            </div>
        </div>
    </div>
</footer>

<script>
window.addEventListener('scroll',()=>{document.querySelector('.nav').style.borderBottomColor=window.scrollY>50?'rgba(255,255,255,.04)':'transparent'});

// Emoji → Font Awesome SVG icon mapping
const emojiMap={
'🪙':'<i class="fa-solid fa-coins"></i>',
'📦':'<i class="fa-solid fa-box"></i>',
'👨‍⚕️':'<i class="fa-solid fa-user-doctor"></i>',
'📊':'<i class="fa-solid fa-chart-column"></i>',
'🏦':'<i class="fa-solid fa-building-columns"></i>',
'💳':'<i class="fa-solid fa-credit-card"></i>',
'🤝':'<i class="fa-solid fa-handshake"></i>',
'🏆':'<i class="fa-solid fa-trophy"></i>',
'🎯':'<i class="fa-solid fa-bullseye"></i>',
'🎰':'<i class="fa-solid fa-dice"></i>',
'🎡':'<i class="fa-solid fa-dharmachakra"></i>',
'🏅':'<i class="fa-solid fa-medal"></i>',
'🎓':'<i class="fa-solid fa-graduation-cap"></i>',
'💰':'<i class="fa-solid fa-sack-dollar"></i>',
'📈':'<i class="fa-solid fa-chart-line"></i>',
'🏪':'<i class="fa-solid fa-store"></i>',
'💼':'<i class="fa-solid fa-briefcase"></i>',
'🌾':'<i class="fa-solid fa-wheat-awn"></i>',
'📢':'<i class="fa-solid fa-bullhorn"></i>',
'👥':'<i class="fa-solid fa-users"></i>',
'🗺️':'<i class="fa-solid fa-map"></i>',
'🎫':'<i class="fa-solid fa-ticket"></i>',
'⚡':'<i class="fa-solid fa-bolt"></i>',
'🌐':'<i class="fa-solid fa-globe"></i>',
'👑':'<i class="fa-solid fa-crown"></i>',
'🤖':'<i class="fa-solid fa-robot"></i>',
'📱':'<i class="fa-solid fa-mobile-screen"></i>',
'⬇️':'<i class="fa-solid fa-arrow-down"></i>',
'🔄':'<i class="fa-solid fa-arrows-rotate"></i>',
'⬆️':'<i class="fa-solid fa-arrow-up"></i>',
'🎁':'<i class="fa-solid fa-gift"></i>',
'📺':'<i class="fa-solid fa-tv"></i>',
'🏠':'<i class="fa-solid fa-house"></i>',
'👨‍👩‍👧‍👦':'<i class="fa-solid fa-people-roof"></i>',
'📋':'<i class="fa-solid fa-clipboard"></i>',
'🪪':'<i class="fa-solid fa-id-card"></i>',
'🔗':'<i class="fa-solid fa-link"></i>',
'🎄':'<i class="fa-solid fa-tree"></i>',
'🥇':'<i class="fa-solid fa-trophy" style="color:#fbbf24"></i>',
'🥈':'<i class="fa-solid fa-trophy" style="color:#94a3b8"></i>',
'🥉':'<i class="fa-solid fa-trophy" style="color:#cd7f32"></i>',
'⭐':'<i class="fa-solid fa-star" style="color:#fbbf24"></i>',
'🔥':'<i class="fa-solid fa-fire" style="color:#f59e0b"></i>',
'✅':'<i class="fa-solid fa-circle-check" style="color:#34d399"></i>',
'⏳':'<i class="fa-solid fa-hourglass-half" style="color:#fbbf24"></i>',
'👤':'<i class="fa-solid fa-user"></i>',
'❤️':'<i class="fa-solid fa-heart" style="color:#ef4444"></i>',
'💬':'<i class="fa-solid fa-comments"></i>',
'💊':'<i class="fa-solid fa-pills"></i>',
'🏥':'<i class="fa-solid fa-hospital"></i>',
'🔒':'<i class="fa-solid fa-lock"></i>',
'🚀':'<i class="fa-solid fa-rocket"></i>',
'🌱':'<i class="fa-solid fa-seedling"></i>',
'💎':'<i class="fa-solid fa-gem"></i>',
'🔐':'<i class="fa-solid fa-lock"></i>',
'🛡️':'<i class="fa-solid fa-shield"></i>',
'🌱':'<i class="fa-solid fa-seedling"></i>',
'⚡':'<i class="fa-solid fa-bolt"></i>',
'🔥':'<i class="fa-solid fa-fire"></i>',
'💎':'<i class="fa-solid fa-gem"></i>',
'🏆':'<i class="fa-solid fa-trophy"></i>',
'👑':'<i class="fa-solid fa-crown"></i>',
'🚀':'<i class="fa-solid fa-rocket"></i>',
'⬇️':'<i class="fa-solid fa-circle-arrow-down"></i>',
'🔄':'<i class="fa-solid fa-arrows-rotate"></i>',
'⬆️':'<i class="fa-solid fa-circle-arrow-up"></i>',
'✅':'<i class="fa-solid fa-circle-check"></i>',
'⏳':'<i class="fa-solid fa-hourglass-half"></i>',
'👤':'<i class="fa-solid fa-user"></i>',
'❤️':'<i class="fa-solid fa-heart"></i>',
'⭐':'<i class="fa-solid fa-star"></i>',
'🏅':'<i class="fa-solid fa-award"></i>'
};
document.querySelectorAll('.mod-card, .gc, .cta-box').forEach(el=>{
    Object.keys(emojiMap).forEach(emoji=>{
        if(el.innerHTML.includes(emoji)){
            el.innerHTML=el.innerHTML.replaceAll(emoji,emojiMap[emoji]);
        }
    });
});
</script>
</body>
</html>
