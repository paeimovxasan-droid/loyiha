@extends('front.layouts.app')
@section('title', 'Marketplace')
@section('content')

<div class="page-title">🛍️ Marketplace</div>

<div style="display:flex; flex-direction:column; gap:14px;">
@forelse($gigs as $gig)
<div class="card">
    <div style="padding:20px;">
        <div style="display:flex; align-items:center; gap:14px;">
            <div style="width:48px; height:48px; border-radius:14px; background:rgba(139,92,246,.1);
                        display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                <i class="fa fa-briefcase" style="color:#a78bfa; font-size:18px;"></i>
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-size:15px; font-weight:700; color:#f1f5f9;">{{ $gig->title }}</div>
                <div style="font-size:12px; color:var(--gray); margin-top:2px;">
                    <i class="fa fa-user" style="font-size:10px;"></i> {{ $gig->user->name ?? 'Noma\'lum' }}
                    @if($gig->category)
                        · {{ $gig->category->name ?? '' }}
                    @endif
                </div>
            </div>
            <div style="text-align:right; flex-shrink:0;">
                <div style="font-size:16px; font-weight:800; color:#34d399;">
                    {{ number_format($gig->price) }}
                </div>
                <div style="font-size:10px; color:var(--gray);">UZS</div>
            </div>
        </div>

        @if($gig->description)
        <div style="font-size:13px; color:var(--gray); margin-top:12px; line-height:1.5;">
            {{ Str::limit($gig->description, 100) }}
        </div>
        @endif

        <div style="display:flex; gap:8px; margin-top:12px;">
            @if($gig->delivery_days)
            <span style="font-size:11px; padding:4px 10px; border-radius:8px;
                         background:rgba(99,102,241,.1); color:#818cf8;">
                <i class="fa fa-clock"></i> {{ $gig->delivery_days }} kun
            </span>
            @endif
            <span style="font-size:11px; padding:4px 10px; border-radius:8px;
                         background:rgba(245,158,11,.1); color:#fbbf24;">
                ⭐ {{ number_format($gig->avg_rating, 1) }}
            </span>
        </div>
    </div>
</div>
@empty
<div class="card" style="padding:50px; text-align:center; color:var(--gray);">
    <i class="fa fa-store" style="font-size:40px; opacity:.3; display:block; margin-bottom:14px;"></i>
    Hozircha xizmatlar yo'q
</div>
@endforelse
</div>

@if($gigs->hasPages())
<div style="margin-top:16px;">{{ $gigs->links() }}</div>
@endif

@endsection
