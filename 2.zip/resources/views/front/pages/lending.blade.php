@extends('front.layouts.app')
@section('title', 'P2P Lending')
@section('content')

<div class="page-title">🏦 P2P Lending</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<a href="{{ route('app.lending.create') }}"
   style="display:flex; align-items:center; justify-content:center; gap:8px; width:100%;
          padding:14px; margin-bottom:16px; background:linear-gradient(135deg, rgba(99,102,241,.15), rgba(99,102,241,.08));
          border:1px solid rgba(99,102,241,.3); border-radius:14px; color:#818cf8;
          text-decoration:none; font-size:14px; font-weight:600;">
    <i class="fa fa-plus"></i> Kredit taklifi yaratish
</a>

{{-- My loans --}}
@if($myLoans->count())
<p class="section-label">Mening qarzlarim</p>
<div style="display:flex; flex-direction:column; gap:10px; margin-bottom:20px;">
@foreach($myLoans as $loan)
<div class="card">
    <div style="padding:16px; display:flex; align-items:center; gap:14px;">
        <div style="width:40px; height:40px; border-radius:12px; flex-shrink:0;
                    background:rgba(239,68,68,.1); display:flex; align-items:center; justify-content:center;">
            <i class="fa fa-hand-holding-dollar" style="color:#f87171; font-size:14px;"></i>
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:600; color:#f1f5f9;">{{ number_format($loan->amount) }} AIS</div>
            <div style="font-size:11px; color:var(--gray);">
                {{ $loan->interest_rate }}% · Muddat: {{ $loan->due_date?->format('d.m.Y') ?? '—' }}
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:13px; font-weight:700; color:#f87171;">{{ number_format($loan->remaining) }}</div>
            <div style="font-size:10px; color:var(--gray);">Qoldiq</div>
        </div>
    </div>
</div>
@endforeach
</div>
@endif

{{-- My offers --}}
@if($myOffers->count())
<p class="section-label">Mening takliflarim</p>
<div style="display:flex; flex-direction:column; gap:10px; margin-bottom:20px;">
@foreach($myOffers as $offer)
<div class="card">
    <div style="padding:16px; display:flex; align-items:center; gap:14px;">
        <div style="width:40px; height:40px; border-radius:12px; flex-shrink:0;
                    background:rgba(16,185,129,.1); display:flex; align-items:center; justify-content:center;">
            <i class="fa fa-coins" style="color:#34d399; font-size:14px;"></i>
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:600; color:#f1f5f9;">{{ number_format($offer->amount) }} AIS</div>
            <div style="font-size:11px; color:var(--gray);">{{ $offer->interest_rate }}% · {{ $offer->duration_days }} kun</div>
        </div>
        <span style="font-size:10px; padding:3px 10px; border-radius:10px; font-weight:600;
                     background:{{ $offer->status === 'active' ? 'rgba(16,185,129,.15)' : 'rgba(100,116,139,.15)' }};
                     color:{{ $offer->status === 'active' ? '#34d399' : 'var(--gray)' }};">
            {{ $offer->status === 'active' ? 'Faol' : $offer->status }}
        </span>
    </div>
</div>
@endforeach
</div>
@endif

{{-- Available offers --}}
<p class="section-label">Mavjud takliflar</p>
<div style="display:flex; flex-direction:column; gap:14px;">
@forelse($offers as $offer)
<div class="card">
    <div style="padding:20px;">
        <div style="display:flex; align-items:center; gap:14px; margin-bottom:12px;">
            <div style="width:48px; height:48px; border-radius:14px; background:rgba(99,102,241,.1);
                        display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                <i class="fa fa-hand-holding-dollar" style="color:#818cf8; font-size:18px;"></i>
            </div>
            <div style="flex:1; min-width:0;">
                <div style="font-size:15px; font-weight:700; color:#f1f5f9;">{{ number_format($offer->amount) }} AIS</div>
                <div style="font-size:12px; color:var(--gray); margin-top:2px;">
                    <i class="fa fa-user" style="font-size:10px;"></i> {{ $offer->lender->name ?? 'Noma\'lum' }}
                </div>
            </div>
        </div>

        <div style="display:flex; gap:8px; margin-bottom:14px;">
            <div style="flex:1; background:rgba(16,185,129,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#34d399;">{{ $offer->interest_rate }}%</div>
                <div style="font-size:10px; color:var(--gray);">Foiz</div>
            </div>
            <div style="flex:1; background:rgba(99,102,241,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:16px; font-weight:700; color:#818cf8;">{{ $offer->duration_days }}</div>
                <div style="font-size:10px; color:var(--gray);">Kun</div>
            </div>
            <div style="flex:1; background:rgba(245,158,11,.08); border-radius:10px; padding:10px; text-align:center;">
                <div style="font-size:14px; font-weight:700; color:#fbbf24;">{{ number_format($offer->amount * (1 + $offer->interest_rate / 100)) }}</div>
                <div style="font-size:10px; color:var(--gray);">Qaytarish</div>
            </div>
        </div>

        @if($offer->lender_id !== auth()->id())
        <form method="POST" action="{{ route('app.lending.borrow', $offer->id) }}">
            @csrf
            <button type="submit" class="btn btn-primary" style="width:100%;"
                    onclick="return confirm('{{ number_format($offer->amount) }} AIS qarz olmoqchimisiz?')">
                <i class="fa fa-hand-holding-dollar"></i> Qarz olish
            </button>
        </form>
        @endif
    </div>
</div>
@empty
<div class="card" style="padding:50px; text-align:center; color:var(--gray);">
    <i class="fa fa-hand-holding-dollar" style="font-size:40px; opacity:.3; display:block; margin-bottom:14px;"></i>
    Hozircha takliflar yo'q
</div>
@endforelse
</div>

@if($offers->hasPages())
<div style="margin-top:16px;">{{ $offers->links() }}</div>
@endif

@endsection
