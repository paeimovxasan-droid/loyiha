@extends('front.layouts.app')
@section('title', __('front.packages.title'))
@section('content')

<div class="page-title">📦 {{ __('front.packages.title') }}</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif

@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<div style="display: flex; flex-direction: column; gap: 16px;">
    @forelse($packages as $package)
    <div class="package-card">
        @if($package->photo_url)
        <img src="{{ $package->photo_url }}" alt="{{ $package->getTranslation('name', app()->getLocale()) }}"
             style="width:100%; height:160px; object-fit:cover;">
        @else
        <div style="height: 80px; background: linear-gradient(135deg, #4f46e5, #7c3aed);"></div>
        @endif

        <div class="package-card-body">
            <div style="display:flex; align-items:flex-start; justify-content:space-between; margin-bottom:10px;">
                <div>
                    <div class="package-name">{{ $package->getTranslation('name', app()->getLocale()) }}</div>
                    <div class="package-price">{{ number_format($package->price, 2) }} <span style="font-size:14px; font-weight:500; color:var(--gray);">UZS</span></div>
                </div>
                @if(in_array($package->id, $myPurchases))
                <span class="badge badge-info"><i class="fa fa-check"></i> {{ __('front.packages.purchased') }}</span>
                @elseif($package->is_default)
                <span class="badge badge-warning"><i class="fa fa-star"></i> {{ __('front.packages.recommended') }}</span>
                @endif
            </div>

            <div class="package-meta">
                <div class="package-meta-row">
                    <span><i class="fa fa-calendar" style="width:14px;"></i> {{ __('front.packages.duration') }}</span>
                    <span>{{ $package->validity_days }} {{ __('front.packages.days') }}</span>
                </div>
                <div class="package-meta-row">
                    <span><i class="fa fa-chart-simple" style="width:14px;"></i> {{ __('front.packages.daily_profit') }}</span>
                    <span style="color:#34d399;">+{{ number_format($package->daily_profit_percent, 2) }}%</span>
                </div>
                <div class="package-meta-row">
                    <span><i class="fa fa-sack-dollar" style="width:14px;"></i> {{ __('front.packages.total_profit') }}</span>
                    <span style="color:#818cf8;">{{ number_format($package->total_profit_percent, 2) }}%</span>
                </div>
                <div class="package-meta-row">
                    <span><i class="fa fa-users" style="width:14px;"></i> {{ __('front.packages.referral_l1') }}</span>
                    <span>{{ number_format($package->ref_level1, 2) }}%</span>
                </div>
            </div>

            @if(!in_array($package->id, $myPurchases))
            <form method="POST" action="{{ route('app.packages.buy', $package) }}">
                @csrf
                <button type="submit" class="btn btn-primary btn-full"
                        onclick="event.preventDefault(); window.openConfirmModal('{{ number_format($package->price, 2) }} UZS {{ __('front.packages.confirm_buy') }}', this.closest('form'))">
                    <i class="fa fa-shopping-cart"></i>
                    {{ number_format($package->price, 2) }} UZS {{ __('front.packages.buy_for') }}
                </button>
            </form>
            @else
            <div class="btn btn-outline btn-full" style="cursor:default; justify-content:center;">
                <i class="fa fa-check"></i> {{ __('front.packages.already_purchased') }}
            </div>
            @endif
        </div>
    </div>
    @empty
    <div class="card" style="padding:50px; text-align:center;">
        <i class="fa fa-box-open" style="font-size:40px; color:var(--gray); opacity:.3; display:block; margin-bottom:14px;"></i>
        <div style="color:var(--gray);">{{ __('front.packages.no_packages') }}</div>
    </div>
    @endforelse
</div>
@endsection
