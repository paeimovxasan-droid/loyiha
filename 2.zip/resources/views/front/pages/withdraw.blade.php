@extends('front.layouts.app')
@section('title', __('front.withdraw.title'))
@section('content')

<div class="page-title">💸 {{ __('front.withdraw.title') }}</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif
@if($errors->any())
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ $errors->first() }}</div>
@endif

{{-- Withdrawal Scoring Card --}}
@php $scoreColor = $scoring['score'] >= 20 ? '#10b981' : ($scoring['score'] >= 10 ? '#f59e0b' : '#ef4444'); @endphp
<div style="margin-bottom: 16px; background: var(--bg-card); border: 1px solid var(--border-primary); border-radius: var(--radius-lg); padding: 16px;">
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 12px;">
        <div style="font-size: 13px; font-weight: 700; color: var(--text-primary);">📊 Yechish skoringi</div>
        <div style="font-size: 20px; font-weight: 800; color: {{ $scoreColor }};">
            {{ $scoring['score'] }}<span style="font-size: 12px; font-weight: 500; color: var(--text-muted);">/100</span>
        </div>
    </div>

    {{-- Progress bar --}}
    <div style="height: 6px; background: rgba(255,255,255,.06); border-radius: 6px; overflow: hidden; margin-bottom: 12px;">
        <div style="height: 100%; width: {{ $scoring['score'] }}%; background: {{ $scoreColor }}; border-radius: 6px; transition: width .5s;"></div>
    </div>

    {{-- Min ball ko'rsatkich --}}
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
        <span style="font-size: 11px; color: var(--text-muted);">Min: {{ $scoring['min_score'] }} ball</span>
        @if($scoring['can_withdraw'])
        <span style="font-size: 11px; font-weight: 600; color: #10b981;"><i class="fa fa-check-circle"></i> Yechish mumkin</span>
        @else
        <span style="font-size: 11px; font-weight: 600; color: #ef4444;"><i class="fa fa-lock"></i> Ball yetarli emas</span>
        @endif
    </div>

    {{-- Tafsilotlar --}}
    <div style="display: flex; flex-direction: column; gap: 6px;">
        @foreach($scoring['details'] as $key => $detail)
        <div style="display: flex; align-items: center; justify-content: space-between; font-size: 11px;">
            <span style="color: var(--text-secondary);">{{ $detail['label'] }}</span>
            <span style="font-weight: 600; color: {{ $detail['score'] >= 0 ? ($detail['score'] > 0 ? '#10b981' : 'var(--text-muted)') : '#ef4444' }};">
                {{ $detail['score'] > 0 ? '+' : '' }}{{ $detail['score'] }}/{{ $detail['max'] }}
            </span>
        </div>
        @endforeach
    </div>

    {{-- Maslahatlar --}}
    @if(!$scoring['can_withdraw'])
    <div style="margin-top: 12px; padding-top: 10px; border-top: 1px solid var(--border-primary);">
        <div style="font-size: 11px; font-weight: 600; color: var(--text-primary); margin-bottom: 6px;">💡 Ball oshirish:</div>
        @foreach($scoring['details'] as $detail)
            @if(!empty($detail['hint']))
            <div style="font-size: 11px; color: var(--text-muted); margin-bottom: 3px;">• {{ $detail['hint'] }}</div>
            @endif
        @endforeach
    </div>
    @endif
</div>

<div class="card" style="margin-bottom: 20px;">
    <div class="card-header">
        <span class="card-title"><i class="fa fa-arrow-up-from-bracket"></i> {{ __('front.withdraw.new_withdraw') }}</span>
        <span style="font-size:13px; color:var(--text-muted);">
            {{ __('front.withdraw.balance') }}: <strong style="color:#818cf8;">{{ number_format(auth()->user()->balance, 2) }}</strong>
        </span>
    </div>
    <div class="card-body">
        @if(!$scoring['can_withdraw'])
        <div style="text-align: center; padding: 24px 16px;">
            <div style="width: 56px; height: 56px; border-radius: 50%; background: rgba(239,68,68,.1); display: flex; align-items: center; justify-content: center; margin: 0 auto 12px;">
                <i class="fa fa-lock" style="font-size: 22px; color: #f87171;"></i>
            </div>
            <div style="font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 4px;">Yechish bloklangan</div>
            <div style="font-size: 12px; color: var(--text-muted); line-height: 1.6;">
                Pul yechish uchun kamida {{ $scoring['min_score'] }} ball kerak.<br>
                Hozirgi balingiz: <strong style="color: #ef4444;">{{ $scoring['score'] }}</strong>
            </div>
        </div>
        @elseif($needsNewDeposit)
        <div style="text-align: center; padding: 24px 16px;">
            <div style="width: 56px; height: 56px; border-radius: 50%; background: rgba(245,158,11,.1); display: flex; align-items: center; justify-content: center; margin: 0 auto 12px;">
                <i class="fa fa-arrow-down" style="font-size: 22px; color: #fbbf24;"></i>
            </div>
            <div style="font-size: 15px; font-weight: 700; color: var(--text-primary); margin-bottom: 4px;">Avval depozit qiling</div>
            <div style="font-size: 12px; color: var(--text-muted); line-height: 1.6; margin-bottom: 14px;">
                Har yechish oldidan yangi depozit qilish majburiy.<br>
                Kamida <strong style="color: #fbbf24;">{{ number_format($setting->min_deposit, 0) }} UZS</strong> miqdorida depozit qiling.
            </div>
            <a href="{{ route('app.deposit') }}" class="btn btn-primary">
                <i class="fa fa-plus"></i> Depozit qilish
            </a>
        </div>
        @else
        <form method="POST" action="{{ route('app.withdraw.store') }}">
            @csrf

            <div class="form-group">
                <label class="form-label">{{ __('front.withdraw.payment_method') }}</label>
                <select name="payment_method_id" required
                        class="form-control {{ $errors->has('payment_method_id') ? 'is-invalid' : '' }}"
                        onchange="showMethodDetails(this)">
                    <option value="">{{ __('front.withdraw.select') }}</option>
                    @foreach($methods as $method)
                    <option value="{{ $method->id }}"
                            data-charge="{{ $method->withdraw_charge_percent }}"
                            data-min="{{ $method->minimum_withdraw }}"
                            data-max="{{ $method->maximum_withdraw }}"
                            {{ old('payment_method_id') == $method->id ? 'selected' : '' }}>
                        {{ $method->getTranslation('name', app()->getLocale()) }}
                    </option>
                    @endforeach
                </select>
                @error('payment_method_id')
                    <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div>
                @enderror
            </div>

            {{-- Method info --}}
            <div id="methodInfo" style="display:none; margin-bottom:16px;">
                <div style="background: rgba(99,102,241,.08); border: 1px solid rgba(99,102,241,.2);
                            border-radius: 14px; padding: 14px;">
                    <div id="methodCharge" style="font-size: 12px; color: var(--gray);"></div>
                </div>
            </div>

            <div class="form-group">
                <label class="form-label">{{ __('front.withdraw.amount') }}</label>
                <input type="number" name="amount" step="0.01"
                       min="{{ $setting->min_withdraw }}" max="{{ $setting->max_withdraw }}"
                       value="{{ old('amount') }}" required
                       class="form-control {{ $errors->has('amount') ? 'is-invalid' : '' }}"
                       placeholder="{{ $setting->min_withdraw }} — {{ $setting->max_withdraw }}"
                       oninput="calcCharge()">
                <div id="chargeInfo" style="font-size:12px; color:var(--gray); margin-top:6px;"></div>
                {{-- Global withdrawal fee ko'rsatish --}}
                @php $globalFee = $setting->withdrawal_fee_percent ?? 1.0; @endphp
                @if($globalFee > 0)
                <div style="font-size:11px; color:#f59e0b; margin-top:4px;">
                    ⚠️ Global komissiya: {{ $globalFee }}% (barcha yechimlar uchun)
                </div>
                @endif
                @error('amount')
                    <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <label class="form-label">{{ __('front.withdraw.account_number') }}</label>
                <input type="text" name="account_number" value="{{ old('account_number') }}" required
                       class="form-control {{ $errors->has('account_number') ? 'is-invalid' : '' }}"
                       placeholder="{{ __('front.withdraw.account_placeholder') }}">
                @error('account_number')
                    <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div>
                @enderror
            </div>

            <button type="submit" class="btn btn-primary btn-full btn-lg">
                <i class="fa fa-paper-plane"></i> {{ __('front.withdraw.submit') }}
            </button>
        </form>
        @endif
    </div>
</div>

{{-- Tarix --}}
<p class="section-label" style="margin-top: 24px;">{{ __('front.withdraw.history') }}</p>
<div class="card">
    @forelse($withdrawals as $w)
    <div class="list-item">
        <div style="width:42px; height:42px; border-radius:12px; flex-shrink:0;
                    background: rgba(239,68,68,.1); display:flex; align-items:center; justify-content:center;">
            <i class="fa fa-arrow-up-from-bracket" style="color:#f87171; font-size:15px;"></i>
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:500; color:#e2e8f0;">
                {{ $w->method_name ?? $w->paymentMethod?->getTranslation('name', app()->getLocale()) }}
            </div>
            <div style="font-size:11px; color:var(--gray); margin-top:2px;">
                {{ $w->receiver_number }} · {{ $w->created_at->format('d.m.Y H:i') }}
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <div style="font-size:14px; font-weight:600; color:#f87171;">
                -{{ number_format($w->amount, 2) }}
            </div>
            <div style="margin-top:3px;">
                @if($w->status === 'approved')
                <span class="badge badge-success"><i class="fa fa-check"></i> {{ __('front.withdraw.approved') }}</span>
                @elseif($w->status === 'rejected')
                <span class="badge badge-danger"><i class="fa fa-times"></i> {{ __('front.withdraw.rejected') }}</span>
                @else
                <span class="badge badge-warning"><i class="fa fa-clock"></i> {{ __('front.withdraw.pending') }}</span>
                @endif
            </div>
        </div>
    </div>
    @empty
    <div style="padding:40px; text-align:center; color:var(--gray);">
        <i class="fa fa-receipt" style="font-size:32px; opacity:.3; display:block; margin-bottom:10px;"></i>
        {{ __('front.withdraw.no_withdrawals') }}
    </div>
    @endforelse
</div>

@if($withdrawals->hasPages())
<div style="margin-top:16px; text-align:center;">
    {{ $withdrawals->links() }}
</div>
@endif

@endsection

@section('scripts')
<script>
let selectedMethod = null;

function showMethodDetails(sel) {
    const opt = sel.options[sel.selectedIndex];
    const info = document.getElementById('methodInfo');
    if (!opt.value) { info.style.display = 'none'; selectedMethod = null; return; }

    selectedMethod = {
        charge: parseFloat(opt.dataset.charge),
        min: parseFloat(opt.dataset.min),
        max: parseFloat(opt.dataset.max),
    };

    document.getElementById('methodCharge').textContent =
        '{{ __('front.withdraw.commission_label') }} ' + opt.dataset.charge + '%  |  {{ __('front.withdraw.min_label') }} ' + opt.dataset.min + '  |  {{ __('front.withdraw.max_label') }} ' + opt.dataset.max;
    info.style.display = 'block';
    calcCharge();
}

function calcCharge() {
    if (!selectedMethod) return;
    const amount = parseFloat(document.querySelector('[name=amount]').value) || 0;
    const charge = (amount * selectedMethod.charge / 100).toFixed(2);
    const net = (amount - charge).toFixed(2);
    document.getElementById('chargeInfo').textContent =
        amount > 0 ? `{{ __('front.withdraw.commission_label') }} ${charge} | {{ __('front.withdraw.you_receive') }} ${net}` : '';
}
</script>
@endsection
