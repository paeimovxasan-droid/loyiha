@extends('front.layouts.app')
@section('title', 'Jamg\'arma')
@section('content')

<div class="page-title">🏦 Jamg'arma</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

{{-- Active plan --}}
@if($activePlan)
<div class="card" style="margin-bottom:20px; border-left:3px solid var(--primary);">
    <div style="padding:20px;">
        <div style="font-size:13px; color:var(--gray); margin-bottom:8px;">
            <i class="fa fa-piggy-bank" style="color:var(--primary);"></i> Faol jamg'arma
        </div>
        <div style="display:flex; gap:8px; margin-bottom:14px;">
            <div style="flex:1; background:rgba(99,102,241,.08); border-radius:10px; padding:12px; text-align:center;">
                <div style="font-size:18px; font-weight:800; color:#818cf8;">{{ number_format($activePlan->total_saved) }}</div>
                <div style="font-size:10px; color:var(--gray);">Jami (UZS)</div>
            </div>
            <div style="flex:1; background:rgba(16,185,129,.08); border-radius:10px; padding:12px; text-align:center;">
                <div style="font-size:18px; font-weight:800; color:#34d399;">{{ $activePlan->bonus_rate }}%</div>
                <div style="font-size:10px; color:var(--gray);">Bonus</div>
            </div>
        </div>

        {{-- Progress --}}
        @php $planProgress = $activePlan->term_months > 0 ? round(($activePlan->paid_months / $activePlan->term_months) * 100) : 0; @endphp
        <div style="margin-bottom:10px;">
            <div style="display:flex; justify-content:space-between; font-size:11px; color:var(--gray); margin-bottom:6px;">
                <span>{{ $activePlan->paid_months }} / {{ $activePlan->term_months }} oy</span>
                <span>{{ $planProgress }}%</span>
            </div>
            <div style="height:6px; background:var(--dark-3); border-radius:3px; overflow:hidden;">
                <div style="height:100%; width:{{ $planProgress }}%;
                            background:linear-gradient(90deg, var(--primary), var(--secondary));
                            border-radius:3px;"></div>
            </div>
        </div>
        <div style="font-size:12px; color:var(--gray);">
            Oylik: {{ number_format($activePlan->monthly_amount) }} UZS ·
            Keyingi to'lov: {{ $activePlan->next_payment_date?->format('d.m.Y') ?? '—' }}
        </div>
    </div>
</div>
@endif

{{-- Create plan form --}}
@if(!$activePlan)
<p class="section-label">Reja tanlang</p>
<div style="display:flex; flex-direction:column; gap:12px; margin-bottom:20px;">
    @php
        $planOptions = [
            ['months' => 3, 'bonus' => 3, 'color' => '#22d3ee', 'bg' => 'rgba(6,182,212,.1)', 'border' => 'rgba(6,182,212,.25)', 'icon' => '🌱'],
            ['months' => 6, 'bonus' => 5, 'color' => '#818cf8', 'bg' => 'rgba(99,102,241,.1)', 'border' => 'rgba(99,102,241,.25)', 'icon' => '🌿'],
            ['months' => 12, 'bonus' => 8, 'color' => '#34d399', 'bg' => 'rgba(16,185,129,.1)', 'border' => 'rgba(16,185,129,.25)', 'icon' => '🌳'],
        ];
    @endphp
    @foreach($planOptions as $opt)
    <div class="card" style="border:1px solid {{ $opt['border'] }}; cursor:pointer;"
         onclick="document.getElementById('term_{{ $opt['months'] }}').checked=true; document.querySelectorAll('.plan-card').forEach(c=>c.style.borderWidth='1px'); this.style.borderWidth='2px';"
         class="plan-card">
        <div style="padding:20px; display:flex; align-items:center; gap:14px;">
            <div style="font-size:32px;">{{ $opt['icon'] }}</div>
            <div style="flex:1;">
                <div style="font-size:16px; font-weight:700; color:{{ $opt['color'] }};">{{ $opt['months'] }} oy</div>
                <div style="font-size:12px; color:var(--gray); margin-top:2px;">Oylik jamg'arma rejasi</div>
            </div>
            <div style="text-align:right;">
                <div style="font-size:20px; font-weight:800; color:{{ $opt['color'] }};">+{{ $opt['bonus'] }}%</div>
                <div style="font-size:10px; color:var(--gray);">Bonus</div>
            </div>
        </div>
    </div>
    @endforeach
</div>

<div class="card" style="margin-bottom:20px;">
    <div style="padding:20px;">
        <div style="font-size:15px; font-weight:700; color:#f1f5f9; margin-bottom:16px;">
            <i class="fa fa-piggy-bank"></i> Jamg'arma rejasi yaratish
        </div>
        <form method="POST" action="{{ route('app.savings.create') }}">
            @csrf
            <div style="margin-bottom:12px;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Muddat</label>
                <div style="display:flex; gap:8px;">
                    @foreach($planOptions as $opt)
                    <label style="flex:1; display:flex; align-items:center; justify-content:center; gap:6px;
                                  padding:10px; border-radius:10px; cursor:pointer;
                                  background:{{ $opt['bg'] }}; border:1px solid {{ $opt['border'] }};
                                  font-size:13px; font-weight:600; color:{{ $opt['color'] }};">
                        <input type="radio" name="term_months" value="{{ $opt['months'] }}" id="term_{{ $opt['months'] }}"
                               style="display:none;" {{ $loop->first ? 'checked' : '' }}>
                        {{ $opt['months'] }} oy
                    </label>
                    @endforeach
                </div>
            </div>
            <div style="margin-bottom:14px;">
                <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Oylik miqdor (UZS)</label>
                <input type="number" name="monthly_amount" min="10000" step="5000" required
                       class="form-control" placeholder="Oylik miqdor">
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;">
                <i class="fa fa-plus"></i> Reja yaratish
            </button>
        </form>
    </div>
</div>
@endif

{{-- Plans history --}}
@if($plans->where('status', '!=', 'active')->count())
<p class="section-label">Jamg'arma tarixi</p>
<div class="card">
    @foreach($plans->where('status', '!=', 'active') as $plan)
    <div class="list-item">
        <div style="width:40px; height:40px; border-radius:12px; flex-shrink:0;
                    background:rgba(100,116,139,.1); display:flex; align-items:center; justify-content:center;">
            <i class="fa fa-piggy-bank" style="color:var(--gray);"></i>
        </div>
        <div style="flex:1; min-width:0;">
            <div style="font-size:13px; font-weight:500; color:#e2e8f0;">
                {{ number_format($plan->total_saved) }} UZS
            </div>
            <div style="font-size:11px; color:var(--gray);">
                {{ $plan->term_months }} oy · {{ $plan->bonus_rate }}% bonus
            </div>
        </div>
        <div style="text-align:right; flex-shrink:0;">
            <span style="font-size:10px; padding:2px 8px; border-radius:10px;
                         background:rgba(100,116,139,.15); color:var(--gray);">
                {{ $plan->status }}
            </span>
        </div>
    </div>
    @endforeach
</div>
@endif

@endsection
