@extends('front.layouts.app')
@section('title', __('front.profile.title'))

@section('content')

<div class="page-title">👤 {{ __('front.profile.title') }}</div>

@if(session('success'))
<div class="alert alert-success"><i class="fa fa-check-circle"></i> {{ session('success') }}</div>
@endif
@if($errors->any())
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ $errors->first() }}</div>
@endif

{{-- Avatar + Info --}}
<div class="card" style="padding: 24px; margin-bottom: 20px; text-align: center;">
    <div style="position: relative; display: inline-block; margin-bottom: 16px;">
        <img src="{{ $user->avatar_url }}" alt="Avatar"
             style="width: 90px; height: 90px; border-radius: 24px; object-fit: cover;
                    border: 3px solid rgba(99,102,241,.4); display: block;">
        <div style="position: absolute; bottom: -4px; right: -4px;
                    width: 22px; height: 22px; border-radius: 50%;
                    background: {{ $user->status === 'active' ? '#10b981' : '#ef4444' }};
                    border: 2px solid var(--dark-2);"></div>
    </div>
    <h2 style="font-size: 18px; font-weight: 700; color: #f1f5f9; margin-bottom: 4px;">
        {{ $user->name }}
    </h2>
    <div style="font-size: 13px; color: var(--gray); margin-bottom: 12px;">
        {{ $user->username ? '@'.$user->username : '—' }}
    </div>

    <div style="display: flex; justify-content: center; gap: 16px;">
        <div style="text-align: center;">
            <div style="font-size: 18px; font-weight: 700; color: #818cf8;">
                {{ number_format($user->balance ?? 0, 2) }}
            </div>
            <div style="font-size: 11px; color: var(--gray);">{{ __('front.profile.balance') }}</div>
        </div>
        <div style="width: 1px; background: var(--border);"></div>
        <div style="text-align: center;">
            <div style="font-size: 18px; font-weight: 700; color: #34d399;">
                {{ $user->referrals()->count() }}
            </div>
            <div style="font-size: 11px; color: var(--gray);">{{ __('front.profile.referrals') }}</div>
        </div>
        <div style="width: 1px; background: var(--border);"></div>
        <div style="text-align: center;">
            <div style="font-size: 18px; font-weight: 700; color: #fbbf24;">
                {{ $user->purchases()->where('status', 'active')->count() }}
            </div>
            <div style="font-size: 11px; color: var(--gray);">{{ __('front.profile.active_package') }}</div>
        </div>
    </div>
</div>

{{-- Ma'lumotlarni tahrirlash --}}
<p class="section-label">{{ __('front.profile.update_info') }}</p>
<div class="card" style="margin-bottom: 20px;">
    <div class="card-header">
        <span class="card-title"><i class="fa fa-pen-to-square"></i> {{ __('front.profile.personal_info') }}</span>
    </div>
    <div class="card-body">
        <form method="POST" action="{{ route('app.profile.update') }}" enctype="multipart/form-data">
            @csrf
            @method('PUT')

            <div class="form-group">
                <label class="form-label">{{ __('front.profile.full_name') }}</label>
                <input type="text" name="name" value="{{ old('name', $user->name) }}" required
                       class="form-control {{ $errors->has('name') ? 'is-invalid' : '' }}">
                @error('name') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
            </div>

            <div class="form-group">
                <label class="form-label">{{ __('front.profile.username') }}</label>
                <input type="text" name="username" value="{{ old('username', $user->username) }}" required
                       class="form-control {{ $errors->has('username') ? 'is-invalid' : '' }}">
                @error('username') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
            </div>

            <div class="form-group">
                <label class="form-label">{{ __('front.profile.email') }}</label>
                <input type="email" name="email" value="{{ old('email', $user->email) }}" required
                       class="form-control {{ $errors->has('email') ? 'is-invalid' : '' }}">
                @error('email') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
            </div>

            <div class="form-group">
                <label class="form-label">{{ __('front.profile.phone') }}</label>
                <input type="text" name="phone" value="{{ old('phone', $user->phone) }}"
                       class="form-control {{ $errors->has('phone') ? 'is-invalid' : '' }}"
                       placeholder="+998901234567">
                @error('phone') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
            </div>

            <div class="form-group">
                <label class="form-label">{{ __('front.profile.avatar') }}</label>

                {{-- Avatar picker --}}
                <div style="display:flex; align-items:center; gap:16px;">
                    {{-- Preview circle --}}
                    <div style="flex-shrink:0;">
                        <img id="avatarPreviewImg"
                             src="{{ $user->avatar_url }}"
                             alt="Avatar"
                             style="width:72px; height:72px; border-radius:18px;
                                    object-fit:cover; border:2px solid rgba(99,102,241,.4);">
                    </div>

                    {{-- Pick button --}}
                    <div style="flex:1;">
                        <div id="avatarPicker"
                             onclick="document.getElementById('avatarInput').click()"
                             style="
                                border: 2px dashed rgba(99,102,241,.4);
                                border-radius: 14px;
                                padding: 14px 16px;
                                cursor: pointer;
                                transition: all .2s;
                                background: rgba(99,102,241,.05);
                             "
                             onmouseenter="this.style.borderColor='rgba(99,102,241,.8)'; this.style.background='rgba(99,102,241,.1)'"
                             onmouseleave="this.style.borderColor='rgba(99,102,241,.4)'; this.style.background='rgba(99,102,241,.05)'">
                            <div style="display:flex; align-items:center; gap:10px;">
                                <div style="width:36px; height:36px; border-radius:10px;
                                            background:rgba(99,102,241,.15);
                                            display:flex; align-items:center; justify-content:center; flex-shrink:0;">
                                    <i class="fa fa-camera" style="color:#818cf8; font-size:15px;"></i>
                                </div>
                                <div>
                                    <div id="avatarPickerText" style="font-size:13px; font-weight:600; color:#c7d2fe;">{{ __('front.profile.select_image') }}</div>
                                    <div style="font-size:11px; color:var(--gray); margin-top:2px;">{{ __('front.profile.image_hint') }}</div>
                                </div>
                            </div>
                        </div>

                        <input type="file" id="avatarInput" name="avatar"
                               accept="image/*" style="display:none;"
                               onchange="previewAvatar(this)">
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-full">
                <i class="fa fa-save"></i> {{ __('front.profile.save') }}
            </button>
        </form>
    </div>
</div>

{{-- Parolni o'zgartirish --}}
<p class="section-label">{{ __('front.profile.security') }}</p>
<div class="card" style="margin-bottom: 20px;">
    <div class="card-header">
        <span class="card-title"><i class="fa fa-lock"></i> {{ __('front.profile.change_password') }}</span>
    </div>
    <div class="card-body">
        <form method="POST" action="{{ route('app.profile.password') }}">
            @csrf
            @method('PUT')

            <div class="form-group">
                <label class="form-label">{{ __('front.profile.current_password') }}</label>
                <input type="password" name="current_password" required class="form-control"
                       placeholder="{{ __('front.profile.current_password_placeholder') }}">
                @error('current_password') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
            </div>

            <div class="form-group">
                <label class="form-label">{{ __('front.profile.new_password') }}</label>
                <input type="password" name="password" required class="form-control"
                       placeholder="{{ __('front.profile.new_password_placeholder') }}">
                @error('password') <div class="invalid-feedback"><i class="fa fa-exclamation-circle"></i> {{ $message }}</div> @enderror
            </div>

            <div class="form-group">
                <label class="form-label">{{ __('front.profile.confirm_password') }}</label>
                <input type="password" name="password_confirmation" required class="form-control"
                       placeholder="{{ __('front.profile.confirm_password_placeholder') }}">
            </div>

            <button type="submit" class="btn btn-danger btn-full">
                <i class="fa fa-key"></i> {{ __('front.profile.update_password') }}
            </button>
        </form>
    </div>
</div>

{{-- Hisobdan chiqish --}}
<div class="card" style="padding: 16px; margin-bottom: 20px;">
    <div style="display:flex; gap:10px; margin-bottom:10px;">
        <a href="{{ route('app.kyc') }}"
           style="flex:1; display:flex; align-items:center; justify-content:center; gap:8px;
                  padding:12px; border-radius:12px; text-decoration:none; font-size:13px; font-weight:600;
                  background:rgba(99,102,241,.1); border:1px solid rgba(99,102,241,.2); color:#818cf8;">
            <i class="fa fa-id-card"></i>
            KYC Tasdiqlash
            @if($user->kyc_status === 'verified')
            <span class="badge badge-success" style="font-size:10px;">✅</span>
            @elseif(in_array($user->kyc_status, ['passport_pending', 'face_pending']))
            <span class="badge badge-warning" style="font-size:10px;">⏳</span>
            @elseif($user->kyc_status === 'passport_verified')
            <span class="badge badge-info" style="font-size:10px;">🪪</span>
            @endif
        </a>
        <a href="{{ route('app.level') }}"
           style="flex:1; display:flex; align-items:center; justify-content:center; gap:8px;
                  padding:12px; border-radius:12px; text-decoration:none; font-size:13px; font-weight:600;
                  background:rgba(245,158,11,.1); border:1px solid rgba(245,158,11,.2); color:#fbbf24;">
            <i class="fa fa-bolt"></i>
            Level {{ $user->userLevel?->level ?? 0 }}
        </a>
    </div>
    <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button type="submit" class="btn btn-outline btn-full"
                onclick="event.preventDefault(); window.openConfirmModal('{{ __('front.profile.logout_confirm') }}', this.closest('form'))"
                style="border-color: rgba(239,68,68,.3); color: #f87171;">
            <i class="fa fa-right-from-bracket"></i> {{ __('front.profile.logout') }}
        </button>
    </form>
</div>

@endsection

@section('scripts')
<script>
function previewAvatar(input) {
    const file = input.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function(e) {
        document.getElementById('avatarPreviewImg').src = e.target.result;
        document.getElementById('avatarPickerText').textContent = file.name;
        document.getElementById('avatarPicker').style.borderColor = 'rgba(16,185,129,.6)';
        document.getElementById('avatarPicker').style.background = 'rgba(16,185,129,.05)';
    };
    reader.readAsDataURL(file);
}
</script>
@endsection
