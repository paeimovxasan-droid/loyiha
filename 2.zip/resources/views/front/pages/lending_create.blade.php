@extends('front.layouts.app')
@section('title', 'Kredit taklifi yaratish')
@section('content')

<div class="page-title">🏦 Kredit taklifi yaratish</div>

@if(session('error'))
<div class="alert alert-danger"><i class="fa fa-exclamation-circle"></i> {{ session('error') }}</div>
@endif

<div class="card" style="padding:20px;">
    <div style="padding:12px; background:rgba(99,102,241,.08); border-radius:10px; margin-bottom:14px;">
        <div style="font-size:12px; color:#818cf8;"><i class="fa fa-info-circle"></i> Taklif yaratganingizda AIS hamyoningizdan mablag' yechiladi</div>
    </div>
    <form method="POST" action="{{ route('app.lending.store') }}">
        @csrf
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Miqdor (AIS)</label>
            <input type="number" name="amount" class="form-control" required min="1" step="0.01" value="{{ old('amount') }}" placeholder="Masalan: 1000">
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Foiz stavkasi (%)</label>
            <input type="number" name="interest_rate" class="form-control" required min="0" max="100" step="0.1" value="{{ old('interest_rate') }}" placeholder="Masalan: 5">
        </div>
        <div style="margin-bottom:14px;">
            <label style="font-size:12px; color:var(--gray); display:block; margin-bottom:6px;">Muddat (kun)</label>
            <input type="number" name="duration_days" class="form-control" required min="1" max="365" value="{{ old('duration_days') }}" placeholder="Masalan: 30">
        </div>
        <button type="submit" class="btn btn-primary" style="width:100%;">
            <i class="fa fa-paper-plane"></i> Taklif yaratish
        </button>
    </form>
</div>

@endsection
