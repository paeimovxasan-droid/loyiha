<?php

/**
 * AISOQQA — Hosting uchun entry point
 * Barcha so'rovlarni public/index.php ga yo'naltiradi
 */

// public/index.php ni chaqirish
require_once __DIR__.'/public/index.php';
