import { useState, useEffect, useCallback } from 'react';
import { getCompetitions } from '../api/client';
import { useLang } from '../contexts/LangContext';
import useHaptic from '../hooks/useHaptic';
import SkeletonLoader from '../components/SkeletonLoader';
import LeaderboardTable from '../components/LeaderboardTable';
import CountdownTimer from '../components/CountdownTimer';

export default function Competitions() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('weekly');
  const { t } = useLang();
  const { impactOccurred } = useHaptic();

  const fetchData = useCallback(async () => {
    try {
      const res = await getCompetitions();
      if (res.data?.success) setData(res.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="page"><SkeletonLoader lines={5} /></div>;

  const comp = data?.[tab];

  return (
    <div className="page">
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '16px' }}>🏆 {t('competitions')}</h2>

      <div className="tab-bar">
        {['weekly', 'monthly'].map((k) => (
          <button key={k} className={tab === k ? 'active' : ''} onClick={() => { impactOccurred('light'); setTab(k); }}>
            {t(k)}
          </button>
        ))}
      </div>

      {comp ? (
        <>
          <div className="card text-center mb-8">
            <CountdownTimer targetDate={comp.ends_at} />
          </div>

          {comp.user_rank && (
            <div className="card flex justify-between items-center">
              <span style={{ fontWeight: 600 }}>{t('your_rank')}</span>
              <span className="text-accent" style={{ fontWeight: 700 }}>#{comp.user_rank}</span>
            </div>
          )}

          {comp.prizes?.length > 0 && (
            <div className="card">
              <div style={{ fontWeight: 600, marginBottom: '8px' }}>🎁 {t('prizes')}</div>
              {comp.prizes.map((p, i) => (
                <div key={i} className="flex justify-between text-hint" style={{ fontSize: '13px', marginBottom: '4px' }}>
                  <span>#{i + 1}</span><span>{p.reward_ais || p.amount} AIS</span>
                </div>
              ))}
            </div>
          )}

          <LeaderboardTable entries={comp.leaderboard || []} userRank={comp.user_rank} />
        </>
      ) : (
        <div className="card text-center text-hint">{t('no_active_competition')}</div>
      )}
    </div>
  );
}
