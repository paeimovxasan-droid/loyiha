import { useState, useEffect, useCallback } from 'react';
import { getInviteChallenge, startChallenge } from '../api/client';
import { useLang } from '../contexts/LangContext';
import useHaptic from '../hooks/useHaptic';
import SkeletonLoader from '../components/SkeletonLoader';
import CountdownTimer from '../components/CountdownTimer';

export default function InviteChallenge() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);
  const { t } = useLang();
  const { notificationOccurred } = useHaptic();

  const fetchData = useCallback(async () => {
    try {
      const res = await getInviteChallenge();
      if (res.data?.success) setData(res.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleStart = async () => {
    setMsg(null);
    try {
      const res = await startChallenge();
      notificationOccurred('success');
      setMsg({ type: 'success', text: res.data?.message || t('success') });
      fetchData();
    } catch (err) {
      notificationOccurred('error');
      setMsg({ type: 'error', text: err.response?.data?.message || t('error') });
    }
  };

  if (loading) return <div className="page"><SkeletonLoader lines={4} /></div>;

  const ch = data?.challenge;

  return (
    <div className="page">
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '16px' }}>🏆 {t('invite_challenge')}</h2>

      {msg && <div className={`card ${msg.type === 'error' ? 'text-destructive' : 'text-accent'}`}>{msg.text}</div>}

      {!data?.active ? (
        <div className="card text-center">
          <div style={{ fontSize: '48px', marginBottom: '8px' }}>🚀</div>
          <p className="text-hint mb-8">{t('no_active_challenge')}</p>
          <button className="btn btn-primary" onClick={handleStart}>🎯 {t('start_challenge')}</button>
        </div>
      ) : (
        <>
          <div className="card text-center">
            <CountdownTimer targetDate={ch?.ends_at} />
          </div>

          <div className="card">
            <div className="flex justify-between items-center mb-8">
              <span style={{ fontWeight: 600 }}>{t('progress')}</span>
              <span className="text-accent" style={{ fontWeight: 700 }}>{ch?.progress || 0} / {ch?.target || 0}</span>
            </div>
            <div className="progress-bar">
              <div className="progress-bar-fill" style={{ width: `${ch?.target ? (ch.progress / ch.target) * 100 : 0}%`, background: 'var(--button-color)' }} />
            </div>
            <div className="text-hint mt-8">🎁 {t('reward')}: {ch?.reward_ais || 0} AIS</div>
          </div>

          {ch?.referrals?.length > 0 && (
            <div>
              <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '8px' }}>{t('referrals')}</h3>
              {ch.referrals.map((r, i) => (
                <div key={i} className="list-item justify-between">
                  <span>{r.name || r.masked_name}</span>
                  <span className="text-hint">{r.registered_at}</span>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
