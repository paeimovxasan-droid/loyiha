import { useState, useEffect, useCallback } from 'react';
import client from '../api/client';
import { useLang } from '../contexts/LangContext';
import useHaptic from '../hooks/useHaptic';
import SkeletonLoader from '../components/SkeletonLoader';

export default function Withdrawal() {
  const [withdrawals, setWithdrawals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const { t } = useLang();
  const { notificationOccurred } = useHaptic();

  const fetchData = useCallback(async () => {
    try {
      const res = await client.get('/withdrawals');
      if (res.data?.success) setWithdrawals(res.data.data.withdrawals || []);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSubmitting(true); setMsg(null);
    try {
      const res = await client.post('/withdrawals', form);
      notificationOccurred('success');
      setMsg({ type: 'success', text: res.data?.message || t('success') });
      setForm({}); setShowForm(false); fetchData();
    } catch (err) {
      notificationOccurred('error');
      setMsg({ type: 'error', text: err.response?.data?.message || t('error') });
    } finally { setSubmitting(false); }
  };

  if (loading) return <div className="page"><SkeletonLoader lines={4} /></div>;

  return (
    <div className="page">
      <div className="flex justify-between items-center mb-16">
        <div className="page-title" style={{ margin: 0 }}>💸 {t('withdraw')}</div>
        <button className="btn btn-primary" style={{ width: 'auto', padding: '8px 16px' }} onClick={() => setShowForm(!showForm)}>+</button>
      </div>

      {msg && <div className={`card ${msg.type === 'error' ? 'text-destructive' : 'text-accent'}`}>{msg.text}</div>}

      {showForm && (
        <form onSubmit={handleSubmit} className="card flex flex-col gap-12 mb-16">
          <input type="number" placeholder={`${t('amount')} (UZS)`} value={form.amount || ''} onChange={(e) => setForm({ ...form, amount: e.target.value })} required />
          <input placeholder="Hisob raqami" value={form.account_number || ''} onChange={(e) => setForm({ ...form, account_number: e.target.value })} required />
          <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? '...' : t('submit')}</button>
        </form>
      )}

      {withdrawals.map((w, i) => (
        <div key={i} className="list-item justify-between">
          <div>
            <div style={{ fontWeight: 600 }}>{Number(w.amount).toLocaleString()} UZS</div>
            <div className="text-hint">{new Date(w.created_at).toLocaleDateString()}</div>
          </div>
          <span className="badge" style={{
            background: w.status === 'approved' ? '#34d399' : w.status === 'rejected' ? 'var(--destructive)' : '#fbbf24',
            color: '#fff',
          }}>{t(w.status)}</span>
        </div>
      ))}
    </div>
  );
}
