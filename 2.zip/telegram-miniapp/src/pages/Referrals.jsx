import { useState, useEffect } from 'react';
import client from '../api/client';
import { useLang } from '../contexts/LangContext';
import SkeletonLoader from '../components/SkeletonLoader';

export default function Referrals() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { t } = useLang();

  useEffect(() => {
    client.get('/referrals').then((res) => {
      if (res.data?.success) setData(res.data.data);
    }).finally(() => setLoading(false));
  }, []);

  const share = () => {
    const tg = window.Telegram?.WebApp;
    if (tg?.openTelegramLink && data?.referral_link_telegram) {
      tg.openTelegramLink(`https://t.me/share/url?url=${encodeURIComponent(data.referral_link_telegram)}&text=${encodeURIComponent('AISOQQA platformasiga qo\'shiling!')}`);
    }
  };

  if (loading) return <div className="page"><SkeletonLoader lines={4} /></div>;

  return (
    <div className="page">
      <div className="page-title">👥 {t('referrals')}</div>

      <div className="card text-center mb-16">
        <div className="stat-value">{Number(data?.total_commission || 0).toLocaleString()}</div>
        <div className="stat-label">Jami komissiya (UZS)</div>
      </div>

      <div className="card mb-16">
        <div className="text-hint mb-8">{t('referral_link')}</div>
        <div style={{ fontSize: '13px', wordBreak: 'break-all', marginBottom: '12px' }}>{data?.referral_link_telegram}</div>
        <button className="btn btn-primary" onClick={share}>📤 {t('share')}</button>
      </div>

      {data?.referrals?.map((ref, i) => (
        <div key={i} className="list-item justify-between">
          <div>
            <div style={{ fontWeight: 600 }}>{ref.name}</div>
            <div className="text-hint">@{ref.username}</div>
          </div>
          <div className="text-hint">{new Date(ref.created_at).toLocaleDateString()}</div>
        </div>
      ))}
    </div>
  );
}
