import { useState, useEffect, useCallback } from 'react';
import client from '../api/client';
import { useLang } from '../contexts/LangContext';
import useHaptic from '../hooks/useHaptic';
import SkeletonLoader from '../components/SkeletonLoader';

export default function Quests() {
  const [quests, setQuests] = useState({});
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);
  const { t } = useLang();
  const { notificationOccurred } = useHaptic();

  const fetchData = useCallback(async () => {
    try {
      const [qRes, sRes] = await Promise.all([
        client.get('/quests'),
        client.get('/quests/stats'),
      ]);
      if (qRes.data?.success) setQuests(qRes.data.data.quests || {});
      if (sRes.data?.success) setStats(sRes.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const claimReward = async (userQuestId) => {
    setMsg(null);
    try {
      const res = await client.post(`/quests/${userQuestId}/claim`);
      notificationOccurred('success');
      setMsg({ type: 'success', text: res.data?.message || t('success') });
      fetchData();
    } catch (err) {
      notificationOccurred('error');
      setMsg({ type: 'error', text: err.response?.data?.message || t('error') });
    }
  };

  if (loading) return <div className="page"><SkeletonLoader lines={5} /></div>;

  return (
    <div className="page">
      {stats && (
        <div className="card grid-2 mb-16">
          <div className="text-center">
            <div className="stat-value">{stats.completed}</div>
            <div className="stat-label">Tugallangan</div>
          </div>
          <div className="text-center">
            <div className="stat-value">{stats.available}</div>
            <div className="stat-label">Mavjud</div>
          </div>
        </div>
      )}

      {msg && <div className={`card ${msg.type === 'error' ? 'text-destructive' : 'text-accent'}`}>{msg.text}</div>}

      {Object.entries(quests).map(([category, items]) => (
        <div key={category}>
          <h3 style={{ fontSize: '15px', fontWeight: 600, margin: '16px 0 8px', textTransform: 'capitalize' }}>
            {category}
          </h3>
          {items.map((q) => (
            <div key={q.id || q.quest_id} className="card">
              <div className="flex justify-between items-center mb-8">
                <div style={{ fontWeight: 600 }}>{q.icon} {q.title}</div>
                <span className="text-hint" style={{ fontSize: '12px' }}>{q.reward_text}</span>
              </div>
              <div className="progress-bar mb-8">
                <div className="progress-bar-fill" style={{ width: `${q.progress_percent}%`, background: 'var(--button-color)' }} />
              </div>
              <div className="flex justify-between items-center">
                <span className="text-hint">{q.progress}/{q.requirement_value}</span>
                {q.status === 'completed' && (
                  <button className="btn btn-primary" style={{ width: 'auto', padding: '8px 16px', fontSize: '13px' }} onClick={() => claimReward(q.id)}>
                    🎁 {t('claim')}
                  </button>
                )}
                {q.status === 'claimed' && <span style={{ color: '#34d399', fontSize: '13px' }}>✅</span>}
              </div>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
