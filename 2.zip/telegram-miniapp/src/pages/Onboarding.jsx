import { useState, useEffect, useCallback } from 'react';
import { getOnboarding } from '../api/client';
import { useLang } from '../contexts/LangContext';
import SkeletonLoader from '../components/SkeletonLoader';
import OnboardingStep from '../components/OnboardingStep';

export default function Onboarding() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { t } = useLang();

  const fetchData = useCallback(async () => {
    try {
      const res = await getOnboarding();
      if (res.data?.success) setData(res.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="page"><SkeletonLoader lines={5} /></div>;

  return (
    <div className="page">
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '4px' }}>📋 {t('onboarding')}</h2>
      <p className="text-hint mb-16">{t('complete_steps_earn')}</p>

      <div className="card mb-16">
        <div className="flex justify-between items-center">
          <span style={{ fontWeight: 600 }}>{t('progress')}</span>
          <span className="text-accent" style={{ fontWeight: 700 }}>{data?.current_step || 1} / 5</span>
        </div>
        <div className="progress-bar mt-8">
          <div className="progress-bar-fill" style={{ width: `${((data?.current_step - 1) / 5) * 100}%`, background: 'var(--button-color)' }} />
        </div>
        <div className="text-hint mt-8">
          {t('total_earn')}: {data?.total_reward || 0} AIS
          {data?.completed && ` + ${data?.bonus_reward || 25} AIS 🎉`}
        </div>
      </div>

      <div className="flex flex-col gap-8">
        {(data?.steps || []).map((step) => (
          <OnboardingStep key={step.step} step={step} isCurrent={step.step === data?.current_step} />
        ))}
      </div>

      {data?.completed && (
        <div className="card text-center mt-16" style={{ background: 'var(--button-color)', color: 'var(--button-text-color)' }}>
          🎉 {t('onboarding_complete')}
        </div>
      )}
    </div>
  );
}
