import { useState, useCallback } from 'react';
import { useLang } from '../contexts/LangContext';
import useExchange from '../hooks/useExchange';
import SkeletonLoader from '../components/SkeletonLoader';
import TickerBar from '../components/exchange/TickerBar';
import PriceChart from '../components/exchange/PriceChart';
import OrderBookPanel from '../components/exchange/OrderBookPanel';
import TradeForm from '../components/exchange/TradeForm';
import BalanceDisplay from '../components/exchange/BalanceDisplay';
import RecentTrades from '../components/exchange/RecentTrades';
import MyOpenOrders from '../components/exchange/MyOpenOrders';
import OrderHistory from '../components/exchange/OrderHistory';

export default function Exchange() {
  const { t } = useLang();
  const {
    ticker, orderBook, recentTrades, candles, openOrders,
    orderHistory, loading, submitting,
    fetchCandles, placeOrder, cancelOrder,
    fetchOrderHistory,
  } = useExchange();

  const [selectedPrice, setSelectedPrice] = useState(null);
  const [view, setView] = useState('book'); // 'book' | 'trades'

  const handlePriceClick = useCallback((price) => {
    setSelectedPrice(price);
  }, []);

  const handleIntervalChange = useCallback((iv) => {
    fetchCandles(iv);
  }, [fetchCandles]);

  if (loading) {
    return (
      <div className="page">
        <SkeletonLoader lines={6} height={20} />
      </div>
    );
  }

  return (
    <div className="page" style={{ paddingBottom: 80 }}>
      <TickerBar ticker={ticker} />
      <BalanceDisplay />
      <PriceChart candles={candles} onIntervalChange={handleIntervalChange} />

      {/* Toggle: Order Book / Recent Trades */}
      <div className="tab-bar" style={{ marginBottom: 0 }}>
        <button
          className={view === 'book' ? 'active' : ''}
          onClick={() => setView('book')}
        >
          {t('order_book') || 'Order Book'}
        </button>
        <button
          className={view === 'trades' ? 'active' : ''}
          onClick={() => setView('trades')}
        >
          {t('recent_trades') || 'Savdolar'}
        </button>
      </div>

      {view === 'book'
        ? <OrderBookPanel orderBook={orderBook} onPriceClick={handlePriceClick} />
        : <RecentTrades trades={recentTrades} />
      }

      <TradeForm
        onSubmit={placeOrder}
        submitting={submitting}
        selectedPrice={selectedPrice}
      />

      <MyOpenOrders orders={openOrders} onCancel={cancelOrder} />
      <OrderHistory orders={orderHistory} onFetch={fetchOrderHistory} />
    </div>
  );
}
