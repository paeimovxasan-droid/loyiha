import { useState, useEffect, useCallback } from 'react';
import client from '../api/client';
import { useLang } from '../contexts/LangContext';
import PullToRefresh from '../components/PullToRefresh';
import SkeletonLoader from '../components/SkeletonLoader';
import SocialProofToast from '../components/SocialProofToast';

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { t } = useLang();

  const fetchData = useCallback(async () => {
    try {
      const res = await client.get('/dashboard');
      if (res.data?.success) setData(res.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="page"><SkeletonLoader lines={6} height={20} /></div>;

  return (
    <PullToRefresh onRefresh={fetchData}>
      <div className="page">
        <div className="card">
          <div className="grid-2">
            <div>
              <div className="stat-value">💵 {Number(data?.balance || 0).toLocaleString()}</div>
              <div className="stat-label">UZS {t('balance')}</div>
            </div>
            <div>
              <div className="stat-value">🪙 {Number(data?.ais_balance || 0).toFixed(2)}</div>
              <div className="stat-label">AIS {t('balance')}</div>
            </div>
          </div>
        </div>

        <div className="grid-2">
          <div className="card">
            <div className="stat-value">{Number(data?.total_earn || 0).toLocaleString()}</div>
            <div className="stat-label">{t('total_earn')}</div>
          </div>
          <div className="card">
            <div className="stat-value">{data?.referrals_count || 0}</div>
            <div className="stat-label">{t('referrals')}</div>
          </div>
        </div>

        {data?.level && (
          <div className="card">
            <div className="flex justify-between items-center mb-8">
              <span style={{ fontWeight: 600 }}>🏅 {data.level.title}</span>
              <span className="badge" style={{ background: data.level.badge_color, color: '#fff' }}>
                Lv. {data.level.level}
              </span>
            </div>
            <div className="progress-bar">
              <div className="progress-bar-fill" style={{ width: `${data.level.progress_percent}%`, background: data.level.badge_color }} />
            </div>
            <div className="text-hint mt-8">{data.level.current_xp} / {data.level.next_level_xp} XP</div>
          </div>
        )}

        {data?.active_packages?.length > 0 && (
          <div>
            <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '8px' }}>{t('active_packages')}</h3>
            {data.active_packages.map((pkg, i) => (
              <div key={i} className="card flex justify-between items-center">
                <div>
                  <div style={{ fontWeight: 600 }}>{pkg.name}</div>
                  <div className="text-hint">{pkg.started_at} — {pkg.expires_at}</div>
                </div>
                <div className="text-accent" style={{ fontWeight: 600 }}>{Number(pkg.price).toLocaleString()}</div>
              </div>
            ))}
          </div>
        )}

        {data?.recent_transactions?.length > 0 && (
          <div>
            <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '8px' }}>{t('recent_transactions')}</h3>
            {data.recent_transactions.map((tx, i) => (
              <div key={i} className="list-item justify-between">
                <div>
                  <div style={{ fontSize: '14px' }}>{tx.description || tx.type}</div>
                  <div className="text-hint">{new Date(tx.created_at).toLocaleDateString()}</div>
                </div>
                <div style={{ fontWeight: 600, color: tx.direction === 'credit' ? '#34d399' : 'var(--destructive)' }}>
                  {tx.direction === 'credit' ? '+' : '-'}{Number(tx.amount).toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <SocialProofToast />
    </PullToRefresh>
  );
}
