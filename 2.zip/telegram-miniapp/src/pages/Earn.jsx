import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import client from '../api/client';
import { useLang } from '../contexts/LangContext';
import useHaptic from '../hooks/useHaptic';
import SkeletonLoader from '../components/SkeletonLoader';

export default function Earn() {
  const [tab, setTab] = useState('packages');
  const [packages, setPackages] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [funds, setFunds] = useState(null);
  const [draws, setDraws] = useState(null);
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState(null);
  const { t } = useLang();
  const { impactOccurred, notificationOccurred } = useHaptic();
  const navigate = useNavigate();

  const fetchTab = useCallback(async () => {
    setLoading(true); setMsg(null);
    try {
      if (tab === 'packages') {
        const res = await client.get('/packages');
        if (res.data?.success) setPackages(res.data.data.packages || []);
      } else if (tab === 'tasks') {
        const res = await client.get('/tasks');
        if (res.data?.success) setTasks(res.data.data.tasks || []);
      } else if (tab === 'funds') {
        const res = await client.get('/funds');
        if (res.data?.success) setFunds(res.data.data);
      } else if (tab === 'lucky_draw') {
        const res = await client.get('/lucky-draw');
        if (res.data?.success) setDraws(res.data.data);
      }
    } catch {} finally { setLoading(false); }
  }, [tab]);

  useEffect(() => { fetchTab(); }, [fetchTab]);

  const buyPackage = async (id) => {
    try {
      const res = await client.post(`/packages/${id}/buy`);
      notificationOccurred('success');
      setMsg({ type: 'success', text: res.data?.message || t('success') });
      fetchTab();
    } catch (err) {
      notificationOccurred('error');
      setMsg({ type: 'error', text: err.response?.data?.message || t('error') });
    }
  };

  return (
    <div className="page">
      <div className="tab-bar">
        {['packages', 'tasks', 'funds', 'lucky_draw'].map((k) => (
          <button key={k} className={tab === k ? 'active' : ''} onClick={() => { impactOccurred('light'); setTab(k); }}>
            {t(k)}
          </button>
        ))}
      </div>

      {msg && <div className={`card ${msg.type === 'error' ? 'text-destructive' : 'text-accent'}`}>{msg.text}</div>}

      {loading ? <SkeletonLoader lines={4} /> : (
        <>
          {tab === 'packages' && packages.map((pkg) => (
            <div key={pkg.id} className="card">
              <div className="flex justify-between items-center mb-8">
                <div style={{ fontWeight: 600 }}>{pkg.name}</div>
                <div className="text-accent" style={{ fontWeight: 700 }}>{Number(pkg.price).toLocaleString()} UZS</div>
              </div>
              <div className="text-hint mb-8">📈 Kunlik: {Number(pkg.daily_profit).toLocaleString()} UZS · ⏱ {pkg.duration_days} kun</div>
              <button className="btn btn-primary" onClick={() => buyPackage(pkg.id)}>📦 {t('buy')}</button>
            </div>
          ))}

          {tab === 'tasks' && tasks.map((task) => (
            <div key={task.id} className="card">
              <div style={{ fontWeight: 600 }}>{task.title}</div>
              <div className="text-hint mb-8">{task.description}</div>
              <div className="flex justify-between items-center">
                <span className="text-accent">💰 {Number(task.reward).toLocaleString()} UZS</span>
                <span className="badge" style={{ background: task.status === 'approved' ? '#34d399' : task.status === 'pending' ? '#fbbf24' : 'var(--secondary-bg)', color: '#fff' }}>
                  {t(task.status === 'not_submitted' ? 'submit' : task.status)}
                </span>
              </div>
            </div>
          ))}

          {tab === 'funds' && funds?.funds?.map((fund) => (
            <div key={fund.id} className="card">
              <div style={{ fontWeight: 600 }}>{fund.name}</div>
              <div className="text-hint mb-8">📊 {fund.commission_percent}% · ⏱ {fund.validity_days} kun · Min: {Number(fund.min_invest).toLocaleString()}</div>
              <button className="btn btn-primary" onClick={() => setMsg({ type: 'info', text: 'Investitsiya sahifasiga o\'ting' })}>{t('invest')}</button>
            </div>
          ))}

          {tab === 'lucky_draw' && draws?.draws?.map((draw) => (
            <div key={draw.id} className="card">
              <div style={{ fontWeight: 600 }}>🎰 {draw.name}</div>
              <div className="text-hint mb-8">🎫 {Number(draw.entry_fee).toLocaleString()} UZS · 🏆 {Number(draw.prize_amount).toLocaleString()} UZS</div>
              <div className="text-hint mb-8">Sotilgan: {draw.tickets_sold}/{draw.max_tickets || '∞'}</div>
            </div>
          ))}
        </>
      )}

      <div style={{ marginTop: '16px' }}>
        <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '8px' }}>🚀 Marketing</h3>
        {[
          { icon: '🎡', key: 'spin_wheel', path: '/spin-wheel' },
          { icon: '🏆', key: 'invite_challenge', path: '/invite-challenge' },
          { icon: '📤', key: 'share', path: '/share' },
          { icon: '🏅', key: 'competitions', path: '/competitions' },
          { icon: '🎪', key: 'events', path: '/events' },
          { icon: '📋', key: 'onboarding', path: '/onboarding' },
          { icon: '🌳', key: 'referral_tree', path: '/referral-tree' },
          { icon: '👑', key: 'vip_status', path: '/vip' },
          { icon: '🏅', key: 'badges', path: '/badges' },
        ].map((item) => (
          <div key={item.path} className="card" onClick={() => { impactOccurred('light'); navigate(item.path); }} style={{ cursor: 'pointer' }}>
            <div className="flex items-center gap-8">
              <span style={{ fontSize: '24px' }}>{item.icon}</span>
              <span style={{ fontWeight: 600 }}>{t(item.key)}</span>
              <span style={{ marginLeft: 'auto', color: 'var(--hint-color)' }}>→</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
