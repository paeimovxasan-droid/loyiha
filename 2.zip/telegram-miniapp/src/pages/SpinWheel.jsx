import { useEffect, useState } from 'react';
import { useLang } from '../contexts/LangContext';
import useHaptic from '../hooks/useHaptic';
import useSpinWheel from '../hooks/useSpinWheel';
import SpinWheelCanvas from '../components/SpinWheelCanvas';
import SkeletonLoader from '../components/SkeletonLoader';

export default function SpinWheel() {
  const { t } = useLang();
  const { notificationOccurred } = useHaptic();
  const { data, loading, spinning, result, fetch, doSpin } = useSpinWheel();
  const [animating, setAnimating] = useState(false);
  const [msg, setMsg] = useState(null);

  useEffect(() => { fetch(); }, [fetch]);

  const handleSpin = async () => {
    setMsg(null);
    try {
      setAnimating(true);
      await doSpin();
    } catch (err) {
      setAnimating(false);
      notificationOccurred('error');
      setMsg({ type: 'error', text: err.response?.data?.message || t('error') });
    }
  };

  const handleFinish = () => {
    setAnimating(false);
    if (result) {
      notificationOccurred('success');
      setMsg({ type: 'success', text: `🎉 ${result.prize_type}: ${result.prize_value}` });
    }
  };

  if (loading) return <div className="page"><SkeletonLoader lines={5} /></div>;

  const prizes = (data?.prizes || []).map((p) => ({
    label: p.label || `${p.type} ${p.value}`,
    color: p.color,
  }));

  return (
    <div className="page">
      <h2 style={{ fontSize: '20px', fontWeight: 700, textAlign: 'center', marginBottom: '16px' }}>🎡 {t('spin_wheel')}</h2>

      <SpinWheelCanvas prizes={prizes} spinning={animating} onFinish={handleFinish} />

      {msg && <div className={`card mt-16 ${msg.type === 'error' ? 'text-destructive' : 'text-accent'}`} style={{ textAlign: 'center' }}>{msg.text}</div>}

      <button
        className="btn btn-primary mt-16"
        disabled={!data?.can_spin || animating}
        onClick={handleSpin}
        style={{ opacity: (!data?.can_spin || animating) ? 0.5 : 1 }}
      >
        {animating ? '⏳...' : data?.can_spin ? `🎰 ${t('spin')}` : `⏳ ${data?.next_spin_at || ''}`}
      </button>

      {data?.history?.length > 0 && (
        <div className="mt-16">
          <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '8px' }}>{t('history')}</h3>
          {data.history.map((h, i) => (
            <div key={i} className="list-item justify-between">
              <span>{h.prize_type}: {h.prize_value}</span>
              <span className="text-hint">{h.spun_at}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
