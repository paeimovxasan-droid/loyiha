import { useState, useEffect, useCallback } from 'react';
import { getEvents } from '../api/client';
import { useLang } from '../contexts/LangContext';
import { useNavigate } from 'react-router-dom';
import SkeletonLoader from '../components/SkeletonLoader';
import EventBanner from '../components/EventBanner';

export default function Events() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const { t } = useLang();
  const navigate = useNavigate();

  const fetchData = useCallback(async () => {
    try {
      const res = await getEvents();
      if (res.data?.success) setEvents(res.data.data?.events || []);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="page"><SkeletonLoader lines={4} /></div>;

  return (
    <div className="page">
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '16px' }}>🎪 {t('events')}</h2>
      {events.length === 0 ? (
        <div className="card text-center text-hint">{t('no_active_events')}</div>
      ) : (
        <div className="flex flex-col gap-12">
          {events.map((ev) => (
            <EventBanner key={ev.id} event={ev} onClick={() => navigate(`/events/${ev.id}`)} />
          ))}
        </div>
      )}
    </div>
  );
}
