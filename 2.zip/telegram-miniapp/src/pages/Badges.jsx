import { useState, useEffect, useCallback } from 'react';
import { getBadges } from '../api/client';
import { useLang } from '../contexts/LangContext';
import SkeletonLoader from '../components/SkeletonLoader';
import BadgeCard from '../components/BadgeCard';

export default function Badges() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { t } = useLang();

  const fetchData = useCallback(async () => {
    try {
      const res = await getBadges();
      if (res.data?.success) setData(res.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="page"><SkeletonLoader lines={4} /></div>;

  const earnedIds = new Set((data?.badges || []).map((b) => b.badge_config_id));

  return (
    <div className="page">
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '16px' }}>🏅 {t('badges')}</h2>
      <div className="grid-2">
        {(data?.available_badges || []).map((b) => {
          const earned = earnedIds.has(b.id);
          const userBadge = earned ? data.badges.find((ub) => ub.badge_config_id === b.id) : null;
          return <BadgeCard key={b.id} badge={{ ...b, awarded_at: userBadge?.awarded_at }} earned={earned} />;
        })}
      </div>
    </div>
  );
}
