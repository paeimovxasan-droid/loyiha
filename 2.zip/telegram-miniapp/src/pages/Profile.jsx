import { useState, useEffect, useCallback } from 'react';
import client from '../api/client';
import { useLang } from '../contexts/LangContext';
import useAuth from '../hooks/useAuth';
import useHaptic from '../hooks/useHaptic';
import SkeletonLoader from '../components/SkeletonLoader';
import QrCodeDisplay from '../components/QrCodeDisplay';
import PromoCodeInput from '../components/PromoCodeInput';

export default function Profile() {
  const { user, refreshUser } = useAuth();
  const [profile, setProfile] = useState(null);
  const [kyc, setKyc] = useState(null);
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({});
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(true);
  const { locale, setLocale, t } = useLang();
  const { impactOccurred, notificationOccurred } = useHaptic();

  const fetchData = useCallback(async () => {
    try {
      const [pRes, kRes] = await Promise.all([
        client.get('/profile'),
        client.get('/kyc/status'),
      ]);
      if (pRes.data?.success) { setProfile(pRes.data.data); setForm(pRes.data.data); }
      if (kRes.data?.success) setKyc(kRes.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleCheckIn = async () => {
    setMsg(null);
    try {
      const res = await client.post('/checkin');
      notificationOccurred('success');
      setMsg({ type: 'success', text: res.data?.message || t('success') });
    } catch (err) {
      notificationOccurred('error');
      setMsg({ type: 'error', text: err.response?.data?.message || t('error') });
    }
  };

  const handleSave = async () => {
    setMsg(null);
    try {
      await client.put('/profile', { name: form.name, username: form.username, email: form.email, phone: form.phone });
      notificationOccurred('success');
      setMsg({ type: 'success', text: t('success') });
      setEditing(false);
      refreshUser();
      fetchData();
    } catch (err) {
      notificationOccurred('error');
      setMsg({ type: 'error', text: err.response?.data?.message || t('error') });
    }
  };

  const shareReferral = () => {
    const tg = window.Telegram?.WebApp;
    const botUsername = 'aisoqqa_bot';
    const link = `https://t.me/${botUsername}?start=ref_${profile?.username}`;
    if (tg?.openTelegramLink) {
      tg.openTelegramLink(`https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent('AISOQQA platformasiga qo\'shiling!')}`);
    }
  };

  if (loading) return <div className="page"><SkeletonLoader lines={6} /></div>;

  return (
    <div className="page">
      <div className="card text-center">
        <div style={{ fontSize: '48px', marginBottom: '8px' }}>👤</div>
        <div style={{ fontSize: '18px', fontWeight: 700 }}>{profile?.name}</div>
        <div className="text-hint">@{profile?.username}</div>
      </div>

      {msg && <div className={`card ${msg.type === 'error' ? 'text-destructive' : 'text-accent'}`}>{msg.text}</div>}

      <button className="btn btn-primary mb-16" onClick={handleCheckIn}>
        ✅ {t('checkin')}
      </button>

      <div className="card">
        <div className="flex justify-between items-center mb-8">
          <span style={{ fontWeight: 600 }}>{t('kyc_status')}</span>
          <span className="badge" style={{
            background: kyc?.status === 'verified' ? '#34d399' : kyc?.status === 'rejected' ? 'var(--destructive)' : '#fbbf24',
            color: '#fff',
          }}>
            {t(kyc?.status || 'none')}
          </span>
        </div>
      </div>

      <div className="card">
        <div className="flex justify-between items-center mb-8">
          <span style={{ fontWeight: 600 }}>{t('profile')}</span>
          <button style={{ background: 'none', border: 'none', color: 'var(--link-color)', cursor: 'pointer' }}
            onClick={() => { impactOccurred('light'); setEditing(!editing); }}>
            {editing ? t('cancel') : '✏️'}
          </button>
        </div>
        {editing ? (
          <div className="flex flex-col gap-8">
            <input placeholder="Ism" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input placeholder="Username" value={form.username || ''} onChange={(e) => setForm({ ...form, username: e.target.value })} />
            <input placeholder="Email" value={form.email || ''} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            <input placeholder="Telefon" value={form.phone || ''} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            <button className="btn btn-primary" onClick={handleSave}>{t('save')}</button>
          </div>
        ) : (
          <div className="flex flex-col gap-8">
            <div className="flex justify-between"><span className="text-hint">Email</span><span>{profile?.email || '—'}</span></div>
            <div className="flex justify-between"><span className="text-hint">Telefon</span><span>{profile?.phone || '—'}</span></div>
            <div className="flex justify-between"><span className="text-hint">{t('level')}</span><span>{profile?.level || 0}</span></div>
          </div>
        )}
      </div>

      <div className="card">
        <div style={{ fontWeight: 600, marginBottom: '8px' }}>{t('referral_link')}</div>
        <button className="btn btn-secondary" onClick={shareReferral}>📤 {t('share')}</button>
      </div>

      <div className="card">
        <div style={{ fontWeight: 600, marginBottom: '8px' }}>{t('language')}</div>
        <div className="flex gap-8">
          {['uz', 'ru', 'en'].map((lang) => (
            <button key={lang} className={`btn ${locale === lang ? 'btn-primary' : 'btn-secondary'}`}
              style={{ flex: 1 }} onClick={() => { impactOccurred('light'); setLocale(lang); }}>
              {lang.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      <PromoCodeInput />
      <QrCodeDisplay />
    </div>
  );
}
