import { useState, useEffect, useCallback } from 'react';
import { getShare } from '../api/client';
import { useLang } from '../contexts/LangContext';
import useHaptic from '../hooks/useHaptic';
import SkeletonLoader from '../components/SkeletonLoader';

export default function Share() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { t } = useLang();
  const { notificationOccurred } = useHaptic();

  const fetchData = useCallback(async () => {
    try {
      const res = await getShare();
      if (res.data?.success) setData(res.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleShare = () => {
    const tg = window.Telegram?.WebApp;
    if (tg?.openTelegramLink && data?.share_link) {
      tg.openTelegramLink(`https://t.me/share/url?url=${encodeURIComponent(data.share_link)}&text=${encodeURIComponent('AISOQQA platformasiga qo\'shiling!')}`);
      notificationOccurred('success');
    }
  };

  if (loading) return <div className="page"><SkeletonLoader lines={4} /></div>;

  return (
    <div className="page">
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '16px' }}>📤 {t('share')}</h2>

      <div className="grid-2">
        <div className="card text-center">
          <div className="stat-value">{data?.total_clicks || 0}</div>
          <div className="stat-label">{t('total_clicks')}</div>
        </div>
        <div className="card text-center">
          <div className="stat-value">{data?.today_clicks || 0}</div>
          <div className="stat-label">{t('today')}</div>
        </div>
      </div>

      <div className="card">
        <div className="flex justify-between items-center">
          <span style={{ fontWeight: 600 }}>{t('total_earn')}</span>
          <span className="text-accent" style={{ fontWeight: 700 }}>{data?.total_earned_ais || 0} AIS</span>
        </div>
        <div className="text-hint mt-8">{t('daily_limit')}: {data?.daily_limit || 5} AIS</div>
      </div>

      {data?.share_link && (
        <div className="card">
          <div className="text-hint mb-8">{t('referral_link')}</div>
          <div style={{ fontSize: '13px', wordBreak: 'break-all', background: 'var(--secondary-bg)', padding: '8px', borderRadius: '8px' }}>
            {data.share_link}
          </div>
        </div>
      )}

      <button className="btn btn-primary mt-8" onClick={handleShare}>📤 {t('share')}</button>
    </div>
  );
}
