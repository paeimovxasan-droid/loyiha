import { useState, useEffect } from 'react';
import client from '../api/client';
import { useLang } from '../contexts/LangContext';
import SkeletonLoader from '../components/SkeletonLoader';

export default function Leaderboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { t } = useLang();

  useEffect(() => {
    client.get('/level/leaderboard').then((res) => {
      if (res.data?.success) setData(res.data.data);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="page"><SkeletonLoader lines={10} /></div>;

  const medals = ['🥇', '🥈', '🥉'];

  return (
    <div className="page">
      <div className="page-title">🏆 {t('leaderboard')}</div>

      {data?.user_rank && (
        <div className="card text-center mb-16">
          <div className="text-hint">Sizning o'rningiz</div>
          <div className="stat-value">#{data.user_rank}</div>
        </div>
      )}

      {data?.top_users?.map((u, i) => (
        <div key={i} className="list-item justify-between">
          <div className="flex items-center gap-12">
            <span style={{ fontSize: '20px', width: '30px', textAlign: 'center' }}>{medals[i] || `#${i + 1}`}</span>
            <div>
              <div style={{ fontWeight: 600 }}>{u.name}</div>
              <div className="text-hint">{u.title} · Lv.{u.level}</div>
            </div>
          </div>
          <div style={{ fontWeight: 600, color: 'var(--accent-text)' }}>{u.total_xp} XP</div>
        </div>
      ))}
    </div>
  );
}
