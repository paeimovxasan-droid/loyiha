// ─── Konstantalar ──────────────────────────────────────────────────────────
const CHALLENGE_LABELS = {
  turn_left:  { uz: '⬅️ Chapga buring',    icon: '⬅️' },
  turn_right: { uz: '➡️ O\'ngga buring',   icon: '➡️' },
  blink:      { uz: '👁️ Ko\'z qisinglar',  icon: '👁️' },
  smile:      { uz: '😊 Jilmaying',        icon: '😊' },
  nod:        { uz: '⬆️ Bosh irg\'ang',    icon: '⬆️' },
};

const STEP = {
  INTRO:      'intro',
  LIVENESS:   'liveness',
  SELFIE:     'selfie',
  DOCUMENT:   'document',
  REVIEW:     'review',
  UPLOADING:  'uploading',
  SUCCESS:    'success',
  ERROR:      'error',
};

// ─── face-api.js CDN dan yuklanadi (bundle'ga qo'shmaslik uchun) ───────────
let faceApiLoaded = false;
async function loadFaceApi() {
  if (faceApiLoaded || window.faceapi) { faceApiLoaded = true; return; }
  await new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/face-api.js@0.22.2/dist/face-api.min.js';
    s.onload = resolve;
    s.onerror = reject;
    document.head.appendChild(s);
  });
  // Modellarni yuklash (CDN dan)
  const MODEL_URL = 'https://cdn.jsdelivr.net/npm/@vladmandic/face-api/model';
  await Promise.all([
    window.faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL),
    window.faceapi.nets.faceLandmark68TinyNet.loadFromUri(MODEL_URL),
    window.faceapi.nets.faceExpressionNet.loadFromUri(MODEL_URL),
  ]);
  faceApiLoaded = true;
}

// ─── Asosiy komponent ──────────────────────────────────────────────────────
export default function FaceKyc({ onComplete }) {
  const [step, setStep]               = useState(STEP.INTRO);
  const [session, setSession]         = useState(null);       // { session_id, challenge }
  const [challengeIdx, setChallengeIdx] = useState(0);
  const [livenessScore, setLivenessScore] = useState(0);
  const [livenessPassed, setLivenessPassed] = useState(false);
  const [selfieBlob, setSelfieBlob]   = useState(null);
  const [selfieUrl, setSelfieUrl]     = useState(null);
  const [docFrontBlob, setDocFrontBlob] = useState(null);
  const [docFrontUrl, setDocFrontUrl] = useState(null);
  const [docBackBlob, setDocBackBlob] = useState(null);
  const [docBackUrl, setDocBackUrl]   = useState(null);
  const [docType, setDocType]         = useState('passport');
  const [error, setError]             = useState('');
  const [loading, setLoading]         = useState(false);
  const [faceApiReady, setFaceApiReady] = useState(false);
  const [detectionMsg, setDetectionMsg] = useState('Yuzingizni kameraga qarating...');
  const [challengeDone, setChallengeDone] = useState([]);

  const videoRef    = useRef(null);
  const canvasRef   = useRef(null);
  const streamRef   = useRef(null);
  const detectionInterval = useRef(null);
  const docInputRef = useRef(null);
  const docBackInputRef = useRef(null);

  // ── Kamerani yoqish ──────────────────────────────────────────────────────
  const startCamera = useCallback(async (facingMode = 'user') => {
    try {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode, width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
    } catch (e) {
      setError('Kameraga ruxsat berilmadi. Brauzer sozlamalarini tekshiring.');
    }
  }, []);

  // ── Kamerani o'chirish ───────────────────────────────────────────────────
  const stopCamera = useCallback(() => {
    if (detectionInterval.current) clearInterval(detectionInterval.current);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
  }, []);

  // ── Cleanup ──────────────────────────────────────────────────────────────
  useEffect(() => () => stopCamera(), [stopCamera]);

  // ── Sessiya boshlash ─────────────────────────────────────────────────────
  const startSession = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await api.post('/kyc/face/start');
      setSession(res.data.data);
      setChallengeIdx(0);
      setChallengeDone([]);
      setLivenessPassed(false);
      setLivenessScore(0);

      // face-api.js yuklash
      setDetectionMsg('Modellar yuklanmoqda...');
      await loadFaceApi();
      setFaceApiReady(true);

      setStep(STEP.LIVENESS);
      await startCamera('user');
    } catch (e) {
      setError(e.response?.data?.message || 'Sessiya boshlanmadi. Qayta urinib ko\'ring.');
    } finally {
      setLoading(false);
    }
  };

  // ── Real-time yuz aniqlash (liveness) ────────────────────────────────────
  useEffect(() => {
    if (step !== STEP.LIVENESS || !faceApiReady || !videoRef.current) return;

    const challenge = session?.challenge ?? [];
    let currentIdx  = challengeIdx;
    let done        = [...challengeDone];
    let score       = livenessScore;

    detectionInterval.current = setInterval(async () => {
      if (!videoRef.current || videoRef.current.readyState < 2) return;

      const detections = await window.faceapi
        .detectSingleFace(videoRef.current, new window.faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks(true)
        .withFaceExpressions();

      if (!detections) {
        setDetectionMsg('Yuzingizni kameraga qarating...');
        return;
      }

      // Liveness score (detection confidence)
      const conf = detections.detection.score;
      score = Math.max(score, conf);
      setLivenessScore(score);

      const currentAction = challenge[currentIdx];
      if (!currentAction) return;

      const label = CHALLENGE_LABELS[currentAction];
      setDetectionMsg(`${label.icon} ${label.uz}`);

      // Harakat aniqlash
      const detected = detectAction(currentAction, detections);

      if (detected) {
        done = [...done, currentAction];
        setChallengeDone([...done]);
        currentIdx++;
        setChallengeIdx(currentIdx);

        if (currentIdx >= challenge.length) {
          // Barcha harakatlar bajarildi
          clearInterval(detectionInterval.current);
          setLivenessPassed(true);
          setDetectionMsg('✅ Liveness tekshiruvi o\'tdi!');

          // Selfie olish
          setTimeout(() => captureAndProceed(score), 800);
        }
      }
    }, 400);

    return () => clearInterval(detectionInterval.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step, faceApiReady]);

  // ── Harakat aniqlash logikasi ─────────────────────────────────────────────
  function detectAction(action, detections) {
    const landmarks = detections.landmarks;
    const expressions = detections.expressions;

    switch (action) {
      case 'smile':
        return (expressions.happy ?? 0) > 0.7;

      case 'blink': {
        // Ko'z qisish: ko'z ochiqlik nisbati (EAR) past bo'lsa
        const leftEye  = landmarks.getLeftEye();
        const rightEye = landmarks.getRightEye();
        const leftEAR  = eyeAspectRatio(leftEye);
        const rightEAR = eyeAspectRatio(rightEye);
        return (leftEAR + rightEAR) / 2 < 0.2;
      }

      case 'turn_left': {
        // Burun uchi chap tomonga siljigan
        const nose = landmarks.getNose();
        const jaw  = landmarks.getJawOutline();
        const noseTip = nose[3];
        const jawCenter = jaw[8];
        return noseTip.x < jawCenter.x - 15;
      }

      case 'turn_right': {
        const nose = landmarks.getNose();
        const jaw  = landmarks.getJawOutline();
        const noseTip = nose[3];
        const jawCenter = jaw[8];
        return noseTip.x > jawCenter.x + 15;
      }

      case 'nod': {
        // Bosh irg'ash: burun uchi pastga tushgan
        const nose = landmarks.getNose();
        const noseTip = nose[3];
        const noseBridge = nose[0];
        return noseTip.y - noseBridge.y > 60;
      }

      default:
        return false;
    }
  }

  // Ko'z ochiqlik nisbati (Eye Aspect Ratio)
  function eyeAspectRatio(eye) {
    const A = dist(eye[1], eye[5]);
    const B = dist(eye[2], eye[4]);
    const C = dist(eye[0], eye[3]);
    return (A + B) / (2.0 * C);
  }

  function dist(p1, p2) {
    return Math.sqrt(Math.pow(p1.x - p2.x, 2) + Math.pow(p1.y - p2.y, 2));
  }

  // ── Selfie olish ─────────────────────────────────────────────────────────
  const captureAndProceed = useCallback((score) => {
    if (!videoRef.current || !canvasRef.current) return;

    const video  = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width  = video.videoWidth  || 640;
    canvas.height = video.videoHeight || 480;

    const ctx = canvas.getContext('2d');
    // Selfie kamera mirror'ini to'g'rilash
    ctx.translate(canvas.width, 0);
    ctx.scale(-1, 1);
    ctx.drawImage(video, 0, 0);
    ctx.setTransform(1, 0, 0, 1, 0, 0);

    canvas.toBlob(blob => {
      setSelfieBlob(blob);
      setSelfieUrl(URL.createObjectURL(blob));
      stopCamera();
      setStep(STEP.SELFIE);
    }, 'image/jpeg', 0.92);
  }, [stopCamera]);

  // ── Hujjat rasmi tanlash ─────────────────────────────────────────────────
  const handleDocFront = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setDocFrontBlob(file);
    setDocFrontUrl(URL.createObjectURL(file));
  };

  const handleDocBack = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setDocBackBlob(file);
    setDocBackUrl(URL.createObjectURL(file));
  };

  // ── Yuborish ─────────────────────────────────────────────────────────────
  const handleSubmit = async () => {
    if (!selfieBlob || !docFrontBlob) {
      setError('Selfie va hujjat old tomoni rasmi kerak.');
      return;
    }

    setStep(STEP.UPLOADING);
    setError('');

    try {
      const formData = new FormData();
      formData.append('session_id',      session.session_id);
      formData.append('selfie',          selfieBlob, 'selfie.jpg');
      formData.append('document_front',  docFrontBlob, 'doc_front.jpg');
      if (docBackBlob) {
        formData.append('document_back', docBackBlob, 'doc_back.jpg');
      }
      formData.append('document_type',   docType);
      formData.append('liveness_passed', livenessPassed ? '1' : '0');
      formData.append('liveness_score',  livenessScore.toFixed(3));

      const res = await api.post('/kyc/face/submit', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        timeout: 60000,
      });

      setStep(STEP.SUCCESS);
      if (onComplete) onComplete(res.data.data);

    } catch (e) {
      setError(e.response?.data?.message || 'Yuborishda xato. Qayta urinib ko\'ring.');
      setStep(STEP.REVIEW);
    }
  };

  // ─────────────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────────────

  // Intro
  if (step === STEP.INTRO) {
    return (
      <div className="face-kyc-page">
        <div className="face-kyc-hero">
          <div className="face-kyc-icon">🤳</div>
          <h2>Face ID KYC</h2>
          <p>Shaxsingizni yuz orqali tasdiqlang. Jarayon 2-3 daqiqa oladi.</p>
        </div>

        <div className="face-kyc-steps">
          {[
            ['📸', 'Liveness tekshiruvi', 'Ko\'rsatilgan harakatlarni bajaring'],
            ['🪪', 'Hujjat rasmi', 'Pasport yoki ID karta rasmini yuklang'],
            ['✅', 'Tasdiqlash', '24 soat ichida natija bildiriladi'],
          ].map(([icon, title, desc]) => (
            <div key={title} className="face-kyc-step-item">
              <span className="face-kyc-step-icon">{icon}</span>
              <div>
                <div className="face-kyc-step-title">{title}</div>
                <div className="face-kyc-step-desc">{desc}</div>
              </div>
            </div>
          ))}
        </div>

        {error && <div className="face-kyc-error">{error}</div>}

        <button
          className="face-kyc-btn-primary"
          onClick={startSession}
          disabled={loading}
        >
          {loading ? '⏳ Yuklanmoqda...' : '🚀 Boshlash'}
        </button>
      </div>
    );
  }

  // Liveness
  if (step === STEP.LIVENESS) {
    const challenge = session?.challenge ?? [];
    const progress  = (challengeIdx / challenge.length) * 100;

    return (
      <div className="face-kyc-page">
        <h3 className="face-kyc-title">Liveness tekshiruvi</h3>

        {/* Kamera */}
        <div className="face-kyc-camera-wrap">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            muted
            className="face-kyc-video"
            style={{ transform: 'scaleX(-1)' }}
          />
          <canvas ref={canvasRef} style={{ display: 'none' }} />

          {/* Yuz doirasi overlay */}
          <div className="face-kyc-oval" />

          {/* Joriy ko'rsatma */}
          <div className="face-kyc-instruction">{detectionMsg}</div>
        </div>

        {/* Progress */}
        <div className="face-kyc-progress-bar">
          <div className="face-kyc-progress-fill" style={{ width: `${progress}%` }} />
        </div>

        {/* Challenge qadamlari */}
        <div className="face-kyc-challenges">
          {challenge.map((action, i) => (
            <div
              key={action}
              className={`face-kyc-challenge-chip ${
                challengeDone.includes(action) ? 'done' :
                i === challengeIdx ? 'active' : 'waiting'
              }`}
            >
              {CHALLENGE_LABELS[action]?.icon} {CHALLENGE_LABELS[action]?.uz}
            </div>
          ))}
        </div>

        {/* Liveness score */}
        <div className="face-kyc-score">
          Yuz aniqligi: {Math.round(livenessScore * 100)}%
        </div>
      </div>
    );
  }

  // Selfie ko'rish
  if (step === STEP.SELFIE) {
    return (
      <div className="face-kyc-page">
        <h3 className="face-kyc-title">Selfie tasdiqlash</h3>
        <p className="face-kyc-subtitle">Rasm aniq va yaxshi ko'rinishda bo'lishi kerak</p>

        <div className="face-kyc-preview-wrap">
          <img src={selfieUrl} alt="Selfie" className="face-kyc-preview-img" />
          <div className="face-kyc-preview-badge">✅ Liveness o'tdi</div>
        </div>

        <div className="face-kyc-btn-row">
          <button
            className="face-kyc-btn-outline"
            onClick={() => {
              setSelfieBlob(null);
              setSelfieUrl(null);
              setLivenessPassed(false);
              setLivenessScore(0);
              setChallengeIdx(0);
              setChallengeDone([]);
              startSession();
            }}
          >
            🔄 Qayta olish
          </button>
          <button
            className="face-kyc-btn-primary"
            onClick={() => setStep(STEP.DOCUMENT)}
          >
            Davom etish ➡️
          </button>
        </div>
      </div>
    );
  }

  // Hujjat rasmi
  if (step === STEP.DOCUMENT) {
    return (
      <div className="face-kyc-page">
        <h3 className="face-kyc-title">Hujjat rasmi</h3>

        {/* Hujjat turi */}
        <div className="face-kyc-doc-type-row">
          {[
            { value: 'passport', label: '📘 Pasport' },
            { value: 'id_card',  label: '🪪 ID karta' },
          ].map(opt => (
            <button
              key={opt.value}
              className={`face-kyc-doc-type-btn ${docType === opt.value ? 'active' : ''}`}
              onClick={() => setDocType(opt.value)}
            >
              {opt.label}
            </button>
          ))}
        </div>

        {/* Old tomoni */}
        <div className="face-kyc-upload-area" onClick={() => docInputRef.current?.click()}>
          {docFrontUrl ? (
            <img src={docFrontUrl} alt="Hujjat old" className="face-kyc-doc-preview" />
          ) : (
            <>
              <div className="face-kyc-upload-icon">📄</div>
              <div className="face-kyc-upload-label">Old tomoni (majburiy)</div>
              <div className="face-kyc-upload-hint">Barcha ma'lumotlar aniq ko'rinsin</div>
            </>
          )}
        </div>
        <input
          ref={docInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          style={{ display: 'none' }}
          onChange={handleDocFront}
        />

        {/* Orqa tomoni (ID karta uchun) */}
        {docType === 'id_card' && (
          <>
            <div
              className="face-kyc-upload-area"
              style={{ marginTop: 12 }}
              onClick={() => docBackInputRef.current?.click()}
            >
              {docBackUrl ? (
                <img src={docBackUrl} alt="Hujjat orqa" className="face-kyc-doc-preview" />
              ) : (
                <>
                  <div className="face-kyc-upload-icon">📄</div>
                  <div className="face-kyc-upload-label">Orqa tomoni (ixtiyoriy)</div>
                </>
              )}
            </div>
            <input
              ref={docBackInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              style={{ display: 'none' }}
              onChange={handleDocBack}
            />
          </>
        )}

        {error && <div className="face-kyc-error">{error}</div>}

        <button
          className="face-kyc-btn-primary"
          style={{ marginTop: 20 }}
          onClick={() => {
            if (!docFrontBlob) { setError('Hujjat old tomoni rasmini yuklang.'); return; }
            setError('');
            setStep(STEP.REVIEW);
          }}
          disabled={!docFrontBlob}
        >
          Ko'rib chiqish ➡️
        </button>
      </div>
    );
  }

  // Ko'rib chiqish
  if (step === STEP.REVIEW) {
    return (
      <div className="face-kyc-page">
        <h3 className="face-kyc-title">Ko'rib chiqish</h3>
        <p className="face-kyc-subtitle">Ma'lumotlar to'g'riligini tekshiring</p>

        <div className="face-kyc-review-grid">
          <div className="face-kyc-review-item">
            <div className="face-kyc-review-label">Selfie</div>
            <img src={selfieUrl} alt="Selfie" className="face-kyc-review-img" />
          </div>
          <div className="face-kyc-review-item">
            <div className="face-kyc-review-label">Hujjat (old)</div>
            <img src={docFrontUrl} alt="Hujjat" className="face-kyc-review-img" />
          </div>
        </div>

        <div className="face-kyc-review-info">
          <div>📋 Hujjat turi: <strong>{docType === 'passport' ? 'Pasport' : 'ID karta'}</strong></div>
          <div>🎯 Liveness: <strong>{Math.round(livenessScore * 100)}%</strong></div>
        </div>

        {error && <div className="face-kyc-error">{error}</div>}

        <div className="face-kyc-btn-row">
          <button
            className="face-kyc-btn-outline"
            onClick={() => setStep(STEP.DOCUMENT)}
          >
            ← Orqaga
          </button>
          <button
            className="face-kyc-btn-primary"
            onClick={handleSubmit}
          >
            📤 Yuborish
          </button>
        </div>
      </div>
    );
  }

  // Yuklanmoqda
  if (step === STEP.UPLOADING) {
    return (
      <div className="face-kyc-page face-kyc-center">
        <div className="face-kyc-spinner">⏳</div>
        <h3>Yuklanmoqda...</h3>
        <p>Ma'lumotlar yuborilmoqda. Iltimos, kuting.</p>
      </div>
    );
  }

  // Muvaffaqiyat
  if (step === STEP.SUCCESS) {
    return (
      <div className="face-kyc-page face-kyc-center">
        <div style={{ fontSize: 64, marginBottom: 16 }}>✅</div>
        <h3>Yuborildi!</h3>
        <p>Ma'lumotlaringiz qabul qilindi.<br />24 soat ichida natija bildiriladi.</p>
        <button
          className="face-kyc-btn-primary"
          style={{ marginTop: 24 }}
          onClick={() => onComplete?.()}
        >
          Bosh sahifaga qaytish
        </button>
      </div>
    );
  }

  return null;
}
