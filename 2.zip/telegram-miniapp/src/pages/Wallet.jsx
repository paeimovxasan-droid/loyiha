import { useState, useEffect, useCallback } from 'react';
import client from '../api/client';
import { useLang } from '../contexts/LangContext';
import useHaptic from '../hooks/useHaptic';
import PullToRefresh from '../components/PullToRefresh';
import SkeletonLoader from '../components/SkeletonLoader';

export default function Wallet() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('info');
  const [form, setForm] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState(null);
  const { t } = useLang();
  const { impactOccurred, notificationOccurred } = useHaptic();

  const fetchData = useCallback(async () => {
    try {
      const res = await client.get('/wallet');
      if (res.data?.success) setData(res.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleTransfer = async (e) => {
    e.preventDefault();
    setSubmitting(true); setMsg(null);
    try {
      const res = await client.post('/wallet/transfer', form);
      notificationOccurred('success');
      setMsg({ type: 'success', text: res.data?.message || t('success') });
      setForm({}); fetchData();
    } catch (err) {
      notificationOccurred('error');
      setMsg({ type: 'error', text: err.response?.data?.message || t('error') });
    } finally { setSubmitting(false); }
  };

  const handleConvert = async (e) => {
    e.preventDefault();
    setSubmitting(true); setMsg(null);
    try {
      const res = await client.post('/wallet/convert', form);
      notificationOccurred('success');
      setMsg({ type: 'success', text: res.data?.message || t('success') });
      setForm({}); fetchData();
    } catch (err) {
      notificationOccurred('error');
      setMsg({ type: 'error', text: err.response?.data?.message || t('error') });
    } finally { setSubmitting(false); }
  };

  if (loading) return <div className="page"><SkeletonLoader lines={5} /></div>;

  return (
    <PullToRefresh onRefresh={fetchData}>
      <div className="page">
        <div className="card text-center">
          <div style={{ fontSize: '28px', fontWeight: 700 }}>🪙 {Number(data?.wallet?.balance || 0).toFixed(4)}</div>
          <div className="text-hint">AIS</div>
          {data?.rate && <div className="text-hint mt-8">1 AIS = {Number(data.rate.buy_rate || 0).toLocaleString()} UZS</div>}
        </div>

        <div className="tab-bar">
          {['info', 'transfer', 'convert'].map((t2) => (
            <button key={t2} className={tab === t2 ? 'active' : ''} onClick={() => { impactOccurred('light'); setTab(t2); setMsg(null); }}>
              {t2 === 'info' ? '📊' : t2 === 'transfer' ? '💸' : '🔄'} {t(t2 === 'info' ? 'wallet' : t2)}
            </button>
          ))}
        </div>

        {msg && <div className={`card ${msg.type === 'error' ? 'text-destructive' : 'text-accent'}`}>{msg.text}</div>}

        {tab === 'info' && (
          <div>
            {data?.transfers?.length > 0 && data.transfers.map((tr, i) => (
              <div key={i} className="list-item justify-between">
                <div>
                  <div style={{ fontSize: '14px' }}>{tr.direction === 'sent' ? '↗️' : '↙️'} {tr.receiver || tr.sender}</div>
                  <div className="text-hint">{new Date(tr.created_at).toLocaleDateString()}</div>
                </div>
                <div style={{ fontWeight: 600 }}>{Number(tr.amount).toFixed(4)} AIS</div>
              </div>
            ))}
          </div>
        )}

        {tab === 'transfer' && (
          <form onSubmit={handleTransfer} className="flex flex-col gap-12">
            <input placeholder="Qabul qiluvchi (username/wallet)" value={form.receiver || ''} onChange={(e) => setForm({ ...form, receiver: e.target.value })} required />
            <input type="number" step="0.0001" placeholder={t('amount')} value={form.amount || ''} onChange={(e) => setForm({ ...form, amount: e.target.value })} required />
            <input placeholder="Izoh" value={form.note || ''} onChange={(e) => setForm({ ...form, note: e.target.value })} />
            <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? '...' : t('transfer')}</button>
          </form>
        )}

        {tab === 'convert' && (
          <form onSubmit={handleConvert} className="flex flex-col gap-12">
            <select value={form.direction || 'buy'} onChange={(e) => setForm({ ...form, direction: e.target.value })}>
              <option value="buy">UZS → AIS</option>
              <option value="sell">AIS → UZS</option>
            </select>
            <input type="number" step="0.01" placeholder={t('amount')} value={form.amount || ''} onChange={(e) => setForm({ ...form, amount: e.target.value })} required />
            <button type="submit" className="btn btn-primary" disabled={submitting}>{submitting ? '...' : t('convert')}</button>
          </form>
        )}
      </div>
    </PullToRefresh>
  );
}
