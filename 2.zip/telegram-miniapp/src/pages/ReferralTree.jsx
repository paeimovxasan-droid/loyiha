import { useState, useEffect, useCallback } from 'react';
import { getReferralTree } from '../api/client';
import { useLang } from '../contexts/LangContext';
import SkeletonLoader from '../components/SkeletonLoader';
import ReferralTreeView from '../components/ReferralTreeView';

export default function ReferralTree() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { t } = useLang();

  const fetchData = useCallback(async () => {
    try {
      const res = await getReferralTree();
      if (res.data?.success) setData(res.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="page"><SkeletonLoader lines={5} /></div>;

  return (
    <div className="page">
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '16px' }}>🌳 {t('referral_tree')}</h2>

      {data?.stats?.length > 0 && (
        <div className="grid-2 mb-16">
          {data.stats.map((s) => (
            <div key={s.level} className="card text-center">
              <div className="stat-value">{s.count}</div>
              <div className="stat-label">{t('level')} {s.level}</div>
              <div className="text-accent" style={{ fontSize: '12px', marginTop: '4px' }}>{Number(s.total_commission || 0).toLocaleString()} AIS</div>
            </div>
          ))}
        </div>
      )}

      <ReferralTreeView tree={data?.tree || []} />
    </div>
  );
}
