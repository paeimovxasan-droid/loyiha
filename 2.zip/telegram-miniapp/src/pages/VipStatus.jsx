import { useState, useEffect, useCallback } from 'react';
import { getVipStatus } from '../api/client';
import { useLang } from '../contexts/LangContext';
import SkeletonLoader from '../components/SkeletonLoader';
import VipProgressBar from '../components/VipProgressBar';

export default function VipStatus() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { t } = useLang();

  const fetchData = useCallback(async () => {
    try {
      const res = await getVipStatus();
      if (res.data?.success) setData(res.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="page"><SkeletonLoader lines={5} /></div>;

  return (
    <div className="page">
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '16px' }}>👑 {t('vip_status')}</h2>

      <VipProgressBar currentTier={data?.tier} nextTier={data?.next_tier} progress={data?.progress} />

      {data?.benefits && (
        <div className="card mt-8">
          <div style={{ fontWeight: 600, marginBottom: '8px' }}>🎁 {t('benefits')}</div>
          <div className="flex flex-col gap-8">
            {data.benefits.cashback_percent > 0 && (
              <div className="flex justify-between">
                <span className="text-hint">Cashback</span>
                <span className="text-accent" style={{ fontWeight: 600 }}>{data.benefits.cashback_percent}%</span>
              </div>
            )}
            {data.benefits.fee_discount > 0 && (
              <div className="flex justify-between">
                <span className="text-hint">{t('fee_discount')}</span>
                <span className="text-accent" style={{ fontWeight: 600 }}>{data.benefits.fee_discount}%</span>
              </div>
            )}
            {data.benefits.special_quests && (
              <div className="flex justify-between">
                <span className="text-hint">{t('special_quests')}</span>
                <span className="text-accent">✅</span>
              </div>
            )}
          </div>
        </div>
      )}

      {data?.history?.length > 0 && (
        <div className="mt-16">
          <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '8px' }}>{t('history')}</h3>
          {data.history.map((h, i) => (
            <div key={i} className="list-item justify-between">
              <div>
                <span style={{ textTransform: 'capitalize' }}>{h.from_tier} → {h.to_tier}</span>
                <div className="text-hint" style={{ fontSize: '11px' }}>{new Date(h.created_at).toLocaleDateString()}</div>
              </div>
              <span className="badge" style={{ background: h.direction === 'upgrade' ? '#34d399' : 'var(--destructive)', color: '#fff' }}>
                {h.direction === 'upgrade' ? '⬆️' : '⬇️'}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
