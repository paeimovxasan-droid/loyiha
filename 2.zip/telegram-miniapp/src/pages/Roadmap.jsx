import { useState, useEffect, useCallback } from 'react';
import { getRoadmap, voteRoadmap, notifyRoadmap } from '../api/client';
import SkeletonLoader from '../components/SkeletonLoader';

const FILTERS = [
  { key: '', label: 'Barchasi' },
  { key: 'coming_soon', label: 'Tez kunda' },
  { key: 'in_progress', label: 'Ishlanmoqda' },
  { key: 'beta', label: 'Beta' },
  { key: 'released', label: 'Tayyor' },
];

export default function Roadmap() {
  const [modules, setModules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');

  const fetchData = useCallback(async () => {
    try {
      const res = await getRoadmap(filter || undefined);
      if (res.data?.success) setModules(res.data.data || []);
    } catch {} finally { setLoading(false); }
  }, [filter]);

  useEffect(() => { setLoading(true); fetchData(); }, [fetchData]);

  const handleVote = async (id) => {
    // Optimistic update
    setModules((prev) =>
      prev.map((m) =>
        m.id === id
          ? {
              ...m,
              user_voted: !m.user_voted,
              votes_count: m.user_voted ? m.votes_count - 1 : m.votes_count + 1,
            }
          : m
      )
    );
    try { await voteRoadmap(id); } catch { fetchData(); }
  };

  const handleNotify = async (id) => {
    setModules((prev) =>
      prev.map((m) =>
        m.id === id ? { ...m, user_subscribed: !m.user_subscribed } : m
      )
    );
    try { await notifyRoadmap(id); } catch { fetchData(); }
  };

  if (loading) return <div className="page"><SkeletonLoader lines={5} /></div>;

  return (
    <div className="page">
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '12px' }}>🗺️ Roadmap</h2>

      {/* Filter tabs */}
      <div style={{ display: 'flex', gap: '6px', overflowX: 'auto', marginBottom: '16px', paddingBottom: '4px' }}>
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            style={{
              padding: '6px 14px',
              borderRadius: '20px',
              border: 'none',
              fontSize: '13px',
              fontWeight: filter === f.key ? 600 : 400,
              background: filter === f.key ? 'var(--tg-theme-button-color, #3B82F6)' : 'var(--tg-theme-secondary-bg-color, #f1f5f9)',
              color: filter === f.key ? '#fff' : 'var(--tg-theme-text-color, #334155)',
              cursor: 'pointer',
              whiteSpace: 'nowrap',
            }}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Module cards */}
      {modules.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '40px 0', color: '#94a3b8' }}>
          <div style={{ fontSize: '40px', marginBottom: '8px' }}>📋</div>
          <p>Modul topilmadi</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          {modules.map((m) => (
            <div
              key={m.id}
              style={{
                background: 'var(--tg-theme-secondary-bg-color, #fff)',
                borderRadius: '16px',
                padding: '16px',
                boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
              }}
            >
              {/* Header */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '8px' }}>
                <span style={{ fontSize: '28px' }}>{m.icon || '📦'}</span>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 600, fontSize: '15px' }}>{m.title}</div>
                  <span
                    style={{
                      display: 'inline-block',
                      fontSize: '11px',
                      fontWeight: 600,
                      padding: '2px 8px',
                      borderRadius: '10px',
                      color: '#fff',
                      background: m.status_color,
                      marginTop: '2px',
                    }}
                  >
                    {m.status_label}
                  </span>
                </div>
              </div>

              {/* Description */}
              <p style={{ fontSize: '13px', color: 'var(--tg-theme-hint-color, #64748b)', margin: '0 0 10px' }}>
                {m.description}
              </p>

              {/* Progress bar */}
              {m.progress_percent !== null && (
                <div style={{ marginBottom: '10px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '11px', color: '#94a3b8', marginBottom: '4px' }}>
                    <span>Progress</span>
                    <span>{m.progress_percent}%</span>
                  </div>
                  <div style={{ height: '6px', borderRadius: '3px', background: '#e2e8f0' }}>
                    <div
                      style={{
                        height: '100%',
                        borderRadius: '3px',
                        width: `${m.progress_percent}%`,
                        background: m.status_color,
                        transition: 'width 0.3s',
                      }}
                    />
                  </div>
                </div>
              )}

              {/* Estimated date */}
              {m.estimated_date && (
                <div style={{ fontSize: '12px', color: '#94a3b8', marginBottom: '10px' }}>
                  📅 {m.estimated_date}
                </div>
              )}

              {/* Actions */}
              <div style={{ display: 'flex', gap: '8px' }}>
                <button
                  onClick={() => handleVote(m.id)}
                  style={{
                    flex: 1,
                    padding: '8px',
                    borderRadius: '10px',
                    border: 'none',
                    fontSize: '13px',
                    fontWeight: 600,
                    cursor: 'pointer',
                    background: m.user_voted ? 'var(--tg-theme-button-color, #3B82F6)' : '#e2e8f0',
                    color: m.user_voted ? '#fff' : '#334155',
                  }}
                >
                  👍 {m.votes_count}
                </button>
                <button
                  onClick={() => handleNotify(m.id)}
                  style={{
                    padding: '8px 14px',
                    borderRadius: '10px',
                    border: 'none',
                    fontSize: '13px',
                    fontWeight: 600,
                    cursor: 'pointer',
                    background: m.user_subscribed ? '#F59E0B' : '#e2e8f0',
                    color: m.user_subscribed ? '#fff' : '#334155',
                  }}
                >
                  {m.user_subscribed ? '🔔' : '🔕'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
