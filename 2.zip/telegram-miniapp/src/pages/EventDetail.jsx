import { useState, useEffect, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { getEventDetail } from '../api/client';
import { useLang } from '../contexts/LangContext';
import SkeletonLoader from '../components/SkeletonLoader';
import CountdownTimer from '../components/CountdownTimer';
import LeaderboardTable from '../components/LeaderboardTable';

export default function EventDetail() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const { t } = useLang();

  const fetchData = useCallback(async () => {
    try {
      const res = await getEventDetail(id);
      if (res.data?.success) setData(res.data.data);
    } catch {} finally { setLoading(false); }
  }, [id]);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="page"><SkeletonLoader lines={5} /></div>;

  const ev = data?.event;

  return (
    <div className="page">
      {ev?.banner_url && (
        <img src={ev.banner_url} alt={ev.name} style={{ width: '100%', height: '180px', objectFit: 'cover', borderRadius: '12px', marginBottom: '16px' }} />
      )}
      <h2 style={{ fontSize: '20px', fontWeight: 700, marginBottom: '4px' }}>{ev?.name}</h2>
      {ev?.description && <p className="text-hint mb-16">{ev.description}</p>}

      <div className="card text-center mb-8">
        <CountdownTimer targetDate={ev?.ends_at} />
      </div>

      {data?.user_progress && (
        <div className="card">
          <div className="flex justify-between items-center">
            <span style={{ fontWeight: 600 }}>{t('your_progress')}</span>
            <span className="text-accent" style={{ fontWeight: 700 }}>{data.user_progress.score || 0}</span>
          </div>
        </div>
      )}

      {ev?.quests?.length > 0 && (
        <div className="mt-8">
          <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '8px' }}>📋 {t('quests')}</h3>
          {ev.quests.map((q, i) => (
            <div key={i} className="list-item justify-between">
              <span>{q.title || q.name}</span>
              <span className="text-accent">{q.reward_xp || 0} XP</span>
            </div>
          ))}
        </div>
      )}

      {data?.leaderboard?.length > 0 && (
        <div className="mt-16">
          <h3 style={{ fontSize: '16px', fontWeight: 600, marginBottom: '8px' }}>🏆 {t('leaderboard')}</h3>
          <LeaderboardTable entries={data.leaderboard} />
        </div>
      )}
    </div>
  );
}
