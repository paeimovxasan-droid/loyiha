import { createContext, useState, useEffect, useCallback } from 'react';
import client from '../api/client';

export const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const authenticate = useCallback(async () => {
    const tg = window.Telegram?.WebApp;
    const initData = tg?.initData;

    if (!initData) {
      setError('Telegram WebApp mavjud emas');
      setLoading(false);
      return;
    }

    // Mavjud token bilan profil olishga urinish
    const existingToken = localStorage.getItem('auth_token');
    if (existingToken) {
      try {
        const res = await client.get('/profile');
        if (res.data?.success) {
          setUser(res.data.data);
          setLoading(false);
          return;
        }
      } catch {
        localStorage.removeItem('auth_token');
      }
    }

    // Yangi autentifikatsiya
    try {
      const startParam = tg?.initDataUnsafe?.start_param || '';
      const ref = startParam.startsWith('ref_') ? startParam : undefined;

      const res = await client.post('/auth/telegram', { initData, ref });

      if (res.data?.success) {
        const { user: userData, token } = res.data.data;
        localStorage.setItem('auth_token', token);
        setUser(userData);
      } else {
        setError(res.data?.message || 'Autentifikatsiya xatosi');
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Tarmoq xatosi');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    authenticate();
  }, [authenticate]);

  const refreshUser = async () => {
    try {
      const res = await client.get('/profile');
      if (res.data?.success) setUser(res.data.data);
    } catch {}
  };

  const logout = () => {
    localStorage.removeItem('auth_token');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, error, refreshUser, logout }}>
      {children}
    </AuthContext.Provider>
  );
}
