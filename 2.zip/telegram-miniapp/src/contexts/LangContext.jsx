import { createContext, useState, useContext, useCallback } from 'react';
import uz from '../i18n/uz.json';
import ru from '../i18n/ru.json';
import en from '../i18n/en.json';

const translations = { uz, ru, en };

const LangContext = createContext(null);

export function LangProvider({ children }) {
  const tgLang = window.Telegram?.WebApp?.initDataUnsafe?.user?.language_code;
  const saved = localStorage.getItem('locale');
  const initial = saved || (['uz', 'ru', 'en'].includes(tgLang) ? tgLang : 'uz');

  const [locale, setLocaleState] = useState(initial);

  const setLocale = useCallback((lang) => {
    if (['uz', 'ru', 'en'].includes(lang)) {
      setLocaleState(lang);
      localStorage.setItem('locale', lang);
    }
  }, []);

  const t = useCallback((key) => {
    return translations[locale]?.[key] || translations.uz[key] || key;
  }, [locale]);

  return (
    <LangContext.Provider value={{ locale, setLocale, t }}>
      {children}
    </LangContext.Provider>
  );
}

export function useLang() {
  return useContext(LangContext);
}
