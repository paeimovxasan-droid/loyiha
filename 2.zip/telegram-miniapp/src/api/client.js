import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_BASE || '/api/v1';

const client = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

// Request interceptor — token va til qo'shish
client.interceptors.request.use((config) => {
  const token = localStorage.getItem('auth_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  const locale = localStorage.getItem('locale') || 'uz';
  config.headers['Accept-Language'] = locale;

  return config;
});

// Response interceptor — 401 da token tozalash
client.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('auth_token');
      window.location.reload();
    }
    return Promise.reject(error);
  }
);

export default client;

// ─── Marketing API funksiyalari ───

export const redeemPromo = (code) => client.post('/promo/redeem', { code });

export const getSpinWheel = () => client.get('/spin-wheel');
export const spin = () => client.post('/spin-wheel/spin');

export const getBadges = () => client.get('/badges');

export const getShare = () => client.get('/share');

export const getInviteChallenge = () => client.get('/invite-challenge');
export const startChallenge = () => client.post('/invite-challenge/start');

export const getOnboarding = () => client.get('/onboarding');

export const getCompetitions = () => client.get('/competitions');

export const getEvents = () => client.get('/events');
export const getEventDetail = (id) => client.get(`/events/${id}`);

export const getSocialProof = () => client.get('/social-proof');

export const getQrReferral = () => client.get('/qr-referral');
export const downloadQr = () => client.get('/qr-referral/download', { responseType: 'blob' });

export const getReferralTree = () => client.get('/referral-tree');
export const getReferralTreeLevel = (level, page = 1) => client.get(`/referral-tree/level/${level}?page=${page}`);

export const getVipStatus = () => client.get('/vip');

// ─── Exchange API funksiyalari ───

export const getOrderBook = (depth = 20) => client.get(`/exchange/order-book?depth=${depth}`);
export const getTicker = () => client.get('/exchange/ticker');
export const getRecentTrades = (limit = 50) => client.get(`/exchange/trades/recent?limit=${limit}`);
export const getCandles = (interval = '1h', from, to) => {
  const params = new URLSearchParams({ interval });
  if (from) params.append('from', from);
  if (to) params.append('to', to);
  return client.get(`/exchange/candles?${params}`);
};
export const placeOrder = (data) => client.post('/exchange/orders', data);
export const cancelOrder = (orderId) => client.delete(`/exchange/orders/${orderId}`);
export const getMyOpenOrders = () => client.get('/exchange/orders/open');
export const getMyOrderHistory = (page = 1) => client.get(`/exchange/orders/history?page=${page}`);
export const getMyTrades = (page = 1) => client.get(`/exchange/trades/my?page=${page}`);

// ─── Roadmap API funksiyalari ───

export const getRoadmap = (status) => {
  const params = status ? `?status=${status}` : '';
  return client.get(`/roadmap${params}`);
};
export const voteRoadmap = (id) => client.post(`/roadmap/${id}/vote`);
export const notifyRoadmap = (id) => client.post(`/roadmap/${id}/notify`);
