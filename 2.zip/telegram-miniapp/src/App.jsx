import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { LangProvider } from './contexts/LangContext';
import useAuth from './hooks/useAuth';
import useTelegram from './hooks/useTelegram';
import BottomNav from './components/BottomNav';
import SkeletonLoader from './components/SkeletonLoader';
import Dashboard from './pages/Dashboard';
import Wallet from './pages/Wallet';
import Earn from './pages/Earn';
import Quests from './pages/Quests';
import Profile from './pages/Profile';
import Leaderboard from './pages/Leaderboard';
import Deposit from './pages/Deposit';
import Withdrawal from './pages/Withdrawal';
import Referrals from './pages/Referrals';
import SpinWheel from './pages/SpinWheel';
import Badges from './pages/Badges';
import Share from './pages/Share';
import InviteChallenge from './pages/InviteChallenge';
import Onboarding from './pages/Onboarding';
import Competitions from './pages/Competitions';
import Events from './pages/Events';
import EventDetail from './pages/EventDetail';
import ReferralTree from './pages/ReferralTree';
import VipStatus from './pages/VipStatus';
import Exchange from './pages/Exchange';
import Roadmap from './pages/Roadmap';
import { useEffect } from 'react';

function AppContent() {
  const { loading, error } = useAuth();
  const { expand, ready } = useTelegram();

  useEffect(() => {
    expand();
    ready();
  }, [expand, ready]);

  if (loading) {
    return (
      <div className="page" style={{ paddingTop: '40vh' }}>
        <SkeletonLoader lines={3} height={20} />
      </div>
    );
  }

  if (error) {
    return (
      <div className="page text-center" style={{ paddingTop: '40vh' }}>
        <div style={{ fontSize: '48px', marginBottom: '16px' }}>⚠️</div>
        <p>{error}</p>
      </div>
    );
  }

  return (
    <>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/wallet" element={<Wallet />} />
        <Route path="/earn" element={<Earn />} />
        <Route path="/quests" element={<Quests />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/leaderboard" element={<Leaderboard />} />
        <Route path="/deposit" element={<Deposit />} />
        <Route path="/withdrawal" element={<Withdrawal />} />
        <Route path="/referrals" element={<Referrals />} />
        <Route path="/spin-wheel" element={<SpinWheel />} />
        <Route path="/badges" element={<Badges />} />
        <Route path="/share" element={<Share />} />
        <Route path="/invite-challenge" element={<InviteChallenge />} />
        <Route path="/onboarding" element={<Onboarding />} />
        <Route path="/competitions" element={<Competitions />} />
        <Route path="/events" element={<Events />} />
        <Route path="/events/:id" element={<EventDetail />} />
        <Route path="/referral-tree" element={<ReferralTree />} />
        <Route path="/vip" element={<VipStatus />} />
        <Route path="/exchange" element={<Exchange />} />
        <Route path="/roadmap" element={<Roadmap />} />
      </Routes>
      <BottomNav />
    </>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <LangProvider>
        <AuthProvider>
          <AppContent />
        </AuthProvider>
      </LangProvider>
    </BrowserRouter>
  );
}
