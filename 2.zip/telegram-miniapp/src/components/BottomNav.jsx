import { useLocation, useNavigate } from 'react-router-dom';
import { useLang } from '../contexts/LangContext';
import useHaptic from '../hooks/useHaptic';

const tabs = [
  { path: '/', icon: '🏠', key: 'home' },
  { path: '/wallet', icon: '💰', key: 'wallet' },
  { path: '/earn', icon: '⚡', key: 'earn' },
  { path: '/quests', icon: '🎯', key: 'quests' },
  { path: '/profile', icon: '👤', key: 'profile' },
];

export default function BottomNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const { t } = useLang();
  const { selectionChanged } = useHaptic();

  return (
    <nav style={{
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
      display: 'flex',
      background: 'var(--section-bg)',
      borderTop: '1px solid var(--secondary-bg)',
      paddingBottom: 'env(safe-area-inset-bottom, 0)',
      zIndex: 100,
    }}>
      {tabs.map((tab) => {
        const active = location.pathname === tab.path;
        return (
          <button
            key={tab.path}
            onClick={() => { selectionChanged(); navigate(tab.path); }}
            style={{
              flex: 1,
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              padding: '8px 0',
              border: 'none',
              background: 'transparent',
              cursor: 'pointer',
              opacity: active ? 1 : 0.5,
              fontSize: '20px',
            }}
            aria-label={t(tab.key)}
            aria-current={active ? 'page' : undefined}
          >
            <span>{tab.icon}</span>
            <span style={{ fontSize: '10px', marginTop: '2px', color: active ? 'var(--accent-text)' : 'var(--hint-color)' }}>
              {t(tab.key)}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
