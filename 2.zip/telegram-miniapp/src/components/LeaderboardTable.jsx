export default function LeaderboardTable({ entries = [], userRank }) {
  const medals = { 1: '🥇', 2: '🥈', 3: '🥉' };
  return (
    <div>
      {entries.map((e, i) => {
        const rank = e.rank || i + 1;
        const isUser = userRank && rank === userRank;
        return (
          <div key={i} className="list-item justify-between" style={{
            background: isUser ? 'var(--secondary-bg)' : 'transparent',
            borderRadius: isUser ? '8px' : 0,
            padding: isUser ? '12px 8px' : '12px 0',
          }}>
            <div className="flex items-center gap-8">
              <span style={{ fontWeight: 700, minWidth: '28px', textAlign: 'center', fontSize: '16px' }}>
                {medals[rank] || `#${rank}`}
              </span>
              <span style={{ fontWeight: isUser ? 700 : 400 }}>{e.name || e.masked_name}</span>
            </div>
            <span className="text-accent" style={{ fontWeight: 600 }}>{Number(e.score || 0).toLocaleString()}</span>
          </div>
        );
      })}
    </div>
  );
}
