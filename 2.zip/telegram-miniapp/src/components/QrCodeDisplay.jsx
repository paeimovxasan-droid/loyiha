import { useState, useEffect, useCallback } from 'react';
import { getQrReferral, downloadQr } from '../api/client';
import { useLang } from '../contexts/LangContext';

export default function QrCodeDisplay() {
  const [data, setData] = useState(null);
  const { t } = useLang();

  const fetchData = useCallback(async () => {
    try {
      const res = await getQrReferral();
      if (res.data?.success) setData(res.data.data);
    } catch {}
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleDownload = async () => {
    try {
      const res = await downloadQr();
      const url = URL.createObjectURL(res.data);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'qr-referral.png';
      a.click();
      URL.revokeObjectURL(url);
    } catch {}
  };

  if (!data?.qr_url) return null;

  return (
    <div className="card text-center">
      <div style={{ fontWeight: 600, marginBottom: '8px' }}>📱 {t('qr_code')}</div>
      <img src={data.qr_url} alt="QR Code" style={{ width: '180px', height: '180px', margin: '0 auto 8px', display: 'block', borderRadius: '8px' }} />
      <div className="text-hint mb-8" style={{ fontSize: '12px', wordBreak: 'break-all' }}>{data.referral_link}</div>
      <button className="btn btn-secondary" onClick={handleDownload}>⬇️ {t('download')}</button>
    </div>
  );
}
