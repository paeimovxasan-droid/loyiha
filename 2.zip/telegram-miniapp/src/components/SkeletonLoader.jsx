export default function SkeletonLoader({ lines = 3, height = 16 }) {
  return (
    <div role="status" aria-label="Loading">
      {Array.from({ length: lines }).map((_, i) => (
        <div
          key={i}
          style={{
            height: `${height}px`,
            background: 'var(--secondary-bg)',
            borderRadius: '8px',
            marginBottom: '8px',
            width: i === lines - 1 ? '60%' : '100%',
            animation: 'pulse 1.5s ease-in-out infinite',
          }}
        />
      ))}
      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
      `}</style>
    </div>
  );
}
