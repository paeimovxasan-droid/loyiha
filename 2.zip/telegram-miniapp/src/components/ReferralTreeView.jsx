const levelColors = { 1: 'var(--button-color)', 2: '#f59e0b', 3: '#8b5cf6' };

function ReferralNode({ node, depth = 1 }) {
  return (
    <div style={{ marginLeft: depth > 1 ? '16px' : 0, borderLeft: depth > 1 ? `2px solid ${levelColors[depth] || 'var(--secondary-bg)'}` : 'none', paddingLeft: depth > 1 ? '12px' : 0 }}>
      <div className="list-item" style={{ borderBottom: 'none', padding: '8px 0' }}>
        <div style={{ flex: 1 }}>
          <div className="flex items-center gap-8">
            <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: node.is_active ? '#34d399' : 'var(--hint-color)', display: 'inline-block' }} />
            <span style={{ fontWeight: 600, fontSize: '14px' }}>{node.masked_name || node.name}</span>
            <span className="badge" style={{ background: levelColors[depth] || 'var(--secondary-bg)', color: '#fff', fontSize: '10px', padding: '2px 6px' }}>
              L{depth}
            </span>
          </div>
          <div className="text-hint" style={{ fontSize: '11px', marginLeft: '16px' }}>
            {node.registered_at} · {Number(node.commission || 0).toLocaleString()} AIS
          </div>
        </div>
      </div>
      {node.children?.map((child, i) => (
        <ReferralNode key={i} node={child} depth={depth + 1} />
      ))}
    </div>
  );
}

export default function ReferralTreeView({ tree = [] }) {
  if (!tree.length) return <div className="card text-center text-hint">Referrallar topilmadi</div>;
  return (
    <div>
      {tree.map((node, i) => (
        <ReferralNode key={i} node={node} depth={1} />
      ))}
    </div>
  );
}
