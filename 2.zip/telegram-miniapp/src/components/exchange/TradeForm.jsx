import { useState, useCallback } from 'react';
import { useLang } from '../../contexts/LangContext';
import useHaptic from '../../hooks/useHaptic';

export default function TradeForm({ onSubmit, submitting, selectedPrice }) {
  const { t } = useLang();
  const { impactOccurred, notificationOccurred } = useHaptic();
  const [type, setType] = useState('limit');
  const [side, setSide] = useState('buy');
  const [price, setPrice] = useState('');
  const [amount, setAmount] = useState('');
  const [msg, setMsg] = useState(null);

  // When price is clicked from order book
  if (selectedPrice && price !== String(selectedPrice)) {
    setPrice(String(selectedPrice));
  }

  const total = type === 'limit' && price && amount
    ? (Number(price) * Number(amount)).toFixed(2)
    : null;

  const fee = amount
    ? (Number(amount) * 0.002).toFixed(4)
    : null;

  const handleSubmit = useCallback(async (e) => {
    e.preventDefault();
    setMsg(null);
    impactOccurred('medium');

    const data = { type, side, amount: Number(amount) };
    if (type === 'limit') data.price = Number(price);

    try {
      const res = await onSubmit?.(data);
      if (res?.success) {
        notificationOccurred('success');
        setMsg({ type: 'success', text: res.message || t('success') || 'Muvaffaqiyatli!' });
        setPrice(''); setAmount('');
      } else {
        notificationOccurred('error');
        setMsg({ type: 'error', text: res?.message || t('error') || 'Xatolik' });
      }
    } catch (err) {
      notificationOccurred('error');
      setMsg({ type: 'error', text: err.response?.data?.message || t('error') || 'Xatolik' });
    }
  }, [type, side, price, amount, onSubmit, impactOccurred, notificationOccurred, t]);

  return (
    <div style={{
      background: 'var(--section-bg)', borderRadius: 12,
      padding: 12, marginBottom: 12,
    }}>
      {/* Type tabs */}
      <div className="tab-bar" style={{ marginBottom: 10 }}>
        {['limit', 'market'].map((tp) => (
          <button
            key={tp}
            className={type === tp ? 'active' : ''}
            onClick={() => { impactOccurred('light'); setType(tp); }}
          >
            {tp === 'limit' ? 'Limit' : 'Market'}
          </button>
        ))}
      </div>

      {msg && (
        <div style={{
          padding: 8, borderRadius: 8, marginBottom: 8, fontSize: 13,
          background: msg.type === 'error' ? 'rgba(239,68,68,0.1)' : 'rgba(34,197,94,0.1)',
          color: msg.type === 'error' ? '#ef4444' : '#22c55e',
        }}>
          {msg.text}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        {type === 'limit' && (
          <div style={{ marginBottom: 8 }}>
            <label style={{ fontSize: 11, color: 'var(--hint-color)' }}>
              {t('price') || 'Narx'} (UZS)
            </label>
            <input
              type="number" step="0.01" value={price}
              onChange={(e) => setPrice(e.target.value)}
              placeholder="0.00" required
              style={{ marginTop: 4 }}
            />
          </div>
        )}

        <div style={{ marginBottom: 8 }}>
          <label style={{ fontSize: 11, color: 'var(--hint-color)' }}>
            {t('amount') || 'Miqdor'} (AIS)
          </label>
          <input
            type="number" step="0.0001" value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="0.0000" required
            style={{ marginTop: 4 }}
          />
        </div>

        {total && (
          <div style={{ fontSize: 12, color: 'var(--hint-color)', marginBottom: 4 }}>
            {t('total') || 'Jami'}: {Number(total).toLocaleString()} UZS
          </div>
        )}
        {fee && (
          <div style={{ fontSize: 11, color: 'var(--hint-color)', marginBottom: 10 }}>
            ~{t('fee') || 'Komissiya'}: {fee} AIS
          </div>
        )}

        {/* Buy / Sell buttons */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          <button
            type="submit"
            disabled={submitting}
            onClick={() => setSide('buy')}
            style={{
              padding: '12px 0', border: 'none', borderRadius: 10,
              fontWeight: 700, fontSize: 15, cursor: 'pointer',
              background: '#22c55e', color: '#fff',
              opacity: submitting ? 0.6 : 1,
            }}
          >
            {submitting && side === 'buy' ? '...' : `Buy`}
          </button>
          <button
            type="submit"
            disabled={submitting}
            onClick={() => setSide('sell')}
            style={{
              padding: '12px 0', border: 'none', borderRadius: 10,
              fontWeight: 700, fontSize: 15, cursor: 'pointer',
              background: '#ef4444', color: '#fff',
              opacity: submitting ? 0.6 : 1,
            }}
          >
            {submitting && side === 'sell' ? '...' : `Sell`}
          </button>
        </div>
      </form>
    </div>
  );
}
