import { useLang } from '../../contexts/LangContext';
import useHaptic from '../../hooks/useHaptic';

export default function MyOpenOrders({ orders, onCancel }) {
  const { t } = useLang();
  const { impactOccurred } = useHaptic();
  const list = orders || [];

  const handleCancel = (id) => {
    impactOccurred('medium');
    onCancel?.(id);
  };

  return (
    <div style={{
      background: 'var(--section-bg)', borderRadius: 12,
      padding: '8px 0', marginBottom: 12,
    }}>
      <div style={{ padding: '0 12px 6px', fontSize: 13, fontWeight: 600 }}>
        {t('open_orders') || 'Ochiq buyurtmalar'}
      </div>
      {list.length === 0 && (
        <div style={{ textAlign: 'center', padding: 16, fontSize: 12, color: 'var(--hint-color)' }}>
          {t('no_open_orders') || 'Ochiq buyurtmalar yo\'q'}
        </div>
      )}
      {list.map((order) => {
        const isBuy = order.side === 'buy';
        return (
          <div key={order.id} style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '8px 12px', borderBottom: '1px solid var(--secondary-bg)',
          }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 12 }}>
                <span style={{
                  color: isBuy ? '#22c55e' : '#ef4444',
                  fontWeight: 700, marginRight: 4,
                }}>
                  {isBuy ? 'BUY' : 'SELL'}
                </span>
                <span style={{ textTransform: 'uppercase', fontSize: 11, color: 'var(--hint-color)' }}>
                  {order.type}
                </span>
              </div>
              <div style={{ fontSize: 12, marginTop: 2 }}>
                {order.price ? `${Number(order.price).toLocaleString()} UZS` : 'Market'} ×{' '}
                {Number(order.remaining_amount || order.amount).toFixed(4)} AIS
              </div>
              <div style={{ fontSize: 11, color: 'var(--hint-color)' }}>
                {order.status === 'partially_filled'
                  ? `${t('filled') || 'Bajarilgan'}: ${Number(order.filled_amount).toFixed(4)}`
                  : order.status}
              </div>
            </div>
            <button
              onClick={() => handleCancel(order.id)}
              style={{
                padding: '6px 12px', border: 'none', borderRadius: 8,
                background: 'rgba(239,68,68,0.1)', color: '#ef4444',
                fontSize: 12, fontWeight: 600, cursor: 'pointer',
              }}
            >
              ✕
            </button>
          </div>
        );
      })}
    </div>
  );
}
