import { useLang } from '../../contexts/LangContext';

export default function RecentTrades({ trades }) {
  const { t } = useLang();
  const list = trades || [];

  return (
    <div style={{
      background: 'var(--section-bg)', borderRadius: 12,
      padding: '8px 0', marginBottom: 12,
    }}>
      <div style={{ padding: '0 12px 6px', fontSize: 13, fontWeight: 600 }}>
        {t('recent_trades') || 'So\'nggi savdolar'}
      </div>
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        padding: '0 12px 4px', fontSize: 11, color: 'var(--hint-color)',
        borderBottom: '1px solid var(--secondary-bg)',
      }}>
        <span>{t('price') || 'Narx'}</span>
        <span>{t('amount') || 'Miqdor'}</span>
        <span>{t('time') || 'Vaqt'}</span>
      </div>
      <div style={{ maxHeight: 200, overflow: 'auto' }}>
        {list.length === 0 && (
          <div style={{ textAlign: 'center', padding: 16, fontSize: 12, color: 'var(--hint-color)' }}>
            {t('no_data') || 'Ma\'lumot yo\'q'}
          </div>
        )}
        {list.map((tr, i) => {
          const isBuy = tr.side === 'buy';
          return (
            <div key={tr.id || i} style={{
              display: 'flex', justifyContent: 'space-between',
              padding: '4px 12px', fontSize: 12,
            }}>
              <span style={{ color: isBuy ? '#22c55e' : '#ef4444', fontWeight: 600 }}>
                {Number(tr.price).toLocaleString()}
              </span>
              <span>{Number(tr.amount).toFixed(4)}</span>
              <span style={{ color: 'var(--hint-color)' }}>
                {tr.created_at ? new Date(tr.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : ''}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
