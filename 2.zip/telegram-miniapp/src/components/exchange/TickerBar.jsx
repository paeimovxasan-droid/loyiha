import { useLang } from '../../contexts/LangContext';

export default function TickerBar({ ticker }) {
  const { t } = useLang();
  if (!ticker) return null;

  const price = Number(ticker.last_price || 0);
  const change = Number(ticker.change_24h || 0);
  const isUp = change >= 0;
  const color = isUp ? '#22c55e' : '#ef4444';

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '10px 16px', background: 'var(--section-bg)',
      borderRadius: 12, marginBottom: 12,
    }}>
      <div>
        <div style={{ fontSize: 11, color: 'var(--hint-color)' }}>AIS/UZS</div>
        <div style={{ fontSize: 20, fontWeight: 700, color }}>{price.toLocaleString()}</div>
      </div>
      <div style={{ textAlign: 'center' }}>
        <div style={{ fontSize: 11, color: 'var(--hint-color)' }}>24h</div>
        <div style={{ fontSize: 14, fontWeight: 600, color }}>
          {isUp ? '+' : ''}{change.toFixed(2)}%
        </div>
      </div>
      <div style={{ textAlign: 'right' }}>
        <div style={{ fontSize: 11, color: 'var(--hint-color)' }}>{t('volume') || 'Hajm'}</div>
        <div style={{ fontSize: 13, fontWeight: 600 }}>
          {Number(ticker.volume_ais_24h || 0).toLocaleString()} AIS
        </div>
      </div>
    </div>
  );
}
