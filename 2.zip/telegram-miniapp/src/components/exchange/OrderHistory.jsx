import { useState, useEffect } from 'react';
import { useLang } from '../../contexts/LangContext';
import useHaptic from '../../hooks/useHaptic';

const TABS = ['all', 'filled', 'cancelled'];

export default function OrderHistory({ orders, onFetch }) {
  const { t } = useLang();
  const { impactOccurred } = useHaptic();
  const [tab, setTab] = useState('all');

  useEffect(() => { onFetch?.(); }, [onFetch]);

  const filtered = (orders || []).filter((o) => {
    if (tab === 'all') return true;
    if (tab === 'filled') return o.status === 'filled' || o.status === 'partially_filled';
    if (tab === 'cancelled') return o.status === 'cancelled';
    return true;
  });

  const statusLabel = (s) => {
    const map = { open: '🟡', partially_filled: '🟠', filled: '🟢', cancelled: '🔴' };
    return map[s] || s;
  };

  return (
    <div style={{
      background: 'var(--section-bg)', borderRadius: 12,
      padding: '8px 0', marginBottom: 12,
    }}>
      <div style={{ padding: '0 12px 6px', fontSize: 13, fontWeight: 600 }}>
        {t('order_history') || 'Buyurtma tarixi'}
      </div>

      <div style={{
        display: 'flex', gap: 4, padding: '0 12px 8px',
      }}>
        {TABS.map((tb) => (
          <button
            key={tb}
            onClick={() => { impactOccurred('light'); setTab(tb); }}
            style={{
              flex: 1, padding: '5px 0', border: 'none', borderRadius: 6,
              fontSize: 11, fontWeight: 600, cursor: 'pointer',
              background: tab === tb ? 'var(--button-color)' : 'var(--secondary-bg)',
              color: tab === tb ? 'var(--button-text-color)' : 'var(--hint-color)',
            }}
          >
            {tb === 'all' ? (t('all') || 'Barchasi')
              : tb === 'filled' ? (t('filled') || 'Bajarilgan')
              : (t('cancelled') || 'Bekor')}
          </button>
        ))}
      </div>

      {filtered.length === 0 && (
        <div style={{ textAlign: 'center', padding: 16, fontSize: 12, color: 'var(--hint-color)' }}>
          {t('no_data') || 'Ma\'lumot yo\'q'}
        </div>
      )}

      {filtered.map((order) => {
        const isBuy = order.side === 'buy';
        return (
          <div key={order.id} style={{
            padding: '8px 12px', borderBottom: '1px solid var(--secondary-bg)',
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <span style={{
                  color: isBuy ? '#22c55e' : '#ef4444',
                  fontWeight: 700, fontSize: 12, marginRight: 4,
                }}>
                  {isBuy ? 'BUY' : 'SELL'}
                </span>
                <span style={{ fontSize: 11, color: 'var(--hint-color)', textTransform: 'uppercase' }}>
                  {order.type}
                </span>
              </div>
              <span style={{ fontSize: 12 }}>{statusLabel(order.status)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4, fontSize: 12 }}>
              <span>{order.price ? `${Number(order.price).toLocaleString()} UZS` : 'Market'}</span>
              <span>{Number(order.filled_amount || 0).toFixed(4)} / {Number(order.amount).toFixed(4)}</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 2, fontSize: 11, color: 'var(--hint-color)' }}>
              <span>{order.created_at ? new Date(order.created_at).toLocaleDateString() : ''}</span>
              {order.total_fee > 0 && <span>Fee: {Number(order.total_fee).toFixed(4)}</span>}
            </div>
          </div>
        );
      })}
    </div>
  );
}
