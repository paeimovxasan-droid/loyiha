import { useState, useEffect, useCallback } from 'react';
import client from '../../api/client';
import { useLang } from '../../contexts/LangContext';

export default function BalanceDisplay() {
  const { t } = useLang();
  const [data, setData] = useState(null);

  const fetch = useCallback(async () => {
    try {
      const res = await client.get('/wallet');
      if (res.data?.success) setData(res.data.data);
    } catch {}
  }, []);

  useEffect(() => { fetch(); }, [fetch]);

  const ais = Number(data?.wallet?.balance || 0);
  const aisFrozen = Number(data?.wallet?.frozen_balance || 0);
  const uzs = Number(data?.uzs_balance || 0);
  const uzsFrozen = Number(data?.frozen_uzs_balance || 0);

  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8,
      padding: 12, background: 'var(--section-bg)', borderRadius: 12, marginBottom: 12,
    }}>
      <div>
        <div style={{ fontSize: 11, color: 'var(--hint-color)' }}>AIS {t('balance') || 'Balans'}</div>
        <div style={{ fontSize: 15, fontWeight: 700 }}>{ais.toFixed(4)}</div>
        {aisFrozen > 0 && (
          <div style={{ fontSize: 11, color: 'var(--hint-color)' }}>🔒 {aisFrozen.toFixed(4)}</div>
        )}
      </div>
      <div style={{ textAlign: 'right' }}>
        <div style={{ fontSize: 11, color: 'var(--hint-color)' }}>UZS {t('balance') || 'Balans'}</div>
        <div style={{ fontSize: 15, fontWeight: 700 }}>{uzs.toLocaleString()}</div>
        {uzsFrozen > 0 && (
          <div style={{ fontSize: 11, color: 'var(--hint-color)' }}>🔒 {uzsFrozen.toLocaleString()}</div>
        )}
      </div>
    </div>
  );
}
