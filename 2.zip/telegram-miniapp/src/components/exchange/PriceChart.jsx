import { useRef, useEffect, useState, useCallback } from 'react';
import useHaptic from '../../hooks/useHaptic';

const INTERVALS = ['1h', '1d', '1w', '1M'];

export default function PriceChart({ candles, onIntervalChange }) {
  const canvasRef = useRef(null);
  const [interval, setInterval_] = useState('1h');
  const { selectionChanged } = useHaptic();

  const handleInterval = useCallback((iv) => {
    selectionChanged();
    setInterval_(iv);
    onIntervalChange?.(iv);
  }, [onIntervalChange, selectionChanged]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
    const W = rect.width;
    const H = rect.height;

    ctx.clearRect(0, 0, W, H);

    const data = candles || [];
    if (data.length < 2) {
      ctx.fillStyle = 'var(--hint-color)';
      ctx.font = '12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('Ma\'lumot yo\'q', W / 2, H / 2);
      return;
    }

    const closes = data.map((c) => Number(c.close));
    const minP = Math.min(...closes);
    const maxP = Math.max(...closes);
    const range = maxP - minP || 1;
    const pad = 8;

    // Draw grid lines
    ctx.strokeStyle = 'rgba(128,128,128,0.1)';
    ctx.lineWidth = 1;
    for (let i = 0; i < 4; i++) {
      const y = pad + ((H - pad * 2) / 3) * i;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(W, y);
      ctx.stroke();
    }

    // Draw line
    const isUp = closes[closes.length - 1] >= closes[0];
    const lineColor = isUp ? '#22c55e' : '#ef4444';

    ctx.beginPath();
    ctx.strokeStyle = lineColor;
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';

    const points = closes.map((p, i) => ({
      x: pad + (i / (closes.length - 1)) * (W - pad * 2),
      y: pad + (1 - (p - minP) / range) * (H - pad * 2),
    }));

    points.forEach((pt, i) => {
      if (i === 0) ctx.moveTo(pt.x, pt.y);
      else ctx.lineTo(pt.x, pt.y);
    });
    ctx.stroke();

    // Fill gradient
    ctx.lineTo(points[points.length - 1].x, H);
    ctx.lineTo(points[0].x, H);
    ctx.closePath();
    const grad = ctx.createLinearGradient(0, 0, 0, H);
    grad.addColorStop(0, isUp ? 'rgba(34,197,94,0.2)' : 'rgba(239,68,68,0.2)');
    grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad;
    ctx.fill();
  }, [candles]);

  return (
    <div style={{
      background: 'var(--section-bg)', borderRadius: 12,
      padding: 12, marginBottom: 12,
    }}>
      <div style={{ display: 'flex', gap: 4, marginBottom: 8 }}>
        {INTERVALS.map((iv) => (
          <button
            key={iv}
            onClick={() => handleInterval(iv)}
            style={{
              flex: 1, padding: '5px 0', border: 'none', borderRadius: 6,
              fontSize: 12, fontWeight: 600, cursor: 'pointer',
              background: interval === iv ? 'var(--button-color)' : 'var(--secondary-bg)',
              color: interval === iv ? 'var(--button-text-color)' : 'var(--hint-color)',
            }}
          >
            {iv}
          </button>
        ))}
      </div>
      <canvas
        ref={canvasRef}
        style={{ width: '100%', height: 160, display: 'block' }}
      />
    </div>
  );
}
