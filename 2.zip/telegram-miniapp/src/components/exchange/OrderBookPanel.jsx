import { useLang } from '../../contexts/LangContext';

export default function OrderBookPanel({ orderBook, onPriceClick }) {
  const { t } = useLang();
  const bids = orderBook?.bids || [];
  const asks = orderBook?.asks || [];

  const maxBidAmt = Math.max(...bids.map((b) => Number(b.amount)), 1);
  const maxAskAmt = Math.max(...asks.map((a) => Number(a.amount)), 1);

  const rowStyle = {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    padding: '3px 8px', fontSize: 12, position: 'relative', cursor: 'pointer',
  };

  const renderRow = (item, side) => {
    const amt = Number(item.amount);
    const max = side === 'bid' ? maxBidAmt : maxAskAmt;
    const pct = (amt / max) * 100;
    const bg = side === 'bid' ? 'rgba(34,197,94,0.12)' : 'rgba(239,68,68,0.12)';
    const color = side === 'bid' ? '#22c55e' : '#ef4444';

    return (
      <div
        key={`${side}-${item.price}`}
        style={rowStyle}
        onClick={() => onPriceClick?.(item.price)}
      >
        <div style={{
          position: 'absolute', top: 0, bottom: 0,
          [side === 'bid' ? 'right' : 'left']: 0,
          width: `${pct}%`, background: bg, zIndex: 0,
        }} />
        <span style={{ color, fontWeight: 600, zIndex: 1 }}>
          {Number(item.price).toLocaleString()}
        </span>
        <span style={{ zIndex: 1 }}>{Number(item.amount).toFixed(4)}</span>
        <span style={{ color: 'var(--hint-color)', zIndex: 1 }}>
          {Number(item.total || item.price * item.amount).toLocaleString()}
        </span>
      </div>
    );
  };

  return (
    <div style={{
      background: 'var(--section-bg)', borderRadius: 12,
      padding: '8px 0', marginBottom: 12, overflow: 'hidden',
    }}>
      <div style={{
        display: 'flex', justifyContent: 'space-between',
        padding: '0 8px 6px', fontSize: 11, color: 'var(--hint-color)',
        borderBottom: '1px solid var(--secondary-bg)',
      }}>
        <span>{t('price') || 'Narx'} (UZS)</span>
        <span>{t('amount') || 'Miqdor'} (AIS)</span>
        <span>{t('total') || 'Jami'} (UZS)</span>
      </div>

      {/* Asks — reversed so lowest ask is at bottom */}
      <div style={{ maxHeight: 160, overflow: 'auto' }}>
        {[...asks].reverse().map((a) => renderRow(a, 'ask'))}
      </div>

      {/* Spread */}
      {bids.length > 0 && asks.length > 0 && (
        <div style={{
          textAlign: 'center', padding: '4px 0', fontSize: 11,
          color: 'var(--hint-color)', borderTop: '1px solid var(--secondary-bg)',
          borderBottom: '1px solid var(--secondary-bg)',
        }}>
          Spread: {(Number(asks[0]?.price) - Number(bids[0]?.price)).toLocaleString()} UZS
        </div>
      )}

      {/* Bids */}
      <div style={{ maxHeight: 160, overflow: 'auto' }}>
        {bids.map((b) => renderRow(b, 'bid'))}
      </div>
    </div>
  );
}
