export default function BadgeCard({ badge, earned }) {
  const icons = { bronze: '🥉', silver: '🥈', gold: '🥇', diamond: '💎' };
  return (
    <div className="card" style={{
      textAlign: 'center',
      opacity: earned ? 1 : 0.4,
      border: earned ? `2px solid ${badge.color || 'var(--accent-text)'}` : '2px solid transparent',
    }}>
      <div style={{ fontSize: '36px', marginBottom: '4px' }}>{icons[badge.type] || '🏅'}</div>
      <div style={{ fontWeight: 600, fontSize: '14px' }}>{badge.name}</div>
      <div className="text-hint" style={{ fontSize: '12px' }}>{badge.required_streak} {badge.required_streak === 1 ? 'kun' : 'kun'}</div>
      {earned && badge.awarded_at && (
        <div className="text-accent" style={{ fontSize: '11px', marginTop: '4px' }}>✅ {new Date(badge.awarded_at).toLocaleDateString()}</div>
      )}
      {!earned && <div className="text-hint" style={{ fontSize: '11px', marginTop: '4px' }}>🎁 {badge.reward_ais} AIS</div>}
    </div>
  );
}
