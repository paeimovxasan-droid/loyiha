import { useState, useRef, useCallback } from 'react';
import client from '../api/client';
import { useLang } from '../contexts/LangContext';

export default function VideoKyc({ onComplete }) {
  const [step, setStep] = useState('start'); // start, recording, uploading, done
  const [code, setCode] = useState(null);
  const [expiresAt, setExpiresAt] = useState(null);
  const [error, setError] = useState(null);
  const [progress, setProgress] = useState(0);
  const videoRef = useRef(null);
  const mediaRecorderRef = useRef(null);
  const chunksRef = useRef([]);
  const { t } = useLang();

  const startVideo = useCallback(async () => {
    setError(null);
    try {
      const res = await client.post('/kyc/video/start');
      if (res.data?.success) {
        setCode(res.data.data.code);
        setExpiresAt(res.data.data.expires_at);
        setStep('recording');

        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: true });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }

        const recorder = new MediaRecorder(stream, { mimeType: 'video/webm' });
        chunksRef.current = [];
        recorder.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
        recorder.onstop = () => { stream.getTracks().forEach((t) => t.stop()); };
        mediaRecorderRef.current = recorder;
        recorder.start();

        // 15 soniyadan keyin avtomatik to'xtatish
        setTimeout(() => { if (recorder.state === 'recording') stopRecording(); }, 15000);
      }
    } catch (err) {
      setError(err.response?.data?.message || t('error'));
    }
  }, [t]);

  const stopRecording = useCallback(async () => {
    const recorder = mediaRecorderRef.current;
    if (!recorder || recorder.state !== 'recording') return;

    recorder.stop();
    setStep('uploading');

    // Kichik kutish — chunks to'planishi uchun
    await new Promise((r) => setTimeout(r, 500));

    const blob = new Blob(chunksRef.current, { type: 'video/webm' });
    const formData = new FormData();
    formData.append('video', blob, 'kyc-video.webm');

    try {
      await client.post('/kyc/video/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        onUploadProgress: (e) => { setProgress(Math.round((e.loaded / e.total) * 100)); },
      });
      setStep('done');
      onComplete?.();
    } catch (err) {
      setError(err.response?.data?.message || t('error'));
      setStep('start');
    }
  }, [onComplete, t]);

  return (
    <div className="card">
      {error && <div className="text-destructive mb-8">{error}</div>}

      {step === 'start' && (
        <div className="text-center">
          <div style={{ fontSize: '48px', marginBottom: '12px' }}>🎥</div>
          <p className="mb-16">Video KYC orqali shaxsingizni tasdiqlang. Yuzingizni, pasportingizni va ekrandagi kodni ko'rsating.</p>
          <button className="btn btn-primary" onClick={startVideo}>Video KYC boshlash</button>
        </div>
      )}

      {step === 'recording' && (
        <div className="text-center">
          <div style={{ position: 'relative', marginBottom: '12px' }}>
            <video ref={videoRef} style={{ width: '100%', borderRadius: '12px', transform: 'scaleX(-1)' }} muted playsInline />
            <div style={{
              position: 'absolute', top: '12px', left: '50%', transform: 'translateX(-50%)',
              background: 'rgba(0,0,0,0.7)', color: '#fff', padding: '8px 20px', borderRadius: '8px',
              fontSize: '24px', fontWeight: 700, letterSpacing: '8px',
            }}>
              {code}
            </div>
          </div>
          <p className="text-hint mb-8">Kodni ovoz chiqarib ayting: {code}</p>
          <button className="btn btn-primary" onClick={stopRecording}>⏹ To'xtatish va yuborish</button>
        </div>
      )}

      {step === 'uploading' && (
        <div className="text-center">
          <div style={{ fontSize: '48px', marginBottom: '12px' }}>⏳</div>
          <p>Video yuklanmoqda... {progress}%</p>
          <div className="progress-bar mt-8">
            <div className="progress-bar-fill" style={{ width: `${progress}%`, background: 'var(--button-color)' }} />
          </div>
        </div>
      )}

      {step === 'done' && (
        <div className="text-center">
          <div style={{ fontSize: '48px', marginBottom: '12px' }}>✅</div>
          <p>Video yuklandi! Admin ko'rib chiqadi.</p>
        </div>
      )}
    </div>
  );
}
