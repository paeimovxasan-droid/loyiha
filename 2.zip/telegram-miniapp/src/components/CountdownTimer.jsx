import useCountdown from '../hooks/useCountdown';

export default function CountdownTimer({ targetDate }) {
  const { days, hours, minutes, seconds, expired } = useCountdown(targetDate);

  if (expired) return <span className="text-destructive">⏰ Tugagan</span>;

  const items = [
    { val: days, label: 'kun' },
    { val: hours, label: 'soat' },
    { val: minutes, label: 'daq' },
    { val: seconds, label: 'son' },
  ];

  return (
    <div style={{ display: 'flex', gap: '8px', justifyContent: 'center' }}>
      {items.map((it) => (
        <div key={it.label} style={{ textAlign: 'center', minWidth: '48px' }}>
          <div style={{ fontSize: '20px', fontWeight: 700, background: 'var(--secondary-bg)', borderRadius: '8px', padding: '6px 4px' }}>
            {String(it.val).padStart(2, '0')}
          </div>
          <div className="text-hint" style={{ fontSize: '10px', marginTop: '2px' }}>{it.label}</div>
        </div>
      ))}
    </div>
  );
}
