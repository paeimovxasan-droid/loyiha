import { useRef, useEffect, useCallback } from 'react';

const SIZE = 300;
const CENTER = SIZE / 2;
const RADIUS = SIZE / 2 - 10;

export default function SpinWheelCanvas({ prizes = [], spinning, onFinish }) {
  const canvasRef = useRef(null);
  const rotation = useRef(0);
  const animRef = useRef(null);
  const speed = useRef(0);

  const draw = useCallback((rot) => {
    const canvas = canvasRef.current;
    if (!canvas || !prizes.length) return;
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, SIZE, SIZE);
    const arc = (2 * Math.PI) / prizes.length;

    prizes.forEach((p, i) => {
      const startAngle = rot + i * arc;
      ctx.beginPath();
      ctx.moveTo(CENTER, CENTER);
      ctx.arc(CENTER, CENTER, RADIUS, startAngle, startAngle + arc);
      ctx.fillStyle = p.color || `hsl(${(i * 360) / prizes.length}, 70%, 55%)`;
      ctx.fill();
      ctx.strokeStyle = '#fff';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.save();
      ctx.translate(CENTER, CENTER);
      ctx.rotate(startAngle + arc / 2);
      ctx.fillStyle = '#fff';
      ctx.font = 'bold 12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(p.label || '', RADIUS * 0.65, 4);
      ctx.restore();
    });

    // pointer
    ctx.beginPath();
    ctx.moveTo(SIZE - 5, CENTER - 10);
    ctx.lineTo(SIZE - 5, CENTER + 10);
    ctx.lineTo(SIZE - 25, CENTER);
    ctx.fillStyle = 'var(--button-color, #2481cc)';
    ctx.fill();
  }, [prizes]);

  useEffect(() => { draw(rotation.current); }, [draw]);

  useEffect(() => {
    if (!spinning) return;
    speed.current = 0.3 + Math.random() * 0.15;
    const decel = 0.997;
    const animate = () => {
      speed.current *= decel;
      rotation.current += speed.current;
      draw(rotation.current);
      if (speed.current > 0.001) {
        animRef.current = requestAnimationFrame(animate);
      } else {
        onFinish?.();
      }
    };
    animRef.current = requestAnimationFrame(animate);
    return () => { if (animRef.current) cancelAnimationFrame(animRef.current); };
  }, [spinning, draw, onFinish]);

  return <canvas ref={canvasRef} width={SIZE} height={SIZE} style={{ width: '100%', maxWidth: SIZE, display: 'block', margin: '0 auto' }} />;
}
