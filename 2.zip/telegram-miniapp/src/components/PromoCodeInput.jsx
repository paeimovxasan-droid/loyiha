import { useState } from 'react';
import { redeemPromo } from '../api/client';
import { useLang } from '../contexts/LangContext';
import useHaptic from '../hooks/useHaptic';

export default function PromoCodeInput() {
  const [code, setCode] = useState('');
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(false);
  const { t } = useLang();
  const { notificationOccurred } = useHaptic();

  const handleRedeem = async () => {
    if (!code.trim()) return;
    setMsg(null);
    setLoading(true);
    try {
      const res = await redeemPromo(code.trim());
      notificationOccurred('success');
      setMsg({ type: 'success', text: res.data?.data?.message || `🎉 +${res.data?.data?.reward_ais || 0} AIS` });
      setCode('');
    } catch (err) {
      notificationOccurred('error');
      setMsg({ type: 'error', text: err.response?.data?.message || t('error') });
    } finally { setLoading(false); }
  };

  return (
    <div className="card">
      <div style={{ fontWeight: 600, marginBottom: '8px' }}>🎟️ {t('promo_code')}</div>
      {msg && <div className={`mb-8 ${msg.type === 'error' ? 'text-destructive' : 'text-accent'}`} style={{ fontSize: '13px' }}>{msg.text}</div>}
      <div className="flex gap-8">
        <input
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase())}
          placeholder={t('enter_promo_code')}
          style={{ flex: 1 }}
        />
        <button className="btn btn-primary" onClick={handleRedeem} disabled={loading} style={{ width: 'auto', padding: '12px 16px' }}>
          {loading ? '⏳' : '✅'}
        </button>
      </div>
    </div>
  );
}
