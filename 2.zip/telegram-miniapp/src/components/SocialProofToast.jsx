import useSocialProof from '../hooks/useSocialProof';

const typeIcons = {
  new_user: '👤',
  package_purchase: '📦',
  level_up: '⬆️',
  badge_earned: '🏅',
  withdrawal: '💸',
  deposit: '💰',
};

export default function SocialProofToast() {
  const { event, visible } = useSocialProof();

  if (!event || !visible) return null;

  return (
    <div style={{
      position: 'fixed',
      bottom: '80px',
      left: '16px',
      right: '16px',
      background: 'var(--section-bg)',
      borderRadius: '12px',
      padding: '12px 16px',
      boxShadow: '0 4px 20px rgba(0,0,0,0.15)',
      zIndex: 200,
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      animation: 'slideUp 0.3s ease-out',
    }}>
      <span style={{ fontSize: '24px' }}>{typeIcons[event.type] || '🔔'}</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 600, fontSize: '13px' }}>{event.masked_name}</div>
        <div className="text-hint" style={{ fontSize: '12px' }}>
          {event.type?.replace(/_/g, ' ')} {event.amount ? `· ${event.amount}` : ''} · {event.time_ago}
        </div>
      </div>
      <style>{`
        @keyframes slideUp {
          from { transform: translateY(100%); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
      `}</style>
    </div>
  );
}
