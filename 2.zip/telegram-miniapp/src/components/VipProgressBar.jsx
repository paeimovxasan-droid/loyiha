const tierColors = { free: '#9ca3af', silver: '#94a3b8', gold: '#f59e0b', platinum: '#8b5cf6' };
const tierIcons = { free: '⭐', silver: '🥈', gold: '🥇', platinum: '💎' };

export default function VipProgressBar({ currentTier, nextTier, progress }) {
  const color = tierColors[currentTier] || 'var(--button-color)';

  return (
    <div className="card">
      <div className="flex justify-between items-center mb-8">
        <div>
          <span style={{ fontSize: '24px' }}>{tierIcons[currentTier] || '⭐'}</span>
          <span style={{ fontWeight: 700, marginLeft: '8px', textTransform: 'capitalize' }}>{currentTier}</span>
        </div>
        {nextTier && (
          <div className="text-hint" style={{ fontSize: '12px' }}>
            → {tierIcons[nextTier.name] || '⭐'} {nextTier.name}
          </div>
        )}
      </div>

      {nextTier && progress && (
        <>
          <div style={{ fontSize: '12px', marginBottom: '4px' }}>
            AIS: {Number(progress.total_ais_earned || 0).toLocaleString()} / {Number(nextTier.min_ais_earned || 0).toLocaleString()}
          </div>
          <div className="progress-bar mb-8">
            <div className="progress-bar-fill" style={{
              width: `${nextTier.min_ais_earned ? Math.min((progress.total_ais_earned / nextTier.min_ais_earned) * 100, 100) : 0}%`,
              background: color,
            }} />
          </div>
          <div style={{ fontSize: '12px', marginBottom: '4px' }}>
            Referrallar: {progress.total_referrals || 0} / {nextTier.min_referrals || 0}
          </div>
          <div className="progress-bar">
            <div className="progress-bar-fill" style={{
              width: `${nextTier.min_referrals ? Math.min((progress.total_referrals / nextTier.min_referrals) * 100, 100) : 0}%`,
              background: color,
            }} />
          </div>
        </>
      )}
    </div>
  );
}
