export default function OnboardingStep({ step, isCurrent }) {
  const icons = { 1: '👤', 2: '🪪', 3: '💰', 4: '📦', 5: '👥' };
  return (
    <div className="card" style={{
      border: isCurrent ? '2px solid var(--button-color)' : '2px solid transparent',
      opacity: step.completed ? 1 : isCurrent ? 1 : 0.5,
    }}>
      <div className="flex items-center gap-8">
        <div style={{ fontSize: '28px', minWidth: '36px', textAlign: 'center' }}>
          {step.completed ? '✅' : icons[step.step] || '📋'}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 600, fontSize: '14px' }}>{step.title}</div>
          {step.description && <div className="text-hint" style={{ fontSize: '12px' }}>{step.description}</div>}
        </div>
        <div style={{ textAlign: 'right' }}>
          <div className="text-accent" style={{ fontWeight: 600, fontSize: '13px' }}>+{step.reward_ais} AIS</div>
          {step.completed_at && <div className="text-hint" style={{ fontSize: '10px' }}>{new Date(step.completed_at).toLocaleDateString()}</div>}
        </div>
      </div>
    </div>
  );
}
