import CountdownTimer from './CountdownTimer';

export default function EventBanner({ event, onClick }) {
  return (
    <div className="card" onClick={onClick} style={{ cursor: onClick ? 'pointer' : 'default', overflow: 'hidden', padding: 0 }}>
      {event.banner_url && (
        <img src={event.banner_url} alt={event.name} style={{ width: '100%', height: '140px', objectFit: 'cover' }} />
      )}
      <div style={{ padding: '12px 16px' }}>
        <div style={{ fontWeight: 700, fontSize: '16px', marginBottom: '4px' }}>{event.name}</div>
        {event.description && <div className="text-hint mb-8" style={{ fontSize: '13px' }}>{event.description}</div>}
        <CountdownTimer targetDate={event.ends_at} />
      </div>
    </div>
  );
}
