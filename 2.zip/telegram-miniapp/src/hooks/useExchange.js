import { useState, useEffect, useCallback, useRef } from 'react';
import {
  getOrderBook, getTicker, getRecentTrades, getCandles,
  placeOrder as placeOrderApi, cancelOrder as cancelOrderApi,
  getMyOpenOrders, getMyOrderHistory, getMyTrades,
} from '../api/client';

export default function useExchange() {
  const [ticker, setTicker] = useState(null);
  const [orderBook, setOrderBook] = useState({ bids: [], asks: [] });
  const [recentTrades, setRecentTrades] = useState([]);
  const [candles, setCandles] = useState([]);
  const [openOrders, setOpenOrders] = useState([]);
  const [orderHistory, setOrderHistory] = useState([]);
  const [myTrades, setMyTrades] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const intervalRef = useRef(null);

  const fetchPublic = useCallback(async () => {
    try {
      const [tickerRes, obRes, tradesRes] = await Promise.all([
        getTicker(), getOrderBook(), getRecentTrades(),
      ]);
      if (tickerRes.data?.success) setTicker(tickerRes.data.data);
      if (obRes.data?.success) setOrderBook(obRes.data.data);
      if (tradesRes.data?.success) setRecentTrades(tradesRes.data.data?.trades || tradesRes.data.data || []);
    } catch {} finally { setLoading(false); }
  }, []);

  const fetchMyOrders = useCallback(async () => {
    try {
      const res = await getMyOpenOrders();
      if (res.data?.success) setOpenOrders(res.data.data?.orders || res.data.data || []);
    } catch {}
  }, []);

  const fetchOrderHistory = useCallback(async (page = 1) => {
    try {
      const res = await getMyOrderHistory(page);
      if (res.data?.success) setOrderHistory(res.data.data?.orders || res.data.data || []);
    } catch {}
  }, []);

  const fetchMyTrades = useCallback(async (page = 1) => {
    try {
      const res = await getMyTrades(page);
      if (res.data?.success) setMyTrades(res.data.data?.trades || res.data.data || []);
    } catch {}
  }, []);

  const fetchCandles = useCallback(async (interval = '1h') => {
    try {
      const res = await getCandles(interval);
      if (res.data?.success) setCandles(res.data.data?.candles || res.data.data || []);
    } catch {}
  }, []);

  const placeOrder = useCallback(async (data) => {
    setSubmitting(true);
    try {
      const res = await placeOrderApi(data);
      if (res.data?.success) {
        fetchPublic();
        fetchMyOrders();
      }
      return res.data;
    } finally { setSubmitting(false); }
  }, [fetchPublic, fetchMyOrders]);

  const doCancelOrder = useCallback(async (orderId) => {
    try {
      const res = await cancelOrderApi(orderId);
      if (res.data?.success) {
        fetchPublic();
        fetchMyOrders();
      }
      return res.data;
    } catch (err) { throw err; }
  }, [fetchPublic, fetchMyOrders]);

  // Initial fetch + polling every 5s
  useEffect(() => {
    fetchPublic();
    fetchMyOrders();
    intervalRef.current = setInterval(() => {
      fetchPublic();
    }, 5000);
    return () => clearInterval(intervalRef.current);
  }, [fetchPublic, fetchMyOrders]);

  return {
    ticker, orderBook, recentTrades, candles, openOrders,
    orderHistory, myTrades, loading, submitting,
    fetchPublic, fetchMyOrders, fetchOrderHistory, fetchMyTrades,
    fetchCandles, placeOrder, cancelOrder: doCancelOrder,
  };
}
