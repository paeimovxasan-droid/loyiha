import { useState, useCallback } from 'react';
import { getSpinWheel, spin as spinApi } from '../api/client';

export default function useSpinWheel() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState(null);

  const fetch = useCallback(async () => {
    setLoading(true);
    try {
      const res = await getSpinWheel();
      if (res.data?.success) setData(res.data.data);
    } catch {} finally { setLoading(false); }
  }, []);

  const doSpin = useCallback(async () => {
    setSpinning(true);
    setResult(null);
    try {
      const res = await spinApi();
      if (res.data?.success) {
        setResult(res.data.data);
        setData((prev) => prev ? { ...prev, can_spin: false, next_spin_at: res.data.data.next_spin_at } : prev);
      }
      return res.data?.data;
    } catch (err) {
      throw err;
    } finally { setSpinning(false); }
  }, []);

  return { data, loading, spinning, result, fetch, doSpin };
}
