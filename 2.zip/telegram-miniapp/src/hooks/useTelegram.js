import { useMemo } from 'react';

const tg = window.Telegram?.WebApp;

export default function useTelegram() {
  const user = useMemo(() => tg?.initDataUnsafe?.user || null, []);
  const initData = useMemo(() => tg?.initData || '', []);
  const colorScheme = tg?.colorScheme || 'light';
  const themeParams = tg?.themeParams || {};

  const expand = () => tg?.expand();
  const close = () => tg?.close();
  const ready = () => tg?.ready();

  const showMainButton = (text, onClick) => {
    if (!tg?.MainButton) return;
    tg.MainButton.setText(text);
    tg.MainButton.onClick(onClick);
    tg.MainButton.show();
  };

  const hideMainButton = () => tg?.MainButton?.hide();

  const showBackButton = (onClick) => {
    if (!tg?.BackButton) return;
    tg.BackButton.onClick(onClick);
    tg.BackButton.show();
  };

  const hideBackButton = () => tg?.BackButton?.hide();

  return {
    tg,
    user,
    initData,
    colorScheme,
    themeParams,
    expand,
    close,
    ready,
    showMainButton,
    hideMainButton,
    showBackButton,
    hideBackButton,
  };
}
