import { useState, useEffect, useRef } from 'react';
import { getSocialProof } from '../api/client';

export default function useSocialProof(intervalMs = 12000) {
  const [event, setEvent] = useState(null);
  const [visible, setVisible] = useState(false);
  const idx = useRef(0);
  const events = useRef([]);

  useEffect(() => {
    let timer;
    const fetchAndRotate = async () => {
      try {
        const res = await getSocialProof();
        if (res.data?.success) events.current = res.data.data?.events || [];
      } catch {}
    };
    fetchAndRotate();

    timer = setInterval(() => {
      const list = events.current;
      if (!list.length) return;
      setEvent(list[idx.current % list.length]);
      setVisible(true);
      idx.current++;
      setTimeout(() => setVisible(false), 4000);
    }, intervalMs);

    return () => clearInterval(timer);
  }, [intervalMs]);

  return { event, visible };
}
