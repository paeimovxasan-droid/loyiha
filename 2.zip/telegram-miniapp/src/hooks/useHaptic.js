const tg = window.Telegram?.WebApp;

export default function useHaptic() {
  const impactOccurred = (style = 'medium') => {
    tg?.HapticFeedback?.impactOccurred(style);
  };

  const notificationOccurred = (type = 'success') => {
    tg?.HapticFeedback?.notificationOccurred(type);
  };

  const selectionChanged = () => {
    tg?.HapticFeedback?.selectionChanged();
  };

  return { impactOccurred, notificationOccurred, selectionChanged };
}
