<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Front\HomeController;
use App\Http\Controllers\Front\AuthController;
use App\Http\Controllers\Front\DashboardController;

/*
|--------------------------------------------------------------------------
| Frontend Routes
|--------------------------------------------------------------------------
*/

// ─── Public (Landing) ──────────────────────────────────────────────
Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/presentation', function () {
    return redirect('/');
})->name('presentation');

// PWA offline sahifasi
Route::get('/offline', function () {
    return view('front.pages.offline');
})->name('offline');

// PWA Manifest (dinamik — DB'dan site name va logo oladi)
Route::get('/manifest.json', function () {
    $setting = \App\Models\Setting::get();
    $siteName = $setting->getTranslation('site_name', 'uz') ?: config('app.name');
    $siteDesc = $setting->getTranslation('site_description', 'uz') ?: 'Investitsiya va moliyaviy platforma';

    $manifest = [
        'name'             => $siteName,
        'short_name'       => mb_substr($siteName, 0, 12),
        'description'      => $siteDesc,
        'start_url'        => '/app',
        'scope'            => '/',
        'display'          => 'standalone',
        'orientation'      => 'portrait',
        'background_color' => '#0f172a',
        'theme_color'      => '#6366f1',
        'lang'             => 'uz',
        'categories'       => ['finance', 'business'],
        'icons'            => [
            ['src' => '/images/pwa/icon-72.png',  'sizes' => '72x72',   'type' => 'image/png', 'purpose' => 'any maskable'],
            ['src' => '/images/pwa/icon-96.png',  'sizes' => '96x96',   'type' => 'image/png', 'purpose' => 'any maskable'],
            ['src' => '/images/pwa/icon-128.png', 'sizes' => '128x128', 'type' => 'image/png', 'purpose' => 'any maskable'],
            ['src' => '/images/pwa/icon-144.png', 'sizes' => '144x144', 'type' => 'image/png', 'purpose' => 'any maskable'],
            ['src' => '/images/pwa/icon-152.png', 'sizes' => '152x152', 'type' => 'image/png', 'purpose' => 'any maskable'],
            ['src' => '/images/pwa/icon-192.png', 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable'],
            ['src' => '/images/pwa/icon-384.png', 'sizes' => '384x384', 'type' => 'image/png', 'purpose' => 'any maskable'],
            ['src' => '/images/pwa/icon-512.png', 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any maskable'],
        ],
        'shortcuts' => [
            ['name' => 'Depozit', 'short_name' => 'Depozit', 'url' => '/app/deposit', 'icons' => [['src' => '/images/pwa/icon-96.png', 'sizes' => '96x96']]],
            ['name' => 'Wallet',  'short_name' => 'Wallet',  'url' => '/app/wallet',  'icons' => [['src' => '/images/pwa/icon-96.png', 'sizes' => '96x96']]],
            ['name' => 'Paketlar','short_name' => 'Paketlar','url' => '/app/packages','icons' => [['src' => '/images/pwa/icon-96.png', 'sizes' => '96x96']]],
        ],
        'prefer_related_applications' => false,
    ];

    return response()->json($manifest)
        ->header('Content-Type', 'application/manifest+json')
        ->header('Cache-Control', 'public, max-age=3600');
})->name('pwa.manifest');

// ─── Auth (Relaxed throttles for production) ─────────────────────────
Route::middleware(['guest', 'throttle:60,1'])->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.post');
    Route::get('/register/{ref}', [AuthController::class, 'showRegister'])->name('register.ref');

    // Password reset
    Route::get('/forgot-password', [\App\Http\Controllers\Front\PasswordResetController::class, 'showForgot'])->name('password.forgot');
    Route::post('/forgot-password', [\App\Http\Controllers\Front\PasswordResetController::class, 'sendResetLink'])->name('password.send')->middleware('throttle:3,60');
    Route::get('/reset-password/{token}', [\App\Http\Controllers\Front\PasswordResetController::class, 'showReset'])->name('password.reset');
    Route::post('/reset-password', [\App\Http\Controllers\Front\PasswordResetController::class, 'reset'])->name('password.update')->middleware('throttle:5,60');
});

Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// ─── Huquqiy sahifalar ─────────────────────────────────────────────
Route::prefix('legal')->name('legal.')->group(function () {
    Route::get('/terms', fn() => view('front.pages.legal.terms', ['setting' => \App\Models\Setting::get()]))->name('terms');
    Route::get('/privacy', fn() => view('front.pages.legal.privacy', ['setting' => \App\Models\Setting::get()]))->name('privacy');
    Route::get('/ais-rules', fn() => view('front.pages.legal.ais-rules', ['setting' => \App\Models\Setting::get()]))->name('ais-rules');
    Route::get('/deposit-withdraw', fn() => view('front.pages.legal.deposit-withdraw', ['setting' => \App\Models\Setting::get()]))->name('deposit-withdraw');
    Route::get('/risk-disclaimer', fn() => view('front.pages.legal.risk-disclaimer', ['setting' => \App\Models\Setting::get()]))->name('risk-disclaimer');
    Route::get('/referral', fn() => view('front.pages.legal.referral', ['setting' => \App\Models\Setting::get()]))->name('referral');
    Route::get('/kyc', fn() => view('front.pages.legal.kyc', ['setting' => \App\Models\Setting::get()]))->name('kyc');
    Route::get('/cookies', fn() => view('front.pages.legal.cookies', ['setting' => \App\Models\Setting::get()]))->name('cookies');
    Route::get('/refund', fn() => view('front.pages.legal.refund', ['setting' => \App\Models\Setting::get()]))->name('refund');
    Route::get('/anti-fraud', fn() => view('front.pages.legal.anti-fraud', ['setting' => \App\Models\Setting::get()]))->name('anti-fraud');
});

// ─── Authenticated User Area ───────────────────────────────────────
Route::middleware([
        \App\Http\Middleware\Front\AuthMiddleware::class,
        \App\Http\Middleware\Front\RequireFirstDeposit::class,
    ])
    ->prefix('app')
    ->name('app.')
    ->group(function () {
        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');
        Route::get('/profile', [DashboardController::class, 'profile'])->name('profile');
        Route::put('/profile', [DashboardController::class, 'updateProfile'])->name('profile.update');
        Route::put('/profile/password', [DashboardController::class, 'updatePassword'])->name('profile.password');

        // Packages
        Route::get('/packages', [\App\Http\Controllers\Front\PackageController::class, 'index'])->name('packages');
        Route::post('/packages/{package}/buy', [\App\Http\Controllers\Front\PackageController::class, 'buy'])->name('packages.buy')->middleware('throttle:30,1');

        // Deposits
        Route::get('/deposit', [\App\Http\Controllers\Front\DepositController::class, 'index'])->name('deposit');
        Route::post('/deposit', [\App\Http\Controllers\Front\DepositController::class, 'store'])->name('deposit.store')->middleware(['throttle:10,1', 'kyc.required']);

        // Withdrawals
        Route::get('/withdraw', [\App\Http\Controllers\Front\WithdrawalController::class, 'index'])->name('withdraw');
        Route::post('/withdraw', [\App\Http\Controllers\Front\WithdrawalController::class, 'store'])->name('withdraw.store')->middleware(['throttle:20,1', 'kyc.required']);

        // Referrals
        Route::get('/referrals', [\App\Http\Controllers\Front\ReferralController::class, 'index'])->name('referrals');

        // Transactions
        Route::get('/transactions', [\App\Http\Controllers\Front\TransactionController::class, 'index'])->name('transactions');

        // Check-in
        Route::post('/checkin', [\App\Http\Controllers\Front\CheckInController::class, 'store'])->name('checkin');

        // ── AIS Wallet ────────────────────────────────────────────────────────
        Route::get('/wallet', [\App\Http\Controllers\Front\WalletController::class, 'index'])->name('wallet');
        Route::post('/wallet/transfer', [\App\Http\Controllers\Front\WalletController::class, 'transfer'])->name('wallet.transfer')->middleware(['throttle:5,5', 'kyc.required']);
        Route::post('/wallet/convert', [\App\Http\Controllers\Front\WalletController::class, 'convert'])->name('wallet.convert')->middleware('throttle:10,1');
        Route::get('/wallet/card/create', [\App\Http\Controllers\Front\WalletController::class, 'createCard'])->name('wallet.card.create');
        Route::post('/wallet/card', [\App\Http\Controllers\Front\WalletController::class, 'storeCard'])->name('wallet.card.store');
        Route::post('/wallet/card/{card}/freeze', [\App\Http\Controllers\Front\WalletController::class, 'freezeCard'])->name('wallet.card.freeze');

        // ── Level / XP ────────────────────────────────────────────────────────
        Route::get('/level', [\App\Http\Controllers\Front\LevelController::class, 'index'])->name('level');
        Route::get('/leaderboard', [\App\Http\Controllers\Front\LevelController::class, 'leaderboard'])->name('leaderboard');

        // ── Spin Wheel ────────────────────────────────────────────────────────────
        Route::get('/spin-wheel', [\App\Http\Controllers\Front\SpinWheelController::class, 'index'])->name('spin_wheel');
        Route::post('/spin-wheel/spin', [\App\Http\Controllers\Front\SpinWheelController::class, 'spin'])->name('spin_wheel.spin')->middleware('throttle:3,1');

        // ── Lucky Draw ────────────────────────────────────────────────────────
        Route::get('/lucky-draw', [\App\Http\Controllers\Front\LuckyDrawController::class, 'index'])->name('lucky_draw');
        Route::post('/lucky-draw/{draw}/buy', [\App\Http\Controllers\Front\LuckyDrawController::class, 'buy'])->name('lucky_draw.buy');

        // ── Tasks ─────────────────────────────────────────────────────────────
        Route::get('/tasks', [\App\Http\Controllers\Front\TaskController::class, 'index'])->name('tasks');
        Route::post('/tasks/{task}/submit', [\App\Http\Controllers\Front\TaskController::class, 'submit'])->name('tasks.submit');

        // ── Funds ─────────────────────────────────────────────────────────────
        Route::get('/funds', [\App\Http\Controllers\Front\FundController::class, 'index'])->name('funds');
        Route::post('/funds/{fund}/invest', [\App\Http\Controllers\Front\FundController::class, 'invest'])->name('funds.invest')->middleware('throttle:5,1');

        // ── KYC ───────────────────────────────────────────────────────────────
        Route::get('/kyc', [\App\Http\Controllers\Front\KycController::class, 'index'])->name('kyc');
        Route::post('/kyc/passport', [\App\Http\Controllers\Front\KycController::class, 'submitPassport'])->name('kyc.passport')->middleware('throttle:3,60');
        Route::post('/kyc/face/start', [\App\Http\Controllers\Front\KycController::class, 'startFaceId'])->name('kyc.face.start')->middleware('throttle:5,1');
        Route::post('/kyc/face/submit', [\App\Http\Controllers\Front\KycController::class, 'submitFaceId'])->name('kyc.face.submit')->middleware('throttle:3,1');

        // ── Quests ────────────────────────────────────────────────────────────
        Route::get('/quests', [\App\Http\Controllers\Front\QuestController::class, 'index'])->name('quests');
        Route::post('/quests/{userQuest}/claim', [\App\Http\Controllers\Front\QuestController::class, 'claim'])->name('quests.claim');

        // ── Roadmap ───────────────────────────────────────────────────────────
        Route::get('/roadmap', [\App\Http\Controllers\Front\RoadmapPageController::class, 'index'])->name('roadmap');
        Route::post('/roadmap/{module}/vote', [\App\Http\Controllers\Front\RoadmapPageController::class, 'vote'])->name('roadmap.vote');

        // ── Crowdfunding ──────────────────────────────────────────────────────
        Route::get('/crowdfunding/create', [\App\Http\Controllers\Front\CrowdfundingPageController::class, 'create'])->name('crowdfunding.create');
        Route::post('/crowdfunding', [\App\Http\Controllers\Front\CrowdfundingPageController::class, 'store'])->name('crowdfunding.store');
        Route::get('/crowdfunding', [\App\Http\Controllers\Front\CrowdfundingPageController::class, 'index'])->name('crowdfunding');
        Route::post('/crowdfunding/{project}/donate', [\App\Http\Controllers\Front\CrowdfundingPageController::class, 'donate'])->name('crowdfunding.donate')->middleware('throttle:5,1');

        // ── Exchange ──────────────────────────────────────────────────────────
        Route::get('/exchange', [\App\Http\Controllers\Front\ExchangePageController::class, 'index'])->name('exchange');
        Route::post('/exchange/order', [\App\Http\Controllers\Front\ExchangePageController::class, 'order'])->name('exchange.order')->middleware('throttle:10,1');

        // ── Marketplace ───────────────────────────────────────────────────────
        Route::get('/marketplace', [\App\Http\Controllers\Front\MarketplacePageController::class, 'index'])->name('marketplace');

        // ── Education ─────────────────────────────────────────────────────────
        Route::get('/education/create', [\App\Http\Controllers\Front\EducationPageController::class, 'create'])->name('education.create');
        Route::post('/education', [\App\Http\Controllers\Front\EducationPageController::class, 'store'])->name('education.store');
        Route::get('/education', [\App\Http\Controllers\Front\EducationPageController::class, 'index'])->name('education');

        // ── Catalog ───────────────────────────────────────────────────────────
        Route::get('/catalog/shop/create', [\App\Http\Controllers\Front\CatalogPageController::class, 'createShop'])->name('catalog.shop.create');
        Route::post('/catalog/shop', [\App\Http\Controllers\Front\CatalogPageController::class, 'storeShop'])->name('catalog.shop.store');
        Route::get('/catalog/product/create', [\App\Http\Controllers\Front\CatalogPageController::class, 'createProduct'])->name('catalog.product.create');
        Route::post('/catalog/product', [\App\Http\Controllers\Front\CatalogPageController::class, 'storeProduct'])->name('catalog.product.store');
        Route::get('/catalog', [\App\Http\Controllers\Front\CatalogPageController::class, 'index'])->name('catalog');

        // ── Credit ────────────────────────────────────────────────────────────
        Route::get('/credit', [\App\Http\Controllers\Front\CreditPageController::class, 'index'])->name('credit');
        Route::post('/credit/apply', [\App\Http\Controllers\Front\CreditPageController::class, 'apply'])->name('credit.apply')->middleware('throttle:3,1');

        // ── Savings ───────────────────────────────────────────────────────────
        Route::get('/savings', [\App\Http\Controllers\Front\SavingsPageController::class, 'index'])->name('savings');
        Route::post('/savings/create', [\App\Http\Controllers\Front\SavingsPageController::class, 'create'])->name('savings.create')->middleware('throttle:3,1');

        // ── Gig Economy ───────────────────────────────────────────────────────
        Route::get('/gig/create', [\App\Http\Controllers\Front\GigPageController::class, 'create'])->name('gig.create');
        Route::post('/gig', [\App\Http\Controllers\Front\GigPageController::class, 'store'])->name('gig.store');
        Route::get('/gig', [\App\Http\Controllers\Front\GigPageController::class, 'index'])->name('gig');

        // ── AgroMarket ────────────────────────────────────────────────────────
        Route::get('/agromarket/create', [\App\Http\Controllers\Front\AgroMarketPageController::class, 'create'])->name('agromarket.create');
        Route::post('/agromarket', [\App\Http\Controllers\Front\AgroMarketPageController::class, 'store'])->name('agromarket.store');
        Route::get('/agromarket', [\App\Http\Controllers\Front\AgroMarketPageController::class, 'index'])->name('agromarket');

        // ── P2P Lending ───────────────────────────────────────────────────────
        Route::get('/lending/create', [\App\Http\Controllers\Front\LendingPageController::class, 'createOffer'])->name('lending.create');
        Route::post('/lending', [\App\Http\Controllers\Front\LendingPageController::class, 'storeOffer'])->name('lending.store');
        Route::post('/lending/{offer}/borrow', [\App\Http\Controllers\Front\LendingPageController::class, 'borrow'])->name('lending.borrow')->middleware('throttle:5,1');
        Route::get('/lending', [\App\Http\Controllers\Front\LendingPageController::class, 'index'])->name('lending');

        // ── AI Yordamchi ──────────────────────────────────────────────────────
        Route::get('/ai-assistant', [\App\Http\Controllers\Front\AiAssistantController::class, 'index'])->name('ai');
        Route::post('/ai-assistant', [\App\Http\Controllers\Front\AiAssistantController::class, 'send'])->name('ai.send');

        // ── Influencer Ad Network ─────────────────────────────────────────────
        Route::prefix('influencer')->name('influencer.')->group(function () {            Route::get('/', [\App\Http\Controllers\Front\Influencer\InfluencerDashboardController::class, 'index'])->name('dashboard');
            Route::get('/channels', [\App\Http\Controllers\Front\Influencer\InfluencerChannelController::class, 'index'])->name('channels');
            Route::post('/channels', [\App\Http\Controllers\Front\Influencer\InfluencerChannelController::class, 'store'])->name('channels.store');
            Route::delete('/channels/{channel}', [\App\Http\Controllers\Front\Influencer\InfluencerChannelController::class, 'destroy'])->name('channels.destroy');
            Route::get('/campaigns', [\App\Http\Controllers\Front\Influencer\InfluencerCampaignController::class, 'index'])->name('campaigns');
            Route::get('/submissions', [\App\Http\Controllers\Front\Influencer\InfluencerSubmissionController::class, 'index'])->name('submissions');
            Route::post('/submissions', [\App\Http\Controllers\Front\Influencer\InfluencerSubmissionController::class, 'store'])->name('submissions.store')->middleware('throttle:10,1');
        });

        // ── Support Tickets ───────────────────────────────────────────────────
        Route::prefix('support')->name('support.')->group(function () {
            Route::get('/', [\App\Http\Controllers\Front\SupportTicketController::class, 'index'])->name('index');
            Route::get('/create', [\App\Http\Controllers\Front\SupportTicketController::class, 'create'])->name('create');
            Route::post('/', [\App\Http\Controllers\Front\SupportTicketController::class, 'store'])->name('store')->middleware('throttle:5,1');
            Route::get('/{ticket}', [\App\Http\Controllers\Front\SupportTicketController::class, 'show'])->name('show');
            Route::post('/{ticket}/reply', [\App\Http\Controllers\Front\SupportTicketController::class, 'reply'])->name('reply')->middleware('throttle:10,1');
            Route::post('/{ticket}/close', [\App\Http\Controllers\Front\SupportTicketController::class, 'close'])->name('close');
        });

        // ── Tibbiyot xizmatlari ───────────────────────────────────────────────
        Route::prefix('medical')->name('medical.')->group(function () {
            Route::get('/', [\App\Http\Controllers\Front\MedicalPageController::class, 'index'])->name('index');
            Route::get('/doctors', [\App\Http\Controllers\Front\MedicalPageController::class, 'doctors'])->name('doctors');
            Route::get('/doctors/{doctorProfile}', [\App\Http\Controllers\Front\MedicalPageController::class, 'doctorShow'])->name('doctors.show');
            Route::post('/consultations/start', [\App\Http\Controllers\Front\MedicalPageController::class, 'startConsultation'])->name('consultations.start')->middleware('throttle:5,1');
            Route::get('/consultations', [\App\Http\Controllers\Front\MedicalPageController::class, 'consultations'])->name('consultations');
            Route::get('/consultations/{consultation}', [\App\Http\Controllers\Front\MedicalPageController::class, 'consultation'])->name('consultation');
            Route::get('/medicine-orders', [\App\Http\Controllers\Front\MedicalPageController::class, 'medicineOrders'])->name('medicine-orders');
            Route::get('/doctor/create', [\App\Http\Controllers\Front\MedicalPageController::class, 'doctorProfileCreate'])->name('doctor.create');
            Route::get('/doctor/dashboard', [\App\Http\Controllers\Front\MedicalPageController::class, 'doctorDashboard'])->name('doctor.dashboard');
        });
    });
