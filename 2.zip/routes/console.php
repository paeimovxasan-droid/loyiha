<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// ── Scheduler ────────────────────────────────────────────────────────────────
Schedule::command('mining:process')->dailyAt('00:05')->withoutOverlapping(60);
Schedule::command('funds:expire')->dailyAt('00:10')->withoutOverlapping(30);
Schedule::command('packages:expire')->dailyAt('00:15')->withoutOverlapping(10);

// ── Telegram kanal postlari ──────────────────────────────────────────────────
Schedule::command('telegram:daily-stats')->dailyAt('20:00')->withoutOverlapping();
Schedule::command('telegram:weekly-leaderboard')->weeklyOn(1, '12:00')->withoutOverlapping();

// ── Marketing scheduled buyruqlar ───────────────────────────────────────────
Schedule::command('challenge:expire')->hourly()->withoutOverlapping();
Schedule::command('leaderboard:start-weekly')->weeklyOn(1, '00:00')->withoutOverlapping();
Schedule::command('leaderboard:finalize-weekly')->weeklyOn(0, '23:59')->withoutOverlapping();
Schedule::command('leaderboard:start-monthly')->monthlyOn(1, '00:00')->withoutOverlapping();
Schedule::command('leaderboard:finalize-monthly')->lastDayOfMonth('23:59')->withoutOverlapping();
Schedule::command('membership:monthly-review')->monthlyOn(1, '02:00')->withoutOverlapping();
Schedule::command('events:finalize')->hourly()->withoutOverlapping();
Schedule::command('share:process-rewards')->everyThirtyMinutes()->withoutOverlapping();

// ── Exchange scheduled buyruqlar ────────────────────────────────────────
Schedule::command('ohlcv:aggregate')->hourly()->withoutOverlapping();

// ── Credit & Savings scheduled buyruqlar ────────────────────────────────
Schedule::command('credit:check-overdue')->dailyAt('01:00')->withoutOverlapping(10);
Schedule::command('savings:monthly-process')->dailyAt('03:00')->withoutOverlapping(60);
Schedule::command('savings:finalize')->dailyAt('04:00')->withoutOverlapping(30);
Schedule::command('group-savings:process')->dailyAt('05:00')->withoutOverlapping(30);

// ── Influencer Ad Network scheduled buyruqlar ────────────────────────────────
Schedule::command('influencer:expire-campaigns')->hourly()->withoutOverlapping();
Schedule::job(new \App\Jobs\Influencer\SendInfluencerDailyReport)->dailyAt('09:00')->withoutOverlapping();

// ── Lucky Draw avtomatik yakunlash ───────────────────────────────────────────
Schedule::command('lucky-draw:process')->everyFiveMinutes()->withoutOverlapping();

// ── Tibbiyot xizmatlari scheduled buyruqlar ──────────────────────────────────
Schedule::command('medical:expire')->hourly()->withoutOverlapping();
Schedule::command('medical:doctor-monitoring')->dailyAt('06:00')->withoutOverlapping();
Schedule::command('medical:reminder')->hourly()->withoutOverlapping();
