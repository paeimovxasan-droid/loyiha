<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\V1\AuthController;
use App\Http\Controllers\Api\V1\DashboardController;
use App\Http\Controllers\Api\V1\WalletController;
use App\Http\Controllers\Api\V1\PackageController;
use App\Http\Controllers\Api\V1\DepositController;
use App\Http\Controllers\Api\V1\WithdrawalController;
use App\Http\Controllers\Api\V1\LevelController;
use App\Http\Controllers\Api\V1\QuestController;
use App\Http\Controllers\Api\V1\TaskController;
use App\Http\Controllers\Api\V1\CheckInController;
use App\Http\Controllers\Api\V1\LuckyDrawController;
use App\Http\Controllers\Api\V1\FundController;
use App\Http\Controllers\Api\V1\CreditController;
use App\Http\Controllers\Api\V1\SavingsController;
use App\Http\Controllers\Api\V1\GroupSavingsController;
use App\Http\Controllers\Api\V1\KycController;
use App\Http\Controllers\Api\V1\ReferralController;
use App\Http\Controllers\Api\V1\TransactionController;
use App\Http\Controllers\Api\V1\ProfileController;
use App\Http\Controllers\Api\V1\SecurityController;
use App\Http\Controllers\Api\V1\TelegramBotController;
use App\Http\Controllers\Api\V1\PromoCodeController;
use App\Http\Controllers\Api\V1\SpinWheelController;
use App\Http\Controllers\Api\V1\BadgeController;
use App\Http\Controllers\Api\V1\ShareController;
use App\Http\Controllers\Api\V1\InviteChallengeController;
use App\Http\Controllers\Api\V1\OnboardingController;
use App\Http\Controllers\Api\V1\LeaderboardChallengeController;
use App\Http\Controllers\Api\V1\SeasonalEventController;
use App\Http\Controllers\Api\V1\SocialProofController;
use App\Http\Controllers\Api\V1\QrReferralController;
use App\Http\Controllers\Api\V1\ReferralTreeController;
use App\Http\Controllers\Api\V1\VipMembershipController;
use App\Http\Controllers\Api\V1\ExchangeController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| /api/v1/ prefiksi ostida versiyalangan API marshrut fayli.
| Bu yerda barcha API endpointlar ro'yxatdan o'tkaziladi.
|
*/

Route::prefix('v1')->group(function () {

    // ---------------------------------------------------------------
    // Public endpointlar (autentifikatsiya talab qilinmaydi)
    // ---------------------------------------------------------------

    Route::post('auth/telegram', [AuthController::class, 'telegramAuth'])
        ->middleware('throttle:auth-api');

    Route::post('telegram/webhook', [TelegramBotController::class, 'webhook']);

    Route::post('telegram/admin-webhook', [\App\Http\Controllers\Api\AdminTelegramController::class, 'handle']);

    // ---------------------------------------------------------------
    // Himoyalangan endpointlar
    // ---------------------------------------------------------------

    Route::middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {

        // Dashboard
        Route::get('dashboard', [DashboardController::class, 'index']);

        // Wallet
        Route::prefix('wallet')->group(function () {
            Route::get('/', [WalletController::class, 'index']);
            Route::post('transfer', [WalletController::class, 'transfer'])->middleware('throttle:financial-api');
            Route::post('convert', [WalletController::class, 'convert'])->middleware('throttle:financial-api');
            Route::post('card', [WalletController::class, 'createCard'])->middleware('throttle:financial-api');
        });

        // Packages
        Route::get('packages', [PackageController::class, 'index']);
        Route::post('packages/{package}/buy', [PackageController::class, 'buy'])->middleware('throttle:financial-api');

        // Deposits
        Route::get('deposits', [DepositController::class, 'index']);
        Route::post('deposits', [DepositController::class, 'store'])->middleware('throttle:financial-api');

        // Withdrawals
        Route::get('withdrawals', [WithdrawalController::class, 'index']);
        Route::get('withdrawals/scoring', [WithdrawalController::class, 'scoring']);
        Route::post('withdrawals', [WithdrawalController::class, 'store'])->middleware('throttle:financial-api');

        // Level / XP
        Route::get('level', [LevelController::class, 'index']);
        Route::get('level/xp-history', [LevelController::class, 'xpHistory']);
        Route::get('level/leaderboard', [LevelController::class, 'leaderboard']);
        Route::get('level/milestones', [LevelController::class, 'milestones']);

        // Quests
        Route::get('quests', [QuestController::class, 'index']);
        Route::post('quests/{userQuest}/claim', [QuestController::class, 'claim']);
        Route::get('quests/stats', [QuestController::class, 'stats']);

        // Tasks
        Route::get('tasks', [TaskController::class, 'index']);
        Route::post('tasks/{task}/submit', [TaskController::class, 'submit']);

        // Check-in
        Route::post('checkin', [CheckInController::class, 'store']);

        // Lucky Draw
        Route::get('lucky-draw', [LuckyDrawController::class, 'index']);
        Route::post('lucky-draw/{draw}/buy', [LuckyDrawController::class, 'buy'])->middleware('throttle:financial-api');

        // Funds
        Route::get('funds', [FundController::class, 'index']);
        Route::post('funds/{fund}/invest', [FundController::class, 'invest'])->middleware('throttle:financial-api');

        // KYC — Yangi 2-bosqichli tizim
        Route::get('kyc/status', [KycController::class, 'status']);
        Route::post('kyc/passport', [KycController::class, 'submitPassport'])->middleware('throttle:3,60');

        // KYC — Face ID (2-bosqich, faqat passport_verified dan keyin)
        Route::prefix('kyc/face')->group(function () {
            Route::post('start', [\App\Http\Controllers\Api\V1\FaceKycController::class, 'start'])
                ->middleware('throttle:5,1');
            Route::post('submit', [\App\Http\Controllers\Api\V1\FaceKycController::class, 'submit'])
                ->middleware('throttle:3,1');
            Route::get('status', [\App\Http\Controllers\Api\V1\FaceKycController::class, 'status']);
        });

        // Referrals
        Route::get('referrals', [ReferralController::class, 'index']);

        // Transactions
        Route::get('transactions', [TransactionController::class, 'index']);

        // Credits (kredit)
        Route::prefix('credits')->group(function () {
            Route::get('rating', [CreditController::class, 'rating']);
            Route::post('/', [CreditController::class, 'store'])->middleware('throttle:financial-api');
            Route::get('/', [CreditController::class, 'index']);
            Route::post('{credit}/repay', [CreditController::class, 'repay'])->middleware('throttle:financial-api');
        });

        // Savings (jamg'arma)
        Route::prefix('savings')->group(function () {
            Route::post('/', [SavingsController::class, 'store'])->middleware('throttle:financial-api');
            Route::get('/', [SavingsController::class, 'index']);
            Route::get('{plan}', [SavingsController::class, 'show']);
            Route::post('{plan}/cancel', [SavingsController::class, 'cancel'])->middleware('throttle:financial-api');
        });

        // Saving Groups (jamoaviy jamg'arma)
        Route::prefix('saving-groups')->group(function () {
            Route::post('/', [GroupSavingsController::class, 'store'])->middleware('throttle:financial-api');
            Route::get('/', [GroupSavingsController::class, 'index']);
            Route::get('{savingGroup}', [GroupSavingsController::class, 'show']);
            Route::post('{savingGroup}/join', [GroupSavingsController::class, 'join'])->middleware('throttle:financial-api');
            Route::post('{savingGroup}/approve/{member}', [GroupSavingsController::class, 'approve'])->middleware('throttle:financial-api');
        });

        // Profile
        Route::get('profile', [ProfileController::class, 'show']);
        Route::put('profile', [ProfileController::class, 'update']);

        // Security & 2FA
        Route::get('security/2fa', [SecurityController::class, 'getTwoFactorStatus']);
        Route::post('security/2fa/enable', [SecurityController::class, 'enableTwoFactor']);
        Route::post('security/2fa/disable', [SecurityController::class, 'disableTwoFactor']);

        // ---------------------------------------------------------------
        // Marketing modullari
        // ---------------------------------------------------------------

        // Promo-kod
        Route::post('promo/redeem', [PromoCodeController::class, 'redeem'])->middleware('throttle:5,1');

        // Spin Wheel
        Route::get('spin-wheel', [SpinWheelController::class, 'index']);
        Route::post('spin-wheel/spin', [SpinWheelController::class, 'spin'])->middleware('throttle:3,1');

        // Badges
        Route::get('badges', [BadgeController::class, 'index']);

        // Share-to-earn
        Route::get('share', [ShareController::class, 'index']);

        // Invite Challenge
        Route::get('invite-challenge', [InviteChallengeController::class, 'index']);
        Route::post('invite-challenge/start', [InviteChallengeController::class, 'start'])->middleware('throttle:3,1');

        // Onboarding
        Route::get('onboarding', [OnboardingController::class, 'index']);

        // Competitions (Leaderboard)
        Route::get('competitions', [LeaderboardChallengeController::class, 'index']);
        Route::get('competitions/history', [LeaderboardChallengeController::class, 'history']);

        // Seasonal Events
        Route::get('events', [SeasonalEventController::class, 'index']);
        Route::get('events/{event}', [SeasonalEventController::class, 'show']);

        // Social Proof
        Route::get('social-proof', [SocialProofController::class, 'index']);

        // QR Referral
        Route::get('qr-referral', [QrReferralController::class, 'generate']);
        Route::get('qr-referral/download', [QrReferralController::class, 'download']);

        // Referral Tree
        Route::get('referral-tree', [ReferralTreeController::class, 'index']);
        Route::get('referral-tree/level/{level}', [ReferralTreeController::class, 'level']);

        // VIP Membership
        Route::get('vip', [VipMembershipController::class, 'index']);

        // Roadmap
        Route::get('roadmap', [\App\Http\Controllers\Api\V1\RoadmapController::class, 'index']);
        Route::post('roadmap/{id}/vote', [\App\Http\Controllers\Api\V1\RoadmapController::class, 'vote'])->middleware('throttle:10,1');
        Route::post('roadmap/{id}/notify', [\App\Http\Controllers\Api\V1\RoadmapController::class, 'notify'])->middleware('throttle:10,1');
    });

    // ---------------------------------------------------------------
    // Tashqi modullar (Refaktorizatsiya bo'yicha alohida fayllarga ajratildi)
    // ---------------------------------------------------------------
    require __DIR__ . '/api/modules/marketplace.php';
    require __DIR__ . '/api/modules/exchange.php';
    require __DIR__ . '/api/modules/catalog.php';
    require __DIR__ . '/api/modules/education.php';
    require __DIR__ . '/api/modules/services.php';
    require __DIR__ . '/api/modules/medical.php';

    // ---------------------------------------------------------------
    // Public marketing endpointlar (autentifikatsiya talab qilinmaydi)
    // ---------------------------------------------------------------
    Route::get('s/{code}', [ShareController::class, 'track']);
});
