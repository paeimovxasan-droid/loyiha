<?php

use App\Http\Controllers\InstallerController;
use Illuminate\Support\Facades\Route;

// ── Vaqtincha migratsiya route (serverda brauzer orqali) ──────────────
Route::get('/run-update', function () {
    $output = [];
    try {
        \Artisan::call('migrate', ['--force' => true]);
        $output[] = '✅ Migratsiya: ' . \Artisan::output();

        \Artisan::call('db:seed', ['--class' => 'Database\\Seeders\\TranslationSeeder', '--force' => true]);
        $output[] = '✅ Tarjimalar yuklandi';

        // user roli yaratish
        \Spatie\Permission\Models\Role::firstOrCreate(['name' => 'user', 'guard_name' => 'web']);
        \Spatie\Permission\Models\Role::firstOrCreate(['name' => 'super-admin', 'guard_name' => 'web']);
        $output[] = '✅ Rollar yaratildi';

        \Artisan::call('cache:clear');
        \Artisan::call('view:clear');
        $output[] = '✅ Cache tozalandi';

        return '<pre style="font-size:16px;padding:20px;">' . implode("\n", $output) . "\n\n🎉 Yangilanish muvaffaqiyatli!</pre>";
    } catch (\Throwable $e) {
        return '<pre style="color:red;font-size:16px;padding:20px;">❌ Xato: ' . $e->getMessage() . "\n\n" . implode("\n", $output) . '</pre>';
    }
});

Route::prefix('install')->name('install.')->group(function () {
    Route::get('/',          [InstallerController::class, 'welcome'])->name('welcome');
    Route::get('/database',  [InstallerController::class, 'database'])->name('database');
    Route::post('/database', [InstallerController::class, 'databaseSave'])->name('database.save');
    Route::get('/site',      [InstallerController::class, 'site'])->name('site');
    Route::post('/site',     [InstallerController::class, 'siteSave'])->name('site.save');
    Route::get('/admin',     [InstallerController::class, 'admin'])->name('admin');
    Route::post('/admin',    [InstallerController::class, 'adminSave'])->name('admin.save');
    Route::get('/process',   [InstallerController::class, 'process'])->name('process');
    Route::post('/run',      [InstallerController::class, 'run'])->name('run');
    Route::get('/complete',  [InstallerController::class, 'complete'])->name('complete');
});
