<?php

use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\DepositController;
use App\Http\Controllers\Admin\WithdrawalController;
use App\Http\Controllers\Admin\PackageController;
use App\Http\Controllers\Admin\SettingController;
use App\Http\Controllers\Admin\TranslationController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
*/

// ── Auth (himoyasiz) ─────────────────────────────────────────────────────
Route::prefix('admin')->name('admin.')->group(function () {

    Route::get('login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('login', [AuthController::class, 'login'])->name('login.post')->middleware('throttle:5,1');
    Route::post('logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

    // ── Admin panel (auth kerak) ──────────────────────────────────────────
    Route::middleware(['auth', 'admin'])->group(function () {

        // Dashboard
        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

        // AJAX File Upload
        Route::post('upload', [\App\Http\Controllers\Admin\FileUploadController::class, 'upload'])->name('upload');


        // Clients (Foydalanuvchilar)
        Route::middleware('can:users.view')->group(function () {
            Route::resource('users', UserController::class)->except('show');
            Route::post('users/{user}/ban', [UserController::class, 'ban'])->name('users.ban')->middleware('can:users.ban');
            Route::post('users/{user}/balance', [UserController::class, 'adjustBalance'])->name('users.balance')->middleware('can:users.balance-adjust');
        });

        // Boshqaruvchilar (Admins)
        Route::middleware('can:admins.view')->group(function () {
            Route::resource('admins', \App\Http\Controllers\Admin\AdminUserController::class)->except('show');
            Route::post('admins/{admin}/ban', [\App\Http\Controllers\Admin\AdminUserController::class, 'ban'])->name('admins.ban')->middleware('can:admins.ban');
            Route::post('admins/{admin}/role', [\App\Http\Controllers\Admin\AdminUserController::class, 'assignRole'])->name('admins.role')->middleware('can:roles.assign');
        });

        // Roles & Permissions
        Route::middleware('can:roles.view')->group(function () {
            Route::resource('roles', RoleController::class)->except('show');
            Route::post('roles/{role}/permissions', [RoleController::class, 'syncPermissions'])->name('roles.permissions');
        });

        // Deposits
        Route::middleware('can:deposits.view')->group(function () {
            Route::resource('deposits', DepositController::class)->only(['index', 'show']);
            Route::post('deposits/{deposit}/approve', [DepositController::class, 'approve'])->name('deposits.approve')->middleware('can:deposits.approve');
            Route::post('deposits/{deposit}/reject', [DepositController::class, 'reject'])->name('deposits.reject')->middleware('can:deposits.reject');
        });

        // Withdrawals
        Route::middleware('can:withdrawals.view')->group(function () {
            Route::resource('withdrawals', WithdrawalController::class)->only(['index', 'show']);
            Route::post('withdrawals/{withdrawal}/approve', [WithdrawalController::class, 'approve'])->name('withdrawals.approve')->middleware('can:withdrawals.approve');
            Route::post('withdrawals/{withdrawal}/reject', [WithdrawalController::class, 'reject'])->name('withdrawals.reject')->middleware('can:withdrawals.reject');
        });

        // Packages
        Route::middleware('can:packages.view')->group(function () {
            Route::resource('packages', PackageController::class)->except('show');
        });
        
        // Stations (Zaryadlash stansiyalari)
        Route::middleware('can:stations.view')->group(function () {
            Route::resource('stations', \App\Http\Controllers\Admin\StationController::class)->except('show');
        });

        // Payment Methods (To'lov usullari / Karta raqamlar)
        Route::middleware('can:payment-methods.view')->group(function () {
            Route::resource('payment-methods', \App\Http\Controllers\Admin\PaymentMethodController::class)->except('show')->names('payment_methods');
        });

        // Settings
        Route::middleware('can:settings.view')->group(function () {
            Route::get('settings', [SettingController::class, 'index'])->name('settings.index');
            Route::put('settings', [SettingController::class, 'update'])->name('settings.update')->middleware('can:settings.edit');
        });

        // Translations (Tarjimalar)
        Route::resource('translations', TranslationController::class)->except('show');
        Route::post('translations/clear-cache', [TranslationController::class, 'clearCache'])
            ->name('translations.clear-cache');

        // ── AIS boshqaruvi ────────────────────────────────────────────────────
        Route::middleware('can:settings.view')->group(function () {
            Route::get('ais/rate', [\App\Http\Controllers\Admin\AisController::class, 'rate'])->name('ais.rate');
            Route::post('ais/rate', [\App\Http\Controllers\Admin\AisController::class, 'updateRate'])->name('ais.rate.update');
            Route::get('ais/wallets', [\App\Http\Controllers\Admin\AisController::class, 'wallets'])->name('ais.wallets');
            Route::get('ais/transfers', [\App\Http\Controllers\Admin\AisController::class, 'transfers'])->name('ais.transfers');
        });

        // ── Lider paneli ──────────────────────────────────────────────────────
        Route::middleware('can:leaders.view')->group(function () {
            Route::get('leaders', [\App\Http\Controllers\Admin\LeaderController::class, 'index'])->name('leaders.index');
            Route::post('leaders/{user}/toggle', [\App\Http\Controllers\Admin\LeaderController::class, 'toggle'])->name('leaders.toggle')->middleware('can:leaders.manage');
            Route::get('leaders/{user}/tree', [\App\Http\Controllers\Admin\LeaderController::class, 'tree'])->name('leaders.tree');
        });

        // ── Level boshqaruvi ──────────────────────────────────────────────────
        Route::middleware('can:settings.view')->group(function () {
            Route::get('levels', [\App\Http\Controllers\Admin\LevelAdminController::class, 'index'])->name('levels.index');
            Route::get('levels/leaderboard', [\App\Http\Controllers\Admin\LevelAdminController::class, 'leaderboard'])->name('levels.leaderboard');
        });

        // ── KYC boshqaruvi ────────────────────────────────────────────────────
        Route::middleware('can:kyc.view')->group(function () {
            // Pasport KYC (1-bosqich)
            Route::get('kyc/passport', [\App\Http\Controllers\Admin\KycController::class, 'index'])->name('kyc.index');
            Route::get('kyc/passport/{user}', [\App\Http\Controllers\Admin\KycController::class, 'show'])->name('kyc.show');
            Route::post('kyc/passport/{user}/approve', [\App\Http\Controllers\Admin\KycController::class, 'approve'])->name('kyc.approve')->middleware('can:kyc.approve');
            Route::post('kyc/passport/{user}/reject', [\App\Http\Controllers\Admin\KycController::class, 'reject'])->name('kyc.reject')->middleware('can:kyc.reject');

            // Face ID KYC (2-bosqich) — kyc/face route'lari {user} dan OLDIN kelishi kerak
            Route::get('kyc/face', [\App\Http\Controllers\Admin\FaceKycController::class, 'index'])->name('kyc.face.index');
            Route::get('kyc/face/{attempt}', [\App\Http\Controllers\Admin\FaceKycController::class, 'show'])->name('kyc.face.show');
            Route::post('kyc/face/{attempt}/approve', [\App\Http\Controllers\Admin\FaceKycController::class, 'approve'])->name('kyc.face.approve')->middleware('can:kyc.approve');
            Route::post('kyc/face/{attempt}/reject', [\App\Http\Controllers\Admin\FaceKycController::class, 'reject'])->name('kyc.face.reject')->middleware('can:kyc.reject');
        });

        // ── Tasks boshqaruvi ──────────────────────────────────────────────────
        Route::middleware('can:tasks.view')->group(function () {
            Route::get('tasks', [\App\Http\Controllers\Admin\TaskAdminController::class, 'index'])->name('tasks.index');
            Route::get('tasks/create', [\App\Http\Controllers\Admin\TaskAdminController::class, 'create'])->name('tasks.create');
            Route::post('tasks', [\App\Http\Controllers\Admin\TaskAdminController::class, 'store'])->name('tasks.store');
            Route::get('tasks/{task}/edit', [\App\Http\Controllers\Admin\TaskAdminController::class, 'edit'])->name('tasks.edit');
            Route::put('tasks/{task}', [\App\Http\Controllers\Admin\TaskAdminController::class, 'update'])->name('tasks.update');
            Route::delete('tasks/{task}', [\App\Http\Controllers\Admin\TaskAdminController::class, 'destroy'])->name('tasks.destroy');
            Route::post('tasks/{userTask}/approve', [\App\Http\Controllers\Admin\TaskAdminController::class, 'approve'])->name('tasks.approve');
            Route::post('tasks/{userTask}/reject', [\App\Http\Controllers\Admin\TaskAdminController::class, 'reject'])->name('tasks.reject');
        });

        // ── Quest boshqaruvi ──────────────────────────────────────────────────
        Route::middleware('can:tasks.view')->group(function () {
            Route::resource('quests', \App\Http\Controllers\Admin\QuestAdminController::class)
                ->except('show')->names('quests');
        });

        // ── Lucky Draw boshqaruvi ─────────────────────────────────────────────
        Route::middleware('can:lucky-draws.view')->group(function () {
            Route::resource('lucky-draw', \App\Http\Controllers\Admin\LuckyDrawAdminController::class)
                ->except('show')->names('lucky-draw');
            Route::post('lucky-draw/{luckyDraw}/draw', [\App\Http\Controllers\Admin\LuckyDrawAdminController::class, 'draw'])
                ->name('lucky-draw.draw');
            Route::get('lucky-draw-results', [\App\Http\Controllers\Admin\LuckyDrawAdminController::class, 'results'])
                ->name('lucky-draw.results');
        });

        // ── Fondlar boshqaruvi ────────────────────────────────────────────────
        Route::middleware('can:funds.view')->group(function () {
            Route::resource('funds', \App\Http\Controllers\Admin\FundAdminController::class)
                ->except('show')->names('funds');
        });

        // ── Telegram kanal postlari ───────────────────────────────────────────
        Route::middleware('can:settings.view')->group(function () {
            Route::get('channel-posts', [\App\Http\Controllers\Admin\ChannelPostController::class, 'index'])->name('channel-posts.index');
            Route::get('channel-posts/create', [\App\Http\Controllers\Admin\ChannelPostController::class, 'create'])->name('channel-posts.create');
            Route::post('channel-posts', [\App\Http\Controllers\Admin\ChannelPostController::class, 'store'])->name('channel-posts.store');
        });

        // ── Roadmap boshqaruvi ────────────────────────────────────────────────
        Route::middleware('can:settings.view')->group(function () {
            Route::resource('roadmap', \App\Http\Controllers\Admin\RoadmapController::class)->except('show')->names('roadmap');
        });

        // ── Birja boshqaruvi ──────────────────────────────────────────────────
        Route::middleware('can:settings.view')->prefix('exchange')->name('exchange.')->group(function () {
            Route::get('settings', [\App\Http\Controllers\Admin\ExchangeSettingController::class, 'index'])->name('settings.index');
            Route::put('settings', [\App\Http\Controllers\Admin\ExchangeSettingController::class, 'update'])->name('settings.update');
            Route::get('stats', [\App\Http\Controllers\Admin\ExchangeSettingController::class, 'stats'])->name('stats');
            Route::get('orders', [\App\Http\Controllers\Admin\ExchangeSettingController::class, 'orders'])->name('orders');
            Route::get('trades', [\App\Http\Controllers\Admin\ExchangeSettingController::class, 'trades'])->name('trades');
        });

        // ── Marketing boshqaruvi (Admin API) ──────────────────────────────────
        Route::prefix('marketing')->name('marketing.')->middleware('can:marketing.promo-codes.view')->group(function () {
            // Promo-kodlar
            Route::get('promo-codes', [\App\Http\Controllers\Admin\Marketing\PromoCodeController::class, 'index'])->name('promo-codes.index');
            Route::post('promo-codes', [\App\Http\Controllers\Admin\Marketing\PromoCodeController::class, 'store'])->name('promo-codes.store')->middleware('can:marketing.promo-codes.manage');
            Route::put('promo-codes/{id}', [\App\Http\Controllers\Admin\Marketing\PromoCodeController::class, 'update'])->name('promo-codes.update')->middleware('can:marketing.promo-codes.manage');
            Route::delete('promo-codes/{id}', [\App\Http\Controllers\Admin\Marketing\PromoCodeController::class, 'destroy'])->name('promo-codes.destroy')->middleware('can:marketing.promo-codes.manage');
            Route::get('promo-codes/{id}/stats', [\App\Http\Controllers\Admin\Marketing\PromoCodeController::class, 'stats'])->name('promo-codes.stats');

            // Spin Wheel mukofotlari
            Route::get('spin-wheel/prizes', [\App\Http\Controllers\Admin\Marketing\SpinWheelController::class, 'index'])->name('spin-wheel.index');
            Route::post('spin-wheel/prizes', [\App\Http\Controllers\Admin\Marketing\SpinWheelController::class, 'store'])->name('spin-wheel.store')->middleware('can:marketing.spin-wheel.manage');
            Route::put('spin-wheel/prizes/{prize}', [\App\Http\Controllers\Admin\Marketing\SpinWheelController::class, 'updatePrize'])->name('spin-wheel.prize.update')->middleware('can:marketing.spin-wheel.manage');
            Route::delete('spin-wheel/prizes/{prize}', [\App\Http\Controllers\Admin\Marketing\SpinWheelController::class, 'destroy'])->name('spin-wheel.prize.destroy')->middleware('can:marketing.spin-wheel.manage');
            Route::put('spin-wheel/prizes', [\App\Http\Controllers\Admin\Marketing\SpinWheelController::class, 'update'])->name('spin-wheel.update')->middleware('can:marketing.spin-wheel.manage');

            // Musobaqalar (Leaderboard)
            Route::get('competitions', [\App\Http\Controllers\Admin\Marketing\LeaderboardController::class, 'index'])->name('competitions.index');
            Route::put('competitions/settings', [\App\Http\Controllers\Admin\Marketing\LeaderboardController::class, 'settings'])->name('competitions.settings')->middleware('can:marketing.competitions.manage');

            // Mavsumiy tadbirlar
            Route::get('events', [\App\Http\Controllers\Admin\Marketing\SeasonalEventController::class, 'index'])->name('events.index');
            Route::post('events', [\App\Http\Controllers\Admin\Marketing\SeasonalEventController::class, 'store'])->name('events.store')->middleware('can:marketing.events.manage');
            Route::put('events/{id}', [\App\Http\Controllers\Admin\Marketing\SeasonalEventController::class, 'update'])->name('events.update')->middleware('can:marketing.events.manage');
            Route::delete('events/{id}', [\App\Http\Controllers\Admin\Marketing\SeasonalEventController::class, 'destroy'])->name('events.destroy')->middleware('can:marketing.events.manage');

            // VIP sozlamalari
            Route::get('vip/settings', [\App\Http\Controllers\Admin\Marketing\VipController::class, 'index'])->name('vip.index');
            Route::put('vip/settings', [\App\Http\Controllers\Admin\Marketing\VipController::class, 'settings'])->name('vip.settings')->middleware('can:marketing.vip.manage');

            // Invite Challenge sozlamalari
            Route::get('invite-challenge/settings', [\App\Http\Controllers\Admin\Marketing\InviteChallengeController::class, 'settings'])->name('invite-challenge.settings');
            Route::put('invite-challenge/settings', [\App\Http\Controllers\Admin\Marketing\InviteChallengeController::class, 'update'])->name('invite-challenge.update')->middleware('can:marketing.invite-challenge.manage');
        });

        // ── Crowdfunding boshqaruvi ───────────────────────────────────────────
        Route::prefix('crowdfunding')->name('crowdfunding.')->middleware('can:crowdfunding.view')->group(function () {
            Route::get('/', [\App\Http\Controllers\Admin\CrowdfundingAdminController::class, 'index'])->name('index');
            Route::post('{project}/approve', [\App\Http\Controllers\Admin\CrowdfundingAdminController::class, 'approve'])->name('approve')->middleware('can:crowdfunding.approve');
            Route::post('{project}/reject', [\App\Http\Controllers\Admin\CrowdfundingAdminController::class, 'reject'])->name('reject')->middleware('can:crowdfunding.reject');
            Route::post('{project}/expenses', [\App\Http\Controllers\Admin\CrowdfundingAdminController::class, 'addExpense'])->name('expenses.store')->middleware('can:crowdfunding.expenses');
            Route::get('{project}/expenses', [\App\Http\Controllers\Admin\CrowdfundingAdminController::class, 'expenses'])->name('expenses.index');
        });

        // ── UBI boshqaruvi ────────────────────────────────────────────────────
        Route::prefix('ubi')->name('ubi.')->middleware('can:settings.view')->group(function () {
            Route::get('settings', [\App\Http\Controllers\Admin\UbiAdminController::class, 'settings'])->name('settings');
            Route::put('settings', [\App\Http\Controllers\Admin\UbiAdminController::class, 'updateSettings'])->name('settings.update');
            Route::get('claims', [\App\Http\Controllers\Admin\UbiAdminController::class, 'claims'])->name('claims');
        });

        // ── Tokenization boshqaruvi ───────────────────────────────────────────
        Route::prefix('tokens')->name('tokens.')->middleware('can:settings.view')->group(function () {
            Route::get('assets', [\App\Http\Controllers\Admin\TokenAdminController::class, 'index'])->name('index');
            Route::post('assets', [\App\Http\Controllers\Admin\TokenAdminController::class, 'store'])->name('store');
            Route::put('assets/{asset}', [\App\Http\Controllers\Admin\TokenAdminController::class, 'update'])->name('update');
        });

        // ── FAQ boshqaruvi ────────────────────────────────────────────────────
        Route::prefix('faq')->name('faq.')->middleware('can:settings.view')->group(function () {
            Route::get('/', [\App\Http\Controllers\Admin\FaqAdminController::class, 'index'])->name('index');
            Route::post('/', [\App\Http\Controllers\Admin\FaqAdminController::class, 'store'])->name('store');
            Route::put('{faq}', [\App\Http\Controllers\Admin\FaqAdminController::class, 'update'])->name('update');
            Route::delete('{faq}', [\App\Http\Controllers\Admin\FaqAdminController::class, 'destroy'])->name('destroy');
        });

        // ── AI Yordamchi boshqaruvi ───────────────────────────────────────────
        Route::prefix('ai-assistant')->name('ai.')->middleware('can:settings.view')->group(function () {
            Route::get('faq', [\App\Http\Controllers\Admin\AiAssistantAdminController::class, 'faq'])->name('faq');
            Route::post('faq', [\App\Http\Controllers\Admin\AiAssistantAdminController::class, 'storeFaq'])->name('faq.store');
            Route::put('faq/{faq}', [\App\Http\Controllers\Admin\AiAssistantAdminController::class, 'updateFaq'])->name('faq.update');
            Route::delete('faq/{faq}', [\App\Http\Controllers\Admin\AiAssistantAdminController::class, 'destroyFaq'])->name('faq.destroy');
            Route::get('conversations', [\App\Http\Controllers\Admin\AiAssistantAdminController::class, 'conversations'])->name('conversations');
        });

        // ── AgroMarket boshqaruvi ─────────────────────────────────────────────
        Route::prefix('agromarket')->name('agromarket.')->middleware('can:agromarket.view')->group(function () {
            Route::get('listings', [\App\Http\Controllers\Admin\AgroMarketAdminController::class, 'listings'])->name('listings');
            Route::get('orders', [\App\Http\Controllers\Admin\AgroMarketAdminController::class, 'orders'])->name('orders');
            Route::get('listings/{listing}/edit', [\App\Http\Controllers\Admin\AgroMarketAdminController::class, 'editListing'])->name('listings.edit');
            Route::put('listings/{listing}', [\App\Http\Controllers\Admin\AgroMarketAdminController::class, 'updateListing'])->name('listings.update')->middleware('can:agromarket.manage');
            Route::delete('listings/{listing}', [\App\Http\Controllers\Admin\AgroMarketAdminController::class, 'destroyListing'])->name('listings.destroy')->middleware('can:agromarket.manage');
        });

        // ── Gig Economy boshqaruvi ────────────────────────────────────────────
        Route::prefix('gig-economy')->name('gig-economy.')->middleware('can:gig-economy.view')->group(function () {
            Route::get('listings', [\App\Http\Controllers\Admin\GigEconomyAdminController::class, 'listings'])->name('listings');
            Route::get('applications', [\App\Http\Controllers\Admin\GigEconomyAdminController::class, 'applications'])->name('applications');
            Route::get('listings/{listing}/edit', [\App\Http\Controllers\Admin\GigEconomyAdminController::class, 'editListing'])->name('listings.edit');
            Route::put('listings/{listing}', [\App\Http\Controllers\Admin\GigEconomyAdminController::class, 'updateListing'])->name('listings.update')->middleware('can:gig-economy.manage');
            Route::delete('listings/{listing}', [\App\Http\Controllers\Admin\GigEconomyAdminController::class, 'destroyListing'])->name('listings.destroy')->middleware('can:gig-economy.manage');
        });

        // ── Ad Network boshqaruvi ─────────────────────────────────────────────
        Route::prefix('ad-network')->name('ad-network.')->middleware('can:ad-network.view')->group(function () {
            Route::get('campaigns', [\App\Http\Controllers\Admin\AdNetworkAdminController::class, 'campaigns'])->name('campaigns');
            Route::get('ads', [\App\Http\Controllers\Admin\AdNetworkAdminController::class, 'ads'])->name('ads');
            Route::get('campaigns/{campaign}/edit', [\App\Http\Controllers\Admin\AdNetworkAdminController::class, 'editCampaign'])->name('campaigns.edit');
            Route::put('campaigns/{campaign}', [\App\Http\Controllers\Admin\AdNetworkAdminController::class, 'updateCampaign'])->name('campaigns.update')->middleware('can:ad-network.manage');
        });

        // ── Influencer Ad Network boshqaruvi ──────────────────────────────────
        Route::prefix('influencer')->name('influencer.')->middleware('can:influencer.channels.view')->group(function () {
            // Kanallar
            Route::get('channels', [\App\Http\Controllers\Admin\Influencer\InfluencerChannelAdminController::class, 'index'])->name('channels.index');
            Route::post('channels/{channel}/approve', [\App\Http\Controllers\Admin\Influencer\InfluencerChannelAdminController::class, 'approve'])->name('channels.approve')->middleware('can:influencer.channels.approve');
            Route::post('channels/{channel}/reject', [\App\Http\Controllers\Admin\Influencer\InfluencerChannelAdminController::class, 'reject'])->name('channels.reject')->middleware('can:influencer.channels.approve');
            Route::post('channels/{channel}/suspend', [\App\Http\Controllers\Admin\Influencer\InfluencerChannelAdminController::class, 'suspend'])->name('channels.suspend')->middleware('can:influencer.channels.approve');

            // Kampaniyalar
            Route::get('campaigns', [\App\Http\Controllers\Admin\Influencer\InfluencerCampaignAdminController::class, 'index'])->name('campaigns.index')->middleware('can:influencer.campaigns.view');
            Route::get('campaigns/create', [\App\Http\Controllers\Admin\Influencer\InfluencerCampaignAdminController::class, 'create'])->name('campaigns.create')->middleware('can:influencer.campaigns.manage');
            Route::post('campaigns', [\App\Http\Controllers\Admin\Influencer\InfluencerCampaignAdminController::class, 'store'])->name('campaigns.store')->middleware('can:influencer.campaigns.manage');
            Route::get('campaigns/{campaign}/edit', [\App\Http\Controllers\Admin\Influencer\InfluencerCampaignAdminController::class, 'edit'])->name('campaigns.edit')->middleware('can:influencer.campaigns.manage');
            Route::put('campaigns/{campaign}', [\App\Http\Controllers\Admin\Influencer\InfluencerCampaignAdminController::class, 'update'])->name('campaigns.update')->middleware('can:influencer.campaigns.manage');
            Route::delete('campaigns/{campaign}', [\App\Http\Controllers\Admin\Influencer\InfluencerCampaignAdminController::class, 'destroy'])->name('campaigns.destroy')->middleware('can:influencer.campaigns.manage');

            // Submissionlar
            Route::get('submissions', [\App\Http\Controllers\Admin\Influencer\InfluencerSubmissionAdminController::class, 'index'])->name('submissions.index')->middleware('can:influencer.submissions.view');
            Route::post('submissions/{submission}/approve', [\App\Http\Controllers\Admin\Influencer\InfluencerSubmissionAdminController::class, 'approve'])->name('submissions.approve')->middleware('can:influencer.submissions.approve');
            Route::post('submissions/{submission}/reject', [\App\Http\Controllers\Admin\Influencer\InfluencerSubmissionAdminController::class, 'reject'])->name('submissions.reject')->middleware('can:influencer.submissions.approve');
            Route::post('submissions/bulk-approve', [\App\Http\Controllers\Admin\Influencer\InfluencerSubmissionAdminController::class, 'bulkApprove'])->name('submissions.bulk-approve')->middleware('can:influencer.submissions.approve');
            Route::get('stats', [\App\Http\Controllers\Admin\Influencer\InfluencerSubmissionAdminController::class, 'stats'])->name('stats');

            // Mukofotlar
            Route::get('rewards', [\App\Http\Controllers\Admin\Influencer\InfluencerRewardAdminController::class, 'index'])->name('rewards.index')->middleware('can:influencer.rewards.view');

            // Sozlamalar
            Route::get('settings', [\App\Http\Controllers\Admin\Influencer\InfluencerSettingAdminController::class, 'index'])->name('settings.index')->middleware('can:influencer.settings.manage');
            Route::put('settings', [\App\Http\Controllers\Admin\Influencer\InfluencerSettingAdminController::class, 'update'])->name('settings.update')->middleware('can:influencer.settings.manage');
        });

        // ── P2P Lending boshqaruvi ────────────────────────────────────────────
        Route::prefix('lending')->name('lending.')->middleware('can:lending.view')->group(function () {
            Route::get('loans', [\App\Http\Controllers\Admin\LendingAdminController::class, 'loans'])->name('loans');
            Route::get('offers', [\App\Http\Controllers\Admin\LendingAdminController::class, 'offers'])->name('offers');
            Route::get('loans/{loan}/edit', [\App\Http\Controllers\Admin\LendingAdminController::class, 'editLoan'])->name('loans.edit');
            Route::put('loans/{loan}', [\App\Http\Controllers\Admin\LendingAdminController::class, 'updateLoan'])->name('loans.update')->middleware('can:lending.manage');
        });

        // ── Marketplace (Freelance) boshqaruvi ───────────────────────────────
        Route::middleware('can:marketplace.view')->group(function () {
            Route::resource('marketplace', \App\Http\Controllers\Admin\MarketplaceAdminController::class)->except('show')->names('marketplace');
        });

        // ── Mikro-kredit boshqaruvi ───────────────────────────────────────────
        Route::prefix('credits')->name('credits.')->middleware('can:credits.view')->group(function () {
            Route::get('/', [\App\Http\Controllers\Admin\CreditAdminController::class, 'index'])->name('index');
            Route::get('{credit}/edit', [\App\Http\Controllers\Admin\CreditAdminController::class, 'edit'])->name('edit');
            Route::put('{credit}', [\App\Http\Controllers\Admin\CreditAdminController::class, 'update'])->name('update')->middleware('can:credits.manage');
        });

        // ── Jamg'arma boshqaruvi ──────────────────────────────────────────────
        Route::prefix('savings')->name('savings.')->middleware('can:savings.view')->group(function () {
            Route::get('/', [\App\Http\Controllers\Admin\SavingsAdminController::class, 'index'])->name('index');
            Route::get('{saving}/edit', [\App\Http\Controllers\Admin\SavingsAdminController::class, 'edit'])->name('edit');
            Route::put('{saving}', [\App\Http\Controllers\Admin\SavingsAdminController::class, 'update'])->name('update')->middleware('can:savings.manage');
        });

        // ── Ta'lim boshqaruvi ─────────────────────────────────────────────────
        Route::prefix('education')->name('education.')->middleware('can:education.view')->group(function () {
            Route::get('/', [\App\Http\Controllers\Admin\EducationAdminController::class, 'index'])->name('index');
            Route::get('{education}/edit', [\App\Http\Controllers\Admin\EducationAdminController::class, 'edit'])->name('edit');
            Route::put('{education}', [\App\Http\Controllers\Admin\EducationAdminController::class, 'update'])->name('update')->middleware('can:education.manage');
            Route::delete('{education}', [\App\Http\Controllers\Admin\EducationAdminController::class, 'destroy'])->name('destroy')->middleware('can:education.manage');
        });

        // ── Katalog boshqaruvi ────────────────────────────────────────────────
        Route::prefix('catalog')->name('catalog.')->middleware('can:catalog.view')->group(function () {
            Route::get('shops', [\App\Http\Controllers\Admin\CatalogAdminController::class, 'shops'])->name('shops');
            Route::get('shops/{shop}/edit', [\App\Http\Controllers\Admin\CatalogAdminController::class, 'editShop'])->name('shops.edit');
            Route::put('shops/{shop}', [\App\Http\Controllers\Admin\CatalogAdminController::class, 'updateShop'])->name('shops.update')->middleware('can:catalog.manage');
            Route::get('products', [\App\Http\Controllers\Admin\CatalogAdminController::class, 'products'])->name('products');
            Route::get('products/{product}/edit', [\App\Http\Controllers\Admin\CatalogAdminController::class, 'editProduct'])->name('products.edit');
            Route::put('products/{product}', [\App\Http\Controllers\Admin\CatalogAdminController::class, 'updateProduct'])->name('products.update')->middleware('can:catalog.manage');
            Route::delete('products/{product}', [\App\Http\Controllers\Admin\CatalogAdminController::class, 'destroyProduct'])->name('products.destroy')->middleware('can:catalog.manage');
        });

        // ── Fraud Dashboard ───────────────────────────────────────────────────
        Route::prefix('fraud')->name('fraud.')->middleware('can:fraud.view')->group(function () {
            Route::get('/', [\App\Http\Controllers\Admin\FraudDashboardController::class, 'index'])->name('index');
            Route::get('/users', [\App\Http\Controllers\Admin\FraudDashboardController::class, 'users'])->name('users');
            Route::get('/transactions', [\App\Http\Controllers\Admin\FraudDashboardController::class, 'transactions'])->name('transactions');
            Route::get('/users/{user}', [\App\Http\Controllers\Admin\FraudDashboardController::class, 'userDetail'])->name('user-detail');
            Route::post('/users/{user}/ban', [\App\Http\Controllers\Admin\FraudDashboardController::class, 'banUser'])->name('ban');
            Route::post('/users/{user}/unban', [\App\Http\Controllers\Admin\FraudDashboardController::class, 'unbanUser'])->name('unban');
            Route::delete('/users/{user}/flags/{flag}', [\App\Http\Controllers\Admin\FraudDashboardController::class, 'removeFraudFlag'])->name('flag.remove');
            Route::get('/audit-logs', [\App\Http\Controllers\Admin\FraudDashboardController::class, 'auditLogs'])->name('audit-logs');
        });

        // ── Support Tickets boshqaruvi ────────────────────────────────────────
        Route::prefix('support')->name('support.')->group(function () {
            Route::get('/', [\App\Http\Controllers\Admin\SupportTicketAdminController::class, 'index'])->name('index');
            Route::get('/{ticket}', [\App\Http\Controllers\Admin\SupportTicketAdminController::class, 'show'])->name('show');
            Route::post('/{ticket}/reply', [\App\Http\Controllers\Admin\SupportTicketAdminController::class, 'reply'])->name('reply');
            Route::put('/{ticket}', [\App\Http\Controllers\Admin\SupportTicketAdminController::class, 'update'])->name('update');
        });

        // ── Tibbiyot xizmatlari boshqaruvi ────────────────────────────────────
        Route::prefix('medical')->name('medical.')->middleware('can:medical.view')->group(function () {
            Route::get('/', [\App\Http\Controllers\Admin\MedicalController::class, 'dashboard'])->name('dashboard');

            // Shifokorlar
            Route::get('doctors', [\App\Http\Controllers\Admin\MedicalController::class, 'doctors'])->name('doctors');
            Route::get('doctors/{doctorProfile}', [\App\Http\Controllers\Admin\MedicalController::class, 'doctorShow'])->name('doctors.show');
            Route::post('doctors/{doctorProfile}/approve', [\App\Http\Controllers\Admin\MedicalController::class, 'doctorApprove'])->name('doctors.approve')->middleware('can:medical.approve');
            Route::post('doctors/{doctorProfile}/reject', [\App\Http\Controllers\Admin\MedicalController::class, 'doctorReject'])->name('doctors.reject')->middleware('can:medical.approve');
            Route::post('doctors/{doctorProfile}/suspend', [\App\Http\Controllers\Admin\MedicalController::class, 'doctorSuspend'])->name('doctors.suspend')->middleware('can:medical.approve');
            Route::post('doctors/{doctorProfile}/reactivate', [\App\Http\Controllers\Admin\MedicalController::class, 'doctorReactivate'])->name('doctors.reactivate')->middleware('can:medical.approve');

            // Maslahatlar
            Route::get('consultations', [\App\Http\Controllers\Admin\MedicalController::class, 'consultations'])->name('consultations');
            Route::get('consultations/{consultation}', [\App\Http\Controllers\Admin\MedicalController::class, 'consultationShow'])->name('consultations.show');

            // Dori buyurtmalar
            Route::get('medicine-orders', [\App\Http\Controllers\Admin\MedicalController::class, 'medicineOrders'])->name('medicine-orders');
            Route::post('medicine-orders/{medicineOrder}/status', [\App\Http\Controllers\Admin\MedicalController::class, 'medicineOrderUpdateStatus'])->name('medicine-orders.status')->middleware('can:medical.approve');

            // Uyga chaqirishlar
            Route::get('home-visits', [\App\Http\Controllers\Admin\MedicalController::class, 'homeVisits'])->name('home-visits');

            // Shikoyatlar
            Route::get('complaints', [\App\Http\Controllers\Admin\MedicalController::class, 'complaints'])->name('complaints');
            Route::post('complaints/{complaint}/review', [\App\Http\Controllers\Admin\MedicalController::class, 'complaintReview'])->name('complaints.review')->middleware('can:medical.approve');

            // Dori katalogi
            Route::get('medicines', [\App\Http\Controllers\Admin\MedicalController::class, 'medicines'])->name('medicines');
            Route::post('medicines', [\App\Http\Controllers\Admin\MedicalController::class, 'medicineStore'])->name('medicines.store')->middleware('can:medical.approve');
            Route::put('medicines/{medicine}', [\App\Http\Controllers\Admin\MedicalController::class, 'medicineUpdate'])->name('medicines.update')->middleware('can:medical.approve');
            Route::delete('medicines/{medicine}', [\App\Http\Controllers\Admin\MedicalController::class, 'medicineDelete'])->name('medicines.destroy')->middleware('can:medical.approve');

            // Moliyaviy hisobot
            Route::get('financial-report', [\App\Http\Controllers\Admin\MedicalController::class, 'financialReport'])->name('financial-report');

            // Sozlamalar
            Route::get('settings', [\App\Http\Controllers\Admin\MedicalSettingController::class, 'index'])->name('settings');
            Route::put('settings', [\App\Http\Controllers\Admin\MedicalSettingController::class, 'update'])->name('settings.update')->middleware('can:medical.approve');
        });

    });
});

// Locale switch (har qanday sahifadan)
Route::get('locale/{lang}', function ($lang) {
    $supported = ['uz', 'ru', 'en'];
    if (in_array($lang, $supported)) {
        session(['locale' => $lang]);
    }
    return back();
})->name('locale.switch');
