<?php

use Illuminate\Support\Facades\Route;

Route::prefix('marketplace')->middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {
    $mc = \App\Http\Controllers\Api\V1\MarketplaceController::class;

    // Categories
    Route::get('categories', [$mc, 'categories']);

    // Gigs
    Route::get('gigs', [$mc, 'gigIndex']);
    Route::get('gigs/{gig}', [$mc, 'gigShow']);
    Route::post('gigs', [$mc, 'gigStore']);
    Route::put('gigs/{gig}', [$mc, 'gigUpdate']);
    Route::delete('gigs/{gig}', [$mc, 'gigDestroy']);

    // Orders
    Route::post('orders', [$mc, 'orderStore'])->middleware('throttle:financial-api');
    Route::get('orders', [$mc, 'orderIndex']);
    Route::get('orders/{order}', [$mc, 'orderShow']);
    Route::post('orders/{order}/accept', [$mc, 'orderAccept']);
    Route::post('orders/{order}/reject', [$mc, 'orderReject']);
    Route::post('orders/{order}/deliver', [$mc, 'orderDeliver']);
    Route::post('orders/{order}/complete', [$mc, 'orderComplete'])->middleware('throttle:financial-api');

    // Disputes
    Route::post('orders/{order}/dispute', [$mc, 'disputeStore']);
    Route::post('disputes/{dispute}/resolve', [$mc, 'disputeResolve'])
        ->middleware('throttle:financial-api');
        // Faqat order egasi yoki admin resolve qila oladi — controller ichida tekshiriladi

    // Reviews
    Route::post('orders/{order}/review', [$mc, 'reviewStore']);

    // Seller profile
    Route::get('sellers/{user}', [$mc, 'sellerProfile']);
});
