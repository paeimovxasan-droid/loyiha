<?php

use Illuminate\Support\Facades\Route;

// Public: Sertifikat tekshirish
Route::get('certificates/verify/{code}', [\App\Http\Controllers\Api\V1\CertificateController::class, 'verify']);

Route::middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {

    // Courses
    Route::get('courses', [\App\Http\Controllers\Api\V1\CourseController::class, 'index']);
    Route::get('courses/my-purchases', [\App\Http\Controllers\Api\V1\CourseController::class, 'myPurchases']);
    Route::get('courses/{course}', [\App\Http\Controllers\Api\V1\CourseController::class, 'show']);
    Route::post('courses', [\App\Http\Controllers\Api\V1\CourseController::class, 'store']);
    Route::post('courses/{course}/lessons', [\App\Http\Controllers\Api\V1\CourseController::class, 'addLesson']);
    Route::post('courses/{course}/publish', [\App\Http\Controllers\Api\V1\CourseController::class, 'publish']);
    Route::post('courses/{course}/purchase', [\App\Http\Controllers\Api\V1\CourseController::class, 'purchase'])
        ->middleware('throttle:financial-api');
    Route::post('courses/lessons/{lesson}/complete', [\App\Http\Controllers\Api\V1\CourseController::class, 'completeLesson']);

    // Certificates
    Route::get('certificates', [\App\Http\Controllers\Api\V1\CertificateController::class, 'index']);
    Route::get('certificates/{certificate}/download', [\App\Http\Controllers\Api\V1\CertificateController::class, 'download']);

    // Mentors
    Route::get('mentors', [\App\Http\Controllers\Api\V1\MentorController::class, 'index']);
    Route::post('mentors/profile', [\App\Http\Controllers\Api\V1\MentorController::class, 'createProfile']);
    Route::post('mentors/{mentor}/request', [\App\Http\Controllers\Api\V1\MentorController::class, 'requestSession'])
        ->middleware('throttle:financial-api');
    Route::post('mentor-sessions/{session}/accept', [\App\Http\Controllers\Api\V1\MentorController::class, 'acceptSession']);
    Route::post('mentor-sessions/{session}/complete', [\App\Http\Controllers\Api\V1\MentorController::class, 'completeSession']);
    Route::get('mentor-sessions', [\App\Http\Controllers\Api\V1\MentorController::class, 'mySessions']);
});
