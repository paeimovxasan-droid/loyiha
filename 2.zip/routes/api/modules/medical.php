<?php

use App\Http\Controllers\Api\V1\Medical\ConsultationController;
use App\Http\Controllers\Api\V1\Medical\DoctorDashboardController;
use App\Http\Controllers\Api\V1\Medical\DoctorProfileController;
use App\Http\Controllers\Api\V1\Medical\HomeVisitController;
use App\Http\Controllers\Api\V1\Medical\MedicalReferralController;
use App\Http\Controllers\Api\V1\Medical\MedicineOrderController;
use App\Http\Controllers\Api\V1\Medical\PrescriptionController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Medical Services API Routes
|--------------------------------------------------------------------------
| Prefix: /api/v1/medical
*/

Route::prefix('medical')->group(function () {

    // ── Public (auth kerak emas) ─────────────────────────────────────────
    Route::get('specialties', [DoctorProfileController::class, 'specialties']);
    Route::get('doctors', [DoctorProfileController::class, 'index']);
    Route::get('doctors/{doctorProfile}', [DoctorProfileController::class, 'show']);

    // ── Auth kerak ───────────────────────────────────────────────────────
    Route::middleware(['auth:sanctum', 'force.json'])->group(function () {

        // Shifokor profili
        Route::get('doctor-profile/me', [DoctorProfileController::class, 'me']);
        Route::post('doctor-profile', [DoctorProfileController::class, 'store']);
        Route::put('doctor-profile', [DoctorProfileController::class, 'update']);
        Route::post('doctor-profile/toggle-online', [DoctorProfileController::class, 'toggleOnline']);

        // Shifokor dashboard
        Route::get('doctor/dashboard', [DoctorDashboardController::class, 'index']);

        // Maslahatlar
        Route::get('consultations', [ConsultationController::class, 'index']);
        Route::post('consultations', [ConsultationController::class, 'store']);
        Route::get('consultations/{consultation}', [ConsultationController::class, 'show']);
        Route::post('consultations/{consultation}/accept', [ConsultationController::class, 'accept']);
        Route::post('consultations/{consultation}/complete', [ConsultationController::class, 'complete']);
        Route::post('consultations/{consultation}/cancel', [ConsultationController::class, 'cancel']);
        Route::post('consultations/{consultation}/messages', [ConsultationController::class, 'sendMessage']);
        Route::post('consultations/{consultation}/review', [ConsultationController::class, 'review']);
        Route::post('consultations/{consultation}/complaint', [ConsultationController::class, 'complaint']);

        // Retseptlar
        Route::post('consultations/{consultation}/prescriptions', [PrescriptionController::class, 'store']);
        Route::get('medicines', [PrescriptionController::class, 'medicines']);

        // Analiz yo'llanma
        Route::post('consultations/{consultation}/referrals', [MedicalReferralController::class, 'store']);

        // Dori buyurtma
        Route::get('medicine-orders', [MedicineOrderController::class, 'index']);
        Route::post('medicine-orders', [MedicineOrderController::class, 'store']);
        Route::post('medicine-orders/{medicineOrder}/cancel', [MedicineOrderController::class, 'cancel']);

        // Uyga chaqirish
        Route::get('home-visits', [HomeVisitController::class, 'index']);
        Route::post('home-visits', [HomeVisitController::class, 'store']);
        Route::post('home-visits/{homeVisit}/accept', [HomeVisitController::class, 'accept']);
        Route::post('home-visits/{homeVisit}/on-the-way', [HomeVisitController::class, 'onTheWay']);
        Route::post('home-visits/{homeVisit}/complete', [HomeVisitController::class, 'complete']);
    });
});
