<?php

use Illuminate\Support\Facades\Route;

// ---------------------------------------------------------------
// Crowdfunding endpointlar
// ---------------------------------------------------------------
Route::prefix('crowdfunding')->middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {
    $cc = \App\Http\Controllers\Api\V1\CrowdfundingController::class;

    Route::get('projects', [$cc, 'index']);
    Route::get('projects/{project}', [$cc, 'show']);
    Route::post('projects', [$cc, 'store']);
    Route::post('projects/{project}/donate', [$cc, 'donate'])->middleware('throttle:financial-api');
});

// ---------------------------------------------------------------
// AgroMarket endpointlar
// ---------------------------------------------------------------
Route::prefix('agromarket')->middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {
    $ac = \App\Http\Controllers\Api\V1\AgroMarketController::class;

    Route::get('listings', [$ac, 'listings']);
    Route::get('listings/{listing}', [$ac, 'showListing']);
    Route::post('listings', [$ac, 'storeListing']);
    Route::put('listings/{listing}', [$ac, 'updateListing']);
    Route::post('orders', [$ac, 'placeOrder'])->middleware('throttle:financial-api');
    Route::get('orders', [$ac, 'orders']);
    Route::post('orders/{order}/confirm', [$ac, 'confirmOrder'])->middleware('throttle:financial-api');
    Route::post('orders/{order}/cancel', [$ac, 'cancelOrder']);
});

// ---------------------------------------------------------------
// Gig Economy endpointlar
// ---------------------------------------------------------------
Route::prefix('gig-economy')->middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {
    $gc = \App\Http\Controllers\Api\V1\GigEconomyController::class;

    Route::get('listings', [$gc, 'listings']);
    Route::get('listings/{listing}', [$gc, 'showListing']);
    Route::post('listings', [$gc, 'storeListing']);
    Route::post('listings/{listing}/apply', [$gc, 'apply']);
    Route::post('applications/{application}/accept', [$gc, 'acceptApplication']);
    Route::post('listings/{listing}/complete', [$gc, 'completeListing'])->middleware('throttle:financial-api');
    Route::post('listings/{listing}/rate', [$gc, 'rate']);
    Route::get('my-listings', [$gc, 'myListings']);
    Route::get('my-applications', [$gc, 'myApplications']);
});

// ---------------------------------------------------------------
// UBI Pilot endpointlar
// ---------------------------------------------------------------
Route::prefix('ubi')->middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {
    $uc = \App\Http\Controllers\Api\V1\UbiController::class;

    Route::get('status', [$uc, 'status']);
    Route::post('claim', [$uc, 'claim'])->middleware('throttle:3,1');
    Route::get('history', [$uc, 'history']);
    Route::get('stats', [$uc, 'stats']);
});

// ---------------------------------------------------------------
// Ad Network endpointlar
// ---------------------------------------------------------------
Route::prefix('ads')->middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {
    $adc = \App\Http\Controllers\Api\V1\AdController::class;

    Route::get('/', [$adc, 'index']);
    Route::post('campaigns', [$adc, 'createCampaign'])->middleware('throttle:financial-api');
    Route::get('campaigns', [$adc, 'myCampaigns']);
    Route::get('campaigns/{campaign}', [$adc, 'showCampaign']);
    Route::post('campaigns/{campaign}/ads', [$adc, 'createAd']);
    Route::post('{ad}/watch', [$adc, 'watchAd'])->middleware('throttle:10,1');
});

// ---------------------------------------------------------------
// P2P Lending endpointlar
// ---------------------------------------------------------------
Route::prefix('lending')->middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {
    $lc = \App\Http\Controllers\Api\V1\LendingController::class;

    Route::get('offers', [$lc, 'offers']);
    Route::post('offers', [$lc, 'createOffer'])->middleware('throttle:financial-api');
    Route::post('offers/{offer}/accept', [$lc, 'acceptOffer'])->middleware('throttle:financial-api');
    Route::post('offers/{offer}/cancel', [$lc, 'cancelOffer']);
    Route::get('loans', [$lc, 'loans']);
    Route::get('loans/{loan}', [$lc, 'showLoan']);
    Route::post('loans/{loan}/pay', [$lc, 'makePayment'])->middleware('throttle:financial-api');
});

// ---------------------------------------------------------------
// Tokenization endpointlar
// ---------------------------------------------------------------
Route::prefix('tokens')->middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {
    $tc = \App\Http\Controllers\Api\V1\TokenController::class;

    Route::get('assets', [$tc, 'assets']);
    Route::get('assets/{asset}', [$tc, 'showAsset']);
    Route::post('assets/{asset}/purchase', [$tc, 'purchase'])->middleware('throttle:financial-api');
    Route::get('portfolio', [$tc, 'portfolio']);
});

// ---------------------------------------------------------------
// AI Assistant endpointlar
// ---------------------------------------------------------------
Route::prefix('ai-assistant')->middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {
    $ai = \App\Http\Controllers\Api\V1\AiAssistantController::class;

    Route::post('ask', [$ai, 'ask']);
    Route::get('conversations', [$ai, 'conversations']);
    Route::get('conversations/{conversation}', [$ai, 'showConversation']);
    Route::get('faq', [$ai, 'faq']);
    Route::get('advice', [$ai, 'advice']);
});
