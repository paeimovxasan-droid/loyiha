<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\V1\ExchangeController;

Route::prefix('exchange')->group(function () {
    // Public endpointlar
    Route::get('order-book', [ExchangeController::class, 'orderBook']);
    Route::get('ticker', [ExchangeController::class, 'ticker']);
    Route::get('trades/recent', [ExchangeController::class, 'recentTrades']);
    Route::get('candles', [ExchangeController::class, 'candles']);

    // Himoyalangan endpointlar
    Route::middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {
        Route::post('orders', [ExchangeController::class, 'placeOrder'])
            ->middleware('throttle:financial-api');
        Route::delete('orders/{order}', [ExchangeController::class, 'cancelOrder'])
            ->middleware('throttle:financial-api');
        Route::get('orders/open', [ExchangeController::class, 'myOpenOrders']);
        Route::get('orders/history', [ExchangeController::class, 'myOrderHistory']);
        Route::get('trades/my', [ExchangeController::class, 'myTrades']);
    });
});
