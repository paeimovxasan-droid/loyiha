<?php

use Illuminate\Support\Facades\Route;

Route::prefix('catalog')->middleware(['auth:sanctum', 'telegram.auth', 'set.locale.api', 'force.json'])->group(function () {
    $cc = \App\Http\Controllers\Api\V1\CatalogController::class;

    // Shops
    Route::post('shops', [$cc, 'shopStore'])->middleware('throttle:financial-api');
    Route::put('shops/{shop}', [$cc, 'shopUpdate']);
    Route::get('shops', [$cc, 'shopIndex']);
    Route::get('shops/{shop}', [$cc, 'shopShow']);

    // Products
    Route::post('shops/{shop}/products', [$cc, 'productStore']);
    Route::put('products/{product}', [$cc, 'productUpdate']);
    Route::delete('products/{product}', [$cc, 'productDestroy']);
    Route::get('products', [$cc, 'productIndex']);

    // Orders
    Route::post('orders', [$cc, 'orderStore'])->middleware('throttle:financial-api');
    Route::get('orders', [$cc, 'orderIndex']);
    Route::post('orders/{order}/confirm', [$cc, 'orderConfirm']);
    Route::post('orders/{order}/deliver', [$cc, 'orderDeliver']);
    Route::post('orders/{order}/complete', [$cc, 'orderComplete'])->middleware('throttle:financial-api');

    // Reviews
    Route::post('orders/{order}/review', [$cc, 'reviewStore']);
});
