#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════
# AISOQQA.UZ — Kritik xatolarni tuzatish uchun deploy script
# Serverda ishlatish: bash fix-deploy.sh
# ═══════════════════════════════════════════════════════════════════════

echo "🔧 AISOQQA.UZ — Xatolarni tuzatish..."

# 1. Storage symlink qayta yaratish (404 xatolarni tuzatadi)
echo "📁 Storage symlink qayta yaratilmoqda..."
rm -f public/storage
php artisan storage:link
echo "✅ Storage symlink yaratildi"

# 2. View cache tozalash (Alpine.js __ xatosini tuzatadi)
echo "🗑️ View cache tozalanmoqda..."
php artisan view:clear
echo "✅ View cache tozalandi"

# 3. Config cache tozalash
echo "🗑️ Config cache tozalanmoqda..."
php artisan config:clear
echo "✅ Config cache tozalandi"

# 4. Application cache tozalash (Settings cache)
echo "🗑️ Application cache tozalanmoqda..."
php artisan cache:clear
echo "✅ Application cache tozalandi"

# 5. Route cache tozalash
echo "🗑️ Route cache tozalanmoqda..."
php artisan route:clear
echo "✅ Route cache tozalandi"

# 6. Migratsiyalarni ishlatish (yangi ustunlar uchun)
echo "📊 Migratsiyalar tekshirilmoqda..."
php artisan migrate --force
echo "✅ Migratsiyalar bajarildi"

echo ""
echo "═══════════════════════════════════════════════════════════════"
echo "✅ Barcha tuzatishlar qo'llanildi!"
echo "═══════════════════════════════════════════════════════════════"
