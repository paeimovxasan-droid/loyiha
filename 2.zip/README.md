# AISOQQA — AIS Valyuta & Investitsiya Platformasi

**Domen:** aisoqqa.uz | **Ichki valyuta:** AIS (1 AIS = 1,000 UZS)

---

## Texnologiyalar

| Stack | Versiya |
|---|---|
| PHP | 8.2+ |
| Laravel | 12 |
| Tailwind CSS | 4.0 |
| Vite | 7 |
| Spatie Permission | 6 |
| Spatie Translatable | 6 |

---

## Tezkor o'rnatish (3 qadam)

```bash
# 1. Dependencylar
composer install
npm install && npm run build

# 2. .env sozlash
cp .env.example .env
# .env faylida quyidagilarni to'ldiring:
#   DB_DATABASE=aisoqqa
#   DB_USERNAME=root
#   DB_PASSWORD=your_password

# 3. Bir buyruq bilan o'rnatish
php artisan app:install
```

> **Qayta o'rnatish** (barcha ma'lumotlarni o'chirib):
> ```bash
> php artisan app:install --fresh
> ```

---

## Ishga tushirish

```bash
php artisan serve
# yoki development rejimi (server + queue + logs + vite):
composer run dev
```

---

## Login ma'lumotlari (seeder)

| Rol | Email | Parol |
|---|---|---|
| Super Admin | superadmin@aisoqqa.uz | Admin@12345 |
| Admin | admin@aisoqqa.uz | Admin@12345 |
| Moderator | moderator@aisoqqa.uz | Admin@12345 |
| Test User | user@aisoqqa.uz | User@12345 |

---

## URL lar

| Sahifa | URL |
|---|---|
| Frontend | http://localhost:8000 |
| Admin panel | http://localhost:8000/admin |
| AIS Kurs | http://localhost:8000/admin/ais/rate |
| Lider paneli | http://localhost:8000/admin/leaders |
| Level tizimi | http://localhost:8000/admin/levels |

---

## Asosiy funksiyalar

### AIS Valyuta tizimi
- Har foydalanuvchiga unikal `AIS-XXXX-XXXX-XXXX` hamyon
- UZS ↔ AIS konvertatsiya (real kurs asosida)
- P2P transfer (Level 5 dan ochiladi)
- Virtual karta (Level 10 dan ochiladi)
- Admin tomonidan kurs boshqaruvi

### Level / XP tizimi
```
Level = floor(sqrt(total_xp / 100))

Lv.0–4   → Newcomer  🌱  (boshlang'ich)
Lv.5–9   → Active    ⚡  [P2P ochiladi]
Lv.10–19 → Experienced 🔥 [Virtual karta ochiladi]
Lv.20–34 → Expert    💎
Lv.35–49 → Master    🏆
Lv.50–74 → Grandmaster 👑
Lv.75–98 → Legend    🌟
Lv.99    → AISOQQA Elite 🚀
```

**XP manbalari:**
| Faoliyat | XP |
|---|---|
| Ro'yxatdan o'tish | +50 |
| Kunlik check-in | +10–40 (streak) |
| Depozit | +dinamik |
| Paket xaridi | +100–500 |
| Referral jalb | +200 |
| P2P transfer | +20 |
| Topshiriq | +50 |
| KYC | +500 |
| Profil to'ldirish | +30 |

### Investitsiya
- Paketlar (kunlik mining daromadi)
- Investitsiya fondlari
- 3 darajali referral komissiya

### Gamification
- Kunlik check-in (streak bonusi)
- Lucky Draw
- Topshiriqlar
- **Kvestlar** — 15+ kvest, kategoriyalar bo'yicha, AIS+UZS+XP mukofot

### Admin panel
- Foydalanuvchilar boshqaruvi
- Depozit/yechish tasdiqlash
- AIS kurs boshqaruvi
- Lider paneli (referral daraxti)
- Level statistika va leaderboard
- KYC tasdiqlash (hujjat ko'rish, approve/reject)
- Topshiriqlar tasdiqlash
- Tarjimalar (uz/ru/en)

---

## Loyiha strukturasi

```
app/
├── Console/Commands/InstallApp.php   # php artisan app:install
├── Http/Controllers/
│   ├── Admin/                        # Admin panel
│   └── Front/                        # Foydalanuvchi paneli
├── Models/
│   ├── AIS/                          # Wallet, VirtualCard, Transfer...
│   ├── Level/                        # UserLevel, XpLog, LevelConfig
│   ├── Finance/                      # Transaction, Commission...
│   ├── Package/                      # Package, Purchase, Mining
│   └── Payment/                      # Deposit, Withdrawal...
└── Services/
    ├── WalletService.php             # AIS hamyon operatsiyalari
    ├── XpService.php                 # XP berish va level hisoblash
    └── FileUploadService.php
```
