<?php

namespace Tests\Unit\Influencer;

use PHPUnit\Framework\TestCase;

/**
 * Talab 10 — Xavfsizlik va firibgarlikdan himoya
 * PBT xossalari:
 * - Screenshot hash unikal bo'lishi kerak
 * - Post URL bir kampaniyada unikal bo'lishi kerak
 * - Kunlik limit oshmasligi kerak
 */
class InfluencerFraudServiceTest extends TestCase
{
    /**
     * Screenshot MD5 hash hisoblash deterministik bo'lishi kerak
     * Bir xil kontent → bir xil hash
     */
    public function test_same_content_produces_same_hash(): void
    {
        $content = 'test screenshot content 12345';
        $hash1   = md5($content);
        $hash2   = md5($content);

        $this->assertEquals($hash1, $hash2, 'Bir xil kontent uchun hash bir xil bo\'lishi kerak');
    }

    /**
     * Har xil kontent → har xil hash (collision yo'q)
     */
    public function test_different_content_produces_different_hash(): void
    {
        $contents = [
            'screenshot_1_content',
            'screenshot_2_content',
            'screenshot_3_content',
            str_repeat('a', 1000),
            str_repeat('b', 1000),
        ];

        $hashes = array_map('md5', $contents);
        $unique = array_unique($hashes);

        $this->assertCount(
            count($contents),
            $unique,
            'Har xil kontent uchun hash unikal bo\'lishi kerak'
        );
    }

    /**
     * Kunlik limit tekshiruvi
     * Publisher max_daily_submissions dan ko'p submission yubora olmasligi kerak
     */
    public function test_daily_limit_enforcement(): void
    {
        $maxDailySubmissions = 5;

        // 0 dan max gacha — ruxsat
        for ($count = 0; $count < $maxDailySubmissions; $count++) {
            $canSubmit = $count < $maxDailySubmissions;
            $this->assertTrue($canSubmit, "Count={$count} da submission ruxsat etilishi kerak");
        }

        // max va undan ko'p — rad
        for ($count = $maxDailySubmissions; $count <= $maxDailySubmissions + 3; $count++) {
            $canSubmit = $count < $maxDailySubmissions;
            $this->assertFalse($canSubmit, "Count={$count} da submission rad etilishi kerak");
        }
    }

    /**
     * Duplicate submission tekshiruvi
     * Bir xil (channel_id, campaign_id) juftligi uchun faqat bitta submission bo'lishi kerak
     */
    public function test_duplicate_submission_detection(): void
    {
        // Mavjud submissionlar (channel_id, campaign_id) juftliklari
        $existingSubmissions = [
            ['channel_id' => 1, 'campaign_id' => 1],
            ['channel_id' => 1, 'campaign_id' => 2],
            ['channel_id' => 2, 'campaign_id' => 1],
        ];

        // Yangi submission urinishlari
        $newAttempts = [
            ['channel_id' => 1, 'campaign_id' => 1, 'is_duplicate' => true],  // duplicate
            ['channel_id' => 1, 'campaign_id' => 3, 'is_duplicate' => false], // yangi
            ['channel_id' => 3, 'campaign_id' => 1, 'is_duplicate' => false], // yangi
            ['channel_id' => 2, 'campaign_id' => 1, 'is_duplicate' => true],  // duplicate
        ];

        foreach ($newAttempts as $attempt) {
            $isDuplicate = collect($existingSubmissions)->contains(function ($sub) use ($attempt) {
                return $sub['channel_id'] === $attempt['channel_id']
                    && $sub['campaign_id'] === $attempt['campaign_id'];
            });

            $this->assertEquals(
                $attempt['is_duplicate'],
                $isDuplicate,
                "channel_id={$attempt['channel_id']}, campaign_id={$attempt['campaign_id']}"
            );
        }
    }

    /**
     * Post URL unikal bo'lishi kerak (bir kampaniyada)
     */
    public function test_post_url_uniqueness_per_campaign(): void
    {
        $existingUrls = [
            ['url' => 'https://t.me/channel/123', 'campaign_id' => 1],
            ['url' => 'https://t.me/channel/456', 'campaign_id' => 1],
            ['url' => 'https://t.me/channel/123', 'campaign_id' => 2], // boshqa kampaniya — OK
        ];

        $newAttempts = [
            ['url' => 'https://t.me/channel/123', 'campaign_id' => 1, 'is_duplicate' => true],
            ['url' => 'https://t.me/channel/789', 'campaign_id' => 1, 'is_duplicate' => false],
            ['url' => 'https://t.me/channel/123', 'campaign_id' => 2, 'is_duplicate' => true],
            ['url' => 'https://t.me/channel/123', 'campaign_id' => 3, 'is_duplicate' => false],
        ];

        foreach ($newAttempts as $attempt) {
            $isDuplicate = collect($existingUrls)->contains(function ($existing) use ($attempt) {
                return $existing['url'] === $attempt['url']
                    && $existing['campaign_id'] === $attempt['campaign_id'];
            });

            $this->assertEquals(
                $attempt['is_duplicate'],
                $isDuplicate,
                "url={$attempt['url']}, campaign_id={$attempt['campaign_id']}"
            );
        }
    }

    /**
     * 5 ta rad → blok mexanizmi
     */
    public function test_rejection_count_triggers_block(): void
    {
        $blockThreshold = 5;

        for ($rejections = 0; $rejections < $blockThreshold; $rejections++) {
            $shouldBlock = $rejections >= $blockThreshold;
            $this->assertFalse($shouldBlock, "Rejections={$rejections}: blok bo'lmasligi kerak");
        }

        // Aynan 5 ta rad — blok
        $this->assertTrue(
            $blockThreshold >= $blockThreshold,
            '5 ta rad bo\'lganda blok bo\'lishi kerak'
        );

        // 5 dan ko'p — ham blok
        for ($rejections = $blockThreshold; $rejections <= $blockThreshold + 5; $rejections++) {
            $shouldBlock = $rejections >= $blockThreshold;
            $this->assertTrue($shouldBlock, "Rejections={$rejections}: blok bo'lishi kerak");
        }
    }
}
