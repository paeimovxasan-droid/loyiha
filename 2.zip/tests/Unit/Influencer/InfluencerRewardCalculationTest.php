<?php

namespace Tests\Unit\Influencer;

use App\Models\Influencer\InfluencerCampaign;
use App\Models\Influencer\InfluencerChannel;
use App\Models\Influencer\InfluencerSetting;
use App\Services\Influencer\InfluencerRewardService;
use PHPUnit\Framework\TestCase;

/**
 * Talab 6.1 — Mukofot hisoblash to'g'riligi
 * PBT xossasi: final_reward = reward_amount × coefficient, va final_reward > 0
 */
class InfluencerRewardCalculationTest extends TestCase
{
    /**
     * Mukofot hisoblash formulasi to'g'riligi
     * final_reward = campaign.reward_amount × channel_type_coefficient
     */
    public function test_reward_calculation_is_correct(): void
    {
        $cases = [
            ['type' => 'youtube_channel',  'coeff' => 1.50, 'base' => 100.0, 'expected' => 150.0],
            ['type' => 'telegram_channel', 'coeff' => 1.20, 'base' => 100.0, 'expected' => 120.0],
            ['type' => 'telegram_group',   'coeff' => 1.00, 'base' => 100.0, 'expected' => 100.0],
            ['type' => 'telegram_bot',     'coeff' => 0.80, 'base' => 100.0, 'expected' => 80.0],
            ['type' => 'youtube_channel',  'coeff' => 1.50, 'base' => 50.0,  'expected' => 75.0],
            ['type' => 'telegram_channel', 'coeff' => 1.20, 'base' => 200.0, 'expected' => 240.0],
        ];

        foreach ($cases as $case) {
            $result = round($case['base'] * $case['coeff'], 4);
            $this->assertEquals(
                $case['expected'],
                $result,
                "Kanal turi: {$case['type']}, base: {$case['base']}, coeff: {$case['coeff']}"
            );
        }
    }

    /**
     * Mukofot har doim musbat bo'lishi kerak
     */
    public function test_reward_is_always_positive(): void
    {
        $rewardAmounts = [0.0001, 1.0, 10.0, 100.0, 1000.0, 9999.9999];
        $coefficients  = [0.01, 0.5, 0.8, 1.0, 1.2, 1.5, 2.0, 10.0];

        foreach ($rewardAmounts as $amount) {
            foreach ($coefficients as $coeff) {
                $result = round($amount * $coeff, 4);
                $this->assertGreaterThan(
                    0,
                    $result,
                    "Mukofot musbat bo'lishi kerak: amount={$amount}, coeff={$coeff}"
                );
            }
        }
    }

    /**
     * Koeffitsient 0 yoki manfiy bo'lsa — validatsiya xatosi
     */
    public function test_zero_or_negative_coefficient_is_invalid(): void
    {
        $invalidCoefficients = [0, -0.1, -1.0, -100.0];

        foreach ($invalidCoefficients as $coeff) {
            $this->assertLessThanOrEqual(
                0,
                $coeff,
                "Noto'g'ri koeffitsient: {$coeff}"
            );
        }
    }

    /**
     * Byudjet chegarasi: spent_budget hech qachon total_budget dan oshmasligi kerak
     */
    public function test_budget_never_exceeds_total(): void
    {
        $scenarios = [
            ['total' => 1000.0, 'spent' => 0.0,    'reward' => 100.0, 'can_pay' => true],
            ['total' => 1000.0, 'spent' => 900.0,   'reward' => 100.0, 'can_pay' => true],
            ['total' => 1000.0, 'spent' => 950.0,   'reward' => 100.0, 'can_pay' => false],
            ['total' => 1000.0, 'spent' => 1000.0,  'reward' => 0.01,  'can_pay' => false],
            ['total' => 500.0,  'spent' => 499.9999,'reward' => 0.0001,'can_pay' => true],
        ];

        foreach ($scenarios as $s) {
            $remaining = $s['total'] - $s['spent'];
            $canPay    = $remaining >= $s['reward'];

            $this->assertEquals(
                $s['can_pay'],
                $canPay,
                "total={$s['total']}, spent={$s['spent']}, reward={$s['reward']}"
            );

            // Agar to'lov amalga oshirilsa — spent hech qachon total dan oshmasligi kerak
            if ($canPay) {
                $newSpent = $s['spent'] + $s['reward'];
                $this->assertLessThanOrEqual(
                    $s['total'],
                    $newSpent,
                    "spent_budget total_budget dan oshib ketdi!"
                );
            }
        }
    }
}
