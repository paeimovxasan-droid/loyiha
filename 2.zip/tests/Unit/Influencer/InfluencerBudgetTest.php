<?php

namespace Tests\Unit\Influencer;

use PHPUnit\Framework\TestCase;

/**
 * Talab 3.2 — Byudjet chegarasi
 * PBT xossasi: spent_budget hech qachon total_budget dan oshmasligi kerak
 */
class InfluencerBudgetTest extends TestCase
{
    /**
     * Byudjet chegarasi — ko'p scenariy
     */
    public function test_budget_constraint_holds_for_multiple_rewards(): void
    {
        $totalBudget = 1000.0;
        $spentBudget = 0.0;
        $rewardAmount = 100.0;

        // 10 ta to'lov — har biri 100 AIS
        for ($i = 0; $i < 10; $i++) {
            $remaining = $totalBudget - $spentBudget;
            $this->assertGreaterThanOrEqual(
                $rewardAmount,
                $remaining,
                "To'lov #{$i}: byudjet yetarli bo'lishi kerak"
            );

            $spentBudget += $rewardAmount;

            $this->assertLessThanOrEqual(
                $totalBudget,
                $spentBudget,
                "To'lov #{$i}: spent_budget total_budget dan oshmasligi kerak"
            );
        }

        // 11-chi to'lov — byudjet yetarli emas
        $remaining = $totalBudget - $spentBudget;
        $this->assertLessThan(
            $rewardAmount,
            $remaining,
            '11-chi to\'lovda byudjet yetarli bo\'lmasligi kerak'
        );
    }

    /**
     * Qisman byudjet — oxirgi to'lov qisman bo'lishi mumkin emas
     */
    public function test_partial_reward_not_allowed(): void
    {
        $totalBudget  = 150.0;
        $spentBudget  = 100.0;
        $rewardAmount = 100.0; // 50 AIS qolgan, lekin 100 kerak

        $remaining = $totalBudget - $spentBudget;
        $canPay    = $remaining >= $rewardAmount;

        $this->assertFalse($canPay, 'Yetarli byudjet bo\'lmasa to\'lov amalga oshirilmasligi kerak');
        $this->assertEquals(50.0, $remaining, 'Qolgan byudjet to\'g\'ri hisoblanishi kerak');
    }

    /**
     * Byudjet tugaganda kampaniya paused bo'lishi kerak
     */
    public function test_campaign_paused_when_budget_exhausted(): void
    {
        $scenarios = [
            ['total' => 100.0, 'spent' => 100.0, 'should_pause' => true],
            ['total' => 100.0, 'spent' => 99.9999, 'should_pause' => false],
            ['total' => 100.0, 'spent' => 100.0001, 'should_pause' => true],
            ['total' => 500.0, 'spent' => 500.0, 'should_pause' => true],
            ['total' => 500.0, 'spent' => 499.9999, 'should_pause' => false],
        ];

        foreach ($scenarios as $s) {
            $shouldPause = $s['spent'] >= $s['total'];
            $this->assertEquals(
                $s['should_pause'],
                $shouldPause,
                "total={$s['total']}, spent={$s['spent']}"
            );
        }
    }
}
