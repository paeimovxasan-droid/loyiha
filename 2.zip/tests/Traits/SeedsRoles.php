<?php

namespace Tests\Traits;

use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;

trait SeedsRoles
{
    protected function seedRolesAndPermissions(): void
    {
        app()[PermissionRegistrar::class]->forgetCachedPermissions();

        $permissions = [
            'users.view', 'users.create', 'users.edit', 'users.delete', 'users.ban', 'users.balance-adjust',
            'admins.view', 'admins.create', 'admins.edit', 'admins.delete', 'admins.ban',
            'roles.view', 'roles.create', 'roles.edit', 'roles.delete', 'roles.assign',
            'deposits.view', 'deposits.approve', 'deposits.reject',
            'withdrawals.view', 'withdrawals.approve', 'withdrawals.reject',
            'packages.view', 'packages.create', 'packages.edit', 'packages.delete',
            'stations.view', 'stations.create', 'stations.edit', 'stations.delete',
            'payment-methods.view', 'payment-methods.create', 'payment-methods.edit', 'payment-methods.delete',
            'settings.view', 'settings.edit',
            'translations.view', 'translations.create', 'translations.edit', 'translations.delete',
        ];

        foreach ($permissions as $perm) {
            Permission::firstOrCreate(['name' => $perm, 'guard_name' => 'web']);
        }

        $superAdmin = Role::firstOrCreate(['name' => 'super-admin', 'guard_name' => 'web']);
        $superAdmin->syncPermissions(Permission::all());

        $admin = Role::firstOrCreate(['name' => 'admin', 'guard_name' => 'web']);
        $admin->syncPermissions(Permission::all());

        Role::firstOrCreate(['name' => 'moderator', 'guard_name' => 'web']);
        Role::firstOrCreate(['name' => 'user', 'guard_name' => 'web']);
    }

    protected function createUser(array $attrs = []): User
    {
        return User::create(array_merge([
            'name'     => 'Test User',
            'username' => 'testuser' . rand(1000, 9999),
            'email'    => 'user' . rand(1000, 9999) . '@test.com',
            'password' => Hash::make('password123'),
            'status'   => 'active',
            'locale'   => 'uz',
            'balance'  => 0,
            'email_verified_at' => now(),
        ], $attrs));
    }

    protected function createRegularUser(array $attrs = []): User
    {
        $user = $this->createUser($attrs);
        $user->assignRole('user');
        return $user;
    }

    protected function createAdmin(array $attrs = []): User
    {
        $user = $this->createUser(array_merge(['email' => 'admin' . rand(1000, 9999) . '@test.com'], $attrs));
        $user->assignRole('admin');
        return $user;
    }

    protected function createSuperAdmin(array $attrs = []): User
    {
        $user = $this->createUser(array_merge(['email' => 'super' . rand(1000, 9999) . '@test.com'], $attrs));
        $user->assignRole('super-admin');
        return $user;
    }
}