<?php

namespace Tests\Feature\Front;

use App\Models\Payment\PaymentMethod;
use App\Models\Setting;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class WithdrawalTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();

        Setting::create([
            'site_name'    => ['uz' => 'Test', 'ru' => 'Test', 'en' => 'Test'],
            'currency'     => 'USD',
            'min_deposit'  => 10,
            'max_deposit'  => 10000,
            'min_withdraw' => 10,
            'max_withdraw' => 10000,
        ]);
    }

    private function createPaymentMethod(array $attrs = []): PaymentMethod
    {
        return PaymentMethod::create(array_merge([
            'name'                    => ['uz' => 'Test Metod', 'ru' => 'Test Метод', 'en' => 'Test Method'],
            'slug'                    => 'test-method-' . rand(100, 999),
            'number'                  => '1234567890',
            'minimum_deposit'         => 10,
            'maximum_deposit'         => 10000,
            'deposit_charge_percent'  => 2.0,
            'minimum_withdraw'        => 10,
            'maximum_withdraw'        => 10000,
            'withdraw_charge_percent' => 2.0,
            'status'                  => 'active',
            'sort_order'              => 1,
        ], $attrs));
    }

    // ─── POST /app/withdraw ──────────────────────────────────────────────────

    public function test_user_can_submit_withdrawal_request(): void
    {
        $user   = $this->createRegularUser(['balance' => 500.00]);
        $method = $this->createPaymentMethod();

        $response = $this->actingAs($user)->post('/app/withdraw', [
            'payment_method_id' => $method->id,
            'amount'            => 100,
            'account_number'    => '9901234567',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $user->refresh();
        $this->assertEquals('400.00', $user->balance);

        $this->assertDatabaseHas('withdrawals', [
            'user_id'           => $user->id,
            'payment_method_id' => $method->id,
            'amount'            => 100,
            'status'            => 'pending',
        ]);
    }

    public function test_withdrawal_charge_is_calculated_correctly(): void
    {
        $user   = $this->createRegularUser(['balance' => 500.00]);
        $method = $this->createPaymentMethod(['withdraw_charge_percent' => 5.0]);

        $this->actingAs($user)->post('/app/withdraw', [
            'payment_method_id' => $method->id,
            'amount'            => 200,
            'account_number'    => '9901234567',
        ]);

        // 5% of 200 = 10 charge, final = 190
        $this->assertDatabaseHas('withdrawals', [
            'user_id'      => $user->id,
            'amount'       => 200,
            'charge'       => 10,
            'final_amount' => 190,
        ]);
    }

    public function test_withdrawal_fails_with_insufficient_balance(): void
    {
        $user   = $this->createRegularUser(['balance' => 50.00]);
        $method = $this->createPaymentMethod();

        $response = $this->actingAs($user)->post('/app/withdraw', [
            'payment_method_id' => $method->id,
            'amount'            => 200,
            'account_number'    => '9901234567',
        ]);

        $response->assertSessionHas('error');

        $user->refresh();
        $this->assertEquals('50.00', $user->balance);
    }

    public function test_withdrawal_fails_below_minimum_amount(): void
    {
        $user   = $this->createRegularUser(['balance' => 500.00]);
        $method = $this->createPaymentMethod();

        $response = $this->actingAs($user)->post('/app/withdraw', [
            'payment_method_id' => $method->id,
            'amount'            => 1,  // min is 10
            'account_number'    => '9901234567',
        ]);

        $response->assertSessionHasErrors('amount');
    }

    public function test_withdrawal_fails_above_maximum_amount(): void
    {
        $user   = $this->createRegularUser(['balance' => 99999.00]);
        $method = $this->createPaymentMethod();

        $response = $this->actingAs($user)->post('/app/withdraw', [
            'payment_method_id' => $method->id,
            'amount'            => 99999,  // max is 10000
            'account_number'    => '9901234567',
        ]);

        $response->assertSessionHasErrors('amount');
    }

    public function test_withdrawal_creates_transaction(): void
    {
        $user   = $this->createRegularUser(['balance' => 500.00]);
        $method = $this->createPaymentMethod();

        $this->actingAs($user)->post('/app/withdraw', [
            'payment_method_id' => $method->id,
            'amount'            => 100,
            'account_number'    => '9901234567',
        ]);

        $this->assertDatabaseHas('transactions', [
            'user_id' => $user->id,
            'type'    => 'withdraw',
        ]);
    }

    public function test_withdrawal_requires_account_number(): void
    {
        $user   = $this->createRegularUser(['balance' => 500.00]);
        $method = $this->createPaymentMethod();

        $response = $this->actingAs($user)->post('/app/withdraw', [
            'payment_method_id' => $method->id,
            'amount'            => 100,
        ]);

        $response->assertSessionHasErrors('account_number');
    }

    public function test_withdrawal_requires_authentication(): void
    {
        $method = $this->createPaymentMethod();

        $response = $this->post('/app/withdraw', [
            'payment_method_id' => $method->id,
            'amount'            => 100,
            'account_number'    => '9901234567',
        ]);

        $response->assertRedirect(route('login'));
    }
}