<?php

namespace Tests\Feature\Front;

use App\Models\Package\Package;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class PackageTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    private function createPackage(array $attrs = []): Package
    {
        return Package::create(array_merge([
            'name'                 => ['uz' => 'Test Paket', 'ru' => 'Test Пакет', 'en' => 'Test Package'],
            'price'                => 100.00,
            'validity_days'        => 30,
            'daily_profit_percent' => 1.5,
            'total_profit_percent' => 45.0,
            'sponsor_income'       => 5.0,
            'ref_level1'           => 3.0,
            'ref_level2'           => 2.0,
            'ref_level3'           => 1.0,
            'status'               => 'active',
            'sort_order'           => 1,
        ], $attrs));
    }

    // ─── POST /app/packages/{package}/buy ────────────────────────────────────

    public function test_user_can_buy_package_with_sufficient_balance(): void
    {
        $package = $this->createPackage(['price' => 100.00]);
        $user    = $this->createRegularUser(['balance' => 200.00]);

        $response = $this->actingAs($user)->post("/app/packages/{$package->id}/buy");

        $response->assertRedirect(route('app.dashboard'));
        $response->assertSessionHas('success');

        $user->refresh();
        $this->assertEquals('100.00', $user->balance);

        $this->assertDatabaseHas('purchases', [
            'user_id'    => $user->id,
            'package_id' => $package->id,
        ]);
    }

    public function test_user_cannot_buy_package_with_insufficient_balance(): void
    {
        $package = $this->createPackage(['price' => 500.00]);
        $user    = $this->createRegularUser(['balance' => 100.00]);

        $response = $this->actingAs($user)->post("/app/packages/{$package->id}/buy");

        $response->assertRedirect();
        $response->assertSessionHas('error');

        $user->refresh();
        $this->assertEquals('100.00', $user->balance);

        $this->assertDatabaseMissing('purchases', [
            'user_id'    => $user->id,
            'package_id' => $package->id,
        ]);
    }

    public function test_buy_package_creates_transaction(): void
    {
        $package = $this->createPackage(['price' => 50.00]);
        $user    = $this->createRegularUser(['balance' => 200.00]);

        $this->actingAs($user)->post("/app/packages/{$package->id}/buy");

        $this->assertDatabaseHas('transactions', [
            'user_id' => $user->id,
            'type'    => 'purchase',
        ]);
    }

    public function test_buy_package_requires_authentication(): void
    {
        $package = $this->createPackage();

        $response = $this->post("/app/packages/{$package->id}/buy");

        $response->assertRedirect(route('login'));
    }

    public function test_buy_package_returns_404_for_nonexistent_package(): void
    {
        $user = $this->createRegularUser(['balance' => 1000.00]);

        $response = $this->actingAs($user)->post('/app/packages/99999/buy');

        $response->assertStatus(404);
    }
}
