<?php

namespace Tests\Feature\Front;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class ProfileTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    // ─── PUT /app/profile ────────────────────────────────────────────────────

    public function test_user_can_update_profile(): void
    {
        $user = $this->createRegularUser([
            'name'     => 'Old Name',
            'username' => 'oldusername',
            'email'    => 'old@example.com',
        ]);

        $response = $this->actingAs($user)->put('/app/profile', [
            'name'     => 'New Name',
            'username' => 'newusername',
            'email'    => 'new@example.com',
            'phone'    => '+998901112233',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $user->refresh();
        $this->assertEquals('New Name', $user->name);
        $this->assertEquals('newusername', $user->username);
        $this->assertEquals('new@example.com', $user->email);
    }

    public function test_profile_update_fails_with_taken_email(): void
    {
        $other = $this->createRegularUser(['email' => 'taken@example.com']);
        $user  = $this->createRegularUser(['email' => 'mine@example.com']);

        $response = $this->actingAs($user)->put('/app/profile', [
            'name'     => 'My Name',
            'username' => 'myusername',
            'email'    => 'taken@example.com',
        ]);

        $response->assertSessionHasErrors('email');
    }

    public function test_profile_update_fails_with_taken_username(): void
    {
        $this->createRegularUser(['username' => 'takenuser']);
        $user = $this->createRegularUser(['username' => 'myuser']);

        $response = $this->actingAs($user)->put('/app/profile', [
            'name'     => 'My Name',
            'username' => 'takenuser',
            'email'    => $user->email,
        ]);

        $response->assertSessionHasErrors('username');
    }

    public function test_profile_update_requires_authentication(): void
    {
        $response = $this->put('/app/profile', [
            'name'     => 'Test',
            'username' => 'test',
            'email'    => 'test@example.com',
        ]);

        $response->assertRedirect(route('login'));
    }

    public function test_user_can_update_own_profile_keeping_same_email(): void
    {
        $user = $this->createRegularUser([
            'email'    => 'same@example.com',
            'username' => 'sameuser',
        ]);

        $response = $this->actingAs($user)->put('/app/profile', [
            'name'     => 'Updated Name',
            'username' => 'sameuser',
            'email'    => 'same@example.com',
        ]);

        $response->assertSessionHas('success');
        $response->assertSessionMissing('errors');
    }

    // ─── PUT /app/profile/password ───────────────────────────────────────────

    public function test_user_can_change_password(): void
    {
        $user = $this->createRegularUser();

        $response = $this->actingAs($user)->put('/app/profile/password', [
            'current_password' => 'password123',
            'password'         => 'newpassword456',
            'password_confirmation' => 'newpassword456',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');
    }

    public function test_password_change_fails_with_wrong_current_password(): void
    {
        $user = $this->createRegularUser();

        $response = $this->actingAs($user)->put('/app/profile/password', [
            'current_password' => 'wrongcurrent',
            'password'         => 'newpassword456',
            'password_confirmation' => 'newpassword456',
        ]);

        $response->assertSessionHasErrors('current_password');
    }

    public function test_password_change_fails_with_short_new_password(): void
    {
        $user = $this->createRegularUser();

        $response = $this->actingAs($user)->put('/app/profile/password', [
            'current_password' => 'password123',
            'password'         => '123',
            'password_confirmation' => '123',
        ]);

        $response->assertSessionHasErrors('password');
    }

    public function test_password_change_fails_with_mismatched_confirmation(): void
    {
        $user = $this->createRegularUser();

        $response = $this->actingAs($user)->put('/app/profile/password', [
            'current_password' => 'password123',
            'password'         => 'newpassword456',
            'password_confirmation' => 'different789',
        ]);

        $response->assertSessionHasErrors('password');
    }

    public function test_password_change_requires_authentication(): void
    {
        $response = $this->put('/app/profile/password', [
            'current_password' => 'password123',
            'password'         => 'newpassword456',
            'password_confirmation' => 'newpassword456',
        ]);

        $response->assertRedirect(route('login'));
    }
}