<?php

namespace Tests\Feature\Front;

use App\Models\Payment\PaymentMethod;
use App\Models\Setting;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class DepositTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();

        // Sozlamalarni yaratish
        Setting::create([
            'site_name'   => ['uz' => 'Test', 'ru' => 'Test', 'en' => 'Test'],
            'currency'    => 'USD',
            'min_deposit' => 10,
            'max_deposit' => 10000,
            'min_withdraw' => 10,
            'max_withdraw' => 10000,
        ]);
    }

    private function createPaymentMethod(array $attrs = []): PaymentMethod
    {
        return PaymentMethod::create(array_merge([
            'name'                    => ['uz' => 'Test Metod', 'ru' => 'Test Метод', 'en' => 'Test Method'],
            'slug'                    => 'test-method-' . rand(100, 999),
            'number'                  => '1234567890',
            'minimum_deposit'         => 10,
            'maximum_deposit'         => 10000,
            'deposit_charge_percent'  => 2.0,
            'minimum_withdraw'        => 10,
            'maximum_withdraw'        => 10000,
            'withdraw_charge_percent' => 1.5,
            'status'                  => 'active',
            'sort_order'              => 1,
        ], $attrs));
    }

    // ─── POST /app/deposit ───────────────────────────────────────────────────

    public function test_user_can_submit_deposit_request(): void
    {
        $user   = $this->createRegularUser();
        $method = $this->createPaymentMethod();

        $response = $this->actingAs($user)->post('/app/deposit', [
            'payment_method_id' => $method->id,
            'amount'            => 100,
            'sender_number'     => '9901234567',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $this->assertDatabaseHas('deposits', [
            'user_id'           => $user->id,
            'payment_method_id' => $method->id,
            'amount'            => 100,
            'status'            => 'pending',
        ]);
    }

    public function test_deposit_charge_is_calculated_correctly(): void
    {
        $user   = $this->createRegularUser();
        $method = $this->createPaymentMethod(['deposit_charge_percent' => 5.0]);

        $this->actingAs($user)->post('/app/deposit', [
            'payment_method_id' => $method->id,
            'amount'            => 200,
            'sender_number'     => '9901234567',
        ]);

        // 5% of 200 = 10 charge, final = 190
        $this->assertDatabaseHas('deposits', [
            'user_id'      => $user->id,
            'amount'       => 200,
            'charge'       => 10,
            'final_amount' => 190,
        ]);
    }

    public function test_deposit_fails_below_minimum_amount(): void
    {
        $user   = $this->createRegularUser();
        $method = $this->createPaymentMethod();

        $response = $this->actingAs($user)->post('/app/deposit', [
            'payment_method_id' => $method->id,
            'amount'            => 1,  // min is 10
            'sender_number'     => '9901234567',
        ]);

        $response->assertSessionHasErrors('amount');
    }

    public function test_deposit_fails_above_maximum_amount(): void
    {
        $user   = $this->createRegularUser();
        $method = $this->createPaymentMethod();

        $response = $this->actingAs($user)->post('/app/deposit', [
            'payment_method_id' => $method->id,
            'amount'            => 99999,  // max is 10000
            'sender_number'     => '9901234567',
        ]);

        $response->assertSessionHasErrors('amount');
    }

    public function test_deposit_fails_with_invalid_payment_method(): void
    {
        $user = $this->createRegularUser();

        $response = $this->actingAs($user)->post('/app/deposit', [
            'payment_method_id' => 99999,
            'amount'            => 100,
            'sender_number'     => '9901234567',
        ]);

        $response->assertSessionHasErrors('payment_method_id');
    }

    public function test_deposit_requires_sender_number(): void
    {
        $user   = $this->createRegularUser();
        $method = $this->createPaymentMethod();

        $response = $this->actingAs($user)->post('/app/deposit', [
            'payment_method_id' => $method->id,
            'amount'            => 100,
        ]);

        $response->assertSessionHasErrors('sender_number');
    }

    public function test_deposit_requires_authentication(): void
    {
        $method = $this->createPaymentMethod();

        $response = $this->post('/app/deposit', [
            'payment_method_id' => $method->id,
            'amount'            => 100,
            'sender_number'     => '9901234567',
        ]);

        $response->assertRedirect(route('login'));
    }
}