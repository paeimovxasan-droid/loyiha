<?php

/**
 * Feature: ideal-kyc-system
 * Property 1: KYC Status Invarianti
 *
 * Har qanday KYC operatsiyasidan keyin kyc_status faqat
 * ruxsat etilgan qiymatlardan biri bo'lishi kerak.
 * 'approved', 'pending', 'video_pending' kabi eski yoki noto'g'ri
 * qiymatlar hech qachon yozilmasligi kerak.
 *
 * Validates: Requirements 1.1, 1.2, 1.3, 1.6
 */

use App\Models\Security\FaceKycAttempt;
use App\Models\User;
use App\Services\Security\FaceKycService;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

$ALLOWED_STATUSES = ['none', 'passport_pending', 'passport_verified', 'face_pending', 'verified', 'rejected'];

// ── Property 1: Status har doim ruxsat etilgan to'plamdan ────────────────────

it('kyc_status har doim ruxsat etilgan qiymatlardan biri — 100 iteratsiya', function () use ($ALLOWED_STATUSES) {
    for ($i = 0; $i < 100; $i++) {
        $user = User::factory()->create(['kyc_status' => 'none']);

        // Tasodifiy operatsiya tanlash (0-5)
        $op = $i % 6;

        match ($op) {
            // none → passport_pending
            0 => $user->update(['kyc_status' => 'passport_pending', 'kyc_stage' => 'passport']),
            // passport_pending → passport_verified
            1 => $user->update(['kyc_status' => 'passport_pending', 'kyc_stage' => 'passport']) &&
                 $user->update(['kyc_status' => 'passport_verified']),
            // passport_pending → rejected
            2 => $user->update(['kyc_status' => 'passport_pending']) &&
                 $user->update(['kyc_status' => 'rejected', 'kyc_rejection_reason' => 'Test']),
            // passport_verified → face_pending
            3 => $user->update(['kyc_status' => 'passport_verified']) &&
                 $user->update(['kyc_status' => 'face_pending', 'kyc_stage' => 'face_id']),
            // face_pending → verified
            4 => $user->update(['kyc_status' => 'face_pending']) &&
                 $user->update(['kyc_status' => 'verified', 'kyc_verified_at' => now()]),
            // rejected → passport_pending (qayta urinish)
            5 => $user->update(['kyc_status' => 'rejected']) &&
                 $user->update(['kyc_status' => 'passport_pending']),
        };

        $freshStatus = $user->fresh()->kyc_status;

        expect(in_array($freshStatus, $ALLOWED_STATUSES))
            ->toBeTrue("Iteratsiya {$i}: kyc_status='{$freshStatus}' ruxsat etilmagan qiymat!");
    }
});

it("'approved' qiymati hech qachon kyc_status sifatida yozilmaydi", function () {
    $user = User::factory()->create(['kyc_status' => 'face_pending']);

    $attempt = FaceKycAttempt::factory()->create([
        'user_id' => $user->id,
        'status'  => 'submitted',
    ]);

    FaceKycService::approveUser($user, $attempt);

    expect($user->fresh()->kyc_status)
        ->toBe('verified')
        ->not->toBe('approved');
});

it("'pending' qiymati hech qachon kyc_status sifatida yozilmaydi", function () {
    $user = User::factory()->create(['kyc_status' => 'passport_verified']);

    $attempt = FaceKycAttempt::factory()->create([
        'user_id' => $user->id,
        'status'  => 'pending',
    ]);

    // processSubmission face_pending yozishi kerak, 'pending' emas
    // Bu test FaceKycService::processSubmission() ni mock qilmasdan
    // to'g'ridan-to'g'ri update ni tekshiradi
    $user->update(['kyc_status' => 'face_pending']);

    expect($user->fresh()->kyc_status)
        ->toBe('face_pending')
        ->not->toBe('pending');
});

it("'video_pending' qiymati hech qachon kyc_status sifatida yozilmaydi", function () use ($ALLOWED_STATUSES) {
    $user = User::factory()->create(['kyc_status' => 'none']);

    // Eski video_pending ni simulate qilishga urinish
    // Bu qiymat endi ENUM da yo'q, shuning uchun DB xatosi chiqishi kerak
    // Lekin biz faqat allowed statuslar ishlatilishini tekshiramiz
    $user->update(['kyc_status' => 'passport_pending']);

    expect(in_array($user->fresh()->kyc_status, $ALLOWED_STATUSES))->toBeTrue();
    expect($user->fresh()->kyc_status)->not->toBe('video_pending');
});
