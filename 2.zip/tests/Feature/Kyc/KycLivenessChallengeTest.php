<?php

/**
 * Feature: ideal-kyc-system
 * Property 6: Liveness Challenge To'plam va Hajm Xossasi
 *
 * generateChallenge() har chaqirilganda:
 *  - steps soni 2-3 oralig'ida bo'lishi kerak
 *  - barcha elementlar ruxsat etilgan to'plamdan bo'lishi kerak
 *  - session_id UUID v4 formatida bo'lishi kerak
 *
 * Validates: Requirements 3.3, 3.4
 */

use App\Services\Security\FaceKycService;

$ALLOWED_ACTIONS = ['turn_left', 'turn_right', 'blink', 'smile', 'nod'];
$UUID_V4_PATTERN = '/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i';

it('generateChallenge steps soni 2-3 oralig\'ida — 100 iteratsiya', function () {
    for ($i = 0; $i < 100; $i++) {
        $result = FaceKycService::generateChallenge();

        expect(count($result['steps']))
            ->toBeGreaterThanOrEqual(2, "Iteratsiya {$i}: steps soni 2 dan kam")
            ->toBeLessThanOrEqual(3, "Iteratsiya {$i}: steps soni 3 dan ko'p");
    }
});

it('generateChallenge barcha elementlar ruxsat etilgan to\'plamdan — 100 iteratsiya', function () use ($ALLOWED_ACTIONS) {
    for ($i = 0; $i < 100; $i++) {
        $result = FaceKycService::generateChallenge();

        $invalidActions = array_diff($result['steps'], $ALLOWED_ACTIONS);

        expect($invalidActions)
            ->toBeEmpty("Iteratsiya {$i}: Ruxsat etilmagan harakatlar: " . implode(', ', $invalidActions));
    }
});

it('generateChallenge session_id UUID v4 formatida — 100 iteratsiya', function () use ($UUID_V4_PATTERN) {
    for ($i = 0; $i < 100; $i++) {
        $result = FaceKycService::generateChallenge();

        expect($result['session_id'])
            ->toMatch($UUID_V4_PATTERN, "Iteratsiya {$i}: session_id UUID v4 formatida emas: {$result['session_id']}");
    }
});

it('generateChallenge har safar noyob session_id qaytaradi', function () {
    $sessionIds = [];

    for ($i = 0; $i < 100; $i++) {
        $result = FaceKycService::generateChallenge();
        $sessionIds[] = $result['session_id'];
    }

    // Barcha session_id lar noyob bo'lishi kerak
    $uniqueIds = array_unique($sessionIds);
    expect(count($uniqueIds))->toBe(100, '100 ta session_id dan takrorlanuvchi topildi');
});

it('generateChallenge steps massivi qaytaradi', function () {
    $result = FaceKycService::generateChallenge();

    expect($result)->toHaveKeys(['session_id', 'steps']);
    expect($result['steps'])->toBeArray();
});
