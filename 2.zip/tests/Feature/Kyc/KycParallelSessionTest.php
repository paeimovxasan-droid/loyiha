<?php

/**
 * Feature: ideal-kyc-system
 * Property 5: Parallel Sessiya Bloklash Invarianti
 *
 * Bir foydalanuvchi uchun bir vaqtda faqat bitta 'pending'
 * FaceKycAttempt bo'lishi mumkin. Yangi sessiya boshlanganda
 * avvalgi 'pending' sessiya 'expired' holatiga o'tkazilishi kerak.
 *
 * Validates: Requirements 2.6, 3.2
 */

use App\Models\Security\FaceKycAttempt;
use App\Models\User;
use App\Services\Security\FaceKycService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;

uses(RefreshDatabase::class);

it('bir foydalanuvchi uchun bir vaqtda faqat bitta pending sessiya — 100 iteratsiya', function () {
    for ($i = 0; $i < 100; $i++) {
        $user = User::factory()->create(['kyc_status' => 'passport_verified']);

        // Bir nechta sessiya boshlash
        $sessionCount = rand(2, 5);
        for ($j = 0; $j < $sessionCount; $j++) {
            // Mavjud pending sessiyalarni expired qilish (API logikasi)
            FaceKycAttempt::where('user_id', $user->id)
                ->where('status', 'pending')
                ->update(['status' => 'expired']);

            $challenge = FaceKycService::generateChallenge();
            FaceKycAttempt::create([
                'user_id'    => $user->id,
                'session_id' => $challenge['session_id'],
                'challenge'  => $challenge['steps'],
                'status'     => 'pending',
                'expires_at' => now()->addMinutes(10),
            ]);
        }

        $pendingCount = FaceKycAttempt::where('user_id', $user->id)
            ->where('status', 'pending')
            ->count();

        expect($pendingCount)
            ->toBeLessThanOrEqual(1, "Iteratsiya {$i}: {$pendingCount} ta pending sessiya topildi, maksimum 1 bo'lishi kerak");
    }
});

it('yangi sessiya boshlanganda avvalgi pending sessiya expired bo\'ladi', function () {
    $user = User::factory()->create(['kyc_status' => 'passport_verified']);

    // Birinchi sessiya
    $firstAttempt = FaceKycAttempt::create([
        'user_id'    => $user->id,
        'session_id' => Str::uuid()->toString(),
        'challenge'  => ['blink', 'smile'],
        'status'     => 'pending',
        'expires_at' => now()->addMinutes(10),
    ]);

    // Yangi sessiya boshlash — avvalgi pending ni expired qilish kerak
    FaceKycAttempt::where('user_id', $user->id)
        ->where('status', 'pending')
        ->update(['status' => 'expired']);

    $secondAttempt = FaceKycAttempt::create([
        'user_id'    => $user->id,
        'session_id' => Str::uuid()->toString(),
        'challenge'  => ['turn_left', 'nod'],
        'status'     => 'pending',
        'expires_at' => now()->addMinutes(10),
    ]);

    expect($firstAttempt->fresh()->status)->toBe('expired');
    expect($secondAttempt->fresh()->status)->toBe('pending');

    $pendingCount = FaceKycAttempt::where('user_id', $user->id)
        ->where('status', 'pending')
        ->count();
    expect($pendingCount)->toBe(1);
});

it('API orqali yangi sessiya boshlash avvalgi pending ni expired qiladi', function () {
    $user = User::factory()->create(['kyc_status' => 'passport_verified']);

    // Birinchi sessiya yaratish
    $firstAttempt = FaceKycAttempt::create([
        'user_id'    => $user->id,
        'session_id' => Str::uuid()->toString(),
        'challenge'  => ['blink'],
        'status'     => 'pending',
        'expires_at' => now()->addMinutes(10),
    ]);

    // API orqali yangi sessiya boshlash
    $response = $this->actingAs($user)
        ->postJson('/api/v1/kyc/face/start');

    expect($response->status())->toBe(200);
    expect($firstAttempt->fresh()->status)->toBe('expired');

    $pendingCount = FaceKycAttempt::where('user_id', $user->id)
        ->where('status', 'pending')
        ->count();
    expect($pendingCount)->toBe(1);
});
