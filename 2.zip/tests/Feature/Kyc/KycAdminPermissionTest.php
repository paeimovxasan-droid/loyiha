<?php

/**
 * Feature: ideal-kyc-system
 * Property 8: Admin Permission Invarianti
 *
 * kyc.view, kyc.approve, kyc.reject permissionlari bo'lmagan
 * foydalanuvchi 403 olishi kerak. Permission mavjud bo'lsa ruxsat.
 *
 * Validates: Requirements 5.1, 5.2, 5.3, 8.5
 */

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

uses(RefreshDatabase::class);

beforeEach(function () {
    // Permissionlarni yaratish
    Permission::firstOrCreate(['name' => 'kyc.view',    'guard_name' => 'web']);
    Permission::firstOrCreate(['name' => 'kyc.approve', 'guard_name' => 'web']);
    Permission::firstOrCreate(['name' => 'kyc.reject',  'guard_name' => 'web']);
});

// ── kyc.view yo'q → 403 ──────────────────────────────────────────────────────

it('kyc.view permissioni yo\'q foydalanuvchi KYC ro\'yxatini ko\'ra olmaydi — 100 iteratsiya', function () {
    for ($i = 0; $i < 100; $i++) {
        $user = User::factory()->create();
        // Hech qanday KYC permission bermaslik
        $role = Role::firstOrCreate(['name' => "no-kyc-role-{$i}", 'guard_name' => 'web']);
        $user->assignRole($role);

        $response = $this->actingAs($user)
            ->get('/admin/kyc/passport');

        expect($response->status())
            ->toBeIn([403, 302], "Iteratsiya {$i}: kyc.view yo'q foydalanuvchi 403 yoki redirect olishi kerak");
    }
});

it('kyc.view permissioni bor foydalanuvchi KYC ro\'yxatini ko\'ra oladi', function () {
    $user = User::factory()->create();
    $role = Role::firstOrCreate(['name' => 'kyc-viewer', 'guard_name' => 'web']);
    $role->givePermissionTo('kyc.view');
    $user->assignRole($role);

    $response = $this->actingAs($user)
        ->get('/admin/kyc/passport');

    // 200 yoki redirect (auth middleware) — 403 bo'lmasligi kerak
    expect($response->status())->not->toBe(403);
});

// ── kyc.approve yo'q → 403 ───────────────────────────────────────────────────

it('kyc.approve permissioni yo\'q foydalanuvchi pasportni tasdiqlaya olmaydi', function () {
    $targetUser = User::factory()->create(['kyc_status' => 'passport_pending']);

    $adminUser = User::factory()->create();
    $role = Role::firstOrCreate(['name' => 'kyc-view-only', 'guard_name' => 'web']);
    $role->givePermissionTo('kyc.view'); // faqat view, approve yo'q
    $adminUser->assignRole($role);

    $response = $this->actingAs($adminUser)
        ->post("/admin/kyc/passport/{$targetUser->id}/approve");

    expect($response->status())->toBeIn([403, 302]);
});

it('kyc.approve permissioni bor foydalanuvchi pasportni tasdiqlaya oladi', function () {
    $targetUser = User::factory()->create(['kyc_status' => 'passport_pending']);

    $adminUser = User::factory()->create();
    $role = Role::firstOrCreate(['name' => 'kyc-approver', 'guard_name' => 'web']);
    $role->givePermissionTo(['kyc.view', 'kyc.approve']);
    $adminUser->assignRole($role);

    $response = $this->actingAs($adminUser)
        ->post("/admin/kyc/passport/{$targetUser->id}/approve");

    // 200 yoki redirect — 403 bo'lmasligi kerak
    expect($response->status())->not->toBe(403);
});

// ── kyc.reject yo'q → 403 ────────────────────────────────────────────────────

it('kyc.reject permissioni yo\'q foydalanuvchi pasportni rad eta olmaydi', function () {
    $targetUser = User::factory()->create(['kyc_status' => 'passport_pending']);

    $adminUser = User::factory()->create();
    $role = Role::firstOrCreate(['name' => 'kyc-view-only-2', 'guard_name' => 'web']);
    $role->givePermissionTo('kyc.view'); // faqat view, reject yo'q
    $adminUser->assignRole($role);

    $response = $this->actingAs($adminUser)
        ->post("/admin/kyc/passport/{$targetUser->id}/reject", [
            'reason' => 'Test sabab',
        ]);

    expect($response->status())->toBeIn([403, 302]);
});

it('kyc.reject permissioni bor foydalanuvchi pasportni rad eta oladi', function () {
    $targetUser = User::factory()->create(['kyc_status' => 'passport_pending']);

    $adminUser = User::factory()->create();
    $role = Role::firstOrCreate(['name' => 'kyc-rejecter', 'guard_name' => 'web']);
    $role->givePermissionTo(['kyc.view', 'kyc.reject']);
    $adminUser->assignRole($role);

    $response = $this->actingAs($adminUser)
        ->post("/admin/kyc/passport/{$targetUser->id}/reject", [
            'reason' => 'Hujjat noaniq',
        ]);

    expect($response->status())->not->toBe(403);
});

// ── RolePermissionSeeder smoke testi ─────────────────────────────────────────

it('RolePermissionSeeder dan keyin KYC permissionlari mavjud', function () {
    $this->artisan('db:seed', ['--class' => 'RolePermissionSeeder']);

    expect(Permission::where('name', 'kyc.view')->exists())->toBeTrue();
    expect(Permission::where('name', 'kyc.approve')->exists())->toBeTrue();
    expect(Permission::where('name', 'kyc.reject')->exists())->toBeTrue();
});

it('moderator roli KYC permissionlariga ega', function () {
    $this->artisan('db:seed', ['--class' => 'RolePermissionSeeder']);

    $moderator = Role::findByName('moderator');

    expect($moderator->hasPermissionTo('kyc.view'))->toBeTrue();
    expect($moderator->hasPermissionTo('kyc.approve'))->toBeTrue();
    expect($moderator->hasPermissionTo('kyc.reject'))->toBeTrue();
});

it('admin roli KYC permissionlariga ega', function () {
    $this->artisan('db:seed', ['--class' => 'RolePermissionSeeder']);

    $admin = Role::findByName('admin');

    expect($admin->hasPermissionTo('kyc.view'))->toBeTrue();
    expect($admin->hasPermissionTo('kyc.approve'))->toBeTrue();
    expect($admin->hasPermissionTo('kyc.reject'))->toBeTrue();
});
