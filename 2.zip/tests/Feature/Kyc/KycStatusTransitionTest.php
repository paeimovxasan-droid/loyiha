<?php

/**
 * Feature: ideal-kyc-system
 * Property 2: Status Tranzitsiya Grafi
 *
 * Faqat ruxsat etilgan tranzitsiyalar amalga oshirilishi mumkin.
 * Taqiqlangan tranzitsiyalar xato qaytarishi kerak.
 *
 * Validates: Requirements 1.4, 2.4, 3.1, 4.5, 4.6, 5.4, 5.6, 6.1, 6.5
 */

use App\Models\User;
use App\Services\Security\FaceKycService;
use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

// ── Ruxsat etilgan tranzitsiyalar ────────────────────────────────────────────

it('none → passport_pending: ruxsat etilgan', function () {
    $user = User::factory()->create(['kyc_status' => 'none']);
    $user->update(['kyc_status' => 'passport_pending', 'kyc_stage' => 'passport']);
    expect($user->fresh()->kyc_status)->toBe('passport_pending');
});

it('passport_pending → passport_verified: admin tasdiqlasa', function () {
    $user = User::factory()->create(['kyc_status' => 'passport_pending']);
    FaceKycService::approvePassport($user);
    expect($user->fresh()->kyc_status)->toBe('passport_verified');
});

it('passport_pending → rejected: admin rad etsa', function () {
    $user = User::factory()->create(['kyc_status' => 'passport_pending']);
    FaceKycService::rejectPassport($user, 'Hujjat noaniq');
    expect($user->fresh()->kyc_status)->toBe('rejected');
});

it('face_pending → verified: admin tasdiqlasa', function () {
    $user = User::factory()->create(['kyc_status' => 'face_pending']);
    FaceKycService::approveUser($user);
    expect($user->fresh()->kyc_status)->toBe('verified');
});

it('face_pending → rejected: admin rad etsa', function () {
    $user = User::factory()->create(['kyc_status' => 'face_pending']);
    FaceKycService::rejectUser($user, 'Yuz mos kelmadi');
    expect($user->fresh()->kyc_status)->toBe('rejected');
});

it('rejected → passport_pending: qayta urinish', function () {
    $user = User::factory()->create(['kyc_status' => 'rejected']);
    $user->update([
        'kyc_status'           => 'passport_pending',
        'kyc_stage'            => 'passport',
        'kyc_rejection_reason' => null,
    ]);
    expect($user->fresh()->kyc_status)->toBe('passport_pending');
});

// ── Taqiqlangan tranzitsiyalar — API orqali tekshirish ───────────────────────

it('Face ID sessiyasi none holatida boshlanmaydi — 100 iteratsiya', function () {
    $nonPassportVerifiedStatuses = [
        'none', 'passport_pending', 'face_pending', 'verified', 'rejected',
    ];

    for ($i = 0; $i < 100; $i++) {
        $status = $nonPassportVerifiedStatuses[$i % count($nonPassportVerifiedStatuses)];

        $user = User::factory()->create(['kyc_status' => $status]);

        $response = $this->actingAs($user)
            ->postJson('/api/v1/kyc/face/start');

        expect($response->status())
            ->toBe(403, "Iteratsiya {$i}: kyc_status='{$status}' bilan face/start 403 qaytarishi kerak");
    }
});

it('verified holatdan passport_pending ga o\'tish API orqali bloklanadi', function () {
    $user = User::factory()->create(['kyc_status' => 'verified']);

    $response = $this->actingAs($user)
        ->postJson('/api/v1/kyc/passport', [
            'document_type' => 'passport',
        ]);

    // 409 Conflict yoki 422 qaytarishi kerak
    expect($response->status())->toBeIn([409, 422]);
});

it('passport_pending holatdan face/start bloklanadi', function () {
    $user = User::factory()->create(['kyc_status' => 'passport_pending']);

    $response = $this->actingAs($user)
        ->postJson('/api/v1/kyc/face/start');

    expect($response->status())->toBe(403);
});
