<?php

namespace Tests\Feature\Auth;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class FrontAuthTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    // ─── POST /login ────────────────────────────────────────────────────────

    public function test_user_can_login_with_email(): void
    {
        $user = $this->createRegularUser(['email' => 'john@example.com']);

        $response = $this->post('/login', [
            'login'    => 'john@example.com',
            'password' => 'password123',
        ]);

        $response->assertRedirect(route('app.dashboard'));
        $this->assertAuthenticatedAs($user);
    }

    public function test_user_can_login_with_username(): void
    {
        $user = $this->createRegularUser(['username' => 'johndoe']);

        $response = $this->post('/login', [
            'login'    => 'johndoe',
            'password' => 'password123',
        ]);

        $response->assertRedirect(route('app.dashboard'));
        $this->assertAuthenticatedAs($user);
    }

    public function test_admin_is_redirected_to_admin_dashboard_on_login(): void
    {
        $admin = $this->createAdmin(['email' => 'admin@example.com']);

        $response = $this->post('/login', [
            'login'    => 'admin@example.com',
            'password' => 'password123',
        ]);

        $response->assertRedirect(route('admin.dashboard'));
    }

    public function test_login_fails_with_wrong_password(): void
    {
        $this->createRegularUser(['email' => 'john@example.com']);

        $response = $this->post('/login', [
            'login'    => 'john@example.com',
            'password' => 'wrongpassword',
        ]);

        $response->assertSessionHasErrors('login');
        $this->assertGuest();
    }

    public function test_login_fails_for_banned_user(): void
    {
        $this->createRegularUser([
            'email'  => 'banned@example.com',
            'status' => 'banned',
        ]);

        $response = $this->post('/login', [
            'login'    => 'banned@example.com',
            'password' => 'password123',
        ]);

        $response->assertSessionHasErrors('login');
        $this->assertGuest();
    }

    public function test_login_requires_login_and_password(): void
    {
        $response = $this->post('/login', []);

        $response->assertSessionHasErrors(['login', 'password']);
    }

    // ─── POST /register ─────────────────────────────────────────────────────

    public function test_user_can_register(): void
    {
        $response = $this->post('/register', [
            'name'                  => 'New User',
            'username'              => 'newuser123',
            'email'                 => 'newuser@example.com',
            'phone'                 => '+998901234567',
            'password'              => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertRedirect(route('app.dashboard'));
        $this->assertDatabaseHas('users', ['email' => 'newuser@example.com']);
        $this->assertAuthenticated();
    }

    public function test_register_with_referral(): void
    {
        $referrer = $this->createRegularUser(['username' => 'referrer01']);

        $response = $this->post('/register', [
            'name'                  => 'Referred User',
            'username'              => 'referred01',
            'email'                 => 'referred@example.com',
            'password'              => 'password123',
            'password_confirmation' => 'password123',
            'ref'                   => 'referrer01',
        ]);

        $response->assertRedirect(route('app.dashboard'));
        $this->assertDatabaseHas('users', [
            'email'       => 'referred@example.com',
            'referred_by' => 'referrer01',
        ]);
    }

    public function test_register_fails_with_duplicate_email(): void
    {
        $this->createRegularUser(['email' => 'existing@example.com']);

        $response = $this->post('/register', [
            'name'                  => 'Another User',
            'username'              => 'anotheruser',
            'email'                 => 'existing@example.com',
            'password'              => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertSessionHasErrors('email');
    }

    public function test_register_fails_with_duplicate_username(): void
    {
        $this->createRegularUser(['username' => 'takenuser']);

        $response = $this->post('/register', [
            'name'                  => 'Another User',
            'username'              => 'takenuser',
            'email'                 => 'another@example.com',
            'password'              => 'password123',
            'password_confirmation' => 'password123',
        ]);

        $response->assertSessionHasErrors('username');
    }

    public function test_register_fails_with_short_password(): void
    {
        $response = $this->post('/register', [
            'name'                  => 'Short Pass',
            'username'              => 'shortpass',
            'email'                 => 'short@example.com',
            'password'              => '123',
            'password_confirmation' => '123',
        ]);

        $response->assertSessionHasErrors('password');
    }

    public function test_register_fails_with_mismatched_passwords(): void
    {
        $response = $this->post('/register', [
            'name'                  => 'Mismatch',
            'username'              => 'mismatch01',
            'email'                 => 'mismatch@example.com',
            'password'              => 'password123',
            'password_confirmation' => 'different123',
        ]);

        $response->assertSessionHasErrors('password');
    }

    // ─── POST /logout ────────────────────────────────────────────────────────

    public function test_authenticated_user_can_logout(): void
    {
        $user = $this->createRegularUser();

        $response = $this->actingAs($user)->post('/logout');

        $response->assertRedirect(route('login'));
        $this->assertGuest();
    }
}