<?php

namespace Tests\Feature\Admin;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class AdminAuthTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    // ─── POST /admin/login ───────────────────────────────────────────────────

    public function test_admin_can_login(): void
    {
        $admin = $this->createAdmin(['email' => 'admin@example.com']);

        $response = $this->post('/admin/login', [
            'email'    => 'admin@example.com',
            'password' => 'password123',
        ]);

        $response->assertRedirect(route('admin.dashboard'));
        $this->assertAuthenticatedAs($admin);
    }

    public function test_super_admin_can_login(): void
    {
        $super = $this->createSuperAdmin(['email' => 'super@example.com']);

        $response = $this->post('/admin/login', [
            'email'    => 'super@example.com',
            'password' => 'password123',
        ]);

        $response->assertRedirect(route('admin.dashboard'));
        $this->assertAuthenticatedAs($super);
    }

    public function test_regular_user_cannot_access_admin(): void
    {
        $this->createRegularUser(['email' => 'user@example.com']);

        $response = $this->post('/admin/login', [
            'email'    => 'user@example.com',
            'password' => 'password123',
        ]);

        $response->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_admin_login_fails_with_wrong_password(): void
    {
        $this->createAdmin(['email' => 'admin@example.com']);

        $response = $this->post('/admin/login', [
            'email'    => 'admin@example.com',
            'password' => 'wrongpassword',
        ]);

        $response->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_banned_admin_cannot_login(): void
    {
        $this->createAdmin([
            'email'  => 'banned@example.com',
            'status' => 'banned',
        ]);

        $response = $this->post('/admin/login', [
            'email'    => 'banned@example.com',
            'password' => 'password123',
        ]);

        $response->assertSessionHasErrors('email');
        $this->assertGuest();
    }

    public function test_admin_login_requires_email_and_password(): void
    {
        $response = $this->post('/admin/login', []);

        $response->assertSessionHasErrors(['email', 'password']);
    }

    // ─── POST /admin/logout ──────────────────────────────────────────────────

    public function test_admin_can_logout(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/logout');

        $response->assertRedirect(route('admin.login'));
        $this->assertGuest();
    }
}