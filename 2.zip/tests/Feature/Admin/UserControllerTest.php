<?php

namespace Tests\Feature\Admin;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class UserControllerTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    // ─── POST /admin/users (store) ───────────────────────────────────────────

    public function test_admin_can_create_user(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/users', [
            'name'     => 'New Client',
            'username' => 'newclient01',
            'email'    => 'newclient@example.com',
            'phone'    => '+998901234567',
            'password' => 'password123',
            'status'   => 'active',
            'balance'  => 0,
        ]);

        $response->assertRedirect(route('admin.users.index'));
        $response->assertSessionHas('success');

        $this->assertDatabaseHas('users', [
            'email'    => 'newclient@example.com',
            'username' => 'newclient01',
        ]);
    }

    public function test_create_user_fails_with_duplicate_email(): void
    {
        $admin = $this->createAdmin();
        $this->createRegularUser(['email' => 'taken@example.com']);

        $response = $this->actingAs($admin)->post('/admin/users', [
            'name'     => 'Another',
            'username' => 'anotheruser01',
            'email'    => 'taken@example.com',
            'password' => 'password123',
            'status'   => 'active',
        ]);

        $response->assertSessionHasErrors('email');
    }

    public function test_create_user_requires_all_mandatory_fields(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/users', []);

        $response->assertSessionHasErrors(['name', 'username', 'email', 'password', 'status']);
    }

    public function test_create_user_fails_with_invalid_status(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/users', [
            'name'     => 'Test',
            'username' => 'testuser99',
            'email'    => 'test99@example.com',
            'password' => 'password123',
            'status'   => 'invalid_status',
        ]);

        $response->assertSessionHasErrors('status');
    }

    // ─── PUT /admin/users/{user} (update) ────────────────────────────────────

    public function test_admin_can_update_user(): void
    {
        $admin = $this->createAdmin();
        $user  = $this->createRegularUser([
            'name'     => 'Old Name',
            'username' => 'olduser',
            'email'    => 'old@example.com',
        ]);

        $response = $this->actingAs($admin)->put("/admin/users/{$user->id}", [
            'name'     => 'Updated Name',
            'username' => 'updateduser',
            'email'    => 'updated@example.com',
            'status'   => 'active',
        ]);

        $response->assertRedirect(route('admin.users.index'));
        $response->assertSessionHas('success');

        $user->refresh();
        $this->assertEquals('Updated Name', $user->name);
        $this->assertEquals('updated@example.com', $user->email);
    }

    public function test_update_user_can_change_password(): void
    {
        $admin = $this->createAdmin();
        $user  = $this->createRegularUser();

        $response = $this->actingAs($admin)->put("/admin/users/{$user->id}", [
            'name'     => $user->name,
            'username' => $user->username,
            'email'    => $user->email,
            'status'   => 'active',
            'password' => 'newpassword456',
        ]);

        $response->assertSessionHas('success');
    }

    public function test_update_user_fails_with_taken_email(): void
    {
        $admin = $this->createAdmin();
        $this->createRegularUser(['email' => 'taken@example.com']);
        $user = $this->createRegularUser(['email' => 'mine@example.com']);

        $response = $this->actingAs($admin)->put("/admin/users/{$user->id}", [
            'name'     => $user->name,
            'username' => $user->username,
            'email'    => 'taken@example.com',
            'status'   => 'active',
        ]);

        $response->assertSessionHasErrors('email');
    }

    // ─── POST /admin/users/{user}/ban ────────────────────────────────────────

    public function test_admin_can_ban_user(): void
    {
        $admin = $this->createAdmin();
        $user  = $this->createRegularUser(['status' => 'active']);

        $response = $this->actingAs($admin)->post("/admin/users/{$user->id}/ban");

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $user->refresh();
        $this->assertEquals('banned', $user->status);
    }

    public function test_admin_can_unban_user(): void
    {
        $admin = $this->createAdmin();
        $user  = $this->createRegularUser(['status' => 'banned']);

        $response = $this->actingAs($admin)->post("/admin/users/{$user->id}/ban");

        $response->assertSessionHas('success');

        $user->refresh();
        $this->assertEquals('active', $user->status);
    }

    // ─── POST /admin/users/{user}/balance ────────────────────────────────────

    public function test_admin_can_add_balance(): void
    {
        $admin = $this->createAdmin();
        $user  = $this->createRegularUser(['balance' => 100.00]);

        $response = $this->actingAs($admin)->post("/admin/users/{$user->id}/balance", [
            'action' => 'add',
            'amount' => 50,
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $user->refresh();
        $this->assertEquals('150.00', $user->balance);
    }

    public function test_admin_can_subtract_balance(): void
    {
        $admin = $this->createAdmin();
        $user  = $this->createRegularUser(['balance' => 200.00]);

        $response = $this->actingAs($admin)->post("/admin/users/{$user->id}/balance", [
            'action' => 'subtract',
            'amount' => 50,
        ]);

        $response->assertSessionHas('success');

        $user->refresh();
        $this->assertEquals('150.00', $user->balance);
    }

    public function test_balance_subtract_fails_when_insufficient(): void
    {
        $admin = $this->createAdmin();
        $user  = $this->createRegularUser(['balance' => 30.00]);

        $response = $this->actingAs($admin)->post("/admin/users/{$user->id}/balance", [
            'action' => 'subtract',
            'amount' => 100,
        ]);

        $response->assertSessionHas('error');

        $user->refresh();
        $this->assertEquals('30.00', $user->balance);
    }

    public function test_balance_adjust_fails_with_invalid_action(): void
    {
        $admin = $this->createAdmin();
        $user  = $this->createRegularUser();

        $response = $this->actingAs($admin)->post("/admin/users/{$user->id}/balance", [
            'action' => 'invalid',
            'amount' => 50,
        ]);

        $response->assertSessionHasErrors('action');
    }

    public function test_balance_adjust_requires_positive_amount(): void
    {
        $admin = $this->createAdmin();
        $user  = $this->createRegularUser();

        $response = $this->actingAs($admin)->post("/admin/users/{$user->id}/balance", [
            'action' => 'add',
            'amount' => 0,
        ]);

        $response->assertSessionHasErrors('amount');
    }

    public function test_user_controller_requires_admin_auth(): void
    {
        $guest = $this->createRegularUser();

        $response = $this->actingAs($guest)->post('/admin/users', [
            'name'     => 'Test',
            'username' => 'test01',
            'email'    => 'test@example.com',
            'password' => 'password123',
            'status'   => 'active',
        ]);

        // Regular user should be redirected (no admin access)
        $response->assertRedirect();
    }
}