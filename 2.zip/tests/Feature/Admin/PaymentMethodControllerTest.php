<?php

namespace Tests\Feature\Admin;

use App\Models\Payment\PaymentMethod;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class PaymentMethodControllerTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    private function validMethodData(array $override = []): array
    {
        return array_merge([
            'name'                    => ['uz' => 'Payme', 'ru' => 'Payme', 'en' => 'Payme'],
            'number'                  => '9860123456789012',
            'minimum_deposit'         => 10,
            'maximum_deposit'         => 10000,
            'deposit_charge_percent'  => 2.0,
            'minimum_withdraw'        => 10,
            'maximum_withdraw'        => 10000,
            'withdraw_charge_percent' => 1.5,
            'status'                  => 'active',
            'sort_order'              => 1,
        ], $override);
    }

    private function createMethod(array $attrs = []): PaymentMethod
    {
        return PaymentMethod::create(array_merge([
            'name'                    => ['uz' => 'Test', 'ru' => 'Test', 'en' => 'Test'],
            'slug'                    => 'test-' . rand(1000, 9999),
            'minimum_deposit'         => 10,
            'maximum_deposit'         => 10000,
            'deposit_charge_percent'  => 2.0,
            'minimum_withdraw'        => 10,
            'maximum_withdraw'        => 10000,
            'withdraw_charge_percent' => 1.5,
            'status'                  => 'active',
            'sort_order'              => 1,
        ], $attrs));
    }

    // ─── POST /admin/payment-methods (store) ─────────────────────────────────

    public function test_admin_can_create_payment_method(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/payment-methods', $this->validMethodData());

        $response->assertRedirect(route('admin.payment_methods.index'));
        $response->assertSessionHas('success');

        $this->assertDatabaseHas('payment_methods', ['status' => 'active']);
    }

    public function test_create_payment_method_requires_name_uz(): void
    {
        $admin = $this->createAdmin();

        $data         = $this->validMethodData();
        $data['name'] = ['uz' => '', 'ru' => 'Test'];

        $response = $this->actingAs($admin)->post('/admin/payment-methods', $data);

        $response->assertSessionHasErrors('name.uz');
    }

    public function test_create_payment_method_requires_numeric_deposit_limits(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/payment-methods',
            $this->validMethodData([
                'minimum_deposit' => 'not_a_number',
                'maximum_deposit' => 'not_a_number',
            ])
        );

        $response->assertSessionHasErrors(['minimum_deposit', 'maximum_deposit']);
    }

    public function test_create_payment_method_requires_valid_status(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/payment-methods',
            $this->validMethodData(['status' => 'pending'])
        );

        $response->assertSessionHasErrors('status');
    }

    public function test_create_payment_method_generates_slug(): void
    {
        $admin = $this->createAdmin();

        $this->actingAs($admin)->post('/admin/payment-methods', $this->validMethodData([
            'name' => ['uz' => 'Click To\'lov', 'ru' => 'Click', 'en' => 'Click'],
        ]));

        $method = PaymentMethod::where('status', 'active')->latest()->first();
        $this->assertNotEmpty($method->slug);
        $this->assertStringContainsString('click', $method->slug);
    }

    // ─── PUT /admin/payment-methods/{method} (update) ────────────────────────

    public function test_admin_can_update_payment_method(): void
    {
        $admin  = $this->createAdmin();
        $method = $this->createMethod();

        $response = $this->actingAs($admin)->put("/admin/payment-methods/{$method->id}",
            $this->validMethodData([
                'name'                   => ['uz' => 'Yangi Nom', 'ru' => 'Новое Имя', 'en' => 'New Name'],
                'minimum_deposit'        => 20,
                'deposit_charge_percent' => 3.0,
            ])
        );

        $response->assertRedirect(route('admin.payment_methods.index'));
        $response->assertSessionHas('success');

        $method->refresh();
        $this->assertEquals('Yangi Nom', $method->getTranslation('name', 'uz'));
        $this->assertEquals(20, $method->minimum_deposit);
        $this->assertEquals(3.0, $method->deposit_charge_percent);
    }

    public function test_update_payment_method_can_set_inactive(): void
    {
        $admin  = $this->createAdmin();
        $method = $this->createMethod(['status' => 'active']);

        $this->actingAs($admin)->put("/admin/payment-methods/{$method->id}",
            $this->validMethodData(['status' => 'inactive'])
        );

        $method->refresh();
        $this->assertEquals('inactive', $method->status);
    }

    public function test_update_payment_method_fails_without_name(): void
    {
        $admin  = $this->createAdmin();
        $method = $this->createMethod();

        $data         = $this->validMethodData();
        $data['name'] = ['uz' => '', 'ru' => ''];

        $response = $this->actingAs($admin)->put("/admin/payment-methods/{$method->id}", $data);

        $response->assertSessionHasErrors('name.uz');
    }

    public function test_update_payment_method_fails_with_negative_charge(): void
    {
        $admin  = $this->createAdmin();
        $method = $this->createMethod();

        $response = $this->actingAs($admin)->put("/admin/payment-methods/{$method->id}",
            $this->validMethodData(['deposit_charge_percent' => -1])
        );

        $response->assertSessionHasErrors('deposit_charge_percent');
    }

    public function test_payment_method_controller_requires_admin_auth(): void
    {
        $user = $this->createRegularUser();

        $response = $this->actingAs($user)->post('/admin/payment-methods', $this->validMethodData());

        $response->assertRedirect();
    }
}