<?php

namespace Tests\Feature\Admin;

use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Role;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class RoleControllerTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    // ─── POST /admin/roles (store) ───────────────────────────────────────────

    public function test_admin_can_create_role(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/roles', [
            'name'        => 'editor',
            'permissions' => ['users.view', 'deposits.view'],
        ]);

        $response->assertRedirect(route('admin.roles.index'));
        $response->assertSessionHas('success');

        $role = Role::where('name', 'editor')->first();
        $this->assertNotNull($role);
        $this->assertTrue($role->hasPermissionTo('users.view'));
        $this->assertTrue($role->hasPermissionTo('deposits.view'));
    }

    public function test_create_role_without_permissions(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/roles', [
            'name' => 'viewer',
        ]);

        $response->assertSessionHas('success');
        $this->assertDatabaseHas('roles', ['name' => 'viewer']);
    }

    public function test_create_role_fails_with_duplicate_name(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/roles', [
            'name' => 'admin', // already exists
        ]);

        $response->assertSessionHasErrors('name');
    }

    public function test_create_role_fails_without_name(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/roles', []);

        $response->assertSessionHasErrors('name');
    }

    public function test_create_role_fails_with_invalid_permission(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/roles', [
            'name'        => 'newrole',
            'permissions' => ['nonexistent.permission'],
        ]);

        $response->assertSessionHasErrors('permissions.0');
    }

    // ─── PUT /admin/roles/{role} (update) ────────────────────────────────────

    public function test_admin_can_update_role(): void
    {
        $admin = $this->createAdmin();
        $role  = Role::create(['name' => 'oldrole', 'guard_name' => 'web']);

        $response = $this->actingAs($admin)->put("/admin/roles/{$role->id}", [
            'name'        => 'updatedrole',
            'permissions' => ['users.view'],
        ]);

        $response->assertRedirect(route('admin.roles.index'));
        $response->assertSessionHas('success');

        $role->refresh();
        $this->assertEquals('updatedrole', $role->name);
        $this->assertTrue($role->hasPermissionTo('users.view'));
    }

    public function test_cannot_update_super_admin_role(): void
    {
        $admin = $this->createAdmin();
        $superRole = Role::where('name', 'super-admin')->first();

        $response = $this->actingAs($admin)->put("/admin/roles/{$superRole->id}", [
            'name' => 'hacked',
        ]);

        $response->assertSessionHas('error');

        $superRole->refresh();
        $this->assertEquals('super-admin', $superRole->name);
    }

    public function test_update_role_removes_all_permissions_when_none_sent(): void
    {
        $admin = $this->createAdmin();
        $role  = Role::create(['name' => 'testrole', 'guard_name' => 'web']);
        $role->givePermissionTo('users.view');

        $response = $this->actingAs($admin)->put("/admin/roles/{$role->id}", [
            'name' => 'testrole',
            // no permissions key = remove all
        ]);

        $response->assertSessionHas('success');
        $role->refresh();
        $this->assertEquals(0, $role->permissions->count());
    }

    // ─── POST /admin/roles/{role}/permissions ─────────────────────────────────

    public function test_admin_can_sync_role_permissions(): void
    {
        $admin = $this->createAdmin();
        $role  = Role::create(['name' => 'customrole', 'guard_name' => 'web']);

        $response = $this->actingAs($admin)->post("/admin/roles/{$role->id}/permissions", [
            'permissions' => ['users.view', 'deposits.view'],
        ]);

        $response->assertRedirect();

        $role->refresh();
        $this->assertTrue($role->hasPermissionTo('users.view'));
        $this->assertTrue($role->hasPermissionTo('deposits.view'));
    }
}