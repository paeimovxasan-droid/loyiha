<?php

namespace Tests\Feature\Admin;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Role;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class AdminUserControllerTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    // ─── POST /admin/admins (store) ──────────────────────────────────────────

    public function test_super_admin_can_create_admin(): void
    {
        $super = $this->createSuperAdmin();

        $response = $this->actingAs($super)->post('/admin/admins', [
            'name'     => 'New Admin',
            'username' => 'newadmin01',
            'email'    => 'newadmin@example.com',
            'phone'    => '+998901234567',
            'password' => 'password123',
            'role'     => 'admin',
            'status'   => 'active',
        ]);

        $response->assertRedirect(route('admin.admins.index'));
        $response->assertSessionHas('success');

        $this->assertDatabaseHas('users', ['email' => 'newadmin@example.com']);

        $newAdmin = User::where('email', 'newadmin@example.com')->first();
        $this->assertTrue($newAdmin->hasRole('admin'));
    }

    public function test_create_admin_fails_with_duplicate_email(): void
    {
        $super = $this->createSuperAdmin();
        $this->createAdmin(['email' => 'taken@example.com']);

        $response = $this->actingAs($super)->post('/admin/admins', [
            'name'     => 'Another',
            'username' => 'another01',
            'email'    => 'taken@example.com',
            'password' => 'password123',
            'role'     => 'admin',
            'status'   => 'active',
        ]);

        $response->assertSessionHasErrors('email');
    }

    public function test_create_admin_fails_with_invalid_role(): void
    {
        $super = $this->createSuperAdmin();

        $response = $this->actingAs($super)->post('/admin/admins', [
            'name'     => 'Test Admin',
            'username' => 'testadmin01',
            'email'    => 'testadmin@example.com',
            'password' => 'password123',
            'role'     => 'nonexistent_role',
            'status'   => 'active',
        ]);

        $response->assertSessionHasErrors('role');
    }

    // ─── PUT /admin/admins/{admin} (update) ──────────────────────────────────

    public function test_super_admin_can_update_admin(): void
    {
        $super = $this->createSuperAdmin();
        $admin = $this->createAdmin([
            'name'  => 'Old Admin',
            'email' => 'oldadmin@example.com',
        ]);

        $response = $this->actingAs($super)->put("/admin/admins/{$admin->id}", [
            'name'     => 'Updated Admin',
            'username' => $admin->username,
            'email'    => 'updatedadmin@example.com',
            'status'   => 'active',
        ]);

        $response->assertRedirect(route('admin.admins.index'));
        $response->assertSessionHas('success');

        $admin->refresh();
        $this->assertEquals('Updated Admin', $admin->name);
    }

    public function test_update_admin_with_password(): void
    {
        $super = $this->createSuperAdmin();
        $admin = $this->createAdmin();

        $response = $this->actingAs($super)->put("/admin/admins/{$admin->id}", [
            'name'     => $admin->name,
            'username' => $admin->username,
            'email'    => $admin->email,
            'status'   => 'active',
            'password' => 'newpassword456',
        ]);

        $response->assertSessionHas('success');
    }

    // ─── POST /admin/admins/{admin}/ban ──────────────────────────────────────

    public function test_super_admin_can_ban_admin(): void
    {
        $super = $this->createSuperAdmin();
        $admin = $this->createAdmin(['status' => 'active']);

        $response = $this->actingAs($super)->post("/admin/admins/{$admin->id}/ban");

        $response->assertSessionHas('success');

        $admin->refresh();
        $this->assertEquals('banned', $admin->status);
    }

    public function test_cannot_ban_super_admin(): void
    {
        $super1 = $this->createSuperAdmin();
        $super2 = $this->createSuperAdmin(['email' => 'super2@example.com']);

        $response = $this->actingAs($super1)->post("/admin/admins/{$super2->id}/ban");

        $response->assertSessionHas('error');

        $super2->refresh();
        $this->assertEquals('active', $super2->status);
    }

    // ─── POST /admin/admins/{admin}/role ─────────────────────────────────────

    public function test_super_admin_can_assign_role(): void
    {
        $super = $this->createSuperAdmin();
        $admin = $this->createAdmin();

        $response = $this->actingAs($super)->post("/admin/admins/{$admin->id}/role", [
            'role' => 'moderator',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $admin->refresh();
        $this->assertTrue($admin->hasRole('moderator'));
    }

    public function test_assign_role_fails_with_invalid_role(): void
    {
        $super = $this->createSuperAdmin();
        $admin = $this->createAdmin();

        $response = $this->actingAs($super)->post("/admin/admins/{$admin->id}/role", [
            'role' => 'invalid_role',
        ]);

        $response->assertSessionHasErrors('role');
    }
}