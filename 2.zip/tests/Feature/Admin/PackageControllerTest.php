<?php

namespace Tests\Feature\Admin;

use App\Models\Package\Package;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class PackageControllerTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    private function validPackageData(array $override = []): array
    {
        return array_merge([
            'name_uz'              => 'Bronza Paket',
            'name_ru'              => 'Бронзовый Пакет',
            'name_en'              => 'Bronze Package',
            'price'                => 100,
            'validity_days'        => 30,
            'daily_profit_percent' => 1.5,
            'total_profit_percent' => 45.0,
            'sponsor_income'       => 5.0,
            'ref_level1'           => 3.0,
            'ref_level2'           => 2.0,
            'ref_level3'           => 1.0,
            'status'               => 'active',
            'sort_order'           => 1,
        ], $override);
    }

    private function createPackage(array $attrs = []): Package
    {
        return Package::create(array_merge([
            'name'                 => ['uz' => 'Test', 'ru' => 'Test', 'en' => 'Test'],
            'price'                => 100.00,
            'validity_days'        => 30,
            'daily_profit_percent' => 1.5,
            'total_profit_percent' => 45.0,
            'sponsor_income'       => 5.0,
            'ref_level1'           => 3.0,
            'ref_level2'           => 2.0,
            'ref_level3'           => 1.0,
            'status'               => 'active',
            'sort_order'           => 1,
        ], $attrs));
    }

    // ─── POST /admin/packages (store) ────────────────────────────────────────

    public function test_admin_can_create_package(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/packages', $this->validPackageData());

        $response->assertRedirect(route('admin.packages.index'));
        $response->assertSessionHas('success');

        $this->assertDatabaseHas('packages', ['price' => 100]);
    }

    public function test_create_package_requires_name_uz(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/packages',
            $this->validPackageData(['name_uz' => ''])
        );

        $response->assertSessionHasErrors('name_uz');
    }

    public function test_create_package_requires_valid_price(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/packages',
            $this->validPackageData(['price' => -10])
        );

        $response->assertSessionHasErrors('price');
    }

    public function test_create_package_requires_valid_validity_days(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/packages',
            $this->validPackageData(['validity_days' => 0])
        );

        $response->assertSessionHasErrors('validity_days');
    }

    public function test_create_package_requires_valid_status(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/packages',
            $this->validPackageData(['status' => 'invalid'])
        );

        $response->assertSessionHasErrors('status');
    }

    public function test_create_default_package_unsets_previous_default(): void
    {
        $admin    = $this->createAdmin();
        $existing = $this->createPackage(['is_default' => true]);

        $this->actingAs($admin)->post('/admin/packages',
            $this->validPackageData(['is_default' => true])
        );

        $existing->refresh();
        $this->assertFalse($existing->is_default);
    }

    // ─── PUT /admin/packages/{id} (update) ───────────────────────────────────

    public function test_admin_can_update_package(): void
    {
        $admin   = $this->createAdmin();
        $package = $this->createPackage(['price' => 100]);

        $response = $this->actingAs($admin)->put("/admin/packages/{$package->id}",
            $this->validPackageData([
                'name_uz' => 'Yangilangan Paket',
                'price'   => 200,
            ])
        );

        $response->assertRedirect(route('admin.packages.index'));
        $response->assertSessionHas('success');

        $package->refresh();
        $this->assertEquals('Yangilangan Paket', $package->getTranslation('name', 'uz'));
        $this->assertEquals(200, $package->price);
    }

    public function test_update_package_fails_with_missing_name(): void
    {
        $admin   = $this->createAdmin();
        $package = $this->createPackage();

        $response = $this->actingAs($admin)->put("/admin/packages/{$package->id}",
            $this->validPackageData(['name_uz' => ''])
        );

        $response->assertSessionHasErrors('name_uz');
    }

    public function test_update_package_sets_translations(): void
    {
        $admin   = $this->createAdmin();
        $package = $this->createPackage();

        $this->actingAs($admin)->put("/admin/packages/{$package->id}",
            $this->validPackageData([
                'name_uz' => 'Yangi Uz',
                'name_ru' => 'Новый Ru',
                'name_en' => 'New En',
            ])
        );

        $package->refresh();
        $this->assertEquals('Yangi Uz', $package->getTranslation('name', 'uz'));
        $this->assertEquals('Новый Ru', $package->getTranslation('name', 'ru'));
        $this->assertEquals('New En', $package->getTranslation('name', 'en'));
    }

    public function test_package_controller_requires_admin_auth(): void
    {
        $user = $this->createRegularUser();

        $response = $this->actingAs($user)->post('/admin/packages', $this->validPackageData());

        $response->assertRedirect();
    }
}