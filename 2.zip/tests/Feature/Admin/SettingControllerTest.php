<?php

namespace Tests\Feature\Admin;

use App\Models\Setting;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class SettingControllerTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();

        // Sozlamalarni yaratish
        Setting::create([
            'site_name'    => ['uz' => 'Online Job', 'ru' => 'Online Job', 'en' => 'Online Job'],
            'currency'     => 'USD',
            'min_deposit'  => 10,
            'max_deposit'  => 10000,
            'min_withdraw' => 10,
            'max_withdraw' => 10000,
        ]);
    }

    private function validSettingData(array $override = []): array
    {
        return array_merge([
            'site_name'        => ['uz' => 'Yangi Nom', 'ru' => 'Новое Имя', 'en' => 'New Name'],
            'site_title'       => ['uz' => 'Sarlavha', 'ru' => 'Заголовок'],
            'site_description' => ['uz' => 'Tavsif', 'ru' => 'Описание'],
            'contact_phone'    => '+998901234567',
            'contact_email'    => 'contact@example.com',
            'telegram'         => '@testchannel',
            'instagram'        => '@testgram',
            'facebook'         => 'facebook.com/test',
            'youtube'          => 'youtube.com/test',
            'min_deposit'      => 10,
            'max_deposit'      => 5000,
            'min_withdraw'     => 20,
            'max_withdraw'     => 3000,
            'currency'         => 'USD',
        ], $override);
    }

    // ─── PUT /admin/settings ─────────────────────────────────────────────────

    public function test_admin_can_update_settings(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->put('/admin/settings', $this->validSettingData());

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $setting = Setting::get();
        $this->assertEquals('Yangi Nom', $setting->getTranslation('site_name', 'uz'));
        $this->assertEquals('USD', $setting->currency);
        $this->assertEquals(5000, $setting->max_deposit);
    }

    public function test_update_settings_requires_site_name_uz(): void
    {
        $admin = $this->createAdmin();

        $data              = $this->validSettingData();
        $data['site_name'] = ['uz' => ''];

        $response = $this->actingAs($admin)->put('/admin/settings', $data);

        $response->assertSessionHasErrors('site_name.uz');
    }

    public function test_update_settings_requires_deposit_limits(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->put('/admin/settings',
            $this->validSettingData([
                'min_deposit' => '',
                'max_deposit' => '',
            ])
        );

        $response->assertSessionHasErrors(['min_deposit', 'max_deposit']);
    }

    public function test_update_settings_requires_withdraw_limits(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->put('/admin/settings',
            $this->validSettingData([
                'min_withdraw' => '',
                'max_withdraw' => '',
            ])
        );

        $response->assertSessionHasErrors(['min_withdraw', 'max_withdraw']);
    }

    public function test_update_settings_requires_currency(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->put('/admin/settings',
            $this->validSettingData(['currency' => ''])
        );

        $response->assertSessionHasErrors('currency');
    }

    public function test_update_settings_validates_contact_email(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->put('/admin/settings',
            $this->validSettingData(['contact_email' => 'not-an-email'])
        );

        $response->assertSessionHasErrors('contact_email');
    }

    public function test_update_settings_saves_social_links(): void
    {
        $admin = $this->createAdmin();

        $this->actingAs($admin)->put('/admin/settings', $this->validSettingData([
            'telegram'  => '@mytelegram',
            'instagram' => '@myinstagram',
        ]));

        $setting = Setting::get();
        $this->assertEquals('@mytelegram', $setting->telegram);
        $this->assertEquals('@myinstagram', $setting->instagram);
    }

    public function test_settings_controller_requires_admin_auth(): void
    {
        $user = $this->createRegularUser();

        $response = $this->actingAs($user)->put('/admin/settings', $this->validSettingData());

        $response->assertRedirect();
    }

    public function test_guest_cannot_access_settings(): void
    {
        $response = $this->put('/admin/settings', $this->validSettingData());

        $response->assertRedirect();
    }
}