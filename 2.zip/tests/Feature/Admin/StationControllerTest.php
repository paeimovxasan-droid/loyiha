<?php

namespace Tests\Feature\Admin;

use App\Models\Station;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class StationControllerTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    private function validStationData(array $override = []): array
    {
        return array_merge([
            'name'          => ['uz' => 'Test Stansiya', 'ru' => 'Test Станция', 'en' => 'Test Station'],
            'address'       => ['uz' => 'Toshkent, Chilonzor', 'ru' => 'Ташкент, Чиланзар'],
            'district'      => ['uz' => 'Chilonzor', 'ru' => 'Чиланзар'],
            'capacity_kw'   => 150,
            'price_per_kw'  => 1500,
            'status'        => 'active',
            'latitude'      => 41.2995,
            'longitude'     => 69.2401,
        ], $override);
    }

    private function createStation(array $attrs = []): Station
    {
        return Station::create(array_merge([
            'name'         => ['uz' => 'Test', 'ru' => 'Test', 'en' => 'Test'],
            'capacity_kw'  => 100,
            'price_per_kw' => 1000,
            'status'       => 'active',
        ], $attrs));
    }

    // ─── POST /admin/stations (store) ────────────────────────────────────────

    public function test_admin_can_create_station(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/stations', $this->validStationData());

        $response->assertRedirect(route('admin.stations.index'));
        $response->assertSessionHas('success');

        $this->assertDatabaseHas('stations', ['capacity_kw' => 150]);
    }

    public function test_create_station_requires_name_uz(): void
    {
        $admin = $this->createAdmin();

        $data         = $this->validStationData();
        $data['name'] = ['uz' => '', 'ru' => 'Test'];

        $response = $this->actingAs($admin)->post('/admin/stations', $data);

        $response->assertSessionHasErrors('name.uz');
    }

    public function test_create_station_requires_capacity(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/stations',
            $this->validStationData(['capacity_kw' => ''])
        );

        $response->assertSessionHasErrors('capacity_kw');
    }

    public function test_create_station_requires_price(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/stations',
            $this->validStationData(['price_per_kw' => ''])
        );

        $response->assertSessionHasErrors('price_per_kw');
    }

    public function test_create_station_requires_valid_status(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/stations',
            $this->validStationData(['status' => 'invalid'])
        );

        $response->assertSessionHasErrors('status');
    }

    public function test_create_station_with_discount(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/stations',
            $this->validStationData([
                'has_discount'       => true,
                'old_price_per_kw'   => 2000,
            ])
        );

        $response->assertSessionHas('success');

        $this->assertDatabaseHas('stations', ['has_discount' => 1]);
    }

    public function test_create_station_with_maintenance_status(): void
    {
        $admin = $this->createAdmin();

        $response = $this->actingAs($admin)->post('/admin/stations',
            $this->validStationData(['status' => 'maintenance'])
        );

        $response->assertSessionHas('success');
        $this->assertDatabaseHas('stations', ['status' => 'maintenance']);
    }

    // ─── PUT /admin/stations/{station} (update) ──────────────────────────────

    public function test_admin_can_update_station(): void
    {
        $admin   = $this->createAdmin();
        $station = $this->createStation(['capacity_kw' => 100]);

        $response = $this->actingAs($admin)->put("/admin/stations/{$station->id}",
            $this->validStationData([
                'capacity_kw'  => 200,
                'price_per_kw' => 2000,
            ])
        );

        $response->assertRedirect(route('admin.stations.index'));
        $response->assertSessionHas('success');

        $station->refresh();
        $this->assertEquals(200, $station->capacity_kw);
        $this->assertEquals(2000, $station->price_per_kw);
    }

    public function test_update_station_sets_multilingual_name(): void
    {
        $admin   = $this->createAdmin();
        $station = $this->createStation();

        $this->actingAs($admin)->put("/admin/stations/{$station->id}",
            $this->validStationData([
                'name' => ['uz' => 'Yangi Stansiya', 'ru' => 'Новая Станция', 'en' => 'New Station'],
            ])
        );

        $station->refresh();
        $this->assertEquals('Yangi Stansiya', $station->getTranslation('name', 'uz'));
        $this->assertEquals('Новая Станция', $station->getTranslation('name', 'ru'));
        $this->assertEquals('New Station', $station->getTranslation('name', 'en'));
    }

    public function test_update_station_fails_with_invalid_status(): void
    {
        $admin   = $this->createAdmin();
        $station = $this->createStation();

        $response = $this->actingAs($admin)->put("/admin/stations/{$station->id}",
            $this->validStationData(['status' => 'broken'])
        );

        $response->assertSessionHasErrors('status');
    }

    public function test_update_station_can_change_to_inactive(): void
    {
        $admin   = $this->createAdmin();
        $station = $this->createStation(['status' => 'active']);

        $this->actingAs($admin)->put("/admin/stations/{$station->id}",
            $this->validStationData(['status' => 'inactive'])
        );

        $station->refresh();
        $this->assertEquals('inactive', $station->status);
    }

    public function test_station_controller_requires_admin_auth(): void
    {
        $user = $this->createRegularUser();

        $response = $this->actingAs($user)->post('/admin/stations', $this->validStationData());

        $response->assertRedirect();
    }
}