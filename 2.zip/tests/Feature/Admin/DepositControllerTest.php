<?php

namespace Tests\Feature\Admin;

use App\Models\Payment\Deposit;
use App\Models\Payment\PaymentMethod;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Str;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class DepositControllerTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    private function createPaymentMethod(): PaymentMethod
    {
        return PaymentMethod::create([
            'name'                    => ['uz' => 'Test', 'ru' => 'Test', 'en' => 'Test'],
            'slug'                    => 'test-' . rand(100, 999),
            'minimum_deposit'         => 10,
            'maximum_deposit'         => 10000,
            'deposit_charge_percent'  => 2.0,
            'minimum_withdraw'        => 10,
            'maximum_withdraw'        => 10000,
            'withdraw_charge_percent' => 2.0,
            'status'                  => 'active',
            'sort_order'              => 1,
        ]);
    }

    private function createDeposit(array $attrs = []): Deposit
    {
        $user   = $this->createRegularUser();
        $method = $this->createPaymentMethod();

        return Deposit::create(array_merge([
            'user_id'           => $user->id,
            'payment_method_id' => $method->id,
            'method_name'       => 'Test Method',
            'order_id'          => Str::uuid(),
            'sender_number'     => '9901234567',
            'amount'            => 100,
            'charge'            => 2,
            'final_amount'      => 98,
            'status'            => 'pending',
        ], $attrs));
    }

    // ─── POST /admin/deposits/{deposit}/approve ──────────────────────────────

    public function test_admin_can_approve_deposit(): void
    {
        $admin   = $this->createAdmin();
        $deposit = $this->createDeposit();
        $user    = $deposit->user;

        $initialBalance = $user->balance;

        $response = $this->actingAs($admin)->post("/admin/deposits/{$deposit->id}/approve", [
            'feedback' => 'Tasdiqlandi',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $deposit->refresh();
        $this->assertEquals('approved', $deposit->status);
        $this->assertNotNull($deposit->approved_at);

        $user->refresh();
        $this->assertEquals(
            bcadd((string) $initialBalance, '98.00', 2),
            $user->balance
        );

        $this->assertDatabaseHas('transactions', [
            'user_id' => $user->id,
            'type'    => 'deposit',
        ]);
    }

    public function test_cannot_approve_already_approved_deposit(): void
    {
        $admin   = $this->createAdmin();
        $deposit = $this->createDeposit(['status' => 'approved']);

        $response = $this->actingAs($admin)->post("/admin/deposits/{$deposit->id}/approve");

        $response->assertSessionHas('error');
    }

    public function test_cannot_approve_rejected_deposit(): void
    {
        $admin   = $this->createAdmin();
        $deposit = $this->createDeposit(['status' => 'rejected']);

        $response = $this->actingAs($admin)->post("/admin/deposits/{$deposit->id}/approve");

        $response->assertSessionHas('error');
    }

    // ─── POST /admin/deposits/{deposit}/reject ───────────────────────────────

    public function test_admin_can_reject_deposit(): void
    {
        $admin   = $this->createAdmin();
        $deposit = $this->createDeposit();

        $response = $this->actingAs($admin)->post("/admin/deposits/{$deposit->id}/reject", [
            'feedback' => 'Noto\'g\'ri ma\'lumot',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $deposit->refresh();
        $this->assertEquals('rejected', $deposit->status);
        $this->assertEquals('Noto\'g\'ri ma\'lumot', $deposit->feedback);
    }

    public function test_cannot_reject_already_approved_deposit(): void
    {
        $admin   = $this->createAdmin();
        $deposit = $this->createDeposit(['status' => 'approved']);

        $response = $this->actingAs($admin)->post("/admin/deposits/{$deposit->id}/reject");

        $response->assertSessionHas('error');
    }

    public function test_deposit_actions_require_admin_auth(): void
    {
        $user    = $this->createRegularUser();
        $deposit = $this->createDeposit();

        $response = $this->actingAs($user)->post("/admin/deposits/{$deposit->id}/approve");

        // Regular user has no admin access
        $response->assertRedirect();
    }
}