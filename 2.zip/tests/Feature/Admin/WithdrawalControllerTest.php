<?php

namespace Tests\Feature\Admin;

use App\Models\Payment\PaymentMethod;
use App\Models\Payment\Withdrawal;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use Tests\Traits\SeedsRoles;

class WithdrawalControllerTest extends TestCase
{
    use RefreshDatabase, SeedsRoles;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seedRolesAndPermissions();
    }

    private function createPaymentMethod(): PaymentMethod
    {
        return PaymentMethod::create([
            'name'                    => ['uz' => 'Test', 'ru' => 'Test', 'en' => 'Test'],
            'slug'                    => 'test-' . rand(100, 999),
            'minimum_deposit'         => 10,
            'maximum_deposit'         => 10000,
            'deposit_charge_percent'  => 2.0,
            'minimum_withdraw'        => 10,
            'maximum_withdraw'        => 10000,
            'withdraw_charge_percent' => 2.0,
            'status'                  => 'active',
            'sort_order'              => 1,
        ]);
    }

    private function createWithdrawal(array $attrs = []): Withdrawal
    {
        $user   = $this->createRegularUser(['balance' => 500.00]);
        $method = $this->createPaymentMethod();

        return Withdrawal::create(array_merge([
            'user_id'           => $user->id,
            'payment_method_id' => $method->id,
            'method_name'       => 'Test Method',
            'receiver_number'   => '9901234567',
            'amount'            => 100,
            'charge'            => 2,
            'final_amount'      => 98,
            'status'            => 'pending',
        ], $attrs));
    }

    // ─── POST /admin/withdrawals/{withdrawal}/approve ─────────────────────────

    public function test_admin_can_approve_withdrawal(): void
    {
        $admin      = $this->createAdmin();
        $withdrawal = $this->createWithdrawal();

        $response = $this->actingAs($admin)->post("/admin/withdrawals/{$withdrawal->id}/approve", [
            'feedback' => 'Tasdiqlandi',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $withdrawal->refresh();
        $this->assertEquals('approved', $withdrawal->status);
        $this->assertNotNull($withdrawal->approved_at);
    }

    public function test_cannot_approve_already_approved_withdrawal(): void
    {
        $admin      = $this->createAdmin();
        $withdrawal = $this->createWithdrawal(['status' => 'approved']);

        $response = $this->actingAs($admin)->post("/admin/withdrawals/{$withdrawal->id}/approve");

        $response->assertSessionHas('error');
    }

    public function test_cannot_approve_rejected_withdrawal(): void
    {
        $admin      = $this->createAdmin();
        $withdrawal = $this->createWithdrawal(['status' => 'rejected']);

        $response = $this->actingAs($admin)->post("/admin/withdrawals/{$withdrawal->id}/approve");

        $response->assertSessionHas('error');
    }

    // ─── POST /admin/withdrawals/{withdrawal}/reject ──────────────────────────

    public function test_admin_can_reject_withdrawal_and_refund_balance(): void
    {
        $admin      = $this->createAdmin();
        $withdrawal = $this->createWithdrawal(['amount' => 100]);
        $user       = $withdrawal->user;

        $initialBalance = $user->balance;

        $response = $this->actingAs($admin)->post("/admin/withdrawals/{$withdrawal->id}/reject", [
            'feedback' => 'Bekor qilindi',
        ]);

        $response->assertRedirect();
        $response->assertSessionHas('success');

        $withdrawal->refresh();
        $this->assertEquals('rejected', $withdrawal->status);
        $this->assertEquals('Bekor qilindi', $withdrawal->feedback);

        // Balance should be refunded
        $user->refresh();
        $this->assertEquals(
            bcadd((string) $initialBalance, '100.00', 2),
            $user->balance
        );

        $this->assertDatabaseHas('transactions', [
            'user_id'  => $user->id,
            'type'     => 'withdraw',
            'status'   => 'reversed',
        ]);
    }

    public function test_cannot_reject_already_rejected_withdrawal(): void
    {
        $admin      = $this->createAdmin();
        $withdrawal = $this->createWithdrawal(['status' => 'rejected']);

        $response = $this->actingAs($admin)->post("/admin/withdrawals/{$withdrawal->id}/reject");

        $response->assertSessionHas('error');
    }

    public function test_withdrawal_actions_require_admin_auth(): void
    {
        $user       = $this->createRegularUser();
        $withdrawal = $this->createWithdrawal();

        $response = $this->actingAs($user)->post("/admin/withdrawals/{$withdrawal->id}/approve");

        $response->assertRedirect();
    }
}